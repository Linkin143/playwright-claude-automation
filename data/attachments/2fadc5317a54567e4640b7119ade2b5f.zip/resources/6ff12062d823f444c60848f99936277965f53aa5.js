"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["feedDependencies"],{44587(t,o,l){l.d(o,{AnaheimLayoutTemplateMap:()=>lX});var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7"
        "slot8 slot9 slot10 slot11"
        "slot8 slot9 slot10 slot11";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot4 slot7"
        "slot2 slot4 slot7"
        "slot6 slot5 slot11"
        "slot6 slot5 slot11"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot7"
        "slot4 slot7"
        "slot5 slot11"
        "slot5 slot11"
        "slot6 slot8"
        "slot6 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),y={cardCount:11,rowHeightPx:{C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C4:[3,1],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:7,C2:6},telemetryRowCol:{C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:6,C2:8},telemetryRowCol:{C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:5,C2:5},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[5,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:9,C2:9},telemetryRowCol:{C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:10,C2:10},telemetryRowCol:{C4:[5,2],C3:[7,2],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:11,C2:11},telemetryRowCol:{C4:[5,3],C3:[7,3],C2:[11,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:8,C2:7},telemetryRowCol:{C4:[5,4],C3:[5,3],C2:[7,2],C1:[21,1]}}],styles:_},e=(0,s.A)`
    :host([layout="C5"]) {
        grid-template-areas:
            "slot1 slot1 slot2 slot3 slot4"
            "slot1 slot1 slot2 slot3 slot4"
            "slot5 slot6 slot7 slot7 slot8"
            "slot5 slot6 slot7 slot7 slot8";
    }

    :host([layout="C4"]) {
        grid-template-areas:
            "slot1 slot1 slot2 slot3"
            "slot1 slot1 slot2 slot3"
            "slot4 slot5 slot6 slot6"
            "slot4 slot5 slot6 slot6";
    }

    :host([layout="C3"]) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2"
            "slot3 slot4 slot5"
            "slot3 slot4 slot5";
    }

    :host([layout="C2"]) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3";
    }

    :host([layout="C1"]) {
        grid-template-areas:
            "slot1"
            "slot1"
            "slot2"
            "slot2";
    }
`.withBehaviors(),r=(0,C.P)(2),a={colWidthPx:300,gutterPx:12,styles:e},u=[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y}}],x=t=>{let o={},l=[];for(let C=1;C<=t;C++){let t=`C${C}`;o[t]=r;for(let o=1;o<=u.length;o++){let C=u[o-1];if(C.layouts[t]){let s=l[o-1];if(!s){let{layouts:t,...o}=C;s={...o,layouts:{}},l.push(s)}s.layouts[t]=C.layouts[t]}}}return{...a,cardCount:l.length,rowHeightPx:o,cardSlots:l}};var d=l(27783),i=l(81336),m=l(22754),g=l(41740),c=l(89270),w=l(77858),h=l(8634),R=l(77679),P=l(14642),D=l(65839),O=l(63041),p=l(23382),n=l(97510),f=l(93728),v=l(47956);let A=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot5 slot3 slot2 slot4"
        "slot1 slot5 slot3 slot2 slot4"
        "slot6 slot6 slot7 slot7 slot8"
        "slot6 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot8"
        "slot3 slot5 slot8"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot6"
        "slot6 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),W={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:A,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[3,1],C3:[3,2],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}}]},B=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot5 slot3 slot2 slot4"
        "slot1 slot5 slot3 slot2 slot4"
        "slot6 slot6 slot7 slot8 slot8"
        "slot6 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot8"
        "slot3 slot5 slot8"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot6"
        "slot6 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),H={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:B,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[3,1],C3:[3,2],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}}]},S=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot7 slot6 slot8"
        "slot5 slot5 slot7 slot6 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot7 slot5 slot6 slot8"
        "slot7 slot5 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),b={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:S,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:4,C2:5,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:2,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:6,C3:5,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:4,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},k=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),T={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:k,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:6,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},$=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot3 slot4"
        "slot2 slot1 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot4"
        "slot2 slot1 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),X={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:$,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:4,C2:5,C1:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:2,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:6,C3:5,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:6,C2:4,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},F=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot5"
        "slot3 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),E={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:F,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:4,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:6,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},L=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot3"
        "slot1 slot1 slot2 slot3 slot3"
        "slot4 slot5 slot6 slot7 slot8"
        "slot4 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot3"
        "slot1 slot1 slot3 slot3"
        "slot4 slot2 slot6 slot6"
        "slot4 slot2 slot6 slot6"
        "slot7 slot7 slot5 slot8"
        "slot7 slot7 slot5 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot4 slot2 slot8"
        "slot4 slot2 slot8"
        "slot5 slot6 slot7"
        "slot5 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot6"
        "slot3 slot6"
        "slot2 slot8"
        "slot2 slot8"
        "slot4 slot5"
        "slot4 slot5"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),Q={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:3},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[3,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:L},Z=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot2"
        "slot1 slot1 slot2 slot2"
        "slot5 slot3 slot4 slot4"
        "slot5 slot3 slot4 slot4"
        "slot7 slot7 slot6 slot8"
        "slot7 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot5 slot3 slot8"
        "slot5 slot3 slot8"
        "slot6 slot4 slot7"
        "slot6 slot4 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),j={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:3},telemetryRowCol:{C5:[1,5],C4:[3,3],C3:[5,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:Z},G=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3"
        "slot4 slot5 slot6 slot7 slot8"
        "slot4 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot4 slot3"
        "slot1 slot1 slot4 slot3"
        "slot2 slot2 slot5 slot5"
        "slot2 slot2 slot5 slot5"
        "slot7 slot7 slot6 slot8"
        "slot7 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot5 slot8"
        "slot2 slot5 slot8"
        "slot4 slot6 slot7"
        "slot4 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot8"
        "slot5 slot8"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),M={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:6,C2:6},telemetryRowCol:{C5:[3,1],C4:[1,3],C3:[5,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,2],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:G},q=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot3 slot8"
        "slot5 slot3 slot3 slot8"
        "slot6 slot6 slot7 slot7"
        "slot6 slot6 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot5 slot6 slot7"
        "slot5 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),z={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:7,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,2],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:8,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:6,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:q},I=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot4"
        "slot1 slot2 slot3 slot4 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),J={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:I,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:6,C2:5},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},K=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot4"
        "slot2 slot1 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot4"
        "slot2 slot1 slot4"
        "slot3 slot7 slot7"
        "slot3 slot7 slot7"
        "slot5 slot6 slot8"
        "slot5 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot3"
        "slot5 slot3"
        "slot7 slot7"
        "slot7 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),N={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:K,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:2,C3:2,C2:3,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:1,C3:1,C2:1,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:5,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:6,C2:4,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:5,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},U=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot7 slot6 slot8"
        "slot5 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),V={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:U,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:5},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},Y=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),tt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:Y,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:6,C2:5},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},to=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot7 slot7"
        "slot3 slot7 slot7"
        "slot5 slot6 slot8"
        "slot5 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot2"
        "slot2 slot2"
        "slot5 slot3"
        "slot5 slot3"
        "slot7 slot7"
        "slot7 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),tl={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:to,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:3,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:5,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:6,C2:4,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:5,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},tC=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot4"
        "slot1 slot1 slot3 slot4"
        "slot5 slot6 slot2 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot5 slot3 slot8"
        "slot5 slot3 slot8"
        "slot6 slot2 slot7"
        "slot6 slot2 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot4"
        "slot5 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot2 slot6"
        "slot2 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),ts={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,styles:tC,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:6,C3:7,C2:6,C1:2},telemetryRowCol:{C5:[1,3],C4:[3,3],C3:[5,2],C2:[7,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:2,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:6,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[4,3],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}]},t_=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot4"
        "slot4 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),ty={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}],styles:t_},te=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot7 slot6 slot5 slot5 slot8"
        "slot7 slot6 slot5 slot5 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot8"
        "slot3 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot5 slot7"
        "slot6 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),tr={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,1],C4:[4,2],C3:[5,3],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:te},ta=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot8"
        "slot3 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot5 slot7"
        "slot6 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),tu={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[4,2],C3:[5,3],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:ta},tx=(0,s.A)`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot5 slot2"
        "slot5 slot2"
        "slot4 slot6"
        "slot4 slot6"
        "slot8 slot7"
        "slot8 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),td={cardCount:8,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:4},telemetryRowCol:{C4:[1,2],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:5},telemetryRowCol:{C4:[1,4],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:3},telemetryRowCol:{C4:[3,1],C3:[3,3],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C4:[3,2],C3:[5,2],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:8},telemetryRowCol:{C4:[3,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,3],C2:[7,1],C1:[15,1]}}],styles:tx},ti=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot15 slot7 slot16 slot9"
        "slot10 slot11 slot12 slot13 slot14"
        "slot10 slot17 slot18 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot16"
        "slot5 slot3 slot15 slot16"
        "slot17 slot8 slot7 slot9"
        "slot18 slot8 slot7 slot9"
        "slot10 slot13 slot11 slot14"
        "slot10 slot13 slot12 slot14";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot16"
        "slot7 slot15 slot16"
        "slot17 slot8 slot5"
        "slot18 slot8 slot5"
        "slot11 slot11 slot10"
        "slot11 slot11 slot10"
        "slot12 slot13 slot14"
        "slot12 slot13 slot14";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot15 slot16"
        "slot17 slot11"
        "slot18 slot11"
        "slot10 slot14"
        "slot10 slot14"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot15"
        "slot7"
        "slot7"
        "slot8"
        "slot16"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot17"
        "slot12"
        "slot18"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),tm={cardCount:18,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(12),C2:(0,C.P)(16),C1:(0,C.P)(28)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:12,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:11,C3:6,C2:7,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:8,C4:10,C3:11,C2:9,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:12,C3:5,C2:5,C1:11},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:14,C3:15,C2:15,C1:12},telemetryRowCol:{C5:[5,1],C4:[7,1],C3:[9,3],C2:[13,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_1y},cardDomOrder:{C5:13,C4:16,C3:14,C2:13,C1:13},telemetryRowCol:{C5:[5,2],C4:[7,3],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_1y},cardDomOrder:{C5:14,C4:18,C3:16,C2:17,C1:15},telemetryRowCol:{C5:[5,3],C4:[8,3],C3:[11,1],C2:[15,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:15,C4:15,C3:17,C2:18,C1:17},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[11,2],C2:[15,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:16,C4:17,C3:18,C2:16,C1:18},telemetryRowCol:{C5:[5,5],C4:[7,4],C3:[11,3],C2:[13,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:10,C4:8,C3:9,C2:10,C1:7},telemetryRowCol:{C5:[4,2],C4:[4,3],C3:[6,2],C2:[10,1],C1:[12,1]}},{grid_area:"slot16",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:11,C4:7,C3:8,C2:11,C1:10},telemetryRowCol:{C5:[4,4],C4:[3,4],C3:[5,3],C2:[10,2],C1:[16,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:17,C4:9,C3:10,C2:12,C1:14},telemetryRowCol:{C5:[6,2],C4:[5,1],C3:[7,1],C2:[11,1],C1:[22,1]}},{grid_area:"slot18",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:18,C4:13,C3:13,C2:14,C1:16},telemetryRowCol:{C5:[6,3],C4:[6,1],C3:[8,1],C2:[12,1],C1:[24,1]}}],styles:ti},tg=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot7 slot10 slot8 slot11"
        "slot7 slot10 slot8 slot11";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),tc={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:10,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:11,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,4],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:tg},tw=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot8 slot10 slot7 slot11"
        "slot8 slot10 slot7 slot11";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),th={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:10,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:8,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:11,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,4],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:tw},tR=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot8"
        "slot5 slot3 slot6 slot8"
        "slot10 slot11 slot7 slot9"
        "slot10 slot11 slot7 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot7 slot6 slot9"
        "slot7 slot6 slot9"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),tP={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:10,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:7,C3:5,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:11,C3:8,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:8,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,1],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:9,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,2],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:tR},tD=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot7 slot3 slot9"
        "slot5 slot7 slot3 slot9"
        "slot6 slot6 slot8 slot13"
        "slot6 slot6 slot8 slot13"
        "slot12 slot11 slot10 slot10"
        "slot12 slot11 slot10 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot5 slot2 slot9"
        "slot5 slot2 slot9"
        "slot3 slot7 slot13"
        "slot3 slot7 slot13"
        "slot6 slot6 slot8"
        "slot6 slot6 slot8"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot13"
        "slot5 slot13"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot10"
        "slot8 slot10"
        "slot11 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),tO={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[5,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:9,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[7,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:13,C3:11,C2:11},telemetryRowCol:{C5:[5,1],C4:[7,3],C3:[9,1],C2:[11,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:11,C3:13,C2:13},telemetryRowCol:{C5:[5,4],C4:[7,1],C3:[9,3],C2:[13,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:8,C2:7},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[7,2],C1:[25,1]}}],styles:tD},tp=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot4 slot2 slot5"
        "slot1 slot4 slot3 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot2 slot1"
        "slot2 slot2 slot1"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot2"
        "slot2 slot2"
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),tn={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(10)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:2,C2:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,3],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:4},telemetryRowCol:{C5:[1,3],C4:[2,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:5},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[3,2],C1:[9,1]}}],styles:tp},tf=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),tv={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,2],C2:[3,2],C1:[7,1]}}],styles:tf},tA=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot3 slot2 slot2"
        "slot3 slot2 slot2";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),tW={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:300,gutterPx:12,styles:tA,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:4},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[3,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}}]},tB=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot6 slot7 slot8 slot9"
        "slot6 slot6 slot7 slot8 slot9"
        "slot10 slot11 slot12 slot13 slot14"
        "slot10 slot11 slot12 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot4 slot2 slot5"
        "slot1 slot4 slot2 slot5"
        "slot3 slot3 slot6 slot9"
        "slot3 slot3 slot6 slot9"
        "slot7 slot8 slot10 slot14"
        "slot7 slot8 slot10 slot14"
        "slot11 slot12 slot13 slot13"
        "slot11 slot12 slot13 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot9"
        "slot3 slot4 slot9"
        "slot6 slot7 slot14"
        "slot6 slot7 slot14"
        "slot8 slot8 slot10"
        "slot8 slot8 slot10"
        "slot11 slot12 slot13"
        "slot11 slot12 slot13";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot9"
        "slot2 slot9"
        "slot3 slot14"
        "slot3 slot14"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot10 slot11"
        "slot10 slot11"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),tH={cardCount:14,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(28)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:5,C2:7},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:11,C2:11},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,3],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,2],C4:[7,1],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:13,C3:13,C2:13},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:14,C3:14,C2:14},telemetryRowCol:{C5:[5,4],C4:[7,3],C3:[9,3],C2:[13,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:11,C3:9,C2:6},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[27,1]}}],styles:tB},tS=(0,s.A)`
:host {
    grid-template-areas:
        "slot2 slot3 slot6 slot4 slot5"
        "slot2 slot3 slot6 slot4 slot5"
        "slot1 slot1 slot7 slot10 slot9"
        "slot1 slot1 slot7 slot10 slot9"
        "slot8 slot11 slot12 slot13 slot14"
        "slot8 slot11 slot12 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot4 slot3 slot5"
        "slot2 slot4 slot3 slot5"
        "slot1 slot1 slot6 slot9"
        "slot1 slot1 slot6 slot9"
        "slot8 slot10 slot12 slot14"
        "slot8 slot10 slot12 slot14"
        "slot11 slot13 slot7 slot7"
        "slot11 slot13 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot9"
        "slot3 slot4 slot9"
        "slot6 slot7 slot14"
        "slot6 slot7 slot14"
        "slot8 slot8 slot10"
        "slot8 slot8 slot10"
        "slot11 slot12 slot13"
        "slot11 slot12 slot13";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot9"
        "slot2 slot9"
        "slot3 slot14"
        "slot3 slot14"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot10 slot11"
        "slot10 slot11"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),tb={cardCount:14,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(28)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:1,C2:1},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:3,C3:4,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:2,C3:5,C2:7},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:6,C3:7,C2:8},telemetryRowCol:{C5:[1,3],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:14,C3:8,C2:9},telemetryRowCol:{C5:[3,3],C4:[7,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:8,C3:10,C2:10},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:9,C3:11,C2:11},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,3],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,2],C4:[7,1],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:10,C3:13,C2:13},telemetryRowCol:{C5:[5,3],C4:[5,3],C3:[9,2],C2:[13,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:13,C3:14,C2:14},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,3],C2:[13,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:14,C4:11,C3:9,C2:6},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[27,1]}}],styles:tS},tk=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: auto !important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot1"
        "slot1 slot1 slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
`.withBehaviors(),tT={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._5x_2y,C4:C.u._4x_2y,C3:C.u._3x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:tk},t$=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot3"
        "slot1 slot1 slot2 slot4 slot3"
        "slot5 slot8 slot6 slot7 slot9"
        "slot5 slot8 slot6 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot5 slot4 slot6 slot6"
        "slot5 slot4 slot6 slot6"
        "slot7 slot7 slot8 slot9"
        "slot7 slot7 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot4 slot2 slot9"
        "slot4 slot2 slot9"
        "slot6 slot6 slot8"
        "slot6 slot6 slot8"
        "slot5 slot7 slot7"
        "slot5 slot7 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot5"
        "slot4 slot5"
        "slot6 slot6"
        "slot6 slot6"
        "slot8 slot9"
        "slot8 slot9"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tX={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,1],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[11,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[9,2],C1:[17,1]}}],styles:t$},tF=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot4 slot3"
        "slot1 slot2 slot2 slot4 slot3"
        "slot5 slot8 slot6 slot7 slot9"
        "slot5 slot8 slot6 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3"
        "slot5 slot5 slot6 slot6"
        "slot5 slot5 slot6 slot6"
        "slot4 slot7 slot8 slot9"
        "slot4 slot7 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8"
        "slot6 slot9"
        "slot6 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tE={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:3,C2:3,C1:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:6,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,4],C4:[5,1],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:5,C2:5,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:5,C3:6,C2:8,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:7,C2:6,C1:7},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:8,C3:8,C2:7,C1:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[17,1]}}],styles:tF},tL=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot4"
        "slot1 slot1 slot3 slot4"
        "slot5 slot2 slot6 slot6"
        "slot5 slot2 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tQ={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:5,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:2,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tL},tZ=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot3 slot2 slot4"
        "slot1 slot1 slot3 slot2 slot4"
        "slot5 slot6 slot8 slot7 slot9"
        "slot5 slot6 slot8 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tj={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tZ},tG=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tM={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:9,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tG},tq=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot7 slot6 slot8 slot9"
        "slot5 slot7 slot6 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot6"
        "slot3 slot5 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tz={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tq},tI=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot7 slot6 slot6"
        "slot5 slot7 slot6 slot6"
        "slot8 slot8 slot3 slot9"
        "slot8 slot8 slot3 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tJ={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[5,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:9,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tI},tK=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot3 slot9"
        "slot5 slot8 slot3 slot9"
        "slot6 slot6 slot7 slot7"
        "slot6 slot6 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tN={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:6,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[6,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tK},tU=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot7 slot7"
        "slot5 slot8 slot7 slot7"
        "slot6 slot6 slot3 slot9"
        "slot6 slot6 slot3 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),tV={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:8,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[5,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:7,C3:8,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:6,C3:9,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[6,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:5,C3:7,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:tU},tY=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot5 slot7 slot8 slot8"
        "slot5 slot7 slot8 slot8"
        "slot9 slot9 slot6 slot4"
        "slot9 slot9 slot6 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot5 slot7 slot3"
        "slot5 slot7 slot3"
        "slot6 slot8 slot8"
        "slot6 slot8 slot8"
        "slot9 slot9 slot4"
        "slot9 slot9 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot2"
        "slot5 slot2"
        "slot7 slot3"
        "slot7 slot3"
        "slot8 slot6"
        "slot8 slot6"
        "slot9 slot4"
        "slot9 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),t1={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:5,C2:5},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,3],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[1,5],C4:[5,4],C3:[7,3],C2:[9,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[7,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[5,1],C3:[7,1],C2:[9,1],C1:[17,1]}}],styles:tY},t2=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot2"
        "slot1 slot1 slot2 slot2"
        "slot5 slot3 slot4 slot4"
        "slot5 slot3 slot4 slot4"
        "slot6 slot8 slot7 slot9"
        "slot6 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot5"
        "slot1 slot1 slot5"
        "slot3 slot2 slot2"
        "slot3 slot2 slot2"
        "slot4 slot4 slot7"
        "slot4 slot4 slot7"
        "slot6 slot8 slot9"
        "slot6 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot2"
        "slot5 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),t3={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C5:[1,5],C4:[3,3],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[1,3],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[7,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[7,3],C2:[9,2],C1:[17,1]}}],styles:t2},t4=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),t5={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:t4},t7=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot9"
        "slot5 slot6 slot7 slot7 slot9";
}

:host([layout="C5"]) fluent-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) msft-article-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) cs-article-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) [class="card-container"][style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),t6={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9},telemetryRowCol:{C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:t7},t0=(0,s.A)`
:host {
    grid-template-areas:
        "slot2 slot3 slot5 slot8 slot4"
        "slot2 slot3 slot5 slot8 slot4"
        "slot1 slot1 slot7 slot6 slot9"
        "slot1 slot1 slot7 slot6 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot8 slot8 slot4"
        "slot2 slot8 slot8 slot4"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot3 slot6"
        "slot7 slot5 slot5 slot9"
        "slot7 slot5 slot5 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot3 slot4"
        "slot2 slot3 slot4"
        "slot1 slot1 slot9"
        "slot1 slot1 slot9"
        "slot7 slot5 slot5"
        "slot7 slot5 slot5"
        "slot8 slot8 slot6"
        "slot8 slot8 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot2"
        "slot2"
        "slot1"
        "slot1"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),t8={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:4,C3:4,C2:3,C1:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:5,C3:2,C2:4,C1:3},telemetryRowCol:{C5:[1,2],C4:[3,3],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:3,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:8,C3:7,C2:6,C1:5},telemetryRowCol:{C5:[1,3],C4:[5,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:6,C3:9,C2:8,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[7,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:2,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:t0},t9=(0,s.A)`
:host {
    grid-template-areas:
        "slot2 slot8 slot5 slot3 slot4"
        "slot2 slot8 slot5 slot3 slot4"
        "slot1 slot1 slot7 slot6 slot9"
        "slot1 slot1 slot7 slot6 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot8 slot8 slot4"
        "slot2 slot8 slot8 slot4"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot3 slot6"
        "slot7 slot5 slot5 slot9"
        "slot7 slot5 slot5 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot3 slot4"
        "slot2 slot3 slot4"
        "slot1 slot1 slot9"
        "slot1 slot1 slot9"
        "slot7 slot5 slot5"
        "slot7 slot5 slot5"
        "slot8 slot8 slot6"
        "slot8 slot8 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot2"
        "slot2"
        "slot1"
        "slot1"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),ot={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:4,C3:4,C2:3,C1:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:5,C3:2,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:3,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:8,C3:7,C2:6,C1:5},telemetryRowCol:{C5:[1,3],C4:[5,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:6,C3:9,C2:8,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[7,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:t9},oo=(0,s.A)`
:host {
    grid-template-areas:
        "slot2 slot1 slot1 slot3 slot4"
        "slot2 slot1 slot1 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot2 slot1 slot1 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot1"
        "slot2 slot1 slot1"
        "slot5 slot3 slot4"
        "slot5 slot3 slot4"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot9"
        "slot8 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),ol={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:5,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[7,3],C2:[5,2],C1:[17,1]}}],styles:oo},oC=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),os={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:oC},o_=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot2 slot1 slot9"
        "slot2 slot2 slot1 slot9"
        "slot3 slot4 slot6 slot6"
        "slot3 slot4 slot6 slot6"
        "slot5 slot7 slot7 slot8"
        "slot5 slot7 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot3"
        "slot2 slot1 slot3"
        "slot4 slot5 slot5"
        "slot4 slot5 slot5"
        "slot6 slot6 slot9"
        "slot6 slot6 slot9"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot2 slot2"
        "slot2 slot2"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot5"
        "slot7 slot5"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot9"
        "slot9"
        "slot8"
        "slot8";
}
`.withBehaviors(),oy={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:2,C3:2,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,3],C3:[1,2],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:1,C3:1,C2:3,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,1],C3:[1,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:4,C3:3,C2:2,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[1,3],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:5,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:7,C3:5,C2:7,C1:5},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[3,2],C2:[7,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:5,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:9,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:9,C3:8,C2:8,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,4],C3:[7,1],C2:[9,1],C1:[17,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:3,C3:7,C2:9,C1:8},telemetryRowCol:{C5:[3,5],C4:[1,4],C3:[5,3],C2:[9,2],C1:[15,1]}}],styles:o_},oe=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot3 slot3 slot2 slot4"
        "slot1 slot3 slot3 slot2 slot4"
        "slot1 slot6 slot5 slot5 slot7"
        "slot1 slot6 slot5 slot5 slot7";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot1 slot5 slot6 slot7"
        "slot1 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot1 slot3 slot7"
        "slot1 slot3 slot7"
        "slot6 slot5 slot5"
        "slot6 slot5 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot1 slot3"
        "slot1 slot3"
        "slot5 slot4"
        "slot5 slot4"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),or={cardCount:7,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(16)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_4y,C4:C.u._1x_4y,C3:C.u._1x_4y,C2:C.u._1x_4y,C1:C.u._1x_4y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:7,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot5",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:5,C2:5},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:4,C2:4},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[7,2],C1:[15,1]}}],styles:oe},oa=(0,s.A)`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot4 slot3 slot5"
        "slot4 slot3 slot5"
        "slot7 slot7 slot6"
        "slot7 slot7 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot6 slot5"
        "slot6 slot5"
        "slot4 slot7"
        "slot4 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),ou={cardCount:7,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(14)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:4,C2:3},telemetryRowCol:{C4:[1,4],C3:[3,2],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:6},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,2],C3:[3,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:4},telemetryRowCol:{C4:[3,3],C3:[5,3],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,1],C2:[7,2],C1:[13,1]}}],styles:oa},ox=(0,s.A)`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot6 slot5"
        "slot2 slot6 slot5"
        "slot7 slot7 slot4"
        "slot7 slot7 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot6 slot5"
        "slot6 slot5"
        "slot4 slot7"
        "slot4 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),od={cardCount:7,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(14)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C4:[3,1],C3:[5,3],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,2],C3:[3,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:4,C2:4},telemetryRowCol:{C4:[3,3],C3:[3,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,1],C2:[7,2],C1:[13,1]}}],styles:ox},oi=(0,s.A)`
:host {
    grid-template-areas:
    "slot1 slot1 slot2 slot3 slot4"
    "slot1 slot1 slot5 slot3 slot4"
    "slot7 slot14 slot10 slot6 slot9"
    "slot8 slot15 slot11 slot6 slot9"
    "slot16 slot16 slot17 slot12 slot13"
    "slot16 slot16 slot17 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1 slot1 slot2 slot4"
    "slot1 slot1 slot5 slot4"
    "slot3 slot7 slot6 slot9"
    "slot3 slot8 slot6 slot9"
    "slot16 slot16 slot10 slot13"
    "slot16 slot16 slot11 slot13"
    "slot14 slot12 slot17 slot17"
    "slot15 slot12 slot17 slot17";
    
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot5 slot3 slot9"
        "slot6 slot7 slot13"
        "slot6 slot8 slot13"
        "slot16 slot16 slot10"
        "slot16 slot16 slot11"
        "slot14 slot12 slot17"
        "slot15 slot12 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot5 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot16 slot16"
        "slot16 slot16"
        "slot6 slot13"
        "slot6 slot13"
        "slot7 slot10"
        "slot8 slot11"
        "slot17 slot17"
        "slot17 slot17"
        "slot14 slot12"
        "slot15 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot5"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot7"
        "slot8"
        "slot6"
        "slot6"
        "slot10"
        "slot11"
        "slot14"
        "slot15"
        "slot9"
        "slot9"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),om={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:2,C2:4,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[4,1],C2:[4,1],C1:[4,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:8,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:6,C4:6,C3:8,C2:10,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:7,C4:7,C3:9,C2:11,C1:7},telemetryRowCol:{C5:[4,1],C4:[4,2],C3:[6,2],C2:[12,1],C1:[10,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:9,C3:6,C2:6,C1:13},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:10,C4:11,C3:12,C2:12,C1:9},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:11,C4:12,C3:13,C2:13,C1:10},telemetryRowCol:{C5:[4,3],C4:[6,3],C3:[8,3],C2:[12,2],C1:[14,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:16,C4:16,C3:16,C2:17,C1:16},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:17,C4:13,C3:10,C2:9,C1:17},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:8,C4:14,C3:14,C2:15,C1:11},telemetryRowCol:{C5:[3,2],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:9,C4:15,C3:15,C2:16,C1:12},telemetryRowCol:{C5:[4,2],C4:[8,1],C3:[10,1],C2:[16,1],C1:[16,1]}},{grid_area:"slot16",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:14,C4:10,C3:11,C2:7,C1:14},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:15,C4:17,C3:17,C2:14,C1:15},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}}],styles:oi},og=(0,s.A)`
:host {
    grid-template-areas:
    "slot1 slot1 slot2 slot3 slot4"
    "slot1 slot1 slot5 slot3 slot4"
    "slot7 slot6 slot10 slot14 slot9"
    "slot8 slot6 slot11 slot15 slot9"
    "slot16 slot16 slot17 slot12 slot13"
    "slot16 slot16 slot17 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1 slot1 slot2 slot4"
    "slot1 slot1 slot5 slot4"
    "slot3 slot7 slot6 slot9"
    "slot3 slot8 slot6 slot9"
    "slot16 slot16 slot10 slot13"
    "slot16 slot16 slot11 slot13"
    "slot14 slot12 slot17 slot17"
    "slot15 slot12 slot17 slot17";
    
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot5 slot3 slot9"
        "slot6 slot7 slot13"
        "slot6 slot8 slot13"
        "slot16 slot16 slot10"
        "slot16 slot16 slot11"
        "slot14 slot12 slot17"
        "slot15 slot12 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot5 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot16 slot16"
        "slot16 slot16"
        "slot6 slot13"
        "slot6 slot13"
        "slot7 slot10"
        "slot8 slot11"
        "slot17 slot17"
        "slot17 slot17"
        "slot14 slot12"
        "slot15 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot5"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot7"
        "slot8"
        "slot6"
        "slot6"
        "slot10"
        "slot11"
        "slot14"
        "slot15"
        "slot9"
        "slot9"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),oc={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:2,C2:4,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[4,1],C2:[4,1],C1:[4,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:6,C4:6,C3:8,C2:10,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:7,C4:7,C3:9,C2:11,C1:7},telemetryRowCol:{C5:[4,1],C4:[4,2],C3:[6,2],C2:[12,1],C1:[10,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:9,C3:6,C2:6,C1:13},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:9,C4:11,C3:12,C2:12,C1:9},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:10,C4:12,C3:13,C2:13,C1:10},telemetryRowCol:{C5:[4,3],C4:[6,3],C3:[8,3],C2:[12,2],C1:[14,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:16,C4:16,C3:16,C2:17,C1:16},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:17,C4:13,C3:10,C2:9,C1:17},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:11,C4:14,C3:14,C2:15,C1:11},telemetryRowCol:{C5:[3,4],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},cardDomOrder:{C5:12,C4:15,C3:15,C2:16,C1:12},telemetryRowCol:{C5:[4,4],C4:[8,1],C3:[10,1],C2:[16,1],C1:[16,1]}},{grid_area:"slot16",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:14,C4:10,C3:11,C2:7,C1:14},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:15,C4:17,C3:17,C2:14,C1:15},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}}],styles:og},ow=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot2 slot8 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot11 slot7 slot13 slot9 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot16 slot12 slot17 slot14 slot15";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot3 slot2 slot5"
        "slot6 slot3 slot2 slot5"
        "slot6 slot9 slot4 slot10"
        "slot12 slot9 slot7 slot10"
        "slot12 slot8 slot7 slot13"
        "slot11 slot8 slot15 slot16"
        "slot11 slot14 slot15 slot17";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot5"
        "slot2 slot3 slot5"
        "slot6 slot3 slot10"
        "slot6 slot9 slot10"
        "slot12 slot9 slot4"
        "slot12 slot7 slot4"
        "slot8 slot7 slot11"
        "slot8 slot13 slot11"
        "slot15 slot13 slot14"
        "slot15 slot16 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot1 slot1"
        "slot1 slot1"
        "slot10 slot9"
        "slot10 slot9"
        "slot6 slot3"
        "slot6 slot3"
        "slot4 slot4"
        "slot4 slot4"
        "slot12 slot11"
        "slot12 slot11"
        "slot15 slot7"
        "slot15 slot7"
        "slot8 slot8"
        "slot8 slot8"
        "slot13 slot14"
        "slot13 slot14"
        "slot16 slot17"
        "slot16 slot17";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17";
}
`.withBehaviors(),oh={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(7),C3:(0,C.P)(10),C2:(0,C.P)(20),C1:(0,C.P)(34)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:7},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[2,2],C2:[7,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:9,C2:8},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[5,3],C2:[9,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5},telemetryRowCol:{C5:[2,1],C4:[2,1],C3:[3,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:10,C3:10,C2:12},telemetryRowCol:{C5:[3,2],C4:[4,3],C3:[6,2],C2:[13,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:11,C3:11,C2:13},telemetryRowCol:{C5:[2,3],C4:[5,2],C3:[7,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:5},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[4,2],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:13,C3:12,C2:10},telemetryRowCol:{C5:[4,1],C4:[6,1],C3:[7,3],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:9,C3:8,C2:9},telemetryRowCol:{C5:[5,2],C4:[4,1],C3:[5,1],C2:[11,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:13,C2:14},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[8,2],C2:[17,1],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:16,C3:15,C2:15},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,3],C2:[17,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:14,C3:14,C2:15},telemetryRowCol:{C5:[5,5],C4:[6,3],C3:[9,1],C2:[13,1],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:15,C2:11},telemetryRowCol:{C5:[6,1],C4:[6,4],C3:[10,2],C2:[19,1],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[6,3],C4:[7,4],C3:[10,3],C2:[19,2],C1:[33,1]}}],styles:ow},oR=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot7 slot3 slot9 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot12 slot8 slot14 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot11 slot16 slot13 slot17 slot15";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot4 slot5"
        "slot3 slot1 slot6 slot5"
        "slot3 slot7 slot6 slot10"
        "slot8 slot7 slot11 slot10"
        "slot8 slot9 slot11 slot15"
        "slot13 slot9 slot12 slot15"
        "slot13 slot16 slot16 slot17"
        "slot14 slot16 slot16 slot17";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot4 slot3"
        "slot2 slot7 slot3"
        "slot1 slot7 slot5"
        "slot1 slot9 slot5"
        "slot6 slot9 slot10"
        "slot6 slot8 slot10"
        "slot12 slot8 slot15"
        "slot12 slot13 slot15"
        "slot14 slot13 slot11"
        "slot16 slot17 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot4 slot4"
        "slot4 slot4"
        "slot1 slot10"
        "slot1 slot10"
        "slot3 slot15"
        "slot3 slot15"
        "slot7 slot7"
        "slot7 slot7"
        "slot9 slot8"
        "slot9 slot8"
        "slot6 slot12"
        "slot6 slot12"
        "slot14 slot14"
        "slot14 slot14"
        "slot11 slot16"
        "slot11 slot16"
        "slot17 slot13"
        "slot17 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17";
}
`.withBehaviors(),oP={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(20),C1:(0,C.P)(34)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:5,C2:4},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[3,1],C2:[5,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,1],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C2:6},telemetryRowCol:{C5:[1,3],C4:[2,1],C3:[1,3],C2:[7,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,2],C2:[3,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:6,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C3:8,C2:11},telemetryRowCol:{C5:[3,1],C4:[2,3],C3:[5,1],C2:[13,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C3:4,C2:8},telemetryRowCol:{C5:[2,2],C4:[3,2],C3:[2,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,3],C4:[4,1],C3:[6,2],C2:[11,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:11,C3:7,C2:9},telemetryRowCol:{C5:[2,4],C4:[5,2],C3:[4,2],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:9,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[5,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:10,C3:15,C2:14},telemetryRowCol:{C5:[5,1],C4:[4,3],C3:[9,3],C2:[17,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:14,C3:11},telemetryRowCol:{C5:[4,2],C4:[6,3],C3:[7,1],C2:[13,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:14,C2:17},telemetryRowCol:{C5:[5,3],C4:[6,1],C3:[8,2],C2:[19,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:15,C2:13},telemetryRowCol:{C5:[4,4],C4:[8,1],C3:[9,1],C2:[15,1],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:12,C2:7},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[7,3],C2:[7,2],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.u._1x_1y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C2:15},telemetryRowCol:{C5:[6,2],C4:[7,2],C3:[10,1],C2:[17,2],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C2:16},telemetryRowCol:{C5:[6,4],C4:[7,4],C3:[10,2],C2:[19,1],C1:[33,1]}}],styles:oR},oD=(0,s.A)`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot4 slot4 slot5 slot6"
        "slot4 slot4 slot5 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot2"
        "slot1 slot3 slot2"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot4 slot2"
        "slot4 slot2"
        "slot5 slot6"
        "slot5 slot6";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
}
`.withBehaviors(),oO={cardCount:6,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(12)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:4},telemetryRowCol:{C4:[1,2],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C4:[1,3],C3:[1,2],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:3},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,3],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:6},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[5,2],C1:[11,1]}}],styles:oD},op=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot2 slot5"
        "slot3 slot9 slot4 slot10"
        "slot3 slot9 slot4 slot10"
        "slot6 slot8 slot7 slot7"
        "slot6 slot8 slot7 slot7";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot5"
        "slot1 slot3 slot5"
        "slot2 slot4 slot10"
        "slot2 slot4 slot10"
        "slot6 slot9 slot7"
        "slot6 slot9 slot8";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),on={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:2,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:9,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[6,3],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:8,C2:10},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:op},of=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot10"
        "slot5 slot6 slot7 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot2 slot1 slot1 slot4"
        "slot5 slot3 slot7 slot10"
        "slot5 slot3 slot7 slot10"
        "slot9 slot8 slot8 slot6"
        "slot9 slot8 slot8 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot6 slot5 slot9"
        "slot6 slot5 slot9"
        "slot7 slot8 slot8"
        "slot7 slot8 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot10"
        "slot3 slot10"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot9"
        "slot6 slot9"
        "slot8 slot8"
        "slot8 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),ov={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,styles:of,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,4],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:9,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:9},telemetryRowCol:{C5:[4,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[19,1]}}]},oA=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot10"
        "slot5 slot6 slot7 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot7 slot10"
        "slot5 slot3 slot7 slot10"
        "slot8 slot8 slot6 slot9"
        "slot8 slot8 slot6 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot6 slot5 slot9"
        "slot6 slot5 slot9"
        "slot7 slot8 slot8"
        "slot7 slot8 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot10"
        "slot3 slot10"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot9"
        "slot6 slot9"
        "slot8 slot8"
        "slot8 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oW={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,styles:oA,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:9,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:8,C2:9},telemetryRowCol:{C5:[4,4],C4:[5,4],C3:[5,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[19,1]}}]},oB=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot10 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot3 slot9"
        "slot5 slot8 slot3 slot9"
        "slot6 slot6 slot7 slot10"
        "slot6 slot6 slot7 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot6"
        "slot7 slot7 slot10"
        "slot7 slot7 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot10 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oH={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:6,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:8,C3:8,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:9,C3:9,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:5,C3:7,C2:10,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:10,C3:10,C2:9,C1:10},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[7,3],C2:[10,1],C1:[19,1]}}],styles:oB},oS=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot7 slot10 slot8 slot8"
        "slot7 slot10 slot8 slot8";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot10 slot5"
        "slot10 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),ob={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:10,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[10,2],C1:[19,1]}}],styles:oS},ok=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot6 slot4 slot7 slot7"
        "slot6 slot4 slot7 slot7"
        "slot9 slot9 slot8 slot10"
        "slot9 slot9 slot8 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot10"
        "slot3 slot4 slot10"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7"
        "slot9 slot9 slot6"
        "slot9 slot9 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot2"
        "slot3 slot2"
        "slot4 slot10"
        "slot4 slot10"
        "slot6 slot8"
        "slot6 slot8"
        "slot7 slot9"
        "slot7 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oT={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:4,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:6,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:10,C2:7,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:9,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:8,C3:9,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:10,C3:6,C2:6,C1:10},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[19,1]}}],styles:ok},o$=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot6 slot8 slot7 slot7"
        "slot6 slot8 slot7 slot7"
        "slot4 slot4 slot9 slot10"
        "slot4 slot4 slot9 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot6 slot3 slot10"
        "slot6 slot3 slot10"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7"
        "slot4 slot4 slot9"
        "slot4 slot4 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot2"
        "slot3 slot2"
        "slot4 slot10"
        "slot4 slot10"
        "slot6 slot8"
        "slot6 slot8"
        "slot7 slot9"
        "slot7 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oX={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:4,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:5,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:8,C3:9,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[5,1],C3:[7,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:5,C3:4,C2:7,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:6,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:10,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:10,C3:6,C2:6,C1:10},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[19,1]}}],styles:o$},oF=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot4 slot4 slot7 slot10"
        "slot4 slot4 slot7 slot10"
        "slot6 slot8 slot9 slot9"
        "slot6 slot8 slot9 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot3 slot10"
        "slot3 slot3 slot10"
        "slot4 slot6 slot6"
        "slot4 slot6 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oE={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:6,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,2],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:oF},oL=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot10 slot7 slot9"
        "slot8 slot10 slot7 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot10 slot5"
        "slot8 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oQ={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:9,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:10,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:8,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,2],C2:[10,2],C1:[19,1]}}],styles:oL},oZ=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot8 slot8 slot7 slot10"
        "slot8 slot8 slot7 slot10";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot10 slot5"
        "slot10 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),oj={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:9,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:10,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,4],C3:[7,1],C2:[10,2],C1:[19,1]}}],styles:oZ},oG=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot12 slot10 slot13"
        "slot8 slot12 slot11 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot13"
        "slot6 slot5 slot13"
        "slot7 slot12 slot10"
        "slot8 slot12 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot13"
        "slot5 slot13"
        "slot6 slot7"
        "slot6 slot8"
        "slot10 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot9"
        "slot9"
        "slot2"
        "slot2"
        "slot6"
        "slot6"
        "slot3"
        "slot3"
        "slot5"
        "slot5"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot13"
        "slot13"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),oM={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[7,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4,C1:6},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3,C1:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6,C1:7},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:8,C1:5},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[9,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:9,C2:9,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[6,1],C3:[8,1],C2:[10,2],C1:[17,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5,C1:3},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[5,1]}},{grid_area:"slot10",layouts:{C5:C.u._2x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C4:11,C3:12,C2:11,C1:11},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,3],C2:[11,1],C1:[21,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:13,C2:12,C1:12},telemetryRowCol:{C5:[5,3],C4:[6,3],C3:[8,3],C2:[12,1],C1:[23,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:11,C2:13,C1:13},telemetryRowCol:{C5:[5,4],C4:[5,2],C3:[7,2],C2:[11,2],C1:[25,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:13,C3:8,C2:7,C1:10},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[7,2],C1:[19,1]}}],styles:oG},oq=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8"
        "slot9 slot10 slot11 slot12 slot13"
        "slot9 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot7 slot7"
        "slot5 slot3 slot7 slot7"
        "slot10 slot10 slot6 slot8"
        "slot10 slot10 slot6 slot8"
        "slot9 slot11 slot12 slot13"
        "slot9 slot11 slot12 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot7 slot7"
        "slot6 slot7 slot7"
        "slot5 slot10 slot13"
        "slot5 slot10 slot13"
        "slot9 slot11 slot12"
        "slot9 slot11 slot12";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot13"
        "slot7 slot13"
        "slot9 slot12"
        "slot9 slot12"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),oz={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:4,C3:8,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:8,C3:6,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:6,C3:7,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:9,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:10,C3:11,C2:10,C1:9},telemetryRowCol:{C5:[5,1],C4:[7,1],C3:[9,1],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:7,C3:9,C2:12,C1:10},telemetryRowCol:{C5:[5,2],C4:[5,1],C3:[7,2],C2:[13,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:11,C3:12,C2:13,C1:11},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:12,C3:13,C2:11,C1:12},telemetryRowCol:{C5:[5,4],C4:[7,3],C3:[9,3],C2:[11,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:13,C4:13,C3:10,C2:9,C1:13},telemetryRowCol:{C5:[5,5],C4:[7,4],C3:[7,3],C2:[9,2],C1:[25,1]}}],styles:oq},oI=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot10 slot10 slot7 slot13"
        "slot10 slot10 slot7 slot13"
        "slot8 slot12 slot11 slot11"
        "slot8 slot12 slot11 slot11";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot13"
        "slot6 slot5 slot13"
        "slot10 slot10 slot7"
        "slot10 slot10 slot7"
        "slot8 slot12 slot11"
        "slot8 slot12 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot10 slot10"
        "slot10 slot10"
        "slot6 slot13"
        "slot6 slot13"
        "slot5 slot7"
        "slot5 slot7"
        "slot11 slot11"
        "slot11 slot11"
        "slot8 slot12"
        "slot8 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),oJ={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:11,C3:11,C2:12},telemetryRowCol:{C5:[3,4],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:9,C2:6},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:13,C3:13,C2:11},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:12,C2:13},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:8,C2:8},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}}],styles:oI},oK=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot2"
        "slot2 slot2"
        "slot3 slot3"
        "slot3 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),oN={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(6),C1:(0,C.P)(6)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:3,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,1],C1:[5,1]}}],styles:oK},oU=(0,s.A)`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot3 slot3"
        "slot3 slot3"
        "slot1 slot2"
        "slot1 slot2";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),oV={cardCount:3,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(6)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:2},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:3,C2:1},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,1],C1:[5,1]}}],styles:oU};var oY=l(22131),o1=l(86856),o2=l(87944);let o3=(0,s.A)`
    :host {
        --background-gradient-angle: 170deg;
    }
`,o4=(0,s.A)`
    :host {
        --background-gradient-angle: -170deg;
    }
`,o5=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot2 slot3 slot4 slot5 slot6"
        "slot2 slot3 slot4 slot5 slot6";
    padding: 20px;
    border-radius: 4px;
    grid-auto-rows: 52px 146px 146px !important;
    --gradient-background: var(--background-gradient-angle), #FEFAD7 1.17%, #FFE0D9 90.12%;
    background: linear-gradient(var(--gradient-background));
}
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot1"
        "slot2 slot4 slot5"
        "slot3 slot4 slot5";
    height: ${(0,o2.c)(368)};
    width: ${(0,o2.c)(924)};
}

:host([layout="C3"]) fluent-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C3"]) msft-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C3"]) cs-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
    height: ${(0,o2.c)(368)};
    width: ${(0,o2.c)(612)};
}

:host([layout="C2"]) fluent-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) fluent-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) msft-article-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) msft-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) cs-article-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) cs-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot2"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
    grid-auto-rows: 52px 146px 146px 146px 146px 146px 146px 146px 146px !important;
}
`.withBehaviors(new o1.t(o3,o4),(0,oY.mr)((0,s.A)`
            :host {
                forced-color-adjust: auto;
            }
        `),(0,oY.G2)((0,s.A)`
            :host([layout]) {
                    --background-gradient-angle-dark-mode: 134.62deg;
                    --gradient-background-dark-mode: var(--background-gradient-angle-dark-mode), #512C2C 1.14%, #252C4E 86.08%;
                    background: linear-gradient(var(--gradient-background-dark-mode));
            }
        `)),o7={cardCount:6,rowHeightPx:{C5:[52,146,146],C4:[52,146,146],C3:[52,146,146],C2:[52,146,146],C1:[52,146,146,146,146,146,146,146,146]},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._5x_1y,C4:C.u._4x_1y,C3:C.u._3x_1y,C2:C.u._2x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[2,1],C4:[2,1],C3:[2,1],C2:[2,1],C1:[2,1]},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[2,2],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]},cardDomOrder:{C5:3,C4:3,C3:3,C2:3,C1:3}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[2,3],C4:[2,2],C3:[2,2],C2:[2,2],C1:[4,1]},cardDomOrder:{C5:4,C4:4,C3:4,C2:4,C1:4}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[2,4],C4:[2,3],C3:[2,3],C1:[6,1]},cardDomOrder:{C5:5,C4:5,C3:5,C1:5}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[2,5],C4:[2,4],C1:[8,1]},cardDomOrder:{C5:6,C4:6,C1:6}}],styles:o5},o6=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8"
        "slot9 slot10 slot11 slot11 slot12"
        "slot9 slot10 slot11 slot11 slot12";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8"
        "slot9 slot10 slot11 slot12"
        "slot9 slot10 slot11 slot12";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10"
        "slot11 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),o0={cardCount:12,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(24)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:3,C4:3,C3:3,C2:3,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:4,C4:4,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:5,C4:5,C3:5,C2:5,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:6,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[3,3],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:7,C4:7,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9,C1:9},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[5,3],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:10,C4:10,C3:10,C2:10,C1:10},telemetryRowCol:{C5:[5,2],C4:[5,2],C3:[7,1],C2:[9,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:11,C4:11,C3:11,C2:11,C1:11},telemetryRowCol:{C5:[5,3],C4:[5,3],C3:[7,2],C2:[11,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C5:12,C4:12,C3:12,C2:12,C1:12},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[7,3],C2:[11,2],C1:[23,1]}}],styles:o6},o8=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot2 slot7 slot4 slot5"
        "slot6 slot9 slot7 slot11 slot12"
        "slot8 slot9 slot10 slot11 slot12";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot3 slot6 slot5"
        "slot4 slot3 slot2 slot5"
        "slot4 slot7 slot2 slot12"
        "slot11 slot7 slot9 slot12"
        "slot11 slot8 slot9 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot5"
        "slot2 slot3 slot5"
        "slot4 slot3 slot12"
        "slot4 slot11 slot12"
        "slot9 slot11 slot8"
        "slot9 slot7 slot8"
        "slot6 slot7 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot1 slot1"
        "slot1 slot1"
        "slot12 slot11"
        "slot12 slot11"
        "slot4 slot3"
        "slot4 slot3"
        "slot6 slot6"
        "slot6 slot6"
        "slot9 slot7"
        "slot9 slot7"
        "slot8 slot10"
        "slot8 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),o9={cardCount:12,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(5),C3:(0,C.P)(7),C2:(0,C.P)(14),C1:(0,C.P)(24)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[2,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_1y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:4,C2:7},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[2,2],C2:[7,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._2x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:11,C2:8},telemetryRowCol:{C5:[2,1],C4:[1,3],C3:[7,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C3:10,C2:10},telemetryRowCol:{C5:[2,3],C4:[3,2],C3:[6,2],C2:[11,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:9,C2:11},telemetryRowCol:{C5:[4,1],C4:[5,2],C3:[5,3],C2:[13,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:11,C3:8,C2:9},telemetryRowCol:{C5:[3,2],C4:[4,3],C3:[5,1],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[7,3],C2:[13,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:7,C2:5},telemetryRowCol:{C5:[3,4],C4:[4,1],C3:[4,2],C2:[5,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,1],C1:[23,1]}}],styles:o8},lt=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot11 slot12 slot13 slot14 slot15"
        "slot16 slot17 slot18 slot19 slot20"
        "slot16 slot17 slot18 slot19 slot20";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8"
        "slot9 slot10 slot11 slot12"
        "slot9 slot10 slot11 slot12"
        "slot13 slot14 slot15 slot16"
        "slot13 slot14 slot15 slot16"
        "slot17 slot18 slot19 slot20"
        "slot17 slot18 slot19 slot20";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12"
        "slot13 slot14 slot15"
        "slot13 slot14 slot15"
        "slot16 slot17 slot18"
        "slot16 slot17 slot18"
        "slot19 slot20 slot20"
        "slot19 slot20 slot20";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10"
        "slot11 slot12"
        "slot11 slot12"
        "slot13 slot14"
        "slot13 slot14"
        "slot15 slot16"
        "slot15 slot16"
        "slot17 slot18"
        "slot17 slot18"
        "slot19 slot20"
        "slot19 slot20";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot18"
        "slot18"
        "slot19"
        "slot19"
        "slot20"
        "slot20";
}
`.withBehaviors(),lo={cardCount:20,rowHeightPx:{C5:(0,C.P)(8),C4:(0,C.P)(10),C3:(0,C.P)(14),C2:(0,C.P)(20),C1:(0,C.P)(40)},colWidthPx:300,gutterPx:12,styles:lt,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,3],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,4],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,2],C3:[7,1],C2:[9,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,2],C2:[11,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[5,2],C4:[5,4],C3:[7,3],C2:[11,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[5,3],C4:[7,1],C3:[9,1],C2:[13,1],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[13,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[5,5],C4:[7,3],C3:[9,3],C2:[15,1],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[7,1],C4:[7,4],C3:[11,1],C2:[15,2],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[7,2],C4:[9,1],C3:[11,2],C2:[17,1],C1:[33,1]}},{grid_area:"slot18",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[7,3],C4:[9,2],C3:[11,3],C2:[17,2],C1:[35,1]}},{grid_area:"slot19",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[7,4],C4:[9,3],C3:[13,1],C2:[19,1],C1:[37,1]}},{grid_area:"slot20",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[7,5],C4:[9,4],C3:[13,2],C2:[19,2],C1:[39,1]}}]},ll=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot10"
        "slot4 slot5 slot6 slot10"
        "slot9 slot8 slot7 slot7"
        "slot9 slot8 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),lC={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,styles:ll,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[7,3],C2:[9,2],C1:[19,1]}}]},ls=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 "
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7"
        "slot8 slot9 slot10 slot10"
        "slot8 slot9 slot10 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),l_={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,4],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,3],C3:[7,3],C2:[9,2],C1:[19,1]}}],styles:ls},ly=(0,s.A)`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot10"
        "slot4 slot5 slot6 slot10"
        "slot8 slot9 slot7 slot7"
        "slot8 slot9 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),le={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,styles:ly,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[7,3],C2:[9,2],C1:[19,1]}}]},lr=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 "
        "slot1 slot1 slot2 slot5"
        "slot3 slot4 slot6 slot10"
        "slot3 slot4 slot6 slot10"
        "slot7 slot8 slot8 slot9"
        "slot7 slot8 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot5"
        "slot1 slot1 slot5"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot4 slot6 slot7"
        "slot4 slot6 slot7"
        "slot8 slot8 slot9"
        "slot8 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),la={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:2,C3:3,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:4,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:5,C3:6,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:6,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,1],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:10,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,4],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},cardDomOrder:{C4:7,C3:5,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:lr},lu=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),lx={cardCount:4,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}}],styles:lu},ld=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot6"
        "slot4 slot5 slot6 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot5"
        "slot4 slot5"
        "slot6 slot6"
        "slot6 slot6";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
}
`.withBehaviors(),li={cardCount:6,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(8),C1:(0,C.P)(12)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[7,1],C1:[11,1]}}],styles:ld},lm=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),lg={cardCount:1,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:lm},lc=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2"
            "slot3 slot4"
            "slot3 slot4"
            "slot5 slot6"
            "slot5 slot6"
            "slot7 slot8"
            "slot7 slot8";
    }
}
`.withBehaviors(),lw={cardCount:8,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[5,2],C3:[5,2],C2:[5,2]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot8",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:lc},lh=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
    grid-auto-rows: auto !important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}
`.withBehaviors(),lR={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._2x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:lh},lP=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3"
            "slot4 slot5"
            "slot4 slot5"
            "slot6 slot7"
            "slot6 slot7";
    }
}
`.withBehaviors(),lD={cardCount:7,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[5,2],C3:[5,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot7",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:lP},lO=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3"
            "slot4 slot4"
            "slot4 slot4"
            "slot5 slot6"
            "slot5 slot6";
    }
}
`.withBehaviors(),lp={cardCount:6,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot4",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot6",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:lO},ln=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3";
    }
}
`.withBehaviors(),lf={cardCount:3,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(4)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}}],styles:ln},lv=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),lA={cardCount:2,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(4)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:lv},lW=(0,s.A)`

    :host {
        grid-template-areas:
            "slot1"
            "slot1"
            "slot2"
            "slot2"
            "slot3"
            "slot3"
            "slot4"
            "slot4";
    }

}
`.withBehaviors(),lB={cardCount:4,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1]}},{grid_area:"slot2",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1]}},{grid_area:"slot3",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1]}},{grid_area:"slot4",layouts:{C4:C.u._1x_2y,C3:C.u._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1]}}],styles:lW},lH=(0,s.A)`
:host {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1"
    "slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
`.withBehaviors(),lS={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:lH};var lb=l(42506),lk=l(43063),lT=l(21907),l$=l(44789);let lX={"above-the-fold-eleven-card":y,"msft-top-section":o7,"river-section-one-row":lx,"river-section-two-row":li,"hero-section-one-row-11111":m.D,"hero-section-one-row-122":c.L,"hero-section-one-row-1211":g.r,"hero-section-one-row-2111":w.x,"hero-section-one-row-2111-b":h.$,"hero-section-one-row-21155":R.k,"hero-section-one-row-221":P.b,"hero-section-one-row-25511":D.w,"hero-section-one-row-3-cards":O.m,"hero-section-one-row-3-mini-widgets":p.v,"hero-section-one-row-5-mini-widgets-drp":f.v,"hero-section-one-row-5-mini-widgets":v.X,"hero-section-one-row-4-cards":n.R,"hero-section-first-river-4-cards":d.O,"hero-section-first-river-5-cards":i.Z,"widgets-cards-1":lb.X,"widgets-cards-2":lk.Q,"widgets-cards-3":lT.X,"widgets-cards-4":l$.c,"msft-twelve-card-five-col-waterfall":o9,"msft-twelve-card-five-col":o0,"enterprise-thirteen-card-five-col":tO,"msft-two-row-five-col":l_,"msft-two-row-five-col-two":la,"msft-two-row-five-col-three":le,"msft-two-row-five-col-deep":lC,"msft-three-card-four-col":oV,"msft-three-card-five-col":oN,"msft-six-card-four-col-deep":oO,"msft-seven-card-four-col-atf":ou,"msft-seven-card-four-col-btf":od,"msft-seven-card-five-col-w14":or,"msft-eight-card-four-col-deep":td,"msft-four-card-five-col":tv,"msft-four-card-five-col-three":tW,"msft-five-card-five-col":tn,"msft-eight-card-five-col":ty,"msft-eight-card-five-col-3":W,"msft-eight-card-five-col-5":H,"msft-eight-card-five-col-two":tu,"msft-eight-card-five-col-three":tr,"msft-eight-card-five-col-four":tt,"msft-eight-card-five-col-five":V,"msft-eight-card-five-col-six":ts,"msft-eight-card-five-col-seven":tl,"msft-eight-card-five-col-eight":N,"msft-eight-card-five-col-deep":J,"msft-eight-card-five-col-btf":T,"msft-eight-card-five-col-btf-two":E,"msft-eight-card-five-col-btf-three":X,"msft-eight-card-five-col-btf-four":b,"msft-eight-card-five-col-cold-a":Q,"msft-eight-card-five-col-cold-b":j,"msft-eight-card-five-col-cold-c":M,"msft-eight-card-five-col-cold-d":z,"msft-eighteen-card-five-col":tm,"msft-eleven-card-five-col":tc,"msft-eleven-card-five-col-two":tP,"msft-eleven-card-five-col-three":th,"msft-seventeen-card-five-col-half-u-a1":om,"msft-seventeen-card-five-col-half-u":oc,"msft-seventeen-card-five-col-waterfall-v1":oh,"msft-seventeen-card-five-col-waterfall-v2":oP,"wpo-rrail-T1-1":lS,"wpo-rrail-T4":lB,"wpo-sc-T1-full-width_1":lR,"wpo-sc-T6":lp,"wpo-sc-T7":lD,"wpo-sc-T8":lw,"wpo-sc-T3":lf,"wpo-sc-T2":lA,"msft-infopanecard-fordenseriver":lg,"msft-nine-card-five-col":os,"msft-nine-card-five-col-1":tX,"msft-nine-card-five-col-5":tE,"msft-nine-card-five-col-atf":tM,"msft-nine-card-five-col-atf-two":tJ,"msft-nine-card-five-col-atf-three":tz,"msft-nine-card-five-col-atf-four":tj,"msft-nine-card-five-col-atf-five":tQ,"msft-nine-card-five-col-btf":tN,"msft-nine-card-five-col-btf-two":tV,"msft-nine-card-five-col-double-cg-two":t6,"msft-nine-card-five-col-double-cg":t5,"msft-nine-card-five-col-cold-d":t1,"msft-nine-card-five-col-cold-e":t3,"msft-nine-card-five-col-move-info":ol,"msft-nine-card-five-col-low-info":t8,"msft-nine-card-five-col-low-info-two":ot,"msft-nine-card-five-col-twoc-ad":oy,"msft-ten-card-five-col":oE,"msft-ten-card-five-col-two":oj,"msft-ten-card-five-col-three":oQ,"msft-ten-card-five-col-four":ob,"msft-ten-card-five-col-five":oH,"msft-ten-card-five-col-six":oX,"msft-ten-card-five-col-da":oW,"msft-ten-card-five-col-da-move-info":ov,"msft-ten-card-five-col-btf":on,"msft-ten-card-five-col-oneu-info":oT,"msft-twenty-card-five-col-all-one":lo,"msft-thirteen-card-five-col":oM,"msft-thirteen-card-five-col-two":oJ,"msft-thirteen-card-five-col-three":oz,"msft-fourteen-card-five-col":tH,"msft-fourteen-card-five-col-three":tb,"msft-full-wide-one-card-five-col":tT,"msft-placeholder-c1":x(1),"msft-placeholder-c2":x(2),"msft-placeholder-c3":x(3),"msft-placeholder-c4":x(4),"msft-placeholder-c5":x(5)}},27783(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot4 slot3"
        "slot1 slot2 slot4 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot4 slot2"
        "slot1 slot4 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot3"
        "slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_1y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,3],C3:[1,2],C2:[1,2],C1:[3,1]}}],styles:_};l.d(o,{},{O:y})},81336(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot3"
        "slot3 slot3"
        "slot2 slot4"
        "slot2 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(10)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[2,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}}],styles:_};l.d(o,{},{Z:y})},22754(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:_};l.d(o,{},{D:y})},41740(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:_};l.d(o,{},{r:y})},89270(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot2"
        "slot1 slot2 slot2";
}
:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3";
}
:host([layout="C2"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),y={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C2:[1,2]}}],styles:_};l.d(o,{},{L:y})},8634(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}
 
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:_};l.d(o,{},{$:y})},77858(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot3 slot1 slot1 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot3";
}

:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[2,3],C2:[4,1]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C2:[3,2]}}],styles:_};l.d(o,{},{x:y})},77679(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot4 slot1 slot1 slot2"
        "slot5 slot1 slot1 slot2";
}
:host([layout="C4"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot5";
}
:host([layout="C3"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot4 slot2"
        "slot5 slot2";
}

:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._2x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C2:[3,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y},telemetryRowCol:{C5:[1,4]}},{grid_area:"slot4",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y},telemetryRowCol:{C5:[1,5],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot5",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y},telemetryRowCol:{C5:[2,5],C4:[2,1],C3:[2,3],C2:[4,1]}}],styles:_};l.d(o,{},{k:y})},14642(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),y={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3]}}],styles:_};l.d(o,{},{b:y})},65839(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot5"
        "slot1 slot1 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot5 slot4"
        "slot1 slot3 slot5 slot4";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot5 slot2 slot4"
        "slot1 slot5 slot3 slot4";
}
`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._2x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,2],C1:[1,3]}},{grid_area:"slot3",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[2,3],C2:[2,2],C1:[2,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,5],C3:[1,5],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,3],C1:[1,2]}}],styles:_};l.d(o,{},{w:y})},63041(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._2x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:_};l.d(o,{},{m:y})},23382(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
`.withBehaviors(),y={cardCount:3,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._2x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_halfy,C4:C.u._2x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:_};l.d(o,{},{v:y})},97510(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._2x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_2y,C4:C.u._1x_2y,C3:C.u._1x_2y,C2:C.u._1x_2y,C1:C.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}}],styles:_};l.d(o,{},{R:y})},93728(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:C.u._1x_halfy},telemetryRowCol:{C5:[1,5]}}],styles:_};l.d(o,{},{v:y})},47956(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

`.withBehaviors(),y={cardCount:5,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:C.u._1x_halfy,C4:C.u._1x_halfy,C3:C.u._1x_halfy,C2:C.u._1x_halfy,C1:C.u._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,5],C3:[1,5],C2:[1,5],C1:[1,5]}}],styles:_};l.d(o,{},{X:y})},42506(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1";
}
`.withBehaviors(),y={cardCount:1,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:_};l.d(o,{},{X:y})},43063(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),y={cardCount:2,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:_};l.d(o,{},{Q:y})},21907(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),y={cardCount:3,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}}],styles:_};l.d(o,{},{X:y})},44789(t,o,l){var C=l(69828),s=l(59669);let _=(0,s.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),y={cardCount:4,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.u._1x_1y,C4:C.u._1x_1y,C3:C.u._1x_1y,C2:C.u._1x_1y,C1:C.u._1x_1y},telemetryRowCol:{C5:[1,4],C4:[1,4]}}],styles:_};l.d(o,{},{c:y})}}]);