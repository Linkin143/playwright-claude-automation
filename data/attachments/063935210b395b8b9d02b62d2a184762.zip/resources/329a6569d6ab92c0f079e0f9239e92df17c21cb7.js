"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-leaderboard"],{18291(t,e,i){i.r(e),i.d(e,{SportsLeaderboardTransformer(){return g}});var a=i(11796),s=i(79811),l=i(70535),n=i(32150),r=i(96950);const o=`${n.T3.StaticsUrl}latest/icons-wc/icons/SportsMotorInprogress.svg`,p=`${n.T3.StaticsUrl}latest/icons-wc/icons/SportsMotorComplete.svg`;class h{constructor(t,e){this.getIdentifier=t=>t?.name||"",this.getLiveGameLogo=()=>r.qy``,this.getNonLiveGameLogo=()=>r.qy``,this.getParticipantName=t=>t?.name||"",this.isWinner=(t,e)=>!(!t?.isWinner||!this.isPostGame(e)),this.isGameSubheaderBold=t=>!1,this.isGameLive=t=>t?.gameStateCatetory===a.Xp.inprogressGame,this.isPostGame=t=>t?.gameStateCatetory===a.Xp.postGame,this.isPreGame=t=>t?.gameStateCatetory===a.Xp.preGame,this.getGameImageUrl=t=>t?.tournamentImageUrl||"",this.getGameName=t=>t?.name||"",this.getGameSubheader=t=>t?.locationName||"",this.displayParticpantCountryFlag=()=>this.isLeaderBoard(),this.displayParticpantScoreTag=()=>!1,this.displayGenericLiveGameIcon=t=>this.isGameLive(t),this.displayGameDate=()=>!1,this.getGameProgress=(t,e)=>{const i=this.sportMatchData&&this.sportMatchData[0];return i?i.gameStateCatetory===a.Xp.postGame?`${i.endDateTime||""} | ${t}`:i.gameStateCatetory===a.Xp.inprogressGame?i.round?`${e} ${i.round} | `:"":i.round?`${e} ${i.round} | ${i.startWeekDay} · ${i.startDateTime}`:`${i.startWeekDay} · ${i.startDateTime}`:""},this.getGameDate=t=>t?t.gameStateCatetory===a.Xp.postGame?t?.endDateTime||"":(t.currentDateTime||0)>(t.gameDate||0)&&(t.currentDateTime||0)<=(t.endDateTime||0)?t.currentDateTime||"":t.gameDate||"":"",this.isLeaderBoard=()=>!!this.sportCardData&&this.sportCardData.dataType===a.VO.leaderboard,this.getParticipantsList=(t,e)=>e&&e.participants&&e.participants.slice(0,t)||[],this.getParticipantScore=(t,e)=>t?.gameStateCatetory===a.Xp.preGame?e?.teetime||"":e?`${e.total||""}`:"",this.getGameDetails=(t,e)=>{const i=t&&t.gameDate&&(new Date).getDate()===new Date(t.gameDate).getDate();let s,l;switch(t.gameStateCatetory){case a.Xp.preGame:s=i?t.gameStartTime:t.gameDate,l=t.tvChannel;break;case a.Xp.inprogressGame:s=t.round,l=t.tvChannel;break;case a.Xp.postGame:s=e,l=t.endDateTime}return{timeOrState:s||"",channelOrDate:l||""}},this.sportCardData=t,this.sportMatchData=e}}class d{constructor(t,e){this.getIdentifier=t=>t?.driverNumber||"",this.getLiveGameLogo=()=>r.qy`<div><img src=${()=>o}></div>`,this.getNonLiveGameLogo=()=>r.qy`<div><img src=${()=>p}></div>`,this.getParticipantName=t=>t?.driverName||"",this.isWinner=t=>t?.isWinner||"0"===t?.timeDifferenceFromLeader,this.getGameProgress=(t="",e="")=>this.sportMatchData&&this.sportMatchData.length&&this.sportMatchData[0]?.laps||"",this.isGameLive=t=>t?.gameStateCatetory===a.Xp.inprogressGame,this.isPreGame=t=>t?.gameStateCatetory===a.Xp.preGame,this.isPostGame=t=>t?.gameStateCatetory===a.Xp.postGame,this.getGameImageUrl=t=>t?.raceImageUrl||"",this.isGameSubheaderBold=t=>this.isPostGame(t)&&!!this.getGameWinner(t),this.getGameName=t=>t?.raceName||"",this.getGameSubheader=t=>{let e=t.locationName;if(this.isPostGame(t)){const i=this.getGameWinner(t);e=i&&i.driverName?`${i.rank||"1"}. ${i.driverName||""}`:e}return e||""},this.getGameWinner=t=>t.participants&&t.participants.filter(t=>t.isWinner)[0],this.getGameDate=t=>t?.gameDate||"",this.isLeaderBoard=()=>!!this.sportCardData&&this.sportCardData.dataType===a.oL.singleRace,this.getParticipantsList=(t,e)=>e?.participants&&e.participants.slice(0,t)||[],this.displayParticpantCountryFlag=()=>!1,this.displayParticpantScoreTag=()=>this.isLeaderBoard(),this.displayGenericLiveGameIcon=t=>!1,this.displayGameDate=()=>!0,this.getParticipantScore=(t,e,i,a,s)=>{let l="";return e?(l=this.isGameLive()?e.isWinner?i:`-${e.timeDifferenceFromLeader||""}${s}`:`${e.points||"-"} ${a}`,l||""):l},this.getGameDetails=(t,e)=>{const i=t&&t.gameDate&&(new Date).getDate()===new Date(t.gameDate).getDate();let s,l;switch(t.gameStateCatetory){case a.Xp.preGame:s=i?t.gameStartTime:t.gameDate,l=t.tvChannel;break;case a.Xp.inprogressGame:s=t.laps,l=t.tvChannel;break;case a.Xp.postGame:s=e,l=t.gameDate}return{timeOrState:s||"",channelOrDate:l||""}},this.sportCardData=t,this.sportMatchData=e}}class c{static getLeaderBoardSportContext(t,e){const i=t&&t.dataType;return i===a.VO.leaderboard||i===a.VO.scheduledTournaments?new h(t,e):new d(t,e)}}class g extends a.Bc{constructor(){super(...arguments),this.getParticipantsCount=(t,e)=>{const i=e?.dataType;switch(t){case"_1x_2y":case"medium":return i===a.oL.raceList||i===a.v1.MotorSportsRaceList?3:6;case"_1x_3y":case"large":return i===a.oL.raceList||i===a.v1.MotorSportsRaceList?6:9;default:return 1}},this.getDataClassName=t=>{const e=t?.dataType,i=e===a.VO.leaderboard||e===a.VO.scheduledTournaments||e===a.v1.GolfSchedule?" golf-data":"";return"b7a76276-375a-718b-52d9-49eae9b263a4"===t?.primaryEntityId?"lb-data formular1-data":"lb-data"+i}}async transform(t){const e=this.getViewModel(t);return{viewTemplate:r.qy`
                <sports-leaderboard
                    :viewModel="${e}"
                ></sports-leaderboard>`}}getViewModel(t){const e=t.matchData?.map(e=>{let i;if(e?.sportsMatchData){const t=e.sportsMatchData;t.gameCenterUrl&&(t.matchClickthroughUrl=(0,s.Ot)(t.gameCenterUrl)),t.gameStateCatetory="string"!=typeof t.gameState?(0,s.m5)(t.gameState.state):t.gameStateCatetory,i=(0,s.yn)(t.gameStartDateTime),t.gameDate=(0,s.AL)(i,n.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,s.ry)(i,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,s.PH)(t.gameState))}if(t.cardData.dataType===a.v1.GolfSchedule||t.cardData.dataType===a.v1.GolfLeaderBoard){const t=e?.sportsMatchData;t.participants?.forEach(t=>{t.total=t.total||t.points,t.countryFlagImageId=t.countryFlagImageId||(0,s.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo),t.isWinner=Boolean(t.isWinner),t.teetime=t.teetime&&"-"!==t.teetime?(0,s.ry)(new Date(t.teetime),n.T3.CurrentMarket):"-"}),t.startWeekDay=(new l.e).localizedWeekday(i,n.T3.CurrentMarket),t.endDateTime=(0,s.AL)((0,s.yn)(t.gameEndDateTime),n.T3.CurrentMarket),t.startDateTime=(0,s.AL)(i,n.T3.CurrentMarket),t.currentDateTime=(0,s.AL)(new Date,n.T3.CurrentMarket),t&&(t.tournamentImageUrl=t.tournamentImageUrl||(0,s.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo))}else if(t.cardData.dataType===a.v1.MotorSportsRaceList||t.cardData.dataType===a.v1.MotorSportsSingleRace){const t=e?.sportsMatchData;t&&(t.raceImageUrl=(0,s.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo)),t.participants?.forEach(t=>{t.isWinner=Boolean(t.isWinner)})}return e.sportsMatchData&&"string"!=typeof e.sportsMatchData.gameState?(0,s.m5)(e.sportsMatchData.gameState.state):e.sportsMatchData.gameStateCatetory,e?.sportsMatchData})||[],i=c.getLeaderBoardSportContext(t.cardData,e),r=t.cardSize;return{dataClassName:this.getDataClassName(t&&t.cardData),linkTarget:"_blank",matchContext:i,matchData:e,showParticipantsCount:this.getParticipantsCount(r,t&&t.cardData),strings:{...this.transformerProvider.strings},isDarkMode:(0,s.jJ)(),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.Game})}}}Promise.resolve().then(i.bind(i,87855))},20517(t,e,i){i.d(e,{z(){return n}});var a=i(56911),s=i(60815),l=i(92011);class n extends l.L{}(0,a.Cg)([s.sH],n.prototype,"viewModel",void 0)},87855(t,e,i){i.r(e),i.d(e,{SportsLeaderboard(){return P}});var a=i(56911),s=i(20517);class l extends s.z{}var n=i(92011),r=i(48751),o=i(86856),p=i(63033),h=i(74849),d=i(22131);const c=h.A` .lb-content{background:var(--sports-item-background)}.lb-game-icon{filter:invert(1)}.formular1-data .lb-game-icon{-webkit-filter:invert(1);filter:invert(1)}.formular1-data .lb-game-icon{-webkit-filter:invert(1);filter:invert(1)}`,g=h.A` .more-actions{right:16px;left:auto}.sports-wc-st-suggest-icon{float:left}`,b=h.A` .more-actions{left:16px;right:auto}.sports-wc-st-suggest-icon{float:right}.lb-content{margin:0 0 0 16px}.lb-game-icon{margin:auto 0px auto 8px}.golf-data .lb-date{float:left}`,x=h.A` .lb-header,.lb-data,.lb-content,.lb-game-list,.lb-content-list{display:flex;align-items:center;width:100%;text-decoration:none;color:${r.l}}.lb-data{box-sizing:border-box;flex-direction:column;height:100%;z-index:1;position:relative}.lb-content{flex-direction:column;align-items:stretch}.golf-data .lb-content{width:100%}.golf-data .lb-header{display:block;padding-bottom:6px}.lb-header{color:${r.l};font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}.lb-sports-liveicon{padding:1px 6px;width:32px;height:16px;background:#FF0000;color:#FFFFFF;border-radius:3px;text-transform:uppercase;font-weight:600;font-size:10px;line-height:14px;text-align:center}.lb-header span{margin:0 2px}.lb-header img{padding-top:4px}.lb-header-title{font-weight:bold}.golf-data .lb-header-title{max-width:210px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}.lb-date{width:50px}.golf-data .lb-date{float:right;text-align:end}.lb-line{display:flex;padding:6px 0 6px 6px;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);width:100%}.golf-data .lb-line{display:grid;grid-template-columns:24px 30px 144px 60px;padding:6px 0px}.golf-data .lb-pre .lb-line{grid-template-columns:30px 168px 60px}.lb-line span{padding:0 4px}.lb-line .winner-tag{padding:6px 0}.lb-winner{color:${r.l}}.lb-real{color:#C80000}.lb-participant{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}.lb-participant-no{font-style:italic;font-size:14px;line-height:20px;font-weight:900;text-align:left;color:#FFFFFF;text-shadow:-1px -1px 1.25px rgba(0,0,0,0.83),1px -1px 1.25px rgba(0,0,0,0.83),-1px 1px 1.25px rgba(0,0,0,0.83),1px 1px 1.25px rgba(0,0,0,0.83)}.lb-score{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:60px;margin-left:auto;margin-right:4px;max-width:60px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.lb-game-list{flex-direction:column;align-items:stretch;width:100%}.lb-game{display:flex;padding:8px;margin:4px 0;border-radius:6px;background:var(--sports-item-background);color:${r.l};text-decoration:none}.lb-game-icon{width:28px;height:28px;margin:auto 8px auto 0px}.lb-rank{width:15px}.lb-country-flag{width:22px;height:20px;margin:auto 8px auto 0px}.lb-game-info{width:158px}.lb-game-subheader,.lb-game-name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height)}.lb-game-name{font-weight:500}.lb-game-detail{text-align:center;color:${r.l};float:right;width:64px;margin:auto;font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}.lb-game-detail > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.lb-game-time,.lb-winner{font-weight:bold}`.withBehaviors(new o.t(g,b),new p.N(null,c),(0,d.mr)(h.A` :host:forced-color-adjust:auto}`));var m=i(96950),f=i(69259),$=i(39957),w=i(32150);const v=m.qy`${t=>t.viewModel.matchContext.getLiveGameLogo()}`,u=m.qy`${t=>t.viewModel.matchContext.getNonLiveGameLogo()}`,y=m.qy`
    <img class="lb-country-flag" role="presentation" 
        src="${(t,e)=>t?.countryFlagImageId}"
    />
`,k=m.qy`
    <span class="lb-participant-no ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" 
        title=${(t,e)=>e.parent.viewModel.matchContext.getIdentifier(t)}>${(t,e)=>`#${e.parent.viewModel.matchContext.getIdentifier(t)}`}
    </span>
`,F=m.qy`
    <span>-</span>
    <span class="lb-date">
        ${t=>t.viewModel.matchContext.getGameDate(t.viewModel.matchData[0])}
    </span>
`,z=m.qy`
    <span>
        ${(0,f.z)(t=>t.viewModel.matchContext.isGameLive(t.viewModel.matchData[0]),v)}
        ${(0,f.z)(t=>!t.viewModel.matchContext.isGameLive(t.viewModel.matchData[0]),u)}
    </span>
`,D=m.qy`
    <span class="lb-sports-liveicon">
        ${t=>t.viewModel.strings.sportsLive}
    </span>
`,S=m.qy`
    ${(0,f.z)(t=>t.viewModel.matchContext.isLeaderBoard(),m.qy`
        <div class="lb-header">
            ${(0,f.z)(t=>!t.viewModel.matchContext.displayGenericLiveGameIcon(t.viewModel.matchData[0])&&t.viewModel.matchContext.displayGameDate(),z)}
            <span class="lb-header-title">
                ${t=>t.viewModel.matchContext.getGameProgress(t.viewModel.strings.sportsStateFinal,t.viewModel.strings.round)}
            </span>
            ${(0,f.z)(t=>t.viewModel.matchContext.displayGenericLiveGameIcon(t.viewModel.matchData[0]),D)}
            ${(0,f.z)(t=>t.viewModel.matchContext.displayGameDate(),F)}
            ${(0,f.z)(t=>!t.viewModel.matchContext.displayGameDate(),m.qy`<span class="lb-date">${t=>t.viewModel.matchContext.isPreGame(t.viewModel.matchData[0])?t.viewModel.strings.teeTime:t.viewModel.strings.total}</span>`)}
        </div>`)}
`,C=m.qy`
    <span 
        class="lb-rank">${(t,e)=>t?.rank||""}
    </span>
`,M=m.qy`
    <div class="lb-line" key=${(t,e)=>e.parent.viewModel.matchContext.getIdentifier(t)}>
        ${(0,f.z)((t,e)=>!e.parent.viewModel.matchContext.isPreGame(e.parent.viewModel.matchData[0]),C)}
        ${(0,f.z)((t,e)=>e.parent.viewModel.matchContext.displayParticpantCountryFlag(),y)}
        <span class="lb-participant ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" title=${(t,e)=>e.parent.viewModel.matchContext.getParticipantName(t)}>
            ${(t,e)=>e.parent.viewModel.matchContext.getParticipantName(t)}
        </span>
        ${(0,f.z)((t,e)=>e.parent.viewModel.matchContext.displayParticpantScoreTag(),k)}
        <span class="lb-score ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" title=${(t,e)=>e.parent.viewModel.matchContext.getParticipantScore(e.parent.viewModel.matchData[0],t)}>
            ${(t,e)=>e.parent.viewModel.matchContext.getParticipantScore(e.parent.viewModel.matchData[0],t,e.parent.viewModel.strings.leader,e.parent.viewModel.strings.pointsAbbreviation,e.parent.viewModel.strings.secondsAbbreviation)}
        </span>
        ${(0,f.z)((t,e)=>e.parent.viewModel.matchContext.isWinner(t)&&0===e.index,m.qy`
            <img
                class="winner-tag"
                src="${w.T3.StaticsUrl}latest/sports/icons/SportsWinnerTag${(t,e)=>e.parent.viewModel.isDarkMode?"Light":"Dark"}.svg">
            `)}
    </div>
`,O=m.qy`
    <a class="lb-game"
        href=${(t,e)=>t?.matchClickthroughUrl||void 0}
        target="${(t,e)=>e.parent.viewModel.linkTarget}"
        data-t="${(t,e)=>e.parent.viewModel.telemetryTag}"
    >
        <img class="lb-game-icon"
            role="presentation"
            src="${(t,e)=>e.parent.viewModel.matchContext.getGameImageUrl(t)}"
        />
        <div class="lb-game-info">
            <div class="lb-game-name" title="${(t,e)=>e.parent.viewModel.matchContext.getGameName(t)}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameName(t)}
            </div>
            <div class="lb-game-subheader ${(t,e)=>e.parent.viewModel.matchContext.isGameSubheaderBold(t)?"lb-winner":""}" title="${(t,e)=>e.parent.viewModel.matchContext.getGameSubheader(t)}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameSubheader(t)}
            </div>
        </div>
        <div class="lb-game-detail">
            <div class="lb-game-time ${(t,e)=>e.parent.viewModel.matchContext.isGameLive(t)?"lb-real":""}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameDetails(t,e.parent.viewModel.strings.sportsStateFinal).timeOrState}
            </div>
            <div class="lb-game-state">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameDetails(t,e.parent.viewModel.strings.sportsStateFinal).channelOrDate}
            </div>
        </div>
    </a>
`,T=m.qy`
    <div class="lb-game-list">
        ${(0,$.ux)(t=>t.viewModel.matchData.slice(0,t.viewModel.showParticipantsCount),O)}
    </div>
`,_=m.qy`
    <a
        class="lb-content${t=>t.viewModel.matchContext.isPreGame(t.viewModel.matchData[0])?" lb-pre":""}"
        href=${t=>t.viewModel.matchData[0]?.matchClickthroughUrl||void 0}
        target="${t=>t.viewModel.linkTarget}"
        data-t="${(t,e)=>t.viewModel.telemetryTag}"
    >
        ${(0,$.ux)(t=>t.viewModel.matchContext.getParticipantsList(t.viewModel.showParticipantsCount,t.viewModel.matchData[0]),M)}
    </a>
`,L=m.qy`
    <div class="${t=>t.viewModel.dataClassName}">
        ${(0,f.z)(t=>t.viewModel.matchContext.isLeaderBoard(),S)}
        ${(0,f.z)(t=>t.viewModel.matchContext.isLeaderBoard(),_)}
        ${(0,f.z)(t=>!t.viewModel.matchContext.isLeaderBoard(),T)}
    </div>
`,B=m.qy`
    ${(0,f.z)(t=>null!=t.viewModel,L)}
`;let P=class extends l{};P=(0,a.Cg)([(0,n.E)({name:"sports-leaderboard",template:B,styles:x,shadowOptions:{delegatesFocus:!0}})],P)}}]);