"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["tcfConsentBanner"],{75470:function(e,n,t){t.d(n,{setupTcfConsentExpireBannerForMsn:function(){return l},shouldShowTcfConsentBanner:function(){return d}});var a=t(7671),r=t(73631),o=t(37210),c=t(89757),i=t(24318),s=t(7446);function l(){let e="Customize your ad experience, including personalized ads settings, on your ",n=(0,i.Lg)(),t={actionDelegate(){n.removeItem("TcfConsentCheckResult")}},l=(0,c.qy)`
        <div class="tcf-leadText">
            ${e} <a
                href="https://account.microsoft.com/privacy/ad-settings"
                class="clickableLeadText"
                target="_blank"
                @click=${(e,n)=>(s.YT.addOrUpdateTmplProperty("TCFRevokeBannerPrivacyClicked","1"),t.actionDelegate(),e.removeBanner(),!0)}
            >${"Microsoft Privacy Dashboard"}</a>
        </div>
    `,d={id:"tcfConsentExpireBannerMsn",group:"Functional",placementSource:"Internal",surfaceModel:{surfaceType:"HorizontalBanner",position:"Top",bannerType:"LegalCompliance",closeSurfaceAction:t,displaySurfaceAction:{actionDelegate(){s.YT.addOrUpdateTmplProperty("TCFRevokeBannerDisplayed","1")}},hideSurfaceAction:{actionDelegate(){s.YT.addOrUpdateTmplProperty("TCFRevokeBannerDismissed","1")}}},contentModel:{title:e,description:l,contentType:a.r.CallToAction}};Promise.all([(0,o.sn)(),(0,r.X9)()]).then(([e])=>{e.sendInternalPlacement(d)})}function d(){let e=(0,i.Lg)(),n="TcfConsentCheckResult";try{let t=JSON.parse(e.getItem(n)||"{}");if(t?.shouldShowBanner)if(Date.now()-t.cleanDate<2592e6)return s.YT.addOrUpdateTmplProperty("TCFRevokeBannerShowed","1"),!0;else e.removeItem(n);return!1}catch(e){return!1}}}}]);