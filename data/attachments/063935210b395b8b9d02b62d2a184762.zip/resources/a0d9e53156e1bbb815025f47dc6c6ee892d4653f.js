"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-augment-card"],{33190(t,e,i){i.r(e),i.d(e,{SportsAugmentCard(){return u},SportsAugmentCardStyles(){return M},SportsAugmentCardTemplate(){return C},ToolingInfo(){return N}});var r=i(56911),n=(i(968),i(60815)),a=i(61473),s=i(11796),o=i(65403),c=i(18576),l=i(52921),d=i(5141),g=i(61823),m=i(2018);class p extends g.N${static getInstance(t,e){const i=`SportsAugmentDataTransformer_${t}`,r=m.vv.get(i,()=>({}));return r[i]||(r[i]=new p("SportsAugmentCard",t,e)),r[i]}tagNameToComponentName(t){if(!this.config?.tagToComponentNameMap)throw new Error("tagToComponentNameMap is not defined in config");return this.config.tagToComponentNameMap[t]||null}}const h={sportsAugmentShown:"SportsAugmentShown",sportsAugmentType:"SportsAugmentType-{0}_{1}",sportsAugmentArticleID:"SportsAugmentArticle-{0}"};class u extends o.U{constructor(){super(...arguments),this.cardId="",this.augmentType="",this.isFirstViewReady=!1,this.ensureObservableBeforeConnect=!0,this.parseFeedData=t=>l.aC.safeExecute(()=>JSON.parse(t),void 0,d.FKe,"SportsAugmentCard - error parsing feed data",`Article ID: ${this.cardId}`),this.generateAugmentView=async t=>{const e=this.getSportsMatchAugmentItem(t);if(e)return await l.aC.safeExecuteAsync(async()=>{const i=p.getInstance(`${s.tX.SportsAugment}_${this.cardId}`,this.transformationContext);if(!i)throw new Error("Could not get SportsAugmentDataTransformer instance");return await i.generateView({cardData:t.sportsMatchupCardData,augmentItem:e,cardSize:this.cardSize,parentTelemetryObject:this.cardTelemetryObject},"sports-augment-card")},void 0,d.NT7,"SportsAugmentCard - generate span view failed",`Article ID: ${this.cardId}`)}}get viewModel(){return this.view.viewModel}experienceConnected(){const t=this.parseFeedData(this.data);if(t){const e=c.F.transformSportsMatchDataWithTrans(t);this.setView(e)}}getExperienceType(){return a.IUs}async setView(t){const e=await this.generateAugmentView(t);e?.viewModel&&(this.view=e,this.isFirstViewReady=!0,this.markVisuallyReadyRaf(),this.setTmplTelemetry())}getSportsMatchAugmentItem(t){return l.aC.safeExecute(()=>{const e=t?.sportsMatchOverallData;if(!e||e.length<1)throw new Error(`SportsAugmentCard - no match items in response: ${e}`);return e[0]},void 0,d._i,"SportsAugmentCard - error getting match item from augment response",`Article ID: ${this.cardId}`)}get transformationContext(){return{config:this.config,strings:this.strings,interestMenuItemClickHandler(){},paginationFlipperClickHandler(){},followClickHandler(){},searchInterestsHandler(){},openSearchViewHandler(){}}}setTmplTelemetry(){if(!this.view)return;(0,l.ao)(h.sportsAugmentShown,1);let t=h.sportsAugmentType.replace("{0}",this.augmentType);t=t.replace("{1}",this.viewModel.id||""),(0,l.ao)(t);const e=h.sportsAugmentArticleID.replace("{0}",this.cardId);(0,l.ao)(e)}}(0,r.Cg)([n.sH],u.prototype,"data",void 0),(0,r.Cg)([n.sH],u.prototype,"view",void 0),(0,r.Cg)([n.sH],u.prototype,"cardId",void 0),(0,r.Cg)([n.sH],u.prototype,"cardSize",void 0),(0,r.Cg)([n.sH],u.prototype,"augmentType",void 0),(0,r.Cg)([n.sH],u.prototype,"isFirstViewReady",void 0);var f=i(96950),v=i(69259);const w=f.qy`
    <img src="${t=>t.viewModel.winnerTagIconUrl}" />
`,x=f.qy`
    <div class="middle-game-detail ${t=>t.viewModel.isWinnerOne?"scale-x":"og-scale"}">
        ${(0,v.z)(t=>t.viewModel.isWinnerOne,w)}
        ${t=>t.viewModel.middleGameDetailsString}
        ${(0,v.z)(t=>t.viewModel.isWinnerTwo,w)}
    </div>
`,$=f.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.middleGameDetailsString}
    </div>
`,A=f.qy`
    <div class="bottom-game-detail">
        ${t=>t.viewModel.gameDateString}
    </div>
`,S=f.qy`
    <div class="game-details">
        ${t=>t.viewModel.isPostGame?x:$}
        ${A}
    </div>
`,y=(t,e)=>f.qy`
    <div class="match-participant">
        ${(0,v.z)(!!t,f.qy`
            <img
                role="presentation"
                src="${t||""}"
            />`)}
        <div class="mp-name">
            ${e||""}
        </div>
    </div>
`,T=f.qy`
    <a
        class="augment-item"
        href="${t=>t.viewModel.clickThroughUrl}"
        title="${t=>t.viewModel.tooltipText}"
        target="_blank"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${t=>y(t.viewModel.participantOneImgIcon,t.viewModel.participantOneName)}
        ${S}
        ${t=>y(t.viewModel.participantTwoImgIcon,t.viewModel.participantTwoName)}
    </a>
`,C=f.qy`
    ${(0,v.z)(t=>t.view&&t.isFirstViewReady,T)}
`;var b=i(74849),I=i(22131),D=i(86856);const k=b.A` :host{--augc-background-color:#141414;--augc-background-hov-color:#292929;--augc-sub-color:#ADADAD;--augc-main-color:#D6D6D6}`,E=b.A` .middle-game-detail.scale-x img{transform:scaleX(-1)}`,H=b.A` .middle-game-detail.og-scale img{transform:scaleX(-1)}`,M=b.A`
:host{--augc-background-color:#F5F5F5;--augc-background-hov-color:#EBEBEB;--augc-sub-color:#616161;--augc-main-color:#424242}.augment-item{border-radius:8px;background-color:var(--augc-background-color);padding:8px 12px;width:242px;height:54px;display:grid;grid-template-columns:72px 98px 72px;font-weight:600;text-decoration:none;color:var(--augc-sub-color)}.augment-item:hover{background-color:var(--augc-background-hov-color)}.match-participant{display:flex;flex-direction:column;align-items:center;justify-content:center}.match-participant img{width:36px;height:36px}.mp-name{font-size:12px;font-style:normal;font-weight:400;line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.game-details{display:flex;flex-direction:column;justify-content:center;align-items:center}.middle-game-detail{font-size:20px;font-style:normal;font-weight:600;line-height:28px;color:var(--augc-main-color);display:flex;align-items:center;gap:4px}.middle-game-detail img{vertical-align:middle}.wt-helper{display:inline-block;height:100%;vertical-align:middle}.bottom-game-detail{font-size:12px;font-style:normal;font-weight:400;line-height:16px}`.withBehaviors(new D.t(E,H),(0,I.G2)(k)),N={experienceConfigSchema:undefined}},26594(t,e,i){i.r(e),i.d(e,{SportsAugmentCardTransformer(){return l}});var r=i(11796),n=i(79811),a=i(52921),s=i(5141),o=i(50180),c=i(32150);class l extends r.ci{constructor(){super(...arguments),this.getTeamImageUrl=t=>{if(t?.imageUrl)return(0,n.Hv)(t?.imageUrl);const e=(0,n.iK)(t?.imageId,!t?.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return(0,n.Hv)(e)},this.getScoreString=t=>{const e=t.participantOne?.score,i=t.participantTwo?.score;return e&&i||a.aC.logErrorWithFormat(s._i,`transformer - Participant scores are missing. p1: ${e}; p2: ${i}`,"SportsAugmentCard"),`${e} - ${i}`},this.getMiddleGameDetailsString=t=>t.gameStateCatetory===r.Xp.postGame?this.getScoreString(t):t.gameStartTime,this.getDateString=t=>t.gameStateCatetory===r.Xp.postGame?`${this.transformerProvider.strings.sportsStateFinal} · ${t.gameDate}`:t.gameDate,this.getTooltipText=t=>t.gameStateCatetory===r.Xp.postGame?(0,o.GP)(this.transformerProvider.strings.sportsMatchAriaPostGame,t.gameDate,t.participantOne?.name,t.participantTwo?.name):(0,o.GP)(this.transformerProvider.strings.sportsMatchAriaGeneric,t.gameDate,t.participantOne?.name,t.participantTwo?.name),this.getWinnerTagIconUrl=()=>(0,n.jJ)()?`${(0,c.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2AugDark.svg`:`${(0,c.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2AugLight.svg`}async transform(t){return{viewModel:this.getViewModel(t)}}getViewModel(t){const e=t.cardData,i=t.augmentItem.sportsMatchData,n=i.gameStateCatetory===r.Xp.postGame,o={brandId:e?.primaryEntityId??e?.leagueId??"",headline:e?.sportType??r.D7.unknown,id:e?.leagueId||"",type:55},c=this.transformerProvider.telemetryBuilder,l=t.parentTelemetryObject,d={...l?.contract?.ext,augHt:70};return c.initTelemetryBuilder(r.BP.Vertical,e?.leagueName,d),l||a.aC.logErrorWithFormat(s.CF0,"transformer - parentTelemetryObject was passed as undefined","SportsAugmentCard"),{clickThroughUrl:i.matchClickthroughUrl,participantOneImgIcon:this.getTeamImageUrl(i.participantOne),participantTwoImgIcon:this.getTeamImageUrl(i.participantTwo),participantOneName:i.participantOne?.name||"",participantTwoName:i.participantTwo?.name||"",middleGameDetailsString:this.getMiddleGameDetailsString(i),gameDateString:this.getDateString(i),isPostGame:n,isWinnerOne:n&&i.participantOne?.isWinner,isWinnerTwo:n&&i.participantTwo?.isWinner,winnerTagIconUrl:this.getWinnerTagIconUrl(),tooltipText:this.getTooltipText(i),id:i.gameId,telemetryTag:c.createNavClickWithTypeTelemetryTag(l,{...o,name:r.BP.Augment},81)}}}}}]);