"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-2c"],{70512(t,e,i){i.d(e,{O(){return r}});var a=i(41432),s=i(11796);class r extends s.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{cardSize:e,isFullCard:i,sportsGameStats:s,isSpotlight2Card:r,participants:n,isSeasonStats:o,isCopilotTheme:l,isMitUX:c}=t;let d=0;switch(e){case a.uE._1x_2y:d=i?5:3;break;case a.uE._1x_3y:d=7;break;case a.uE._2x_2y:d=4;break;case a.uE._15u:d=3}return{sportsGameStats:s.slice(0,d).map(t=>{const e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:r,isFullCard:i,participants:n,cardTitle:this.getCardTitle(o,l),isCopilotTheme:l,isMitUX:c,telemetryTag:""}}isPercentStats(t){return t?.includes("%")}getBarPercentage(t,e,i){const a=this.isPercentStats(i);return 0===t&&0===e?0:100*(a?t:t/(t+e))}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},82724(t,e,i){i.r(e),i.d(e,{SportsMatchTransformer(){return c}});var a=i(11796),s=i(79811),r=i(31157),n=i(50180),o=i(32150),l=i(83991);class c extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.preGame?t.preGameNotificationMessage:null,this.getPostGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.postGame?t.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=t=>this.isNotificationEnabledAndAvailable(t)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=t=>null!=this.getPreGameNotificationMessage(t)||null!=this.getPostGameNotificationMessage(t),this.getTeamColor=(t,e="")=>t?.primaryColor?(0,s.gS)(t.primaryColor):t?.primaryColorHex?(0,s.gS)(t.primaryColorHex):e,this.getTeamImageUrl=t=>{if(t?.imageUrl)return(0,s.Hv)(t?.imageUrl);const e=(0,s.iK)(t?.imageId,!t?.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return(0,s.Hv)(e)},this.getBackgroundGradient=t=>{if(!t)return"";const e=this.getTeamColor(t.participantOne),i=this.getTeamColor(t.participantTwo);if(!e||!i||e===i&&"#ffffff"===e.toLowerCase())return"";const a=this.hexToRgba(e,1),s=this.hexToRgba(e,.35),r=this.hexToRgba(i,1),n=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${s} 11%,\n                        ${s} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${n} 85.25%,\n                        ${n} 89%,\n                        ${r} 89.25%,\n                        ${r} 100%)`},this.isRTLDirection=()=>document.dir===r.O.rtl,this.getGameDate=t=>{const{gameStartDateTime:e,gameStateCatetory:i}=t||{};if(this.isCopilotTheme){const t=(0,s.yn)(e),r=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return t.toLocaleDateString(o.T3.CurrentMarket,r)}{const t=(0,s.yn)(e);return(0,s.AL)(t,o.T3.CurrentMarket)}}}async transform(t){return{viewModel:await this.getViewModel(t)}}updateAdditionalInfo(t){const{sportsMatchData:e}=t;if(e&&e.additionalInfo){if(!e.additionalInfo.round&&e.additionalInfo.roundLocKey){let t=this.transformerProvider.strings[e.additionalInfo.roundLocKey];e.additionalInfo.roundParams?.forEach((e,i)=>{t=t?.replace(`{${i}}`,e)}),e.additionalInfo.round=t}if(!e.additionalInfo.roundSummary&&e.additionalInfo.roundLocKey){let t=this.transformerProvider.strings[e.additionalInfo.roundSummaryLocKey];e.additionalInfo.roundSummaryParams?.forEach((e,i)=>{t=t?.replace(`{${i}}`,e)}),e.additionalInfo.roundSummary=t}}}getGroupInfo(t){const e=t.matchData.sportsMatchData;if(!t.isMitUX||e.gameStateCatetory!==a.Xp.inprogressGame){if(t.isMitUX&&e.phaseId){if("Group"===e.phaseId)return this.formatGroupText(e.group);const t=this.getPhaseLabel(e.phaseId);if(t)return t}return e.groupInfo?this.formatGroupText(e.groupInfo):t.topDetailText||void 0}}formatGroupText(t){const e=this.transformerProvider.strings.groupTextStr||this.transformerProvider.strings.groupText;if(!e)return;const i=e.split("${0}").join("{0}");return(0,n.GP)(i,t??"")}getPhaseLabel(t){const e=this.transformerProvider.strings;return{RoundOf32:e.bracketPhaseNameRoundOf32,RoundOf16:e.bracketPhaseNameRoundOf16,QuarterFinal:e.bracketPhaseNameQuarterfinal,SemiFinal:e.bracketPhaseNameSemifinal,Final:e.bracketPhaseNameFinal}[t]}hexToRgba(t,e=1){const i=t.match(/\w\w/g);if(!i)return"";const[a,s,r]=i.map(t=>parseInt(t,16));return`rgba(${a},${s},${r},${e})`}hasLongScore(t){const e=t.participantOne?.score||"",i=t.participantTwo?.score||"";return e.length+i.length>6}getHeaderText(t){if(!t||0===Object.keys(t).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:e,gameDate:i,gamePeriodAndClock:s,gameStateCatetory:r}=t,n=t.participantOne?.score,o=t.participantTwo?.score,l=t.participantOne?.standings,c=t.participantTwo?.standings,d=new Date(e).getFullYear(),p=t.gameStartTime?t.gameStartTime.toLocaleLowerCase():"";let g,h,m,x,v;switch(r){case a.Xp.preGame:g=p,h=this.isCopilotTheme?i:`${i}, ${d}`,m=l,x=c;break;case a.Xp.inprogressGame:g=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),h=s,m=n,x=o;break;case a.Xp.postGame:g=this.transformerProvider.strings.sportsStateFinal,h=`${i}, ${d}`,m=n,x=o;break;default:g=p,h=i,m=l,x=c}switch(!0){case!!g&&!!h:v=`${g} • ${h}`;break;case!!g:v=g;break;case!!h:v=h;break;default:v=""}return{header:v,topScoreText:m,bottomScoreText:x,leftHeaderText:g,rightHeaderText:h}}async getViewModel(t){const{matchData:e,isVertical:i,telemetryConstants:r,showMatchUXV2:n,noBackgrounds:c,participantOneFollowed:d,participantTwoFollowed:p,reason:g,isContainLiveMatch:h,parentTelemetryObject:m,useLargeTeamIcon:x,hasVerticalLine:v,isSpotlight2Card:f,isSpotlightCard:u}=t||{},b=e.sportsMatchData;this.isCopilotTheme=t.isCopilotTheme||!1,this.updateAdditionalInfo(e),"string"!=typeof b.gameState&&(b.gameStateCatetory=(0,s.m5)(b.gameState.state));const $=(0,s.yn)(b.gameStartDateTime);b.gameDate=this.getGameDate(b),b.gameStartTime=(b.gameStartDateTimeIsToBeAnnounced?null:(0,s.ry)($,o.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof b.gameState&&(b.gamePeriodAndClock=(0,s.PH)(b.gameState)),"string"!=typeof b.gameState&&(b.gamePeriod=b.gameState.gamePeriod),b.participantOne&&(b.participantOne.scheduleUrl=(0,s.Ot)(b.participantOne.gameCenterUrl)),b.participantTwo&&(b.participantTwo.scheduleUrl=(0,s.Ot)(b.participantTwo.gameCenterUrl)),b.gameCenterUrl&&(b.matchClickthroughUrl=(0,s.Ot)(b.gameCenterUrl)),b.participantOne.imageUrl=(0,s.iK)(b.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.participantTwo.imageUrl=(0,s.iK)(b.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.gameState=b.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:b.gameStateCatetory,t.isMitUX&&b.gameStateCatetory===a.Xp.inprogressGame&&(b.tvChannel=void 0);const w={...r,name:a.BP.Game},y=i||t.isCopilotTheme,k=this.transformerProvider.config.enableLiveScores,z=n&&!c&&!k,S=(0,s.jJ)()?`${o.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${o.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:k||n?"":this.getBackgroundGradient(b),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(m,{...w,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(b),gameNumber:"number",linkTarget:"_blank",matchData:e,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(b),overrideStyleForMatch:"",participantOneColor:z?this.getTeamColor(b.participantOne):"",participantOneFollowed:d,participantOneImgIcon:this.getTeamImageUrl(b.participantOne),participantTwoColor:z?this.getTeamColor(b.participantTwo):"",participantTwoFollowed:p,participantTwoImgIcon:this.getTeamImageUrl(b.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(b),preGameNotificationMessage:this.getPreGameNotificationMessage(b),reason:g,shouldDisplayT4:!h,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(m,w),cardSize:t.cardSize,topDetailText:this.getGroupInfo(t),useLargeTeamIcon:k||x,enableLiveScores:!t.isMitUX&&(k||n),showMatchUXV2:k||n,noBackgrounds:c,isVertical:i,headerText:y?this.getHeaderText(b):void 0,needsVerticalLine:v,liveIconUrl:S,isSpotlight2Card:f,isSpotlightCard:u,isCopilotTheme:this.isCopilotTheme,isWindows:o.T3.AppType===l.u.WindowsNewsWidgets,isMitUX:t.isMitUX}}}},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},83546(t,e,i){i.d(e,{h(){return s}});var a=i(53128);function s(){return(0,a.oh)()}},57877(t,e,i){i.r(e),i.d(e,{SportsGameStatsTransformer(){return a.O},SportsMatchTransformer(){return s.SportsMatchTransformer},SportsMatchWithScoresTransformer(){return c},SportsSpotlight2cTransformer(){return g}});var a=i(70512),s=i(82724),r=i(11796),n=i(87906),o=i(5141),l=i(32150);class c extends r.Bc{async transform(t){return{viewModel:await this.getViewModel(t)}}async getViewModel(t){const e=t.matchMetadata,i=await this.transformerProvider.generateView(e,r.hi.SportsMatch),a=e.matchData.sportsMatchData,s=this.getTableViewModel(t),n={...e.telemetryConstants,name:r.BP.SportsSpotlightMatchCard2c},o=a?.gameInfo,l=this.getGameInfoStrings(a);return{match:i.viewModel,gameInfo:o,tableView:s,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,n),gameInfoStrings:l}}getTableViewModel(t){try{const e=t.matchMetadata,i=e.matchData.sportsMatchData,a=i.detailedScore;if(!a)return;if(!a.game||a.game?.length<2)return void(0,n.vV)(o.BfS,"Sports scores table detailedScored game data missing",`market=${l.T3.CurrentMarket}`,t);const s=a.game,c=a.scoreKeyOrder,d=12;if(c.length>d)return;const p=[];i.participantOne&&(i.participantOne?.shortName&&p.push(i.participantOne.shortName),i.participantTwo?.shortName&&p.push(i.participantTwo.shortName));const g=p.map((t,e)=>({gameScore:Object.values(s[e]).slice(0,c.length),participantName:t}));if(0===g.length)return;const h={...e.telemetryConstants,name:r.BP.SportsSpotlightScores2c},m=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,h),x=this.getTableStyle(c,d),v=c.length>=5;return{headerRow:c,participants:g,maxElements:d,tableStyle:x,isLarge:v,telemetryTag:m}}catch(e){return void(0,n.vV)(o.BfS,`Error generating sports scores table view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}getGameInfoStrings(t){const e=t?.gameInfo,i={venueTitle:"",venueValue:"",streamTitle:"",streamValue:"",leagueTitle:"",leagueValue:""};return e&&(i.venueTitle=this.transformerProvider.strings.venue,i.venueValue=t.gameInfo.venueInfo,i.streamTitle=this.transformerProvider.strings.liveStream,i.streamValue=t.gameInfo.streamInfo,i.leagueTitle=this.transformerProvider.strings.league,i.leagueValue=t.gameInfo.league),i}getGap(t,e){const i=t,a=e;return`gap: ${Math.round(3*(a-i))}px;`}getTableStyle(t,e){const i=t.length;return i<5?`grid-template-columns: repeat(auto-fit, minmax(16px, max-content)); ${this.getGap(i,e)}`:"grid-template-columns: repeat(auto-fit, minmax(16px, 1fr));"}}var d=i(79811),p=i(96950);class g extends r.Bc{constructor(){super(...arguments),this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"yardsPerGame",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame"}}async transform(t){const e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.upcomingMatches)},i=await this.getCurrentViewModel(e);return{viewTemplate:p.qy`
                <sports-spotlight-2c
                    :viewModel="${i}"
                ></sports-spotlight-2c>`}}async getCurrentViewModel(t){if((0,d.nD)(t))(0,n.vV)(o.BfS,"2c spotlight metadata missing",`market=${l.T3.CurrentMarket}`,t);else try{const e=t.spotlightData?.matchlist,i=this.getMatchesMetadata(t,e),a=await this.getMatchWithScoresViews(i);0===a.length&&(0,n.vV)(o.BfS,"2c spotlight match data missing",`market=${l.T3.CurrentMarket}`,t);const{cardSize:s}=t;let r,c,d,p;if(t.spotlightData?.sportsGameStats?.length>0)r=await this.getGameStatsInfo(t),d=t.spotlightData?.isSeasonStats?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.matchStatistics;else{const e=t.spotlightData?.upcomingMatchList,i=this.getMatchesMetadata(t,e).map(t=>({...t,hasVerticalLine:!0}));c=await this.getMatchViews(i),p=this.transformerProvider.strings.upcomingGames}return{matchesWithScores:a,upcomingMatches:c,cardSize:s,sportsGameStatsCard:r,sportsGameStatsTitle:d,sportsUpcomingMatchesTitle:p,telemetryTag:""}}catch(e){(0,n.vV)(o.BfS,`Error generating sports spotlight 2c view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}async getGameStatsInfo(t){const{sportsGameStats:e,isSeasonStats:i=!1}=t.spotlightData||{},{cardSize:a}=t,s={cardSize:a,sportsGameStats:e,isSeasonStats:i};return await this.transformerProvider.generateView(s,r.hi.SportsGameStats)}getMatchesMetadata(t,e){if(!e)return[];const i=(0,d.nD)(t.followedSports)?new Map:t.followedSports,a=(0,d.Yo)(e);return e.map(e=>{const s=e.sportsMatchData,r=i.get(s.participantOne?.satoriId||"")||i.get(s.participantOne?.yId||"")||!1,n=i.get(s.participantTwo?.satoriId||"")||i.get(s.participantTwo?.yId||"")||!1;return{matchData:e,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,participantOneFollowed:r,participantTwoFollowed:n,isContainLiveMatch:a,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:t.isHeroCard,isVertical:!0}})}async getMatchViews(t){const e=t.map(t=>this.transformerProvider.generateView(t,r.hi.SportsMatch));return(await Promise.all(e)).filter(d.z2)}async getMatchWithScoresViews(t){const e=t.map(t=>this.transformerProvider.generateView({matchMetadata:t},r.hi.SportsMatchWithScores));return(await Promise.all(e)).filter(d.z2)}transformSportsSpotlightData(t,e){const{statistics:i}=t,a=t.match&&this.transformMatchData(t.match);let s,r=d.Zi,c=d.ZL;const p=[];if(a){const t=a.participantOne?.primaryColorHex===a.participantTwo?.primaryColorHex&&"ffffff"===a.participantOne?.primaryColorHex?.toLowerCase();!t&&a.participantOne?.primaryColorHex&&(r=(0,d.gS)(a.participantOne.primaryColorHex)),!t&&a.participantTwo?.primaryColorHex&&(c=(0,d.gS)(a.participantTwo.primaryColorHex)),a.matchClickthroughUrl?s=a.matchClickthroughUrl:a.gameCenterUrl&&(s=(0,d.Ot)(a.gameCenterUrl),a.matchClickthroughUrl=s),p.push({sportsMatchData:a})}let g=[];e&&(g=e.map(t=>(!(t=this.transformMatchData(t)).matchClickthroughUrl&&t.gameCenterUrl&&(t.matchClickthroughUrl=(0,d.Ot)(t.gameCenterUrl)),{sportsMatchData:t})));const h=this.transformGameState(i,[r,c]);if(h||0!==g.length)return{matchlist:p,upcomingMatchList:g,sportsGameStats:h,matchClickthroughUrl:s||"",isSeasonStats:i&&i.season&&2===i.season.length};(0,n.vV)(o.BfS,"Missing both game stats and upcoming match data",`market=${l.T3.CurrentMarket}`,t)}transformMatchData(t){const e=(0,d.yn)(t.gameStartDateTime);return t.gameDate=(0,d.AL)(e,l.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,d.ry)(e,l.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,t.gameStateCatetory="string"!=typeof t.gameState?(0,d.m5)(t.gameState.state):t.gameStateCatetory,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,d.PH)(t.gameState)),t.participantOne&&(t.participantOne.scheduleUrl=(0,d.Ot)(t.participantOne.gameCenterUrl)),t.participantTwo&&(t.participantTwo.scheduleUrl=(0,d.Ot)(t.participantTwo.gameCenterUrl)),t.gameCenterUrl&&(t.matchClickthroughUrl=(0,d.Ot)(t.gameCenterUrl)),t.participantOne.imageUrl=(0,d.iK)(t.participantOne.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.participantTwo.imageUrl=(0,d.iK)(t.participantTwo.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.gameState=t.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:t.gameStateCatetory,t}transformGameState(t,e){if((0,d.nD)(t))return;let i=[];t.season&&2===t.season.length?i=t.season:t.game&&2===t.game.length&&(i=t.game);const a=[];if(i[0]&&i[1]){const s=i[0],r=i[1],n=t.statsKeyOrder||Object.keys(s);for(const t of n){const i=Number(s[t]),n=Number(r[t]),o=this.gameStatsFormatMap[t],l=this.formatGameStatsNumber(i,o),c=this.formatGameStatsNumber(n,o),d=this.calculatePercentNumbers(i,n),p={key:this.gameStatsLocKeyMap[t]||t,left:i,right:n,leftText:l,rightText:c,leftColor:e[0],rightColor:e[1],...d};a.push(p)}}return a}formatGameStatsNumber(t,e){if(!e)return t.toString();let i="";return e.isPercent&&(i="%"),void 0!==e.toFix?`${t.toFixed(e.toFix)}${i}`:`${t}${i}`}calculatePercentNumbers(t,e){let i=0,a=0,s=0;return 0!==t&&0!==e?(s=.7,i=t/(t+e)*99.3,a=e/(t+e)*99.3):0===t&&0===e?(i=0,a=0,s=0):0===t?(i=2.3,a=97,s=.7):0===e&&(i=97,a=2.3,s=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(a.toFixed(1)),gap:s}}}Promise.resolve().then(i.bind(i,9306)),Promise.resolve().then(i.bind(i,61618)),Promise.resolve().then(i.bind(i,80195)),Promise.resolve().then(i.bind(i,42273)),Promise.resolve().then(i.bind(i,55283))},20517(t,e,i){i.d(e,{z(){return n}});var a=i(56911),s=i(60815),r=i(92011);class n extends r.L{}(0,a.Cg)([s.sH],n.prototype,"viewModel",void 0)},71372(t,e,i){i.d(e,{a(){return n}});var a=i(56911),s=i(92011),r=i(95144);let n=class extends s.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,a.Cg)([r.x],n)},61618(t,e,i){i.r(e),i.d(e,{SportsGameStats(){return j}});var a=i(56911),s=i(20517),r=i(83546),n=i(60815);class o extends s.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,r.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,a.Cg)([n.sH],o.prototype,"isMitUx",void 0);var l=i(92011),c=i(86856),d=i(63033),p=i(74849),g=i(4126),h=i(22131);const m=p.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,x=p.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,v=p.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,f=p.A` .game-stats-item-content{transform:scaleX(-1)}`,u=p.A` .game-stats-list{background:var(--button-light-rest)}.game-stats-item-header > span:nth-child(2){font-weight:550}@media (prefers-color-scheme:dark){.game-stats-list{background-color:#00000040}.game-stats-item{color:#fff}.game-stats-title{color:#fff}}`,b=p.A` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new c.t(null,f),new d.N(v,x),new g.o("isAdaptiveThemeEnabled",!0,m),new g.o("isMitUx",!0,u),(0,h.mr)(p.A` :host{forced-color-adjust:auto}`));var $=i(96950),w=i(69259),y=i(39957);const k=$.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,z=$.qy`
    <div class="team-container">
        ${(0,w.z)((t,e)=>0!==e.index,$.qy`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,w.z)((t,e)=>0===e.index,$.qy`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,S=$.qy`
    <div class="game-team-icons">
        ${(0,y.ux)(t=>t.viewModel.participants,z,{positioning:!0})}
    </div>
`,F=$.qy`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,T=$.qy`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,w.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,S)}
        ${(0,w.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,F)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,y.ux)(t=>t.viewModel.sportsGameStats,k)}
        </div>
    </div>
`,M=$.qy`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,y.ux)(t=>t.viewModel.sportsGameStats,$.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,C=$.qy`${t=>t.viewModel?.isCopilotTheme?M:T}`,A=$.qy`
    ${(0,w.z)(t=>null!=t.viewModel,C)}
`;let j=class extends o{};j=(0,a.Cg)([(0,l.E)({name:"sports-game-stats",template:A,styles:b,shadowOptions:{delegatesFocus:!0}})],j)},42273(t,e,i){i.r(e),i.d(e,{SportsMatchWithScores(){return k}});var a=i(56911),s=i(20517);class r extends s.z{shouldShowTable(){return void 0!==this.viewModel.tableView}}var n=i(92011),o=i(48751),l=i(86856),c=i(63033),d=i(74849),p=i(22131);const g=d.A` :host{--line-style:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,h=d.A`
`,m=d.A`
`,x=d.A` :host{--line-style:#F2F2F2;--background-color:#FAFAFA}.vert-match{display:flex;height:216px;padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:12px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.match-cntnr,.game-info,.line,.scores-table{width:100%}.game-info{display:flex;flex-direction:column;align-items:flex-start;padding:4px 0px;gap:6px;border-radius:8px}.game-item{display:flex;justify-content:space-between;align-items:flex-start;align-self:stretch;gap:20px}.game-title,.game-value{line-height:var(--type-ramp-minus-1-line-height,16px);font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;white-space:nowrap;color:${o.l}}.game-value{text-align:right;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.line{height:1px;background:var(--line-style)}.scores-table{min-height:1px}`.withBehaviors(new l.t(h,m),new c.N(null,g),(0,p.mr)(d.A` :host{forced-color-adjust:auto}`));var v=i(96950);const f=v.qy`
    <sports-match class="match-cntnr"
        :viewModel="${t=>t.viewModel.match}"
    ></sports-match>
`,u=v.qy`
    <div class="game-info">
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.leagueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.leagueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                 ${t=>t.viewModel.gameInfoStrings.venueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.venueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.streamTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.streamValue}
            </div>
        </div>
    </div>
`,b=v.qy`
    <sports-scores-table class="scores-table"
        :viewModel="${t=>t.viewModel.tableView}"
    ></sports-scores-table>
`,$=v.qy`
<div class="vert-match">
    ${f}
    <div class="line"></div>
    ${b}
</div>
`,w=v.qy`
    <div class="vert-match">
        ${f}
        <div class="line"></div>
        ${u}
    </div>
`,y=v.qy`
    ${t=>t.shouldShowTable()?$:w}
`;let k=class extends r{};k=(0,a.Cg)([(0,n.E)({name:"sports-match-with-scores",template:y,styles:x,shadowOptions:{delegatesFocus:!0}})],k)},80195(t,e,i){i.r(e),i.d(e,{SportsMatch(){return lt}});var a=i(56911),s=i(52921),r=i(60815),n=i(20517);class o extends n.z{constructor(){super(...arguments),this.isMitUx=!1,this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(t,e,i,a){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const r="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,s.LE)(t.currentTarget,r,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,a)}}}(0,a.Cg)([r.sH],o.prototype,"isMitUx",void 0);var l=i(92011),c=i(48751),d=i(62047),p=i(61138),g=i(41123),h=i(71157),m=i(62198),x=i(4283),v=i(70289),f=i(63033),u=i(50882),b=i(74849),$=i(4126),w=i(22131);const y="#CD3800",k="#E98F6D",z=b.A` .date,.nodate{width:auto}`,S=b.A` .sports-match{background-color:rgba(255,255,255,0.7);border-radius:8px;padding:7px 5px;gap:23px;justify-content:center;height:66px;box-sizing:border-box}.side-by-side-matchup-content{width:242px}.side-by-side-gradient-container{background-image:none !important}.participant-container{height:52px;justify-content:center;align-items:center;width:74px}.participant-icon,.participant-icon.logo-backplate{width:45px;height:45px}.participant-container .logo-backplate.participant-icon-large img{width:45px;height:45px}.game-in-progress-text{color:#1A1A1A}@media (prefers-color-scheme:dark){.sports-match{background-color:#00000040}.bottom-game-detail .game-in-progress-text{color:#fff}}`,F=b.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${k}}.game-in-progress-text{color:${k}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${k};background-color:${k}}.standings-style{color:${c.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,T=b.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${v.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${c.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${c.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${c.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${c.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${c.l}}.foreground-rest-text-color{color:${c.l}}.top-game-detail{color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${c.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${c.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${p.k};line-height:${p.F};color:${c.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${g.K};line-height:${g.Z};font-weight:600;color:${c.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${c.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${y};font-size:${p.k};line-height:${p.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${y};font-size:${d.t}}.participant-name-style{font-size:${p.k};line-height:${p.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${h.T};line-height:${h.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${p.k};line-height:${p.F};max-width:100px}.game-score-notification-text-style{font-size:${h.T};line-height:${h.O}}.game-score-text-style{color:${c.l};line-height:${h.O};font-size:${m.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${y};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${d.t};line-height:${d.e};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${c.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${g.K};line-height:${g.Z};font-weight:900;color:${c.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${p.k};line-height:${p.F};font-weight:600;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${x.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${y};width:16px;height:0;left:126px;top:20px;position:absolute;background-color:${y}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${c.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${c.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${c.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${v.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new f.N(null,F),(0,w.mr)(b.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${u.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${u.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${u.A.LinkText}}.click-for-detail{border:1px solid;background-color:${u.A.LinkText}}.detail-live-animation{background-color:${u.A.LinkText}}.scores-line{overflow:hidden}}`),new $.o("isWindowsCopilot",!0,z),new $.o("isMitUx",!0,S));var M=i(11796),C=i(50180),A=i(96950),j=i(69259),P=i(36516),G=i(10500),_='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const I=(t,e)=>A.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,C.GP)(e?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",t.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:M.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:M.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${t=>t.viewModel?.followTelemetryTag}"
    >
        <div class="${t=>e?"icon-add":"icon-selected"}"> ${A.qy.partial(e?P.A:G.A)}</div>
    </div>
`,V=A.qy`
    <div class="game-details">
        ${A.qy`<div class="top-game-detail">${t=>t.viewModel.topDetailText}</div>`}
        ${t=>((t,e,i=null,a=null)=>{switch(t.getMatchData().gameStateCatetory){case M.Xp.preGame:return null==i?K():tt(i);case M.Xp.inprogressGame:return rt();case M.Xp.postGame:return e?st():(0,C.oT)(t.viewModel.topDetailText)?it(a||""):at();default:return K()}})(t,t.viewModel.shouldShowChampionPostGame,t.viewModel.preGameNotificationMessage,t.viewModel.postGameNotificationMessage)}
    </div>
`,D=A.qy`
    <div class="${t=>t.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${V}
        ${t=>U(t.getMatchData().additionalInfo)}
    </div>
`,L=()=>A.qy`
    <div class="g-dtl ${t=>t.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${t=>t.getMatchData().gameStateCatetory===M.Xp.inprogressGame?H:""}
            ${t=>t.getMatchData().gameStateCatetory===M.Xp.postGame?X:""}
            <div class="kscr-cntr">
                <span class="kscr ${t=>t.getMatchData().participantOne?.isWinner?"winner-team":""} part-left">
                    ${(0,j.z)(t=>t.getMatchData().participantOne?.isWinner,A.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${A.qy.partial(_)}</span>`)}
                    ${t=>t.getMatchData().participantOne?.score??""}
                </span>
                ${t=>(0,C.oT)(t.getMatchData().participantOne?.score||"")||(0,C.oT)(t.getMatchData().participantTwo?.score||"")?"":N}
                <span class="kscr ${t=>t.getMatchData().participantTwo?.isWinner?"winner-team":""}">
                    ${t=>t.getMatchData().participantTwo?.score??""}
                    ${(0,j.z)(t=>t.getMatchData().participantTwo?.isWinner,A.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${A.qy.partial(_)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,O=()=>A.qy`
    <div class="date">
        <div class="prehdr">${t=>t.viewModel.headerText?.rightHeaderText}</div>
        <div class="ktime">${t=>t.getMatchData().gameStartTime}</div>
    </div>
`,U=t=>t?A.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${t.round||""}
                </div>
                <div class="round-summary-info">
                    ${t.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${t.scores}
                </div>
            </div>
        `:null,N=A.qy`
    <span class="scores-line">${A.qy.partial(M.Z5)}</span>
`,E=A.qy`
    <span>${A.qy.partial("·")}</span>
`,H=A.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${t=>t.viewModel.liveIconUrl}" />
        <span class="r-live-text">${M.T0.Live}</span>
    </div>
`,X=A.qy`
    <div class="pghdr">
        <span>${M.T0.Final}</span>
        ${t=>t.getMatchData().gameDate?E:""}
        <span>${t=>t.getMatchData().gameDate}</span>
    </div>
`,B=A.qy`
    <div class="vert-noline">
        <div class="vert-header ${t=>t.getMatchData().gameStateCatetory===M.Xp.inprogressGame?"in-prog-vert":""}">
            ${t=>t.viewModel.headerText?.header}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>t.getMatchData().participantOne?.name}">
                        ${t=>t.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===M.Xp.preGame?"standings-style":""}">${t=>t.viewModel.headerText?.topScoreText}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>t.getMatchData().participantTwo?.name}">
                        ${t=>t.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===M.Xp.preGame?"standings-style":""}">${t=>t.viewModel.headerText?.bottomScoreText}</div>
            </div>
        </div>
    </div>
`,R=A.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>t.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>t.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${t=>t.viewModel.headerText?.leftHeaderText}</div>
            <div>${t=>t.viewModel.headerText?.rightHeaderText}</div>
        </div>
    </div>
`,W=A.qy`
    ${t=>t.viewModel.isSpotlightCard?q:Z}
`,Y=A.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>t.getMatchData().participantOne?.name||""}"
                />
            </div>
            <div class="kname ${t=>!t.getMatchData().participantOne?.shortName&&t.getMatchData().participantOne?.name?"long-name":""}" title="${t=>t.getMatchData().participantOne?.name||""}">
                ${t=>t.getMatchData().participantOne?.shortName||t.getMatchData().participantOne?.name||""}
            </div>
        </div>
        ${t=>(t=>t.getMatchData().gameStateCatetory===M.Xp.inprogressGame||t.getMatchData().gameStateCatetory===M.Xp.postGame?L():O())(t)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>t.getMatchData().participantTwo?.name||""}"
                />
            </div>
            <div class="kname ${t=>!t.getMatchData().participantTwo?.shortName&&t.getMatchData().participantTwo?.name?"long-name":""}" title="${t=>t.getMatchData().participantTwo?.name||""}">
                ${t=>t.getMatchData().participantTwo?.shortName||t.getMatchData().participantTwo?.name||""}
            </div>
        </div>
    </div>
`,Z=A.qy`
    <a class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}"
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${Y}
    </a>
`,q=A.qy`
    <div class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}">
        ${Y}
    </div>
`,Q=A.qy`
    ${t=>t.viewModel.needsVerticalLine?R:B}
`,J=A.qy`
    <a class="
        sports-match matchup-neutral-background
        ${t=>t.viewModel.noBackgrounds?"no-bg":""}
        ${t=>t.viewModel.reason.length>0?"reason":""}
        ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${t=>`background-image: ${t.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${t=>t.viewModel.overrideStyleForMatch} ${t=>t.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${t=>t.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${t=>I(t.getMatchData().participantOne||{},!t.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${t=>t.getMatchData().participantOne?.name}">
                    ${t=>t.isMitUx?t.getMatchData().participantOne?.shortName||t.getMatchData().participantOne?.name||"":t.getMatchData().participantOne?.name||""}
                </div>
            </div>
            ${D}
            <div class="participant-container right-participant ${t=>t.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantTwoColor};`}">
                    ${(0,j.z)(t=>t.viewModel.isSpotlight2Card,A.qy`${t=>I(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,j.z)(t=>!t.viewModel.isSpotlight2Card,A.qy`${t=>I(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${t=>t.getMatchData().participantTwo?.name}">
                    ${t=>t.isMitUx?t.getMatchData().participantTwo?.shortName||t.getMatchData().participantTwo?.name||"":t.getMatchData().participantTwo?.name||""}
                </div>
            </div>
        </div>
    </a>
`,K=()=>A.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${t=>t.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gameDate} - ${t.getMatchData().tvChannel}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameDate||""}</span>
            ${t=>t.getMatchData().tvChannel&&t.getMatchData().gameDate?N:""}
        <span>${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,tt=t=>A.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime+"-"+t.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${t=>""+(t.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${t}">
        <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${t}
        </span>
    </div>
`,et=()=>A.qy`
    <div class="middle-game-detail ${t=>t.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,j.z)(t=>t.getMatchData().participantOne?.isWinner,A.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${A.qy.partial(_)}</span>`)}
            ${t=>t.getMatchData().participantOne?.score??""}
        </span>
        ${t=>(0,C.oT)(t.getMatchData().participantOne?.score||"")||(0,C.oT)(t.getMatchData().participantTwo?.score||"")?"":N}
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantTwo?.score??""}
            ${(0,j.z)(t=>t.getMatchData().participantTwo?.isWinner,A.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${A.qy.partial(_)}</span>`)}
        </span>
    </div>
`,it=t=>A.qy`
    <div class="top-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?E:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
    ${et()}
    ${(0,j.z)(!(0,C.oT)(t),A.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${t}">
            <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${t}
            </span>
        </div>
    `)}
`,at=()=>A.qy`
    ${et()}
    <div class="bottom-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?E:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
`,st=()=>A.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${t=>nt(t)}
        </div>
        <div class="game-winner-description" title="${t=>t.viewModel.strings.champions||""}">
            ${t=>t.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantOne?.score??""}
        </span>
        ${t=>(0,C.oT)(t.getMatchData().participantOne?.score||"")||(0,C.oT)(t.getMatchData().participantTwo?.score||"")?"":N}
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantTwo?.score??""}
        </span>
    </div>
`,rt=()=>A.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.enableLiveScores?A.qy`
    <span class="game-score-text-style">
        ${t=>t.getMatchData().participantOne?.score??""}
    </span>
    ${t=>(0,C.oT)(t.getMatchData().participantOne?.score||"")||(0,C.oT)(t.getMatchData().participantTwo?.score||"")?"":N}
    <span class="game-score-text-style">
        ${t=>t.getMatchData().participantTwo?.score??""}
    </span>
`:A.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${t=>(t.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.enableLiveScores?"live-scores-detail":""}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gamePeriodAndClock} - ${t.getMatchData().tvChannel}`:t.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${t=>t.getMatchData().gamePeriodAndClock}">
            ${t=>t.getMatchData().gamePeriodAndClock||""}
        </span>
        ${t=>t.getMatchData().gamePeriodAndClock&&t.getMatchData().tvChannel?N:""}
        <span title="${t=>t.getMatchData().tvChannel}">${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,nt=t=>{const e=t.getMatchData();if(e&&e.gameStateCatetory==M.Xp.postGame){let t=e.participantOne?.isWinner?e.participantOne?.name?.toUpperCase():null;return t||(t=e.participantTwo?.isWinner?e.participantTwo?.name?.toUpperCase():null),t||""}return""},ot=A.qy`
    ${t=>t.isVertical()?A.qy` ${Q} `:t.isCopilotTheme()?A.qy` ${W} `:t.viewModel?A.qy` ${J} `:void 0}
`;let lt=class extends o{};lt=(0,a.Cg)([(0,l.E)({name:"sports-match",template:ot,styles:T,shadowOptions:{delegatesFocus:!0}})],lt)},55283(t,e,i){i.r(e),i.d(e,{SportsScoresTable(){return w}});var a=i(56911),s=i(71372);class r extends s.a{}var n=i(92011),o=i(48751),l=i(86856),c=i(74849),d=i(22131),p=i(63033);const g=c.A`
`,h=c.A`
`,m=c.A`
.table-cntnr{display:flex;gap:6px;align-self:stretch;justify-content:space-between}.part-row,.header-row{display:grid;align-self:stretch;justify-content:end}.header-row:last-child{gap:0}.item-cntnr{align-items:center;justify-content:end}.score-item,.header-item{text-align:center;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:16px;max-width:16px;color:${o.l}}.header-item{font-weight:400}.title-item{display:grid;text-align:left;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:24px;height:16px;color:${o.l};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bold-items{font-weight:600}.title-cntnr,.item-cntnr{display:flex;flex-direction:column;gap:6px}`.withBehaviors(new l.t(null,h),new p.N(null,g),(0,d.mr)(c.A` :host{forced-color-adjust:auto}`));var x=i(96950),v=i(39957),f=i(69259);const u=x.qy`
    ${t=>{const e=t.viewModel?.tableStyle;return(t=>x.qy`
        ${(0,v.ux)(t=>t.viewModel.participants??[],x.qy`<div class="part-row" style=${t}>
                ${(0,v.ux)(t=>t.gameScore??[],x.qy`<div class="score-item">
                    ${t=>t}
                </div>`)}
        </div>`)}
    `)(e)}}
`,b=x.qy`
    <div class="table-cntnr">
            <div class ="title-cntnr">
                <div class="title-item"></div>
                ${(0,v.ux)(t=>t.viewModel.participants??[],x.qy`<div class="title-item">
                    ${t=>t.participantName}
                </div>
                `)}
            </div>
            <div class="item-cntnr" style="${t=>t.viewModel?.isLarge?"width: 100%;":"width: 70%;"}">
                <div class="header-row" style="${t=>t.viewModel?.tableStyle}">
                    ${(0,v.ux)(t=>t.viewModel.headerRow??[],x.qy`<div class="header-item">
                        ${t=>t}
                    </div>`)}
                </div>
                    ${u}
            </div>
    </div>
`,$=x.qy`
    ${(0,f.z)(t=>void 0!==t.viewModel,b)}
`;let w=class extends r{};w=(0,a.Cg)([(0,n.E)({name:"sports-scores-table",template:$,styles:m,shadowOptions:{delegatesFocus:!0}})],w)},9306(t,e,i){i.r(e),i.d(e,{SportsSpotlight2c(){return M}});var a=i(56911),s=i(20517);class r extends s.z{constructor(){super(...arguments),this.shouldShowGameStats=()=>!!this.viewModel.sportsGameStatsCard}}var n=i(92011),o=i(48751),l=i(86856),c=i(74849),d=i(22131),p=i(63033);const g=c.A`
`,h=c.A` :host{--line-color:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,m=c.A` :host{--line-color:#F2F2F2;--background-color:#FAFAFA;--width-1c:278px;--card-height:216px}.game-stats2c,.game-stats-teams-container,.upcmng-matches2c{display:flex;justify-content:space-between}.title,.name{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal;font-weight:600;color:${o.l}}.game-stats2c{width:580px;align-items:center}.game-stats{display:flex;width:var(--width-1c);height:var(--card-height);padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:10px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.line{width:254px;height:0px;border:1px solid var(--line-color)}.game-stats-teams-container{align-items:center;align-self:stretch}.game-stats-teams-container > div{display:flex;align-items:center;gap:6px}.icon{width:16px;height:16px}.name{max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.icon img{max-width:100%;max-height:100%;width:auto;height:auto}.upcmng-matches2c{flex-direction:row;align-items:center;padding:0px;gap:24px}.upcmng-matches{display:flex;flex-direction:column;align-items:flex-start;padding:8px 12px 12px;gap:12px;width:var(--width-1c);height:var(--card-height);background:var(--background-color);border-radius:8px;box-sizing:border-box}.1c{display:flex;justify-content:center;align-items:center;width:268px}.upcmng-matches2c > div:first-of-type{width:var(--width-1c)}.game-stats2c > div:first-of-type{width:var(--width-1c)}`.withBehaviors(new l.t(null,g),new p.N(null,h),(0,d.mr)(c.A` :host{forced-color-adjust:auto}`));var x=i(96950),v=i(39957),f=i(69259);const u=x.qy`
    ${(0,v.ux)(t=>t.viewModel.matchesWithScores??[],x.qy`<sports-match-with-scores style="width: 100%;"
        :viewModel="${t=>t.viewModel}"
    ></sports-match-with-scores>`,{positioning:!0})}
`,b=x.qy`
    ${t=>{const e=t?.viewModel?.matchesWithScores?.[0]?.viewModel?.match;return e?(t=>x.qy`
    <div class="title">
        ${t=>t.viewModel.sportsGameStatsTitle||""}
    </div>
    <div class="line">
    </div>
    <div class="game-stats-teams-container">
        <div>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantOneImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
            <span class="name" title="${t.matchData.sportsMatchData.participantOne?.name||""}">
                    ${t.matchData.sportsMatchData.participantOne?.name||""}
            </span>
        </div>
        <div>
            <span class="name" title="${t.matchData.sportsMatchData.participantTwo?.name||""}">
                    ${t.matchData.sportsMatchData.participantTwo?.name||""}
            </span>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantTwoImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
        </div>
    </div>
`)(e):""}}
`,$=x.qy`
    <div class="game-stats">
        ${b}
        <sports-game-stats :viewModel="${t=>t.viewModel.sportsGameStatsCard?.viewModel}">
        </sports-game-stats>
    </div>
`,w=x.qy`
    <div class=upcmng-matches>
        <div class="title">${t=>t.viewModel.sportsUpcomingMatchesTitle}</div>
        ${(0,v.ux)(t=>t.viewModel.upcomingMatches??[],x.qy`
            <div class="line"></div>
            <sports-match
                :viewModel="${t=>t.viewModel}"
            ></sports-match>`,{positioning:!0})}
    </div>
`,y=x.qy`
    <div class="game-stats2c">
        <div>
            ${u}
        </div>
        ${$}
    </div>
`,k=x.qy`
    <div class="upcmng-matches2c">
        <div>
            ${u}
        </div>
        ${w}
    </div>
`,z=x.qy`
    <div class="1c">
        ${u}
    </div>
`,S=x.qy`
    ${t=>t.shouldShowGameStats()?y:k}
`,F=x.qy`
    ${t=>"_2x_2y"===t.viewModel.cardSize?S:z}
`,T=x.qy`
    ${(0,f.z)(t=>null!=t.viewModel,F)}
`;let M=class extends r{};M=(0,a.Cg)([(0,n.E)({name:"sports-spotlight-2c",template:T,styles:m,shadowOptions:{delegatesFocus:!0}})],M)},99657(t,e,i){i.d(e,{D(){return n},I(){return r}});var a=i(68136);const{create:s}=a.G,r=s("sloppy-click-z-index",1),n=s("click-z-index",1)},38817(t,e,i){i.d(e,{R7(){return x},e(){return h},kc(){return m},nH(){return g}});var a=i(57416),s=i(55153),r=i(95239),n=i(26920),o=i(48751),l=i(64187),c=i(22131),d=i(74849),p=i(50882);const g=d.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,h=d.A` ${(0,l.V)("flex")} :host{background:${r.p};outline:calc(${n.XA} * 1px) solid ${s.cu};border-radius:calc((${a.JU} - ${n.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${o.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${n.XA} * 1px) ${s.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${n.XA} * 1px) ${s.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${n.XA} * 1px) ${s.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${s.QG} * 1px);height:calc(${s.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${s.QG} * 1px);height:calc((${s.l8} * 2px) + (${s.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${s.QG} * 2px) + (${s.Sn} * 1px));height:calc((${s.l8} * 2px) + (${s.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${s.QG} * 2px) + (${s.Sn} * 1px));height:calc(${s.l8} * 1px)}::slotted(*){color:inherit}`,m=(0,c.mr)(d.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),x=d.A` ${h} ${g} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(m)},70289(t,e,i){i.d(e,{f(){return l}});var a=i(64187),s=i(74849),r=i(38817),n=i(99657),o=i(36452);const l=s.A.partial`position: relative; z-index: ${n.D};`;s.A` ${r.e} ${r.nH} ${(0,a.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${o.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${o.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${o.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(r.kc)}}]);