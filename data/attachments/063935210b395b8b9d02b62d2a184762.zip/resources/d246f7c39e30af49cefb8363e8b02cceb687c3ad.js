"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-cricket-exploration"],{22726(e,t,i){i.r(t),i.d(t,{SportsCricketTransformer(){return d}});var r=i(11796),o=i(79811),a=i(31157),n=i(52921),s=i(32150),l=i(96950);const c="yet to bat";class d extends r.Bc{constructor(){super(...arguments),this.getShowMatchCount=e=>{switch(e){case"_1x_2y":case"medium":return 3;case"_1x_3y":case"large":return 4;default:return 1}},this.getGameDate=e=>(new Date).toDateString()===new Date(e).toDateString()?this.transformerProvider.strings.today:e,this.getMatchSummaryText=e=>{if(!e)return"";switch(e.detailedGameState){case r.Xp.preGame:return e.venueInfo?e.venueInfo:e.venue?`${e.venue?.name}, ${e.venue?.state||e.venue?.city||""}`:"";case r.Xp.inprogressGame:case r.Xp.dinner:case r.Xp.tea:case r.Xp.drinks:case r.Xp.fog:case r.Xp.innings:case r.Xp.lunch:case r.Xp.stumps:case r.Xp.break:case r.Xp.superover:case r.Xp.abandoned:case r.Xp.postponed:case r.Xp.delayed:return e.gameSummaryInfo||e.tossInfo||"";case r.Xp.postGame:return e.gameSummaryInfo||"";case r.Xp.toss:return e.tossInfo||"";case r.Xp.nonlive:{const t=e.detailedGameState;return this.transformerProvider.strings[t]||t||""}default:return""}}}async transform(e){const t=await this.getViewModel(e);return{viewTemplate:l.qy`
                <sports-cricket
                    :viewModel="${t}"
                ></sports-cricket>`}}async getViewModel(e){const t=this.getMatchData(e),i=e.cardSize,s=this.getShowMatchCount(i),l={...e.telemetryConstants,name:r.BP.Game};return{cardSize:i,enabledCricketMatchSummaryInfo:s>1,followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.FollowTeam},!0),followedMap:t.followedMap,isExploration:e.isExploration,isIPL:"Cricket_IPL"===e.leagueId,isRTL:document.dir===a.O.rtl,linkTarget:"_blank",matchData:t.matches,matchSummaryMap:t.matchSummaryMap,scoreClassNameMap:t.scoreClassNameMap,scoresMap:t.scoresMap,showMatchCount:s,shouldShowPinToDesk:!1,isDarkMode:(0,o.jJ)(),pinToDeskClick(){},strings:{...this.transformerProvider.strings},telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,l),pinToDeskButtonTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{telemetryContentContext:l,name:r.BP.PinToDesk},n.YJ.Customize)}}getMatchData(e){const t=e.matchData?.map(e=>e?.sportsMatchData)||[],i=e.followedSports||new Map,a=new Map,n=new Map,l=new Map,c=new Map;return t.forEach(e=>{if(e){const t=e.participantOne||{},d=e.participantTwo||{},p=e.gameId||"";let h=e.gameDate;const g=(0,o.yn)(e.gameStartDateTime);h=(0,o.AL)(g,s.T3.CurrentMarket),e.gameStartTime=(e.gameStartDateTimeIsToBeAnnounced?null:(0,o.ry)(g,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA;const x="string"!=typeof e.gameState?(0,o.m5)(e.gameState.state):e.gameStateCatetory,u=e.gameState&&"string"!=typeof e.gameState?this.getDetailedGameStatus(e.gameState?.detailedGameState):e.detailedGameState;e.detailedGameState=u!==r.Xp.nonlive?u:x;let f="";f=u&&u!==r.Xp.nonlive?u:x===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:x,e.gameStateCatetory=x,e.gameState=f,t.imageUrl=this.getParticipantIconUrl(t.imageUrl||(0,o.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),d.imageUrl=this.getParticipantIconUrl(d.imageUrl||(0,o.iK)(d.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),t.gameCenterUrl&&(t.scheduleUrl=(0,o.Ot)(t.gameCenterUrl)),d.gameCenterUrl&&(d.scheduleUrl=(0,o.Ot)(d.gameCenterUrl)),e.gameCenterUrl&&!e.matchClickthroughUrl&&(e.matchClickthroughUrl=(0,o.Ot)(e.gameCenterUrl)),a.set(`${p}${t.satoriId}`,this.getParticipantScoreClassname(t,d,!0)),a.set(`${p}${d.satoriId}`,this.getParticipantScoreClassname(d,t,!1)),n.set(`${p}${t.satoriId}`,this.getScoreLines(t)),n.set(`${p}${d.satoriId}`,this.getScoreLines(d)),e.gameDate=this.getGameDate(h||""),e.gameStateCatetory=e.cricketGameCategory||e.gameStateCatetory,l.set(p,this.getMatchSummaryText(e)),(0,o.gK)(t,i)&&c.set(t.satoriId,!0),(0,o.gK)(d,i)&&c.set(d.satoriId,!0)}}),{matches:t,scoreClassNameMap:a,scoresMap:n,matchSummaryMap:l,followedMap:c}}getParticipantIconUrl(e){return e?.replace(/w=([\d]*)?&h=([\d]*)?/,"w=72&h=72")}getParticipantScoreClassname(e,t,i){let r="participant-score";return e&&(i&&(r+=" text-align-end"),e.isWinner?r+=" winner":t?.isWinner&&(r+=" loser"),e.score?.toLowerCase()===c&&(r+=" long-score")),r}getScoreLines(e){if(e&&e.score){if(e.score.includes("&")){const t=e.score.split("&"),i=t[0],r=i.indexOf("(");return-1!==r&&(t[0]=i.slice(0,r)),t}return e.score.toLowerCase()===c?["--/-",e.score]:e.score.split(" ")}return[]}getDetailedGameStatus(e){switch(e){case"InProgressGame":case"InProgress":return r.Xp.inprogressGame;case"Drinks":return r.Xp.drinks;case"Dinner":return r.Xp.dinner;case"Tea":return r.Xp.tea;case"Lunch":return r.Xp.lunch;case"Fog":return r.Xp.fog;case"Innings":return r.Xp.innings;case"Stumps":return r.Xp.stumps;case"InningsBreak":return r.Xp.break;case"Toss":return r.Xp.toss;case"SuperOver":return r.Xp.superover;case"BadWeatherCondition":return r.Xp.BadWeatherCondition;case"PreGame":return r.Xp.preGame;case"Final":case"PostGame":return r.Xp.postGame;case"Delayed":return r.Xp.delayed;case"Abandoned":return r.Xp.abandoned;case"Postponed":return r.Xp.postponed;default:return r.Xp.nonlive}}}},81714(e,t,i){i.d(t,{K(){return s}});var r=i(41432),o=i(11796),a=i(52921),n=i(79811);class s extends o.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}getShouldShowSecondaryText(e){return e.cardSize!==r.uE._1x_1y&&!e.shouldHideSecondaryText}async getViewModel(e){const t=this.transformerProvider.config.skipFeedRefreshExploration,i=(0,n.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return{followLeagueClickHandler:t=>{this.transformerProvider.followClickEntityHandler({id:e.league.satoriId,yId:e.league.yId,name:e.league.name,type:o.XR.League,imageUrl:i},t,"",!0)},dislikeLeagueClickHandler:()=>{this.transformerProvider.hideClickHandler?.(e.league.id||"",t),this.transformerProvider.config.goToNextTabDelay&&t&&this.transformerProvider.goToNextTabIfExists()},shouldShowDislikeMessage:t,shouldShowSecondaryText:this.getShouldShowSecondaryText(e),followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:o.BP.FollowSports},!0),dislikeTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:o.BP.ExplorationDislike},a.YJ.Customize),isFollowed:this.isFollowed(e),telemetryConstants:e.telemetryConstants,reasonText:e.reasonText,secondaryText:e.secondaryText,logoUrl:(0,n.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced),cardSize:e.cardSize,logoPrimaryColor:e.logoPrimaryColor,isDisliked:e.isDisliked,leagueName:e.league.name,strings:{follow:this.transformerProvider.strings.follow,notInterested:this.transformerProvider.strings.iAmNotInterested,youFollowed:this.transformerProvider.strings.youAreNowFollowing,youDisliked:this.transformerProvider.strings.youWillSeeLessContent},telemetryObject:e.telemetryObject,telemetryTag:""}}isFollowed(e){return e.followedSports.get(e.league.satoriId||"")}}},36516(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},17255(e,t,i){i.r(t),i.d(t,{SportsCricketExplorationTransformer(){return n},SportsCricketTransformer(){return s.SportsCricketTransformer},SportsExplorationHeadTransformer(){return l.K}});var r=i(41432),o=i(11796),a=i(96950);class n extends o.Bc{async transform(e){const t=await this.getCurrentViewModel(e);return{viewTemplate:a.qy`
                <sports-cricket-exploration
                    :viewModel="${t}"
                ></sports-cricket-exploration>`}}async getCurrentViewModel(e){const[t,i]=await Promise.all([this.getExplorationHeadView(e),this.getCricketView(e)]);return{telemetryConstants:e.telemetryConstants,head:t,cricket:i,cardSize:e.cardSize,strings:{featuredGames:this.transformerProvider.strings.featuredGames},telemetryObject:e.telemetryObject,telemetryTag:""}}async getExplorationHeadView(e){const t={followedSports:e.followedSports,reasonText:e.reasonText,secondaryText:e.secondaryText,cardSize:e.cardSize,isDisliked:e.isDisliked,logoPrimaryColor:e.logoPrimaryColor,league:e.league,telemetryObject:e.telemetryObject,shouldHideSecondaryText:e.cardSize===r.uE._1x_2y,telemetryConstants:e.telemetryConstants};return await this.transformerProvider.generateView(t,o.hi.ExplorationHead)}getMaxMatchesCount(e){switch(e.cardSize){case r.uE._1x_2y:return 1;case r.uE._1x_3y:return 3;default:return 0}}async getCricketView(e){const t=this.getMaxMatchesCount(e),i=e.matchList.slice(0,t),r={leagueId:e.league.id,matchData:i,cardSize:e.cardSize,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,isExploration:!0,followedSports:e.followedSports};return await this.transformerProvider.generateView(r,o.hi.SportsCricket)}}var s=i(22726),l=i(81714);Promise.resolve().then(i.bind(i,37699)),Promise.resolve().then(i.bind(i,65201)),Promise.resolve().then(i.bind(i,36571))},71372(e,t,i){i.d(t,{a(){return n}});var r=i(56911),o=i(92011),a=i(95144);let n=class extends o.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,r.Cg)([a.x],n)},37699(e,t,i){i.r(t),i.d(t,{SportsCricketExploration(){return v}});var r=i(56911),o=i(71372);class a extends o.a{}var n=i(92011),s=i(70289),l=i(63033),c=i(74849),d=i(48751);const p=c.A` :host{--divider-color:rgba(255,255,255,0.06)}`,h=c.A` :host{--divider-color:rgba(0,0,0,0.06)}.wrap._1x_2y{margin-top:8px}.divider{width:100%;height:1px;background-color:var(--divider-color);margin-bottom:8px;${s.f};pointer-events:none}.matches-wrap{margin-top:12px}.matches{display:grid;grid-template-columns:131px 131px;gap:6px}.feat-games{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin-bottom:4px;color:${d.l};${s.f};pointer-events:none}`.withBehaviors(new l.N(null,p));var g=i(96950),x=i(69259);const u=g.qy`
    <sports-exploration-head
        :viewModel="${e=>e.viewModel.head.viewModel}"
    ></sports-exploration-head>
`,f=g.qy`
    ${(0,x.z)(e=>"_1x_1y"!==e.viewModel.cardSize,g.qy`
        <div class="matches-wrap">
            <div class="divider"></div>
            <div class="feat-games">${e=>e.viewModel.strings.featuredGames}</div>
            <div class="matches">
                ${e=>e.viewModel.cricket.viewTemplate}
            </div>
        </div>
    `)}
`,b=g.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${u}
        ${f}
     </div>
`,m=g.qy`
    ${(0,x.z)(e=>void 0!==e.viewModel,b)}
`;let v=class extends a{};v=(0,r.Cg)([(0,n.E)({name:"sports-cricket-exploration",template:m,styles:h,shadowOptions:{delegatesFocus:!0}})],v)},36571(e,t,i){i.r(t),i.d(t,{SportsCricket(){return E}});var r=i(56911),o=i(11796),a=i(71372),n=i(50180),s=i(52921);class l extends a.a{handleClickFollowIcon(e,t,i,r){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();const o="keydown"===e.type||"keypress"===e.type||"keyup"===e.type;(0,s.LE)(e.currentTarget,o,t),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,t,r)}}getScoreClassName(e,t){return this.viewModel.scoreClassNameMap?.get(`${e}${t.satoriId}`)||""}getScoreLineByIndex(e,t,i){const r=this.viewModel.scoresMap.get(`${e}${t.satoriId}`),o=r&&r.length>i?r[i]:void 0;return o?.trim()}getMiddleTemplate(e){return e==o.Xp.preGame?"pre":e==o.Xp.postGame?"post":"live"}getMiddleTemplateClass(e){return e===o.Xp.superover?"state-top":e===o.Xp.postponed?"state-bottom":""}getParticipant(e,t){return this.viewModel.isRTL?e?t.participantTwo:t.participantOne:e?t.participantOne:t.participantTwo}getLiveText(e){return e==o.Xp.inprogressGame?this.viewModel.strings?.sportsLive:e}getFollowIconTitle(e,t){return(0,n.GP)((t?this.viewModel.strings?.followSports:this.viewModel.strings?.haveFollowed)||"",e.name||"")}getGameTime(e){return(e.tvChannel?`${e.gameStartTime}, ${e.tvChannel}`:e.gameStartTime)||""}isScoreMultiLine(e,t){const i=this.viewModel.scoresMap.get(`${e}${t.satoriId}`);return!!i&&i.length>1}shouldRenderResults(e){return e!=o.Xp.preGame&&e!=o.Xp.toss}shouldShowSuperOver(e){return e===o.Xp.superover}shouldShowPostPoned(e){return e===o.Xp.postponed}}var c=i(92011),d=i(86856),p=i(63033),h=i(74849),g=i(22131),x=i(70289);const u=h.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}.match-content{color:#FFFFFF}.ipl-super-over{background:rgba(255,255,255,0.09)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(255,255,255,0.3)}.cricket-final{color:#FFFFFF}.expl .cricket-final{background:rgba(255,255,255,0.3)}.winner-tag path{fill:#FFFFFF}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#0078d4}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.cricket-live-tag{background:rgba(36,214,87,1);color:#000000}.expl .cricket-live-tag{background-color:rgba(233,143,109)}.match-footer{color:#FFFFFF}.pin-to-desk-block{background:rgba(91,51,143,1);background-image:linear-gradient(45deg,rgb(255,0,165) 0,rgb(255,0,165) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgba(255,0,165,0.8) 87%,rgb(255,0,165) 100%);color:white}.pin-to-desk-button{border:1px solid white}.win-light{display:none}.win-dark{display:block}`,f=h.A` `,b=h.A` .flip-h .follow-icon{float:left}.match-footer{right:calc(50% - 90px)}.pin-to-desk-button > img{margin-left:4px}`,m=h.A` :host{--participant-height:55px;--match-content-height:54px;--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{text-align:center;align-items:center;display:grid;row-gap:4px;position:relative;height:100%}.match-content{background:var(--sports-item-background);display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:#000000;width:268px;backdrop-filter:blur(6px);height:54px;${x.f}}.match-content:hover,.match-content:focus-visible{background:var(--sports-item-hover-background)}.match-content:active{background:var(--sports-item-active-background)}._1x_1y .match-content{height:var(--match-content-height)}._1x_1y .participant-container{height:var(--match-content-height)}._1x_1y .participant-container .follow-icon{top:-5px;right:-8px}._1x_3y .match-content{height:72px}._1x_3y .participant-content{height:100%}._1x_3y .participant-score span{margin-top:3px}._1x_3y .participant-score{margin-top:10px}:host([isMobile=true]) .match-content{width:100%}:host([cardlayout="_1x_1y"]) .match-content{padding:0}:host([isMobile=true]) .match-content{margin:0 auto;margin-bottom:8px}:host([isMobile=true]) .participant-container{padding:20px;box-sizing:border-box}:host([cardlayout="_1x_1y"]) .participant-container{max-height:70px}:host([isMobile=true]),:host([isMobile=true]) *:active,:host([isMobile=true]) *:hover{border:none;outline:none;box-shadow:none;text-decoration:none;-webkit-tap-highlight-color:transparent;-webkit-highlight:none}.participant-container{width:108px;max-width:132px;margin:0 0 0 13px;height:100%}.participant-container.flip-h{margin:0 13px 0 0}.results{display:flex}.flip-h .results{flex-flow:row-reverse}.single{align-items:center}.single .participant-score span.score-line1{margin:0 0 5px 0}.participant-info{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}.participant-content{display:flex;column-gap:7px;height:var(--participant-height);position:relative}.flip-h .participant-content{flex-flow:row-reverse}.match-detail{height:var(--participant-height);display:flex;align-items:center}.ipl .match-detail.state-top{height:80px}._1x_1y .match-detail{height:var(--match-content-height)}.participant-icon{width:32px;height:auto;border-radius:8px}.participant-name{font-weight:600;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80px;margin:0 auto}.participant-score span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);max-width:62px}.participant-score{max-height:36px;text-align:start;display:flex;flex-direction:column}.participant-score span.score-line1{margin-top:5px;font-size:14px;font-weight:600;line-height:18px}.flip-h .participant-score{text-align:end}.winner{font-weight:600}.winner-tag{position:absolute;height:100%;display:flex;align-items:center;left:-5px;margin-top:-8px;transform:scaleX(-1)}.flip-h .winner-tag{transform:scaleX(1);right:-5px;left:auto}.winner-tag > svg{fill:currentColor}.middle-detail{align-items:center;display:flex;flex-direction:column;direction:ltr}.game-detail{margin-top:-15px}.game-date{font-weight:600;font-size:14px;line-height:20px}.game-time{font-weight:400;font-size:12px;line-height:16px}.pre-game{width:120px}.cricket-live-tag{display:inline-block;background:rgb(7,148,48);color:rgb(255,255,255);font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-line-height,16px);height:16px;padding:1px 6px;margin:0;border-radius:3px;font-weight:600;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-transform:uppercase}.status-text{font-size:12px;line-height:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ipl-super-over{background:rgba(255,255,255,0.4);display:flex;justify-content:center;align-items:center;border-radius:6px}.super-over-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0 4px 0 4px;font-size:10px;font-weight:400;line-height:14px}.state-top{flex-direction:column;justify-content:center}.state-top .middle-detail{flex:1;margin-top:15px}.state-bottom{flex-direction:column;justify-content:center;height:100%;margin-top:10px}.live-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;margin-top:1px}.detail-live-animation{height:1px;transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate;background:white}@keyframes liveAnimation{0%{width:20px}100%{width:4px}}.match-extended-details{width:180px;text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0px 10px;box-sizing:border-box}.match-footer{color:#1A1A1A;font-style:normal;font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:180px;display:inline-block;position:absolute;bottom:5px;left:calc(50% - 90px)}:host([cardlayout="_1x_1y"]) .match-footer{bottom:4px}.super-over-words{background:rgba(255,255,255,0.35);border-radius:3px;color:rgb(101,107,155);font-style:italic;font-weight:600;width:130px;height:30px;font-size:20px;transform:scale(0.5);line-height:14px;display:flex;align-items:center;justify-content:center;padding:0 3px 5px 0;box-sizing:border-box}.cricket-final{width:21px;height:21px;background:var(--sports-item-background);border-radius:21px;font-weight:400;font-size:10px;line-height:21px;color:#000000}.participant-hover{display:flex;align-items:center;justify-content:center;width:36px;height:28px}.ipl .participant-hover{border:0.5px solid rgba(186,186,186,0.22);border-radius:5px}.detail-live-animation .bottom-game-detail{line-height:14px}@keyframes liveAnimationCommon{0%{width:40px}100%{width:4px}}.participant-container .follow-icon{opacity:0;pointer-events:none;height:20px;position:absolute;bottom:35px;left:25px}.flip-h .follow-icon{float:right}.participant-container:hover .follow-icon,.match-content:focus-visible .follow-icon,.follow-icon:focus-visible{opacity:1;pointer-events:all}.match-content:focus-visible{outline-offset:-1px}._1x_1y.match-data:focus-visible{outline:none}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.pin-to-desk-block{background-color:rgb(255,241,250);background-image:linear-gradient(45deg,rgb(252,151,216) 0,rgb(252,151,216) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgb(252,151,216) 87%,rgb(252,151,216) 100%);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:6px;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:black;width:268px;backdrop-filter:blur(6px);height:54px}.pin-to-desk-block:hover{cursor:pointer}.pin-to-desk-des,.pin-to-desk-button{font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:16px}.pin-to-desk-button{display:flex;height:28px;padding:2px 10px;justify-content:center;align-items:center;border-radius:100px;border:1px solid black}.pin-to-desk-button > img{margin-right:4px}.win-dark{display:none}._1x_1y .pin-to-desk-block{height:var(--match-content-height)}._1x_3y .pin-to-desk-block{height:72px}:host([isMobile=true]) .pin-to-desk-block{width:100%}:host([cardlayout="_1x_1y"]) .pin-to-desk-block{padding:0}:host([isMobile=true]) .pin-to-desk-block{margin:0 auto;margin-bottom:8px}.detailed-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;padding:2px 6px;border-radius:3px;text-transform:uppercase;background:rgba(53,21,105,1)}.final-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);padding:2px 6px;border-radius:3px;background:rgba(53,21,105,0.5)}.expl._1x_2y .match-content,.expl._1x_3y .match-content{box-sizing:border-box;height:66px}.expl._1x_3y{row-gap:6px}.expl._1x_3y .participant-score{margin-top:0px}.expl .match-content{box-sizing:border-box;height:66px;background-color:var(--bg-color)}.expl .match-content:hover{background-color:var(--bg-color-hover)}.expl .cricket-final{background:rgba(26,26,26,0.1)}.expl .cricket-live-tag{background-color:rgb(196,43,28)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(26,26,26,0.1)}`.withBehaviors(new d.t(f,b),new p.N(null,u),(0,g.mr)(h.A` :host{forced-color-adjust:auto}`));var v=i(96950),w=i(69259),k=i(39957),y=i(10500),$=i(36516),F=i(32150);const z=v.qy`
    <img
        src="${()=>(0,F.rA)().StaticsUrl}latest/sports/icons/PinBlack.svg"
        class="win-light"
    >
    <img
        src="${()=>(0,F.rA)().StaticsUrl}latest/sports/icons/PinWhite.svg"
        class="win-dark"
    />
`,_=(e,t,i,r)=>v.qy`
<div class="participant-container${e=>t?"":" flip-h"}" title="${i?.name||""}">
<div class="participant-content" index="-1">
            <div class="winner-tag">    
                ${(0,w.z)(e=>i?.isWinner,v.qy`${v.qy.partial('<svg width="5" height="10" viewBox="0 0 5 10" fill="none"><path d="M5 0 0 5.22 5 10V0Z"/></svg>')}`)}
            </div>
            <div class="participant-info" index="-1">
                <div class="participant-hover">
                    <img class="participant-icon" role="presentation" src="${e=>i.imageUrl}"/>
                </div>
                <div class="participant-name">${i?.name||""}</div>
                ${(e,t)=>((e,t)=>v.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${(i,r)=>r.parent.getFollowIconTitle(e,t)}"
        @click="${(i,r)=>r.parent.handleClickFollowIcon(r.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:o.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||"")}"
        @keyup="${(i,r)=>r&&r.event&&"Enter"===r.event.key?r.parent.handleClickFollowIcon(r.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:o.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||""):null}"
        data-t="${(e,t)=>t.parent.viewModel.followTelemetryTag}"
    >
    <div class="${e=>t?"icon-add":"icon-selected"}"> ${v.qy.partial(t?$.A:y.A)}</div>
    </div>
`)(i||{},1!=t.parent.viewModel.followedMap?.get(i.satoriId))}
            </div>
            ${(0,w.z)((e,t)=>t.parent.shouldRenderResults(r),((e,t,i)=>v.qy`
    <div class="results ${(t,r)=>r.parent.getScoreLineByIndex(e,i,1)?"":"single"}">
        <div class="${(t,r)=>r.parent.getScoreClassName(e,i)}">
            <span class="score-line1">${(t,r)=>r.parent.getScoreLineByIndex(e,i,0)}</span>
            ${(0,w.z)((t,r)=>r.parent.isScoreMultiLine(e,i),v.qy`
                        <span>${(t,r)=>r.parent.getScoreLineByIndex(e,i,1)}</span>`)}
        </div>
    </div>
`)(e,0,i))}
        </div>
    </div>
`,M=v.qy`
    <div class="cricket-live-detail">
        ${(0,w.z)(e=>e.detailedGameState!=o.Xp.nonlive,v.qy`
            <div class="cricket-live-tag">
                <span class="live-text">${(e,t)=>t.parent.getLiveText(e.detailedGameState)}</span>
            </div>
        `)}
    </div>
`,S=v.qy`
    <div class="game-detail pre-game">
        <div class="game-date">
            ${e=>e.gameDate}
        </div>
        <div class="game-time">
            ${(e,t)=>t.parent.getGameTime(e)}
        </div>
    </div>
`,C=v.qy`
    <div class="game-detail post-game">
        <div class="game-state cricket-final">
            ${(e,t)=>t.parent.viewModel.strings?.sportsVS||"VS"}
        </div>
    </div>
`,T=v.qy`
 <div class="middle-detail">
     ${(e,t)=>{switch(t.parent.getMiddleTemplate(e.detailedGameState)){case"pre":return S;case"post":return C;case"live":return M;default:return""}}}
 </div>
`,D=(v.qy`
<div class="detailed-game-state">
    ${e=>e.detailedGameState}
</div>
`,v.qy`
<div class="detailed-game-state">
    ${e=>o.Xp.postponed}
</div>
`,v.qy`
    <div class="match-detail ${(e,t)=>t.parent.getMiddleTemplateClass(e.detailedGameState)}">
        ${T}
    </div>
`),P=v.qy`  
    <a class="match-content"
        tabindex="0"
        href="${e=>e.matchClickthroughUrl?e.matchClickthroughUrl:void 0}"
        target="${(e,t)=>t.parent.viewModel.linkTarget}"
        data-t="${(e,t)=>t.parent.viewModel.telemetryTag}"
    >
        ${(e,t)=>_(e.gameId||"",!0,t.parent.getParticipant(!0,e)||{},e.detailedGameState)}
        ${D}
        ${(e,t)=>_(e.gameId||"",!1,t.parent.getParticipant(!1,e)||{},e.detailedGameState)}
        <div class="match-footer">${(e,t)=>{return i=t.parent.viewModel.matchSummaryMap.get(e.gameId),v.qy`
    <div>
        <div class="match-extended-details" title="${i||""}">
            ${i||""}
        </div>
    </div>
`;var i}}</div>
    </a>
`,I=v.qy`
    <a class="pin-to-desk-block"
        tabindex="0"
        role="button"
        @click="${e=>e.viewModel.pinToDeskClick&&e.viewModel.pinToDeskClick()}"
        data-t="${e=>e.viewModel.pinToDeskButtonTelemetryTag}"
    >
        <div class="pin-to-desk-des">
            ${e=>e.viewModel.strings.pinToDeskDesc||"Follow the latest games on desktop"}
        </div>
        <div class="pin-to-desk-button">
            ${z}${e=>e.viewModel.strings.pinToDeskButton||"Pin live score"}
        </div>
    </a>
`,j=v.qy`
    ${(0,w.z)(e=>e.viewModel.matchData.length>0,v.qy`
        <div class="match-data ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isIPL?"ipl":""} ${e=>e.viewModel.isExploration?"expl":""}">
            ${(0,k.ux)(e=>e.viewModel.matchData.slice(0,e.viewModel.shouldShowPinToDesk?e.viewModel.showMatchCount-1:e.viewModel.showMatchCount),P,{positioning:!0})}
            ${(0,w.z)(e=>e.viewModel.shouldShowPinToDesk,I)}
        </div>`)}
`,H=v.qy`
    ${(0,w.z)(e=>null!=e.viewModel,j)}
`;let E=class extends l{};E=(0,r.Cg)([(0,c.E)({name:"sports-cricket",template:H,styles:m,shadowOptions:{delegatesFocus:!0}})],E)},65201(e,t,i){i.r(t),i.d(t,{SportsExplorationHead(){return D}});var r,o=i(56911),a=i(50180),n=i(60815),s=i(71372),l=i(95144);!function(e){e[e.Initial=0]="Initial",e[e.Followed=1]="Followed",e[e.Disliked=2]="Disliked"}(r||(r={}));let c=class extends s.a{constructor(){super(...arguments),this.followState=r.Initial}onFollowClick(e){this.viewModel.followLeagueClickHandler(e),this.followState=r.Followed}onDislikeClick(){this.viewModel.dislikeLeagueClickHandler(),this.viewModel.shouldShowDislikeMessage&&(this.followState=r.Disliked)}connected(){super.connected(),this.viewModel.isFollowed?this.followState=r.Followed:this.viewModel.isDisliked&&this.viewModel.shouldShowDislikeMessage&&(this.followState=r.Disliked)}getFollowElements(e,t,i){switch(this.followState){case r.Initial:return e;case r.Followed:return t;case r.Disliked:return i}}get youDislikedInnerHtml(){return(0,a.GP)(this.viewModel.strings.youDisliked,`<span class="league-name">${this.viewModel.leagueName}</span>`)}get youFollowedInnerHtml(){return(0,a.GP)(this.viewModel.strings.youFollowed,`<span class="league-name">${this.viewModel.leagueName}</span>`)}};(0,o.Cg)([n.sH],c.prototype,"followState",void 0),c=(0,o.Cg)([l.x],c);var d=i(92011),p=i(48751),h=i(37302),g=i(86856),x=i(70289),u=i(63033),f=i(74849);const b=f.A` :host{--sec-text-color:rgba(255,255,255,0.78);--dislike-bg-color:#292929;--dislike-border-color:#757575;--dislike-color:#FFFFFF;--dislike-bg-hover:#3D3D3D;--dislike-border-color-hover:rgba(255,255,255,0.06);--result-bg-color:#FFFFFF;--result-color:#2b2b2b}`,m=f.A`
`,v=f.A` :host{--sec-text-color:rgba(0,0,0,0.6);--follow-color:#FFFFFF;--follow-bg-color:#036AC4;--follow-bg-color-hover:#0473CE;--dislike-bg-color:rgba(255,255,255,0.46);--dislike-border-color:#D6D6D6;--dislike-border-color-hover:rgba(0,0,0,0.06);--result-bg-color:#292929;--result-color:#FFFFFF;--logo-wrap-border-color:#D6D6D6;--dislike-color:${p.l};--dislike-bg-hover:${h.Xt}}.reason-wrap{display:grid;grid-template-columns:50px 1fr;gap:6px;align-items:center;${x.f};pointer-events:none}.logo-wrap{margin:3px;border-radius:4px;display:flex;align-items:center;justify-content:center;width:44px;height:44px;box-sizing:border-box;border:1px solid var(--logo-wrap-border-color)}.logo{width:32px;height:32px}.reason-text,.sec-text{${x.f};pointer-events:none;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.reason-text{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;padding:3px 0px;color:${p.l}}.sec-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--sec-text-color);height:32px}.follow-wrap{display:flex;justify-content:space-between;margin-top:8px}.follow-btn,.dislike-btn{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:132px;border-radius:4px;height:22px;box-sizing:border-box;${x.f}}.btn-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;max-width:110px;padding:2px 0px 4px}.league-name{font-weight:600}.follow-btn{background-color:var(--follow-bg-color);color:var(--follow-color);border:0px;border:1px solid rgba(0,0,0,0)}.follow-btn:hover{background-color:var(--follow-bg-color-hover)}.plus{width:9px;height:9px}.dislike-btn{background-color:var(--dislike-bg-color);border:1px solid var(--dislike-border-color);color:var(--dislike-color)}.dislike-btn:hover{border-color:var(--dislike-border-color-hover) var(--dislike-border-color-hover) rgba(0,0,0,0.16) var(--dislike-border-color-hover);background-color:var(--dislike-bg-hover)}.disliked,.followed{background-color:var(--result-bg-color);color:var(--result-color);border-radius:4px;padding:3px 10px;width:268px;box-sizing:border-box;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${x.f};pointer-events:none}._1x_1y .reason-wrap{grid-template-columns:40px 1fr;height:40px}._1x_1y .logo{width:27px;height:27px}._1x_1y .logo-wrap{width:35px;height:35px}._1x_1y .reason-text{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px;color:${p.l}}._1x_1y .follow-wrap{margin-top:4px}`.withBehaviors(new g.t(null,m),new u.N(null,b));var w=i(96950),k=i(69259),y=i(32150);const $=w.qy`
    <div class="reason-wrap">
        <div class="logo-wrap" style="background-color: #${e=>e.viewModel.logoPrimaryColor}">
            <img src="${e=>e.viewModel.logoUrl}" class="logo">
        </div>
        <div class="reason-text">${e=>e.viewModel.reasonText}</div>
    </div>
`,F=w.qy`
    ${(0,k.z)(e=>e.viewModel.shouldShowSecondaryText,w.qy`
        <div class="sec-text">
            ${e=>e.viewModel.secondaryText}
        </div>
    `)}
`,z=w.qy`
    <fluent-button
        class="follow-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.follow}"
        aria-label="${e=>e.viewModel.strings.follow}"
        role="button"
        data-t="${e=>e.viewModel.followTelemetryTag}"
        @click="${e=>e.onFollowClick(!0)}"
    >
        <div class="btn-content">
            <img src="${(0,y.rA)().StaticsUrl}latest/shopping/plusw.svg" class="plus">
            ${e=>e.viewModel.strings.follow}
        </div>
    </fluent-button>
    <fluent-button
        class="dislike-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.notInterested}"
        aria-label="${e=>e.viewModel.strings.notInterested}"
        role="button"
        data-t="${e=>e.viewModel.dislikeTelemetryTag}"
        @click="${e=>e.onDislikeClick()}"
    >
        <div class="btn-content">
            ${e=>e.viewModel.strings.notInterested}
        </div>
    </fluent-button>
`,_=w.qy`
    ${e=>w.qy`
        <div class="followed">${w.qy.partial(e.youFollowedInnerHtml)}</div>
    `}
`,M=w.qy`
    ${e=>w.qy`
        <div class="disliked">${w.qy.partial(e.youDislikedInnerHtml)}</div>
    `}
`,S=w.qy`
    <div class="follow-wrap">
        ${e=>e.getFollowElements(z,_,M)}
    </div>
`,C=w.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${$}
        ${F}
        ${S}
    </div>
`,T=w.qy`
    ${(0,k.z)(e=>void 0!==e.viewModel,C)}
`;let D=class extends c{};D=(0,o.Cg)([(0,d.E)({name:"sports-exploration-head",template:T,styles:v,shadowOptions:{delegatesFocus:!0}})],D)},99657(e,t,i){i.d(t,{D(){return n},I(){return a}});var r=i(68136);const{create:o}=r.G,a=o("sloppy-click-z-index",1),n=o("click-z-index",1)},38817(e,t,i){i.d(t,{R7(){return u},e(){return g},kc(){return x},nH(){return h}});var r=i(57416),o=i(55153),a=i(95239),n=i(26920),s=i(48751),l=i(64187),c=i(22131),d=i(74849),p=i(50882);const h=d.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,g=d.A` ${(0,l.V)("flex")} :host{background:${a.p};outline:calc(${n.XA} * 1px) solid ${o.cu};border-radius:calc((${r.JU} - ${n.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${s.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${n.XA} * 1px) ${o.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${n.XA} * 1px) ${o.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${n.XA} * 1px) ${o.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${o.QG} * 1px);height:calc(${o.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${o.QG} * 1px);height:calc((${o.l8} * 2px) + (${o.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${o.QG} * 2px) + (${o.Sn} * 1px));height:calc((${o.l8} * 2px) + (${o.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${o.QG} * 2px) + (${o.Sn} * 1px));height:calc(${o.l8} * 1px)}::slotted(*){color:inherit}`,x=(0,c.mr)(d.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),u=d.A` ${g} ${h} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(x)},70289(e,t,i){i.d(t,{f(){return l}});var r=i(64187),o=i(74849),a=i(38817),n=i(99657),s=i(36452);const l=o.A.partial`position: relative; z-index: ${n.D};`;o.A` ${a.e} ${a.nH} ${(0,r.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${s.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${s.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${s.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(a.kc)}}]);