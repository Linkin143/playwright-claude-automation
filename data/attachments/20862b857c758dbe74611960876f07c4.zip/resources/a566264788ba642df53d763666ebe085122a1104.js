"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-match-confetti"],{87517(s,i,a){a.r(i),a.d(i,{SportsMatchConfetti:()=>x});var t=a(56911),e=a(92011),r=a(59669),d=a(63033);let o=(0,r.A)` :host{}`,p=(0,r.A)` :host{display:block;overflow:visible;position:absolute}.confetti{--burst-x:2px;--burst-y:10px}.confetti .particle{transform:translate(var(--burst-x),var(--burst-y)) rotate(var(--r0)) scale(var(--s));opacity:0;animation-timing-function:cubic-bezier(.16,.84,.36,1);animation-fill-mode:forwards;animation-iteration-count:1;animation-name:confetti-burst;position:absolute;left:0;top:0;background:currentColor;will-change:transform,opacity;pointer-events:none}.confetti .burst-a{animation-delay:0ms}.confetti .burst-b{animation-delay:180ms}.confetti .shape-rect{width:6px;height:2px;border-radius:1px}.confetti .shape-dot{width:4px;height:4px;border-radius:50%}@keyframes confetti-burst{0%{transform:translate(var(--burst-x),var(--burst-y)) rotate(var(--r0)) scale(var(--s));opacity:1}70%{opacity:1}100%{transform:translate(calc(var(--burst-x) + var(--dx)),calc(var(--burst-y) + var(--dy))) rotate(calc(var(--r0) + var(--spin))) scale(var(--s));opacity:0}}`.withBehaviors(new d.N(null,o));var n=a(89757);let l=(0,n.qy)`
    <div id="confetti" class="confetti" aria-hidden="true">
        <!-- First burst: 28 particles, snappy default -->
        <i class="particle shape-rect burst-a" style="color:#FF3D8A;--dx:-84.90px;--dy:148.81px;--r0:0.0deg;--spin:-540.0deg;--s:1.000;animation-duration:706ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF7A1A;--dx:-143.88px;--dy:111.25px;--r0:137.0deg;--spin:226.8deg;--s:1.162;animation-duration:955ms"></i>
        <i class="particle shape-dot burst-a" style="color:#A8E63A;--dx:-181.29px;--dy:107.90px;--r0:274.0deg;--spin:-86.4deg;--s:1.325;animation-duration:734ms"></i>
        <i class="particle shape-rect burst-a" style="color:#22C7FF;--dx:-127.12px;--dy:37.17px;--r0:51.0deg;--spin:-399.6deg;--s:1.487;animation-duration:984ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF3D8A;--dx:-157.90px;--dy:16.19px;--r0:188.0deg;--spin:367.2deg;--s:1.137;animation-duration:762ms"></i>
        <i class="particle shape-dot burst-a" style="color:#FF7A1A;--dx:-106.53px;--dy:26.93px;--r0:325.0deg;--spin:54.0deg;--s:1.300;animation-duration:1012ms"></i>
        <i class="particle shape-rect burst-a" style="color:#A8E63A;--dx:-95.83px;--dy:-43.95px;--r0:102.0deg;--spin:-259.2deg;--s:1.462;animation-duration:791ms"></i>
        <i class="particle shape-rect burst-a" style="color:#22C7FF;--dx:-108.19px;--dy:-79.51px;--r0:239.0deg;--spin:507.6deg;--s:1.113;animation-duration:1040ms"></i>
        <i class="particle shape-dot burst-a" style="color:#FF3D8A;--dx:-19.40px;--dy:-60.62px;--r0:16.0deg;--spin:194.4deg;--s:1.275;animation-duration:819ms"></i>
        <i class="particle shape-dot burst-a" style="color:#FF7A1A;--dx:-12.92px;--dy:-97.39px;--r0:153.0deg;--spin:-118.8deg;--s:1.438;animation-duration:1068ms"></i>
        <i class="particle shape-rect burst-a" style="color:#A8E63A;--dx:-0.91px;--dy:-46.25px;--r0:290.0deg;--spin:-432.0deg;--s:1.087;animation-duration:847ms"></i>
        <i class="particle shape-rect burst-a" style="color:#22C7FF;--dx:69.93px;--dy:-65.70px;--r0:67.0deg;--spin:334.8deg;--s:1.250;animation-duration:1096ms"></i>
        <i class="particle shape-dot burst-a" style="color:#FF3D8A;--dx:97.33px;--dy:-91.66px;--r0:204.0deg;--spin:21.6deg;--s:1.412;animation-duration:875ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF7A1A;--dx:118.76px;--dy:-1.70px;--r0:341.0deg;--spin:-291.6deg;--s:1.062;animation-duration:1125ms"></i>
        <i class="particle shape-rect burst-a" style="color:#A8E63A;--dx:155.03px;--dy:-10.93px;--r0:118.0deg;--spin:475.2deg;--s:1.225;animation-duration:904ms"></i>
        <i class="particle shape-dot burst-a" style="color:#22C7FF;--dx:113.72px;--dy:21.62px;--r0:255.0deg;--spin:162.0deg;--s:1.388;animation-duration:1153ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF3D8A;--dx:161.43px;--dy:79.83px;--r0:32.0deg;--spin:-151.2deg;--s:1.037;animation-duration:932ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF7A1A;--dx:196.44px;--dy:94.16px;--r0:169.0deg;--spin:-464.4deg;--s:1.200;animation-duration:711ms"></i>
        <i class="particle shape-dot burst-a" style="color:#A8E63A;--dx:123.02px;--dy:153.16px;--r0:306.0deg;--spin:302.4deg;--s:1.363;animation-duration:960ms"></i>
        <i class="particle shape-dot burst-a" style="color:#22C7FF;--dx:146.40px;--dy:182.49px;--r0:83.0deg;--spin:-10.8deg;--s:1.012;animation-duration:739ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF3D8A;--dx:99.38px;--dy:158.81px;--r0:220.0deg;--spin:-324.0deg;--s:1.175;animation-duration:988ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF7A1A;--dx:64.81px;--dy:227.69px;--r0:357.0deg;--spin:442.8deg;--s:1.338;animation-duration:767ms"></i>
        <i class="particle shape-dot burst-a" style="color:#A8E63A;--dx:37.47px;--dy:182.93px;--r0:134.0deg;--spin:129.6deg;--s:1.500;animation-duration:1016ms"></i>
        <i class="particle shape-rect burst-a" style="color:#22C7FF;--dx:39.58px;--dy:219.81px;--r0:271.0deg;--spin:-183.6deg;--s:1.150;animation-duration:795ms"></i>
        <i class="particle shape-rect burst-a" style="color:#FF3D8A;--dx:-37.31px;--dy:257.22px;--r0:48.0deg;--spin:-496.8deg;--s:1.312;animation-duration:1045ms"></i>
        <i class="particle shape-dot burst-a" style="color:#FF7A1A;--dx:-35.75px;--dy:204.53px;--r0:185.0deg;--spin:270.0deg;--s:1.475;animation-duration:824ms"></i>
        <i class="particle shape-rect burst-a" style="color:#A8E63A;--dx:-114.55px;--dy:200.95px;--r0:322.0deg;--spin:-43.2deg;--s:1.125;animation-duration:1073ms"></i>
        <i class="particle shape-rect burst-a" style="color:#22C7FF;--dx:-85.54px;--dy:157.19px;--r0:99.0deg;--spin:-356.4deg;--s:1.288;animation-duration:852ms"></i>

        <!-- Second burst: 28 particles, slower + more upward, longer hang -->
        <i class="particle shape-rect burst-b" style="color:#22C7FF;--dx:-28.49px;--dy:157.73px;--r0:29.0deg;--spin:-226.8deg;--s:0.938;animation-duration:1020ms"></i>
        <i class="particle shape-rect burst-b" style="color:#A8E63A;--dx:-84.86px;--dy:157.36px;--r0:166.0deg;--spin:-540.0deg;--s:1.141;animation-duration:1269ms"></i>
        <i class="particle shape-dot burst-b" style="color:#FF7A1A;--dx:-113.66px;--dy:171.34px;--r0:303.0deg;--spin:226.8deg;--s:1.344;animation-duration:1048ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF3D8A;--dx:-101.89px;--dy:99.33px;--r0:80.0deg;--spin:-86.4deg;--s:1.547;animation-duration:1297ms"></i>
        <i class="particle shape-rect burst-b" style="color:#22C7FF;--dx:-133.61px;--dy:97.53px;--r0:217.0deg;--spin:-399.6deg;--s:1.109;animation-duration:1076ms"></i>
        <i class="particle shape-dot burst-b" style="color:#A8E63A;--dx:-90.80px;--dy:84.09px;--r0:354.0deg;--spin:367.2deg;--s:1.312;animation-duration:1325ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF7A1A;--dx:-113.79px;--dy:31.00px;--r0:131.0deg;--spin:54.0deg;--s:1.516;animation-duration:1104ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF3D8A;--dx:-138.44px;--dy:10.45px;--r0:268.0deg;--spin:-259.2deg;--s:1.078;animation-duration:1354ms"></i>
        <i class="particle shape-dot burst-b" style="color:#22C7FF;--dx:-67.01px;--dy:-10.33px;--r0:45.0deg;--spin:507.6deg;--s:1.281;animation-duration:1133ms"></i>
        <i class="particle shape-dot burst-b" style="color:#A8E63A;--dx:-78.44px;--dy:-40.05px;--r0:182.0deg;--spin:194.4deg;--s:1.484;animation-duration:1382ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF7A1A;--dx:-48.11px;--dy:-6.91px;--r0:319.0deg;--spin:-118.8deg;--s:1.047;animation-duration:1161ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF3D8A;--dx:-7.83px;--dy:-50.51px;--r0:96.0deg;--spin:-432.0deg;--s:1.250;animation-duration:1410ms"></i>
        <i class="particle shape-dot burst-b" style="color:#22C7FF;--dx:0.78px;--dy:-81.50px;--r0:233.0deg;--spin:334.8deg;--s:1.453;animation-duration:1189ms"></i>
        <i class="particle shape-rect burst-b" style="color:#A8E63A;--dx:51.21px;--dy:-24.89px;--r0:10.0deg;--spin:21.6deg;--s:1.016;animation-duration:1438ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF7A1A;--dx:73.65px;--dy:-47.57px;--r0:147.0deg;--spin:-291.6deg;--s:1.219;animation-duration:1217ms"></i>
        <i class="particle shape-dot burst-b" style="color:#FF3D8A;--dx:56.44px;--dy:-6.03px;--r0:284.0deg;--spin:475.2deg;--s:1.422;animation-duration:1467ms"></i>
        <i class="particle shape-rect burst-b" style="color:#22C7FF;--dx:114.04px;--dy:13.63px;--r0:61.0deg;--spin:162.0deg;--s:0.984;animation-duration:1245ms"></i>
        <i class="particle shape-rect burst-b" style="color:#A8E63A;--dx:145.90px;--dy:8.73px;--r0:198.0deg;--spin:-151.2deg;--s:1.188;animation-duration:1024ms"></i>
        <i class="particle shape-dot burst-b" style="color:#FF7A1A;--dx:115.90px;--dy:79.92px;--r0:335.0deg;--spin:-464.4deg;--s:1.391;animation-duration:1274ms"></i>
        <i class="particle shape-dot burst-b" style="color:#FF3D8A;--dx:145.87px;--dy:91.07px;--r0:112.0deg;--spin:302.4deg;--s:0.953;animation-duration:1053ms"></i>
        <i class="particle shape-rect burst-b" style="color:#22C7FF;--dx:100.90px;--dy:93.05px;--r0:249.0deg;--spin:-10.8deg;--s:1.156;animation-duration:1302ms"></i>
        <i class="particle shape-rect burst-b" style="color:#A8E63A;--dx:106.42px;--dy:155.19px;--r0:26.0deg;--spin:-324.0deg;--s:1.359;animation-duration:1081ms"></i>
        <i class="particle shape-dot burst-b" style="color:#FF7A1A;--dx:67.31px;--dy:133.22px;--r0:163.0deg;--spin:442.8deg;--s:1.562;animation-duration:1330ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF3D8A;--dx:85.10px;--dy:159.25px;--r0:300.0deg;--spin:129.6deg;--s:1.125;animation-duration:1109ms"></i>
        <i class="particle shape-rect burst-b" style="color:#22C7FF;--dx:47.58px;--dy:217.78px;--r0:77.0deg;--spin:-183.6deg;--s:1.328;animation-duration:1358ms"></i>
        <i class="particle shape-dot burst-b" style="color:#A8E63A;--dx:26.73px;--dy:177.83px;--r0:214.0deg;--spin:-496.8deg;--s:1.531;animation-duration:1137ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF7A1A;--dx:-29.15px;--dy:208.86px;--r0:351.0deg;--spin:270.0deg;--s:1.094;animation-duration:1387ms"></i>
        <i class="particle shape-rect burst-b" style="color:#FF3D8A;--dx:-25.79px;--dy:164.09px;--r0:128.0deg;--spin:-43.2deg;--s:1.297;animation-duration:1165ms"></i>
    </div>
`;class c extends e.L{}let x=class extends c{};x=(0,t.Cg)([(0,e.E)({name:"sports-match-confetti",template:l,styles:p,shadowOptions:{delegatesFocus:!0}})],x)}}]);