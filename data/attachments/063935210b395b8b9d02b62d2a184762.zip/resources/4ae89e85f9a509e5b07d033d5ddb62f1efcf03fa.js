"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-tournament-status-row"],{91014(e,t,n){n.d(t,{_(){return i}});var a=n(11796);class i extends a.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}async getViewModel(e){const t={...e.telemetryConstants,name:a.BP.SportsTournamentStatusRow};return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,t),...e}}}},57386(e,t,n){n.r(t),n.d(t,{SportsTournamentStatusRowTransformer(){return a._}});var a=n(91014);Promise.resolve().then(n.bind(n,99674))},71372(e,t,n){n.d(t,{a(){return o}});var a=n(56911),i=n(92011),r=n(95144);let o=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([r.x],o)},99674(e,t,n){n.r(t),n.d(t,{TournamentStatusRow(){return $}});var a=n(56911),i=n(92011),r=n(48751);const o="\n    font-size: var(--type-ramp-minus-1-font-size, 12px);\n    font-weight: 600;\n    line-height: var(--type-ramp-minus-1-line-height, 16px);\n",s="\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n",d=n(74849).A`
.tournament-container{display:flex;flex-direction:column;gap:2px;padding:5px 8px;border-radius:8px;background:var(--sports-item-background);position:relative;max-width:252px;text-decoration:none;color:${r.l};z-index:1}.tournament-container:hover{background:var(--sports-item-hover-background)}.winner-image-container{height:16px;width:16px;display:flex;justify-content:center;align-items:flex-end}.live-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.pregame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.postgame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.inprogress-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.tournament-location{${s} font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px);max-width:260px;height:100%}.tournament-title-container{display:flex;flex-direction:row;height:100%;align-items:flex-start;gap:6px;align-self:stretch}.tournament-details-container{display:flex;flex-direction:column;height:100%;gap:2px}.tournament-image{height:20px;width:20px}.tournament-title{font-size:var(--type-ramp-base-font-size,14px);font-weight:${"600"};line-height:var(--type-ramp-base-line-height,20px);${s} max-width:260px;height:100%}.winner-details-container{display:flex;justify-content:space-between;align-items:center}.winner-name-container{display:flex;flex-direction:row;align-items:center}.winner-score{${o} ${s} max-width:19px}.winner-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;margin-right:2px}.winner-name{${o} ${s} max-width:128px}.winner-image{height:12px;width:12px}`;var l=n(96950),m=n(69259);Object.freeze({unknown:"unknown",preGame:"pre-game",inprogressGame:"inprogress-game",postGame:"post-game",tba:"tba"});const c=Object.freeze({unknown:"Unknown",preGame:"PreGame",inProgress:"InProgress",inProgressBreak:"InProgressBreak",postponed:"Postponed",suspended:"Suspended",cancelled:"Cancelled",forfeited:"Forfeited",delayed:"Delayed",final:"Final",bye:"Bye",abandoned:"Abandoned",live:"Live"});Object.freeze({Unknown:"Unknown",Invalid:"Invalid",PreGame:"PreGame",AboutToStart:"AboutToStart",ParticipantsAreNotKnownYet:"ParticipantsAreNotKnownYet",InProgress:"InProgress",InProgressBreak:"InProgressBreak",Postponed:"Postponed",Suspended:"Suspended",Cancelled:"Cancelled",Unscheduled:"Unscheduled",ForfeitedByBothTeams:"ForfeitedByBothTeams",ForfeitedByAwayTeam:"ForfeitedByAwayTeam",ForfeitedByHomeTeam:"ForfeitedByHomeTeam",ForfeitedByAwayTeamVacatedByHome:"ForfeitedByAwayTeamVacatedByHome",ForfeitedByHomeTeamVacatedByAway:"ForfeitedByHomeTeamVacatedByAway",VacatedByBothTeams:"VacatedByBothTeams",VacatedByAwayTeam:"VacatedByAwayTeam",VacatedByHomeTeam:"VacatedByHomeTeam",Delayed:"Delayed",StartDelayed:"StartDelayed",Final:"Final",Bye:"Bye",Retired:"Retired",Abandoned:"Abandoned",Unnecessary:"Unnecessary",Tea:"Tea",Lunch:"Lunch",InningsBreak:"InningsBreak",Stumps:"Stumps",RainDelay:"RainDelay",BadLight:"BadLight",CrowdTrouble:"CrowdTrouble",PitchCondition:"PitchCondition",FloodlightFailure:"FloodlightFailure",Drinks:"Drinks",SuperOver:"SuperOver",BadGroundCondition:"BadGroundCondition",BadWeatherCondition:"BadWeatherCondition",Dinner:"Dinner",Fog:"Fog",PlayHalted:"PlayHalted",StrategicTimeout:"StrategicTimeout",SuperOverInProgress:"SuperOverInProgress",WetGroundCondition:"WetGroundCondition",WetPitchCondition:"WetPitchCondition",DayWashedOut:"DayWashedOut",Toss:"Toss",MatchAbandonedWithoutToss:"MatchAbandonedWithoutToss",MatchAbandonedWithoutSingleBallBeingBowled:"MatchAbandonedWithoutSingleBallBeingBowled",MatchConceded:"MatchConceded",MatchAwarded:"MatchAwarded",Maintenance:"Maintenance"}),Object.freeze({full:"full",extendedBoxscore:"extended_boxscore",boxscore:"boxscore"}),Object.freeze({Unknown:"Unknown",PreGame:"PreGame",LiveGame:"LiveGame",PostGame:"PostGame"});const p=l.qy`
    <div class="live-tournament-status-title">
            ${e=>`${e.viewModel?.strings?.sportsLive} • ${e.viewModel?.gameState?.name}`}
    </div>
`,u=l.qy`
    <div class="pregame-tournament-status-title">
            ${e=>e.viewModel?.gameScheduleString}
    </div>
`,h=l.qy`
    <div class="postgame-tournament-status-title">
            ${e=>`${e.viewModel?.gameScheduleString} • ${e.viewModel?.strings?.sportsStateFinal}`}
    </div>
`,g=l.qy`
    <div class="inprogress-tournament-status-title">
            ${e=>e.viewModel?.strings?.inProgress}
    </div>
`,y=l.qy`
    <div class="winner-details-container">
        <div class="winner-name-container">
            <span class="winner-text">${e=>e.viewModel?.strings?.winner}</span>
            <div class="winner-image-container">
                <img class="winner-image" src=${e=>e.viewModel?.winnerDetails?.imageUrl} alt=${e=>e.viewModel?.winnerDetails?.name}></img>
            </div>
            <span class="winner-name">${e=>e.viewModel?.winnerDetails?.name}</span>
        </div>
        <div class="winner-score">
            ${e=>e.viewModel?.winnerDetails?.score}
        </div>
    </div>
`,w=l.qy`
    <div class="tournament-location">
        ${e=>e.viewModel?.locationName}
    </div>
`,x=l.qy`
    <div class="tournament-details-container">
        <div class="tournament-title-container">
            <img class="tournament-image" src=${e=>e.viewModel?.imageUrl} alt=${e=>e.viewModel?.name}></img>
            <span class="tournament-title" title=${e=>e.viewModel?.name}>
                ${e=>e.viewModel?.name}
            </span>
        </div>
        ${(0,m.z)(e=>e.viewModel?.gameState?.state!==c.final,w)}
        ${(0,m.z)(e=>e.viewModel?.gameState?.state===c.final&&e.viewModel?.winnerDetails,y)}
    </div>
`,v=l.qy`
<a
    class="tournament-container"
    href="${e=>e.viewModel.gameCenterUrl}"
    target="_blank"
    data-t="${e=>e.viewModel.telemetryTag}"
    tabindex="0"
    >
    ${e=>(e=>{switch(e){case c.live:return p;case c.preGame:return u;case c.final:return h;case c.inProgress:return g;default:return u}})(e.viewModel?.gameState?.state||"")}
    ${x}
</a>
`,f=l.qy`
    ${(0,m.z)(e=>null!=e.viewModel,v)}
`;var B=n(71372);class b extends B.a{}let $=class extends b{};$=(0,a.Cg)([(0,i.E)({name:"tournament-status-row",template:f,styles:d})],$)}}]);