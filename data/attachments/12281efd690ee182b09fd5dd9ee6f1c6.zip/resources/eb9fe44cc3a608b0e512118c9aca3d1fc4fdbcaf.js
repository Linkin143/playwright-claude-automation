"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-cricket"],{79811(e,t,i){i.d(t,{AL:()=>ea,B5:()=>eo,CP:()=>W,EZ:()=>et,F_:()=>N,HX:()=>T,Hn:()=>q,Hv:()=>E,IR:()=>X,K4:()=>Y,Ot:()=>ee,PH:()=>el,UU:()=>w,VY:()=>U,Yf:()=>k,Yo:()=>K,ZL:()=>x,Zi:()=>b,_K:()=>F,_S:()=>eg,bm:()=>R,bw:()=>A,d:()=>ec,d$:()=>M,gK:()=>eh,gS:()=>ei,iK:()=>Q,ij:()=>em,jJ:()=>J,ju:()=>O,lb:()=>H,m5:()=>en,nD:()=>ep,oT:()=>D,or:()=>G,p6:()=>z,qM:()=>_,ry:()=>er,s$:()=>Z,sP:()=>L,v4:()=>B,wB:()=>P,ww:()=>V,yn:()=>es,z2:()=>I,zy:()=>ed});var a=i(23305),r=i(54694),s=i(33335),n=i(87906),o=i(24656),l=i(33744),p=i(25066),d=i(58319),c=i(53128),g=i(18633),h=i(67072),m=i(70535),u=i(50180),v=i(9960),S=i(72627),y=i(83991),f=i(10279);let w="OSC.LBUDD745586EC750353FBC1F3971212F2F92540502D2A29306D4081FAD3D5858B79B",b="#A71930",x="#036779",M="#B10E1C",T="#DC626D",k=e=>e?$(e):"",$=e=>(e&&(C(e)?e+="&h=50&w=50&m=6&q=100&u=t&o=t&l=f&f=png":e.indexOf("//www.bing.com/th?")>=0&&e.indexOf("&w=")>0&&(e=e.split("&w=")[0]+"&w=100&h=100&qlt=100&c=0&rs=1")),e),C=e=>["//img-s-msn-com.akamaized.net/tenant/amp/entityid","//img-s.msn.cn/tenant/amp/entityid"].some(t=>e.indexOf(t)>=0);function I(e){return null!=e}let D=e=>!e||!e.trim(),E=e=>F(e,80,80,!0),F=(e="",t=40,i=40,a=!1)=>e?e.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${a?i+20:i}&h=${a?t+20:t}`):null,P=e=>e.get(a.kA.sportsData),_=e=>{let t=A(e);return g.aC.safeExecute(()=>t.tabContent?.league?.sportsMatches?.map(e=>({sportsMatchData:e}))||[],void 0,s.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(t.tabContent?.league?.sportsMatches)}; tabType=${t.tabType};`)},O=e=>{let t=A(e);return t.tabContent?.freTeams?.map(e=>({...e,id:e.id||e.satoriId}))},R=e=>A(e).reason||"-1",z=e=>{let t=A(e);return t.tabContent?.sportsSpotLightData},B=e=>e.get(a.kA.pollOptionIds),A=e=>{let t=P(e),i=L(e)-1;return t.Model?.Tabs[i]},H=e=>e===a.v1.Fre,N=e=>e===a.v1.SpotlightFRE,G=e=>e===a.v1.StandingsRankings,L=e=>e.get(a.kA.tabCurrentPageIndex)||1,V=e=>{let t=A(e);return t?j(t.tabType):a.v1.TeamVsTeam},j=e=>{switch(e){case a.v1.EventBrief:case a.v1.TeamVsTeamWithBracket:case a.v1.SpotlightTennis:case a.v1.SpotlightRace:case a.v1.SpotlightGolf:case a.v1.SpotlightFRE:case a.v1.StandingsRankings:case a.v1.SportsMedal:case a.v1.LeagueEventResultOneVsOne:case a.v1.LeagueEventResultOneVsMany:case a.v1.LeagueEventResultTeamVsTeam:case a.v1.LeagueEvents:case a.v1.TeamStandingWithEvents:case a.v1.TeamStandingWithMedals:case a.v1.SpotlightCricket:case a.v1.TournamentsList:case a.v1.Spotlight2c:return e;case a.v1.SeasonStatistics:case a.v1.Video:case a.v1.Countdown:case a.v1.Spotlight:return a.v1.Spotlight;default:return a.v1.TeamVsTeam}};function q(e){return"boolean"==typeof e?e:!!e&&("1"===e||"true"===e.toLowerCase())}function W(e){switch(e){case h.uE._1x_1y:return"small";case h.uE._1x_3y:return"large";default:return"medium"}}let U=(e,t)=>void 0!==e&&void 0!==t&&(t.get(e)||!1),X=(e,t,i)=>{switch(e){case h.uE._15u:case h.uE._1x_2y:return 3;case h.uE._1x_3y:return t===a.aB.Cricket?4:i;default:return 1}},K=e=>e.some(e=>e&&e.sportsMatchData&&e.sportsMatchData.gameStateCatetory===a.Xp.inprogressGame),Y=(e,t,i,a)=>{let r;return a&&a[i]&&a[i][t.toString()]?(0,u.GP)((r=146,i===h.uE._1x_2y?r=304:i===h.uE._1x_3y&&(r=462),`https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w=300&h=${r}&q=90&m=6&f=jpg&u=t`),a[i][t.toString()]):null},J=()=>l.T3.AppType===y.u.BingHomepage||l.T3.AppType===y.u.WindowsShellV2?f.y.appInDarkMode():o.F_?.get(o.nz.IsDarkMode)??(0,v.ud)(),Z=(e,t,i,r)=>{let s=+e;if(!r||Number.isNaN(s)||s<0)return"";if(1===s)return i===a.XR.League?t.followedReasonLeague:t.followedReasonTeam;let n=a.IG[e];return n&&t[n]||""};function Q(e,t=!1,i){let a={format:r.f5.PNG,enableDpiScaling:!1,crop:0,...i};return D(e)?t?(0,r.XP)("BB1dV8FG",a):null:e.indexOf(".")>0?(0,r.oQ)(`${r.Ro}?id=${e}&pid=MSports`,a):(0,r.XP)(e,a)}function ee(e){if(e?.startsWith("http"))return e;if(!e)return"";let t=(0,p.g2)((0,d.t7)(e));return(0,c.oh)()?function(e){if(!e)return e;try{let t=new URL((0,S.$N)()),i=new URL(e),a=t.searchParams.getAll("item").find(e=>e.startsWith("flights:"));return a&&i.searchParams.append("item",a),i.href}catch{return e}}(t):t}function et(e,t){if(!e||!t)return e;try{let i=new URL(e),a=i.searchParams;return Object.keys(t).forEach(e=>{e&&t[e]&&a.set(e,t[e])}),i.toString()}catch{return e}}function ei(e){return e&&!e.startsWith("#")?`#${e}`:e}function ea(e,t){let i=new m.e;try{return i.localizedMonthDate(e,t)}catch(a){(0,n.vV)(s.Gu,"Sports card localizedMonthDate exception.",`date=${e} market=${t} error=${a&&a.message}`);let i=e.toLocaleDateString("en-us",{month:"short",day:"numeric"});if(i||(i=e.toDateString()),i)return i.replace(/\u200E/g,"").replace(/\u200F/g,"");return i}}function er(e,t){let i=new m.e;try{return i.formatTimeFromDate(e,t)}catch(i){return(0,n.vV)(s.Gu,"Sports card formatTimeFromDate exception.",`date=${e} market=${t} error=${i&&i.message}`),e.toTimeString()}}function es(e){let t=60*new Date().getTimezoneOffset()*1e3;return new Date(new Date(e).valueOf()-t)}function en(e){switch(e){case"PreGame":default:return a.Xp.preGame;case"InProgressGame":case"InProgress":return a.Xp.inprogressGame;case"Final":case"PostGame":return a.Xp.postGame}}function eo(e){return"string"!=typeof e.gameState?en(e.gameState?.state):e.gameStateCatetory}function el(e){if(!e||"string"==typeof e)return"";let{gamePeriod:t,gameClock:i}=e;return t&&i?`${t} ${i}`:t||i||""}function ep(e){return!e||"object"==typeof e&&0===Object.keys(e).length}function ed(e){return e.get(a.kA.cardType)?.toLowerCase().startsWith("sportshero")||!1}function ec(e){return e.get(a.kA.cardType)?.toLowerCase().startsWith("sportsspotlight2")||!1}function eg(e,t){if(e.id&&t&&!e.isStream){let i=new URL(t);i.searchParams.append("videoId",e.id),t=i.toString()}return t}function eh(e,t){return!e.hasExplicitInterest||t?.has(e.satoriId)||t?.has(e.yId)?t?.get(e.satoriId||"")===!0||t?.get(e.yId||"")===!0:(t?.set(e.satoriId,!0),!0)}let em=(e,t=16,i=16)=>{if(!e)return"";try{return(0,r.oQ)(e,{quality:100,width:t,height:i,enableDpiScaling:!1,enableWebpFormat:!0},!0)}catch{return e}}},36516(e,t,i){i.d(t,{A:()=>a});let a='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(e,t,i){i.d(t,{A:()=>a});let a='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},83991(e,t,i){var a,r,s,n;i.d(t,{u:()=>a}),(s=a||(a={})).BingHomepage="bingHomepage",s.ChannelMobile="channelmobile",s.Community="community",s.ContentTools="contentTools",s.EdgeChromium="edgeChromium",s.EdgeMobile="edgeMobile",s.Finance="finance",s.Gaming="gaming",s.CGHomePage="cgHomePage",s.HomePage="homePage",s.Hub="hub",s.KnowledgeAgents="knowledgeAgents",s.Office="office",s.Personalize="personalize",s.msn="msn",s.MSNStudio="msnStudio",s.SharedWidgets="sharedWidgets",s.SuperApp="superApp",s.Shopping="shopping",s.Sports="sports",s.Distribution="distribution",s.UGC="ugc",s.Views="views",s.Weather="weather",s.WeatherWidgets="weatherWidgets",s.WeatherLocal="weatherLocal",s.WindowsNewsPlus="windowsNewsPlus",s.WindowsNewsWidgets="winWidgets",s.WindowsShell="windowsShell",s.WindowsShellV2="windowsShellV2",s.WebWidgets="webWidgets",(n=r||(r={})).Default="Default",n.WinDashboard="WinDashboard",n.Edge="Edge"},83546(e,t,i){i.d(t,{h:()=>r});var a=i(53128);function r(){return(0,a.oh)()}},67072(e,t,i){var a,r;i.d(t,{_n:()=>s,GH:()=>l,CE:()=>o,iD:()=>n,uE:()=>a}),(r=a||(a={}))._1x_1y="_1x_1y",r._1x_2y="_1x_2y",r._1x_3y="_1x_3y",r._1x_4y="_1x_4y",r._1x_5y="_1x_5y",r._2x_1y="_2x_1y",r._2x_2y="_2x_2y",r._2x_3y="_2x_3y",r._2x_4y="_2x_4y",r._2x_6y="_2x_6y",r._3x_1y="_3x_1y",r._3x_2y="_3x_2y",r._4x_1y="_4x_1y",r._4x_2y="_4x_2y",r._5x_1y="_5x_1y",r._5x_2y="_5x_2y",r._125u="1.25u",r._15u="1.5u",r._05u="0.5u",r._2c="2c",r.pill="pill";let s={DefaultRecommendation:"default-recommendation",DefaultNotification:"default-notification",ExplorationTab:"exploration-tab",ExplorationReco:"exploration-recommendation"},n={dropdownHistory:"dropdownHistory",dismissHistory:"dismissHistory",suppressHistory:"suppressHistory"};function o(e,t){return 0!==e&&["_1x_3y","_1x_1y"].includes(t)&&304===e}class l{constructor(e){this.transformerProvider=e}}},18633(e,t,i){i.d(t,{Ai:()=>c,dI:()=>h,j8:()=>u,ao:()=>v,iJ:()=>S,LE:()=>m,Eh:()=>g,x1:()=>l,YJ:()=>o,h9:()=>y,aC:()=>r});var a,r,s=i(98378),n=i(12360);let o={Customize:s.MS.Customize,Paginate:s.MS.Paginate,Hide:s.MS.Hide,Cancel:s.MS.Cancel,Close:s.MS.Close,Dislike:s.MS.Dislike,Show:s.MS.Show,Click:s.MS.Click};class l{createTelemetryObjectTag(e){return e?e.getMetadataTag():""}createTelemetryObject(e,t,i,a){if(!e||!t)return;let{name:r,content:o,...l}=t,p={...o,type:o?.type||s.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},d={...this.ext,signature:i};a&&(d.previewType=a);let c={...l,ext:d,zone:this.zone};return(0,n.g)(r,p,c)}createViewTelemetryObject(e,t){return this.createTelemetryObject(e,{name:t.name,action:s.EG.View,behavior:s.MS.Show,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType)}createViewTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,behavior:s.MS.View,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:s.MS.Navigate,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:s.MS.Add,type:s.MJ.ActionButton,content:{headline:t.headline}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,action:s.EG.Hover,behavior:s.MS.Show,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,action:s.EG.MouseLeave,behavior:s.MS.Close,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(e,t){let i=this.createTelemetryObject(e,{name:t.name,behavior:s.MS.Dislike,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(e,t,i){let a=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:i?s.MS.Follow:s.MS.Unfollow,type:s.MJ.ActionButton,content:{headline:t.headline}},t.signature,t.previewType);return this.createTelemetryObjectTag(a)}createMenuDataProviderTelemetryTag(e,t,i){let a=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:s.MS.Undefined,type:s.MJ.ActionButton,content:{headline:t.headline},zone:i},t.signature,t.previewType);return this.createTelemetryObjectTag(a)}createNavClickWithTypeTelemetryTag(e,t,i){let a=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:s.MS.Navigate,type:i,content:{headline:t.headline,id:t.id,brandId:t.brandId,type:t.type||s.b5.StructuredData}},t.signature,t.previewType);return this.createTelemetryObjectTag(a)}createBehaviorTelemetryTag(e,t,i){let a=this.createTelemetryObject(e,{name:t.name,action:s.EG.Click,behavior:i,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);return this.createTelemetryObjectTag(a)}createBaseContentCardTelemetryContext(e,t){let i=this.createTelemetryObject(e,{name:t.name,type:s.MJ.ContentCard,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType),a=this.createTelemetryObject(i,{name:t.name,type:s.MJ.Headline,behavior:s.MS.Navigate,content:{headline:t.headline,id:t.id,brandId:t.brandId}},t.signature,t.previewType);if(i&&a)return{contentCard:i,destination:a}}initTelemetryBuilder(e,t,i,a,r){this.verticalName=e,this.categoryName=t,this.ext=i,this.zone=a,this.subCategoryName=r}updateExt(e){this.ext=e}}var p=i(7446),d=i(20421);function c(e){try{p.YT.sendActionEvent(e,s.EG.MouseLeave,s.MS.Close)}catch(e){return}}function g(e){try{p.YT.sendActionEvent(e,s.EG.Hover,s.MS.Show)}catch(e){return}}function h(e,t){try{p.YT.sendActionEvent(e,s.EG.Click,s.MS.Navigate,t)}catch(e){return}}function m(e,t,i){try{p.YT.sendActionEvent(e,t?s.EG.KeyPress:s.EG.Click,i?s.MS.Follow:s.MS.Unfollow)}catch(e){return}}function u(e){try{if(!e)throw Error("Current target is undefined, cannot send content view telemetry.");p.YT.sendContentViewEvent(e,d.ym.View)}catch(e){return}}function v(e,t){let i=t?`${t}`:"";p.YT.addOrUpdateTmplProperty(e,i)}function S(e){p.YT.removeTmplProperty(e)}function y(e){for(let t of e)S(t)}var f=i(87906);(a=r||(r={})).safeExecute=function(e,t,i,a,r,s={}){try{return e()}catch(e){return i&&(0,f.vV)(i,`${a}: ${e?.message}`,r,s),t}},a.safeExecuteAsync=async function(e,t,i,a,r,s={}){try{return await e()}catch(e){return i&&(0,f.vV)(i,`${a}: ${e?.message}`,r,s),Promise.resolve(t)}},a.logExceptionWithFormat=function(e,t,i,a,r,s={}){(0,f.c_)(e,t,`${a}${a?": ":""}${i}`,r,s)},a.logErrorWithFormat=function(e,t,i,a,r={}){(0,f.vV)(e,`${i}${i?": ":""}${t}`,a,r)}},22944(e,t,i){i.r(t),i.d(t,{SportsSpotlightCricketTransformer:()=>p});var a=i(23305),r=i(87906),s=i(33335),n=i(33744),o=i(79811),l=i(89757);class p extends a.Bc{constructor(){super(...arguments),this.getCricketMetaData=e=>({cardSize:this.cardSize,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,leagueId:"",matchData:[{sportsMatchData:{...e.sportsSpotlightCricketData.match}}],followedSports:e.followedSports})}async transform(e){let{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,o.jJ)();let i=await this.getCurrentViewModel(e);return{viewTemplate:(0,l.qy)`
                <sports-spotlight-cricket
                    :viewModel="${i}"
                ></sports-spotlight-cricket>
            `}}async getCurrentViewModel(e){try{let t,i,l,p;if(!e.sportsSpotlightCricketData)return void(0,r.vV)(s.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,e);let{match:d,partnershipInfo:c,playerOfTheMatchInfo:g,recentMatches:h}=e.sportsSpotlightCricketData;((0,o.nD)(d)||(0,o.nD)(c)&&(0,o.nD)(g)&&(0,o.nD)(h))&&(0,r.vV)(s.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,e);let{telemetryBuilder:m}=this.transformerProvider,u=d.gameCenterUrl,v=u&&(0,o.Ot)(u),S=this.getCricketMetaData(e);return l=await this.transformerProvider.generateView(S,a.hi.SportsCricket),(0,o.nD)(c)||(i=this.getPartnership(e)),(0,o.nD)(g)||(t=this.getPlayerOfMatch(e)),(0,o.nD)(h)||(p=this.getRecentMatches(e)),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:m.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),sportsSpotlightCricketData:e.sportsSpotlightCricketData,partnership:i,matchView:l?.viewTemplate,clickThroughUrl:v,playerOfMatch:t,recentMatches:p}}catch(t){(0,r.vV)(s.Ax,"Error in transforming Spotlight Cricket data",`market=${n.T3.CurrentMarket}`,e);return}}getPlayerOfMatch(e){let{telemetryBuilder:t,strings:i}=this.transformerProvider,{playerOfTheMatchInfo:r}=e.sportsSpotlightCricketData,s=(0,o.iK)(r.teamImageId||e.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),n=r.imageId?(0,o.iK)(r.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced):"";return{gameFormat:e.sportsSpotlightCricketData.match.gameFormat,cardSize:this.cardSize,playerOfTheMatchInfo:r,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),imageUrl:n,teamImageUrl:s,strings:i}}getPartnership(e){let{telemetryBuilder:t,strings:i}=this.transformerProvider,{partnershipInfo:r}=e.sportsSpotlightCricketData;return r.batter1.imageUrl=(0,o.iK)(r.batter1.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),r.batter2.imageUrl=(0,o.iK)(r.batter2.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),r.batter1.teamImageUrl=(0,o.iK)(r.batter1.teamImageId||e.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.suggestionImageInfo),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,partnershipInfo:r,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),strings:{currentPartnership:i.currentPartnership,runs:i.runsScoredText,balls:i.ballsFacedText,strikeRate:i.strikeRateText}}}getParticipantIconUrl(e){return e?.replace(/w=([\d]*)?&h=([\d]*)?/,"w=70&h=70")}getRecentMatches(e){let{telemetryBuilder:t,strings:i}=this.transformerProvider,{recentMatches:r}=e.sportsSpotlightCricketData;return r.forEach(e=>{e.teamImageUrl=e.teamImageId?(0,o.iK)(e.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo):null,e.matches=e.matches?.slice(0,5)}),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,recentMatches:r,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),strings:{recentMatches:i.recentMatches}}}}Promise.resolve().then(i.bind(i,22265)),Promise.resolve().then(i.bind(i,18937)),Promise.resolve().then(i.bind(i,30502)),Promise.resolve().then(i.bind(i,23501)),Promise.resolve().then(i.bind(i,98170))},23305(e,t,i){i.d(t,{pC:()=>Q,kA:()=>F,hi:()=>X,qz:()=>$,Pp:()=>A,T0:()=>M,Xp:()=>x,pA:()=>C,D7:()=>O,VO:()=>f,XR:()=>N,cp:()=>U,JH:()=>ei,Z5:()=>z,tX:()=>Y,X2:()=>G,oL:()=>w,BP:()=>et,Bc:()=>Z,aB:()=>T,t9:()=>E,rq:()=>H,bo:()=>b,v1:()=>_.v,S_:()=>D,mx:()=>P,IG:()=>L,JC:()=>W,jx:()=>B,Qy:()=>K,kt:()=>R,ci:()=>ee,GC:()=>V});var a,r,s,n,o,l,p,d,c,g,h,m,u,v,S,y,f,w,b,x,M,T,k,$,C,I,D,E,F,P,_=i(48098);(a=y||(y={})).Initial="initial",a.Default="default",a.Settings="settings",a.ColdStart="coldstart",(r=f||(f={})).scheduledTournaments="GolfSchedule",r.leaderboard="GolfLeaderBoard",(s=w||(w={})).singleRace="MotorSportsSingleRace",s.raceList="MotorSportsRaceList";let O=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey","auto racing":"Racing",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia"});(n=b||(b={})).Mentioned="Mentioned",n.Related="Related",n.Clickable="Clickable";let R="CHAMPIONS",z=" - ";(o=x||(x={})).preGame="pre-game",o.inprogressGame="inprogress-game",o.postGame="post-game",o.nonlive="non-live",o.toss="Toss",o.dinner="Dinner",o.drinks="Drinks",o.fog="Fog",o.innings="Innings",o.lunch="Lunch",o.stumps="Stumps",o.tea="Tea",o.break="Break",o.superover="SuperOver",o.abandoned="Abandoned",o.postponed="Postponed",o.BadWeatherCondition="BadWeatherCondition",o.delayed="Delayed",(l=M||(M={})).PreGame="PreGame",l.InProgressGame="InProgressGame",l.InProgress="InProgress",l.Final="Final",l.PostGame="PostGame",l.Live="Live",l.Unknown="Unknown";let B={Badge:"Badge",Preview:"PreviewCard"},A=/^(Sports|Event)/,H="SportsFre",N={League:"League",Team:"Team"},G={Dislike:"Dislike",Follow:"Follow"};(p=T||(T={})).Leaderboard="Leaderboard",p.FRE="Fre",p.Tennis="Tennis",p.Cricket="Cricket",p.SportsSpotlight="SportsSpotlight",p.SideBySide="SideBySide",p.Countdown="Countdown";let L={0:"recommendationNone",1:"recommendationExplicit",2:"recommendationImplicit",3:"recommendationPopular",4:"recommendationLive",5:"recommendationMIT",6:"recommendationLocalPopular",7:"recommendationRecentSelect"},V="EntityId~";(d=k||(k={})).Gold="Gold",d.Silver="Silver",d.Bronze="Bronze",d.Total="Total",(c=$||($={})).Won="Won",c.Lost="Lost",c.Tied="Tied",(g=C||(C={})).none="None",g.unknown="Unknown",g.captain="Captain",g.batter="Batter",g.bowler="Bowler",g.wicketKeeper="WicketKeeper",g.allRounder="AllRounder",(h=I||(I={})).one="1",h.two="2",(m=D||(D={})).test="Test",m.odi="Odi",m.t20="T20",(u=E||(E={})).PickTheWinner="PickTheWinner",u.PickWinner="PickWinner",u.PlayerOfMatch="PlayerOfMatch";var j=i(91089),q=i(2018);let W="sportsInfoAppState";(v=F||(F={}))[v.sportsInfoApiData=1]="sportsInfoApiData",v[v.sportsData=2]="sportsData",v[v.sportsSDCardView=3]="sportsSDCardView",v[v.sportsViewMode=4]="sportsViewMode",v[v.tabCurrentPageIndex=5]="tabCurrentPageIndex",v[v.currentTabEntityId=6]="currentTabEntityId",v[v.cardSize=7]="cardSize",v[v.cardType=8]="cardType",v[v.experienceName=9]="experienceName",v[v.entityDataMap=10]="entityDataMap",v[v.entityViewMap=11]="entityViewMap",v[v.sportsSuggestIDMap=12]="sportsSuggestIDMap",v[v.interestOptions=13]="interestOptions",v[v.allRecommendations=14]="allRecommendations",v[v.dislikedEntities=15]="dislikedEntities",v[v.followedSports=16]="followedSports",v[v.sportsConfig=17]="sportsConfig",v[v.sportsStrings=18]="sportsStrings",v[v.rootTelemetryObject=19]="rootTelemetryObject",v[v.telemetryExt=20]="telemetryExt",v[v.isPinned=21]="isPinned",v[v.isHidePopupOpen=22]="isHidePopupOpen",v[v.widgetDimension=23]="widgetDimension",v[v.searchSuggestions=24]="searchSuggestions",v[v.toggleInterestManager=25]="toggleInterestManager",v[v.sportsFeedDataParsed=26]="sportsFeedDataParsed",v[v.feedDataTimestamp=27]="feedDataTimestamp",v[v.wpoMetadata=28]="wpoMetadata",v[v.currentSpotlightEntityId=29]="currentSpotlightEntityId",v[v.previewTypeInfo=30]="previewTypeInfo",v[v.isInit=31]="isInit",v[v.isV2Data=32]="isV2Data",v[v.skinnyDataConsumed=33]="skinnyDataConsumed",v[v.isCopilotTheme=34]="isCopilotTheme",v[v.IsRubyPill=35]="IsRubyPill",v[v.pollOptionIds=36]="pollOptionIds",v[v.isRubyMiniWidget=37]="isRubyMiniWidget",v[v.isCardHovered=38]="isCardHovered",v[v.explorationSettings=39]="explorationSettings";let U=(0,j.G)({getInstance:()=>q.vv.get("sportsStates",()=>new Map)}),X={SportsInfo:"sports-sd-container",SportsInfoSpan:"sports-info-span",SportsMatchList:"sports-match-list",SportsMatch:"sports-match",Articles:"sports-articles",Standings:"sports-standings",Leaderboard:"sports-leaderboard",SportsCricket:"sports-cricket",SportsCricketV2:"sports-cricket-v2",SportsTennis:"sports-tennis",SportsMarchmadness:"sports-marchmadness",FeedsNotificationToast:"feeds-notification-toast",SportsHidePopup:"sports-hidepopup",SportsFre:"sports-fre",SportsEventBrief:"sports-event-brief",SportsEventCountry:"sports-event-country",SportsEventResults:"sports-event-results",SportsSpanMatch:"sports-span-match",SportsSpotlight:"sports-spotlight",SportsGameStats:"sports-game-stats",SportsGameLeaders:"sports-game-leaders",SportsCountdown:"sports-countdown",SportsAugmentCard:"sports-augment-card",SportsSpotlightRace:"sports-spotlight-race",SportsSpotlightTennis:"sports-spotlight-tennis",SportsTennisMatch:"sports-tennis-match",SportsSpotlightGolf:"sports-spotlight-golf",SharedHeroNewsCard:"shared-hero-news-card",SportsSimpleMatch:"sports-simple-match",SportsStandingsRankings:"sports-standings-rankings",SportsMedal:"sports-medal",SportsMedalV2:"sports-medal-v2",SportsEventSchedule:"sports-event-schedule",SportsRecentMedal:"sports-recent-medal",SportsRubyPill:"sports-ruby-pill",SportsInfoList:"sports-info-list",SportsSpotlightCricket:"sports-spotlight-cricket",SportsSpotlightCricketV2:"sports-spotlight-cricket-v2",SportsPickWinner:"sports-pick-winner-wc",SportsMatchWithScores:"sports-match-with-scores",SportsSpotlight2c:"sports-spotlight-2c",SportsUpcomingMatches:"sports-upcoming-matches",SportsTournamentsList:"sports-tournaments-list",SportsTournamentStatusRow:"tournament-status-row",SportsPlayerEvent:"sports-player-event"},K={TeamVsTeam:X.SportsMatchList,TeamVsTeamWithBracket:X.SportsMarchmadness,Standings:X.Standings,Articles:X.Articles,EventBrief:X.SportsEventBrief,OneVsOneEventResult:X.SportsEventResults,OneVsManyEventResult:X.SportsEventResults,TeamVsTeamEventResult:X.SportsEventResults,TeamStandingWithEvents:X.SportsEventCountry,TeamStandingWithMedals:X.SportsEventCountry,Spotlight:X.SportsSpotlight,SpotlightFRE:X.SportsSpotlight,SpotlightRace:X.SportsSpotlightRace,SpotlightTennis:X.SportsSpotlightTennis,SpotlightGolf:X.SportsSpotlightGolf,StandingsRankings:X.SportsStandingsRankings,LeagueTodaysEvents:X.SportsEventSchedule,TeamStandings:X.SportsMedal,SpotlightCricket:X.SportsSpotlightCricket,TournamentsList:X.SportsTournamentsList,Spotlight2c:X.SportsSpotlight2c},Y={SportsMatch:"SportsMatch",SportsTournamentStatusRow:"SportsTournamentStatusRow",EventSDCardSportsMIT1:"EventSDCardSportsMIT1",EventSDCardSportsMIT2:"EventSDCardSportsMIT2",EventSDCardSportsMIT3:"EventSDCardSportsMIT3",SportsSpans:"SportsSpans",SportsAugment:"SportsAugment",SportsHeroFre:"SportsHeroFre",SportsHeroLeagueTodaysEvents:"SportsHeroLeagueTodaysEvents",SportsHeroMatch1SeasonStats:"SportsHeroMatch1SeasonStats",SportsHeroMatch1Stats:"SportsHeroMatch1Stats",SportsHeroMatch2SeasonStats:"SportsHeroMatch2SeasonStats",SportsHeroMatch2Stats:"SportsHeroMatch2Stats",SportsHeroMatch3SeasonStats:"SportsHeroMatch3SeasonStats",SportsHeroMatch3Stats:"SportsHeroMatch3Stats",SportsHeroMatchStatistics:"SportsHeroMatchStatistics",SportsSpotlight2Match1:"SportsSpotlight2Match1",SportsSpotlight2Match2:"SportsSpotlight2Match2",SportsHeroNews:"SportsHeroNews",SportsHeroOneVsManyEventResult:"SportsHeroOneVsManyEventResult",SportsHeroOneVsOneEventResult:"SportsHeroOneVsOneEventResult",SportsMatchMiniWidget:"SportsMatchMiniWidget",SportsHeroSeasonStatistics:"SportsHeroSeasonStatistics",SportsHeroStandingsRankings:"SportsHeroStandingsRankings",SportsHeroTeamStandings:"SportsHeroTeamStandings",SportsHeroTeamStandingWithEvents:"SportsHeroTeamStandingWithEvents",SportsHeroTeamStandingWithMedals:"SportsHeroTeamStandingWithMedals",SportsHeroTeamVsTeam:"SportsHeroTeamVsTeam",SportsHeroTeamVsTeamEventResult:"SportsHeroTeamVsTeamEventResult",SportsHeroVideo:"SportsHeroVideo",SportsHeroMatchCard:"SportsHeroMatchCard"};Y.SportsMatch,Y.EventSDCardSportsMIT1,Y.EventSDCardSportsMIT2,Y.EventSDCardSportsMIT3,Y.SportsSpans,Y.SportsAugment,(S=P||(P={}))[S.entityViewMap=0]="entityViewMap",S[S.sportsConfig=1]="sportsConfig",S[S.sportsStrings=2]="sportsStrings",S[S.rootTelemetryObject=3]="rootTelemetryObject",S[S.sportsFeedDataParsed=4]="sportsFeedDataParsed",(0,j.G)({getInstance:()=>q.vv.get("sportsSpanStates",()=>new Map)});var J=i(67072);class Z extends J.GH{}class Q extends J.GH{}class ee extends J.GH{}let et=Object.freeze({SportsCard:"SportsCard",Game:"sports_game",Team:"sports_team",Vertical:"sports",DislikeSports:"HideSport",SportsSuggest:"suggestresult",SportsSuggestUrl:"suggesturl",FollowSports:"Follow",SportsFRE:"freexperience",FollowTeam:"follow_team",HeroGem:"HeroGem",SportsInfoSpotlight:"SportsInfoSpotlight",SportsDiscoverMore:"SportsDiscoverMore",ChangeLeagueTeam:"ChangeLeagueTeam",Feedback:"Feedback",PopupHideSport:"PopupHideSport",PopupHide:"popup_hide",PopupCancel:"popup_cancel",PopupClose:"popup_close",EventBriefClick:"event_brief",EventBriefContentClick:"EventBriefContent",MarchMadnessCard:"MarchMadnessCard",SportsArticle:"sports_article",SportsCarousel:"SportsCarousel",TeamVsTeam:"TeamVsTeam",ExplorationDislike:"ExplorationDislike",SportsTopSpan:"SportsTopSpan",SportsStickySpan:"SportsStickySpan",SportsTopSpanOverlay:"SportsTopSpanOverlay",SportsStickySpanOverlay:"SportsStickySpanOverlay",SeeDetails:"seedetails",SportsNotificationToast:"SportsNotificationToast",SportsNotificationToastLink:"SportsNotificationToastLink",SportsNotificationToastDismiss:"SportsNotificationToastDismiss",SportsNotificationToastYes:"SportsNotificationToastYes",SportsNotificationToastNo:"SportsNotificationToastNo",SportsAfterFollowDismiss:"SportsAfterFollowDismiss",SportsSpotlightVideo:"SpotlightVideo",Countdown:"Countdown",PinToDesk:"PinToDesk",Destination:"destination",Augment:"augment",SportsRubyClick:"SportsRubyClick",SportsSpotlightTennisCard:"SportsSpotlightTennisCard",SportsSpotlightRaceCard:"SportsSpotlightRaceCard",SportsSpotlightGolfCard:"SportsSpotlightGolfCard",SportsStandingsRankingsCard:"SportsStandingsRankingsCard",SportsStandingsRankingsTable:"SportsStandingsRankingsTable",SportsMedalCard:"SportsMedalCard",SportsAgentSpotlight:"SportsAgentSpotlight",SportsEventResults:"SportsEventResults",SportsEventScheduleCard:"SportsEventScheduleCard",SportsEventCountryCard:"SportsEventCountryCard",SportsSpotlightCricketCard:"SportsSpotlightCricketCard",SportsPickWinner:"SportsPickWinner",SportsSpotlightMatchCard2c:"SportsSpotlightMatchCard2c",SportsSpotlightScores2c:"SportsSpotlightScores2c",SportsUpcomingMatches2c:"SportsUpcomingMatches2c",SportsTournamentsListCard:"SportsTournamentsListCard",SportsInfoMiniWidget:"SportsInfoMiniWidget",SportsTournamentStatusRow:"SportsTournamentStatusRow"}),ei=Object.freeze({ChannelStoreLaunched:"ChannelStoreLaunched",Badge:"SportsBadge",TaskbarRotation:"SportsTBR",SportsFrePresent:"SportsFrePresent",SportsTabType:"SportsTabType",SportsLeagueName:"SportsLeagueName",SportsDefaultLeagueShown:"SportsDefaultLeagueShown",SportsUserFollowsDefaultLeague:"SportsUserFollowsDefaultLeague",SportsUserFollowsOtherteams:"SportsUserFollowsOtherteams",SportsDropdownChangedLeague:"SportsDropdownChangedLeague",SportsUserFollowsDropdownChangedLeague:"SportsUserFollowsDropdownChangedLeague",SportsUserGroup:"SportsUserGroup",SportsExplorationReason:"SportsExplorationReason",SportsDropdownChangedViewShown:"SportsDropdownChangedViewShown",SportsCardeSize:"SportsCardeSize",SportsReasonShown:"SportsReasonShown",SportsDfltRecoPopupShown:"SportsDefaultRecommendationPopupShown",SportsExplorationPopupShown:"SportsExplorationPopupShown",SportsEventBriefShown:"SportsEventBriefShown",SpotlightCardPreviewType:"SpotlightCardPreviewType",SpotlightCardEntityId:"SpotlightCardEntityId",SportsNewSpotlightCard:"SportsNewSpotlightCard",SportsCardType:"SportsCardType",SportsVideoSpotlightShown:"SportsVideoSpotlightShown",SportsNewSpotlightCountdown:"SportsNewSpotlightCountdown",SportsPinToDeskShown:"SportsPinToDeskShown",SportsDataV2:"SportsDataV2",SportsPinToDeskEdgeFeatureEnabled:"SportsPinToDeskEdgeFeatureEnabled",SportsNewSpotlightTennis:"SportsNewSpotlightTennis",SportsNewSpotlightRace:"SportsNewSpotlightRace",SportsNewSpotlightGolf:"SportsNewSpotlightGolf",SportsCardCurrentTabId:"SportsCardCurrentTabId",SportsCardCopilotCurrentTabId:"SportsCardCopilotCurrentTabId",SportsStandingsRankings:"SportsStandingsRankings",SportsCardIsInViewPort:"SportsCardIsInViewPort",SportsNewSpotlightCricket:"SportsSpotlightCricket",SportsCardFirstTagName:"SportsCardFirstTagName",SportsRubyPillShown:"SportsRubyPillShown",SportsTournamentsList:"SportsTournamentsList"})},23501(e,t,i){i.r(t),i.d(t,{PlayerOfMatchCard:()=>V});var a=i(56911),r=i(92011),s=i(41123),n=i(61138),o=i(62047),l=i(47810),p=i(59669);let d=`
    display: flex;
    flex-direction: column;
    font-size: ${s.K};
    justify-content: center;
`,c=`
    ${d}
    height: 30px;
`,g=(0,p.A)`
.pom-card{display:flex;flex-direction:column;gap:16px;padding:12px 12px 10px 12px;border-radius:8px;background:var(--sports-item-background);position:relative;max-height:125px}.pom-container{display:flex;flex-direction:column;align-items:center;padding:5px 0px 0px 0px;gap:5px;height:100%}.pom-info-container{display:flex;justify-content:space-between}.pom-title{font-size:${n.k};font-weight:${"600"};line-height:${n.F};position:relative}.player-stats-container{display:flex;justify-content:space-between}.stats-sub-container{${d} align-items:flex-start}.inning-container{${d}}.container-rt,.inning2-container{${d} align-items:center}.stats-container{${c} align-items:flex-start}.stats-container-inning2,.rt-stats-container{${c} align-items:center}.rt-stats-container-inning2{${c} align-items:flex-end}.empty-allrounder-summary-stats{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;font-size:${o.t};height:30px;font-weight:400}.stats-and-sub-container{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.divider{width:1px;background:${l.l};opacity:0.05}.player-stats{display:flex;justify-content:space-between;width:244px}.player-name{font-size:${o.e};font-weight:${"600"};line-height:${s.Z};max-height:20px;width:182px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.team-name{font-size:${o.t};font-weight:${"600"};line-height:${o.e}}.summary-stats-left{font-size:${n.k};font-weight:${"600"};line-height:${n.F};display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between}.summary-stats{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;text-align:center;width:244px;justify-content:space-between}.detailed-summary-stats{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;justify-content:space-between;flex:2}.empty-summary-stats{font-size:${o.t};font-weight:400;line-height:${n.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.summary-stats-right{font-size:${n.k};font-weight:600;line-height:20px;display:flex;flex-direction:column;align-items:flex-end}.summary-stats-label{font-size:${o.t};font-weight:400;line-height:${o.e};text-align:center}.summary-stats-and-label{font-size:${n.k};font-weight:600;line-height:${o.e};text-align:center}.subtext-label{font-size:${o.t};font-weight:400;line-height:${o.e}}.player-role{font-size:${o.t};font-weight:400;line-height:${o.e}}.player-details-container{display:flex;flex-direction:column}.team-details-container{display:flex;gap:4px}.sport-with-subtext-title{text-wrap:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:justify;width:90px;font-weight:600;font-size:${n.k}}.team-image{width:16px;height:16px}.player-image{width:50px;height:50px}`;var h=i(89757),m=i(69259),u=i(23305);let v=(0,h.qy)`
    <div class="player-title-container">
        <div class="player-name">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.name}
        </div>
        <div class="player-role">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.role?.title}
        </div>
    </div>
`,S=(0,h.qy)`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.oversBowled}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.oversBowledText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.maidenOvers}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.maidenOversText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.runsConceded}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.runsConcededText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.wicketsTaken}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.wicketsTakenText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.economyRate}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.economyRateText}</span>
        </div>
    </div>
`,y=(0,h.qy)`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.runsScored}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.runsScoredText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.ballsFaced}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.ballsFacedText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.foursHit}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.foursHitText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.sixesHit}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.sixesHitText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.strikeRate}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.strikeRateText}</span>
        </div>
    </div>
`,f=(0,h.qy)`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.runsScored}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.runsScoredText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.ballsFaced}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.ballsFacedText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            <span class="summary-stats-and-label">&</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.wicketsTaken}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.wicketsTakenText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.runsConceded}
            <span class="summary-stats-label">${e=>e.viewModel?.strings.runsConcededText}</span>
        </div>
    </div>
`,w=(0,h.qy)`
    <div class="player-stats">
        ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics?.battingSummary?y:null}
        ${e=>e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.bowlingSummary?S:null}
    </div>
`,b=(0,h.qy)`
    <div class="player-stats">
        ${f}
    </div>
`,x=(0,h.qy)`
    <div class="player-stats">
        ${e=>e.viewModel?.playerOfTheMatchInfo?.battingStatistics&&e.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?b:w}
    </div>
`,M=(e,t)=>(0,h.qy)`
    <div class=${t?"container-rt":"inning-container"}>
        ${t=>t.getBattingStatsRunsScored(e)}
        <span class="summary-stats-label">${e=>e.viewModel?.strings.runsScoredText}</span>
    </div>
    <div class="divider"></div>
    <div class=${t?"inning-container":"inning2-container"}>
        ${t=>t.getBattingStatsBallsFaced(e)}
        <span class="summary-stats-label">${e=>e.viewModel?.strings.ballsFacedText}</span>
    </div>
`,T=(e,t)=>(0,h.qy)`
    <div class=${t?"container-rt":"inning-container"}>
        ${t=>t.getBowlingStatsWicketsTaken(e)}
        <span class="summary-stats-label">${e=>e.viewModel?.strings.wicketsTakenText}</span>
    </div>
    <div class="divider"></div>
    <div class=${t?"inning-container":"inning2-container"}>
        ${t=>t.getBowlingStatsRunsConceded(e)}
        <span class="summary-stats-label">${e=>e.viewModel?.strings.runsScoredText}</span>
    </div>
`,k=e=>(0,h.qy)`
    <div class="empty-summary-stats">
        <div class="placeholder-container">${e}</div>
    </div>
`,$=(0,h.qy)`
    <div class="player-stats">
        <div class="summary-stats">
            ${e=>e.isBattingStatsAvailable("1")?M("1",!1):k(e.viewModel?.strings.didNotBat)}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${e=>e.isBattingStatsAvailable("2")?M("2",!0):k(e.viewModel?.strings.didNotBat)}
        </div>
    </div>
`,C=(0,h.qy)`
    <div class="player-stats">
        <div class="summary-stats">
            ${e=>e.isBowlingStatsAvailable("1")?T("1",!1):k(e.viewModel?.strings.didNotBowl)}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${e=>e.isBowlingStatsAvailable("2")?T("2",!1):k(e.viewModel?.strings.didNotBowl)}
        </div>
    </div>
`,I=(e,t,i)=>(0,h.qy)`
    <div class="${i?"rt-":""}stats-container${t?"-inning2":""}">
        ${e}
    </div>
`,D=e=>(0,h.qy)`
    <div class="empty-allrounder-summary-stats">
        <div class="placeholder-container">${e}</div>
    </div>
`,E=(0,h.qy)`
    <div class="player-stats">
        <div class="summary-stats">
            ${e=>e.isBattingStatsAvailable("1")?I(e.getBattingStatsSummary("1"),!1,!1):D(e.viewModel?.strings?.didNotBat)}
            <div class="divider"></div>
            ${e=>e.isBowlingStatsAvailable("1")?I(e.getBowlingStatsSummary("1"),!1,!0):D(e.viewModel?.strings.didNotBowl)}
            <div class="divider"></div>
            <div class="inning-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${e=>e.isBattingStatsAvailable("2")?I(e.getBattingStatsSummary("2"),!0,!1):D(e.viewModel?.strings.didNotBat)}
            <div class="divider"></div>
            ${e=>e.isBowlingStatsAvailable("2")?I(e.getBowlingStatsSummary("2"),!0,!0):D(e.viewModel?.strings.didNotBowl)}
        </div>
    </div>
`,F=(0,h.qy)`
<div class="player-stats">
    ${e=>(e=>{switch(e){case u.pA.allRounder:return E;case u.pA.batter:return $;case u.pA.bowler:return C;default:return E}})(e.viewModel?.playerOfTheMatchInfo?.role?.primaryRole||"")}    
</div>
`,P=(0,h.qy)`
    <div class="player-stats-container">
        <div class="player-stats">
            ${e=>((e,t)=>{if(t===u.S_.test)return F;switch(e){case u.pA.allRounder:return x;case u.pA.batter:return O;case u.pA.bowler:return _;default:return x}})(e.viewModel?.playerOfTheMatchInfo?.role?.primaryRole||"",e.viewModel?.gameFormat||"")}
        </div>
    </div>
`,_=(0,h.qy)`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${S}
        </div>
    </div>
`,O=(0,h.qy)`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${y}
        </div>
    </div>
`,R=(0,h.qy)`
    <div class="player-image-container">
        <img class="player-image" src=${e=>e.viewModel?.imageUrl} alt=${e=>e.viewModel?.playerOfTheMatchInfo?.name}></img>
    </div>
`,z=(0,h.qy)`
    <div class="team-details-container">
        <img class="team-image" src=${e=>e.viewModel?.teamImageUrl} alt=${e=>e.viewModel?.playerOfTheMatchInfo?.teamShortName}></img>
        <span class="team-name">
            ${e=>e.viewModel?.playerOfTheMatchInfo?.teamShortName}
        </span>
    </div>
`,B=(0,h.qy)`
    <div class="player-details-container">
        ${z}
        ${v}
    </div>
`,A=(0,h.qy)`
    <div class="pom-info-container">
        ${B}
        ${e=>e.viewModel?.imageUrl?R:null}
    </div>
`,H=(0,h.qy)`
    <div class="pom-container">
        <span class="pom-title">
            ${e=>e.viewModel?.strings.playerOfTheMatchHeader}
        </span>
        <div class="pom-card" data-t="${e=>e.viewModel?.telemetryTag}">
            ${A}
            ${P}
        </div>
    </div>
`,N=(0,h.qy)`
    ${(0,m.z)(e=>void 0!=e.viewModel,H)}
`;var G=i(71372);class L extends G.a{constructor(){super(...arguments),this.isBattingStatsAvailable=e=>!!this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(t=>t.inningNumber===e),this.getBattingStatsRunsScored=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(t=>t.inningNumber===e)?.runsScored||"",this.getBattingStatsBallsFaced=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(t=>t.inningNumber===e)?.ballsFaced||"",this.getBattingStatsSummary=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(t=>t.inningNumber===e)?.battingSummary||"",this.getBowlingStatsWicketsTaken=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(t=>t.inningNumber===e)?.wicketsTaken||"",this.getBowlingStatsRunsConceded=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(t=>t.inningNumber===e)?.runsConceded||"",this.getBowlingStatsSummary=e=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(t=>t.inningNumber===e)?.bowlingSummary||"",this.isBowlingStatsAvailable=e=>!!this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(t=>t.inningNumber===e)}}let V=class extends L{};V=(0,a.Cg)([(0,r.E)({name:"player-of-match-card",template:N,styles:g})],V)},71372(e,t,i){i.d(t,{a:()=>l});var a=i(56911),r=i(92011),s=i(60815),n=i(23305),o=i(95144);let l=class extends r.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}addSubscriptions(){}initHandlers(){}getState(){return n.cp.get(this.viewModel.experienceName)||null}};(0,a.Cg)([s.sH],l.prototype,"viewModel",void 0),l=(0,a.Cg)([o.x],l)},18937(e,t,i){i.r(t),i.d(t,{SportsCricketPartnership:()=>k});var a=i(56911),r=i(92011),s=i(59669),n=i(47810),o=i(61138),l=i(62047),p=i(33113),d=i(41123),c=i(63033);let g=(0,s.A)` .cricket-partnership{color:${n.l}}`,h=(0,s.A)` p{margin:0;font-family:"Segoe UI"}.cricket-partnership{width:268px}.ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.current-partnership{font-size:${o.k};line-height:${o.F};font-weight:600;margin:6px 0;text-align:center}.stats-item{height:28px;display:flex;justify-content:end;flex-direction:column;flex:1;padding:0 5px}.bar-title{height:14px;line-height:${l.e};font-size:${l.t};font-weight:600;display:flex;justify-content:center}.bar-title >div{display:inline-block;line-height:${o.F};font-size:${o.k}}.stats-bar{display:flex;height:8px;width:100%;border-radius:8px;justify-content:space-between;background:${p.I2};margin-top:6px}.left-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${p.I2};border-radius:8px 0 0 8px;justify-content:flex-end}.right-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${p.I2};border-radius:0 8px 8px 0;justify-content:flex-start}.left-bar-progress{height:8px;width:30%;border-radius:8px 0 0 8px;background:#EACF24}.right-bar-progress{height:8px;width:30%;border-radius:0 8px 8px 0;background:#9C8C26}.individual-partnership{flex-direction:row;flex-wrap:nowrap;justify-content:space-between;text-align:justify;position:relative;background:var(--sports-item-background);padding:12px;border-radius:8px;display:flex}.partnership-player{display:flex;flex-direction:column}.player-stats{height:20px;font-family:'Segoe UI';font-style:normal;font-weight:400;font-size:${o.k};;line-height:${o.F}}.player-name{font-style:normal;font-weight:600;font-size:${o.k};line-height:${o.F};max-width:70px}.left-player{text-align:left;flex:1 1 0}.right-player{text-align:right;flex:1 1 0}.horizontal-bar{box-sizing:border-box;width:100%;height:1px;background:var(--neutral-stroke-divider-rest);flex:0 0 auto;order:0}.stats-bar{text-align:center}._1x_3y{.current-partnership{margin:10px 0;font-size:${d.K};line-height:${d.Z}}.individual-partnership{padding:13px}.player-name{-webkit-line-clamp:2}}.player-image{width:50px;height:50px}.middle-section{width:118px;display:flex;flex-direction:column}.team-image{width:16px;height:16px}.team-name{font-size:${l.t};line-height:${l.e};font-weight:600;margin-left:6px}.team-image-container{display:flex;flex:1;justify-content:center;align-items:center}.individual-partnership.without-image{flex-direction:column;.partnership-player{flex-direction:row}.player-name-container{display:flex;flex:3 1 0;flex-direction:column;overflow:hidden}.player-stats{display:flex;flex:1 1 0;flex-direction:column;p{min-width:16px;max-width:35px;text-align:center}}.grid-stats{display:grid;grid-template-columns:1fr 1fr;column-gap:12px;width:100%}.header{font-weight:600}p{font-size:${o.k};line-height:${o.F}}.stats-header-row,.stats-row{display:flex}.player-name{max-width:none}.player1{padding-bottom:8px;padding-top:4px;border-bottom:1px solid rgba(0,0,0,0.05)}.player2{padding-top:8px}}.partnership-info{margin-left:auto;font-size:${l.t};line-height:${l.e};font-weight:600}`.withBehaviors(new c.N(null,g));var m=i(89757),u=i(69259);let v=e=>(0,m.qy)`
    <div class="partnership-player">
        <div class="player-image-container">
            <img class="player-image" src="${e.imageUrl}" alt="${e.name}" />
        </div>
        <p class="player-name ellipsis"  title="${e.name}">
            ${e.name}
        </p>
        <p class="player-stats ellipsis">
            ${t=>t.setPlayerStats(e.battingStatistics?.runsScored||"",e.battingStatistics?.ballsFaced||"")}
        </p>
    </div>
`,S=(0,m.qy)`
    <div class="stats-item">
        <div class="bar-title">
            <div>${e=>e.viewModel.partnershipInfo.runs} (${e=>e.viewModel.partnershipInfo.balls})</div>
        </div>
        <div class="stats-bar">
            <div class="left-bar"><div class="left-bar-progress" style="width: ${e=>e.partnershipPercentage("batter1")}"></div></div>
            <div class="right-bar"><div class="right-bar-progress" style="width: ${e=>e.partnershipPercentage("batter2")}"></div></div>
        </div>
    </div>
`,y=(0,m.qy)`
    <div class="cricket-partnership ${e=>e.viewModel.cardSize}" data-t="${e=>e.viewModel.telemetryTag}">
        <p class="current-partnership">${e=>e.viewModel.strings.currentPartnership}</p>
        ${e=>e.viewModel.partnershipInfo.batter1.imageUrl&&e.viewModel.partnershipInfo.batter2.imageUrl?w:f}
    </div>
`,f=(0,m.qy)`
    <div class="individual-partnership without-image">
        <div class="team-image-container">
            <img class="team-image" src="${e=>e.viewModel.partnershipInfo.batter1.teamImageUrl}" />
            <p class="team-name ellipsis" title="${e=>e.viewModel.partnershipInfo.batter1.teamName}">${e=>e.viewModel.partnershipInfo.batter1.teamShortName}</p>
            <p class="partnership-info">${e=>e.viewModel.partnershipInfo.runs}(${e=>e.viewModel.partnershipInfo.balls})</p>
        </div>
        <div class="player1">
            ${e=>b(e.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="player2">
            ${e=>b(e.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,w=(0,m.qy)`
    <div class="individual-partnership">
        <div class="left-player">
            ${e=>v(e.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="middle-section">
            <div class="team-image-container">
                <img class="team-image" src="${e=>e.viewModel.partnershipInfo.batter1.teamImageUrl}" />
                <p class="team-name ellipsis" title="${e=>e.viewModel.partnershipInfo.batter1.teamName}">${e=>e.viewModel.partnershipInfo.batter1.teamShortName}</p>
            </div>
            ${S}
        </div>
        <div class="right-player">
            ${e=>v(e.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,b=e=>(0,m.qy)`
    <div class="partnership-player">
        <div class="player-name-container">
            <p class="player-name ellipsis header" title="${e.name}">
                ${e.name}
            </p>
            <p class="player-role ellipsis" title="${e.role.title}">
                ${e.role.title}
            </p>
        </div>
        <div class="player-stats">
            <div class="grid-stats">
                <p class="stats-header header">${e=>e.viewModel.strings.runs}</p>
                <p class="stats-header header">${e=>e.viewModel.strings.balls}</p>
                <p class="stats ellipsis">${e.battingStatistics?.runsScored||""}</p>
                <p class="stats ellipsis">${e.battingStatistics?.ballsFaced||""}</p>
            </div>
        </div>
    </div>
`,x=(0,m.qy)`
    ${(0,u.z)(e=>void 0!=e.viewModel,y)}
`;var M=i(71372);class T extends M.a{constructor(){super(...arguments),this.setPlayerStats=(e,t)=>e?t?e+" ("+t+")":e:"",this.partnershipPercentage=e=>{let t="batter1"===e?this.viewModel.partnershipInfo.batter1:this.viewModel.partnershipInfo.batter2,i=t.battingStatistics?.runsScored||"",a=this.viewModel.partnershipInfo.runs||"";return this.isEmpty(i)||this.isEmpty(a)?"0%":100*parseInt(i)/parseInt(a)+"%"},this.isEmpty=e=>null===e||""===e}}let k=class extends T{};k=(0,a.Cg)([(0,r.E)({name:"sports-cricket-partnership",template:x,styles:h,shadowOptions:{delegatesFocus:!0}})],k)},98170(e,t,i){i.r(t),i.d(t,{SportsCricketRecentMatches:()=>k});var a=i(56911),r=i(92011),s=i(59669),n=i(22131),o=i(4126),l=i(47810),p=i(61138),d=i(62047);let c=(0,s.A)` .ruby{container-type:inline-size}@container (min-width:180px) and (max-width:233px){.ruby{.content{.team-info{min-width:55px;max-width:60px}.team-performance{gap:2px}}}}@container (min-width:234px) and (max-width:269px){.ruby{.content{.team-performance{gap:7px}}}}`,g=(0,s.A)` :host{--ruby-win-color:#6CC57B;--ruby-loss-color:#F98981;--ruby-tie-color:#8791B0;--ruby-win-bg-color:#09662033;--ruby-loss-bg-color:#9D192033;--ruby-tie-bg-color:#323F60A6}.recent-matches{color:${l.l}}.ruby .result-element .team-name{color:#D7DEEF}`,h=(0,n.G2)(g),m=(0,s.A)` :host{--ruby-win-color:#01712B;--ruby-loss-color:#AC1922;--ruby-tie-color:#635C57;--ruby-win-bg-color:#94DC7F33;--ruby-loss-bg-color:#FFB5AE33;--ruby-tie-bg-color:#F8F4F2}p{margin:0;font-family:"Segoe UI"}.team-info{margin-right:8px}.title{font-size:${p.k};line-height:${p.F};font-weight:600;margin:8px 0;text-align:center}.content{display:flex;flex-direction:column;background:var(--sports-item-background);padding:6px 12px;border-radius:8px}.team-performance{display:flex;flex-direction:row;gap:8px;&:first-child{padding-bottom:5px;margin-bottom:5px;border-bottom:1px solid rgba(0,0,0,0.05)}}.result-element{padding-top:4px;width:32px;display:flex;flex-direction:column;align-items:center;span{width:24px;text-align:center}.result{color:#fff;font-size:${p.k};line-height:${p.F};text-align:center;border-radius:6px;font-weight:600;height:24px;display:flex;justify-content:center;align-items:center;margin-bottom:6px}.winner{background-color:rgba(15,112,59,1)}.loss{background-color:rgba(209,52,56,1)}.tied{background-color:rgba(220,159,6,1)}}.team-name{font-size:${d.t};line-height:${d.e};font-weight:600;text-align:center}.team-image{height:32px}.underscore{width:12px;height:1px;position:absolute;bottom:6px;right:50%;transform:translateX(50%)}.ruby{.content{background:none;padding:0px 0px 18px}.title{display:none}.team-info{display:flex;align-items:center;width:70px;margin-right:0px}.team-image{width:20px;height:20px}.team-performance{gap:12px;&:first-child{margin-bottom:24px;border-bottom:0px}}.team-name{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:550;margin:0px 0px 0px 4px;max-width:44px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit}.result-element{position:relative;padding-top:0px;width:auto;.team-name{display:none}.winner{background-color:var(--ruby-win-bg-color);color:var(--ruby-win-color)}.loss{background-color:var(--ruby-loss-bg-color);color:var(--ruby-loss-color)}.tied{background-color:var(--ruby-tie-bg-color);color:var(--ruby-tie-color)}.underscore{&.winner{background-color:var(--ruby-win-color)}&.loss{background-color:var(--ruby-loss-color)}&.tied{background-color:var(--ruby-tie-color)}}}.result{margin-bottom:0px;border-radius:14px;height:28px;width:28px;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}}`.withBehaviors(h,new o.o("isAdaptiveThemeEnabled",!0,c));var u=i(89757),v=i(69259),S=i(68835);let y=(0,u.qy)`
    <div class="team-performance">
        <div class="team-info">
            <img class="team-image" src="${e=>e.teamImageUrl}" alt="${e=>e.teamName}" />
            <p class="team-name">${e=>e.teamName}</p>
        </div>
        ${(0,S.ux)(e=>e.matches,()=>(0,u.qy)`
    <div class="result-element">
        <span class="${(e,t)=>t.parentContext.parent.getResultClass(e.gameStatus)} result">
            ${e=>e.summary}
        </span>
        <span class="team-name">${e=>e.teamName}</span>
        ${(0,v.z)(e=>e.isLatest,(0,u.qy)`<div class="underscore ${(e,t)=>t.parentContext.parent.getResultClass(e.gameStatus)}"></div>`)}
    </div>
`)}
    </div>
`,f=(0,u.qy)`
    <div class="recent-matches ${e=>e.viewModel.isRubySpotlight?"ruby":""}" data-t="${e=>e.viewModel.telemetryTag}">
        <p class="title">${e=>e.viewModel.strings?.recentMatches}</p>
        <div class="content">
            ${(0,S.ux)(e=>e.viewModel.recentMatches,y)}
        </div>
    </div>
`,w=(0,u.qy)`
    ${(0,v.z)(e=>void 0!=e.viewModel,f)}
`;var b=i(23305),x=i(71372),M=i(83546);class T extends x.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,M.h)()}getResultClass(e){return e===b.qz.Won?"winner":e===b.qz.Lost?"loss":"tied"}}let k=class extends T{};k=(0,a.Cg)([(0,r.E)({name:"sports-cricket-recent-matches",template:w,styles:m,shadowOptions:{delegatesFocus:!0}})],k)},30502(e,t,i){i.r(t),i.d(t,{SportsCricket:()=>z});var a=i(56911),r=i(23305),s=i(71372),n=i(50180),o=i(18633);class l extends s.a{handleClickFollowIcon(e,t,i,a){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();let r="keydown"===e.type||"keypress"===e.type||"keyup"===e.type;(0,o.LE)(e.currentTarget,r,t),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,t,a)}}getScoreClassName(e,t){return this.viewModel.scoreClassNameMap?.get(`${e}${t.satoriId}`)||""}getScoreLineByIndex(e,t,i){let a=this.viewModel.scoresMap.get(`${e}${t.satoriId}`),r=a&&a.length>i?a[i]:void 0;return r?.trim()}getMiddleTemplate(e){return e==r.Xp.preGame?"pre":e==r.Xp.postGame?"post":"live"}getMiddleTemplateClass(e){return e===r.Xp.superover?"state-top":e===r.Xp.postponed?"state-bottom":""}getParticipant(e,t){return this.viewModel.isRTL?e?t.participantTwo:t.participantOne:e?t.participantOne:t.participantTwo}getLiveText(e){return e==r.Xp.inprogressGame?this.viewModel.strings?.sportsLive:e}getFollowIconTitle(e,t){return(0,n.GP)((t?this.viewModel.strings?.followSports:this.viewModel.strings?.haveFollowed)||"",e.name||"")}getGameTime(e){return(e.tvChannel?`${e.gameStartTime}, ${e.tvChannel}`:e.gameStartTime)||""}isScoreMultiLine(e,t){let i=this.viewModel.scoresMap.get(`${e}${t.satoriId}`);return!!i&&i.length>1}shouldRenderResults(e){return e!=r.Xp.preGame&&e!=r.Xp.toss}shouldShowSuperOver(e){return e===r.Xp.superover}shouldShowPostPoned(e){return e===r.Xp.postponed}}var p=i(92011),d=i(86856),c=i(63033),g=i(59669),h=i(22131),m=i(70289);let u=(0,g.A)` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}.match-content{color:#FFFFFF}.ipl-super-over{background:rgba(255,255,255,0.09)}.cricket-final{color:#FFFFFF}.winner-tag path{fill:#FFFFFF}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#0078d4}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.cricket-live-tag{background:rgba(36,214,87,1);color:#000000}.match-footer{color:#FFFFFF}.pin-to-desk-block{background:rgba(91,51,143,1);background-image:linear-gradient(45deg,rgb(255,0,165) 0,rgb(255,0,165) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgba(255,0,165,0.8) 87%,rgb(255,0,165) 100%);color:white}.pin-to-desk-button{border:1px solid white}.win-light{display:none}.win-dark{display:block}`,v=(0,g.A)` `,S=(0,g.A)` .flip-h .follow-icon{float:left}.match-footer{right:calc(50% - 90px)}.pin-to-desk-button > img{margin-left:4px}`,y=(0,g.A)` :host{--participant-height:55px;--match-content-height:54px;--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{text-align:center;align-items:center;display:grid;row-gap:4px;position:relative;height:100%}.match-content{background:var(--sports-item-background);display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:#000000;width:268px;backdrop-filter:blur(6px);height:54px;${m.f}}.match-content:hover,.match-content:focus-visible{background:var(--sports-item-hover-background)}.match-content:active{background:var(--sports-item-active-background)}._1x_1y .match-content{height:var(--match-content-height)}._1x_1y .participant-container{height:var(--match-content-height)}._1x_1y .participant-container .follow-icon{top:-5px;right:-8px}._1x_3y .match-content{height:72px}._1x_3y .participant-content{height:100%}._1x_3y .participant-score span{margin-top:3px}._1x_3y .participant-score{margin-top:10px}:host([isMobile=true]) .match-content{width:100%}:host([cardlayout="_1x_1y"]) .match-content{padding:0}:host([isMobile=true]) .match-content{margin:0 auto;margin-bottom:8px}:host([isMobile=true]) .participant-container{padding:20px;box-sizing:border-box}:host([cardlayout="_1x_1y"]) .participant-container{max-height:70px}:host([isMobile=true]),:host([isMobile=true]) *:active,:host([isMobile=true]) *:hover{border:none;outline:none;box-shadow:none;text-decoration:none;-webkit-tap-highlight-color:transparent;-webkit-highlight:none}.participant-container{width:108px;max-width:132px;margin:0 0 0 13px;height:100%}.participant-container.flip-h{margin:0 13px 0 0}.results{display:flex}.flip-h .results{flex-flow:row-reverse}.single{align-items:center}.single .participant-score span.score-line1{margin:0 0 5px 0}.participant-info{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}.participant-content{display:flex;column-gap:7px;height:var(--participant-height);position:relative}.flip-h .participant-content{flex-flow:row-reverse}.match-detail{height:var(--participant-height);display:flex;align-items:center}.ipl .match-detail.state-top{height:80px}._1x_1y .match-detail{height:var(--match-content-height)}.participant-icon{width:32px;height:auto;border-radius:8px}.participant-name{font-weight:600;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80px;margin:0 auto}.participant-score span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);max-width:62px}.participant-score{max-height:36px;text-align:start;display:flex;flex-direction:column}.participant-score span.score-line1{margin-top:5px;font-size:14px;font-weight:600;line-height:18px}.flip-h .participant-score{text-align:end}.winner{font-weight:600}.winner-tag{position:absolute;height:100%;display:flex;align-items:center;left:-5px;margin-top:-8px;transform:scaleX(-1)}.flip-h .winner-tag{transform:scaleX(1);right:-5px;left:auto}.winner-tag > svg{fill:currentColor}.middle-detail{align-items:center;display:flex;flex-direction:column;direction:ltr}.game-detail{margin-top:-15px}.game-date{font-weight:600;font-size:14px;line-height:20px}.game-time{font-weight:400;font-size:12px;line-height:16px}.pre-game{width:120px}.cricket-live-tag{display:inline-block;background:rgb(6,132,43);color:rgb(255,255,255);font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-line-height,16px);height:16px;padding:1px 6px;margin:0;border-radius:3px;font-weight:600;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-transform:uppercase}.status-text{font-size:12px;line-height:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ipl-super-over{background:rgba(255,255,255,0.4);display:flex;justify-content:center;align-items:center;border-radius:6px}.super-over-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0 4px 0 4px;font-size:10px;font-weight:400;line-height:14px}.state-top{flex-direction:column;justify-content:center}.state-top .middle-detail{flex:1;margin-top:15px}.state-bottom{flex-direction:column;justify-content:center;height:100%;margin-top:10px}.live-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;margin-top:1px}.detail-live-animation{height:1px;transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate;background:white}@keyframes liveAnimation{0%{width:20px}100%{width:4px}}.match-extended-details{width:180px;text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0px 10px;box-sizing:border-box}.match-footer{color:#1A1A1A;font-style:normal;font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:180px;display:inline-block;position:absolute;bottom:5px;left:calc(50% - 90px)}:host([cardlayout="_1x_1y"]) .match-footer{bottom:4px}.super-over-words{background:rgba(255,255,255,0.35);border-radius:3px;color:rgb(101,107,155);font-style:italic;font-weight:600;width:130px;height:30px;font-size:20px;transform:scale(0.5);line-height:14px;display:flex;align-items:center;justify-content:center;padding:0 3px 5px 0;box-sizing:border-box}.cricket-final{width:21px;height:21px;background:var(--sports-item-background);border-radius:21px;font-weight:400;font-size:10px;line-height:21px;color:#000000}.participant-hover{display:flex;align-items:center;justify-content:center;width:36px;height:28px}.ipl .participant-hover{border:0.5px solid rgba(186,186,186,0.22);border-radius:5px}.detail-live-animation .bottom-game-detail{line-height:14px}@keyframes liveAnimationCommon{0%{width:40px}100%{width:4px}}.participant-container .follow-icon{opacity:0;pointer-events:none;height:20px;position:absolute;bottom:35px;left:25px}.flip-h .follow-icon{float:right}.participant-container:hover .follow-icon,.match-content:focus-visible .follow-icon,.follow-icon:focus-visible{opacity:1;pointer-events:all}.match-content:focus-visible{outline-offset:-1px}._1x_1y.match-data:focus-visible{outline:none}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.pin-to-desk-block{background-color:rgb(255,241,250);background-image:linear-gradient(45deg,rgb(252,151,216) 0,rgb(252,151,216) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgb(252,151,216) 87%,rgb(252,151,216) 100%);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:6px;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:black;width:268px;backdrop-filter:blur(6px);height:54px}.pin-to-desk-block:hover{cursor:pointer}.pin-to-desk-des,.pin-to-desk-button{font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:16px}.pin-to-desk-button{display:flex;height:28px;padding:2px 10px;justify-content:center;align-items:center;border-radius:100px;border:1px solid black}.pin-to-desk-button > img{margin-right:4px}.win-dark{display:none}._1x_1y .pin-to-desk-block{height:var(--match-content-height)}._1x_3y .pin-to-desk-block{height:72px}:host([isMobile=true]) .pin-to-desk-block{width:100%}:host([cardlayout="_1x_1y"]) .pin-to-desk-block{padding:0}:host([isMobile=true]) .pin-to-desk-block{margin:0 auto;margin-bottom:8px}.detailed-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;padding:2px 6px;border-radius:3px;text-transform:uppercase;background:rgba(53,21,105,1)}.final-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);padding:2px 6px;border-radius:3px;background:rgba(53,21,105,0.5)}`.withBehaviors(new d.t(v,S),new c.N(null,u),(0,h.mr)((0,g.A)` :host{forced-color-adjust:auto}`));var f=i(89757),w=i(69259),b=i(68835),x=i(10500),M=i(36516),T=i(33744);let k=(0,f.qy)`
    <img
        src="${()=>(0,T.rA)().StaticsUrl}latest/sports/icons/PinBlack.svg"
        class="win-light"
    >
    <img
        src="${()=>(0,T.rA)().StaticsUrl}latest/sports/icons/PinWhite.svg"
        class="win-dark"
    />
`,$=(e,t,i,a)=>(0,f.qy)`
<div class="participant-container${e=>t?"":" flip-h"}" title="${i?.name||""}">
<div class="participant-content" index="-1">
            <div class="winner-tag">    
                ${(0,w.z)(e=>i?.isWinner,(0,f.qy)`${f.qy.partial('<svg width="5" height="10" viewBox="0 0 5 10" fill="none"><path d="M5 0 0 5.22 5 10V0Z"/></svg>')}`)}
            </div>
            <div class="participant-info" index="-1">
                <div class="participant-hover">
                    <img class="participant-icon" role="presentation" src="${e=>i.imageUrl}"/>
                </div>
                <div class="participant-name">${i?.name||""}</div>
                ${(e,t)=>{let a,s;return a=i||{},s=t.parent.viewModel.followedMap?.get(i.satoriId)!=!0,(0,f.qy)`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${(e,t)=>t.parent.getFollowIconTitle(a,s)}"
        @click="${(e,t)=>t.parent.handleClickFollowIcon(t.event,s,{id:a.satoriId||"",name:a.name,yId:a.yId||"",type:r.XR.Team,imageUrl:a.imageUrl},a.scheduleUrl||"")}"
        @keyup="${(e,t)=>t&&t.event&&"Enter"===t.event.key?t.parent.handleClickFollowIcon(t.event,s,{id:a.satoriId||"",name:a.name,yId:a.yId||"",type:r.XR.Team,imageUrl:a.imageUrl},a.scheduleUrl||""):null}"
        data-t="${(e,t)=>t.parent.viewModel.followTelemetryTag}"
    >
    <div class="${e=>s?"icon-add":"icon-selected"}"> ${f.qy.partial(s?M.A:x.A)}</div>
    </div>
`}}
            </div>
            ${(0,w.z)((e,t)=>t.parent.shouldRenderResults(a),(0,f.qy)`
    <div class="results ${(t,a)=>a.parent.getScoreLineByIndex(e,i,1)?"":"single"}">
        <div class="${(t,a)=>a.parent.getScoreClassName(e,i)}">
            <span class="score-line1">${(t,a)=>a.parent.getScoreLineByIndex(e,i,0)}</span>
            ${(0,w.z)((t,a)=>a.parent.isScoreMultiLine(e,i),(0,f.qy)`
                        <span>${(t,a)=>a.parent.getScoreLineByIndex(e,i,1)}</span>`)}
        </div>
    </div>
`)}
        </div>
    </div>
`,C=(0,f.qy)`
    <div class="cricket-live-detail">
        ${(0,w.z)(e=>e.detailedGameState!=r.Xp.nonlive,(0,f.qy)`
            <div class="cricket-live-tag">
                <span class="live-text">${(e,t)=>t.parent.getLiveText(e.detailedGameState)}</span>
            </div>
        `)}
    </div>
`,I=(0,f.qy)`
    <div class="game-detail pre-game">
        <div class="game-date">
            ${e=>e.gameDate}
        </div>
        <div class="game-time">
            ${(e,t)=>t.parent.getGameTime(e)}
        </div>
    </div>
`,D=(0,f.qy)`
    <div class="game-detail post-game">
        <div class="game-state cricket-final">
            ${(e,t)=>t.parent.viewModel.strings?.sportsVS||"VS"}
        </div>
    </div>
`,E=(0,f.qy)`
 <div class="middle-detail">
     ${(e,t)=>{switch(t.parent.getMiddleTemplate(e.detailedGameState)){case"pre":return I;case"post":return D;case"live":return C;default:return""}}}
 </div>
`;(0,f.qy)`
<div class="detailed-game-state">
    ${e=>e.detailedGameState}
</div>
`,(0,f.qy)`
<div class="detailed-game-state">
    ${e=>r.Xp.postponed}
</div>
`;let F=(0,f.qy)`
    <div class="match-detail ${(e,t)=>t.parent.getMiddleTemplateClass(e.detailedGameState)}">
        ${E}
    </div>
`,P=(0,f.qy)`  
    <a class="match-content"
        tabindex="0"
        href="${e=>e.matchClickthroughUrl?e.matchClickthroughUrl:void 0}"
        target="${(e,t)=>t.parent.viewModel.linkTarget}"
        data-t="${(e,t)=>t.parent.viewModel.telemetryTag}"
    >
        ${(e,t)=>$(e.gameId||"",!0,t.parent.getParticipant(!0,e)||{},e.detailedGameState)}
        ${F}
        ${(e,t)=>$(e.gameId||"",!1,t.parent.getParticipant(!1,e)||{},e.detailedGameState)}
        <div class="match-footer">${(e,t)=>{let i;return i=t.parent.viewModel.matchSummaryMap.get(e.gameId),(0,f.qy)`
    <div>
        <div class="match-extended-details" title="${i||""}">
            ${i||""}
        </div>
    </div>
`}}</div>
    </a>
`,_=(0,f.qy)`
    <a class="pin-to-desk-block"
        tabindex="0"
        role="button"
        @click="${e=>e.viewModel.pinToDeskClick&&e.viewModel.pinToDeskClick()}"
        data-t="${e=>e.viewModel.pinToDeskButtonTelemetryTag}"
    >
        <div class="pin-to-desk-des">
            ${e=>e.viewModel.strings.pinToDeskDesc||"Follow the latest games on desktop"}
        </div>
        <div class="pin-to-desk-button">
            ${k}${e=>e.viewModel.strings.pinToDeskButton||"Pin live score"}
        </div>
    </a>
`,O=(0,f.qy)`
    ${(0,w.z)(e=>e.viewModel.matchData.length>0,(0,f.qy)`
        <div class="match-data ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isIPL?"ipl":""}">
            ${(0,b.ux)(e=>e.viewModel.matchData.slice(0,e.viewModel.shouldShowPinToDesk?e.viewModel.showMatchCount-1:e.viewModel.showMatchCount),P,{positioning:!0})}
            ${(0,w.z)(e=>e.viewModel.shouldShowPinToDesk,_)}
        </div>`)}
`,R=(0,f.qy)`
    ${(0,w.z)(e=>void 0!=e.viewModel,O)}
`,z=class extends l{};z=(0,a.Cg)([(0,p.E)({name:"sports-cricket",template:R,styles:y,shadowOptions:{delegatesFocus:!0}})],z)},22265(e,t,i){i.r(t),i.d(t,{SportsSpotlightCricket:()=>b});var a=i(56911),r=i(71372);class s extends r.a{}var n=i(92011),o=i(59669),l=i(22131),p=i(47810);let d=(0,o.A)` .sports-spotlight-content{color:${p.l}}`,c=(0,l.G2)(d),g=(0,o.A)` .sports-spotlight-content{text-decoration:none;color:${p.l};display:grid;position:relative;z-index:1;height:100%;margin-top:2px;grid-auto-rows:min-content}._1x_1y.sports-spotlight-content{outline:none}`.withBehaviors(c);var h=i(89757),m=i(69259);let u=(0,h.qy)`
<sports-cricket-partnership
    :viewModel="${e=>e.viewModel.partnership}"
></sports-cricket-partnership>
`,v=(0,h.qy)`
 ${(0,h.qy)`${e=>e.viewModel.matchView}`}
`,S=(0,h.qy)`
<player-of-match-card
    :viewModel="${e=>e.viewModel.playerOfMatch}"
    ></player-of-match-card>
`,y=(0,h.qy)`
<sports-cricket-recent-matches
    :viewModel="${e=>e.viewModel.recentMatches}"
></sports-cricket-recent-matches>
`,f=(0,h.qy)`
    <a
        class="sports-spotlight-content ${e=>e.viewModel.cardSize}"
        href="${e=>e.viewModel.clickThroughUrl}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${v}
        ${S}
        ${(0,m.z)(e=>"_1x_1y"!==e.viewModel.cardSize,u)}
        ${y}
    </a>
`,w=(0,h.qy)`
    ${(0,m.z)(e=>void 0!=e.viewModel,f)}
`,b=class extends s{};b=(0,a.Cg)([(0,n.E)({name:"sports-spotlight-cricket",template:w,styles:g,shadowOptions:{delegatesFocus:!0}})],b)},99657(e,t,i){i.d(t,{D:()=>s,I:()=>r});let{create:a}=i(97747).G,r=a("sloppy-click-z-index",1),s=a("click-z-index",1)},70289(e,t,i){i.d(t,{f:()=>l});var a=i(59669),r=i(64187),s=i(38817),n=i(99657),o=i(33113);let l=a.A.partial`position: relative; z-index: ${n.D};`;(0,a.A)` ${s.e} ${s.nH} ${(0,r.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${o.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${o.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${o.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(s.kc)}}]);