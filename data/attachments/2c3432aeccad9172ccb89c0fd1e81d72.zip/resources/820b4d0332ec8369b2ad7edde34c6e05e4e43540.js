"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-match-list"],{14472(e,t,s){s.r(t);var a=s(67072),i=s(23305),o=s(89757),r=s(79811);class l extends i.Bc{constructor(){super(...arguments),this.cardSize=a.uE._1x_2y}async transform(e){this.cardSize=this.transformerProvider?.config?.enablePillHover&&e.cardSize===a.uE.pill?a.uE._15u:e.cardSize;let t=await this.getCurrentViewModel(e);return{viewTemplate:(0,o.qy)`
                <sports-match-list
                    :viewModel="${t}"
                ></sports-match-list>`}}async getCurrentViewModel(e){let t=await this.getMatches(e,e.reason);return{matches:t,isIncomplete:e.isCopilotTheme&&t.length<e.numberOfMatches,cardSize:this.cardSize,paginationStyle:"",reason:e.reason,showParticipantAddIcon:!1,tabIndex:0,telemetryTag:"",isCopilotTheme:e.isCopilotTheme}}async getMatches(e,t){if(!e.sportsMatchOverallData)return[];let s=e.followedSports||new Map,o=(0,r.Yo)(e.sportsMatchOverallData),l=e.sportsMatchOverallData.slice(0,e.numberOfMatches).map(async l=>{let n=l.sportsMatchData,c=(0,r.gK)(n.participantOne,s),p=(0,r.gK)(n.participantTwo,s),h={matchData:l,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:c,participantTwoFollowed:p,topDetailText:e.matchTopDetailText,isContainLiveMatch:o,reason:t,enableLiveScores:this.transformerProvider.config.enableLiveScores,cardSize:this.cardSize,showMatchUXV2:e.showMatchUXV2,isCopilotTheme:e.isCopilotTheme,isHoverable:this.cardSize===a.uE._15u,isMitUX:e.isMitUX};return this.transformerProvider.generateView(h,i.hi.SportsMatch)});return(await Promise.all(l)).filter(r.z2)}}s.d(t,{SportsMatchListTransformer:()=>l})},35908(e,t,s){s.r(t);var a=s(14472),i=s(82724);Promise.resolve().then(s.bind(s,83322)),Promise.resolve().then(s.bind(s,4708)),s.d(t,{SportsMatchListTransformer:()=>a.SportsMatchListTransformer,SportsMatchTransformer:()=>i.SportsMatchTransformer})},83322(e,t,s){s.r(t),s.d(t,{SportsMatchList:()=>g});var a=s(56911),i=s(71372);class o extends i.a{}var r=s(92011),l=s(59669),n=s(61138),c=s(63033);let p=(0,l.A)`
`,h=(0,l.A)` .sports-match-list{row-gap:12px;display:grid}.reason.sports-match-list{row-gap:8px}.reason-text{font-size:${n.k};line-height:${n.F};font-weight:600;padding-bottom:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;position:relative}.sports-match-list._15u{row-gap:0;height:272px}.sports-match-list._15u.incomplete{height:252px;padding-top:20px}.sports-match-list._15u.copilot-theme{row-gap:10px;align-items:center}`.withBehaviors(new c.N(null,p));var d=s(89757),m=s(69259),v=s(68835);let w=(0,d.qy)`
    <div class="sports-match-list ${e=>e.viewModel.paginationStyle} ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>"1.5u"===e.viewModel.cardSize?"_15u":""} ${e=>e.viewModel.isIncomplete?"incomplete":""} ${e=>e.viewModel.isCopilotTheme?"copilot-theme":""}"
    >
        ${(0,m.z)(e=>!e.viewModel.isCopilotTheme&&e.viewModel.reason,(0,d.qy)`<div class="reason-text">
            ${e=>e.viewModel.reason}
        </div>`)}
        ${(0,v.ux)(e=>e.viewModel.matches,(0,d.qy)`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>
        `,{positioning:!0})}
    </div>
`,M=(0,d.qy)`
    ${(0,m.z)(e=>void 0!=e.viewModel,w)}
`,g=class extends o{};g=(0,a.Cg)([(0,r.E)({name:"sports-match-list",template:M,styles:h,shadowOptions:{delegatesFocus:!0}})],g)}}]);