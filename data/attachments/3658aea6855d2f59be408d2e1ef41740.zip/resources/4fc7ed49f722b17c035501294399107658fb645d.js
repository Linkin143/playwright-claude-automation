"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-spotlight"],{79811(t,e,i){i.d(e,{AL(){return ct},B5(){return ut},CP(){return K},EZ(){return lt},F_(){return G},HX(){return k},Hn(){return J},Hv(){return P},IR(){return Q},K4(){return et},Lw(){return W},Ot(){return nt},PH(){return mt},UU(){return x},VQ(){return N},VY(){return Z},Yf(){return F},Yo(){return tt},ZL(){return $},Zi(){return w},_K(){return B},_S(){return vt},bm(){return j},bw(){return H},d(){return bt},d$(){return S},gK(){return xt},gS(){return pt},iK(){return st},jJ(){return it},ju(){return I},lb(){return V},m5(){return ht},nD(){return yt},or(){return U},p6(){return O},qM(){return A},ry(){return dt},s$(){return at},sP(){return Y},wB(){return R},ww(){return X},yl(){return L},yn(){return gt},z2(){return D},zy(){return ft}});var a=i(11796),r=i(54694),o=i(33335),s=i(87906),n=i(24656),l=i(32150),p=i(58319),c=i(53128),d=i(25066),g=i(52921),h=i(41432),u=i(70535),m=i(50180),y=i(9960),f=i(72627),b=i(83991),v=i(26619);const x="OSC.LBUDD745586EC750353FBC1F3971212F2F92540502D2A29306D4081FAD3D5858B79B",w="#A71930",$="#036779",S="#B10E1C",k="#DC626D",T="sportshero",C="sportsspotlight2",z=[a.v1.TeamVsTeamExploration,a.v1.CricketExploration,a.v1.TennisExploration],F=t=>{if(t){return M(t)}return""},M=t=>t?(_(t)?t+="&h=50&w=50&m=6&q=100&u=t&o=t&l=f&f=png":t.indexOf("//www.bing.com/th?")>=0&&t.indexOf("&w=")>0&&(t=t.split("&w=")[0]+"&w=100&h=100&qlt=100&c=0&rs=1"),t):t,_=t=>["//img-s-msn-com.akamaized.net/tenant/amp/entityid","//img-s.msn.cn/tenant/amp/entityid"].some(e=>t.indexOf(e)>=0);function D(t){return null!=t}const E=t=>!t||!t.trim(),P=t=>B(t,80,80,!0),B=(t="",e=40,i=40,a=!1)=>t?t.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${a?i+20:i}&h=${a?e+20:e}`):null,R=t=>t.get(a.kA.sportsData),A=t=>{const e=H(t);return g.aC.safeExecute(()=>e.tabContent?.league?.sportsMatches?.map(t=>({sportsMatchData:t}))||[],void 0,o.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(e.tabContent?.league?.sportsMatches)}; tabType=${e.tabType};`)},I=t=>{const e=H(t);return e.tabContent?.freTeams?.map(t=>({...t,id:t.id||t.satoriId}))},j=t=>H(t).reason||"-1",O=t=>{const e=H(t);return e.tabContent?.sportsSpotLightData},L=t=>t.get(a.kA.pollOptionId),H=t=>{const e=R(t),i=Y(t)-1;return e.Model?.Tabs[i]},N=t=>Boolean(t)&&z.includes(t),V=t=>t===a.v1.Fre,G=t=>t===a.v1.SpotlightFRE,U=t=>t===a.v1.StandingsRankings,W=(t,e)=>{const i=t.get(a.kA.dislikedEntities);return i?.has(e)},Y=t=>t.get(a.kA.tabCurrentPageIndex)||1,X=t=>{const e=H(t);return e?q(e.tabType):a.v1.TeamVsTeam},q=t=>{switch(t){case a.v1.TeamVsTeamExploration:case a.v1.CricketExploration:case a.v1.TennisExploration:case a.v1.EventBrief:case a.v1.TeamVsTeamWithBracket:case a.v1.SpotlightTennis:case a.v1.SpotlightRace:case a.v1.SpotlightGolf:case a.v1.SpotlightFRE:case a.v1.StandingsRankings:case a.v1.SportsMedal:case a.v1.LeagueEventResultOneVsOne:case a.v1.LeagueEventResultOneVsMany:case a.v1.LeagueEventResultTeamVsTeam:case a.v1.LeagueEvents:case a.v1.TeamStandingWithEvents:case a.v1.TeamStandingWithMedals:case a.v1.SpotlightCricket:case a.v1.TournamentsList:case a.v1.Spotlight2c:return t;case a.v1.SeasonStatistics:case a.v1.Video:case a.v1.Countdown:case a.v1.Spotlight:return a.v1.Spotlight;default:return a.v1.TeamVsTeam}};function J(t){return"boolean"==typeof t?t:!!t&&("1"===t||"true"===t.toLowerCase())}function K(t){switch(t){case h.uE._1x_1y:return"small";case h.uE._1x_3y:return"large";default:return"medium"}}const Z=(t,e)=>void 0!==t&&void 0!==e&&(e.get(t)||!1),Q=(t,e,i)=>{switch(t){case h.uE._15u:case h.uE._1x_2y:return 3;case h.uE._1x_3y:return e===a.aB.Cricket?4:i;default:return 1}},tt=t=>t.some(t=>t&&t.sportsMatchData&&t.sportsMatchData.gameStateCatetory===a.Xp.inprogressGame),et=(t,e,i,a)=>{const r=a;return r&&r[i]&&r[i][e.toString()]?(0,m.GP)((t=>{let e=146;return t===h.uE._1x_2y?e=304:t===h.uE._1x_3y&&(e=462),`https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w=300&h=${e}&q=90&m=6&f=jpg&u=t`})(i),r[i][e.toString()]):null},it=()=>l.T3.AppType===b.u.BingHomepage?v.y.appInDarkMode():n.F_?.get(n.nz.IsDarkMode)??(0,y.ud)(),at=(t,e,i,r)=>{const o=+t;if(!r||Number.isNaN(o)||o<0)return"";if(1===o)return i===a.XR.League?e.followedReasonLeague:e.followedReasonTeam;const s=a.IG[t];return s&&e[s]||""},rt="BB1dV8FG",ot="MSports";function st(t,e=!1,i){const a={format:r.f5.PNG,enableDpiScaling:!1,crop:0,...i};return E(t)?e?(0,r.XP)(rt,a):null:t.indexOf(".")>0?(0,r.oQ)(`${r.Ro}?id=${t}&pid=${ot}`,a):(0,r.XP)(t,a)}function nt(t){if(t?.startsWith("http"))return t;if(!t)return"";const e=(0,d.g2)((0,p.t7)(t));return(0,c.oh)()?function(t){if(!t)return t;try{const e=new URL((0,f.$N)()),i=new URL(t),a=e.searchParams.getAll("item").find(t=>t.startsWith("flights:"));return a&&i.searchParams.append("item",a),i.href}catch{return t}}(e):e}function lt(t,e){if(!t||!e)return t;try{const i=new URL(t),a=i.searchParams;return Object.keys(e).forEach(t=>{t&&e[t]&&a.set(t,e[t])}),i.toString()}catch{return t}}function pt(t){return t&&!t.startsWith("#")?`#${t}`:t}function ct(t,e){const i=new u.e;try{return i.localizedMonthDate(t,e)}catch(i){(0,s.vV)(o.Gu,"Sports card localizedMonthDate exception.",`date=${t} market=${e} error=${i&&i.message}`);let a=t.toLocaleDateString("en-us",{month:"short",day:"numeric"});return a||(a=t.toDateString()),a?a.replace(/\u200E/g,"").replace(/\u200F/g,""):a}}function dt(t,e){const i=new u.e;try{return i.formatTimeFromDate(t,e)}catch(i){return(0,s.vV)(o.Gu,"Sports card formatTimeFromDate exception.",`date=${t} market=${e} error=${i&&i.message}`),t.toTimeString()}}function gt(t){const e=60*(new Date).getTimezoneOffset()*1e3,i=new Date(t).valueOf();return new Date(i-e)}function ht(t){switch(t){case"PreGame":default:return a.Xp.preGame;case"InProgressGame":case"InProgress":return a.Xp.inprogressGame;case"Final":case"PostGame":return a.Xp.postGame}}function ut(t){return"string"!=typeof t.gameState?ht(t.gameState?.state):t.gameStateCatetory}function mt(t){if(!t||"string"==typeof t)return"";const{gamePeriod:e,gameClock:i}=t;return e&&i?`${e} ${i}`:e||i||""}function yt(t){return!t||"object"==typeof t&&0===Object.keys(t).length}function ft(t){return t.get(a.kA.cardType)?.toLowerCase().startsWith(T)||!1}function bt(t){return t.get(a.kA.cardType)?.toLowerCase().startsWith(C)||!1}function vt(t,e){if(t.id&&e){const i=new URL(e);i.searchParams.append("videoId",t.id),e=i.toString()}return e}function xt(t,e){return!t.hasExplicitInterest||e?.has(t.satoriId)||e?.has(t.yId)?!0===e?.get(t.satoriId||"")||!0===e?.get(t.yId||""):(e?.set(t.satoriId,!0),!0)}},70512(t,e,i){i.d(e,{O(){return o}});var a=i(41432),r=i(11796);class o extends r.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{cardSize:e,isFullCard:i,sportsGameStats:r,isSpotlight2Card:o,participants:s,isSeasonStats:n,isCopilotTheme:l,isMitUX:p}=t;let c=0;switch(e){case a.uE._1x_2y:c=i?5:3;break;case a.uE._1x_3y:c=7;break;case a.uE._2x_2y:c=4;break;case a.uE._15u:c=3}return{sportsGameStats:r.slice(0,c).map(t=>{const e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:o,isFullCard:i,participants:s,cardTitle:this.getCardTitle(n,l),isCopilotTheme:l,isMitUX:p,telemetryTag:""}}isPercentStats(t){return t?.includes("%")}getBarPercentage(t,e,i){const a=this.isPercentStats(i);return 0===t&&0===e?0:100*(a?t:t/(t+e))}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},34959(t,e,i){i.d(e,{V(){return c}});var a=i(79811),r=i(11796),o=i(41432),s=i(32150),n=i(96950),l=i(5141),p=i(87906);class c extends r.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0},timeOfPossession:{isTime:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"totalYards",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame",timeOfPossession:"timeOfPossession"}}async transform(t){this.isCopilotTheme=t.isCopilotTheme||!1;const e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.tabClickThroughUrl,t.isSpotlightFRE)},i=await this.getCurrentViewModel(e);return{viewTemplate:n.qy`
                <sports-spotlight
                    :viewModel="${i}"
                ></sports-spotlight>`}}async getCurrentViewModel(t){if(!t||0===Object.keys(t).length)return void(0,p.vV)(l.K0b,"Spotlight metadata missing",`market=${s.T3.CurrentMarket}`,t);const e=await this.getMatches(t),{cardSize:i,tabClickThroughUrl:a}=t;let n;const c=i===o.uE._1x_1y||i===o.uE._05u;let d,g;!c&&this.transformerProvider.config.enablePickWinner&&(n=await this.getPolls(t)),!t.isSpotlightFRE&&c||null!=n||(d=this.getVideoInfo(t),g=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsSpotlightVideo}));const h=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsInfoSpotlight});let u,m;c||null!=d||null!=n||(u=await this.getGameStatsInfo(t)),e.length||(m=t.spotlightData.headerData,m.clickThroughUrl=t.tabClickThroughUrl);return{cardSize:i,tabClickThroughUrl:a,matches:e,sportsGameStatsCard:u,sportsPickWinnerCard:n,sportsVideo:d,headerData:m,spotsVideoTelemetry:g,telemetryTag:h,sportsGameLeadersCard:await this.getGameLeadersInfo(t),isCopilotTheme:this.isCopilotTheme,isMitUX:t.isMitUX}}async getPolls(t){const{pollOptionId:e,isSpotlight2Card:i,spotlightData:{poll:a,matchlist:o}={}}=t;if(!a?.pollId&&a?.type!==r.t9.PickWinner||!o?.length||!o[0].sportsMatchData)return null;const{participantOne:s,participantTwo:n}=o[0].sportsMatchData||{};if(!o||!s||!n)return null;if(e){a.userVote=e;const t=a.options?.find(t=>t.id===e);t?t.count=(parseInt(t.count)+1).toString():a.options?.push({id:e,count:"1"})}const l={poll:a,match:o[0].sportsMatchData,isSpotlight2Card:i,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants};return await this.transformerProvider.generateView(l,r.hi.SportsPickWinner)}getVideoInfo(t){const{video:e}=t.spotlightData||{},i=t.isSpotlightFRE?null:this.transformerProvider.strings.gameHighlights;return e?{...e,videoTagTitle:i}:null}async getGameStatsInfo(t){const{spotlightData:e,isSpotlight2Card:i}=t||{},{sportsGameStats:a,isSeasonStats:o=!1,matchlist:s,isGameStatsFull:n}=e||{};if(!a)return null;const{cardSize:l}=t,{participantOne:p,participantTwo:c}=s[0].sportsMatchData||{},d={cardSize:l,sportsGameStats:a,isSeasonStats:o,isSpotlight2Card:i,isFullCard:n,participants:[p,c],isCopilotTheme:this.isCopilotTheme,isMitUX:t.isMitUX};return await this.transformerProvider.generateView(d,r.hi.SportsGameStats)}async getGameLeadersInfo(t){const{gameLeaders:e,matchlist:i}=t.spotlightData||{},{sportsMatchData:o}=i.length?i[0]:{sportsMatchData:void 0},s={};if(o?.participantOne?.id&&(s[o.participantOne.id]=(0,a.gS)(o.participantOne.primaryColorHex)),o?.participantTwo?.id&&(s[o.participantTwo.id]=(0,a.gS)(o.participantTwo.primaryColorHex)),!e)return null;const{cardSize:n}=t,l={cardSize:n,sportsGameLeaders:e,teamColors:s,parentTelemetryObject:t.telemetryObject};return await this.transformerProvider.generateView(l,r.hi.SportsGameLeaders)}async getMatches(t){const{spotlightData:e,telemetryObject:i,telemetryConstants:o,isHeroCard:s,isSpotlight2Card:n,followedSports:l=new Map}=t,{matchlist:p}=e||{};if(!p)return[];const c=(0,a.Yo)(p),d=p.map(async e=>{const p=e.sportsMatchData,d=(0,a.gK)(p.participantOne,l),g=(0,a.gK)(p.participantTwo,l),h={matchData:e,parentTelemetryObject:i,telemetryConstants:o,participantOneFollowed:d,participantTwoFollowed:g,isContainLiveMatch:c,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:s,isSpotlight2Card:n,isSpotlightCard:Boolean(t.spotlightData.statistics),isCopilotTheme:this.isCopilotTheme,isMitUX:t.isMitUX};return this.transformerProvider.generateView(h,r.hi.SportsMatch)});return(await Promise.all(d)).filter(a.z2)}transformSportsSpotlightData(t,e,i=!1){const{statistics:o,video:n,match:c,poll:d,headerData:g,gameLeaders:h}=t;let u,m=a.Zi,y=a.ZL;const f=[];if(c){const t=(0,a.yn)(c.gameStartDateTime);c.gameDate=(0,a.AL)(t,s.T3.CurrentMarket),c.gameStartTime=(c.gameStartDateTimeIsToBeAnnounced?null:(0,a.ry)(t,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,c.gameStateCatetory="string"!=typeof c.gameState?(0,a.m5)(c.gameState.state):c.gameStateCatetory,"string"!=typeof c.gameState&&(c.gamePeriodAndClock=(0,a.PH)(c.gameState)),c.participantOne&&(c.participantOne.scheduleUrl=(0,a.Ot)(c.participantOne.gameCenterUrl)),c.participantTwo&&(c.participantTwo.scheduleUrl=(0,a.Ot)(c.participantTwo.gameCenterUrl)),c.gameCenterUrl&&(c.matchClickthroughUrl=(0,a.Ot)(c.gameCenterUrl)),c.participantOne.imageUrl=(0,a.iK)(c.participantOne.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),c.participantTwo.imageUrl=(0,a.iK)(c.participantTwo.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),"string"==typeof c.gameState||c.gamePeriod||(c.gamePeriod=c.gameState.gamePeriod||c.gamePeriod),c.gameState=c.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:c.gameStateCatetory,this.adjustParticipantColors(c);const e=c.participantOne?.primaryColorHex===c.participantTwo?.primaryColorHex&&"ffffff"===c.participantOne?.primaryColorHex?.toLowerCase();!e&&c.participantOne?.primaryColorHex&&(m=(0,a.gS)(c.participantOne.primaryColorHex)),!e&&c.participantTwo?.primaryColorHex&&(y=(0,a.gS)(c.participantTwo.primaryColorHex)),c.matchClickthroughUrl?u=c.matchClickthroughUrl:c.gameCenterUrl&&(u=(0,a.Ot)(c.gameCenterUrl),c.matchClickthroughUrl=u),f.push({sportsMatchData:c})}const b=this.transformGameState(o,[m,y]),v=!(h&&0!==Object.keys(h).length||b&&0!==b.length||n||d);if(i||0!==f.length&&!v&&u){if(n){let t=u??"";i&&(t=(0,a.Ot)(e)),n.msnVideoEmbedLink=(0,a._S)(n,t)}return{gameLeaders:h,matchlist:f,sportsGameStats:b,video:n,poll:d,matchClickthroughUrl:u||"",isSeasonStats:o&&o.season&&2===o.season.length,isGameStatsFull:!!o?.isFullCard,headerData:g}}(0,p.vV)(l.K0b,"Spotlight metadata missing",`market=${s.T3.CurrentMarket}`,t)}transformGameState(t,e){if(!t||0===Object.keys(t).length)return;let i=[];t.season&&2===t.season.length?i=t.season:t.game&&2===t.game.length&&(i=t.game);const a=[];if(i[0]&&i[1]){const r=i[0],o=i[1],s=t.statsKeyOrder||Object.keys(r);for(const t of s){const i=Number(r[t]),s=Number(o[t]),n=this.gameStatsFormatMap[t],l=this.formatGameStatsNumber(i,n),p=this.formatGameStatsNumber(s,n),c=this.calculatePercentNumbers(i,s),d={key:this.gameStatsLocKeyMap[t]||t,left:i,right:s,leftText:l,rightText:p,leftColor:e[0],rightColor:e[1],...c};a.push(d)}}return a}formatGameStatsNumber(t,e){if(!e)return t.toString();let i="";return e.isPercent&&(i="%"),void 0!==e.toFix?`${t.toFixed(e.toFix)}${i}`:e.isTime?this.secondsToMinutes(t):`${t}${i}`}secondsToMinutes(t){return`${Math.floor(t/60)}:${Math.floor(t%60).toString().padStart(2,"0")}`}calculatePercentNumbers(t,e){let i=0,a=0,r=0;return 0!==t&&0!==e?(r=.7,i=t/(t+e)*99.3,a=e/(t+e)*99.3):0===t&&0===e?(i=0,a=0,r=0):0===t?(i=2.3,a=97,r=.7):0===e&&(i=97,a=2.3,r=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(a.toFixed(1)),gap:r}}adjustParticipantColors(t){if(!this.isCopilotTheme)return;const e=t.participantOne?.primaryColorHex.toLowerCase(),i=t.participantTwo?.primaryColorHex.toLowerCase(),r=this.isClashingColor(e),o=this.isClashingColor(i);r&&(t.participantOne.primaryColorHex=a.Zi),o&&(t.participantTwo.primaryColorHex=a.ZL)}isClashingColor(t){const e=(0,a.jJ)(),i=t.startsWith("#")?t.slice(1):t,r=parseInt(i.slice(0,2),16),o=parseInt(i.slice(2,4),16),s=parseInt(i.slice(4,6),16),n=r>200&&o>200&&s>200;return e?n||r<50&&o<50&&s<50:n}}},82724(t,e,i){i.r(e),i.d(e,{SportsMatchTransformer(){return p}});var a=i(11796),r=i(79811),o=i(31157),s=i(50180),n=i(32150),l=i(83991);class p extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.preGame?t.preGameNotificationMessage:null,this.getPostGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.postGame?t.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=t=>this.isNotificationEnabledAndAvailable(t)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=t=>null!=this.getPreGameNotificationMessage(t)||null!=this.getPostGameNotificationMessage(t),this.getTeamColor=(t,e="")=>t?.primaryColor?(0,r.gS)(t.primaryColor):t?.primaryColorHex?(0,r.gS)(t.primaryColorHex):e,this.getTeamImageUrl=t=>{if(t?.imageUrl)return(0,r.Hv)(t?.imageUrl);const e=(0,r.iK)(t?.imageId,!t?.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return(0,r.Hv)(e)},this.getBackgroundGradient=t=>{if(!t)return"";const e=this.getTeamColor(t.participantOne),i=this.getTeamColor(t.participantTwo);if(!e||!i||e===i&&"#ffffff"===e.toLowerCase())return"";const a=this.hexToRgba(e,1),r=this.hexToRgba(e,.35),o=this.hexToRgba(i,1),s=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${r} 11%,\n                        ${r} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${s} 85.25%,\n                        ${s} 89%,\n                        ${o} 89.25%,\n                        ${o} 100%)`},this.isRTLDirection=()=>document.dir===o.O.rtl,this.getGameDate=t=>{const{gameStartDateTime:e,gameStateCatetory:i}=t||{};if(this.isCopilotTheme){const t=(0,r.yn)(e),o=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return t.toLocaleDateString(n.T3.CurrentMarket,o)}{const t=(0,r.yn)(e);return(0,r.AL)(t,n.T3.CurrentMarket)}}}async transform(t){return{viewModel:await this.getViewModel(t)}}updateAdditionalInfo(t){const{sportsMatchData:e}=t;if(e&&e.additionalInfo){if(!e.additionalInfo.round&&e.additionalInfo.roundLocKey){let t=this.transformerProvider.strings[e.additionalInfo.roundLocKey];e.additionalInfo.roundParams?.forEach((e,i)=>{t=t?.replace(`{${i}}`,e)}),e.additionalInfo.round=t}if(!e.additionalInfo.roundSummary&&e.additionalInfo.roundLocKey){let t=this.transformerProvider.strings[e.additionalInfo.roundSummaryLocKey];e.additionalInfo.roundSummaryParams?.forEach((e,i)=>{t=t?.replace(`{${i}}`,e)}),e.additionalInfo.roundSummary=t}}}getGroupInfo(t){const e=t.matchData.sportsMatchData;if(!t.isMitUX||e.gameStateCatetory!==a.Xp.inprogressGame){if(t.isMitUX&&e.phaseId){if("Group"===e.phaseId)return this.formatGroupText(e.group);const t=this.getPhaseLabel(e.phaseId);if(t)return t}return e.groupInfo?this.formatGroupText(e.groupInfo):t.topDetailText||void 0}}formatGroupText(t){const e=this.transformerProvider.strings.groupTextStr||this.transformerProvider.strings.groupText;if(!e)return;const i=e.split("${0}").join("{0}");return(0,s.GP)(i,t??"")}getPhaseLabel(t){const e=this.transformerProvider.strings;return{RoundOf32:e.bracketPhaseNameRoundOf32,RoundOf16:e.bracketPhaseNameRoundOf16,QuarterFinal:e.bracketPhaseNameQuarterfinal,SemiFinal:e.bracketPhaseNameSemifinal,Final:e.bracketPhaseNameFinal}[t]}hexToRgba(t,e=1){const i=t.match(/\w\w/g);if(!i)return"";const[a,r,o]=i.map(t=>parseInt(t,16));return`rgba(${a},${r},${o},${e})`}hasLongScore(t){const e=t.participantOne?.score||"",i=t.participantTwo?.score||"";return e.length+i.length>6}getHeaderText(t){if(!t||0===Object.keys(t).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:e,gameDate:i,gamePeriodAndClock:r,gameStateCatetory:o}=t,s=t.participantOne?.score,n=t.participantTwo?.score,l=t.participantOne?.standings,p=t.participantTwo?.standings,c=new Date(e).getFullYear(),d=t.gameStartTime?t.gameStartTime.toLocaleLowerCase():"";let g,h,u,m,y;switch(o){case a.Xp.preGame:g=d,h=this.isCopilotTheme?i:`${i}, ${c}`,u=l,m=p;break;case a.Xp.inprogressGame:g=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),h=r,u=s,m=n;break;case a.Xp.postGame:g=this.transformerProvider.strings.sportsStateFinal,h=`${i}, ${c}`,u=s,m=n;break;default:g=d,h=i,u=l,m=p}switch(!0){case!!g&&!!h:y=`${g} • ${h}`;break;case!!g:y=g;break;case!!h:y=h;break;default:y=""}return{header:y,topScoreText:u,bottomScoreText:m,leftHeaderText:g,rightHeaderText:h}}async getViewModel(t){const{matchData:e,isVertical:i,telemetryConstants:o,showMatchUXV2:s,noBackgrounds:p,participantOneFollowed:c,participantTwoFollowed:d,reason:g,isContainLiveMatch:h,parentTelemetryObject:u,useLargeTeamIcon:m,hasVerticalLine:y,isSpotlight2Card:f,isSpotlightCard:b}=t||{},v=e.sportsMatchData;this.isCopilotTheme=t.isCopilotTheme||!1,this.updateAdditionalInfo(e),"string"!=typeof v.gameState&&(v.gameStateCatetory=(0,r.m5)(v.gameState.state));const x=(0,r.yn)(v.gameStartDateTime);v.gameDate=this.getGameDate(v),v.gameStartTime=(v.gameStartDateTimeIsToBeAnnounced?null:(0,r.ry)(x,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof v.gameState&&(v.gamePeriodAndClock=(0,r.PH)(v.gameState)),"string"!=typeof v.gameState&&(v.gamePeriod=v.gameState.gamePeriod),v.participantOne&&(v.participantOne.scheduleUrl=(0,r.Ot)(v.participantOne.gameCenterUrl)),v.participantTwo&&(v.participantTwo.scheduleUrl=(0,r.Ot)(v.participantTwo.gameCenterUrl)),v.gameCenterUrl&&(v.matchClickthroughUrl=(0,r.Ot)(v.gameCenterUrl)),v.participantOne.imageUrl=(0,r.iK)(v.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),v.participantTwo.imageUrl=(0,r.iK)(v.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),v.gameState=v.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:v.gameStateCatetory,t.isMitUX&&v.gameStateCatetory===a.Xp.inprogressGame&&(v.tvChannel=void 0);const w={...o,name:a.BP.Game},$=i||t.isCopilotTheme,S=this.transformerProvider.config.enableLiveScores,k=s&&!p&&!S,T=(0,r.jJ)()?`${n.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${n.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:S||s?"":this.getBackgroundGradient(v),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(u,{...w,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(v),gameNumber:"number",linkTarget:"_blank",matchData:e,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(v),overrideStyleForMatch:"",participantOneColor:k?this.getTeamColor(v.participantOne):"",participantOneFollowed:c,participantOneImgIcon:this.getTeamImageUrl(v.participantOne),participantTwoColor:k?this.getTeamColor(v.participantTwo):"",participantTwoFollowed:d,participantTwoImgIcon:this.getTeamImageUrl(v.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(v),preGameNotificationMessage:this.getPreGameNotificationMessage(v),reason:g,shouldDisplayT4:!h,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(u,w),cardSize:t.cardSize,topDetailText:this.getGroupInfo(t),useLargeTeamIcon:S||m,enableLiveScores:!t.isMitUX&&(S||s),showMatchUXV2:S||s,noBackgrounds:p,isVertical:i,headerText:$?this.getHeaderText(v):void 0,needsVerticalLine:y,liveIconUrl:T,isSpotlight2Card:f,isSpotlightCard:b,isCopilotTheme:this.isCopilotTheme,isWindows:n.T3.AppType===l.u.WindowsNewsWidgets,isMitUX:t.isMitUX}}}},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},83991(t,e,i){var a,r;i.d(e,{u(){return a}}),function(t){t.BingHomepage="bingHomepage",t.ChannelMobile="channelmobile",t.Community="community",t.ContentTools="contentTools",t.EdgeChromium="edgeChromium",t.EdgeMobile="edgeMobile",t.Finance="finance",t.Gaming="gaming",t.CGHomePage="cgHomePage",t.HomePage="homePage",t.Hub="hub",t.KnowledgeAgents="knowledgeAgents",t.Office="office",t.Personalize="personalize",t.msn="msn",t.MSNStudio="msnStudio",t.SharedWidgets="sharedWidgets",t.SuperApp="superApp",t.Shopping="shopping",t.Sports="sports",t.Distribution="distribution",t.UGC="ugc",t.Views="views",t.Weather="weather",t.WeatherWidgets="weatherWidgets",t.WeatherLocal="weatherLocal",t.Windows="windows",t.WindowsNewsPlus="windowsNewsPlus",t.WindowsNewsWidgets="winWidgets",t.WindowsShell="windowsShell",t.WindowsShellV2="windowsShellV2",t.WebWidgets="webWidgets"}(a||(a={})),function(t){t.Default="Default",t.WinDashboard="WinDashboard",t.Edge="Edge"}(r||(r={}))},59682(t,e,i){i.d(e,{SportsGameStatsTransformer(){return a.O},SportsMatchTransformer(){return r.SportsMatchTransformer},SportsSpotlightTransformer(){return o.V}});var a=i(70512),r=i(82724),o=i(34959);Promise.resolve().then(i.bind(i,89895)),Promise.resolve().then(i.bind(i,61618)),Promise.resolve().then(i.bind(i,80195))},83546(t,e,i){i.d(e,{h(){return r}});var a=i(53128);function r(){return(0,a.oh)()}},41432(t,e,i){var a;i.d(e,{GH(){return n},uE(){return a},_n(){return r},iD(){return o},CE(){return s}}),function(t){t._1x_1y="_1x_1y",t._1x_2y="_1x_2y",t._1x_3y="_1x_3y",t._1x_4y="_1x_4y",t._1x_5y="_1x_5y",t._2x_1y="_2x_1y",t._2x_2y="_2x_2y",t._2x_3y="_2x_3y",t._2x_4y="_2x_4y",t._2x_6y="_2x_6y",t._3x_1y="_3x_1y",t._3x_2y="_3x_2y",t._4x_1y="_4x_1y",t._4x_2y="_4x_2y",t._5x_1y="_5x_1y",t._5x_2y="_5x_2y",t._125u="1.25u",t._15u="1.5u",t._05u="0.5u",t._2c="2c",t.pill="pill"}(a||(a={}));const r={DefaultRecommendation:"default-recommendation",DefaultNotification:"default-notification",ExplorationTab:"exploration-tab",ExplorationReco:"exploration-recommendation"},o={dropdownHistory:"dropdownHistory",dismissHistory:"dismissHistory",suppressHistory:"suppressHistory"};function s(t,e){return 0!==t&&["_1x_3y","_1x_1y"].includes(e)&&304===t}class n{constructor(t){this.transformerProvider=t}}},52921(t,e,i){i.d(e,{aC(){return f},YJ(){return o},x1(){return s},iJ(){return m},h9(){return y},LE(){return g},Eh(){return c},Ai(){return p},dI(){return d},j8(){return h},ao(){return u}});var a=i(98378),r=i(12360);const o={Customize:a.MS.Customize,Paginate:a.MS.Paginate,Hide:a.MS.Hide,Cancel:a.MS.Cancel,Close:a.MS.Close,Dislike:a.MS.Dislike,Show:a.MS.Show,Click:a.MS.Click};class s{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,i,o){if(!t||!e)return;const{name:s,content:n,...l}=e,p={...n,type:n?.type||a.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},c={...this.ext,signature:i};o&&(c.previewType=o);const d={...l,ext:c,zone:this.zone};return(0,r.g)(s,p,d)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:a.EG.View,behavior:a.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:a.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:a.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:a.MS.Add,type:a.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:a.EG.Hover,behavior:a.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:a.EG.MouseLeave,behavior:a.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:a.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(t,e,i){const r=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:i?a.MS.Follow:a.MS.Unfollow,type:a.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createMenuDataProviderTelemetryTag(t,e,i){const r=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:a.MS.Undefined,type:a.MJ.ActionButton,content:{headline:e.headline},zone:i},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createNavClickWithTypeTelemetryTag(t,e,i){const r=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:a.MS.Navigate,type:i,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||a.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createBehaviorTelemetryTag(t,e,i){const r=this.createTelemetryObject(t,{name:e.name,action:a.EG.Click,behavior:i,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createBaseContentCardTelemetryContext(t,e){const i=this.createTelemetryObject(t,{name:e.name,type:a.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),r=this.createTelemetryObject(i,{name:e.name,type:a.MJ.Headline,behavior:a.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(i&&r)return{contentCard:i,destination:r}}initTelemetryBuilder(t,e,i,a,r){this.verticalName=t,this.categoryName=e,this.ext=i,this.zone=a,this.subCategoryName=r}updateExt(t){this.ext=t}}var n=i(7446),l=i(20421);function p(t){try{n.YT.sendActionEvent(t,a.EG.MouseLeave,a.MS.Close)}catch(t){return}}function c(t){try{n.YT.sendActionEvent(t,a.EG.Hover,a.MS.Show)}catch(t){return}}function d(t,e){try{n.YT.sendActionEvent(t,a.EG.Click,a.MS.Navigate,e)}catch(t){return}}function g(t,e,i){try{n.YT.sendActionEvent(t,e?a.EG.KeyPress:a.EG.Click,i?a.MS.Follow:a.MS.Unfollow)}catch(t){return}}function h(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");n.YT.sendContentViewEvent(t,l.ym.View)}catch(t){return}}function u(t,e){const i=e?`${e}`:"";n.YT.addOrUpdateTmplProperty(t,i)}function m(t){n.YT.removeTmplProperty(t)}function y(t){for(const e of t)m(e)}var f,b=i(87906);!function(t){t.safeExecute=function(t,e,i,a,r,o={}){try{return t()}catch(t){return i&&(0,b.vV)(i,`${a}: ${t?.message}`,r,o),e}},t.safeExecuteAsync=async function(t,e,i,a,r,o={}){try{return await t()}catch(t){return i&&(0,b.vV)(i,`${a}: ${t?.message}`,r,o),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,i,a,r,o={}){(0,b.c_)(t,e,`${a}${a?": ":""}${i}`,r,o)},t.logErrorWithFormat=function(t,e,i,a,r={}){(0,b.vV)(t,`${i}${i?": ":""}${e}`,a,r)}}(f||(f={}))},46187(t,e,i){i.d(e,{WB(){return r},zv(){return a}});const a=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",bowling:"Bowling",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia",biathlon:"Biathlon",bobsledding:"Bobsledding",curling:"Curling",luge:"Luge",skating:"Skating",skiing:"Skiing",breaking:"Breaking"});new Set(["Soccer_InternationalIntFriendlyGames","Soccer_BelgiumSuperCup","Baseball_ChineseTaipeiCpbl","Soccer_InternationalClubsUefaEuropaConferenceLeague","Soccer_FranceCoupeDeFrance","Soccer_Turkey1Lig","Soccer_BelgiumSuperCup","Soccer_VietnamVLeague","Soccer_BrazilBrasileiroSerieC","Football_CanadaCfl","Soccer_BoliviaDivisionProfesional","Football_USAUSFL"]);const r=Object.freeze([a.football,a.basketball,a.baseball,a.cricket,a.soccer,a.icehockey])},65119(t,e,i){i.d(e,{Bk(){return u},UU(){return g},C9(){return w},OY(){return f},eU(){return v}});var a=i(54694),r=i(32150),o=i(25066),s=i(46187);const n=Object.freeze({sport:"sport",league:"league",team:"team",player:"player",flag:"flag",venue:"venue",background:"background",teaser:"teaser"});Object.freeze({[s.zv.baseball]:"OSB.26BE_Baseball.png",[s.zv.football]:"OSB.1F3C8_AmericanFootball.png",[s.zv.volleyballbeach]:"OSB.1F3D0_Volleyball.png",[s.zv.volleyballteam]:"OSB.1F3D0_Volleyball.png",[s.zv.tennis]:"OSB.Tennis.png",[s.zv.tabletennis]:"OSB.1F3DG_TableTennis.png",[s.zv.soccer]:"OSB.1F3D1_Soccer.png",[s.zv.rugbyleague]:"OSB.1F3C9_RugbyFootball.png",[s.zv.rugbyunion]:"OSB.1F3C9_RugbyFootball.png",[s.zv.golf]:"OSB.26F3_Golf.png",[s.zv.cricket]:"OSB.1F3CF_CricketGame.png",[s.zv.boxing]:"OSB.1F94A_Boxing.png",[s.zv.bowling]:"OSB.1F3B3_Bowling.png",[s.zv.basketball]:"OSB.1F3C0_Basketball.png",[s.zv.badminton]:"OSB.1F3F8_Badminton.png",[s.zv.icehockey]:"OSB.1F3D2_IceHockey.png"}),i(48566);var l=i(72627),p=i(50180),c=i(59010);const d="OSB.team_logo_placeholder.png",g=`${(0,r.rA)().StaticsUrl}/latest/sports/img/IPL/DefaultPlayerImage.svg`,h=`${(0,r.rA)().StaticsUrl}/latest/sports/img/flags/generic.svg`,u={width:28,height:28,enableDpiScaling:!0,devicePixelRatio:2,format:a.f5.PNG},m="sports/",y="MSports";function f(t,e,i,r=!0){let o=t;if((0,p.oT)(o)){if(!r)return"";switch(i){case n.player:o=g;break;case n.team:o=d;break;case n.flag:o=h;break;default:o=d}}return e.crop||(e.crop=0),e.padding||0===e.padding||(e.padding=1),o.indexOf(".")>0&&!o.startsWith("http")?(0,a.oQ)(`${a.Ro}?id=${o}&pid=${y}`,e):b(o,e)}function b(t,e){return t.startsWith("http")?(0,a.oQ)(t,e):(0,a.XP)(t,e)}function v(t,e){if(t||(t=m),t.startsWith("/")||(t=`/${t}`),e)for(const i in e)Object.prototype.hasOwnProperty.call(e,i)&&(t=t.replace(`{${i}}`,e[i]));let i=`${r.T3.NavTargetUrlWithLocale}${t}`;if(i=(0,o.wY)(i),function(t){const e=new c.m(t||(0,l.iA)());return"1"===e.get("vptest")||"vp"===e.get("reqsrc")}())return i;const a=new URL(i),s=new URLSearchParams((0,l.iA)()),n=s.getAll("item");n?.length&&n.forEach(t=>{t&&a.searchParams.append("item",t)});const p=s.getAll("src");p?.length&&p.forEach(t=>{t&&a.searchParams.append("src",t)});const d=s.get("uxmode");return d&&a.searchParams.append("uxmode",d),a.href}const x={FullName:"FullName",ShortName:"ShortName",SchoolName:"SchoolName",Alias:"Alias",Abbreviation:"Abbreviation"};function w(t,e=[]){if(!t)return null;if(!e.length){if(!(0,p.oT)(t.name?.localizedName))return t.name.localizedName;if(!(0,p.oT)(t.name?.rawName))return t.name.rawName}for(const i of e)switch(i){case x.FullName:if(!(0,p.oT)(t.name?.localizedName)||!(0,p.oT)(t.name?.rawName))return t.name.localizedName??t.name.rawName;break;case x.ShortName:if(!(0,p.oT)(t.shortName?.localizedName))return t.shortName.localizedName;if(!(0,p.oT)(t.name?.localizedName))return t.name.localizedName;if(!(0,p.oT)(t.shortName?.rawName))return t.shortName.rawName;if(!(0,p.oT)(t.name?.rawName))return t.name.rawName;break;case x.SchoolName:if(!(0,p.oT)(t.schoolName?.localizedName))return t.schoolName.localizedName;if(!(0,p.oT)(t.schoolName))return t.schoolName;break;case x.Alias:if(!(0,p.oT)(t.alias?.localizedName))return t.alias.localizedName;if(!(0,p.oT)(t.alias))return t.alias;break;case x.Abbreviation:if(!(0,p.oT)(t.abbreviation?.localizedName))return t.abbreviation.localizedName;if(!(0,p.oT)(t.abbreviation))return t.abbreviation}return null}},46763(t,e,i){let a;i.d(e,{Nx(){return a}})},53315(t,e,i){i.r(e),i.d(e,{SportsGameLeadersTransformer(){return c},SportsGameStatsTransformer(){return d.O},SportsMatchTransformer(){return g.SportsMatchTransformer},SportsPickWinnerTransformer(){return u},SportsSpotlightTransformer(){return m.V}});var a=i(41432),r=i(11796),o=i(79811),s=i(87906),n=i(5141);const l=Object.freeze({points:"PTSAbbr",goals:"GAbbr",assists:"AAbbr",saves:"SVAbbr",hits:"HAbbr",atBats:"ABAbbr",strikeOuts:"KAbbr",yards:"YDSAbbr",receptions:"RECAbbr",rebounds:"REBAbbr",attempts:"FGAAbbr",redCards:"RCAbbr",yellowCards:"YCAbbr",powerPlayGoals:"PPGAbbr",powerPlayAssists:"PPAAbbr",fieldGoalsPercentage:"FGPerAbbr",freeThrowsPercentage:"FTPerAbbr",turnovers:"TOAbbr",defensiveRebounds:"DREBAbbr",offensiveRebounds:"OREBAbbr",runsBattedIn:"RBIAbbr",cmpPercValue:"CMPAbbr",touchdowns:"TDAbbr",interceptions:"INTAbbr",rating:"RTGAbbr",longest:"LGAbbr"}),p=Object.freeze({points:"points",rebounds:"rebounds",assists:"assists",passingYards:"passing",rushingYards:"rushing",receivingYards:"receiving",hits:"hits",rbi:"RBI",strikeOuts:"strikeouts",goals:"goals",saves:"saves",cards:"cards"});class c extends r.Bc{async transform(t){try{return{viewModel:await this.getCurrentViewModel(t)}}catch(e){(0,s.vV)(n.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(t)}`,void 0)}}async getCurrentViewModel(t){if(!t)return(0,s.vV)(n.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(t)}`,void 0),null;let e=0;switch(t.cardSize){case a.uE._1x_1y:e=1;break;case a.uE._1x_2y:e=3;break;case a.uE._1x_3y:e=5;break;case a.uE._2x_2y:e=4}const i=this.transformSportsGameLeadersToVM(t.sportsGameLeaders,t.teamColors).slice(0,e),r=t.parentTelemetryObject.getMetadataTag();return{sportsGameLeaders:{categories:i},cardSize:t.cardSize,cardTitle:this.transformerProvider.strings.gameLeaders,telemetryTag:r}}transformSportsGameLeadersToVM(t,e){if(!t?.categoryKeyOrder||!t?.categories)return(0,s.vV)(n.EfP,"GameLeaders object is not valid",`jsonData:${JSON.stringify(t)}`,void 0),[];return t.categoryKeyOrder.map(i=>{const a=t.categories[i];if(!a)return(0,s.vV)(n.EfP,"GameLeaders category data is missing",`jsonData:${JSON.stringify(t)}`,void 0),null;const r=a.players.map(t=>{const i=a.statsKeyOrder.map(e=>({abbreviation:this.transformerProvider.strings[l[e]]||e.slice(0,3).toLocaleUpperCase(),title:e,value:Number(t.playerStats[e]).toFixed(0)||0}));return e[t.teamId]||(0,s.vV)(n.khl,"GameLeaders player team color is missing",`jsonData:${JSON.stringify(t)}`,void 0),{playerImage:(0,o.iK)(t.playerImage||o.UU,!t.playerImage,this.transformerProvider.config.teamImageInfoEnhanced),playerName:t.playerName,playerNumber:t.playerNumber,teamColor:e[t.teamId],playerStats:i}});return{categoryTitle:this.transformerProvider.strings[p[i]]||i.toLocaleUpperCase(),players:r}}).filter(t=>t)}}var d=i(70512),g=i(82724),h=i(52921);class u extends r.Bc{async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{poll:e,telemetryConstants:i,parentTelemetryObject:a,match:o,isSpotlight2Card:s}=t||{},{participantOne:n,participantTwo:l,gameState:p,gameId:c}=o||{},{strings:d,telemetryBuilder:g}=this.transformerProvider,u=[n,l];let m=0;return Array.isArray(e.options)||(e.options=[]),e.options?.forEach(t=>{t.id!==u[0].id&&t.id!==u[1].id||(m+=parseInt(t.count))}),{strings:{...d},isSpotlight2Card:s,isEntrypoint:!0,teamsVoteData:u.map(t=>{const i=parseInt(e.options?.find(e=>e.id===t.id)?.count)||0;return{id:t.id,imageUrl:t.imageUrl,shortName:t.shortName||t.name,hasWon:t.isWinner,voteCount:i,votePercentage:Math.round(i/m*100)||0}}),gameState:"string"==typeof p?p:p.state,userVote:e.userVote,disableVoting:p!==r.Xp.preGame,telemetryContext:{rootTag:a.getMetadataTag(),voteButtonTag:g.createBehaviorTelemetryTag(a,{...i,name:r.BP.SportsPickWinner},h.YJ.Click)},recordUserVote:async t=>{this.transformerProvider.recordUserVote(c,r.t9.PickWinner,t)},telemetryTag:a.getMetadataTag()}}}var m=i(34959);Promise.resolve().then(i.bind(i,89895)),Promise.resolve().then(i.bind(i,61618)),Promise.resolve().then(i.bind(i,80195)),Promise.resolve().then(i.bind(i,62795)),Promise.resolve().then(i.bind(i,3628))},11796(t,e,i){var a,r,o,s,n;i.d(e,{X2(){return b},qz(){return S},pA(){return k},S_(){return C},VO(){return s},oL(){return n},GC(){return w},IG(){return x},D7(){return l},bo(){return p},ci(){return O},Bc(){return I},hi(){return E},XR(){return f},rq(){return y},Xp(){return g},kA(){return D},JC(){return _},tX(){return B},mx(){return R},aB(){return v},jx(){return u},t9(){return z},sQ(){return m},T0(){return h},Z5(){return d},pC(){return j},JH(){return H},v1(){return a},BP(){return L},kt(){return c},Qy(){return P}}),function(t){t.Standings="Standings",t.Articles="Articles",t.TeamVsTeam="TeamVsTeam",t.TeamVsTeamWithBracket="TeamVsTeamWithBracket",t.Tennis="Tennis",t.MotorSportsSingleRace="MotorSportsSingleRace",t.MotorSportsRaceList="MotorSportsRaceList",t.GolfSchedule="GolfSchedule",t.GolfLeaderBoard="GolfLeaderBoard",t.Cricket="Cricket",t.TeamVsTeamExploration="TeamVsTeamExploration",t.LeagueEventResultOneVsOne="OneVsOneEventResult",t.LeagueEventResultOneVsMany="OneVsManyEventResult",t.LeagueEventResultTeamVsTeam="TeamVsTeamEventResult",t.CricketExploration="CricketExploration",t.TennisExploration="TennisExploration",t.EventBrief="EventBrief",t.SeasonStatistics="SeasonStatistics",t.Video="Video",t.Countdown="Countdown",t.Fre="FRE",t.Spotlight="Spotlight",t.SpotlightRace="SpotlightRace",t.SpotlightTennis="SpotlightTennis",t.SpotlightGolf="SpotlightGolf",t.SpotlightFRE="SpotlightFRE",t.StandingsRankings="StandingsRankings",t.SportsMedal="TeamStandings",t.LeagueEvents="LeagueTodaysEvents",t.TeamStandingWithMedals="TeamStandingWithMedals",t.TeamStandingWithEvents="TeamStandingWithEvents",t.SpotlightCricket="SpotlightCricket",t.TournamentsList="TournamentsList",t.Spotlight2c="Spotlight2c",t.AgentSpotlight="AgentSpotlight"}(a||(a={})),function(t){t.SportsInfo="SportsInfo",t.SportsInfoSpan="SportsInfoSpan",t.SportsMatchList="SportsMatchList",t.SportsMatch="SportsMatch",t.SportsSpanMatch="SportsSpanMatch",t.SportsArticle="SportsArticle",t.SportsTeamExploration="SportsTeamExploration",t.SportsTeamExplorationMatch="SportsTeamExplorationMatch",t.SportsCricketExploration="SportsCricketExploration",t.SportsTennisExploration="SportsTennisExploration",t.SportsExplorationHead="SportsExplorationHead",t.SportsLeaderboard="SportsLeaderboard",t.SportsCricket="SportsCricket",t.SportsCricketV2="SportsCricketV2",t.SportsTennis="SportsTennis",t.SportsMarchmadness="SportsMarchmadness",t.SportsEventBrief="SportsEventBrief",t.SportsEventCountry="SportsEventCountry",t.SportsEventResults="SportsEventResults",t.FeedsNotificationToast="FeedsNotificationToast",t.SportsHidePopup="SportsHidePopup",t.SportsFre="SportsFre",t.SportsSpotlight="SportsSpotlight",t.AgentSpotlight="AgentSpotlight",t.SportsSpotlight2c="SportsSpotlight2c",t.SportsGameStats="SportsGameStats",t.SportsCountdown="SportsCountdown",t.SportsAugmentCard="SportsAugmentCard",t.SportsSpotlightRace="SportsSpotlightRace",t.SportsSpotlightTennis="SportsSpotlightTennis",t.SportsTennisMatch="SportsTennisMatch",t.SportsSpotlightGolf="SportsSpotlightGolf",t.SharedHeroNewsCard="SharedHeroNewsCard",t.SportsSimpleMatch="SportsSimpleMatch",t.SportsStandingsRankings="SportsStandingsRankings",t.SportsEventSchedule="SportsEventSchedule",t.SportsMedal="SportsMedal",t.SportsMedalV2="SportsMedalV2",t.SportsInfoList="SportsInfoList",t.SportsRecentMedal="SportsRecentMedal",t.SportsRubyPill="SportsRubyPill",t.SportsSpotlightCricket="SportsSpotlightCricket",t.SportsSpotlightCricketV2="SportsSpotlightCricketV2",t.SportsTournamentsList="SportsTournamentsList",t.SportsTournamentStatusRow="SportsTournamentStatusRow"}(r||(r={})),function(t){t.Initial="initial",t.Default="default",t.Settings="settings",t.ColdStart="coldstart"}(o||(o={})),function(t){t.scheduledTournaments="GolfSchedule",t.leaderboard="GolfLeaderBoard"}(s||(s={})),function(t){t.singleRace="MotorSportsSingleRace",t.raceList="MotorSportsRaceList"}(n||(n={}));const l=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey","auto racing":"Racing",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia"});var p;!function(t){t.Mentioned="Mentioned",t.Related="Related"}(p||(p={}));const c="CHAMPIONS",d=" - ";var g,h;!function(t){t.preGame="pre-game",t.inprogressGame="inprogress-game",t.postGame="post-game",t.nonlive="non-live",t.toss="Toss",t.dinner="Dinner",t.drinks="Drinks",t.fog="Fog",t.innings="Innings",t.lunch="Lunch",t.stumps="Stumps",t.tea="Tea",t.break="Break",t.superover="SuperOver",t.abandoned="Abandoned",t.postponed="Postponed",t.BadWeatherCondition="BadWeatherCondition",t.delayed="Delayed"}(g||(g={})),function(t){t.PreGame="PreGame",t.InProgressGame="InProgressGame",t.InProgress="InProgress",t.Final="Final",t.PostGame="PostGame",t.Live="Live",t.Unknown="Unknown"}(h||(h={}));const u={Badge:"Badge",Preview:"PreviewCard"},m="Sports",y="SportsFre",f={League:"League",Team:"Team"},b={Dislike:"Dislike",Follow:"Follow"};var v;!function(t){t.Leaderboard="Leaderboard",t.FRE="Fre",t.Tennis="Tennis",t.Cricket="Cricket",t.SportsSpotlight="SportsSpotlight",t.SideBySide="SideBySide",t.Countdown="Countdown"}(v||(v={}));const x={0:"recommendationNone",1:"recommendationExplicit",2:"recommendationImplicit",3:"recommendationPopular",4:"recommendationLive",5:"recommendationMIT",6:"recommendationLocalPopular",7:"recommendationRecentSelect"},w="EntityId~";var $,S,k,T,C,z;!function(t){t.Gold="Gold",t.Silver="Silver",t.Bronze="Bronze",t.Total="Total"}($||($={})),function(t){t.Won="Won",t.Lost="Lost",t.Tied="Tied"}(S||(S={})),function(t){t.none="None",t.unknown="Unknown",t.captain="Captain",t.batter="Batter",t.bowler="Bowler",t.wicketKeeper="WicketKeeper",t.allRounder="AllRounder"}(k||(k={})),function(t){t.one="1",t.two="2"}(T||(T={})),function(t){t.test="Test",t.odi="Odi",t.t20="T20"}(C||(C={})),function(t){t.PickTheWinner="PickTheWinner",t.PickWinner="PickWinner",t.PlayerOfMatch="PlayerOfMatch"}(z||(z={}));var F=i(91089),M=i(2018);const _="sportsInfoAppState";var D;!function(t){t[t.sportsInfoApiData=1]="sportsInfoApiData",t[t.sportsData=2]="sportsData",t[t.sportsSDCardView=3]="sportsSDCardView",t[t.sportsViewMode=4]="sportsViewMode",t[t.tabCurrentPageIndex=5]="tabCurrentPageIndex",t[t.currentTabEntityId=6]="currentTabEntityId",t[t.cardSize=7]="cardSize",t[t.cardType=8]="cardType",t[t.experienceName=9]="experienceName",t[t.entityDataMap=10]="entityDataMap",t[t.entityViewMap=11]="entityViewMap",t[t.sportsSuggestIDMap=12]="sportsSuggestIDMap",t[t.interestOptions=13]="interestOptions",t[t.allRecommendations=14]="allRecommendations",t[t.dislikedEntities=15]="dislikedEntities",t[t.followedSports=16]="followedSports",t[t.sportsConfig=17]="sportsConfig",t[t.sportsStrings=18]="sportsStrings",t[t.rootTelemetryObject=19]="rootTelemetryObject",t[t.telemetryExt=20]="telemetryExt",t[t.isPinned=21]="isPinned",t[t.isExplorationCard=22]="isExplorationCard",t[t.isHidePopupOpen=23]="isHidePopupOpen",t[t.widgetDimension=24]="widgetDimension",t[t.searchSuggestions=25]="searchSuggestions",t[t.toggleInterestManager=26]="toggleInterestManager",t[t.sportsFeedDataParsed=27]="sportsFeedDataParsed",t[t.feedDataTimestamp=28]="feedDataTimestamp",t[t.wpoMetadata=29]="wpoMetadata",t[t.currentSpotlightEntityId=30]="currentSpotlightEntityId",t[t.previewTypeInfo=31]="previewTypeInfo",t[t.isInit=32]="isInit",t[t.isV2Data=33]="isV2Data",t[t.skinnyDataConsumed=34]="skinnyDataConsumed",t[t.isCopilotTheme=35]="isCopilotTheme",t[t.IsRubyPill=36]="IsRubyPill",t[t.pollOptionId=37]="pollOptionId",t[t.isRubyMiniWidget=38]="isRubyMiniWidget"}(D||(D={})),(0,F.G)({getInstance(){return M.vv.get("sportsStates",()=>new Map)}});const E={SportsInfo:"sports-sd-container",SportsInfoSpan:"sports-info-span",SportsMatchList:"sports-match-list",SportsMatch:"sports-match",Articles:"sports-articles",TeamExploration:"sports-team-exploration",TeamExplorationMatch:"sports-team-exploration-match",CricketExploration:"sports-cricket-exploration",TennisExploration:"sports-tennis-exploration",ExplorationHead:"sports-exploration-head",Standings:"sports-standings",Leaderboard:"sports-leaderboard",SportsCricket:"sports-cricket",SportsCricketV2:"sports-cricket-v2",SportsTennis:"sports-tennis",SportsMarchmadness:"sports-marchmadness",FeedsNotificationToast:"feeds-notification-toast",SportsHidePopup:"sports-hidepopup",SportsFre:"sports-fre",SportsEventBrief:"sports-event-brief",SportsEventCountry:"sports-event-country",SportsEventResults:"sports-event-results",SportsSpanMatch:"sports-span-match",SportsSpotlight:"sports-spotlight",AgentSpotlight:"agent-spotlight",SportsGameStats:"sports-game-stats",SportsGameLeaders:"sports-game-leaders",SportsCountdown:"sports-countdown",SportsAugmentCard:"sports-augment-card",SportsSpotlightRace:"sports-spotlight-race",SportsSpotlightTennis:"sports-spotlight-tennis",SportsTennisMatch:"sports-tennis-match",SportsSpotlightGolf:"sports-spotlight-golf",SharedHeroNewsCard:"shared-hero-news-card",SportsSimpleMatch:"sports-simple-match",SportsStandingsRankings:"sports-standings-rankings",SportsMedal:"sports-medal",SportsMedalV2:"sports-medal-v2",SportsEventSchedule:"sports-event-schedule",SportsRecentMedal:"sports-recent-medal",SportsRubyPill:"sports-ruby-pill",SportsInfoList:"sports-info-list",SportsSpotlightCricket:"sports-spotlight-cricket",SportsSpotlightCricketV2:"sports-spotlight-cricket-v2",SportsPickWinner:"sports-pick-winner-wc",SportsMatchWithScores:"sports-match-with-scores",SportsSpotlight2c:"sports-spotlight-2c",SportsUpcomingMatches:"sports-upcoming-matches",SportsTournamentsList:"sports-tournaments-list",SportsTournamentStatusRow:"tournament-status-row"},P={TeamVsTeam:E.SportsMatchList,TeamVsTeamWithBracket:E.SportsMarchmadness,Standings:E.Standings,Articles:E.Articles,TeamVsTeamExploration:E.TeamExploration,EventBrief:E.SportsEventBrief,OneVsOneEventResult:E.SportsEventResults,OneVsManyEventResult:E.SportsEventResults,TeamVsTeamEventResult:E.SportsEventResults,TeamStandingWithEvents:E.SportsEventCountry,TeamStandingWithMedals:E.SportsEventCountry,CricketExploration:E.CricketExploration,TennisExploration:E.TennisExploration,Spotlight:E.SportsSpotlight,SpotlightFRE:E.SportsSpotlight,SpotlightRace:E.SportsSpotlightRace,SpotlightTennis:E.SportsSpotlightTennis,SpotlightGolf:E.SportsSpotlightGolf,StandingsRankings:E.SportsStandingsRankings,LeagueTodaysEvents:E.SportsEventSchedule,TeamStandings:E.SportsMedal,SpotlightCricket:E.SportsSpotlightCricket,TournamentsList:E.SportsTournamentsList,Spotlight2c:E.SportsSpotlight2c,AgentSpotlight:"AgentSpotlight"},B={SportsMatch:"SportsMatch",SportsTournamentStatusRow:"SportsTournamentStatusRow",EventSDCardSportsMIT1:"EventSDCardSportsMIT1",EventSDCardSportsMIT2:"EventSDCardSportsMIT2",EventSDCardSportsMIT3:"EventSDCardSportsMIT3",SportsSpans:"SportsSpans",SportsAugment:"SportsAugment",SportsHeroFre:"SportsHeroFre",SportsHeroLeagueTodaysEvents:"SportsHeroLeagueTodaysEvents",SportsHeroMatch1SeasonStats:"SportsHeroMatch1SeasonStats",SportsHeroMatch1Stats:"SportsHeroMatch1Stats",SportsHeroMatch2SeasonStats:"SportsHeroMatch2SeasonStats",SportsHeroMatch2Stats:"SportsHeroMatch2Stats",SportsHeroMatch3SeasonStats:"SportsHeroMatch3SeasonStats",SportsHeroMatch3Stats:"SportsHeroMatch3Stats",SportsHeroMatchStatistics:"SportsHeroMatchStatistics",SportsSpotlight2Match1:"SportsSpotlight2Match1",SportsSpotlight2Match2:"SportsSpotlight2Match2",SportsHeroNews:"SportsHeroNews",SportsHeroOneVsManyEventResult:"SportsHeroOneVsManyEventResult",SportsHeroOneVsOneEventResult:"SportsHeroOneVsOneEventResult",SportsMatchMiniWidget:"SportsMatchMiniWidget",SportsHeroSeasonStatistics:"SportsHeroSeasonStatistics",SportsHeroStandingsRankings:"SportsHeroStandingsRankings",SportsHeroTeamStandings:"SportsHeroTeamStandings",SportsHeroTeamStandingWithEvents:"SportsHeroTeamStandingWithEvents",SportsHeroTeamStandingWithMedals:"SportsHeroTeamStandingWithMedals",SportsHeroTeamVsTeam:"SportsHeroTeamVsTeam",SportsHeroTeamVsTeamEventResult:"SportsHeroTeamVsTeamEventResult",SportsHeroVideo:"SportsHeroVideo",SportsHeroMatchCard:"SportsHeroMatchCard"};var R;B.SportsMatch,B.EventSDCardSportsMIT1,B.EventSDCardSportsMIT2,B.EventSDCardSportsMIT3,B.SportsSpans,B.SportsAugment,function(t){t[t.entityViewMap=0]="entityViewMap",t[t.sportsConfig=1]="sportsConfig",t[t.sportsStrings=2]="sportsStrings",t[t.rootTelemetryObject=3]="rootTelemetryObject",t[t.sportsFeedDataParsed=4]="sportsFeedDataParsed"}(R||(R={})),(0,F.G)({getInstance(){return M.vv.get("sportsSpanStates",()=>new Map)}});var A=i(41432);class I extends A.GH{}class j extends A.GH{}class O extends A.GH{}const L=Object.freeze({SportsCard:"SportsCard",Game:"sports_game",Team:"sports_team",Vertical:"sports",DislikeSports:"HideSport",SportsSuggest:"suggestresult",SportsSuggestUrl:"suggesturl",FollowSports:"Follow",SportsFRE:"freexperience",FollowTeam:"follow_team",HeroGem:"HeroGem",SportsInfoSpotlight:"SportsInfoSpotlight",SportsDiscoverMore:"SportsDiscoverMore",ChangeLeagueTeam:"ChangeLeagueTeam",Feedback:"Feedback",PopupHideSport:"PopupHideSport",PopupHide:"popup_hide",PopupCancel:"popup_cancel",PopupClose:"popup_close",EventBriefClick:"event_brief",EventBriefContentClick:"EventBriefContent",MarchMadnessCard:"MarchMadnessCard",SportsArticle:"sports_article",SportsCarousel:"SportsCarousel",TeamVsTeam:"TeamVsTeam",ExplorationDislike:"ExplorationDislike",SportsTopSpan:"SportsTopSpan",SportsStickySpan:"SportsStickySpan",SportsTopSpanOverlay:"SportsTopSpanOverlay",SportsStickySpanOverlay:"SportsStickySpanOverlay",SeeDetails:"seedetails",SportsNotificationToast:"SportsNotificationToast",SportsNotificationToastLink:"SportsNotificationToastLink",SportsNotificationToastDismiss:"SportsNotificationToastDismiss",SportsNotificationToastYes:"SportsNotificationToastYes",SportsNotificationToastNo:"SportsNotificationToastNo",SportsAfterFollowDismiss:"SportsAfterFollowDismiss",SportsSpotlightVideo:"SpotlightVideo",Countdown:"Countdown",PinToDesk:"PinToDesk",Destination:"destination",Augment:"augment",SportsRubyClick:"SportsRubyClick",SportsSpotlightTennisCard:"SportsSpotlightTennisCard",SportsSpotlightRaceCard:"SportsSpotlightRaceCard",SportsSpotlightGolfCard:"SportsSpotlightGolfCard",SportsStandingsRankingsCard:"SportsStandingsRankingsCard",SportsStandingsRankingsTable:"SportsStandingsRankingsTable",SportsMedalCard:"SportsMedalCard",SportsAgentSpotlight:"SportsAgentSpotlight",SportsEventResults:"SportsEventResults",SportsEventScheduleCard:"SportsEventScheduleCard",SportsEventCountryCard:"SportsEventCountryCard",SportsSpotlightCricketCard:"SportsSpotlightCricketCard",SportsPickWinner:"SportsPickWinner",SportsSpotlightMatchCard2c:"SportsSpotlightMatchCard2c",SportsSpotlightScores2c:"SportsSpotlightScores2c",SportsUpcomingMatches2c:"SportsUpcomingMatches2c",SportsTournamentsListCard:"SportsTournamentsListCard",SportsInfoMiniWidget:"SportsInfoMiniWidget",SportsTournamentStatusRow:"SportsTournamentStatusRow"}),H=Object.freeze({ChannelStoreLaunched:"ChannelStoreLaunched",Badge:"SportsBadge",TaskbarRotation:"SportsTBR",SportsFrePresent:"SportsFrePresent",SportsTabType:"SportsTabType",SportsLeagueName:"SportsLeagueName",SportsDefaultLeagueShown:"SportsDefaultLeagueShown",SportsUserFollowsDefaultLeague:"SportsUserFollowsDefaultLeague",SportsUserFollowsOtherteams:"SportsUserFollowsOtherteams",SportsDropdownChangedLeague:"SportsDropdownChangedLeague",SportsUserFollowsDropdownChangedLeague:"SportsUserFollowsDropdownChangedLeague",SportsUserGroup:"SportsUserGroup",SportsExplorationReason:"SportsExplorationReason",SportsDropdownChangedViewShown:"SportsDropdownChangedViewShown",SportsCardeSize:"SportsCardeSize",SportsReasonShown:"SportsReasonShown",SportsDfltRecoPopupShown:"SportsDefaultRecommendationPopupShown",SportsExplorationPopupShown:"SportsExplorationPopupShown",SportsExplorationCardShown:"SportsExplorationCardShown",SportsEventBriefShown:"SportsEventBriefShown",SpotlightCardPreviewType:"SpotlightCardPreviewType",SpotlightCardEntityId:"SpotlightCardEntityId",SportsNewSpotlightCard:"SportsNewSpotlightCard",SportsCardType:"SportsCardType",SportsVideoSpotlightShown:"SportsVideoSpotlightShown",SportsNewSpotlightCountdown:"SportsNewSpotlightCountdown",SportsPinToDeskShown:"SportsPinToDeskShown",SportsDataV2:"SportsDataV2",SportsPinToDeskEdgeFeatureEnabled:"SportsPinToDeskEdgeFeatureEnabled",SportsNewSpotlightExploration:"SportsNewSpotlightExploration",SportsNewSpotlightTennis:"SportsNewSpotlightTennis",SportsNewSpotlightRace:"SportsNewSpotlightRace",SportsNewSpotlightGolf:"SportsNewSpotlightGolf",SportsCardCurrentTabId:"SportsCardCurrentTabId",SportsCardCopilotCurrentTabId:"SportsCardCopilotCurrentTabId",SportsStandingsRankings:"SportsStandingsRankings",SportsCardIsInViewPort:"SportsCardIsInViewPort",SportsNewSpotlightCricket:"SportsSpotlightCricket",SportsCardFirstTagName:"SportsCardFirstTagName",SportsRubyPillShown:"SportsRubyPillShown",SportsTournamentsList:"SportsTournamentsList"})},20517(t,e,i){i.d(e,{z(){return s}});var a=i(56911),r=i(60815),o=i(92011);class s extends o.L{}(0,a.Cg)([r.sH],s.prototype,"viewModel",void 0)},71372(t,e,i){i.d(e,{a(){return s}});var a=i(56911),r=i(92011),o=i(95144);let s=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,a.Cg)([o.x],s)},3628(t,e,i){i.r(e),i.d(e,{SportsGameLeaders(){return At}});var a=i(56911),r=i(20517);class o extends r.z{}var s=i(92011),n=i(61138),l=i(63033),p=i(74849);const c=p.A` :host{--secondary-font-color:#999999}`,d=p.A` :host{--secondary-font-color:#707070}`,g=p.A` :host{display:inline-block;width:100%}.game-leaders{display:grid;gap:12px}.category-row{display:grid;justify-items:center;gap:4px}.category-title{font-size:${n.k};line-height:${n.F};font-weight:400;color:var(--secondary-font-color)}.player-cards{width:100%;display:grid;grid-template-columns:1fr 1fr}`.withBehaviors(new l.N(d,c));var h=i(96950),u=i(39957),m=i(69259),y=i(60815),f=i(9960);const b=Object.freeze({default:"default",lite:"lite"}),v=Object.freeze({Stack:"stack",SideBySide:"side-by-side"});class x extends s.L{constructor(){super(),this.type=b.default,this.name="",this.fullName="",this.nameDetail="",this.description="",this.image="",this.isDarkMode=(0,f.ud)(),this.playerInfoRenderMode=v.Stack,this.isRuby=!1,this.isCopilot=!1,this.isMai=!1,this.imageClickHandler=()=>{this.redirectLink&&open(this.redirectLink,"_blank")},this.colorSchemeChangeHandler=this.colorSchemeChangeHandler.bind(this)}connectedCallback(){super.connectedCallback();const t=window.matchMedia("(prefers-color-scheme: dark)");t.addEventListener&&t.addEventListener("change",this.colorSchemeChangeHandler)}disconnectedCallback(){super.disconnectedCallback();window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change",this.colorSchemeChangeHandler)}colorSchemeChangeHandler(){this.isDarkMode=(0,f.ud)()}get playerNameInitials(){if(!this.name||!this.name.trim())return"";const t=this.name.trim().split(/\s+/);if(t.length<2)return this.name.charAt(0);const e=t[0],i=t[1];return`${e.charAt(0)}${i.charAt(0)}`}get playerNameAndNameDetailsCombined(){return[this.name,this.nameDetail].filter(Boolean).join(" ")}}(0,a.Cg)([y.sH],x.prototype,"type",void 0),(0,a.Cg)([y.sH],x.prototype,"name",void 0),(0,a.Cg)([y.sH],x.prototype,"fullName",void 0),(0,a.Cg)([y.sH],x.prototype,"nameDetail",void 0),(0,a.Cg)([y.sH],x.prototype,"playerNumber",void 0),(0,a.Cg)([y.sH],x.prototype,"description",void 0),(0,a.Cg)([y.sH],x.prototype,"image",void 0),(0,a.Cg)([y.sH],x.prototype,"teamColor",void 0),(0,a.Cg)([y.sH],x.prototype,"teamImage",void 0),(0,a.Cg)([y.sH],x.prototype,"injuryInfo",void 0),(0,a.Cg)([y.sH],x.prototype,"statistics",void 0),(0,a.Cg)([y.sH],x.prototype,"statisticsLabel",void 0),(0,a.Cg)([y.sH],x.prototype,"isDarkMode",void 0),(0,a.Cg)([y.sH],x.prototype,"playerInfoRenderMode",void 0),(0,a.Cg)([y.sH],x.prototype,"redirectLink",void 0),(0,a.Cg)([y.sH],x.prototype,"isPlayerImageAvailable",void 0),(0,a.Cg)([y.sH],x.prototype,"columnLayout",void 0),(0,a.Cg)([y.sH],x.prototype,"isRuby",void 0),(0,a.Cg)([y.sH],x.prototype,"isCopilot",void 0),(0,a.Cg)([y.sH],x.prototype,"isMai",void 0);var w=i(22683),$=i(41123),S=i(43774),k=i(62047),T=i(37302),C=i(24458),z=i(89580),F=i(64003),M=i(22131),_=i(68136);_.G.create("cricket-win-color"),_.G.create("copilot-header-color"),_.G.create("ruby-border-radius"),_.G.create("copilot-container-fill-color"),_.G.create("sp-container-1-col-width"),_.G.create("sp-container-mobile-width"),_.G.create("sp-container-flyout-width"),_.G.create("sp-container-2-col-width"),_.G.create("sp-container-3-col-width"),_.G.create("sp-container-4-col-width"),_.G.create("sp-container-padding"),_.G.create("sp-container-one-col-padding"),_.G.create("sp-container-mobile-padding"),_.G.create("sp-container-margin"),_.G.create("sp-container-one-col-margin"),_.G.create("sp-container-mobile-margin"),_.G.create("sp-container-corner-radius"),_.G.create("sp-container-one-col-corner-radius"),_.G.create("sp-content-row-gap"),_.G.create("sp-content-row-gap-one-col"),_.G.create("sp-content-row-gap-mobile"),_.G.create("sp-content-column-gap"),_.G.create("sp-content-column-gap-one-col"),_.G.create("sp-content-column-gap-mobile"),_.G.create("sp-vertical-container-margin-bottom"),_.G.create("sp-vertical-container-margin-bottom-one-col"),_.G.create("sp-vertical-container-margin-bottom-mobile"),_.G.create("sp-container-title-margin"),_.G.create("sp-container-title-one-col-margin"),_.G.create("sp-container-title-mobile-margin"),_.G.create("sp-scroll-proxy-container-margin"),_.G.create("sp-scroll-proxy-container-one-col-margin"),_.G.create("sp-scores-schedule-container-padding"),_.G.create("sp-scores-schedule-container-one-col-padding"),_.G.create("sp-scores-schedule-container-mobile-padding"),_.G.create("sp-game-summary-container-padding"),_.G.create("sp-game-summary-container-one-col-padding"),_.G.create("sp-game-summary-container-mobile-padding"),_.G.create("sp-cricket-rankings-container-header-padding"),_.G.create("sp-cricket-rankings-container-header-one-col-padding"),_.G.create("sp-cricket-rankings-container-header-mobile-padding");const D=_.G.create("sp-text-base-font-size"),E=(_.G.create("sp-text-minus-1-font-size"),_.G.create("sp-text-minus-2-font-size"),_.G.create("sp-text-minus-3-font-size"),_.G.create("sp-text-plus-1-font-size")),P=(_.G.create("sp-text-plus-2-font-size"),_.G.create("sp-text-plus-3-font-size"),_.G.create("sp-text-plus-4-font-size"),_.G.create("sp-text-plus-5-font-size"),_.G.create("sp-text-minus-1-line-height"),_.G.create("sp-text-minus-2-line-height"),_.G.create("sp-text-minus-3-line-height"),_.G.create("sp-text-base-line-height")),B=(_.G.create("sp-text-plus-1-line-height"),_.G.create("sp-text-plus-2-line-height"),_.G.create("sp-font-color")),R=_.G.create("sp-font-color-sub"),A=(_.G.create("sp-cr-font-color-sub"),_.G.create("sp-mai-background-color"),_.G.create("section-header-color"),_.G.create("sp-cr-top-border-color"),_.G.create("sp-cr-live-color-lll"),_.G.create("sp-cr-live-color-ll"),_.G.create("sp-cr-live-color-l"),_.G.create("sp-cr-live-color"),_.G.create("sp-cr-delayed-color"),_.G.create("sp-copilot-divider-color"),_.G.create("sp-copilot-divider-border"),_.G.create("sp-tab-hover-background-color"),_.G.create("sp-tab-pressed-background-color"),_.G.create("sp-tab-pressed-font-color"),_.G.create("sp-button-hover-background-color"),_.G.create("sp-button-pressed-background-color"),_.G.create("sp-button-pressed-font-color"),_.G.create("sp-button-second-hover-background-color"),_.G.create("sp-button-second-pressed-background-color"),_.G.create("sp-button-second-pressed-font-color"),p.A`
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        white-space: nowrap;
        border-width: 0;
        clip-path: inset(100%);
    }

    .ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @supports (-webkit-line-clamp: 2) {
        .ellipsis.with-2-lines {
            white-space: normal;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    }
`),I=p.A` :host{--ruby-player-round-bg:rgba(255,255,255,5%);--ruby-player-team-shadow:#000000;--ruby-player-team-bg:#F6F9FC;--ruby-player-name-color:#FFFFFF;--ruby-stat-val-color:#FFFFFF;--ruby-player-desc-color:${R};--ruby-lite-round-bg:rgba(255,255,255,0.05);--ruby-copilot-lite-round-bg:rgba(157,168,217,0.05);--player-initials-bg:#6D585B;--player-initials-color:#F2DDCC}`,j=p.A` :host{--ruby-player-round-bg:rgba(0,0,0,5%);--ruby-player-team-shadow:#FFFFFF;--ruby-player-team-bg:#23272B;--ruby-player-name-color:#23272B;--ruby-stat-val-color:#23272B;--ruby-player-desc-color:${R};--ruby-lite-round-bg:rgba(0,0,0,0.05);--ruby-copilot-lite-round-bg:rgba(204,196,192,0.2);--player-initials-bg:#FFD79C;--player-initials-color:#33302E}`,O=p.A` .ruby .player-desc-wrapper .player-desc,.sports-player-card.lite.ruby.copilot .player-info .player-name{forced-color-adjust:auto}`,L=p.A` ${A} :host{display:inline-block;width:100%;border-bottom:1px solid ${w.hb}}.sports-player-card{object-fit:cover;width:100%;height:100%}.ruby.sports-player-card{column-gap:16px}.ruby.copilot.sports-player-card{column-gap:12px}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-info,.injury-info,.player-stat{flex-direction:column}.sports-player-card{display:flex;align-items:flex-start}.sports-player-card.lite{display:flex;align-items:center}.sports-player-card.lite .player-image{align-items:center}.sports-player-card .player-image{display:flex;flex-direction:row;height:100%}.sports-player-card .player-image .player-image-info{display:flex;flex-direction:column;justify-content:space-between;align-items:center}.player-image .player-image-info .player-info-team{height:${$.Z};width:${$.Z}}.player-image .player-image-info .player-info-number{font-size:${n.k};line-height:${n.F};color:${S.ls}}.player-image .player-image-info .player-info-number-small{font-size:${k.t};line-height:${k.e}}.sports-player-card .player-image .player-round-image{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${T.X4};overflow:hidden}.sports-player-card .player-image .player-round-image-clickable{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${T.X4};overflow:hidden;cursor:pointer}.sports-player-card .player-image .player-round-image,.sports-player-card .player-image .player-round-image-clickable{width:65px;height:65px}.sports-player-card.lite .player-image .player-round-image,.sports-player-card.lite .player-image .player-round-image-clickable{width:36px;height:36px}.sports-player-card .player-image .player-icon{height:100%;width:100%}.sports-player-card .player-image .player-image-link{width:100%;position:absolute;bottom:0;display:flex;justify-content:center;align-items:center;background:rgba(0,0,0,0.44);backdrop-filter:blur(1px)}.player-image-link image{fill:${C.m_}}.player-info{width:60%;flex-direction:column;padding:5px 15px 0 15px}.sports-player-card.lite .player-info{padding:5px}.player-info .player-name{font-size:${$.K};line-height:${$.Z};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.ruby .player-info .player-name{font-size:${z.Y};line-height:24px;font-weight:550;color:var(--ruby-player-name-color)}.sports-player-card.lite.ruby .player-info .player-name{font-size:${$.K}}.sports-player-card.lite.ruby.copilot .player-info .player-name{font-size:${D};line-height:${P};font-weight:410;color:${B}}.player-info .player-name .name-detail{font-weight:400;color:${F.c}}.sports-player-card .player-info{width:100%;min-width:0;flex-direction:column;display:flex;align-items:flex-start;padding:0 12px}.ruby.sports-player-card .player-info{width:unset;flex-grow:1;padding:0}.ruby.copilot.sports-player-card .player-info{width:calc(100% - 48px);align-items:unset;gap:2px}.sports-player-card .player-info .player-stats{width:100%;display:flex;justify-content:space-between;text-align:center}.sports-player-card .player-info .player-stats .player-stat{display:flex;flex-direction:column;align-items:flex-start}.sports-player-card.lite .player-info .player-name{font-size:${$.K}}.player-info .player-desc{font-size:${k.t};line-height:${k.e};color:${S.ls};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.injury-info,.player-stats{line-height:${$.Z};font-size:${$.K}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${z.Y};height:${z.Y};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-between;text-align:center}.stat-val,.injury-status{font-weight:600;font-size:${$.K};line-height:${$.Z}}.stat-title{font-size:${n.k};line-height:${n.F};color:${S.ls}}.ruby.sports-player-card{align-items:center}.ruby-player-image{position:relative;width:80px;height:80px}.layout-1 .ruby-player-image{width:60px;height:60px}.ruby-player-image.only-team-image,.layout-1 .ruby-player-image.only-team-image{align-self:flex-start;width:24px;height:24px}.ruby-player-round-image{width:100%;height:100%;background-color:var(--ruby-player-round-bg);border-radius:50%}.ruby-player-team-image{position:absolute;right:2px;bottom:2px;width:24px;height:24px;box-shadow:0 0 0 2px var(--ruby-player-team-shadow);background-color:var(--ruby-player-team-bg);border-radius:50%}.layout-1 .ruby-player-team-image{width:20px;height:20px}.player-desc-wrapper{display:flex;max-width:100%}.ruby .player-desc-wrapper{gap:8px}.ruby .player-desc-wrapper .player-info-number{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby.lite.copilot .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z}}.ruby .player-stats{margin-top:8px}.layout-1.ruby .player-stats{margin-top:4px}.ruby .player-stat{flex:1 1 0}.ruby .player-stat:last-child{flex:0 1 42px}.ruby.layout-2 .player-stat:last-child{flex:1 1 0}.ruby .stat-val{font-size:${z.Y};line-height:24px;font-weight:550;color:var(--ruby-stat-val-color)}.ruby .stat-title{font-weight:550;color:var(--ruby-player-desc-color)}.layout-4.ruby .stat-title{font-size:${$.K};line-height:${$.Z}}.ruby.lite.layout-4 .player-info .player-name{font-size:${z.Y};line-height:${z.v}}.ruby.lite.layout-4 .player-info .player-desc-wrapper{font-size:${$.K};line-height:${$.Z}}.ruby.lite .player-image .player-round-image,.ruby.lite .player-image .player-round-image-clickable{background:var(--ruby-lite-round-bg)}.ruby.copilot.lite .player-image .player-round-image,.ruby.copilot.lite .player-image .player-round-image-clickable{background:var(--ruby-copilot-lite-round-bg)}.ruby.lite.layout-4 .player-image .player-round-image,.ruby.lite.layout-4 .player-image .player-round-image-clickable{height:40px;width:40px}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--background-color,--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${E};line-height:${P};font-weight:400;letter-spacing:-0.01em;color:var(--font-color,--player-initials-color)}.layout-1 .player-initials > span{font-size:${D}}`.withBehaviors(new l.N(j,I),(0,M.mr)(O)),H=h.qy`
    <div class="injury-info">
        <span class="injury-status">
            ${(0,m.z)(t=>t.injuryInfo?.statusIconColor,h.qy`
                <i class="status-icon" style="background: ${t=>t.isDarkMode?t.injuryInfo?.statusIconColor?.dark:t.injuryInfo?.statusIconColor?.primary}"></i>
            `)}
            <span class="status-text" title="${t=>t.injuryInfo?.status}">
                ${t=>t.injuryInfo?.status}
            </span>
        </span>
        ${(0,m.z)(t=>t.injuryInfo?.injuryArea,h.qy`
            <span class="injury-area">${t=>t.injuryInfo?.injuryArea}</span>
        `)}
    </div>
`;var N=i(32150),V=i(65119);const G=`${(0,N.rA)().StaticsUrl}/latest/sports/icons/SportsImageExplorer.svg`,U=h.qy`
    <div class="player-stats">
        ${(0,u.ux)(t=>t.statistics,h.qy`
            <div class="player-stat">
                <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                    <span class="stat-title" title="${t=>t.title}">${t=>t.abbreviation}</span>
                `)}
            </div>
        `)}
    </div>
`,W=h.qy`
    <div class="player-image">
        ${(0,m.z)(t=>t.type===b.default,h.qy`
            <div class="player-image-info">
                ${(0,m.z)(t=>t.teamImage,h.qy`
                    <img class="player-info-team" loading="lazy" role="presentation" src="${t=>t.teamImage||" "}" />
                `)}
                ${(0,m.z)(t=>t.playerNumber,h.qy`
                    <span class="${t=>t.isPlayerImageAvailable?"player-info-number":"player-info-number-small"}">
                        #${t=>t.playerNumber}
                    </span>
                `)}
            </div>
        `)}
        ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
            <div 
                class="${t=>t.redirectLink?"player-round-image-clickable":"player-round-image"}" 
                @click=${t=>t.imageClickHandler()}
            >
                ${(0,m.z)(t=>t.image&&""!==t.image,h.qy`
                    <img class="player-icon" loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}" />
                `,h.qy`
                    <span class="sr-only">${t=>t.fullName||t.name}</span>
                    <div
                        class="player-initials"
                        title=${t=>t.fullName||t.name}
                        aria-hidden="true"
                    >
                        <span>${t=>t.playerNameInitials}</span>
                    </div>
                `)}
                ${(0,m.z)(t=>t.redirectLink,h.qy`
                    <div class="player-image-link">
                        <img src=${G} alt="sportsImageExplorerIcon" loading="lazy" aria-hidden="true" />
                    </div>
                `)}
            </div>
        `)}
    </div>
`,Y=h.qy`
    <img class="ruby-player-round-image" loading="lazy" src=${t=>(0,V.OY)(V.UU,V.Bk)} alt=${t=>t.fullName||t.name} />
`,X=h.qy`
    ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
        <div class="ruby-player-image" @click=${t=>t.imageClickHandler()}>
            <img class="ruby-player-round-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
            ${(0,m.z)(t=>t.teamImage,h.qy`
                <img class="ruby-player-team-image" loading="lazy" role="presentation" src=${t=>t.teamImage} />
            `)}
        </div>
    `,h.qy`
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <div class="ruby-player-image only-team-image" @click=${t=>t.imageClickHandler()}>
                <img class="ruby-player-round-image" loading="lazy" src=${t=>t.teamImage} alt=${t=>t.fullName||t.name} />
            </div>
        `,Y)}
    `)}
`,q=h.qy`
    <div class="sports-player-card ${t=>t.type} ${t=>t.columnLayout?`layout-${t.columnLayout}`:""} ${t=>t.isRuby?"ruby":""} ${t=>t.isCopilot?"copilot":""}">
        ${(0,m.z)(t=>t.isRuby&&t.type!==b.lite,X,W)}
        <div class="player-info">
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <span
                class="player-name"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                ${t=>t.name}
                <span class="name-detail"> ${t=>t.nameDetail}</span>
            </span>
            <div class="player-desc-wrapper">
                ${(0,m.z)(t=>t.playerNumber&&t.isRuby,h.qy`<span class="player-info-number">#${t=>t.playerNumber}</span>`)}
                <span class="player-desc">${t=>t.description}</span>
            </div>
            ${(0,m.z)(t=>t.injuryInfo,H)}
            ${(0,m.z)(t=>t.statistics?.length,U)}
        </div>
    </div>
`;var J=i(36452);const K=p.A` ${A} :host{display:inline-block;width:100%}.sports-player-card{object-fit:cover;width:100%;height:100%;flex-direction:column;align-items:center}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-stats{flex-direction:row}.player-info,.injury-info,.player-stat{flex-direction:column}.player-stat{margin-inline-start:6px}.player-image{padding-bottom:5px;position:relative}.sports-player-card.grid-card .player-image{padding-bottom:0;align-items:center}.player-image img{width:40px;height:40px;border-radius:50px;border:1px solid ${J.I2}}.sports-player-card.grid-card .player-image img{width:36px;height:36px;border-radius:50%;background:unset;border:1px solid ${T.X4}}.player-image{bottom:5px;border-end-start-radius:5px;padding:2px 0}.player-info{width:60%;flex-direction:column;align-items:center}.player-info-text-content{flex-direction:column;align-items:center;display:flex}.sports-player-card.grid-card .player-info{padding:5px}.player-info .player-name{font-size:${n.k};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center}.player-desc{overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center;white-space:nowrap}.player-info .player-desc{font-size:${k.t};line-height:${k.e}}.injury-info,.player-stats{line-height:${k.e};font-size:${k.t}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${k.t};height:${k.e};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-around;text-align:center;width:100px}.stat-val,.injury-status{font-weight:600;font-size:${n.k}}.stat-title,.player-desc{color:${S.ls}}.sports-player-card.side-by-side{flex-direction:row}.sports-player-card.side-by-side .player-info{flex-direction:row;width:100%}.sports-player-card.side-by-side .player-info .player-info-text-content{margin-inline-start:10px}.sports-player-card.side-by-side .player-info .player-name{text-align:unset}.sports-player-card.side-by-side .player-image{bottom:unset}.sports-player-card.side-by-side .player-info .player-name{text-align:unset;width:150px}.sports-player-card.side-by-side .player-desc{text-align:unset;width:150px}.sports-player-card.side-by-side .injury-status .status-icon{height:7px;width:7px}.sports-player-card.side-by-side .injury-status .injury-info{padding-inline-start:10px}`.withBehaviors(),Z=h.qy`
    <div class="player-stats">
        ${(0,u.ux)(t=>t.statistics,h.qy`
            ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                <div class="player-stat">
                    <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                    <span class="stat-title" title="${t=>t.title??t.abbreviation}">${t=>t.abbreviation}</span>
                </div>
            `)}
        `)}
    </div>
`,Q=h.qy`
    <div class="sports-player-card ${t=>t.type} ${t=>t.playerInfoRenderMode==v.SideBySide?"side-by-side":""}">
        <div class="player-image">
            <img loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}">
        </div>
        <div class="player-info">
            <div class="player-info-text-content">
                <span class="sr-only">${t=>t.fullName||t.name}</span>
                <span class="player-name" title="${t=>t.fullName||t.name}" aria-hidden="true">${t=>t.name}</span>
                <span class="player-desc">${t=>t.description+" "}
                    <span> ${t=>null==t.playerNumber?"":"#"+t.playerNumber}</span>
                </span>
            </div>
            ${(0,m.z)(t=>t.injuryInfo,H)}
            ${(0,m.z)(t=>t.statistics?.length,Z)}
        </div>
    </div>
`,tt=p.A` :host{--secondary-font-color:#999999;--image-border-color:#666666}`,et=p.A` :host{--secondary-font-color:#707070;--image-border-color:#D1D1D1}`,it=p.A` ${A} :host{display:inline-block;width:100%;min-width:0}.sports-player-card{display:grid;grid-template-columns:max-content auto;align-items:center;gap:6px}.player-round-image{object-fit:cover;border-radius:50%;overflow:hidden}.image-border{border:1px solid var(--image-border-color)}.player-icon{width:36px;height:36px;display:block}.player-info{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-width:0}.player-name{font-weight:600;text-align:left;max-width:96px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:20px;font-size:${$.K};line-height:${$.Z};max-width:100%}.player-stats{display:flex;flex-wrap:nowrap;font-size:12px;height:20px;gap:2px;display:flex;align-items:center}.player-stats-vals{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.player-stats-titles{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.stat-val{font-weight:600}.stat-title{font-weight:400;color:var(--secondary-font-color)}`.withBehaviors(new l.N(et,tt)),at=h.qy`
    <div class="player-stats">
        <div class="player-stats-vals">
            ${(0,u.ux)(t=>t.statistics,h.qy`
                <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                ${(0,m.z)((t,e)=>!e.isLast,h.qy`-`)}
            `,{positioning:!0})}
        </div>
        <div class="player-stats-titles">
            ${(0,u.ux)(t=>t.statistics,h.qy`
                ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                    <span class="stat-title" title="${t=>t.title}">${t=>t.abbreviation}</span>
                `)}
                ${(0,m.z)((t,e)=>!e.isLast,h.qy`<span class="stat-title">-</span>`)}        
            `,{positioning:!0})}
        </div>
    </div>
`,rt=h.qy`
<div class="sports-player-card ${t=>t.type}">
    ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
        <div class="player-round-image ${t=>t.teamColor?"image-border":""}" style="background-color:${t=>t.teamColor};">
            <img class="player-icon" loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}">
        </div>
    `)}
    <div class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span class="player-name" title="${t=>t.fullName||t.name}" aria-hidden="true">
            ${t=>t.name}
        </span>
        ${(0,m.z)(t=>t.statistics?.length,at)}
    </div>
</div>
`;var ot=i(37079),st=i(62198),nt=i(32257);const lt=p.A` .player-image,.player-stats{background-color:#9DA8D90D}.player-initials{background-color:#6D585B}.team-logo{box-shadow:0 0 0 2px #282F42;background-color:#282F42}`,pt=p.A` .player-image,.player-stats{background-color:#CCC4C033}.player-initials{background-color:#FFD79C}.team-logo{box-shadow:0 0 0 2px #F4EFED;background-color:#F4EFED}`,ct=p.A` ${A} .sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;flex-direction:column;align-items:center;width:100%;row-gap:12px;text-align:center}.layout-1.sports-player-card{row-gap:8px}.player-image-container{position:relative;width:90px;height:90px}.player-image{width:100%;height:100%;border-radius:50%}.mai .player-image{background-color:${nt.GEK}}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:50%}.player-initials > span{font-size:${ot.F};line-height:${st.b};font-weight:400;letter-spacing:-0.01em;color:${B}}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;border-radius:50%}.mai .team-logo{box-shadow:0 0 0 2px ${nt.GEK};background-color:${nt.GEK}}.player-info{display:flex;flex-direction:column;align-items:center;width:100%;padding-inline:4px}.player-name{width:100%;font-size:15px;line-height:${$.Z};font-weight:700;color:${B};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{width:100%;font-size:${n.k};line-height:${n.F};font-weight:650;color:${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px}.mai .player-stats{border-radius:${nt.g6L};background-color:${nt.GEK}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${B};white-space:nowrap}.stat-title{display:block;font-size:${k.t};line-height:${k.e};font-weight:700;color:${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new l.N(pt,lt));var dt=i(46763),gt=i(46187);const ht=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(t=>t.isPlayerImageAvailable&&t.image&&!t.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
        `,h.qy`
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <div
                class="player-initials"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                <span>${t=>t.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${t=>t.teamImage} alt="" />
        `)}
    </div>
`,ut=h.qy`
    <header class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span
            id=${t=>`header-${t.id}`}
            class="player-name"
            title=${t=>t.fullName||t.name}
            aria-hidden="true"
        >
            ${t=>t.name}
        </span>
        <span class="player-description">
            ${t=>t.playerNumber?`#${t.playerNumber} ${t.description}`:`${t.description}`}
        </span>
    </header>
`,mt=h.qy`
    ${(0,m.z)(t=>t.abbreviation&&t.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${t=>`${t.value} ${t.title}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${t=>t.value}
            </span>
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        </div>
    `)}
`,yt=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${t=>`${t.value} ${t.title}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${t=>t.value}
        </span>
        ${(0,m.z)(t=>t.abbreviation,h.qy`
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        `)}
    </div>
`,ft=h.qy`
    <div class="sports-player-card ${t=>t.isMai?"mai":""} layout-${t=>t.columnLayout}" role="article" aria-labelledby=${t=>t.id?`header-${t.id}`:""}>
        ${ht}
        ${ut}
        <div class="player-stats" role="list" aria-label=${t=>t.statisticsLabel||""}>
            ${(0,u.ux)(t=>t.statistics,h.qy`
                ${(0,m.z)(t=>dt.Nx?.Sport===gt.zv.soccer,mt,yt)}
            `)}
        </div>
    </div>
`;var bt=i(25975);const vt=p.A` :host{--player-initials-bg:#6D585B}`,xt=p.A` :host{--player-initials-bg:#FFD79C}`,wt=p.A` ${A} :host{--player-image-bg:${nt.GEK};--player-stats-bg:${nt.GEK};--player-initials-color:${B};--team-logo-shadow:${nt.GEK};--team-logo-bg:${nt.GEK}}.sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;align-items:flex-start;width:100%;gap:12px}.layout-1.sports-player-card{gap:8px}.player-content{flex:1;min-width:0;display:flex;flex-direction:column;gap:12px}.layout-1 .player-content{gap:8px}.player-image-container{position:relative;flex:0 0 80px;width:80px;height:80px}.player-image{width:100%;height:100%;background-color:var(--player-image-bg);border-radius:50%}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${ot.F};line-height:${st.b};font-weight:400;letter-spacing:-0.01em;color:var(--player-initials-color)}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;box-shadow:0 0 0 2px var(--team-logo-shadow);background-color:var(--team-logo-bg);border-radius:50%}.player-info{display:flex;flex-direction:row;align-items:center;justify-content:space-between;width:100%;gap:4px}.player-name{flex:0 0 auto;min-width:0;max-width:75%;font-size:15px;line-height:${$.Z};font-weight:700;color:${B};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{flex:1 1 auto;min-width:0;font-size:${n.k};line-height:${n.F};font-weight:650;color:${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px;background-color:var(--player-stats-bg)}@supports (corner-shape:squircle){.player-stats{border-radius:calc(12px * ${bt.MU6});corner-shape:squircle}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${B};white-space:nowrap}.stat-title{display:block;font-size:${k.t};line-height:${k.e};font-weight:700;color:${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new l.N(xt,vt)),$t=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(t=>t.isPlayerImageAvailable&&t.image&&!t.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
        `,h.qy`
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <div
                class="player-initials"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                <span>${t=>t.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${t=>t.teamImage} alt="" />
        `)}
    </div>
`,St=h.qy`
    <header class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span
            id=${t=>`header-${t.id}`}
            class="player-name"
            title=${t=>t.fullName||t.name}
            aria-hidden="true"
        >
            ${t=>t.name}
        </span>
        <span class="player-description">
            ${t=>t.playerNumber?`#${t.playerNumber} ${t.description}`:`${t.description}`}
        </span>
    </header>
`,kt=h.qy`
    ${(0,m.z)(t=>t.abbreviation&&t.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${t=>t.title?`${t.value} ${t.title}`:`${t.value}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${t=>t.value}
            </span>
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        </div>
    `)}
`,Tt=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${t=>t.title?`${t.value} ${t.title}`:`${t.value}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${t=>t.value}
        </span>
        ${(0,m.z)(t=>t.abbreviation,h.qy`
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        `)}
    </div>
`,Ct=h.qy`
    <div class="sports-player-card layout-${t=>t.columnLayout}" role="article" aria-labelledby=${t=>t.id?`header-${t.id}`:""}>
        ${$t}
        <div class="player-content">
            ${St}
            <div class="player-stats" role="list" aria-label=${t=>t.statisticsLabel||""}>
                ${(0,u.ux)(t=>t.statistics,h.qy`
                    ${(0,m.z)(t=>dt.Nx?.Sport===gt.zv.soccer,kt,Tt)}
                `)}
            </div>
        </div>
    </div>
`;let zt=class extends x{};zt=(0,a.Cg)([(0,s.E)({name:"sports-player-card",template:q,styles:L})],zt);let Ft=class extends x{};Ft=(0,a.Cg)([(0,s.E)({name:"sports-player-card-v2",template:Q,styles:K})],Ft);let Mt=class extends x{};Mt=(0,a.Cg)([(0,s.E)({name:"sports-player-card-v3",template:rt,styles:it})],Mt);let _t=class extends x{};_t=(0,a.Cg)([(0,s.E)({name:"sports-player-card-copilot",template:ft,styles:ct})],_t);let Dt=class extends x{};Dt=(0,a.Cg)([(0,s.E)({name:"sports-player-card-mai",template:Ct,styles:wt})],Dt);const Et=h.qy`
    <sports-player-card-v3
        class="player-card"
        :type=${t=>b.default}
        :name=${t=>t.playerName}
        :playerNumber=${t=>t.playerNumber}
        :image=${t=>t.playerImage}
        :teamColor=${t=>t.teamColor}
        :teamImage=${t=>t.playerImage}
        :isPlayerImageAvailable=${t=>t.playerImage}
        :statistics=${t=>t.playerStats}>
    </sports-player-card-v3>
`,Pt=h.qy`
    <div class="category-row">
        <div class="category-title">
            ${t=>t.categoryTitle}
        </div>
        <div class="player-cards">
            ${(0,u.ux)(t=>t.players,Et)}
        </div>
    </div>
`,Bt=h.qy`
    <div class="game-leaders">
        ${(0,u.ux)(t=>t.viewModel.sportsGameLeaders.categories,Pt,{positioning:!0})}
    </div>
`,Rt=h.qy`
    ${(0,m.z)(t=>null!=t.viewModel,Bt)}
`;let At=class extends o{};At=(0,a.Cg)([(0,s.E)({name:"sports-game-leaders",template:Rt,styles:g,shadowOptions:{delegatesFocus:!0}})],At)},61618(t,e,i){i.r(e),i.d(e,{SportsGameStats(){return D}});var a=i(56911),r=i(20517),o=i(83546),s=i(60815);class n extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,o.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,a.Cg)([s.sH],n.prototype,"isMitUx",void 0);var l=i(92011),p=i(86856),c=i(63033),d=i(74849),g=i(4126),h=i(22131);const u=d.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,m=d.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,y=d.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,f=d.A` .game-stats-item-content{transform:scaleX(-1)}`,b=d.A` .game-stats-list{background:var(--button-light-rest)}.game-stats-item-header > span:nth-child(2){font-weight:550}@media (prefers-color-scheme:dark){.game-stats-list{background-color:#00000040}.game-stats-item{color:#fff}.game-stats-title{color:#fff}}`,v=d.A` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new p.t(null,f),new c.N(y,m),new g.o("isAdaptiveThemeEnabled",!0,u),new g.o("isMitUx",!0,b),(0,h.mr)(d.A` :host{forced-color-adjust:auto}`));var x=i(96950),w=i(69259),$=i(39957);const S=x.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,k=x.qy`
    <div class="team-container">
        ${(0,w.z)((t,e)=>0!==e.index,x.qy`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,w.z)((t,e)=>0===e.index,x.qy`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,T=x.qy`
    <div class="game-team-icons">
        ${(0,$.ux)(t=>t.viewModel.participants,k,{positioning:!0})}
    </div>
`,C=x.qy`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,z=x.qy`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,w.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,T)}
        ${(0,w.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,C)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,$.ux)(t=>t.viewModel.sportsGameStats,S)}
        </div>
    </div>
`,F=x.qy`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,$.ux)(t=>t.viewModel.sportsGameStats,x.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,M=x.qy`${t=>t.viewModel?.isCopilotTheme?F:z}`,_=x.qy`
    ${(0,w.z)(t=>null!=t.viewModel,M)}
`;let D=class extends n{};D=(0,a.Cg)([(0,l.E)({name:"sports-game-stats",template:_,styles:v,shadowOptions:{delegatesFocus:!0}})],D)},80195(t,e,i){i.r(e),i.d(e,{SportsMatch(){return lt}});var a=i(56911),r=i(52921),o=i(60815),s=i(20517);class n extends s.z{constructor(){super(...arguments),this.isMitUx=!1,this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(t,e,i,a){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const o="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,r.LE)(t.currentTarget,o,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,a)}}}(0,a.Cg)([o.sH],n.prototype,"isMitUx",void 0);var l=i(92011),p=i(48751),c=i(62047),d=i(61138),g=i(41123),h=i(71157),u=i(62198),m=i(4283),y=i(70289),f=i(63033),b=i(50882),v=i(74849),x=i(4126),w=i(22131);const $="#CD3800",S="#E98F6D",k=v.A` .date,.nodate{width:auto}`,T=v.A` .sports-match{background-color:rgba(255,255,255,0.7);border-radius:8px;padding:7px 5px;gap:23px;justify-content:center;height:66px;box-sizing:border-box}.side-by-side-matchup-content{width:242px}.side-by-side-gradient-container{background-image:none !important}.participant-container{height:52px;justify-content:center;align-items:center;width:74px}.participant-icon,.participant-icon.logo-backplate{width:45px;height:45px}.participant-container .logo-backplate.participant-icon-large img{width:45px;height:45px}.game-in-progress-text{color:#1A1A1A}@media (prefers-color-scheme:dark){.sports-match{background-color:#00000040}}`,C=v.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${S}}.game-in-progress-text{color:${S}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${S};background-color:${S}}.standings-style{color:${p.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,z=v.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${y.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${p.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${p.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${p.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${p.l};font-size:${c.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${p.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${p.l}}.foreground-rest-text-color{color:${p.l}}.top-game-detail{color:${p.l};font-size:${c.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${p.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${p.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${d.k};line-height:${d.F};color:${p.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${g.K};line-height:${g.Z};font-weight:600;color:${p.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${p.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${$};font-size:${d.k};line-height:${d.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${$};font-size:${c.t}}.participant-name-style{font-size:${d.k};line-height:${d.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${h.T};line-height:${h.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${d.k};line-height:${d.F};max-width:100px}.game-score-notification-text-style{font-size:${h.T};line-height:${h.O}}.game-score-text-style{color:${p.l};line-height:${h.O};font-size:${u.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${$};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${p.l};font-size:${c.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${c.t};line-height:${c.e};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${p.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${g.K};line-height:${g.Z};font-weight:900;color:${p.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${d.k};line-height:${d.F};font-weight:600;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${m.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${$};width:16px;height:0;left:126px;top:20px;position:absolute;background-color:${$}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${p.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${p.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${p.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${y.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new f.N(null,C),(0,w.mr)(v.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${b.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${b.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${b.A.LinkText}}.click-for-detail{border:1px solid;background-color:${b.A.LinkText}}.detail-live-animation{background-color:${b.A.LinkText}}.scores-line{overflow:hidden}}`),new x.o("isWindowsCopilot",!0,k),new x.o("isMitUx",!0,T));var F=i(11796),M=i(50180),_=i(96950),D=i(69259),E=i(36516),P=i(10500),B='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const R=(t,e)=>_.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,M.GP)(e?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",t.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:F.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:F.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${t=>t.viewModel?.followTelemetryTag}"
    >
        <div class="${t=>e?"icon-add":"icon-selected"}"> ${_.qy.partial(e?E.A:P.A)}</div>
    </div>
`,A=_.qy`
    <div class="game-details">
        ${_.qy`<div class="top-game-detail">${t=>t.viewModel.topDetailText}</div>`}
        ${t=>((t,e,i=null,a=null)=>{switch(t.getMatchData().gameStateCatetory){case F.Xp.preGame:return null==i?Q():tt(i);case F.Xp.inprogressGame:return ot();case F.Xp.postGame:return e?rt():(0,M.oT)(t.viewModel.topDetailText)?it(a||""):at();default:return Q()}})(t,t.viewModel.shouldShowChampionPostGame,t.viewModel.preGameNotificationMessage,t.viewModel.postGameNotificationMessage)}
    </div>
`,I=_.qy`
    <div class="${t=>t.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${A}
        ${t=>L(t.getMatchData().additionalInfo)}
    </div>
`,j=()=>_.qy`
    <div class="g-dtl ${t=>t.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame?V:""}
            ${t=>t.getMatchData().gameStateCatetory===F.Xp.postGame?G:""}
            <div class="kscr-cntr">
                <span class="kscr ${t=>t.getMatchData().participantOne?.isWinner?"winner-team":""} part-left">
                    ${(0,D.z)(t=>t.getMatchData().participantOne?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(B)}</span>`)}
                    ${t=>t.getMatchData().participantOne?.score??""}
                </span>
                ${t=>(0,M.oT)(t.getMatchData().participantOne?.score||"")||(0,M.oT)(t.getMatchData().participantTwo?.score||"")?"":H}
                <span class="kscr ${t=>t.getMatchData().participantTwo?.isWinner?"winner-team":""}">
                    ${t=>t.getMatchData().participantTwo?.score??""}
                    ${(0,D.z)(t=>t.getMatchData().participantTwo?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(B)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,O=()=>_.qy`
    <div class="date">
        <div class="prehdr">${t=>t.viewModel.headerText?.rightHeaderText}</div>
        <div class="ktime">${t=>t.getMatchData().gameStartTime}</div>
    </div>
`,L=t=>t?_.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${t.round||""}
                </div>
                <div class="round-summary-info">
                    ${t.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${t.scores}
                </div>
            </div>
        `:null,H=_.qy`
    <span class="scores-line">${_.qy.partial(F.Z5)}</span>
`,N=_.qy`
    <span>${_.qy.partial("·")}</span>
`,V=_.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${t=>t.viewModel.liveIconUrl}" />
        <span class="r-live-text">${F.T0.Live}</span>
    </div>
`,G=_.qy`
    <div class="pghdr">
        <span>${F.T0.Final}</span>
        ${t=>t.getMatchData().gameDate?N:""}
        <span>${t=>t.getMatchData().gameDate}</span>
    </div>
`,U=_.qy`
    <div class="vert-noline">
        <div class="vert-header ${t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame?"in-prog-vert":""}">
            ${t=>t.viewModel.headerText?.header}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>t.getMatchData().participantOne?.name}">
                        ${t=>t.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===F.Xp.preGame?"standings-style":""}">${t=>t.viewModel.headerText?.topScoreText}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>t.getMatchData().participantTwo?.name}">
                        ${t=>t.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===F.Xp.preGame?"standings-style":""}">${t=>t.viewModel.headerText?.bottomScoreText}</div>
            </div>
        </div>
    </div>
`,W=_.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>t.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>t.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${t=>t.viewModel.headerText?.leftHeaderText}</div>
            <div>${t=>t.viewModel.headerText?.rightHeaderText}</div>
        </div>
    </div>
`,Y=_.qy`
    ${t=>t.viewModel.isSpotlightCard?J:q}
`,X=_.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>t.getMatchData().participantOne?.name||""}"
                />
            </div>
            <div class="kname ${t=>!t.getMatchData().participantOne?.shortName&&t.getMatchData().participantOne?.name?"long-name":""}" title="${t=>t.getMatchData().participantOne?.name||""}">
                ${t=>t.getMatchData().participantOne?.shortName||t.getMatchData().participantOne?.name||""}
            </div>
        </div>
        ${t=>(t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame||t.getMatchData().gameStateCatetory===F.Xp.postGame?j():O())(t)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>t.getMatchData().participantTwo?.name||""}"
                />
            </div>
            <div class="kname ${t=>!t.getMatchData().participantTwo?.shortName&&t.getMatchData().participantTwo?.name?"long-name":""}" title="${t=>t.getMatchData().participantTwo?.name||""}">
                ${t=>t.getMatchData().participantTwo?.shortName||t.getMatchData().participantTwo?.name||""}
            </div>
        </div>
    </div>
`,q=_.qy`
    <a class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}"
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${X}
    </a>
`,J=_.qy`
    <div class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}">
        ${X}
    </div>
`,K=_.qy`
    ${t=>t.viewModel.needsVerticalLine?W:U}
`,Z=_.qy`
    <a class="
        sports-match matchup-neutral-background
        ${t=>t.viewModel.noBackgrounds?"no-bg":""}
        ${t=>t.viewModel.reason.length>0?"reason":""}
        ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${t=>`background-image: ${t.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${t=>t.viewModel.overrideStyleForMatch} ${t=>t.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${t=>t.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${t=>R(t.getMatchData().participantOne||{},!t.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${t=>t.getMatchData().participantOne?.name}">
                    ${t=>t.isMitUx?t.getMatchData().participantOne?.shortName||t.getMatchData().participantOne?.name||"":t.getMatchData().participantOne?.name||""}
                </div>
            </div>
            ${I}
            <div class="participant-container right-participant ${t=>t.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantTwoColor};`}">
                    ${(0,D.z)(t=>t.viewModel.isSpotlight2Card,_.qy`${t=>R(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,D.z)(t=>!t.viewModel.isSpotlight2Card,_.qy`${t=>R(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${t=>t.getMatchData().participantTwo?.name}">
                    ${t=>t.isMitUx?t.getMatchData().participantTwo?.shortName||t.getMatchData().participantTwo?.name||"":t.getMatchData().participantTwo?.name||""}
                </div>
            </div>
        </div>
    </a>
`,Q=()=>_.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${t=>t.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gameDate} - ${t.getMatchData().tvChannel}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameDate||""}</span>
            ${t=>t.getMatchData().tvChannel&&t.getMatchData().gameDate?H:""}
        <span>${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,tt=t=>_.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime+"-"+t.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${t=>""+(t.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${t}">
        <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${t}
        </span>
    </div>
`,et=()=>_.qy`
    <div class="middle-game-detail ${t=>t.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,D.z)(t=>t.getMatchData().participantOne?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(B)}</span>`)}
            ${t=>t.getMatchData().participantOne?.score??""}
        </span>
        ${t=>(0,M.oT)(t.getMatchData().participantOne?.score||"")||(0,M.oT)(t.getMatchData().participantTwo?.score||"")?"":H}
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantTwo?.score??""}
            ${(0,D.z)(t=>t.getMatchData().participantTwo?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(B)}</span>`)}
        </span>
    </div>
`,it=t=>_.qy`
    <div class="top-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?N:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
    ${et()}
    ${(0,D.z)(!(0,M.oT)(t),_.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${t}">
            <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${t}
            </span>
        </div>
    `)}
`,at=()=>_.qy`
    ${et()}
    <div class="bottom-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?N:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
`,rt=()=>_.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${t=>st(t)}
        </div>
        <div class="game-winner-description" title="${t=>t.viewModel.strings.champions||""}">
            ${t=>t.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantOne?.score??""}
        </span>
        ${t=>(0,M.oT)(t.getMatchData().participantOne?.score||"")||(0,M.oT)(t.getMatchData().participantTwo?.score||"")?"":H}
        <span class="game-score-text-style">
            ${t=>t.getMatchData().participantTwo?.score??""}
        </span>
    </div>
`,ot=()=>_.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.enableLiveScores?_.qy`
    <span class="game-score-text-style">
        ${t=>t.getMatchData().participantOne?.score??""}
    </span>
    ${t=>(0,M.oT)(t.getMatchData().participantOne?.score||"")||(0,M.oT)(t.getMatchData().participantTwo?.score||"")?"":H}
    <span class="game-score-text-style">
        ${t=>t.getMatchData().participantTwo?.score??""}
    </span>
`:_.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${t=>(t.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.enableLiveScores?"live-scores-detail":""}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gamePeriodAndClock} - ${t.getMatchData().tvChannel}`:t.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${t=>t.getMatchData().gamePeriodAndClock}">
            ${t=>t.getMatchData().gamePeriodAndClock||""}
        </span>
        ${t=>t.getMatchData().gamePeriodAndClock&&t.getMatchData().tvChannel?H:""}
        <span title="${t=>t.getMatchData().tvChannel}">${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,st=t=>{const e=t.getMatchData();if(e&&e.gameStateCatetory==F.Xp.postGame){let t=e.participantOne?.isWinner?e.participantOne?.name?.toUpperCase():null;return t||(t=e.participantTwo?.isWinner?e.participantTwo?.name?.toUpperCase():null),t||""}return""},nt=_.qy`
    ${t=>t.isVertical()?_.qy` ${K} `:t.isCopilotTheme()?_.qy` ${Y} `:t.viewModel?_.qy` ${Z} `:void 0}
`;let lt=class extends n{};lt=(0,a.Cg)([(0,l.E)({name:"sports-match",template:nt,styles:z,shadowOptions:{delegatesFocus:!0}})],lt)},62795(t,e,i){i.r(e),i.d(e,{SportsPickWinnerWC(){return j}});var a=i(56911),r=i(11796),o=i(60815),s=i(66591),n=i(71372),l=i(48566),p=t=>t.replace(/(<([^>]+)>)/gi,"");(Object.getOwnPropertyDescriptor(p,"name")||{}).writable||Object.defineProperty(p,"name",{value:"default",configurable:!0});class c extends n.a{constructor(){super(...arguments),this.handlePollOptionOnClick=t=>{this.viewModel.userVote||(this.viewModel.recordUserVote(t),this.viewModel.userVote=t,this.handleVoteDataBuffer(t),o.cP.notify(this,"viewModel"))},this.handleVoteDataBuffer=t=>{if(""!==t){this.viewModel.teamsVoteData.forEach((e,i)=>this.viewModel.teamsVoteData[i]=e.id===t?{...e,voteCount:(e.voteCount||0)+1}:e);const e=(this.viewModel.teamsVoteData[0].voteCount||0)+(this.viewModel.teamsVoteData[1].voteCount||0);this.viewModel.teamsVoteData.forEach((t,i)=>this.viewModel.teamsVoteData[i].votePercentage=this.getTeamPercent(t.voteCount||0,e))}}}connected(){super.connected(),this.viewModel.userVote&&this.handleVoteDataBuffer(this.viewModel.userVote),this.commentsButton=this.shadowRoot?.querySelector?.(".comments-button"),this.commentsButton&&this.viewModel.handleCommentsClick&&this.commentsButton.addEventListener("click",this.viewModel.handleCommentsClick)}disconnected(){this.commentsButton&&this.viewModel.handleCommentsClick&&this.commentsButton.removeEventListener("click",this.viewModel.handleCommentsClick)}getPollResultText(t){return this.viewModel.gameState===r.T0.Final?t?.hasWon?this.viewModel.strings.winnerText:"":(this.viewModel.disableVoting||this.viewModel.userVote)&&void 0!==t.votePercentage?`${t.votePercentage}%`:""}getComponentString(t){const{gameState:e,strings:i}=this.viewModel;let a="";this.viewModel.userVote?e===r.T0.PreGame||e===r.Xp.preGame?a=t?i.postselPrimary:i.postselSecondaryPre:e===r.T0.InProgress||e===r.Xp.inprogressGame?a=t?i.postselPrimary:i.postselSecondaryLive:e===r.T0.Final&&(a=this.viewModel.teamsVoteData.find(t=>t.id===this.viewModel.userVote)?.hasWon?t?i.postselPrimaryWon:i.postselSecondaryPost:t?i.postselPrimaryLost:i.postselSecondaryPost):e===r.T0.PreGame||e===r.Xp.preGame?a=t?i.preselPrimary:i.preselSecondary:e===r.T0.InProgress||e===r.Xp.inprogressGame?a=t?i.preselPrimaryLive:i.preselSecondaryLive:e===r.T0.Final&&(a=t?i.preselPrimaryLive:i.postselSecondaryPost);const o=this.viewModel.teamsVoteData.find(t=>t.id===this.viewModel.userVote)?.shortName;return a?.includes("{teamName}")&&(a=o?l.Qf.Format(a,{teamName:o}):""),a}getTeamPercent(t,e){return Math.round(t/e*100)||0}getCanUserVote(){return!this.viewModel.userVote&&!this.viewModel.disableVoting}getTeamName(t){return this.viewModel.isRuby&&t.name&&(3===this.viewModel.columnLayout||4===this.viewModel.columnLayout)?t.name:t.shortName||""}get teamButtonClassNames(){return(0,s.x)("pick-winner-option",["voted",!!this.viewModel.userVote],["disabled",!!this.viewModel.disableVoting],["entrypoint",!!this.viewModel.isEntrypoint])}getTeamButtonStyles(t){return!this.getCanUserVote()&&this.viewModel.isRuby&&t.teamColor?`background: ${t.teamColor}0D;`:""}getTeamButtonAriaLabel(t){const e=this.getTeamName(t),i=e&&this.viewModel.userVote===t.id?this.viewModel.strings.selectedText.replace("{0}",e||""):e,a=this.getCanUserVote()||void 0===t.votePercentage?i:`${i} ${t.votePercentage}%`;return`${[this.viewModel.strings.pickWinner,this.getComponentString(!0),p(this.getComponentString(!1))].filter(Boolean).join(" ")} ${a}`}isTeamWinningPoll(t,e){return e.reduce((t,e)=>t.votePercentage&&e.votePercentage&&t.votePercentage>e.votePercentage?t:e).id===t}getTeamButtonPercentageBarClassNames(t){return(0,s.x)("option-item-bar",["selected",!!this.viewModel.userVote&&this.viewModel.userVote===t||!!this.viewModel.disableVoting&&this.isTeamWinningPoll(t,this.viewModel.teamsVoteData)])}getTeamButtonPercentageBarStyles(t){if(!this.getCanUserVote()&&void 0!==t.votePercentage){let e=`width: ${t.votePercentage}%;`;return this.viewModel.isRuby&&t.teamColor&&(e+=` background: ${t.teamColor}33`),e}return"width: 0%;"}getOptionItemContentClassNames(t){return(0,s.x)("option-item-content",["entrypoint",!!this.viewModel.isEntrypoint],["selected",this.viewModel.userVote===t])}}(0,a.Cg)([o.sH],c.prototype,"viewModel",void 0),(0,a.Cg)([o.sH],c.prototype,"commentsButton",void 0);var d=i(92011),g=i(22683),h=i(45476),u=i(37302),m=i(61138),y=i(71157),f=i(64003),b=i(92393),v=i(74849),x=i(22131),w=i(70289);const $=v.A` .option-item-bar{background:var(--color-neutral-stroke-2,#EEEEEE)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#E0EDFF)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#D1D1D1)}`,S=v.A` .option-item-bar{background:var(--color-neutral-stroke-2,#3D3D3D)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#243966)}.like-icon{filter:invert(1)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#666666)}`,k=v.A` .pick-winner-container{border-top:1px solid ${g.hb};padding:8px 0;gap:8px;display:grid}.pick-winner-container.ruby{border:none;gap:16px;padding:0}.pick-winner-options{padding:unset;display:grid;gap:6px;margin-top:unset;margin-bottom:4px}.ruby .pick-winner-options{margin:unset;gap:16px}.pick-winner-option{all:unset;${w.f} display:flex;height:36px;align-items:center;border-radius:100px;overflow:hidden;background:${h.Wl}}.pick-winner-option:focus-visible{outline:-webkit-focus-ring-color auto 1px;outline-offset:2px}.ruby .pick-winner-option{height:56px;border:none}.pick-winner-option:not(.voted):not(.disabled):hover{cursor:pointer;background-color:${u.Xt}}.pick-winner-option.entrypoint{height:30px}.option-item-content{display:flex;justify-content:space-between;width:100%;position:relative;font-weight:600;padding:0 10px;font-size:14px}.ruby .option-item-content{padding:0 16px;align-items:center}.option-item-bar{position:absolute;height:100%;left:0;width:0%;transition:width 0.5s ease-in-out}.option-item-text-container{display:flex;gap:6px}.ruby .option-item-text-container{gap:12px;align-items:center}.option-item-text{-webkit-line-clamp:1;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all}.option-item-content.entrypoint:not(.selected){font-weight:400}.option-item-image{width:auto;height:24px}.ruby .option-item-image{height:40px}.like-button-container{align-items:center;display:flex}.pick-winner-text-container{display:flex;flex-direction:column;gap:2px}.pick-winner-primary-text{font-size:${m.k};font-weight:600}.ruby .pick-winner-primary-text,.ruby .option-item-text,.ruby .option-item-result{font-weight:550;font-size:18px;line-height:${y.O}}.ruby .option-item-result{display:flex;gap:4px}.pick-winner-secondary-text{font-size:${m.k};color:${f.c}}.comments-button{all:unset;font-size:inherit;${w.f} color:${b.W_};text-decoration:underline;cursor:pointer}.comments-button:hover{color:${b.YL}}.comments-button:focus-visible{outline:-webkit-focus-ring-color auto 1px}.ruby .like-icon{height:24px}`.withBehaviors((0,x.C7)($),(0,x.G2)(S));var T=i(96950),C=i(69259),z=i(93809),F=i(39957),M=i(32150),_=i(30876);const D=`${(0,M.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_regular.svg`,E=`${(0,M.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_filled.svg`,P=t=>T.qy`
    <div class="like-button-container">
        <img class="like-icon" src="${e=>t?E:D}" alt="" />
    </div>
`,B=T.qy`
    <div class="option-item-result">
        ${(t,e)=>e.parent.getPollResultText(t)}
        ${(0,C.z)((t,e)=>e.parent.viewModel.isRuby&&e.parent.viewModel.gameState!==r.T0.Final,T.qy`
            ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
        `)}
    </div>
`,R=T.qy`
    <button
        type="button"
        id=${t=>t.id}
        class=${(t,e)=>e.parent.teamButtonClassNames}
        @click=${(t,e)=>e.parent.getCanUserVote()&&e.parent.handlePollOptionOnClick?.(t.id)}
        data-t=${(t,e)=>e.parent.getCanUserVote()?e.parent.viewModel.telemetryContext?.voteButtonTag:null}
        style=${(t,e)=>e.parent.getTeamButtonStyles(t)}
        aria-label=${(t,e)=>e.parent.getTeamButtonAriaLabel(t)}
        title=${(t,e)=>e.parent.getTeamButtonAriaLabel(t)}
    >
        <div
            class=${(t,e)=>e.parent.getTeamButtonPercentageBarClassNames(t.id)}
            style=${(t,e)=>e.parent.getTeamButtonPercentageBarStyles(t)}
        ></div>
        <div class=${(t,e)=>e.parent.getOptionItemContentClassNames(t.id)}>
            <div class="option-item-text-container">
                ${(0,C.z)((t,e)=>!e.parent.viewModel.isEntrypoint,T.qy`
                    <img class="option-item-image" alt="" src=${t=>t.imageUrl||""} />
                `)}
                <span class="option-item-text" aria-hidden="true">${(t,e)=>e.parent.getTeamName(t)}</span>
                ${(0,C.z)((t,e)=>!e.parent.viewModel.isRuby&&!e.parent.viewModel.disableVoting&&!e.parent.viewModel.isEntrypoint&&e.parent.viewModel.userVote===t.id,T.qy`
                    ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
                `)}
            </div>
            ${(0,C.z)((t,e)=>!e.parent.getCanUserVote(),B,T.qy`
                ${(0,C.z)((t,e)=>!e.parent.viewModel.isEntrypoint,T.qy`
                    ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
                `)}
            `)}
        </div>
    </button>
`,A=T.qy`
    <div
        class="pick-winner-container ${t=>t.viewModel.isRuby?"ruby":""}"
        data-t=${t=>t.viewModel.telemetryContext?.rootTag}
    >
        <div class="pick-winner-text-container">
            ${(0,C.z)(t=>!!t.getComponentString(!0),T.qy`
                <div class="pick-winner-primary-text">
                    ${t=>t.getComponentString(!0)}
                </div>
            `)}
            ${(0,C.z)(t=>!t.viewModel.isRuby&&!!t.getComponentString(!1),T.qy`
                <div
                    class="pick-winner-secondary-text"
                    :innerHTML=${(0,z.U)(t=>t.getComponentString(!1),_.r)}
                ></div>
            `)}
        </div>
        <div class="pick-winner-options">
            ${(0,F.ux)(t=>t.viewModel.teamsVoteData,T.qy`
                ${R}
            `,{positioning:!0})}
        </div>
    </div>
`,I=T.qy`
    ${(0,C.z)(t=>!!t.viewModel,A)}
`;let j=class extends c{};j=(0,a.Cg)([(0,d.E)({name:"sports-pick-winner-wc",template:I,styles:k,shadowOptions:{delegatesFocus:!0}})],j)},89895(t,e,i){i.r(e),i.d(e,{SportsSpotlight(){return j}});var a=i(56911),r=i(20517),o=i(83546),s=i(60815);class n extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,o.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,a.Cg)([s.sH],n.prototype,"isMitUx",void 0);var l=i(92011),p=i(86856),c=i(74849),d=i(4126),g=i(22131),h=i(48751),u=i(63033),m=i(70289);const y=c.A` @container (min-width:180px) and (max-width:273px){.cop-video{.match-wrap{padding:40px 0 0px}}}`,f=c.A` .spotlight-video-tagtitle{right:16px}._1x_3y.spotlight-video-img{margin-right:-50%}`,b=c.A`
`,v=c.A` ._1x_3y.spotlight-video{margin-top:12px}._1x_2y.spotlight-video{height:150px}._1x_3y.spotlight-video{height:296px}._1x_2y.spotlight-video .spotlight-video-tagtitle,._1x_3y.spotlight-video .spotlight-video-tagtitle{inset-inline-start:8px;top:8px;backdrop-filter:blur(25px);padding:1px 8px 3px}._1x_2y.spotlight-video .spotlight-video-title,._1x_3y.spotlight-video .spotlight-video-title{inset-inline-start:8px;bottom:4px;height:52px;font-weight:550;line-height:26px;max-width:252px}._1x_2y.spotlight-video .spotlight-video-icon{top:48px;transform:translateX(-50%)}._1x_2y.spotlight-video .spotlight-video-icon img{width:32px;height:32px}`,x=c.A` .spotlight-video{display:block;position:relative;margin-top:8px;border-radius:8px;overflow:hidden;z-index:1}._1x_1y.spotlight-video{height:56px;width:56px;margin-top:0px}._1x_3y.spotlight-video{height:308px}.spotlight-video-img{max-width:100%;object-fit:scale-down;overflow:hidden;border-radius:8px;display:block}._1x_1y.spotlight-video-img{width:100%;height:100%;object-fit:cover}._1x_3y.spotlight-video-img{max-height:100%;max-width:none;margin-left:-50%}.spotlight-video-tagtitle{position:absolute;left:16px;top:9px;width:fit-content;height:16px;line-height:16px;border-radius:6px;border:1px solid rgba(255,255,255,0.20);background:rgba(255,255,255,0.10);backdrop-filter:blur(12.5px);padding:0 8px;font-weight:400;font-size:12px;color:#FFFFFF}.spotlight-video-title{position:absolute;left:16px;bottom:16px;height:44px;line-height:22px;font-weight:600;font-size:16px;color:#FFFFFF;display:-webkit-box;max-width:236px;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;white-space:normal}.spotlight-video-icon{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}._1x_1y.spotlight-video-icon > img{width:24px;height:24px}.spotlight-video-overlay{position:absolute;width:100%;height:100%;left:0;bottom:0;transition:background 0.1s;background-image:linear-gradient(180deg,rgba(0,0,0,0.00) 0,rgba(0,0,0,0.50) 59px,rgba(0,0,0,0.50) 100%)}.spotlight-fre-container{position:relative;z-index:var(--click-z-index);margin-bottom:16px;display:flex;flex-direction:row;align-items:start;max-width:fit-content}.spotlight-video-overlay:hover{background:rgba(0,0,0,0.25)}.spotlight-fre-text{overflow:hidden;white-space:nowrap;color:${h.l};text-decoration:none;padding-right:6px}._1x_1y.spotlight-fre-text{width:206px}.fre-header{font-weight:600;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-header{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);margin-bottom:4px}.fre-content{font-weight:400;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-content{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);white-space:normal;max-height:32px;-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}.v2cntr{width:100%;height:266px;display:flex;flex-direction:column;gap:16px;margin-top:12px;sports-game-stats{margin-top:5px}}.cop-video{container-type:inline-size;.vidv3{height:196px;width:100%;display:block;position:relative;overflow:hidden;border-radius:var(--cstm-corner-media-in-card);corner-shape:squircle}.vidv3:focus-visible{outline-offset:-1px}.thumbnail{height:196px;width:100%;object-fit:cover;transition:transform 0.4s ease-out}.vidv3:hover .thumbnail{transform:scale(1.05)}.play-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px}.match-wrap{padding:40px 20px 0px}}.wrap{text-decoration:none;${m.f}}`.withBehaviors(new p.t(null,f),new u.N(null,b),new d.o("isAdaptiveThemeEnabled",!0,y),new d.o("isMitUx",!0,v),(0,g.mr)(c.A` :host{forced-color-adjust:auto}`));var w=i(96950),$=i(39957),S=i(69259),k=i(32150);const T=`${(0,k.rA)().StaticsUrl}latest/icons-wc/icons/PlayIconLarge.svg`,C=`${(0,k.rA)().StaticsUrl}latest/sports/icons/PlayIconCopilot.svg`,z=w.qy`
    <div>
        ${(0,$.ux)(t=>t.viewModel.matches,w.qy`<sports-match
            :viewModel="${t=>t.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,F=w.qy`
    ${(0,S.z)(t=>null!=t.viewModel.headerData,w.qy`
        <div class="spotlight-fre-container">
            <a class="spotlight-fre-text ${t=>t.viewModel.cardSize}"
                data-t="${t=>t.viewModel.spotsVideoTelemetry}"
                href="${t=>t.viewModel.headerData?.clickThroughUrl}"
                target="_blank"
            >
                <div class="fre-header" title="${t=>t.viewModel.headerData?.headerTextLine1}">
                    ${t=>t.viewModel.headerData?.headerTextLine1}
                </div>
                <div class="fre-content" title="${t=>t.viewModel.headerData?.headerTextLine2}">
                    ${t=>t.viewModel.headerData?.headerTextLine2}
                </div>
            </a>
            ${(0,S.z)(t=>"_1x_1y"===t.viewModel.cardSize&&t.viewModel.sportsVideo?.msnVideoEmbedLink,w.qy`
                <a
                    class="spotlight-video ${t=>t.viewModel.cardSize}"
                    data-t="${t=>t.viewModel.spotsVideoTelemetry}"
                    href="${t=>t.viewModel.sportsVideo?.msnVideoEmbedLink}"
                    target="_blank"
                >
                    <img
                        class="spotlight-video-img ${t=>t.viewModel.cardSize}"
                        role="presentation"
                        src="${t=>t.viewModel.sportsVideo?.videoThumbnailUrl}"
                    />
                    <div class="spotlight-video-overlay">
                        <div class="spotlight-video-icon ${t=>t.viewModel.cardSize}">
                            <img role="presentation" src=${T} alt="" />
                        </div>
                    </div>
                </a>
            `)}
        </div>
    `)}
`,M=w.qy`
    <sports-game-stats
        :viewModel="${t=>t.viewModel.sportsGameStatsCard?.viewModel}"
    >
    </sports-game-stats>
`,_=w.qy`
    <sports-game-leaders
        :viewModel="${t=>t.viewModel.sportsGameLeadersCard?.viewModel}"
    >
    </sports-game-leaders>
`,D=w.qy`
    <sports-pick-winner-wc
        :viewModel="${t=>t.viewModel.sportsPickWinnerCard?.viewModel}"
    >
    </sports-pick-winner-wc>
`,E=w.qy`
    ${(0,S.z)(t=>"_1x_1y"!==t.viewModel.cardSize,w.qy`
        <a
            class="spotlight-video ${t=>t.viewModel.cardSize}"
            data-t="${t=>t.viewModel.spotsVideoTelemetry}"
            href="${t=>t.viewModel.sportsVideo?.msnVideoEmbedLink}"
            target="_blank"
        >
            <img
                class="spotlight-video-img ${t=>t.viewModel.cardSize}"
                role="presentation"
                src="${t=>t.viewModel.sportsVideo?.videoThumbnailUrl}"
            />
            <div class="spotlight-video-overlay">
                ${(0,S.z)(t=>t.viewModel.sportsVideo?.videoTagTitle,w.qy`
                    <div class="spotlight-video-tagtitle">
                        ${t=>t.viewModel.sportsVideo?.videoTagTitle}
                    </div>
                `)}
                <div class="spotlight-video-title" title="${t=>t.viewModel.sportsVideo?.videoTitle||""}">
                    ${t=>t.viewModel.sportsVideo?.videoTitle||""}
                </div>
                <div class="spotlight-video-icon">
                    <img role="presentation" src=${T} alt="" />
                </div>
            </div>
        </a>
    `)}
`,P=w.qy`
    ${(0,S.z)(t=>t.viewModel.sportsGameStatsCard?.viewModel?.isFullCard,M,w.qy`
        ${(0,S.z)(t=>t.viewModel.matches.length,z,F)}
        ${(0,S.z)(t=>null!=t.viewModel.sportsPickWinnerCard,D)}
        ${(0,S.z)(t=>null!=t.viewModel.sportsGameStatsCard,M)}
        ${(0,S.z)(t=>null!=t.viewModel.sportsVideo,E)}
    `)}
`,B=w.qy`
    <a
        class="wrap"
        data-t="${t=>t.viewModel.telemetryTag}"
        href="${t=>t.viewModel.tabClickThroughUrl}"
        target="_blank"
    >
        <div class="v2cntr">
            ${(0,S.z)(t=>t.viewModel.matches.length,z,F)}
            ${(0,S.z)(t=>t.viewModel.sportsGameStatsCard,M)}
        </div>
    </a>
`,R=w.qy`
    <a
        class="vidv3"
        data-t="${t=>t.viewModel.spotsVideoTelemetry}"
        href="${t=>t.viewModel.sportsVideo?.msnVideoEmbedLink}"
        target="_blank"
    >
        <img
            class="thumbnail"
            role="presentation"
            src="${t=>t.viewModel.sportsVideo?.videoThumbnailUrl}"
        />
        <img role="presentation" src=${C} alt="" class="play-icon"/>
    </a>
`,A=w.qy`
    <div class="cop-video">
        ${R}
        <div class="match-wrap">
            ${z}
        </div>
    </div>
`,I=w.qy`
    ${(0,S.z)(t=>null!=t.viewModel,w.qy`${t=>{return(e=t.viewModel).sportsGameLeadersCard?_:e.isCopilotTheme&&e.sportsVideo?A:e.isCopilotTheme?B:P;var e}}`)}
`;let j=class extends n{};j=(0,a.Cg)([(0,l.E)({name:"sports-spotlight",template:I,styles:x,shadowOptions:{delegatesFocus:!0}})],j)},43774(t,e,i){i.d(e,{p4(){return m},ls(){return y},vA(){return u},nF(){return h}});var a=i(68136),r=i(68009),o=i(95239);const{create:s}=a.G,n=s("neutral-stroke-strong-hover-delta",40),l=s("neutral-stroke-strong-active-delta",16),p=s("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:d}=a.G,g=d({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,i,a,o,s){const n=(0,r.F)(e),l=t.colorContrast(e,i),p=t.closestIndexOf(l);return{rest:l,hover:t.get(p+n*a),active:t.get(p+n*o),focus:t.get(p+n*s)}}(t(c.r),t(o.p),3,t(n),t(l),t(p))}}),h=d("neutral-stroke-strong-rest",t=>t(g).evaluate(t).rest),u=d("neutral-stroke-strong-hover",t=>t(g).evaluate(t).hover),m=d("neutral-stroke-strong-active",t=>t(g).evaluate(t).active),y=d("neutral-stroke-strong-focus",t=>t(g).evaluate(t).focus)},99657(t,e,i){i.d(e,{D(){return s},I(){return o}});var a=i(68136);const{create:r}=a.G,o=r("sloppy-click-z-index",1),s=r("click-z-index",1)},30876(t,e,i){i.d(e,{r(){return o}});var a=i(7686),r=i(42277);const o=i(68244).F.create({trustedType:{createHTML:t=>a.A.sanitize(t,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[r.D.property]:{innerHTML:(t,e,i,r)=>(t,e,i,...o)=>{const s=a.A.sanitize(i,{RETURN_TRUSTED_TYPE:!0});r(t,e,s,...o)}}}}})},38817(t,e,i){i.d(e,{R7(){return m},e(){return h},kc(){return u},nH(){return g}});var a=i(57416),r=i(55153),o=i(95239),s=i(26920),n=i(48751),l=i(64187),p=i(22131),c=i(74849),d=i(50882);const g=c.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,h=c.A` ${(0,l.V)("flex")} :host{background:${o.p};outline:calc(${s.XA} * 1px) solid ${r.cu};border-radius:calc((${a.JU} - ${s.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${n.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${r.QG} * 1px);height:calc(${r.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${r.QG} * 1px);height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc(${r.l8} * 1px)}::slotted(*){color:inherit}`,u=(0,p.mr)(c.A` :host{background:${d.A.Canvas};color:${d.A.CanvasText}}`),m=c.A` ${h} ${g} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(u)},70289(t,e,i){i.d(e,{f(){return l}});var a=i(64187),r=i(74849),o=i(38817),s=i(99657),n=i(36452);const l=r.A.partial`position: relative; z-index: ${s.D};`;r.A` ${o.e} ${o.nH} ${(0,a.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${n.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${n.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${n.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(o.kc)}}]);