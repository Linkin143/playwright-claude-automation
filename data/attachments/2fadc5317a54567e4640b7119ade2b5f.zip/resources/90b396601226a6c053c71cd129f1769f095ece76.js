"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["libs_video-manager_dist_players_StadiumPlayer_js"],{85975(e,t,a){var i=a(99607),s=a(66946);let n=["play","pause","ended"];class r extends s.a{constructor(){super(...arguments),this.type="Stadium",this.normalizeEventData=()=>{let e=this.createContentEvent(),{content:t}=e,{title:a,videoDuration:i}=t;return{...e,isPlayerPaused:this.instance.paused(),content:{...t,videoPositionSec:this.instance.currentTime()??0,title:a,videoDuration:this.instance.duration()||i}}}}async initialize({js:e,container:t,playerInfo:a,isAutoplay:s}){if(!e)return;let{id:n,sourceId:r}=a.video,d=`${n}_stadium`,o=this.createPlayer(s,d,r),l=this.createPlayerStyleOverrides();t.insertAdjacentHTML("beforebegin",l),t.insertAdjacentHTML("beforeend",o);let{src:u}=e;return await (0,i.k)({id:`${this.type}-player`,src:u}),new Promise(e=>{let i=document.getElementById(d),s=window.bc(i?.id);super.init(s,t,a),this.subscribeToEvents(e)})}dispose(){this.instance.off(),this.instance.dispose(),super.dispose()}play(){this.instance.play(),super.play()}pause(){this.instance&&!this.instance.paused()&&this.instance.pause(),super.pause()}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!0}createTimeUpdateEventData(){return this.normalizeEventData()}createPlayer(e,t,a){return`
            <video
                id="${t}"
                data-video-id="${a}"
                autoplay="${e}"
                muted="true"
                class="video-js stadium-video-player"
                controls
                data-account="5994000126001"
                data-player="3NqDmnlmh"
                data-embed="default"
                plays-inline="true"
            >
            </video>
        `}createPlayerStyleOverrides(){return`
            <style>
                .stadium-video-player {
                    height: 100% !important;
                    width: 100% !important;
                }
            </style>
        `}subscribeToEvents(e){this.instance.ready(()=>{for(let t of(e(),window.setTimeout(()=>this.triggerEvent("ready",this.normalizeEventData())),n))this.instance.on(t,()=>{switch(t){case"play":{let e=this.hasStartedPlaying?"resume":"play";this.hasStartedPlaying=!0,this.triggerEvent(e,this.normalizeEventData());break}case"pause":if(this.instance.duration()-this.instance.currentTime()<.5)break;this.triggerEvent("pause",this.normalizeEventData());break;default:this.triggerEvent(t,this.normalizeEventData())}})})}}a.d(t,{StadiumPlayer:()=>r})}}]);