"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_video-card-wc_dist_components_PlutoTvPlayerElement_js"],{60630(e,t,l){var a=l(56911),o=l(59669),r=l(89757),s=l(92011);let n=(0,o.A)`
.plutoTV_root > iframe{
    border: none;
    height: 70vh;
    min-height: 720px;
    width: 100%;
}`,p=(0,r.qy)`
<div class="plutoTV_root" data-t="${e=>e.videoCardProps?.telemetryContext?.parentTelemetry?.getMetadataTag()}">
    <iframe class="plutotvplayer" scrolling="no" src="//msn.pluto.tv/" allowfullscreen="true" allow="autoplay; fullscreen"></iframe>
</div>`,i=class extends s.L{};i=(0,a.Cg)([(0,s.E)({name:"pluto-tv-player",template:p,styles:n})],i),l.d(t,{PlutoTvPlayerElement:()=>i})}}]);