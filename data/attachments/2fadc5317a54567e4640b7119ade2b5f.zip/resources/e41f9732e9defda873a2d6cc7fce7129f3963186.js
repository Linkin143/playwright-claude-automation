"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_entry-point-hp-wc_dist_lazy-loadings_widgetLayoutTemplateMaps_js"],{18575(t,o,l){l.d(o,{AnaheimWidgetsLayoutTemplateMap:()=>R});var s=l(27783),a=l(81336),C=l(22754),e=l(41740),y=l(89270),_=l(77858),r=l(8634),u=l(77679),i=l(65839),x=l(14642),d=l(63041),h=l(23382),g=l(97510),n=l(93728),m=l(47956),p=l(42506),P=l(43063),w=l(21907),c=l(44789);let R={"hero-section-one-row-11111":C.D,"hero-section-one-row-122":y.L,"hero-section-one-row-1211":e.r,"hero-section-one-row-2111":_.x,"hero-section-one-row-2111-b":r.$,"hero-section-one-row-21155":u.k,"hero-section-one-row-25511":i.w,"hero-section-one-row-221":x.b,"hero-section-one-row-3-cards":d.m,"hero-section-one-row-3-mini-widgets":h.v,"hero-section-one-row-5-mini-widgets-drp":n.v,"hero-section-one-row-5-mini-widgets":m.X,"hero-section-one-row-4-cards":g.R,"hero-section-first-river-4-cards":s.O,"hero-section-first-river-5-cards":a.Z,"widgets-cards-1":p.X,"widgets-cards-2":P.Q,"widgets-cards-3":w.X,"widgets-cards-4":c.c}},27783(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot4 slot3"
        "slot1 slot2 slot4 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot4 slot2"
        "slot1 slot4 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot3"
        "slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(8)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._1x_2y,C3:s.u._1x_1y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_1y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,3],C3:[1,2],C2:[1,2],C1:[3,1]}}],styles:C};l.d(o,{},{O:e})},81336(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot3"
        "slot3 slot3"
        "slot2 slot4"
        "slot2 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(4),C2:(0,s.P)(6),C1:(0,s.P)(10)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_1y,C3:s.u._1x_2y,C2:s.u._2x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_1y,C3:s.u._2x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[2,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}}],styles:C};l.d(o,{},{Z:e})},22754(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C};l.d(o,{},{D:e})},41740(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C};l.d(o,{},{r:e})},89270(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot2"
        "slot1 slot2 slot2";
}
:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3";
}
:host([layout="C2"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._2x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._2x_2y,C4:s.u._1x_2y,C2:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C2:[1,2]}}],styles:C};l.d(o,{},{L:e})},8634(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}
 
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C};l.d(o,{},{$:e})},77858(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot3 slot1 slot1 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot3";
}

:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._2x_2y,C2:s.u._2x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_2y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[2,3],C2:[4,1]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C2:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C2:[3,2]}}],styles:C};l.d(o,{},{x:e})},77679(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot4 slot1 slot1 slot2"
        "slot5 slot1 slot1 slot2";
}
:host([layout="C4"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot5";
}
:host([layout="C3"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot4 slot2"
        "slot5 slot2";
}

:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._2x_2y,C2:s.u._2x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C2:s.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C2:[3,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y},telemetryRowCol:{C5:[1,4]}},{grid_area:"slot4",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y},telemetryRowCol:{C5:[1,5],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot5",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y},telemetryRowCol:{C5:[2,5],C4:[2,1],C3:[2,3],C2:[4,1]}}],styles:C};l.d(o,{},{k:e})},14642(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3]}}],styles:C};l.d(o,{},{b:e})},65839(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot5"
        "slot1 slot1 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot5 slot4"
        "slot1 slot3 slot5 slot4";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot5 slot2 slot4"
        "slot1 slot5 slot3 slot4";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._2x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,2],C1:[1,3]}},{grid_area:"slot3",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[2,3],C2:[2,2],C1:[2,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,5],C3:[1,5],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,3],C1:[1,2]}}],styles:C};l.d(o,{},{w:e})},63041(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._2x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._2x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C};l.d(o,{},{m:e})},23382(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._2x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_halfy,C4:s.u._2x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C};l.d(o,{},{v:e})},97510(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._2x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_2y,C4:s.u._1x_2y,C3:s.u._1x_2y,C2:s.u._1x_2y,C1:s.u._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}}],styles:C};l.d(o,{},{R:e})},93728(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.u._1x_halfy},telemetryRowCol:{C5:[1,5]}}],styles:C};l.d(o,{},{v:e})},47956(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.u._1x_halfy,C4:s.u._1x_halfy,C3:s.u._1x_halfy,C2:s.u._1x_halfy,C1:s.u._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,5],C3:[1,5],C2:[1,5],C1:[1,5]}}],styles:C};l.d(o,{},{X:e})},42506(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1";
}
`.withBehaviors(),e={cardCount:1,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:C};l.d(o,{},{X:e})},43063(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:2,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:C};l.d(o,{},{Q:e})},21907(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}}],styles:C};l.d(o,{},{X:e})},44789(t,o,l){var s=l(69828),a=l(59669);let C=(0,a.A)`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:300,gutterPx:12,cardSlots:[{grid_area:"slot1",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.u._1x_1y,C4:s.u._1x_1y,C3:s.u._1x_1y,C2:s.u._1x_1y,C1:s.u._1x_1y},telemetryRowCol:{C5:[1,4],C4:[1,4]}}],styles:C};l.d(o,{},{c:e})}}]);