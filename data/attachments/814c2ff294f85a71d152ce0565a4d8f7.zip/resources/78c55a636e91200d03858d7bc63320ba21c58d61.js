"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["tcfConsentBanner"],{75470(e,n,t){t.d(n,{setupTcfConsentExpireBannerForMsn(){return l},shouldShowTcfConsentBanner(){return u}});var c=t(7671),o=t(73631),a=t(37210),r=t(89757),s=t(24318),i=t(7446);function l(){const e="Customize your ad experience, including personalized ads settings, on your ",n=(0,s.Lg)(),t={actionDelegate(){n.removeItem("TcfConsentCheckResult")}},l=r.qy`
        <div class="tcf-leadText">
            ${e} <a
                href="https://account.microsoft.com/privacy/ad-settings"
                class="clickableLeadText"
                target="_blank"
                @click=${(e,n)=>(i.YT.addOrUpdateTmplProperty("TCFRevokeBannerPrivacyClicked","1"),t.actionDelegate(),e.removeBanner(),!0)}
            >${"Microsoft Privacy Dashboard"}</a>
        </div>
    `,u={id:"tcfConsentExpireBannerMsn",group:"Functional",placementSource:"Internal",surfaceModel:{surfaceType:"HorizontalBanner",position:"Top",bannerType:"LegalCompliance",closeSurfaceAction:t,displaySurfaceAction:{actionDelegate(){i.YT.addOrUpdateTmplProperty("TCFRevokeBannerDisplayed","1")}},hideSurfaceAction:{actionDelegate(){i.YT.addOrUpdateTmplProperty("TCFRevokeBannerDismissed","1")}}},contentModel:{title:e,description:l,contentType:c.r.CallToAction}};Promise.all([(0,a.sn)(),(0,o.X9)()]).then(([e])=>{e.sendInternalPlacement(u)})}function u(){const e=(0,s.Lg)(),n="TcfConsentCheckResult";try{const t=JSON.parse(e.getItem(n)||"{}");return!!t?.shouldShowBanner&&(Date.now()-t.cleanDate<2592e6?(i.YT.addOrUpdateTmplProperty("TCFRevokeBannerShowed","1"),!0):(e.removeItem(n),!1))}catch(e){return!1}}}}]);