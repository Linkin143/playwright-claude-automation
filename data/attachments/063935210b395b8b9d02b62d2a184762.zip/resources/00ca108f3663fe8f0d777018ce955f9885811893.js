(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-cards_dist_cards_sub-components_card-action-tray_OptedOutReactionTemplate_js"],{28463(t,e,a){"use strict";a.d(e,{tB(){return w},LW(){return p},nj(){return m}});var l=a(95402),c=a(96950),s=a(69259),n=a(16215),i=a(44978),r=a(69828),o=a(86203),d=a.n(o),h=a(48493),$=a.n(h),g=a(32150),u=a(13186),v=a(2375);const m=({theme:t="default",hideComments:e=!1})=>c.qy`
<div style="display: flex; gap: 4px;">
    ${(0,s.z)(t=>t.optedOutOfReactions&&!t.disableOptedOutButton,c.qy`
        ${p}
        ${w}
    `)}
    <social-bar-wc
        config-instance-src=${t=>t.socialBarWCConfigInfo&&(0,v.v)(t.socialBarWCConfigInfo)}
        instance-id=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.instanceId}
        config-shared-ns=${t=>t.socialBarWCConfigInfo?.configRef?.sharedNs}
        :additionalHeaders=${t=>t.additionalHeaders}
        :hideComments=${t=>e}
        :canShowOneLineComments=${t=>!(t.isInfopane||t.cardSize!==r.uE._2x_2y||"flex-article-card"===t.childTemplateType&&t.articleTopCommentConfigInfo&&t.articleTopCommentId)}
        :contentId=${t=>t.id}
        :destinationUrl=${t=>t.destinationUrl}
        :title=${t=>t.title}
        :locale=${t=>g.T3.CurrentMarket||t.locale}
        :rootTelemetryObject=${t=>t.telemetryContext&&(t.telemetryContext.contentCardTelemetryObject||t.telemetryContext.contentCard)}
        :getReplacementCardsCallback=${t=>t.getReplacementCardsCallback}
        :reactionCallback=${t=>t.reactionCallback}
        :cardActionHideHandler=${t=>t.cardActionClickHandler&&((...e)=>t.cardActionClickHandler(t.id,t.cardActionStatus^i.J.hide,...e))}
        :shareActionHandler=${t=>t.shareActionHandler}
        :isInfoPane=${t=>t.isInfopane}
        :isRightPos=${t=>t.socialBarInRight}
        :socialMetadata=${t=>({...t.metadata,imageData:t.imageData,providerData:t.providerData,title:t.title})}
        :theme=${e=>t}
    ></social-bar-wc>
</div>
`,p=c.qy`
<msn-card-button
    class="card-button"
    data-icon=${i.J.showMore}
    style="${t=>t.isInfopane||t.optedOutOfReactions||!t.enableFilledIconOnHover?"":"display: flex;"} ${t=>t.enableAnimatedShowMoreBtn||t.optedOutOfReactions||!t.enableFilledIconOnHover?"":"margin-inline-end: 8px;"}"
    select-title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.showMore}
    unselect-title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.undoShowMore}
    animation-text=${t=>t.showMoreAnimationTitle}
    select-icon=${t=>t.useArrowIcons&&!t.optedOutOfReactions?d():'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48.7c-.8-.83-2.09-.38-2.43.6-.28.8-.64 1.77-1 2.48C6 5.9 5.37 7.1 3.67 8.63c-.23.2-.52.36-.84.49-1.13.44-2.2 1.61-1.92 3l.36 1.77a2.5 2.5 0 0 0 1.8 1.92l5.6 1.52a4.5 4.5 0 0 0 5.6-3.53l.69-3.76A3 3 0 0 0 12 6.5h-.88l.01-.05c.08-.41.18-.97.24-1.59.07-.6.1-1.28.05-1.9a3.68 3.68 0 0 0-.5-1.74 4.16 4.16 0 0 0-.44-.52Z"/></svg>'}
    unselect-icon=${t=>t.useArrowIcons&&!t.optedOutOfReactions?$():'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 1.3C8.4.31 9.68-.14 10.48.7c.16.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H12a3 3 0 0 1 2.96 3.54l-.69 3.76a4.5 4.5 0 0 1-5.6 3.53l-5.6-1.52a2.5 2.5 0 0 1-1.8-1.92L.9 12.12c-.27-1.39.79-2.56 1.92-3 .32-.13.61-.3.84-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49Zm1.96 5.58v-.01l.01-.03a9.08 9.08 0 0 0 .13-.58c.08-.4.17-.92.23-1.5s.09-1.18.04-1.73a2.73 2.73 0 0 0-.34-1.25 3.26 3.26 0 0 0-.32-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.89.34-1.45 1.14-1.3 1.87l.35 1.77c.1.56.53 1 1.07 1.15l5.6 1.53c1.98.54 4-.73 4.37-2.75l.68-3.76A2 2 0 0 0 12 7.5h-1.5a.5.5 0 0 1-.48-.62Z"/></svg>'}
    filled-icon-path=${t=>t.useArrowIcons&&!t.optedOutOfReactions?n.qb:n.vz}
    fill-color-selected=${t=>!t.enableNeutralFilledShowMoreIcon&&u.P}
    layout=${t=>(0,l.V1)(t)}
    selected=${t=>!!(t.cardActionStatus&i.J.showMore)}
    @selected-state-changed=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus&i.J.showFewer?t.cardActionStatus^i.J.showMore^i.J.showFewer:t.cardActionStatus^i.J.showMore,"ShowMore",!0,t.cardActionClickHandler,null,!t.enableAnimatedShowMoreBtn,e.event)}
    select-telemetry-tag=${t=>t.telemetryContext&&t.telemetryContext.showMore&&t.telemetryContext.showMore.getMetadataTag()}
    unselect-telemetry-tag=${t=>t.telemetryContext&&t.telemetryContext.undoShowMore&&t.telemetryContext.undoShowMore.getMetadataTag()}
>
</msn-card-button>
`,w=c.qy`
<msn-card-button
    class="card-button"
    data-icon=${i.J.showFewer}
    style="${t=>!t.enableAnimatedShowMoreBtn&&t.enableFilledIconOnHover?"margin-inline-start: 8px;":""}"
    select-title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.showFewer}
    unselect-title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.undoShowFewer}
    select-icon=${t=>'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48 17.3c-.8.83-2.09.38-2.43-.6-.28-.8-.64-1.77-1-2.48C6 12.1 5.37 10.9 3.67 9.37c-.23-.2-.52-.36-.84-.49C1.7 8.44.63 7.27.9 5.88l.36-1.77a2.5 2.5 0 0 1 1.8-1.92L8.66.66a4.5 4.5 0 0 1 5.6 3.54l.69 3.76A3 3 0 0 1 12 11.5h-.88l.01.05c.08.41.18.97.24 1.58.07.62.1 1.29.05 1.92a3.68 3.68 0 0 1-.5 1.73c-.11.16-.28.35-.44.52Z"/></svg>'}
    unselect-icon=${t=>'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 16.7c.34.98 1.63 1.43 2.43.6.16-.17.33-.36.44-.52.32-.48.45-1.12.5-1.73.05-.63.02-1.3-.05-1.91-.06-.62-.16-1.18-.24-1.59v-.05H12a3 3 0 0 0 2.96-3.54l-.69-3.76A4.5 4.5 0 0 0 8.67.67l-5.6 1.52c-.92.25-1.62 1-1.8 1.92L.9 5.88c-.27 1.39.79 2.56 1.92 3 .32.13.61.3.84.5 1.7 1.5 2.32 2.72 3.38 4.84.36.71.72 1.68 1 2.49Zm1.96-5.58v.01l.01.03a8.94 8.94 0 0 1 .13.58c.08.4.17.92.23 1.5s.09 1.18.04 1.73c-.04.55-.16.98-.34 1.25-.05.1-.17.22-.32.39-.2.2-.63.16-.76-.23-.29-.82-.67-1.83-1.05-2.6-1.07-2.14-1.76-3.5-3.62-5.15-.34-.3-.74-.52-1.13-.68-.89-.34-1.45-1.14-1.3-1.87l.35-1.77c.1-.56.53-1 1.07-1.15l5.6-1.53a3.5 3.5 0 0 1 4.37 2.75l.68 3.76A2 2 0 0 1 12 10.5h-1.5a.5.5 0 0 0-.48.62Z"/></svg>'}
    filled-icon-path=${t=>n.M3}
    fill-color-selected=${t=>!t.enableNeutralFilledShowMoreIcon&&u.P}
    layout=${t=>(0,l.V1)(t)}
    selected=${t=>!!(t.cardActionStatus&i.J.showFewer)}
    @selected-state-changed=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus&i.J.showMore?t.cardActionStatus^i.J.showMore^i.J.showFewer:t.cardActionStatus^i.J.showFewer,"ShowFewer",!0,t.cardActionClickHandler,null,!t.contentType,e.event)}
    select-telemetry-tag=${t=>t.telemetryContext&&t.telemetryContext.showMore&&t.telemetryContext.showFewer.getMetadataTag()}
    unselect-telemetry-tag=${t=>t.telemetryContext&&t.telemetryContext.undoShowFewer&&t.telemetryContext.undoShowFewer.getMetadataTag()}
>
</msn-card-button>
`},16215(t,e,a){"use strict";a.d(e,{C2(){return c},M3(){return s},i_(){return l},qb(){return i},vz(){return n}});const l="M6.75 10a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0m5 0a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0M15 11.75a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5",c="M6.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0m5 0a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0M15 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5",s="M10.481 17.296c-.798.837-2.091.387-2.43-.59-.28-.807-.644-1.772-.998-2.483-1.06-2.126-1.679-3.336-3.385-4.85a2.8 2.8 0 0 0-.84-.49C1.698 8.438.637 7.269.914 5.88l.353-1.765a2.5 2.5 0 0 1 1.794-1.922l5.6-1.527A4.5 4.5 0 0 1 14.272 4.2l.684 3.762a3 3 0 0 1-2.951 3.537h-.884l.01.052c.08.408.177.97.241 1.583.065.61.099 1.284.048 1.912-.049.617-.184 1.25-.504 1.73a4 4 0 0 1-.435.519",n="M10.481.704c-.798-.837-2.091-.387-2.43.59-.28.806-.644 1.772-.998 2.483-1.06 2.126-1.679 3.335-3.385 4.849-.226.2-.518.363-.84.49-1.13.446-2.191 1.616-1.914 3.005l.353 1.765a2.5 2.5 0 0 0 1.794 1.922l5.6 1.527a4.5 4.5 0 0 0 5.611-3.537l.684-3.761A3 3 0 0 0 12.005 6.5h-.884l.01-.052c.08-.409.177-.97.241-1.583.065-.61.099-1.285.048-1.913-.049-.616-.184-1.249-.504-1.73a4 4 0 0 0-.435-.518",i="M11.14 2.53a1.5 1.5 0 0 0-2.28 0l-6.62 7.8A1 1 0 0 0 3 11.98h3V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-5.02h3a1 1 0 0 0 .76-1.65z"},13186(t,e,a){"use strict";a.d(e,{P(){return l}});const l="#0078D4"},24174(t,e,a){"use strict";a.r(e),a.d(e,{OptedOutReactionTemplate(){return c}});var l=a(28463);const c=a(96950).qy`
    ${l.LW}
    ${l.tB}
`},86203(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11.14 2.53a1.5 1.5 0 00-2.28 0l-6.62 7.8A1 1 0 003 11.98h3V17a1 1 0 001 1h6a1 1 0 001-1v-5.02h3a1 1 0 00.76-1.65l-6.62-7.8z"></path></svg>'},48493(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.86 2.53c.6-.7 1.68-.7 2.28 0l6.62 7.8a1 1 0 01-.76 1.65h-3V17a1 1 0 01-1 1H7a1 1 0 01-1-1v-5.02H3a1 1 0 01-.76-1.65l6.62-7.8zm1.52.65a.5.5 0 00-.76 0L3 10.98h3.5c.28 0 .5.23.5.5V17h6v-5.52c0-.27.22-.5.5-.5H17l-6.62-7.8z"></path></svg>'}}]);