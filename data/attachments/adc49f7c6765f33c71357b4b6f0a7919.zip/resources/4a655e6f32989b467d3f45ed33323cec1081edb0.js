"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_recipes-sd-card_src_index_ts"],{9549:function(e,t,i){i.r(t),i.d(t,{RecipesSdCard:function(){return j},RecipesSdCardStyles:function(){return et},RecipesSdCardTemplate:function(){return V},ToolingInfo:function(){return ei}});var a=i(94826),r=i(4731),s=i(37180),n=i(56050),c=i(63242),o=i(86262),l=i(55672),p=i(42228),d=i(61473),h=i(56911),m=i(94108),g=i(87906),u=i(40450),b=i(16250),y=i(98378);let T="RecipesCard",f="RecipesCard_seemore",C="RecipesCard_customization",w="RecipesCard_customization_report",v="RecipesCard_customization_hide",x="RecipesCard_customization_moresettings",S="RecipesCard_BowheadPipeline";var k=i(3583),R=i(65794),U=i(12882);let M={Id:null,Type:"recipe-card",data:'[{"Title":"Make-Ahead Cranberry Sauce","PreperationTime":"30 min","ServingPerRecipe":"2","Rating":"4.5","RatingScale":"5","ReviewCount":"188","Calories":"676","Domain":"www.foodnetwork.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%228a03d8b3e2a54e61c6dc98aa0a986ba7%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailId":"OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.foodnetwork.com/recipes/ina-garten/make-ahead-cranberry-sauce-3160641","DisplayName":"Food Network"},{"Title":"The Ultimate Potato Soup Recipe","PreperationTime":"30 min","ServingPerRecipe":"8","Rating":"4.98","RatingScale":"5","ReviewCount":"7","Calories":"521","Domain":"sugarspunrun.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%229030ec38b5ae70711df71d680465269c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailId":"OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://sugarspunrun.com/creamy-potato-soup-recipe/","DisplayName":"Sugar Spun Run"},{"Title":"Arancini","Rating":"0","ReviewCount":"0","Calories":"549","Domain":"www.jamieoliver.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%224e425609c043ea522fbaa3d26d9fddc4%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.4c44689e1151c802c5955998fef49e55","ThumbnailId":"OSK.4c44689e1151c802c5955998fef49e55","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.jamieoliver.com/recipes/rice/arancini/","DisplayName":"Jamie Oliver"},{"Title":"Ultimate Slow Cooker Pot Roast","PreperationTime":"8 hr 15 min","ServingPerRecipe":"8","Rating":"4.86","RatingScale":"5","ReviewCount":"344","Calories":"498","Domain":"dinnerthendessert.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%2258a799e3cf5f1360978f4a2ecca44567%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailId":"OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://dinnerthendessert.com/ultimate-slow-cooker-pot-roast/","DisplayName":"Dinner Then Dessert"},{"Title":"BEST Chicken Salad","PreperationTime":"4 hr 15 min","ServingPerRecipe":"8","Rating":"4.92","RatingScale":"5","ReviewCount":"6","Calories":"360","Domain":"www.daringgourmet.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22644dc0f93ab206b3e98cd3dc637fe29c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailId":"OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.daringgourmet.com/classic-chicken-salad/","DisplayName":"Daring Gourmet"},{"Title":"Candied Yams Recipe","PreperationTime":"40 min","ServingPerRecipe":"6","Rating":"4.42","RatingScale":"5","ReviewCount":"48","Calories":"443","Domain":"www.lovebakesgoodcakes.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22597b08b323cf9890ba96834721503fac%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailId":"OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.lovebakesgoodcakes.com/candied-yams-recipe/","DisplayName":"Love Bakes Good Cakes"},{"Title":"Vegan Gluten Free Cupcakes","PreperationTime":"17 min","ServingPerRecipe":"12","Rating":"5","RatingScale":"5","ReviewCount":"7","Calories":"177","Domain":"thebigmansworld.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22eec3abe61e2eae837878e4efc30f3453%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailId":"OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://thebigmansworld.com/vegan-chocolate-cupcakes/","DisplayName":"The Big Man\'s World"},{"Title":"The Best Classic Zucchini Bread Recipe","PreperationTime":"1 hr 5 min","ServingPerRecipe":"12","Rating":"4.97","RatingScale":"5","ReviewCount":"15","Calories":"214","Domain":"www.thewholesomedish.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22fb2e1c1e25b956b0a1183c1c18c1fe1d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailId":"OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thewholesomedish.com/the-best-classic-zucchini-bread/","DisplayName":"The Wholesome Dish"},{"Title":"One Pot Chicken Parmesan Pasta","PreperationTime":"30 min","ServingPerRecipe":"6","Rating":"4.61","RatingScale":"5","ReviewCount":"10","Calories":"582","Domain":"www.thechunkychef.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22dac84e545711b27c7564cd2eba21444d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailId":"OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thechunkychef.com/one-pot-chicken-parmesan-pasta/","DisplayName":"The Chunky Chef"}]',DataType:null,Version:1,Previews:null,Badges:null,Metadata:{market:"en-us",language:"en",region:"us"},PreviewsV2:null,IsSkipped:null,PulseData:null,ClusterIds:null,AdditionalNewsContent:[],message:"",BowheadMetadata:{PipelineTag:"TEST"},debugLogs:[]};var P=i(60815),D=i(96484),N=i(33744),O=i(9960),$=i(88651),H=i(12360),z=i(71843),I=i(44704);class j extends R.U{constructor(){super(),this.dataType="RecipesSdCard",this.isActionMenuOpen=!1,this.recipes=[],this.seeMoreUrl=new URL('https://www.bing.com/search?q=Popular Recipes&filters=userscenario:"dsb" ForceHighConfRecipe:"true"'),this.childTelemetryObjects={},this.market=m.Rb?.Locale??"en-us",this.version="superSDCard",this.pageNumber=0,this.maxRecipeNumber=4}experienceConnected(){try{(0,U.uC)(this.config.cardActionWC)}catch(e){(0,g.c_)(e,u.TQ$,"Failed to load cardActionWc")}try{let e=this.mapperArgs?.cardMetadata??M;this.loadData(e)}catch(e){(0,g.c_)(e,u.TQ$,"Failed to load cardMetaData",e),this.recipes=null,this.pipelineName=null}this.maxRecipeNumber=this.recipes.length??0,this.dataIsValid(this.recipes)&&(this.setupTelemetryObjects(),this.initSuperSDSetting(),this.loadUI())}getLocalizedPreparationTime(e){if(!e)return"";let t=e.split(" ");if(2!==t.length)return`${t[0]} ${this.strings.hours} ${t[2]} ${this.strings.minutes}`;{let e="min"===t[1]?this.strings.minutes:this.strings.hours;return`${t[0]} ${e}`}}loadData(e){if(!e)return;let t=JSON.parse(e.data);for(let e=0;e<this.maxRecipeNumber;e++){let i=new URL(t[e].ClickThroughUrl);i.searchParams.has("setmkt")&&this.seeMoreUrl.searchParams.set("setmkt",i.searchParams.get("setmkt")),i.searchParams.has("setlang")&&this.seeMoreUrl.searchParams.set("setlang",i.searchParams.get("setlang")),i.searchParams.has("cc")&&this.seeMoreUrl.searchParams.set("cc",i.searchParams.get("cc")),i.searchParams.has("q")&&this.seeMoreUrl.searchParams.set("q",i.searchParams.get("q")),this.recipes.push({href:i.toString(),thumbnailUrl:this.getRecipeThumbnailUrl(t[e].Thumbnail),thumbnailId:t[e].Thumbnail.ThumbnailId,name:t[e].Title,hasVideo:!1,siteName:t[e].Domain,siteUrl:t[e].Domain,preparationTime:this.getLocalizedPreparationTime(t[e].PreperationTime),calorieContent:t[e].Calories,starRating:t[e].Rating,displayName:t[e].DisplayName})}this.pipelineName=e.BowheadMetadata?.PipelineTag??S}loadUI(){let e;this.cardTelemetryObject?this.cardTelemetryObject.contract=(0,$.u)(this.dataType??"",{type:y.b5.StructuredData,vertical:"Recipe"},{ext:{...this.parentTelemetry?.contract?.ext,...this.telemetryObject?.contract?.ext,recipeList:this.recipes.map(e=>this.getSatoriId(e?.href)),signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)}}):this.cardTelemetryObject=(0,H.g)(this.dataType??"",{type:y.b5.StructuredData,vertical:"Recipe"},{ext:{...this.parentTelemetry?.contract?.ext,...this.telemetryObject?.contract?.ext,recipeList:this.recipes.map(e=>this.getSatoriId(e?.href)),signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)}}),this.sdData={id:this.id,isSpotlightCard:!0,cardSize:"_1x_2y",childTemplateType:"",headerData:{headerLogo:`<img src=${e=`recipes-icon.${(0,O.ud)()?"dark":"light"}.svg`,`${(0,N.rA)().StaticsUrl}latest/recipes/${e}`} alt="" />`,title:this.strings.title,titleNavigationLink:this.seeMoreUrl.toString(),actionMenuData:{hideCardCallback:this.hideCardCallback.bind(this),moreSettingsPersonalizeCallback:this.moreSettingsCallback.bind(this)},telemetryContext:{headerTelemetryObject:this.getChildTelemetry({name:"header",action:y.EG.Click,behavior:y.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),headerTitleTelemetryObject:this.getChildTelemetry({name:"headertitle",action:y.EG.Click,behavior:y.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()})?.getMetadataTag(),headerLogoTelemetryTag:this.getChildTelemetry({name:"headerlogo",action:y.EG.Click,behavior:y.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()})?.getMetadataTag(),pinTelemetryTag:this.getChildTelemetry({name:"pin",action:y.EG.Click,behavior:y.MS.Pin}),actionMenuTelemetryTag:this.getChildTelemetry({name:"actionmenu",action:y.EG.Click,behavior:y.MS.ContextMenu}),hideCard:this.getChildTelemetry({name:"hidecard",action:y.EG.Click,behavior:y.MS.Hide}),moreSettings:this.getChildTelemetry({name:"moresettings",action:y.EG.Click,behavior:y.MS.More})}},footerData:{footerLink:{text:this.strings.seeMore,navigationUrl:this.seeMoreUrl.toString()},paginationData:{currentPageIndex:this.pageNumber+1,pageCount:this.maxRecipeNumber,onFlipperClick:this.dataPaginationCallback.bind(this),onDotClick:(e,t)=>{this.pageNumber=e,this.loadUI()}},telemetryContext:{footerLink:this.getChildTelemetry({name:"footerlink",action:y.EG.Click,behavior:y.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),previousFlipper:this.getChildTelemetry({name:"previous",action:y.EG.Click,behavior:y.MS.Paginate}),nextFlipper:this.getChildTelemetry({name:"next",action:y.EG.Click,behavior:y.MS.Paginate})}},contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:null,telemetryContext:{contentCard:this.getChildTelemetry({name:"SuperSDCard"})}}}isHidden(e){return e!=this.pageNumber}setupTelemetryObjects(){if(null==this.telemetryObject)return;let e=this.parentTelemetry?.contract?.ext;this.recipesTelemetryObject=(0,H.g)(T,{id:T,type:y.b5.StructuredData},y.MS.View,y.EG.View,{...e,signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)},{type:y.MJ.Module}),this.wholeCardTelemetryTag=this.recipesTelemetryObject.getMetadataTag();for(let t=0;t<this.maxRecipeNumber;t++)this.recipes[t].telemetryTag=(0,H.g)("RecipesCard_recipe",{id:this.recipes[t].entityId,type:y.b5.StructuredData,headline:this.recipes[t].name},y.MS.Navigate,y.EG.Click,e,{type:y.MJ.ContentCard}).getMetadataTag();this.seeMoreTelemetryTag=(0,H.g)(f,{id:f,type:y.b5.StructuredData,headline:f},y.MS.Navigate,y.EG.Click,e,{type:y.MJ.Footer}).getMetadataTag(),this.actionsMenuTelemetryTag=(0,H.g)(C,{id:C,type:y.b5.StructuredData,headline:C},y.MS.More,y.EG.Click,e,{type:y.MJ.ActionButton}).getMetadataTag(),this.recipesReportTelemetryObject=(0,H.g)(w,{id:w,type:y.b5.StructuredData,headline:w},y.MS.Report,y.EG.Click,e,{type:y.MJ.ActionButton}),this.pipelineTelemetryTag=(0,H.g)(S,{id:S,type:y.b5.StructuredData,headline:this.pipelineName},y.MS.View,y.EG.View,e,{type:y.MJ.ContentCard}).getMetadataTag(),this.customizeTelemetryTag=(0,H.g)("RecipesCard_Customization",{type:y.b5.StructuredData,headline:"More options"},y.MS.More,{ext:e}).getMetadataTag(),this.reportTelemetryTag=this.recipesReportTelemetryObject.getMetadataTag(),this.moreSettingTelemetryTag=(0,H.l)(x,{id:x,type:y.b5.StructuredData,headline:x},y.MS.Navigate,y.EG.Click,y.MJ.ActionButton).getMetadataTag(),this.hideCardTelemetryTags=(0,H.l)(v,{id:v,type:y.b5.StructuredData,headline:v},y.MS.Hide,y.EG.Click,y.MJ.ActionButton).getMetadataTag()}shadowDomPopulated(){try{this.cardActionRef=this.shadowRoot?.querySelector?.("card-action"),this.markVisuallyReadyRaf()}catch(e){(0,g.c_)(e,u.TQ$,"Failed to get cardActionRef")}}getSatoriId(e){return new URLSearchParams(e).get("filters")?.split(" ")[0]?.split("sid:")?.[1]?.slice(1,-1)??""}getExperienceType(){return d.Lz8}getRecipeThumbnailUrl(e){return e&&e.ThumbnailUrl?"https://www.bing.com"+e.ThumbnailUrl:"https://www.bing.com/th?id=empty"}async hideCardCallback(){try{await D.d.updateSegmentCardsEnableStatus([{cardType:k.s.RecipesCard,enabled:!1}])&&(this.mapperArgs?.refreshSDCardSection?this.mapperArgs.refreshSDCardSection():this.$emit("refreshSDCardSection"))}catch(e){(0,g.c_)(e,u.fKW,"Failed to call pdp service to hide card")}}moreSettingsCallback(){this.mapperArgs?.goToPersonalizeSettingsCallback?this.mapperArgs.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")}initSuperSDSetting(){let e={moreSetting:{title:this.strings.moreSettings,telemetryTag:this.moreSettingTelemetryTag},hideSetting:{title:this.strings.hideCard,telemetryTag:this.hideCardTelemetryTags}};this.superSDSetting=new b.t(j,k.s.RecipesCard,e,this.goToPersonalizeSettingsCallback,this.refreshSDCardSection)}getChildTelemetry(e){return this.childTelemetryObjects?.[e.name]?this.childTelemetryObjects[e.name].contract=(0,z.C)(e?.name,e?.behavior,e?.action,{...this.cardTelemetryObject?.contract?.ext,...e.ext},{destinationUrl:e?.destinationUrl}):this.childTelemetryObjects[e.name]=(0,I.u)(e?.name,e?.behavior,e?.action,{...this.cardTelemetryObject?.contract?.ext,...e.ext},{destinationUrl:e?.destinationUrl}),this.childTelemetryObjects[e.name]}dataPaginationCallback(e){let t=this.recipes.length||1,i=(this.pageNumber+(e?1:-1)+t)%t;this.pageNumber=i,this.loadUI()}handleNext(){this.pageNumber=(this.pageNumber+1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}handlePrev(){this.pageNumber=(this.pageNumber+this.maxRecipeNumber-1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}dataIsValid(e){if(!Array.isArray(e)||e.length<this.maxRecipeNumber)return!1;for(let t of e)if(!t.href||!t.name)return!1;return e.length>=0}}(0,h.Cg)([P.sH],j.prototype,"isActionMenuOpen",void 0),(0,h.Cg)([P.sH],j.prototype,"actionMenuItems",void 0),(0,h.Cg)([P.sH],j.prototype,"superSDSetting",void 0),(0,h.Cg)([P.sH],j.prototype,"sdData",void 0),(0,h.Cg)([P.sH],j.prototype,"customizeTelemetryTag",void 0),(0,h.Cg)([P.sH],j.prototype,"reportTelemetryTag",void 0),(0,h.Cg)([P.sH],j.prototype,"moreSettingTelemetryTag",void 0),(0,h.Cg)([P.sH],j.prototype,"hideCardTelemetryTags",void 0),(0,h.Cg)([P.sH],j.prototype,"pageNumber",void 0),(0,h.Cg)([P.sH],j.prototype,"currentPage",void 0);var E=i(89757),A=i(68835),_=i(69259);let F=(0,E.qy)` ${(0,A.ux)(e=>e.recipes.slice(e.pageNumber,e.pageNumber+1),(0,E.qy)`<div class="recipe_supersd_content"><a class="recipe" href="${e=>e.href}" target="_blank" @click=${(e,t)=>t.parent.handleClickCard(t.event)} data-t="${e=>e.telemetryTag}"><div class="${e=>e.hasVideo?"video":""}"><img src="${e=>e.thumbnailUrl}" alt="${e=>e.name}" height=126px width=268px /></div><div class="metadata"><div class="site">${e=>e.displayName||e.siteName}</div><div class="name" title=${e=>e.name}>${e=>e.name}</div><div class="recipe-info">${(0,_.z)(e=>e.starRating,(0,E.qy)`<div class="rating"><img class="star-icon" src="${`${(0,N.rA)().StaticsUrl}latest/fluent-icons/star_16_filled.svg`}" alt="Star Icon"/><div>${e=>Number.isInteger(Number(e.starRating))?Number(e.starRating).toFixed(1):e.starRating}</div></div>`)} ${(0,_.z)(e=>e.calorieContent||e.preparationTime,(0,E.qy)`<div class="recipe-details">${(0,_.z)(e=>e.preparationTime,(0,E.qy)`<div class="preparation-time">${e=>e.preparationTime}</div>`)} ${(0,_.z)(e=>e.calorieContent&&e.preparationTime,(0,E.qy)`<div class="dot">·</div>`)} ${(0,_.z)(e=>e.calorieContent,(0,E.qy)`<div class="nutritional-value">${(e,t)=>`${e.calorieContent} ${t.parent.strings?.calorieUnit||"cals"}`}</div>`)}</div>`)}</div></div></a></div>`)}
`,B=(0,E.qy)`<responsive-sd-card :data="${e=>e.sdData}" data-t=""><div class="container" slot="card-content">${F}</div></responsive-sd-card>`,V=(0,E.qy)`<div class="root" data-t="${e=>e.wholeCardTelemetryTag}">${B}</div>`;var q=i(57416),G=i(6032),L=i(47810),K=i(86856),W=i(59669),J=i(22131),Q=i(70289);let X=(0,W.A)`
    .star-icon{
        --invertStarIcon: 64.84%; // #adadad
    }
`,Z=(0,W.A)`
    .star-icon{
        --invertStarIcon: 14.2%; // #242424
    }
`,Y=(0,W.A)` .more-options{right:10px}.v2 .more-options{right:16px}`,ee=(0,W.A)` .more-options{left:10px}.v2 .more-options{right:16px}`,et=(0,W.A)`
:host{border-radius:calc(${q.JU} * 1px);font-family:"Segoe UI";font-size:12px;line-height:16px}@media (prefers-color-scheme:light){.v1,.v2{h5,.site,.disclaimer{color:${G.c}}.name{color:${L.l}}}.root.rootv2{background:linear-gradient(144.59deg,rgba(200,220,243,0.1) 0%,rgba(200,220,243,0.4) 88.78%)}}@media (prefers-color-scheme:dark){.v1,.v2{.site,.disclaimer{color:${G.c}}h5,.name{color:${L.l}}}.root.rootv2{background:linear-gradient(122.3deg,rgba(28,46,68,0.4) 0%,rgba(28,46,68,0.8) 84.48%)}}h5{margin:0;margin-bottom:24px;padding:0;height:16px;font-size:12px}a{text-decoration:none}.recipe{margin:16px 0;height:90px;display:flex;column-gap:12px}img{object-fit:cover;border-radius:calc(${q.JU} * 1px);
}

.video {
    position: relative;
}

.video::after {
    content: ' ';
    position: absolute;
    top: 4px;
    left: 4px;
    height: 20px;
    width: 20px;
    z-index: 1;
    background-size: 20px 20px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.metadata {
    min-width: 0;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v1 .name,
.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.recipes-footer {
    display: flex;
    justify-content: center;
}

.sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
}

.toggle-button {
    position: absolute;
    top: 12px;
    right: 10px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

.more-options {
    position: absolute;
    top: 12px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

msn-actions-menu {
    z-index: 700;
}

.rootV2 {
    user-select: none;
    padding: 16px 16px 12px;
    background: linear-gradient(144.59deg, rgba(200, 220, 243, 0.1) 0%, rgba(200, 220, 243, 0.4) 88.78%);
}

.v2 {
    height: 276px;
}

.v2 h5 {
    margin: 0;
    margin-bottom: 8px;
    padding: 0;
    height: 16px;
    font-size: 12px;
}

.v2 a {
    text-decoration: none;
}

.v2 a:hover .name {
    text-decoration: underline;
}

.v2 .recipe {
    height: 90px;
    display: initial;
}

.v2 img {
    object-fit: cover;
    border-radius: calc(${q.JU} * 1px);
}

.v2 .video {
    position: relative;
}

.v2 .video::after {
    content: ' ';
    position: absolute;
    top: 42px;
    left: 114px;
    height: 40px;
    width: 40px;
    z-index: 1;
    background-size: 40px 40px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="40" height="40" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.v2 .metadata {
    min-width: 0;
    margin-top: 12px;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.v2 .recipes-footer {
    position: absolute;
    bottom: 12px;
    display: flex;
    justify-content: space-between;
    width: 268px;
    height: 24px;
    line-height: 24px;
}

.v2 .recipes-footer .button {
    width: 24px;
    height: 24px;
    border-radius: 1000px;
}

.prev-button, .next-button {
    background: #00000012;
    float: left;
}

.v2 .prev-button svg {
    margin: 8px 10px 8px 9px;
}

.v2 .next-button svg {
    margin: 8px 9px 8px 10px;
}

.v2 .page-number {
    margin: 0 8px;
    float: left;
}

.v2 .sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
    background-color: transparent;
}

.v2 .see-more-text {
    float: left;
}

.v2 .recipes-footer .see-more-button {
    float: right;
    margin-left: 8px;
    background: #0078D4;
}

.v2 .recipes-footer .see-more-button svg {
    margin: 8px 7px;
}

.recipe_supersd_content {
    position: absolute;
    width: 268px;
    ${Q.f} .recipe{display:flex;flex-direction:column;row-gap:16px;margin:0;height:auto;.metadata{color:${L.l};display:flex;flex-direction:column;row-gap:6px;.name{overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:1;white-space:nowrap;font-size:14px;font-style:normal;font-weight:600;line-height:20px}.recipe-info{display:flex;column-gap:8px;align-items:center;font-size:12px;color:var(--color-neutral-foreground-3);font-family:"Segoe UI";.rating{display:flex;justify-content:space-between;height:24px;padding:0px 6px 0px 4px;align-items:center;gap:2px;background-color:var(--color-neutral-background-2);border-radius:4px;font-weight:600;.star-icon{filter:invert(var(--invertStarIcon,0))}}.recipe-details{display:flex;align-items:center;column-gap:4px;font-style:normal;font-weight:400}}}}}`.withBehaviors((0,J.G2)(X),(0,J.C7)(Z),new K.t(Y,ee)),ei={experienceConfigSchema:void 0},ea=d.Lz8;p.p&&l.L.registerExperience(ea,()=>Promise.resolve().then(i.bind(i,9549))),r.m.define(s.c.registry),n.m.define(s.c.registry),c.m.define(s.c.registry),o.m.define(s.c.registry),(0,a.d)()}}]);