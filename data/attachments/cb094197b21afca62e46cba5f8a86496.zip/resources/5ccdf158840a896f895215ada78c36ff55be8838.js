"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_content-video-player_dist_Utils_AdControlBarStyles_js"],{30539(e,t,r){r.r(t);let n="msn-ad-control-bar-styles",l=`
.vjs-default-skin .vjs-volume-panel.vjs-volume-panel-vertical {
    left: 32px;
    right: auto;
}

.vjs-default-skin .vjs-current-time {
    margin-left: 44px;
}
`;function o(e,t){let r=e?.querySelector("#ad_iframe");if(r)for(let e of function e(t,r=0,n=[]){if(!t||r>3)return n;for(let l of(t.querySelector(".vjs-control-bar")&&n.push(t),Array.from(t.querySelectorAll("iframe"))))e(s(l),r+1,n);return n}(s(r)))!function(e,t){if(!e.head||e.getElementById(n))return;let r=e.createElement("style");r.id=n,r.textContent=t,e.head.appendChild(r)}(e,t)}function s(e){try{return e.contentDocument??void 0}catch{return}}r.d(t,{applyAdControlBarStyles:()=>o},{AdVolumeControlLeftCss:l})}}]);