"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_entry-point-hp-wc_dist_lazy-loadings_widgetLayoutTemplateMaps_js"],{62196(t,o,l){l.d(o,{AnaheimWidgetsLayoutTemplateMap(){return P}});var s=l(27783),C=l(81336),e=l(22754),a=l(41740),r=l(89270),y=l(77858),i=l(8634),d=l(77679),g=l(65839),u=l(14642),n=l(63041),h=l(23382),m=l(97510),p=l(93728),w=l(47956),c=l(42506),_=l(43063),R=l(21907),x=l(44789);const P={"hero-section-one-row-11111":e.D,"hero-section-one-row-122":r.L,"hero-section-one-row-1211":a.r,"hero-section-one-row-2111":y.x,"hero-section-one-row-2111-b":i.$,"hero-section-one-row-21155":d.k,"hero-section-one-row-25511":g.w,"hero-section-one-row-221":u.b,"hero-section-one-row-3-cards":n.m,"hero-section-one-row-3-mini-widgets":h.v,"hero-section-one-row-5-mini-widgets-drp":p.v,"hero-section-one-row-5-mini-widgets":w.X,"hero-section-one-row-4-cards":m.R,"hero-section-first-river-4-cards":s.O,"hero-section-first-river-5-cards":C.Z,"widgets-cards-1":c.X,"widgets-cards-2":_.Q,"widgets-cards-3":R.X,"widgets-cards-4":x.c}},27783(t,o,l){l.d(o,{O(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot4 slot3"
        "slot1 slot2 slot4 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot4 slot2"
        "slot1 slot4 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot3"
        "slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(8)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_1y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_1y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,3],C3:[1,2],C2:[1,2],C1:[3,1]}}],styles:C}},81336(t,o,l){l.d(o,{Z(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot3"
        "slot3 slot3"
        "slot2 slot4"
        "slot2 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(4),C2:(0,s.P)(6),C1:(0,s.P)(10)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._2x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[2,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}}],styles:C}},22754(t,o,l){l.d(o,{D(){return e}});var s=l(69828);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},41740(t,o,l){l.d(o,{r(){return e}});var s=l(69828);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},89270(t,o,l){l.d(o,{L(){return e}});var s=l(69828);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot2"
        "slot1 slot2 slot2";
}
:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3";
}
:host([layout="C2"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C2:[1,2]}}],styles:C}},8634(t,o,l){l.d(o,{$(){return e}});var s=l(69828);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}
 
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},77858(t,o,l){l.d(o,{x(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot3 slot1 slot1 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot3";
}

:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[2,3],C2:[4,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C2:[3,2]}}],styles:C}},77679(t,o,l){l.d(o,{k(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot4 slot1 slot1 slot2"
        "slot5 slot1 slot1 slot2";
}
:host([layout="C4"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot5";
}
:host([layout="C3"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot4 slot2"
        "slot5 slot2";
}

:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C2:[3,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y},telemetryRowCol:{C5:[1,4]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,5],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[2,5],C4:[2,1],C3:[2,3],C2:[4,1]}}],styles:C}},14642(t,o,l){l.d(o,{b(){return e}});var s=l(69828);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3]}}],styles:C}},65839(t,o,l){l.d(o,{w(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot5"
        "slot1 slot1 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot5 slot4"
        "slot1 slot3 slot5 slot4";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot5 slot2 slot4"
        "slot1 slot5 slot3 slot4";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,2],C1:[1,3]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[2,3],C2:[2,2],C1:[2,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,5],C3:[1,5],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,3],C1:[1,2]}}],styles:C}},63041(t,o,l){l.d(o,{m(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C}},23382(t,o,l){l.d(o,{v(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_halfy,C4:s.uE._2x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C}},97510(t,o,l){l.d(o,{R(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}}],styles:C}},93728(t,o,l){l.d(o,{v(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5]}}],styles:C}},47956(t,o,l){l.d(o,{X(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,5],C3:[1,5],C2:[1,5],C1:[1,5]}}],styles:C}},42506(t,o,l){l.d(o,{X(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1";
}
`.withBehaviors(),e={cardCount:1,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:C}},43063(t,o,l){l.d(o,{Q(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:2,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:C}},21907(t,o,l){l.d(o,{X(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}}],styles:C}},44789(t,o,l){l.d(o,{c(){return e}});var s=l(69828);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[1,4]}}],styles:C}}}]);