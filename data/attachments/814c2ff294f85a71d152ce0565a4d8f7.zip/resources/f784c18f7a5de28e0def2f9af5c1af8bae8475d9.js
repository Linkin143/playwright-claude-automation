"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_content-video-player_dist_sub-components_VideoJsCCToggleButton_js"],{10227(t,e,s){s.d(e,{VideoJsCCToggleButton(){return u}});var i,o=s(39610),n=s(56911),r=s(92011),l=s(60815),c=s(89757),h=s(59669),d=s(84540);let a=i=class extends r.L{constructor(){super(...arguments),this.isInitiallyTurnedOn=!0,this.touchTimeout=void 0,this.handleTouchEnd=()=>{this.touchTimeout&&(clearTimeout(this.touchTimeout),this.toggle(),this.removeEventListener("touchend",this.handleTouchEnd))}}connectedCallback(){super.connectedCallback(),void 0===i.globalIsTurnedOn&&(i.globalIsTurnedOn=this.isInitiallyTurnedOn)}handleTouchStart(){this.touchTimeout&&clearTimeout(this.touchTimeout),this.touchTimeout=window.setTimeout(()=>{this.touchTimeout=void 0,this.removeEventListener("touchend",this.handleTouchEnd)},300),this.addEventListener("touchend",this.handleTouchEnd)}toggle(){i.globalIsTurnedOn=!i.globalIsTurnedOn,i.setStyle(),this.$emit("toggle",{isTurnedOn:i.globalIsTurnedOn})}static setStyle(){document.documentElement.style.setProperty("--vjs-text-track-display-mode",this.globalIsTurnedOn?"initial":"none")}};a.globalIsTurnedOn=void 0,(0,n.Cg)([l.sH],a.prototype,"localizedStrings",void 0),(0,n.Cg)([l.sH],a,"globalIsTurnedOn",void 0),a=i=(0,n.Cg)([(0,r.E)({name:"cc-toggle-button",template:c.qy`
        <button @click="${t=>t.toggle()}" @touchstart="${t=>t.handleTouchStart()}" aria-pressed='${()=>!!a.globalIsTurnedOn}' aria-label="${t=>t?.localizedStrings?.captions}">
            <img src="${t=>a.globalIsTurnedOn?d.M0:d.b1}" role="presentation" />
        </button>
    `,shadowOptions:null,styles:h.A`
        button {
            background: none;
            border: none;
            cursor: pointer;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        @media (prefers-color-scheme: light) {
            button {
                filter: invert(1);
            }
        }
    `})],a);class u extends(o.default.getComponent("Component")){constructor(t,e){super(t,e),this.ccToggleButton=new a,this.el().appendChild(this.ccToggleButton)}}}}]);