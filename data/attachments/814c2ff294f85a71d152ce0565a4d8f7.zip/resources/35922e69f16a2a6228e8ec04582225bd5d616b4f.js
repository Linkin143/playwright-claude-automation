"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-cricket-exploration"],{81714(e,o,t){t.d(o,{K(){return a}});var r=t(67072),i=t(23305),s=t(18633),l=t(79811);class a extends i.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}getShouldShowSecondaryText(e){return e.cardSize!==r.uE._1x_1y&&!e.shouldHideSecondaryText}async getViewModel(e){const o=this.transformerProvider.config.skipFeedRefreshExploration,t=(0,l.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return{followLeagueClickHandler:o=>{this.transformerProvider.followClickEntityHandler({id:e.league.satoriId,yId:e.league.yId,name:e.league.name,type:i.XR.League,imageUrl:t},o,"",!0)},dislikeLeagueClickHandler:()=>{this.transformerProvider.hideClickHandler?.(e.league.id||"",o),this.transformerProvider.config.goToNextTabDelay&&o&&this.transformerProvider.goToNextTabIfExists()},shouldShowDislikeMessage:o,shouldShowSecondaryText:this.getShouldShowSecondaryText(e),followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.FollowSports},!0),dislikeTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.ExplorationDislike},s.YJ.Customize),isFollowed:this.isFollowed(e),telemetryConstants:e.telemetryConstants,reasonText:e.reasonText,secondaryText:e.secondaryText,logoUrl:(0,l.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced),cardSize:e.cardSize,logoPrimaryColor:e.logoPrimaryColor,isDisliked:e.isDisliked,leagueName:e.league.name,strings:{follow:this.transformerProvider.strings.follow,notInterested:this.transformerProvider.strings.iAmNotInterested,youFollowed:this.transformerProvider.strings.youAreNowFollowing,youDisliked:this.transformerProvider.strings.youWillSeeLessContent},telemetryObject:e.telemetryObject,telemetryTag:""}}isFollowed(e){return e.followedSports.get(e.league.satoriId||"")}}},85642(e,o,t){t.r(o),t.d(o,{SportsExplorationHeadTransformer(){return n.K},SportsCricketExplorationTransformer(){return l},SportsCricketTransformer(){return a.SportsCricketTransformer}});var r=t(67072),i=t(23305),s=t(89757);class l extends i.Bc{async transform(e){const o=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <sports-cricket-exploration
                    :viewModel="${o}"
                ></sports-cricket-exploration>`}}async getCurrentViewModel(e){const[o,t]=await Promise.all([this.getExplorationHeadView(e),this.getCricketView(e)]);return{telemetryConstants:e.telemetryConstants,head:o,cricket:t,cardSize:e.cardSize,strings:{featuredGames:this.transformerProvider.strings.featuredGames},telemetryObject:e.telemetryObject,telemetryTag:""}}async getExplorationHeadView(e){const o={followedSports:e.followedSports,reasonText:e.reasonText,secondaryText:e.secondaryText,cardSize:e.cardSize,isDisliked:e.isDisliked,logoPrimaryColor:e.logoPrimaryColor,league:e.league,telemetryObject:e.telemetryObject,shouldHideSecondaryText:e.cardSize===r.uE._1x_2y,telemetryConstants:e.telemetryConstants};return await this.transformerProvider.generateView(o,i.hi.ExplorationHead)}getMaxMatchesCount(e){switch(e.cardSize){case r.uE._1x_2y:return 1;case r.uE._1x_3y:return 3;default:return 0}}async getCricketView(e){const o=this.getMaxMatchesCount(e),t=e.matchList.slice(0,o),r={leagueId:e.league.id,matchData:t,cardSize:e.cardSize,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,isExploration:!0,followedSports:e.followedSports};return await this.transformerProvider.generateView(r,i.hi.SportsCricket)}}var a=t(22726),n=t(81714);Promise.resolve().then(t.bind(t,70796)),Promise.resolve().then(t.bind(t,87595)),Promise.resolve().then(t.bind(t,30502))},70796(e,o,t){t.r(o),t.d(o,{SportsCricketExploration(){return m}});var r=t(56911),i=t(71372);class s extends i.a{}var l=t(92011),a=t(70289),n=t(63033),d=t(59669),c=t(47810);const p=d.A` :host{--divider-color:rgba(255,255,255,0.06)}`,h=d.A` :host{--divider-color:rgba(0,0,0,0.06)}.wrap._1x_2y{margin-top:8px}.divider{width:100%;height:1px;background-color:var(--divider-color);margin-bottom:8px;${a.f};pointer-events:none}.matches-wrap{margin-top:12px}.matches{display:grid;grid-template-columns:131px 131px;gap:6px}.feat-games{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin-bottom:4px;color:${c.l};${a.f};pointer-events:none}`.withBehaviors(new n.N(null,p));var g=t(89757),x=t(69259);const v=g.qy`
    <sports-exploration-head
        :viewModel="${e=>e.viewModel.head.viewModel}"
    ></sports-exploration-head>
`,u=g.qy`
    ${(0,x.z)(e=>"_1x_1y"!==e.viewModel.cardSize,g.qy`
        <div class="matches-wrap">
            <div class="divider"></div>
            <div class="feat-games">${e=>e.viewModel.strings.featuredGames}</div>
            <div class="matches">
                ${e=>e.viewModel.cricket.viewTemplate}
            </div>
        </div>
    `)}
`,w=g.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${v}
        ${u}
     </div>
`,b=g.qy`
    ${(0,x.z)(e=>void 0!==e.viewModel,w)}
`;let m=class extends s{};m=(0,r.Cg)([(0,l.E)({name:"sports-cricket-exploration",template:b,styles:h,shadowOptions:{delegatesFocus:!0}})],m)},87595(e,o,t){t.r(o),t.d(o,{SportsExplorationHead(){return H}});var r,i,s=t(56911),l=t(50180),a=t(60815),n=t(71372),d=t(95144);(i=r||(r={}))[i.Initial=0]="Initial",i[i.Followed=1]="Followed",i[i.Disliked=2]="Disliked";let c=class extends n.a{constructor(){super(...arguments),this.followState=r.Initial}onFollowClick(e){this.viewModel.followLeagueClickHandler(e),this.followState=r.Followed}onDislikeClick(){this.viewModel.dislikeLeagueClickHandler(),this.viewModel.shouldShowDislikeMessage&&(this.followState=r.Disliked)}connected(){super.connected(),this.viewModel.isFollowed?this.followState=r.Followed:this.viewModel.isDisliked&&this.viewModel.shouldShowDislikeMessage&&(this.followState=r.Disliked)}getFollowElements(e,o,t){switch(this.followState){case r.Initial:return e;case r.Followed:return o;case r.Disliked:return t}}get youDislikedInnerHtml(){return(0,l.GP)(this.viewModel.strings.youDisliked,`<span class="league-name">${this.viewModel.leagueName}</span>`)}get youFollowedInnerHtml(){return(0,l.GP)(this.viewModel.strings.youFollowed,`<span class="league-name">${this.viewModel.leagueName}</span>`)}};(0,s.Cg)([a.sH],c.prototype,"followState",void 0),c=(0,s.Cg)([d.x],c);var p=t(92011),h=t(47810),g=t(83252),x=t(86856),v=t(70289),u=t(63033),w=t(59669);const b=w.A` :host{--sec-text-color:rgba(255,255,255,0.78);--dislike-bg-color:#292929;--dislike-border-color:#757575;--dislike-color:#FFFFFF;--dislike-bg-hover:#3D3D3D;--dislike-border-color-hover:rgba(255,255,255,0.06);--result-bg-color:#FFFFFF;--result-color:#2b2b2b}`,m=w.A`
`,f=w.A` :host{--sec-text-color:rgba(0,0,0,0.6);--follow-color:#FFFFFF;--follow-bg-color:#036AC4;--follow-bg-color-hover:#0473CE;--dislike-bg-color:rgba(255,255,255,0.46);--dislike-border-color:#D6D6D6;--dislike-border-color-hover:rgba(0,0,0,0.06);--result-bg-color:#292929;--result-color:#FFFFFF;--logo-wrap-border-color:#D6D6D6;--dislike-color:${h.l};--dislike-bg-hover:${g.Xt}}.reason-wrap{display:grid;grid-template-columns:50px 1fr;gap:6px;align-items:center;${v.f};pointer-events:none}.logo-wrap{margin:3px;border-radius:4px;display:flex;align-items:center;justify-content:center;width:44px;height:44px;box-sizing:border-box;border:1px solid var(--logo-wrap-border-color)}.logo{width:32px;height:32px}.reason-text,.sec-text{${v.f};pointer-events:none;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.reason-text{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;padding:3px 0px;color:${h.l}}.sec-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--sec-text-color);height:32px}.follow-wrap{display:flex;justify-content:space-between;margin-top:8px}.follow-btn,.dislike-btn{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:132px;border-radius:4px;height:22px;box-sizing:border-box;${v.f}}.btn-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;max-width:110px;padding:2px 0px 4px}.league-name{font-weight:600}.follow-btn{background-color:var(--follow-bg-color);color:var(--follow-color);border:0px;border:1px solid rgba(0,0,0,0)}.follow-btn:hover{background-color:var(--follow-bg-color-hover)}.plus{width:9px;height:9px}.dislike-btn{background-color:var(--dislike-bg-color);border:1px solid var(--dislike-border-color);color:var(--dislike-color)}.dislike-btn:hover{border-color:var(--dislike-border-color-hover) var(--dislike-border-color-hover) rgba(0,0,0,0.16) var(--dislike-border-color-hover);background-color:var(--dislike-bg-hover)}.disliked,.followed{background-color:var(--result-bg-color);color:var(--result-color);border-radius:4px;padding:3px 10px;width:268px;box-sizing:border-box;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${v.f};pointer-events:none}._1x_1y .reason-wrap{grid-template-columns:40px 1fr;height:40px}._1x_1y .logo{width:27px;height:27px}._1x_1y .logo-wrap{width:35px;height:35px}._1x_1y .reason-text{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px;color:${h.l}}._1x_1y .follow-wrap{margin-top:4px}`.withBehaviors(new x.t(null,m),new u.N(null,b));var y=t(89757),k=t(69259),$=t(33744);const F=y.qy`
    <div class="reason-wrap">
        <div class="logo-wrap" style="background-color: #${e=>e.viewModel.logoPrimaryColor}">
            <img src="${e=>e.viewModel.logoUrl}" class="logo">
        </div>
        <div class="reason-text">${e=>e.viewModel.reasonText}</div>
    </div>
`,z=y.qy`
    ${(0,k.z)(e=>e.viewModel.shouldShowSecondaryText,y.qy`
        <div class="sec-text">
            ${e=>e.viewModel.secondaryText}
        </div>
    `)}
`,S=y.qy`
    <fluent-button
        class="follow-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.follow}"
        aria-label="${e=>e.viewModel.strings.follow}"
        role="button"
        data-t="${e=>e.viewModel.followTelemetryTag}"
        @click="${e=>e.onFollowClick(!0)}"
    >
        <div class="btn-content">
            <img src="${(0,$.rA)().StaticsUrl}latest/shopping/plusw.svg" class="plus">
            ${e=>e.viewModel.strings.follow}
        </div>
    </fluent-button>
    <fluent-button
        class="dislike-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.notInterested}"
        aria-label="${e=>e.viewModel.strings.notInterested}"
        role="button"
        data-t="${e=>e.viewModel.dislikeTelemetryTag}"
        @click="${e=>e.onDislikeClick()}"
    >
        <div class="btn-content">
            ${e=>e.viewModel.strings.notInterested}
        </div>
    </fluent-button>
`,C=y.qy`
    ${e=>y.qy`
        <div class="followed">${y.qy.partial(e.youFollowedInnerHtml)}</div>
    `}
`,D=y.qy`
    ${e=>y.qy`
        <div class="disliked">${y.qy.partial(e.youDislikedInnerHtml)}</div>
    `}
`,T=y.qy`
    <div class="follow-wrap">
        ${e=>e.getFollowElements(S,C,D)}
    </div>
`,_=y.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${F}
        ${z}
        ${T}
    </div>
`,E=y.qy`
    ${(0,k.z)(e=>void 0!==e.viewModel,_)}
`;let H=class extends c{};H=(0,s.Cg)([(0,p.E)({name:"sports-exploration-head",template:E,styles:f,shadowOptions:{delegatesFocus:!0}})],H)}}]);