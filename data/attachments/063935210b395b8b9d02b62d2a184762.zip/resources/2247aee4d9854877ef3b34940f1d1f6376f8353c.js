"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-tennis-exploration"],{81714(e,t,r){r.d(t,{K(){return l}});var i=r(41432),o=r(11796),a=r(52921),s=r(79811);class l extends o.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}getShouldShowSecondaryText(e){return e.cardSize!==i.uE._1x_1y&&!e.shouldHideSecondaryText}async getViewModel(e){const t=this.transformerProvider.config.skipFeedRefreshExploration,r=(0,s.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return{followLeagueClickHandler:t=>{this.transformerProvider.followClickEntityHandler({id:e.league.satoriId,yId:e.league.yId,name:e.league.name,type:o.XR.League,imageUrl:r},t,"",!0)},dislikeLeagueClickHandler:()=>{this.transformerProvider.hideClickHandler?.(e.league.id||"",t),this.transformerProvider.config.goToNextTabDelay&&t&&this.transformerProvider.goToNextTabIfExists()},shouldShowDislikeMessage:t,shouldShowSecondaryText:this.getShouldShowSecondaryText(e),followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:o.BP.FollowSports},!0),dislikeTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:o.BP.ExplorationDislike},a.YJ.Customize),isFollowed:this.isFollowed(e),telemetryConstants:e.telemetryConstants,reasonText:e.reasonText,secondaryText:e.secondaryText,logoUrl:(0,s.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced),cardSize:e.cardSize,logoPrimaryColor:e.logoPrimaryColor,isDisliked:e.isDisliked,leagueName:e.league.name,strings:{follow:this.transformerProvider.strings.follow,notInterested:this.transformerProvider.strings.iAmNotInterested,youFollowed:this.transformerProvider.strings.youAreNowFollowing,youDisliked:this.transformerProvider.strings.youWillSeeLessContent},telemetryObject:e.telemetryObject,telemetryTag:""}}isFollowed(e){return e.followedSports.get(e.league.satoriId||"")}}},87760(e,t,r){r.r(t),r.d(t,{SportsTennisTransformer(){return l}});var i=r(11796),o=r(79811),a=r(32150),s=r(96950);class l extends i.Bc{constructor(){super(...arguments),this.getShowMatchCount=e=>{switch(e){case"_1x_2y":case"medium":return 3;case"_1x_3y":case"large":return 5;default:return 1}},this.computeScore=e=>{if(!e)return"";const t=e.split(", "),r=/\((.*?)\)/i;let i,o="";return t.forEach(e=>{e.includes("(")?(o+=e.charAt(0),i=e.match(r),null!==i&&i.length>1&&(o+=i[1].sup()+"  ")):o+=e+"  "}),`${o.trim()}`},this.getGameDate=e=>(new Date).toDateString()===new Date(e).toDateString()?this.transformerProvider.strings.today:e}async transform(e){const t=this.getViewModel(e);return{viewTemplate:s.qy`
                <sports-tennis
                    :viewModel="${t}"
                ></sports-tennis>`}}getWinnerSvgUrl(e){const t=(0,o.jJ)()?"Light":"Dark",r=e.isExploration?"SportsWinnerTag2":"SportsWinnerTag";return`${(0,a.rA)().StaticsUrl}latest/sports/icons/${r}${t}.svg`}getViewModel(e){const t=this.getMatchData(e),r=e.cardSize;return{linkTarget:"_blank",matchData:t,showMatchCount:this.getShowMatchCount(r),isExploration:e.isExploration,winnerSvgUrl:this.getWinnerSvgUrl(e),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.Game})}}getMatchData(e){const t=e.matchData?.map(e=>e?.sportsMatchData)||[];return t.forEach(e=>{if(e){const t=e.participantOne||{},r=e.participantTwo||{};let s=e.gameDate;const l=(0,o.yn)(e.gameStartDateTime);s=(0,o.ry)(l,a.T3.CurrentMarket),e.gameStartTime=(e.gameStartDateTimeIsToBeAnnounced?null:(0,o.ry)(l,a.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,s=(0,o.AL)(l,a.T3.CurrentMarket),e.gameStateCatetory="string"!=typeof e.gameState?(0,o.m5)(e.gameState.state):e.gameStateCatetory,"string"!=typeof e.gameState&&(e.gamePeriodAndClock=(0,o.PH)(e.gameState)),e.gameState=e.gameStateCatetory===i.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:e.gameStateCatetory,t.isWinner=Boolean(t.isWinner),r.isWinner=Boolean(r.isWinner),t.imageUrl=(0,o.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),r.imageUrl=(0,o.iK)(r.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),e.gameCenterUrl&&(e.matchClickthroughUrl=(0,o.Ot)(e.gameCenterUrl)),t.score=this.computeScore(t.score||""),r.score=this.computeScore(r.score||""),e.gameDate=this.getGameDate(s||"")}}),t}}},28418(e,t,r){r.r(t),r.d(t,{SportsExplorationHeadTransformer(){return i.K},SportsTennisExplorationTransformer(){return l},SportsTennisTransformer(){return n.SportsTennisTransformer}});var i=r(81714),o=r(41432),a=r(11796),s=r(96950);class l extends a.Bc{async transform(e){const t=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <sports-tennis-exploration
                    :viewModel="${t}"
                ></sports-tennis-exploration>`}}async getCurrentViewModel(e){const[t,r]=await Promise.all([this.getExplorationHeadView(e),this.getTennisView(e)]);return{telemetryConstants:e.telemetryConstants,head:t,tennis:r,cardSize:e.cardSize,strings:{featuredGames:this.transformerProvider.strings.featuredGames},telemetryObject:e.telemetryObject,telemetryTag:""}}async getExplorationHeadView(e){const t={followedSports:e.followedSports,reasonText:e.reasonText,secondaryText:e.secondaryText,cardSize:e.cardSize,isDisliked:e.isDisliked,logoPrimaryColor:e.logoPrimaryColor,league:e.league,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants};return await this.transformerProvider.generateView(t,a.hi.ExplorationHead)}getMaxMatchesCount(e){switch(e.cardSize){case o.uE._1x_2y:return 1;case o.uE._1x_3y:return 3;default:return 0}}async getTennisView(e){const t=this.getMaxMatchesCount(e),r={matchData:e.matchList.slice(0,t),cardSize:e.cardSize,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,isExploration:!0};return await this.transformerProvider.generateView(r,a.hi.SportsTennis)}}var n=r(87760);Promise.resolve().then(r.bind(r,62727)),Promise.resolve().then(r.bind(r,65201)),Promise.resolve().then(r.bind(r,94941))},71372(e,t,r){r.d(t,{a(){return s}});var i=r(56911),o=r(92011),a=r(95144);let s=class extends o.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,i.Cg)([a.x],s)},65201(e,t,r){r.r(t),r.d(t,{SportsExplorationHead(){return M}});var i,o=r(56911),a=r(50180),s=r(60815),l=r(71372),n=r(95144);!function(e){e[e.Initial=0]="Initial",e[e.Followed=1]="Followed",e[e.Disliked=2]="Disliked"}(i||(i={}));let d=class extends l.a{constructor(){super(...arguments),this.followState=i.Initial}onFollowClick(e){this.viewModel.followLeagueClickHandler(e),this.followState=i.Followed}onDislikeClick(){this.viewModel.dislikeLeagueClickHandler(),this.viewModel.shouldShowDislikeMessage&&(this.followState=i.Disliked)}connected(){super.connected(),this.viewModel.isFollowed?this.followState=i.Followed:this.viewModel.isDisliked&&this.viewModel.shouldShowDislikeMessage&&(this.followState=i.Disliked)}getFollowElements(e,t,r){switch(this.followState){case i.Initial:return e;case i.Followed:return t;case i.Disliked:return r}}get youDislikedInnerHtml(){return(0,a.GP)(this.viewModel.strings.youDisliked,`<span class="league-name">${this.viewModel.leagueName}</span>`)}get youFollowedInnerHtml(){return(0,a.GP)(this.viewModel.strings.youFollowed,`<span class="league-name">${this.viewModel.leagueName}</span>`)}};(0,o.Cg)([s.sH],d.prototype,"followState",void 0),d=(0,o.Cg)([n.x],d);var c=r(92011),p=r(48751),g=r(37302),h=r(86856),x=r(70289),v=r(63033),u=r(74849);const f=u.A` :host{--sec-text-color:rgba(255,255,255,0.78);--dislike-bg-color:#292929;--dislike-border-color:#757575;--dislike-color:#FFFFFF;--dislike-bg-hover:#3D3D3D;--dislike-border-color-hover:rgba(255,255,255,0.06);--result-bg-color:#FFFFFF;--result-color:#2b2b2b}`,b=u.A`
`,m=u.A` :host{--sec-text-color:rgba(0,0,0,0.6);--follow-color:#FFFFFF;--follow-bg-color:#036AC4;--follow-bg-color-hover:#0473CE;--dislike-bg-color:rgba(255,255,255,0.46);--dislike-border-color:#D6D6D6;--dislike-border-color-hover:rgba(0,0,0,0.06);--result-bg-color:#292929;--result-color:#FFFFFF;--logo-wrap-border-color:#D6D6D6;--dislike-color:${p.l};--dislike-bg-hover:${g.Xt}}.reason-wrap{display:grid;grid-template-columns:50px 1fr;gap:6px;align-items:center;${x.f};pointer-events:none}.logo-wrap{margin:3px;border-radius:4px;display:flex;align-items:center;justify-content:center;width:44px;height:44px;box-sizing:border-box;border:1px solid var(--logo-wrap-border-color)}.logo{width:32px;height:32px}.reason-text,.sec-text{${x.f};pointer-events:none;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.reason-text{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;padding:3px 0px;color:${p.l}}.sec-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--sec-text-color);height:32px}.follow-wrap{display:flex;justify-content:space-between;margin-top:8px}.follow-btn,.dislike-btn{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:132px;border-radius:4px;height:22px;box-sizing:border-box;${x.f}}.btn-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;max-width:110px;padding:2px 0px 4px}.league-name{font-weight:600}.follow-btn{background-color:var(--follow-bg-color);color:var(--follow-color);border:0px;border:1px solid rgba(0,0,0,0)}.follow-btn:hover{background-color:var(--follow-bg-color-hover)}.plus{width:9px;height:9px}.dislike-btn{background-color:var(--dislike-bg-color);border:1px solid var(--dislike-border-color);color:var(--dislike-color)}.dislike-btn:hover{border-color:var(--dislike-border-color-hover) var(--dislike-border-color-hover) rgba(0,0,0,0.16) var(--dislike-border-color-hover);background-color:var(--dislike-bg-hover)}.disliked,.followed{background-color:var(--result-bg-color);color:var(--result-color);border-radius:4px;padding:3px 10px;width:268px;box-sizing:border-box;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${x.f};pointer-events:none}._1x_1y .reason-wrap{grid-template-columns:40px 1fr;height:40px}._1x_1y .logo{width:27px;height:27px}._1x_1y .logo-wrap{width:35px;height:35px}._1x_1y .reason-text{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px;color:${p.l}}._1x_1y .follow-wrap{margin-top:4px}`.withBehaviors(new h.t(null,b),new v.N(null,f));var w=r(96950),$=r(69259),k=r(32150);const y=w.qy`
    <div class="reason-wrap">
        <div class="logo-wrap" style="background-color: #${e=>e.viewModel.logoPrimaryColor}">
            <img src="${e=>e.viewModel.logoUrl}" class="logo">
        </div>
        <div class="reason-text">${e=>e.viewModel.reasonText}</div>
    </div>
`,z=w.qy`
    ${(0,$.z)(e=>e.viewModel.shouldShowSecondaryText,w.qy`
        <div class="sec-text">
            ${e=>e.viewModel.secondaryText}
        </div>
    `)}
`,F=w.qy`
    <fluent-button
        class="follow-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.follow}"
        aria-label="${e=>e.viewModel.strings.follow}"
        role="button"
        data-t="${e=>e.viewModel.followTelemetryTag}"
        @click="${e=>e.onFollowClick(!0)}"
    >
        <div class="btn-content">
            <img src="${(0,k.rA)().StaticsUrl}latest/shopping/plusw.svg" class="plus">
            ${e=>e.viewModel.strings.follow}
        </div>
    </fluent-button>
    <fluent-button
        class="dislike-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.notInterested}"
        aria-label="${e=>e.viewModel.strings.notInterested}"
        role="button"
        data-t="${e=>e.viewModel.dislikeTelemetryTag}"
        @click="${e=>e.onDislikeClick()}"
    >
        <div class="btn-content">
            ${e=>e.viewModel.strings.notInterested}
        </div>
    </fluent-button>
`,T=w.qy`
    ${e=>w.qy`
        <div class="followed">${w.qy.partial(e.youFollowedInnerHtml)}</div>
    `}
`,D=w.qy`
    ${e=>w.qy`
        <div class="disliked">${w.qy.partial(e.youDislikedInnerHtml)}</div>
    `}
`,S=w.qy`
    <div class="follow-wrap">
        ${e=>e.getFollowElements(F,T,D)}
    </div>
`,_=w.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${y}
        ${z}
        ${S}
    </div>
`,C=w.qy`
    ${(0,$.z)(e=>void 0!==e.viewModel,_)}
`;let M=class extends d{};M=(0,o.Cg)([(0,c.E)({name:"sports-exploration-head",template:C,styles:m,shadowOptions:{delegatesFocus:!0}})],M)},62727(e,t,r){r.r(t),r.d(t,{SportsTennisExploration(){return m}});var i=r(56911),o=r(71372);class a extends o.a{}var s=r(92011),l=r(70289),n=r(63033),d=r(74849),c=r(48751);const p=d.A` :host{--divider-color:rgba(255,255,255,0.06)}`,g=d.A` :host{--divider-color:rgba(0,0,0,0.06)}.divider{width:100%;height:1px;background-color:var(--divider-color);margin-bottom:8px;${l.f};pointer-events:none}.matches-wrap{margin-top:12px}.feat-games{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin-bottom:4px;color:${c.l};${l.f};pointer-events:none}`.withBehaviors(new n.N(null,p));var h=r(96950),x=r(69259);const v=h.qy`
    <sports-exploration-head
        :viewModel="${e=>e.viewModel.head.viewModel}"
    ></sports-exploration-head>
`,u=h.qy`
    ${(0,x.z)(e=>"_1x_1y"!==e.viewModel.cardSize,h.qy`
        <div class="matches-wrap">
            <div class="divider"></div>
            <div class="feat-games">${e=>e.viewModel.strings.featuredGames}</div>
            <div class="matches">
                ${e=>e.viewModel.tennis.viewTemplate}
            </div>
        </div>
    `)}
`,f=h.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${v}
        ${u}
     </div>
`,b=h.qy`
    ${(0,x.z)(e=>void 0!==e.viewModel,f)}
`;let m=class extends a{};m=(0,i.Cg)([(0,s.E)({name:"sports-tennis-exploration",template:b,styles:g,shadowOptions:{delegatesFocus:!0}})],m)},94941(e,t,r){r.r(t),r.d(t,{SportsTennis(){return D}});var i=r(56911),o=r(71372);class a extends o.a{onSizeChange(e){}onPaginate(e){}}var s=r(92011),l=r(48751),n=r(61138),d=r(86856),c=r(63033),p=r(50882),g=r(74849),h=r(22131);const x=g.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}`,v=g.A` .more-actions{right:16px;left:auto}.score-container{flex-direction:row}`,u=g.A` .more-actions{left:16px;right:auto}.score-container{flex-direction:row-reverse}`,f=g.A` :host{--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{display:flex;align-items:center;width:100%;text-decoration:none;color:${l.l}}.match-data{box-sizing:border-box;flex-direction:column;display:grid;row-gap:12px;padding-top:4px}.match-link{color:${l.l};text-decoration:none;z-index:2;overflow:hidden;padding:0px 8px 0px 12px;border-radius:6px;background:var(--sports-item-background)}.match-link:active{background:var(--sports-item-active-background)}.match-link a::after{position:absolute;content:"";bottom:0;top:0;left:0;right:0}.match-link:hover,.match-link:focus-visible{background:var(--sports-item-hover-background);border-radius:6px;overflow:hidden}.sports-match{align-items:center;display:flex;flex-direction:row;padding:0}.match-netural-bg{border-radius:6px;margin:0 12px;padding:4px}.match-participants{display:flex;flex-direction:column;padding:6px 0;width:196px;min-width:196px;gap:4px}.participant{align-items:center;display:flex;flex-direction:row;height:24px}.participant-image{height:24px;padding-inline-end:8px;width:24px}.participant-image img{width:100%}.participant-name{flex:1;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;padding-inline-end:8px;text-overflow:ellipsis;white-space:nowrap}.score-container{display:flex;flex-direction:row;align-items:center}.participant-score{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;padding-inline-end:4px;text-align:right;text-overflow:ellipsis;white-space:nowrap;left:-4px;position:relative}.game-time{font-weight:600}.match-details{font-size:${n.k};line-height:${n.F};width:56px;color:${l.l};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.detail-attributes{display:flex;flex-direction:column;flex:1;min-width:0;align-items:center}.team-style{padding-left:142px;padding-right:5px;width:20px;height:20px;display:inline-flex}.sports-team-image-style{width:9%}.vote-percent-style{padding-right:5px;padding-left:4px}.game-clock,.game-state,.game-date,.game-time,.game-tv-channel{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center;color:${l.l};font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.pre-game .game-time{min-width:60px}.inprogress-game .game-clock{color:#cc0000;font-weight:bold}.winner-tag{padding-inline-end:4px;width:5px;height:24px;max-height:24px;position:relative;left:-4px;display:flex;align-items:center}.winner-tag > svg > path{fill:currentColor}.winner .participant-name,.winner .participant-score{font-weight:600}.expl .match-link{background-color:var(--bg-color)}.expl .match-link:hover,.expl .match-link:focus-visible{background-color:var(--bg-color-hover)}.game-state{font-weight:600}.expl .winner-tag{height:27px}`.withBehaviors(new d.t(v,u),new c.N(null,x),(0,h.mr)(g.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.inprogress-game{color:${p.A.LinkText}}}`));var b=r(11796),m=r(96950),w=r(69259),$=r(39957),k=r(50180);const y=(e,t,r,i,o,a)=>m.qy`
    <div class="participant ${()=>t?"winner":""}">
        ${(0,w.z)(t=>e&&!(0,k.oT)(e),m.qy`
        <div class="participant-image" >
            <img role="presentation"
                src="${e}"
            />
        </div>`)}
        <div class="participant-name" title="${e=>i}">
            ${e=>i}
        </div>
        <div class="score-container">
        ${(0,w.z)(e=>r!=b.Xp.preGame,m.qy`
            <div class="participant-score">
                ${m.qy.partial(o)}
            </div>
            <div class="winner-tag">
            ${(0,w.z)(e=>t,m.qy`
                <img src=${e=>a} >
            `)}
            </div>
        `)}
        </div>
    </div>
`,z=m.qy`
    <a class="match-link match-neutral-link"
        href=${e=>e.matchClickthroughUrl?e.matchClickthroughUrl:void 0}
        target="${(e,t)=>t.parent.viewModel.linkTarget}"
        data-t="${(e,t)=>t.parent.viewModel.telemetryTag}"
    >
        <div class="sports-match long-score">
            <div class="match-participants">
                ${(e,t)=>y(e.participantOne?.imageUrl||"",e.participantOne?.isWinner&&e.gameStateCatetory===b.Xp.postGame||!1,e.gameStateCatetory,e.participantOne?.name||"",e.participantOne?.score||"",t.parent.viewModel.winnerSvgUrl)}
                ${(e,t)=>y(e.participantTwo?.imageUrl||"",e.participantTwo?.isWinner&&e.gameStateCatetory===b.Xp.postGame||!1,e.gameStateCatetory,e.participantTwo?.name||"",e.participantTwo?.score||"",t.parent.viewModel.winnerSvgUrl)}
            </div>
            <div class="match-details">
                ${(0,w.z)(e=>e.gameStateCatetory&&e.gameStateCatetory==b.Xp.preGame,m.qy`
                    <div class="detail-attributes pre-game">
                        <div class="game-date" title="${e=>e.gameDate}">
                            ${e=>e.gameDate}
                        </div>
                        <div class="game-time" title="${e=>e.gameStartTime}">
                            ${e=>e.gameStartTime}
                        </div>
                        <div class="game-channel" title="${e=>e.tvChannel}">
                            ${e=>e.tvChannel}
                        </div>
                    </div>
                `)}
                ${(0,w.z)(e=>e.gameStateCatetory&&e.gameStateCatetory==b.Xp.inprogressGame,m.qy`
                    <div class="detail-attributes inprogress-game">
                        <div class="game-clock" title="${e=>e.gamePeriodAndClock}">
                            ${e=>e.gamePeriodAndClock}
                        </div>
                        <div class="game-channel" title="${e=>e.tvChannel}">
                            ${e=>e.tvChannel}
                        </div>
                    </div>
                `)}
                ${(0,w.z)(e=>e.gameStateCatetory&&e.gameStateCatetory==b.Xp.postGame,m.qy`
                    <div class="detail-attributes post-game">
                        <div class="game-state" title="${e=>e.gameState}">
                            ${e=>e.gameState}
                        </div>
                        <div class="game-date" title="${e=>e.gameDate}">
                            ${e=>e.gameDate}
                        </div>
                    </div>
                `)}
            </div>
        </div>
    </a>
`,F=m.qy`
    ${(0,w.z)(e=>e.viewModel.matchData.length>0,m.qy`
        <div class="match-data ${e=>e.viewModel.isExploration?"expl":""}">
            ${(0,$.ux)(e=>e.viewModel.matchData.slice(0,e.viewModel.showMatchCount),z)}
        </div>`)}
`,T=m.qy`
    ${(0,w.z)(e=>null!=e.viewModel,F)}
`;let D=class extends a{};D=(0,i.Cg)([(0,s.E)({name:"sports-tennis",template:T,styles:f,shadowOptions:{delegatesFocus:!0}})],D)},99657(e,t,r){r.d(t,{D(){return s},I(){return a}});var i=r(68136);const{create:o}=i.G,a=o("sloppy-click-z-index",1),s=o("click-z-index",1)},38817(e,t,r){r.d(t,{R7(){return v},e(){return h},kc(){return x},nH(){return g}});var i=r(57416),o=r(55153),a=r(95239),s=r(26920),l=r(48751),n=r(64187),d=r(22131),c=r(74849),p=r(50882);const g=c.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,h=c.A` ${(0,n.V)("flex")} :host{background:${a.p};outline:calc(${s.XA} * 1px) solid ${o.cu};border-radius:calc((${i.JU} - ${s.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${l.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${s.XA} * 1px) ${o.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${o.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${o.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${o.QG} * 1px);height:calc(${o.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${o.QG} * 1px);height:calc((${o.l8} * 2px) + (${o.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${o.QG} * 2px) + (${o.Sn} * 1px));height:calc((${o.l8} * 2px) + (${o.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${o.QG} * 2px) + (${o.Sn} * 1px));height:calc(${o.l8} * 1px)}::slotted(*){color:inherit}`,x=(0,d.mr)(c.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),v=c.A` ${h} ${g} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(x)},70289(e,t,r){r.d(t,{f(){return n}});var i=r(64187),o=r(74849),a=r(38817),s=r(99657),l=r(36452);const n=o.A.partial`position: relative; z-index: ${s.D};`;o.A` ${a.e} ${a.nH} ${(0,i.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${n}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${l.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${l.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${l.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(a.kc)}}]);