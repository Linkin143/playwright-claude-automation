"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_recipes-sd-card_src_index_ts"],{25314(e,i,t){t.r(i),t.d(i,{RecipesSdCard(){return L},RecipesSdCardStyles(){return re},RecipesSdCardTemplate(){return Q},ToolingInfo(){return ne}});var a=t(12375),s=t(4731),r=t(37180),n=t(41555),o=t(17704),c=t(23329),l=t(55672),h=t(86385),d=t(61473),p=t(56911),m=t(10146),u=t(87906),g=t(5141),b=t(16250),f=t(98378);const w="RecipesCard",v="RecipesCard_recipe",y="RecipesCard_seemore",x="RecipesCard_customization",T="RecipesCard_customization_report",C="RecipesCard_customization_hide",k="RecipesCard_customization_moresettings",R="RecipesCard_BowheadPipeline",S="RecipesCard_Customization";var U=t(3583),P=t(65403),$=t(76506);const D={Id:null,Type:"recipe-card",data:'[{"Title":"Make-Ahead Cranberry Sauce","PreperationTime":"30 min","ServingPerRecipe":"2","Rating":"4.5","RatingScale":"5","ReviewCount":"188","Calories":"676","Domain":"www.foodnetwork.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%228a03d8b3e2a54e61c6dc98aa0a986ba7%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailId":"OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.foodnetwork.com/recipes/ina-garten/make-ahead-cranberry-sauce-3160641","DisplayName":"Food Network"},{"Title":"The Ultimate Potato Soup Recipe","PreperationTime":"30 min","ServingPerRecipe":"8","Rating":"4.98","RatingScale":"5","ReviewCount":"7","Calories":"521","Domain":"sugarspunrun.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%229030ec38b5ae70711df71d680465269c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailId":"OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://sugarspunrun.com/creamy-potato-soup-recipe/","DisplayName":"Sugar Spun Run"},{"Title":"Arancini","Rating":"0","ReviewCount":"0","Calories":"549","Domain":"www.jamieoliver.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%224e425609c043ea522fbaa3d26d9fddc4%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.4c44689e1151c802c5955998fef49e55","ThumbnailId":"OSK.4c44689e1151c802c5955998fef49e55","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.jamieoliver.com/recipes/rice/arancini/","DisplayName":"Jamie Oliver"},{"Title":"Ultimate Slow Cooker Pot Roast","PreperationTime":"8 hr 15 min","ServingPerRecipe":"8","Rating":"4.86","RatingScale":"5","ReviewCount":"344","Calories":"498","Domain":"dinnerthendessert.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%2258a799e3cf5f1360978f4a2ecca44567%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailId":"OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://dinnerthendessert.com/ultimate-slow-cooker-pot-roast/","DisplayName":"Dinner Then Dessert"},{"Title":"BEST Chicken Salad","PreperationTime":"4 hr 15 min","ServingPerRecipe":"8","Rating":"4.92","RatingScale":"5","ReviewCount":"6","Calories":"360","Domain":"www.daringgourmet.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22644dc0f93ab206b3e98cd3dc637fe29c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailId":"OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.daringgourmet.com/classic-chicken-salad/","DisplayName":"Daring Gourmet"},{"Title":"Candied Yams Recipe","PreperationTime":"40 min","ServingPerRecipe":"6","Rating":"4.42","RatingScale":"5","ReviewCount":"48","Calories":"443","Domain":"www.lovebakesgoodcakes.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22597b08b323cf9890ba96834721503fac%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailId":"OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.lovebakesgoodcakes.com/candied-yams-recipe/","DisplayName":"Love Bakes Good Cakes"},{"Title":"Vegan Gluten Free Cupcakes","PreperationTime":"17 min","ServingPerRecipe":"12","Rating":"5","RatingScale":"5","ReviewCount":"7","Calories":"177","Domain":"thebigmansworld.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22eec3abe61e2eae837878e4efc30f3453%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailId":"OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://thebigmansworld.com/vegan-chocolate-cupcakes/","DisplayName":"The Big Man\'s World"},{"Title":"The Best Classic Zucchini Bread Recipe","PreperationTime":"1 hr 5 min","ServingPerRecipe":"12","Rating":"4.97","RatingScale":"5","ReviewCount":"15","Calories":"214","Domain":"www.thewholesomedish.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22fb2e1c1e25b956b0a1183c1c18c1fe1d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailId":"OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thewholesomedish.com/the-best-classic-zucchini-bread/","DisplayName":"The Wholesome Dish"},{"Title":"One Pot Chicken Parmesan Pasta","PreperationTime":"30 min","ServingPerRecipe":"6","Rating":"4.61","RatingScale":"5","ReviewCount":"10","Calories":"582","Domain":"www.thechunkychef.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22dac84e545711b27c7564cd2eba21444d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailId":"OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thechunkychef.com/one-pot-chicken-parmesan-pasta/","DisplayName":"The Chunky Chef"}]',DataType:null,Version:1,Previews:null,Badges:null,Metadata:{market:"en-us",language:"en",region:"us"},PreviewsV2:null,IsSkipped:null,PulseData:null,ClusterIds:null,AdditionalNewsContent:[],message:"",BowheadMetadata:{PipelineTag:"TEST"},debugLogs:[]};var O=t(60815),H=t(79713),z=t(32150),I=t(9960);const F=e=>`${(0,z.rA)().StaticsUrl}latest/recipes/${e}`,_=()=>F(`recipes-icon.${(0,I.ud)()?"dark":"light"}.svg`);var N=t(88651),j=t(12360),B=t(71843),K=t(44704);class L extends P.U{constructor(){super(),this.dataType="RecipesSdCard",this.isActionMenuOpen=!1,this.recipes=[],this.seeMoreUrl=new URL('https://www.bing.com/search?q=Popular Recipes&filters=userscenario:"dsb" ForceHighConfRecipe:"true"'),this.childTelemetryObjects={},this.market=m.Rb?.Locale??"en-us",this.version="superSDCard",this.pageNumber=0,this.maxRecipeNumber=4}experienceConnected(){try{(0,$.uC)(this.config.cardActionWC)}catch(e){(0,u.c_)(e,g.TQ$,"Failed to load cardActionWc")}try{const e=this.mapperArgs?.cardMetadata??D;this.loadData(e)}catch(e){(0,u.c_)(e,g.TQ$,"Failed to load cardMetaData",e),this.recipes=null,this.pipelineName=null}this.maxRecipeNumber=this.recipes.length??0,this.dataIsValid(this.recipes)&&(this.setupTelemetryObjects(),this.initSuperSDSetting(),this.loadUI())}getLocalizedPreparationTime(e){if(!e)return"";const i=e.split(" ");if(2===i.length){const e="min"===i[1]?this.strings.minutes:this.strings.hours;return`${i[0]} ${e}`}return`${i[0]} ${this.strings.hours} ${i[2]} ${this.strings.minutes}`}loadData(e){if(!e)return;const i=JSON.parse(e.data);for(let e=0;e<this.maxRecipeNumber;e++){const t=i[e].ClickThroughUrl,a=new URL(t);a.searchParams.has("setmkt")&&this.seeMoreUrl.searchParams.set("setmkt",a.searchParams.get("setmkt")),a.searchParams.has("setlang")&&this.seeMoreUrl.searchParams.set("setlang",a.searchParams.get("setlang")),a.searchParams.has("cc")&&this.seeMoreUrl.searchParams.set("cc",a.searchParams.get("cc")),a.searchParams.has("q")&&this.seeMoreUrl.searchParams.set("q",a.searchParams.get("q")),this.recipes.push({href:a.toString(),thumbnailUrl:this.getRecipeThumbnailUrl(i[e].Thumbnail),thumbnailId:i[e].Thumbnail.ThumbnailId,name:i[e].Title,hasVideo:!1,siteName:i[e].Domain,siteUrl:i[e].Domain,preparationTime:this.getLocalizedPreparationTime(i[e].PreperationTime),calorieContent:i[e].Calories,starRating:i[e].Rating,displayName:i[e].DisplayName})}this.pipelineName=e.BowheadMetadata?.PipelineTag??R}loadUI(){this.cardTelemetryObject?this.cardTelemetryObject.contract=(0,N.u)(this.dataType??"",{type:f.b5.StructuredData,vertical:"Recipe"},{ext:{...this.parentTelemetry?.contract?.ext,...this.telemetryObject?.contract?.ext,recipeList:this.recipes.map(e=>this.getSatoriId(e?.href)),signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)}}):this.cardTelemetryObject=(0,j.g)(this.dataType??"",{type:f.b5.StructuredData,vertical:"Recipe"},{ext:{...this.parentTelemetry?.contract?.ext,...this.telemetryObject?.contract?.ext,recipeList:this.recipes.map(e=>this.getSatoriId(e?.href)),signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)}}),this.sdData={id:this.id,isSpotlightCard:!0,cardSize:"_1x_2y",childTemplateType:"",headerData:{headerLogo:`<img src=${_()} alt="" />`,title:this.strings.title,titleNavigationLink:this.seeMoreUrl.toString(),actionMenuData:{hideCardCallback:this.hideCardCallback.bind(this),moreSettingsPersonalizeCallback:this.moreSettingsCallback.bind(this)},telemetryContext:{headerTelemetryObject:this.getChildTelemetry({name:"header",action:f.EG.Click,behavior:f.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),headerTitleTelemetryObject:this.getChildTelemetry({name:"headertitle",action:f.EG.Click,behavior:f.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()})?.getMetadataTag(),headerLogoTelemetryTag:this.getChildTelemetry({name:"headerlogo",action:f.EG.Click,behavior:f.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()})?.getMetadataTag(),pinTelemetryTag:this.getChildTelemetry({name:"pin",action:f.EG.Click,behavior:f.MS.Pin}),actionMenuTelemetryTag:this.getChildTelemetry({name:"actionmenu",action:f.EG.Click,behavior:f.MS.ContextMenu}),hideCard:this.getChildTelemetry({name:"hidecard",action:f.EG.Click,behavior:f.MS.Hide}),moreSettings:this.getChildTelemetry({name:"moresettings",action:f.EG.Click,behavior:f.MS.More})}},footerData:{footerLink:{text:this.strings.seeMore,navigationUrl:this.seeMoreUrl.toString()},paginationData:{currentPageIndex:this.pageNumber+1,pageCount:this.maxRecipeNumber,onFlipperClick:this.dataPaginationCallback.bind(this),onDotClick:(e,i)=>{this.pageNumber=e,this.loadUI()}},telemetryContext:{footerLink:this.getChildTelemetry({name:"footerlink",action:f.EG.Click,behavior:f.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),previousFlipper:this.getChildTelemetry({name:"previous",action:f.EG.Click,behavior:f.MS.Paginate}),nextFlipper:this.getChildTelemetry({name:"next",action:f.EG.Click,behavior:f.MS.Paginate})}},contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:null,telemetryContext:{contentCard:this.getChildTelemetry({name:"SuperSDCard"})}}}isHidden(e){return e!=this.pageNumber}setupTelemetryObjects(){if(null==this.telemetryObject)return;const e=this.parentTelemetry?.contract?.ext;this.recipesTelemetryObject=(0,j.g)(w,{id:w,type:f.b5.StructuredData},f.MS.View,f.EG.View,{...e,signature:this.getSatoriId(this.recipes[this.pageNumber]?.href)},{type:f.MJ.Module}),this.wholeCardTelemetryTag=this.recipesTelemetryObject.getMetadataTag();for(let i=0;i<this.maxRecipeNumber;i++)this.recipes[i].telemetryTag=(0,j.g)(v,{id:this.recipes[i].entityId,type:f.b5.StructuredData,headline:this.recipes[i].name},f.MS.Navigate,f.EG.Click,e,{type:f.MJ.ContentCard}).getMetadataTag();this.seeMoreTelemetryTag=(0,j.g)(y,{id:y,type:f.b5.StructuredData,headline:y},f.MS.Navigate,f.EG.Click,e,{type:f.MJ.Footer}).getMetadataTag(),this.actionsMenuTelemetryTag=(0,j.g)(x,{id:x,type:f.b5.StructuredData,headline:x},f.MS.More,f.EG.Click,e,{type:f.MJ.ActionButton}).getMetadataTag(),this.recipesReportTelemetryObject=(0,j.g)(T,{id:T,type:f.b5.StructuredData,headline:T},f.MS.Report,f.EG.Click,e,{type:f.MJ.ActionButton}),this.pipelineTelemetryTag=(0,j.g)(R,{id:R,type:f.b5.StructuredData,headline:this.pipelineName},f.MS.View,f.EG.View,e,{type:f.MJ.ContentCard}).getMetadataTag(),this.customizeTelemetryTag=(0,j.g)(S,{type:f.b5.StructuredData,headline:"More options"},f.MS.More,{ext:e}).getMetadataTag(),this.reportTelemetryTag=this.recipesReportTelemetryObject.getMetadataTag(),this.moreSettingTelemetryTag=(0,j.l)(k,{id:k,type:f.b5.StructuredData,headline:k},f.MS.Navigate,f.EG.Click,f.MJ.ActionButton).getMetadataTag(),this.hideCardTelemetryTags=(0,j.l)(C,{id:C,type:f.b5.StructuredData,headline:C},f.MS.Hide,f.EG.Click,f.MJ.ActionButton).getMetadataTag()}shadowDomPopulated(){try{this.cardActionRef=this.shadowRoot?.querySelector?.("card-action"),this.markVisuallyReadyRaf()}catch(e){(0,u.c_)(e,g.TQ$,"Failed to get cardActionRef")}}getSatoriId(e){return new URLSearchParams(e).get("filters")?.split(" ")[0]?.split("sid:")?.[1]?.slice(1,-1)??""}getExperienceType(){return d.Lz8}getRecipeThumbnailUrl(e){return e&&e.ThumbnailUrl?"https://www.bing.com"+e.ThumbnailUrl:"https://www.bing.com/th?id=empty"}async hideCardCallback(){try{await H.d.updateSegmentCardsEnableStatus([{cardType:U.s.RecipesCard,enabled:!1}])&&(this.mapperArgs?.refreshSDCardSection?this.mapperArgs.refreshSDCardSection():this.$emit("refreshSDCardSection"))}catch(e){(0,u.c_)(e,g.fKW,"Failed to call pdp service to hide card")}}moreSettingsCallback(){this.mapperArgs?.goToPersonalizeSettingsCallback?this.mapperArgs.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")}initSuperSDSetting(){const e={moreSetting:{title:this.strings.moreSettings,telemetryTag:this.moreSettingTelemetryTag},hideSetting:{title:this.strings.hideCard,telemetryTag:this.hideCardTelemetryTags}};this.superSDSetting=new b.t(L,U.s.RecipesCard,e,this.goToPersonalizeSettingsCallback,this.refreshSDCardSection)}getChildTelemetry(e){return this.childTelemetryObjects?.[e.name]?this.childTelemetryObjects[e.name].contract=(0,B.C)(e?.name,e?.behavior,e?.action,{...this.cardTelemetryObject?.contract?.ext,...e.ext},{destinationUrl:e?.destinationUrl}):this.childTelemetryObjects[e.name]=(0,K.u)(e?.name,e?.behavior,e?.action,{...this.cardTelemetryObject?.contract?.ext,...e.ext},{destinationUrl:e?.destinationUrl}),this.childTelemetryObjects[e.name]}dataPaginationCallback(e){const i=this.recipes.length||1,t=(this.pageNumber+(e?1:-1)+i)%i;this.pageNumber=t,this.loadUI()}handleNext(){this.pageNumber=(this.pageNumber+1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}handlePrev(){this.pageNumber=(this.pageNumber+this.maxRecipeNumber-1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}dataIsValid(e){if(!Array.isArray(e)||e.length<this.maxRecipeNumber)return!1;for(const i of e)if(!i.href||!i.name)return!1;return e.length>=0}}(0,p.Cg)([O.sH],L.prototype,"isActionMenuOpen",void 0),(0,p.Cg)([O.sH],L.prototype,"actionMenuItems",void 0),(0,p.Cg)([O.sH],L.prototype,"superSDSetting",void 0),(0,p.Cg)([O.sH],L.prototype,"sdData",void 0),(0,p.Cg)([O.sH],L.prototype,"customizeTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"reportTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"moreSettingTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"hideCardTelemetryTags",void 0),(0,p.Cg)([O.sH],L.prototype,"pageNumber",void 0),(0,p.Cg)([O.sH],L.prototype,"currentPage",void 0);var V=t(96950),q=t(39957),M=t(69259);const E=V.qy` ${(0,q.ux)(e=>e.recipes.slice(e.pageNumber,e.pageNumber+1),V.qy`<div class="recipe_supersd_content"><a class="recipe" href="${e=>e.href}" target="_blank" @click=${(e,i)=>i.parent.handleClickCard(i.event)} data-t="${e=>e.telemetryTag}"><div class="${e=>e.hasVideo?"video":""}"><img src="${e=>e.thumbnailUrl}" alt="${e=>e.name}" height=126px width=268px /></div><div class="metadata"><div class="site">${e=>e.displayName||e.siteName}</div><div class="name" title=${e=>e.name}>${e=>e.name}</div><div class="recipe-info">${(0,M.z)(e=>e.starRating,V.qy`<div class="rating"><img class="star-icon" src="${`${(0,z.rA)().StaticsUrl}latest/fluent-icons/star_16_filled.svg`}" alt="Star Icon"/><div>${e=>Number.isInteger(Number(e.starRating))?Number(e.starRating).toFixed(1):e.starRating}</div></div>`)} ${(0,M.z)(e=>e.calorieContent||e.preparationTime,V.qy`<div class="recipe-details">${(0,M.z)(e=>e.preparationTime,V.qy`<div class="preparation-time">${e=>e.preparationTime}</div>`)} ${(0,M.z)(e=>e.calorieContent&&e.preparationTime,V.qy`<div class="dot">·</div>`)} ${(0,M.z)(e=>e.calorieContent,V.qy`<div class="nutritional-value">${(e,i)=>`${e.calorieContent} ${i.parent.strings?.calorieUnit||"cals"}`}</div>`)}</div>`)}</div></div></a></div>`)}
`,W=V.qy`<responsive-sd-card :data="${e=>e.sdData}" data-t=""><div class="container" slot="card-content">${E}</div></responsive-sd-card>`,Q=V.qy`<div class="root" data-t="${e=>e.wholeCardTelemetryTag}">${W}</div>`;var X=t(57416),A=t(64003),G=t(48751),Z=t(86856),J=t(74849),Y=t(22131),ee=t(70289);const ie=J.A`
    .star-icon{
        --invertStarIcon: 64.84%; // #adadad
    }
`,te=J.A`
    .star-icon{
        --invertStarIcon: 14.2%; // #242424
    }
`,ae=J.A` .more-options{right:10px}.v2 .more-options{right:16px}`,se=J.A` .more-options{left:10px}.v2 .more-options{right:16px}`,re=J.A`
:host{border-radius:calc(${X.JU} * 1px);font-family:"Segoe UI";font-size:12px;line-height:16px}@media (prefers-color-scheme:light){.v1,.v2{h5,.site,.disclaimer{color:${A.c}}.name{color:${G.l}}}.root.rootv2{background:linear-gradient(144.59deg,rgba(200,220,243,0.1) 0%,rgba(200,220,243,0.4) 88.78%)}}@media (prefers-color-scheme:dark){.v1,.v2{.site,.disclaimer{color:${A.c}}h5,.name{color:${G.l}}}.root.rootv2{background:linear-gradient(122.3deg,rgba(28,46,68,0.4) 0%,rgba(28,46,68,0.8) 84.48%)}}h5{margin:0;margin-bottom:24px;padding:0;height:16px;font-size:12px}a{text-decoration:none}.recipe{margin:16px 0;height:90px;display:flex;column-gap:12px}img{object-fit:cover;border-radius:calc(${X.JU} * 1px);
}

.video {
    position: relative;
}

.video::after {
    content: ' ';
    position: absolute;
    top: 4px;
    left: 4px;
    height: 20px;
    width: 20px;
    z-index: 1;
    background-size: 20px 20px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.metadata {
    min-width: 0;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v1 .name,
.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.recipes-footer {
    display: flex;
    justify-content: center;
}

.sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
}

.toggle-button {
    position: absolute;
    top: 12px;
    right: 10px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

.more-options {
    position: absolute;
    top: 12px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

msn-actions-menu {
    z-index: 700;
}

.rootV2 {
    user-select: none;
    padding: 16px 16px 12px;
    background: linear-gradient(144.59deg, rgba(200, 220, 243, 0.1) 0%, rgba(200, 220, 243, 0.4) 88.78%);
}

.v2 {
    height: 276px;
}

.v2 h5 {
    margin: 0;
    margin-bottom: 8px;
    padding: 0;
    height: 16px;
    font-size: 12px;
}

.v2 a {
    text-decoration: none;
}

.v2 a:hover .name {
    text-decoration: underline;
}

.v2 .recipe {
    height: 90px;
    display: initial;
}

.v2 img {
    object-fit: cover;
    border-radius: calc(${X.JU} * 1px);
}

.v2 .video {
    position: relative;
}

.v2 .video::after {
    content: ' ';
    position: absolute;
    top: 42px;
    left: 114px;
    height: 40px;
    width: 40px;
    z-index: 1;
    background-size: 40px 40px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="40" height="40" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.v2 .metadata {
    min-width: 0;
    margin-top: 12px;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.v2 .recipes-footer {
    position: absolute;
    bottom: 12px;
    display: flex;
    justify-content: space-between;
    width: 268px;
    height: 24px;
    line-height: 24px;
}

.v2 .recipes-footer .button {
    width: 24px;
    height: 24px;
    border-radius: 1000px;
}

.prev-button, .next-button {
    background: #00000012;
    float: left;
}

.v2 .prev-button svg {
    margin: 8px 10px 8px 9px;
}

.v2 .next-button svg {
    margin: 8px 9px 8px 10px;
}

.v2 .page-number {
    margin: 0 8px;
    float: left;
}

.v2 .sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
    background-color: transparent;
}

.v2 .see-more-text {
    float: left;
}

.v2 .recipes-footer .see-more-button {
    float: right;
    margin-left: 8px;
    background: #0078D4;
}

.v2 .recipes-footer .see-more-button svg {
    margin: 8px 7px;
}

.recipe_supersd_content {
    position: absolute;
    width: 268px;
    ${ee.f} .recipe{display:flex;flex-direction:column;row-gap:16px;margin:0;height:auto;.metadata{color:${G.l};display:flex;flex-direction:column;row-gap:6px;.name{overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:1;white-space:nowrap;font-size:14px;font-style:normal;font-weight:600;line-height:20px}.recipe-info{display:flex;column-gap:8px;align-items:center;font-size:12px;color:var(--color-neutral-foreground-3);font-family:"Segoe UI";.rating{display:flex;justify-content:space-between;height:24px;padding:0px 6px 0px 4px;align-items:center;gap:2px;background-color:var(--color-neutral-background-2);border-radius:4px;font-weight:600;.star-icon{filter:invert(var(--invertStarIcon,0))}}.recipe-details{display:flex;align-items:center;column-gap:4px;font-style:normal;font-weight:400}}}}}`.withBehaviors((0,Y.G2)(ie),(0,Y.C7)(te),new Z.t(ae,se)),ne={experienceConfigSchema:undefined},oe=d.Lz8;h.p&&l.L.registerExperience(oe,()=>Promise.resolve().then(t.bind(t,25314))),s.m.define(r.c.registry),n.m.define(r.c.registry),o.m.define(r.c.registry),c.m.define(r.c.registry),(0,a.d)()}}]);