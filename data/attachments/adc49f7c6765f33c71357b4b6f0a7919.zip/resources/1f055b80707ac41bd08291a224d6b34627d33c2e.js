"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-match-list"],{14472:function(e,t,s){s.r(t),s.d(t,{SportsMatchListTransformer:function(){return r}});var o=s(23305),a=s(89757),i=s(79811);class r extends o.Bc{async transform(e){let t=await this.getCurrentViewModel(e);return{viewTemplate:(0,a.qy)`
                <sports-match-list
                    :viewModel="${t}"
                ></sports-match-list>`}}async getCurrentViewModel(e){let t=await this.getMatches(e,e.reason);return{matches:t,isIncomplete:e.isCopilotTheme&&t.length<e.numberOfMatches,cardSize:e.cardSize,paginationStyle:"",reason:e.reason,showParticipantAddIcon:!1,tabIndex:0,telemetryTag:"",isCopilotTheme:e.isCopilotTheme}}async getMatches(e,t){if(!e.sportsMatchOverallData)return[];let s=e.followedSports||new Map,a=(0,i.Yo)(e.sportsMatchOverallData),r=e.sportsMatchOverallData.slice(0,e.numberOfMatches).map(async r=>{let n=r.sportsMatchData,l=(0,i.gK)(n.participantOne,s),c=(0,i.gK)(n.participantTwo,s),p={matchData:r,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:l,participantTwoFollowed:c,topDetailText:e.matchTopDetailText,isContainLiveMatch:a,reason:t,enableLiveScores:this.transformerProvider.config.enableLiveScores,cardSize:e.cardSize,showMatchUXV2:e.showMatchUXV2,isCopilotTheme:e.isCopilotTheme,isMitUX:e.isMitUX};return this.transformerProvider.generateView(p,o.hi.SportsMatch)});return(await Promise.all(r)).filter(i.z2)}}},35908:function(e,t,s){s.r(t),s.d(t,{SportsMatchListTransformer:function(){return o.SportsMatchListTransformer},SportsMatchTransformer:function(){return a.SportsMatchTransformer}});var o=s(14472),a=s(82724);Promise.resolve().then(s.bind(s,83322)),Promise.resolve().then(s.bind(s,4708))},83322:function(e,t,s){s.r(t),s.d(t,{SportsMatchList:function(){return u}});var o=s(56911),a=s(71372);class i extends a.a{}var r=s(92011),n=s(59669),l=s(61138),c=s(63033);let p=(0,n.A)`
`,h=(0,n.A)` .sports-match-list{row-gap:12px;display:grid}.reason.sports-match-list{row-gap:8px}.reason-text{font-size:${l.k};line-height:${l.F};font-weight:600;padding-bottom:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;position:relative}.sports-match-list._15u{row-gap:0;height:272px}.sports-match-list._15u.incomplete{height:252px;padding-top:20px}.sports-match-list._15u.copilot-theme{row-gap:10px;align-items:center}`.withBehaviors(new c.N(null,p));var m=s(89757),d=s(69259),w=s(68835);let v=(0,m.qy)`
    <div class="sports-match-list ${e=>e.viewModel.paginationStyle} ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>"1.5u"===e.viewModel.cardSize?"_15u":""} ${e=>e.viewModel.isIncomplete?"incomplete":""} ${e=>e.viewModel.isCopilotTheme?"copilot-theme":""}"
    >
        ${(0,d.z)(e=>!e.viewModel.isCopilotTheme&&e.viewModel.reason,(0,m.qy)`<div class="reason-text">
            ${e=>e.viewModel.reason}
        </div>`)}
        ${(0,w.ux)(e=>e.viewModel.matches,(0,m.qy)`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>
        `,{positioning:!0})}
    </div>
`,M=(0,m.qy)`
    ${(0,d.z)(e=>void 0!=e.viewModel,v)}
`,u=class extends i{};u=(0,o.Cg)([(0,r.E)({name:"sports-match-list",template:M,styles:h,shadowOptions:{delegatesFocus:!0}})],u)}}]);