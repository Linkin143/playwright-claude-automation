"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-country"],{54467(e,t,i){i.r(t),i.d(t,{SportsEventCountryTransformer(){return c}});var o=i(41432),r=i(11796),n=i(79811),s=i(96950),a=i(32150),l=i(87906),d=i(33335);class c extends r.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,n.jJ)();const i=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <sports-event-country
                    :viewModel="${i}"
                ></sports-event-country>`}}isFollowed(e){return e.followedSports&&e.followedSports.get(e.data?.teamMedalCount?.team?.satoriId||"")}getLeagueLogoUrl(e){return e?(0,n._K)((0,n.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced),58,58,!0):this.getTeamImageFallback()}getTeamImageFallback(){return`${(0,a.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}async getCurrentViewModel(e){const{telemetryBuilder:t,strings:i}=this.transformerProvider;if(!e.data?.teamMedalCount)return void(0,l.vV)(d.Ax,"Sports Event Country data missing",`market=${a.T3.CurrentMarket}`,JSON.stringify(e));const o=e.data?.teamMedalCount?.team||{},s=this.getLeagueLogoUrl(o.imageId),c=(0,n.Ot)(e.data?.clickThroughUrl);return(0,n.Hn)(o.hasExplicitInterest)&&!this.isFollowed(e)&&e.followedSports?.set(o.satoriId,!0),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,strings:i,teamMedalCount:e.data?.teamMedalCount,leagueLogoUrl:s,listView:await this.getListView(e),followLeagueClickHandler:e=>{o.hasExplicitInterest=e,this.transformerProvider.followClickEntityHandler({id:o.satoriId,yId:o.yId,name:o.name,type:r.XR.League,imageUrl:s},e,c)},destinationUrl:c,isFollowed:this.isFollowed(e),followTelemetryTag:t.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.SportsEventCountryCard,brandId:"SportsEventCountryCard",headline:r.BP.SportsEventCountryCard,id:1,signature:e.telemetryConstants.signature},!0),unFollowTelemetryTag:t.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.SportsEventCountryCard,brandId:"SportsEventCountryCard",headline:r.BP.SportsEventCountryCard,id:1,signature:e.telemetryConstants.signature},!1),telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsEventCountryCard})}}async getListView(e){if(this.cardSize===o.uE._1x_1y)return;const{recentMedals:t}=e.data||{};return t&&t.length>0?await this.transformerProvider.generateView(e,r.hi.SportsRecentMedal):await this.transformerProvider.generateView(e,r.hi.SportsEventSchedule)}}Promise.resolve().then(i.bind(i,82435)),Promise.resolve().then(i.bind(i,15146))},20517(e,t,i){i.d(t,{z(){return s}});var o=i(56911),r=i(60815),n=i(92011);class s extends n.L{}(0,o.Cg)([r.sH],s.prototype,"viewModel",void 0)},71372(e,t,i){i.d(t,{a(){return s}});var o=i(56911),r=i(92011),n=i(95144);let s=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,o.Cg)([n.x],s)},82435(e,t,i){i.r(t),i.d(t,{SportsEventCountry(){return T}});var o=i(56911),r=i(71372),n=i(60815),s=i(50180);class a extends r.a{constructor(){super(...arguments),this.isFollowed=!1}connected(){super.connected(),this.isFollowed=this.viewModel.isFollowed}onFollowClick(){this.viewModel.followLeagueClickHandler(!this.isFollowed),this.isFollowed=!this.isFollowed}getFollowButtonIconName(){return this.isFollowed?"OlympicFollow":this.viewModel.isDarkModeTheme?"CircleAddLargeDark":"CircleAddLarge"}getFollowItemButtonTitle(){return(0,s.GP)(this.viewModel.isFollowed?this.viewModel.strings?.haveFollowed:this.viewModel.strings?.followSports,this.viewModel.teamMedalCount?.team?.name||"")}followButtonTelemetry(){return""}getMedalCountList(){const e=this.viewModel.teamMedalCount?.medalsWon;return[{name:this.viewModel.strings?.gold,medal:"Gold",count:e?.Gold},{name:this.viewModel.strings?.silver,medal:"Silver",count:e?.Silver},{name:this.viewModel.strings?.bronze,medal:"Bronze",count:e?.Bronze}]}}(0,o.Cg)([n.sH],a.prototype,"isFollowed",void 0);var l=i(92011),d=i(48751),c=i(86856),p=i(70289),h=i(63033),g=i(74849);const x=g.A` .sports-follow-icon::before{background-color:rgba(0,0,0,0.5)}.sports-event-country-follow{color:rgba(255,255,255,0.9)}.icon-add-light{display:none}.icon-add-dark{display:block}`,u=g.A`
`,m=g.A` .sports-follow-icon{margin:1px auto 0 4px}`,f=g.A` .sports-event-country-card{${p.f};width:268px;color:${d.l};text-decoration:none}._1x_1y .sports-event-country-card{height:65px}._1x_2y .sports-event-country-card{height:230px}._1x_3y .sports-event-country-card{height:380px}.sports-event-country-follow{display:flex;flex-direction:column;align-items:center;margin-bottom:4px}.sports-country-follow{display:flex;width:100%;align-items:center;margin-bottom:6px}.sports-country-content{display:flex;align-items:center;justify-content:center;color:${d.l};font-size:15px;font-weight:600;overflow:hidden}.sports-country-icon{width:24px;height:24px;margin:0 8px 0 0}.sports-follow-icon{position:relative;cursor:pointer;margin:0 -2px 0 auto;width:24px;height:24px;border:none;background:none;padding:0;border-radius:50%;overflow:hidden;display:flex;justify-content:center;align-items:center}.sports-follow-icon::before{content:'';position:absolute;top:50%;left:50%;width:18px;height:18px;background-color:rgba(255,255,255,0.9);border-radius:50%;transform:translate(-50%,-50%)}.icon-selected{position:relative;object-fit:cover;border-radius:50%;width:18px;height:18px}.icon-add{position:relative;object-fit:cover;border-radius:50%;width:24px;height:24px}.icon-add-light{display:block}.icon-add-dark{display:none}.icon-hide{display:none}.sports-medal-count{width:268px;height:64px;display:flex;background:var(--sports-item-background);border-radius:6px;color:${d.l}}.sports-medal-count:hover,.sports-medal-count:focus-visible{background:var(--sports-item-hover-background)}._1x_1y .sports-country-follow{margin-bottom:2px}._1x_3y .sports-country-follow{margin-bottom:12px}._1x_1y .sports-medal-count{height:38px}._1x_3y .sports-medal-count{height:74px}.sports-medal-item-panel{display:flex;justify-content:center;align-items:center}.sports-medal-item{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;width:65px}._1x_1y .sports-medal-item{flex-direction:row}.sports-medal-item p,.sports-medal-total-medals{margin:0;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600}.sports-medal-icon{width:16px;height:16px}.sports-medal-divider{width:1px;height:45px;background:var(--color-neutral-stroke-1);border-radius:4px}._1x_1y .sports-medal-divider{height:25px}.sports-medal-total{flex-grow:1;display:flex;justify-content:center;flex-direction:column;align-items:center}._1x_1y .sports-medal-total{flex-direction:row}.sports-medal-total-text{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin:2px 0px 1px 0px}.sports-medal-total-medals{margin:0}._1x_1y .sports-medal-total p{margin-right:4px;padding-top:2px}._1x_1y .sports-medal-icon{margin-inline-end:6px}.sports-medal-count-number{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:700}._1x_3y .sports-event-country-follow{margin-bottom:12px}`.withBehaviors(new c.t(u,m),new h.N(null,x));var b=i(96950),v=i(69259),y=i(39957),$=i(32150);const w=b.qy`
    <div class="sports-country-follow">
        <div class="sports-country-content">
            ${(0,v.z)(e=>e.viewModel.leagueLogoUrl,b.qy`
                <img src="${e=>e.viewModel.leagueLogoUrl}" class="sports-country-icon" onerror="this.style.visibility='hidden'" alt="" />
            `)}
            ${e=>e.viewModel.teamMedalCount?.team?.name}
        </div>
        <button
            class="sports-follow-icon"
            type="button"
            tabindex="0"
            aria-label="${e=>e.getFollowItemButtonTitle()}"
            title="${e=>e.getFollowItemButtonTitle()}"
            data-t="${e=>e.isFollowed?e.viewModel.unFollowTelemetryTag:e.viewModel.followTelemetryTag}"
            @click="${e=>e.onFollowClick()}"
        >
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/OlympicFollow.svg"
                class="${e=>e.isFollowed?"icon-selected":"icon-hide"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/CircleAddLarge.svg"
                class="${e=>e.isFollowed?"icon-hide":"icon-add icon-add-light"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/CircleAddLargeDark.svg"
                class="${e=>e.isFollowed?"icon-hide":"icon-add icon-add-dark"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
        </button>
    </div>
`,k=b.qy`
    <div class="sports-medal-item-panel">    
        <div class="sports-medal-item">
            <img src="${(0,$.rA)().StaticsUrl}latest/sports/icons/Olympic${e=>e.medal}.svg" class="sports-medal-icon" onerror="this.style.visibility='hidden'" alt="" />
            <div class="sports-medal-count-number">
                ${e=>e.count||0}
            </div>
            <p>
                ${(0,v.z)((e,t)=>"_1x_1y"!==t.parent.viewModel.cardSize,e=>e.name)}
            </p>
        </div>
        <div class="sports-medal-divider"></div>
    </div>
`,_=b.qy`
      <div class="sports-medal-count">
        ${(0,y.ux)(e=>e.getMedalCountList(),k)}
        <div class="sports-medal-total">
            <p class="sports-medal-total-text">
                ${e=>e.viewModel.strings?.total}
            </p>
            <div class="sports-medal-count-number">
                ${e=>e.viewModel.teamMedalCount?.medalsWon?.Total||0}
            </div>
            ${(0,v.z)(e=>"_1x_1y"!==e.viewModel.cardSize,b.qy`
                <p class="sports-medal-total-medals">
                    ${e=>e.viewModel.strings?.medals}
                </p>    
            `)}
        </div>
    </div>
`,z=b.qy`
    <div class="sports-event-country-follow">
        ${w}
        ${_}
    </div>
`,C=b.qy`
    ${e=>e.viewModel.listView?.viewTemplate}
`,F=b.qy`
    <a class="sports-event-country-card ${e=>e.viewModel.cardSize}" href="${e=>e.viewModel.destinationUrl}" target="_blank" data-t="${e=>e.viewModel.telemetryTag}">
        ${z}
        ${(0,v.z)(e=>"_1x_1y"!==e.viewModel.cardSize,C)}
    </a>
`,S=b.qy`
    ${(0,v.z)(e=>e&&null!=e.viewModel,F)}
`;let T=class extends a{};T=(0,o.Cg)([(0,l.E)({name:"sports-event-country",template:S,styles:f})],T)},15146(e,t,i){i.r(t),i.d(t,{SportsInfoList(){return _}});var o=i(56911),r=i(92011),n=i(74849),s=i(22131),a=i(61138),l=i(41123),d=i(62047),c=i(70289),p=i(63033);const h=n.A` .info-list{color:rgba(255,255,255,1)}.divider>div:not(:first-child){border-top:1px solid rgba(255,255,255,0.1)}.list-content{background:rgba(26,26,26,0.5)}`,g=n.A` .list-container{text-decoration:none;${c.f}}.info-list{width:268px;height:fit-content;display:flex;flex-direction:column;color:rgba(36,36,36,1)}.list-header{display:flex;flex-direction:row;justify-content:space-between;margin-bottom:6px;align-items:baseline}.list-title{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}.list-sub-title{font-weight:600;font-size:${a.k}}.list-content{display:flex;flex-direction:column;width:100%;border-radius:8px;background:rgba(255,255,255,0.5);padding:0 12px;box-sizing:border-box;overflow:hidden}.hero-bg{background:var(--sports-item-background)}.hero-bg:hover,.hero-bg:focus-visible{background:var(--sports-item-hover-background)}.list-content._1x_1y{max-height:42px}.list-content._1x_2y{max-height:200px}.list-content._1x_3y{max-height:358px}._1x_1y.list-header{margin-bottom:4px}._1x_1y .list-title{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}._1x_1y .list-sub-title{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.divider>div:not(:first-child){border-top:1px solid rgba(0,0,0,0.05)}.content-item{display:flex;flex-direction:row;align-items:center;gap:8px;height:50px;box-sizing:border-box}.content-item .hero-bg{border-radius:8px}.content-item.small{height:50px;padding:9px 0px;&>img{width:32px;height:32px};&>.content-middle{height:32px}}._1x_1y>.content-item.small{height:42px;&>.content-middle{height:32px}}.content-item.medium{height:66px;padding:6px 0px;&>img{width:40px;height:40px}}.content-item.large{height:96px;padding:12px 0px;&>img{width:54px;height:54px}}.content-middle{display:flex;flex-direction:column;justify-content:space-between;height:38px;width:100%;flex-grow:2;min-width:0}.content-title{font-weight:600;font-size:${l.K};line-height:${l.Z};text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.small>.content-middle>.content-title{font-size:${a.k};line-height:${a.F}}.content-sub-title{font-weight:400;font-size:${a.k};line-height:${a.F};white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.small>.content-middle>.content-sub-title{font-size:${d.t};line-height:${d.e}}.content-des{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);white-space:nowrap}.small>.content-des{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}`.withBehaviors(new p.N(null,h),(0,s.mr)(n.A` :host{forced-color-adjust:auto}`));var x=i(96950),u=i(69259),m=i(50180),f=i(39957);const b=x.qy`
    <div class="content-item ${(e,t)=>t.parent.viewModel.itemSize} ${(e,t)=>t.parent.viewModel.hasItemBg?"hero-bg":""}" style="${e=>e.itemStyle?e.itemStyle:""}">
        ${(0,u.z)(e=>e.icon&&!(0,m.oT)(e.icon),x.qy`
            <img
                class="content-icon"
                style="${e=>e.iconStyle?e.iconStyle:""}"
                role="presentation"
                onerror="this.style.visibility='hidden'"
                src="${e=>e.icon}"/>`)}
        <div class="content-middle" style="${e=>e.contentMiddleStyle||""}">
            <div class="content-title" title="${e=>e.title}">${e=>e.title}</div>
            <div class="content-sub-title" title="${e=>e.subTitle}">${e=>e.subTitle}</div>
        </div>
        ${(0,u.z)(e=>e.des&&!(0,m.oT)(e.des),x.qy`
            <div class="content-des" style="${e=>e.desStyle?e.desStyle:""}">${e=>e.des}</div>
        `)}
    </div>
`,v=x.qy`
    <div class="list-header ${e=>e.viewModel.cardSize}">
        <div class="list-title" title="${e=>e.viewModel.title}">${e=>e.viewModel.title}</div>
        ${(0,u.z)(e=>e.viewModel.subTitle,x.qy`<div class="list-sub-title" title="${e=>e.viewModel.subTitle}">${e=>e.viewModel.subTitle}</div>`)}
    </div>
`,y=x.qy`
    <a 
        class="${e=>e.viewModel.clickThroughUrl?"list-container":""}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div class="info-list">
            ${(0,u.z)(e=>e.viewModel.title||e.viewModel.subTitle,v)}
            <div class="
                list-content
                ${e=>e.viewModel.cardSize}
                ${e=>e.viewModel.showDivider?"divider":""}
                ${e=>e.viewModel.hasItemBg?"":"hero-bg"}
            "
                style="${e=>e.viewModel.listStyle?e.viewModel.listStyle:""}"
            >
                ${(0,f.ux)(e=>e.viewModel.items,b)}
            </div>
        </div>
    </a>
`,$=x.qy`
    ${(0,u.z)(e=>null!=e.viewModel,y)}
`;var w=i(20517);class k extends w.z{}let _=class extends k{};_=(0,o.Cg)([(0,r.E)({name:"sports-info-list",template:$,styles:g,shadowOptions:{delegatesFocus:!0}})],_)},99657(e,t,i){i.d(t,{D(){return s},I(){return n}});var o=i(68136);const{create:r}=o.G,n=r("sloppy-click-z-index",1),s=r("click-z-index",1)},38817(e,t,i){i.d(t,{R7(){return u},e(){return g},kc(){return x},nH(){return h}});var o=i(57416),r=i(55153),n=i(95239),s=i(26920),a=i(48751),l=i(64187),d=i(22131),c=i(74849),p=i(50882);const h=c.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,g=c.A` ${(0,l.V)("flex")} :host{background:${n.p};outline:calc(${s.XA} * 1px) solid ${r.cu};border-radius:calc((${o.JU} - ${s.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${a.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${s.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${r.QG} * 1px);height:calc(${r.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${r.QG} * 1px);height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc(${r.l8} * 1px)}::slotted(*){color:inherit}`,x=(0,d.mr)(c.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),u=c.A` ${g} ${h} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(x)},70289(e,t,i){i.d(t,{f(){return l}});var o=i(64187),r=i(74849),n=i(38817),s=i(99657),a=i(36452);const l=r.A.partial`position: relative; z-index: ${s.D};`;r.A` ${n.e} ${n.nH} ${(0,o.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${a.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${a.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${a.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(n.kc)}}]);