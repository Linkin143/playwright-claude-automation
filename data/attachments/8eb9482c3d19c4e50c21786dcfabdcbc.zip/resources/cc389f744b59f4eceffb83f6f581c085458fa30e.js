"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-results"],{82724(e,t,i){i.r(t),i.d(t,{SportsMatchTransformer(){return l}});var a=i(11796),r=i(79811),n=i(31157),o=i(32150),s=i(83991);class l extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.preGame?e.preGameNotificationMessage:null,this.getPostGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.postGame?e.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=e=>this.isNotificationEnabledAndAvailable(e)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=e=>null!=this.getPreGameNotificationMessage(e)||null!=this.getPostGameNotificationMessage(e),this.getTeamColor=(e,t="")=>e?.primaryColor?(0,r.gS)(e.primaryColor):e?.primaryColorHex?(0,r.gS)(e.primaryColorHex):t,this.getTeamImageUrl=e=>{if(e?.imageUrl)return(0,r.Hv)(e?.imageUrl);const t=(0,r.iK)(e?.imageId,!e?.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return(0,r.Hv)(t)},this.getBackgroundGradient=e=>{if(!e)return"";const t=this.getTeamColor(e.participantOne),i=this.getTeamColor(e.participantTwo);if(!t||!i||t===i&&"#ffffff"===t.toLowerCase())return"";const a=this.hexToRgba(t,1),r=this.hexToRgba(t,.35),n=this.hexToRgba(i,1),o=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${r} 11%,\n                        ${r} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${o} 85.25%,\n                        ${o} 89%,\n                        ${n} 89.25%,\n                        ${n} 100%)`},this.isRTLDirection=()=>document.dir===n.O.rtl,this.getGameDate=e=>{const{gameStartDateTime:t,gameStateCatetory:i}=e||{};if(this.isCopilotTheme){const e=(0,r.yn)(t),n=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return e.toLocaleDateString(o.T3.CurrentMarket,n)}{const e=(0,r.yn)(t);return(0,r.AL)(e,o.T3.CurrentMarket)}}}async transform(e){return{viewModel:await this.getViewModel(e)}}updateAdditionalInfo(e){const{sportsMatchData:t}=e;if(t&&t.additionalInfo){if(!t.additionalInfo.round&&t.additionalInfo.roundLocKey){let e=this.transformerProvider.strings[t.additionalInfo.roundLocKey];t.additionalInfo.roundParams?.forEach((t,i)=>{e=e?.replace(`{${i}}`,t)}),t.additionalInfo.round=e}if(!t.additionalInfo.roundSummary&&t.additionalInfo.roundLocKey){let e=this.transformerProvider.strings[t.additionalInfo.roundSummaryLocKey];t.additionalInfo.roundSummaryParams?.forEach((t,i)=>{e=e?.replace(`{${i}}`,t)}),t.additionalInfo.roundSummary=e}}}getGroupInfo(e){const t=e.matchData.sportsMatchData;if(t.groupInfo)return this.transformerProvider.strings.groupText?.replace("${0}",t.groupInfo)}hexToRgba(e,t=1){const i=e.match(/\w\w/g);if(!i)return"";const[a,r,n]=i.map(e=>parseInt(e,16));return`rgba(${a},${r},${n},${t})`}hasLongScore(e){const t=e.participantOne?.score||"",i=e.participantTwo?.score||"";return t.length+i.length>6}getHeaderText(e){if(!e||0===Object.keys(e).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:t,gameDate:i,gamePeriodAndClock:r,gameStateCatetory:n}=e,o=e.participantOne?.score,s=e.participantTwo?.score,l=e.participantOne?.standings,d=e.participantTwo?.standings,c=new Date(t).getFullYear(),p=e.gameStartTime?e.gameStartTime.toLocaleLowerCase():"";let g,h,x,m,v;switch(n){case a.Xp.preGame:g=p,h=this.isCopilotTheme?i:`${i}, ${c}`,x=l,m=d;break;case a.Xp.inprogressGame:g=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),h=r,x=o,m=s;break;case a.Xp.postGame:g=this.transformerProvider.strings.sportsStateFinal,h=`${i}, ${c}`,x=o,m=s;break;default:g=p,h=i,x=l,m=d}switch(!0){case!!g&&!!h:v=`${g} • ${h}`;break;case!!g:v=g;break;case!!h:v=h;break;default:v=""}return{header:v,topScoreText:x,bottomScoreText:m,leftHeaderText:g,rightHeaderText:h}}async getViewModel(e){const{matchData:t,isVertical:i,telemetryConstants:n,showMatchUXV2:l,noBackgrounds:d,participantOneFollowed:c,participantTwoFollowed:p,reason:g,isContainLiveMatch:h,parentTelemetryObject:x,topDetailText:m,useLargeTeamIcon:v,hasVerticalLine:f,isSpotlight2Card:u,isSpotlightCard:$}=e||{},b=t.sportsMatchData;this.isCopilotTheme=e.isCopilotTheme||!1,this.updateAdditionalInfo(t),"string"!=typeof b.gameState&&(b.gameStateCatetory=(0,r.m5)(b.gameState.state));const w=(0,r.yn)(b.gameStartDateTime);b.gameDate=this.getGameDate(b),b.gameStartTime=(b.gameStartDateTimeIsToBeAnnounced?null:(0,r.ry)(w,o.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof b.gameState&&(b.gamePeriodAndClock=(0,r.PH)(b.gameState)),"string"!=typeof b.gameState&&(b.gamePeriod=b.gameState.gamePeriod),b.participantOne&&(b.participantOne.scheduleUrl=(0,r.Ot)(b.participantOne.gameCenterUrl)),b.participantTwo&&(b.participantTwo.scheduleUrl=(0,r.Ot)(b.participantTwo.gameCenterUrl)),b.gameCenterUrl&&(b.matchClickthroughUrl=(0,r.Ot)(b.gameCenterUrl)),b.participantOne.imageUrl=(0,r.iK)(b.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.participantTwo.imageUrl=(0,r.iK)(b.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.gameState=b.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:b.gameStateCatetory;const y={...n,name:a.BP.Game},k=i||e.isCopilotTheme,z=this.transformerProvider.config.enableLiveScores,T=l&&!d&&!z,S=(0,r.jJ)()?`${o.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${o.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:z||l?"":this.getBackgroundGradient(b),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(x,{...y,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(b),gameNumber:"number",linkTarget:"_blank",matchData:t,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(b),overrideStyleForMatch:"",participantOneColor:T?this.getTeamColor(b.participantOne):"",participantOneFollowed:c,participantOneImgIcon:this.getTeamImageUrl(b.participantOne),participantTwoColor:T?this.getTeamColor(b.participantTwo):"",participantTwoFollowed:p,participantTwoImgIcon:this.getTeamImageUrl(b.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(b),preGameNotificationMessage:this.getPreGameNotificationMessage(b),reason:g,shouldDisplayT4:!h,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(x,y),cardSize:e.cardSize,topDetailText:this.getGroupInfo(e)||m||"",useLargeTeamIcon:z||v,enableLiveScores:z||l,showMatchUXV2:z||l,noBackgrounds:d,isVertical:i,headerText:k?this.getHeaderText(b):void 0,needsVerticalLine:f,liveIconUrl:S,isSpotlight2Card:u,isSpotlightCard:$,isCopilotTheme:this.isCopilotTheme,isWindows:o.T3.AppType===s.u.WindowsNewsWidgets}}}},36516(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},38304(e,t,i){i.r(t),i.d(t,{SportsEventResultsTransformer(){return c},SportsMatchTransformer(){return p.SportsMatchTransformer}});var a=i(41432),r=i(11796),n=i(87906),o=i(33335),s=i(79811),l=i(32150),d=i(96950);class c extends r.Bc{async transform(e){const t=await this.getViewModel(e);return{viewTemplate:d.qy`
                <sports-event-results
                    :viewModel="${t}"
                ></sports-event-results>`}}async getViewModel(e){const{telemetryBuilder:t}=this.transformerProvider,i=e.cardSize,a=this.getFirstMatch(e),{sport:d,eventName:c,clickThroughUrl:p}=e.tabData.tabContent,g=await this.getMatchView(e),h=(0,s.jJ)()?a?.sport?.darkImageId:a?.sport?.imageId,x=(0,l.rA)().CurrentMarket,m=this.getHeaderImageFallback();return a||(0,n.vV)(o.Ax,"Sports Event Results error: empty match list",`market=${x}`,e),{tabType:e.tabData.tabType,headerImage:this.buildHeaderIconUrl(h),headerImageFallback:m,teamImageFallback:this.getTeamImageFallback(),sport:d||"",eventName:c,phase:a?.phaseName||"",tabClickUrl:(0,s.Ot)(p),cardSize:i,matchView:g,tableData:this.getTableData(e),winnerSvg:this.getWinnerSvgUrl(),participantOneData:this.getParticipantData(a?.participantOne||{}),participantTwoData:this.getParticipantData(a?.participantTwo||{}),isHeroCard:e.isHeroCard,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsEventResults})}}getFirstMatch(e){return e.matchData[0]?.sportsMatchData}buildTeamIconUrl(e){return e?this.buildIconUrl(e):this.getTeamImageFallback()}buildHeaderIconUrl(e){return e?(0,s._K)(this.buildIconUrl(e),100,100):this.getHeaderImageFallback()}buildIconUrl(e){return(0,s.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced)}getWinnerSvgUrl(){const e=(0,s.jJ)()?"Light":"Dark";return`${(0,l.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2${e}.svg`}getTeamImageFallback(){return`${(0,l.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}getHeaderImageFallback(){return`${(0,l.rA)().StaticsUrl}latest/sports/icons/Olympics2024.svg`}getParticipantData(e){return{imageUrl:this.buildTeamIconUrl(e.imageId),name:e.name,isWinner:(0,s.Hn)(e.isWinner),score:e.score||""}}async getMatchView(e){const t=this.getFirstMatch(e);if(!t||e.tabData.tabType!==r.v1.LeagueEventResultTeamVsTeam)return;const i=e.followedSports||new Map,a=i.get(t.participantOne?.satoriId||"")||i.get(t.participantOne?.yId||"")||!1,n=i.get(t.participantTwo?.satoriId||"")||i.get(t.participantTwo?.yId||"")||!1,o={matchData:{sportsMatchData:t},parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:a,participantTwoFollowed:n,reason:"",showMatchUXV2:!0,noBackgrounds:!0,useLargeTeamIcon:!0,enableLiveScores:this.transformerProvider.config.enableLiveScores};return await this.transformerProvider.generateView(o,r.hi.SportsMatch)}getRowHeight(e){return e.cardSize===a.uE._1x_2y?"28px":e.cardSize===a.uE._1x_3y?"29px":"22px"}getTableData(e){if(e.tabData.tabType!==r.v1.LeagueEventResultOneVsMany)return null;const t=this.getTableKey(e),i=this.getTableBody(e),a={keys:t,body:i},n=this.getRowHeight(e),o=`repeat(${i.length}, ${n})`;return{telemetryTag:"",cardSize:e.cardSize,isDarkModeTheme:(0,s.jJ)(),tableStyles:this.getTableStyles(e),gridStyles:"width: auto;",data:a,columnStyle:(this.hasRanking(e)?"minmax(auto, 20px)":"")+" minmax(0, 1fr) minmax(auto, 50px)",rowStyle:o}}getTableKey(e){return this.hasRanking(e)?["rank","player","score"]:["player","score"]}hasRanking(e){const t=this.getFirstMatch(e),i=t?.participants||[];return!!i.length&&i.some(e=>e.overallRank)}getTableBody(e){const t=this.getFirstMatch(e),i=t?.participants||[];if(!i.length)return(0,n.vV)(o.Ax,"Sports Event Results error: empty participant list",`market=${(0,l.rA)().CurrentMarket}`,e),[];const r=this.getRowCount(e),s=e.cardSize===a.uE._1x_1y,d="font-size: 12px; line-height: 16px; font-weight: 600;",c=s?"icon-20":"icon-24";return i.slice(0,r).map(e=>({rank:{value:e.overallRank,cellClass:"no-border",textStyles:d},player:{icon:this.buildTeamIconUrl(e.imageId),iconClass:c,cellClass:"no-border",value:e.name,textStyles:d+`margin-inline-start: ${s?"6px":"8px"};`},score:{class:"right",cellClass:"no-border",value:e.score||"",textStyles:d}}))}getRowCount(e){return e.cardSize===a.uE._1x_2y?6:e.cardSize===a.uE._1x_3y?11:2}getTableStyles(e){return`\n            margin-top: 0px;\n            padding: ${e.isHeroCard?"0px 8px":"2px 8px"};\n            background-color: rgba(0, 0, 0, 0);\n        `}}var p=i(82724);Promise.resolve().then(i.bind(i,71214)),Promise.resolve().then(i.bind(i,69620)),Promise.resolve().then(i.bind(i,80195))},20517(e,t,i){i.d(t,{z(){return o}});var a=i(56911),r=i(60815),n=i(92011);class o extends n.L{}(0,a.Cg)([r.sH],o.prototype,"viewModel",void 0)},71372(e,t,i){i.d(t,{a(){return o}});var a=i(56911),r=i(92011),n=i(95144);let o=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([n.x],o)},71214(e,t,i){i.r(t),i.d(t,{SportsEventResults(){return M}});var a=i(56911),r=i(71372),n=i(60815);class o extends r.a{constructor(){super(...arguments),this.isSportsImageUnavailable=!1}isFullCardBg(){return"_1x_1y"!==this.viewModel.cardSize&&(!!this.viewModel.isHeroCard||"OneVsManyEventResult"!==this.viewModel.tabType)}onHeaderImageError(){this.isSportsImageUnavailable=!0}}(0,a.Cg)([n.sH],o.prototype,"isSportsImageUnavailable",void 0);var s=i(92011),l=i(48751),d=i(86856),c=i(70289),p=i(63033),g=i(74849);const h=g.A` :host{--divider-color:rgba(255,255,255,0.1);--wrap-bg-color:rgba(26,26,26,0.5);--phase-color:rgb(214,214,214);--divider-hero-color:rgb(102,102,102)}`,x=g.A` .match .win-wrap img{transform:rotate(180deg)}`,m=g.A` :host{--divider-color:rgba(0,0,0,0.05);--wrap-bg-color:rgba(255,255,255,0.5);--phase-color:rgb(112,112,112);--divider-hero-color:rgba(0,0,0,0.08)}.wrap{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:${l.l};${c.f}}.bg{background:var(--sports-item-background);border-radius:8px}.table{border-radius:8px;margin-top:4px}.table-title{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;width:100%}.sport-icon{width:60px;height:60px;margin-top:16px}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bold{font-weight:600}.sport{font-weight:700;font-size:var(--type-ramp-plus-3-font-size,24px);line-height:var(--type-ramp-plus-3-line-height,32px);margin-top:4px;max-width:calc(100% - 16px)}.event{font-weight:600;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-2-font-size,20px);margin-top:2px;padding-bottom:2px;max-width:calc(100% - 16px)}.divider{margin:8px 0px 8px;width:calc(100% - 16px);height:1px;background-color:var(--divider-color)}.divider-header{width:calc(100% - 16px);height:1px;background-color:var(--divider-hero-color)}.match{width:100%}.match .team-icon{height:20px;width:20px;min-width:20px;margin-inline-end:6px}.match-line{display:flex;justify-content:flex-start;align-items:center;height:20px}.team-name{margin-inline-end:auto}.team-name,.score{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);margin-inline-start:4px}.simple-match-wrap{width:100%;padding:2px 8px;margin-top:4px;box-sizing:border-box}.match .win-wrap img{width:8px;height:8px}.win-wrap{width:14px;min-width:14px;display:flex;align-items:center;justify-content:flex-end}.sm-header{display:grid;grid-template-columns:min-content 1fr min-content;width:100%;column-gap:4px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden}.table .sm-header{width:252px;max-width:252px;margin:6px 8px 4px;display:flex;justify-content:space-between}.sm-sport{font-weight:600}.phase{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);color:var(--phase-color)}.one-v-one{padding:0px 12px 12px;width:100%;box-sizing:border-box}.one-v-one .header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;width:100%}.no-phase .match{height:46px;display:flex;flex-direction:column;justify-content:space-between;margin-top:8px}sports-match{pointer-events:none}._1x_2y.wrap{height:224px}._1x_3y.wrap.v-align-mid{height:334px;margin-top:20px}._1x_3y .one-v-one{padding-top:12px}._1x_1y .one-v-one .header{margin-bottom:4px}._1x_3y .sport-icon{width:108px;height:108px;margin-top:32px}._1x_3y .sport{margin-top:20px}._1x_3y .event{margin-top:6px}._1x_3y .divider{margin:28px 0px 12px}.hero._1x_2y.wrap{height:220px}.hero .table-title{padding:6px 8px;box-sizing:border-box}.hero .table{margin-top:0px}.hero .table .sm-header{margin-top:4px}.hero .divider{margin-bottom:4px;background-color:var(--divider-hero-color)}`.withBehaviors(new d.t(null,x),new p.N(null,h));var v=i(96950),f=i(69259);const u=v.qy`
    <img src="${e=>e.viewModel.winnerSvg}">
`,$=({score:e,isWinner:t})=>v.qy`
    <div class="score" title=${t=>e}>${t=>e}</div>
    <div class="win-wrap">
        ${e=>t?u:null}
    </div>
`,b=v.qy`
    <div class="match">
        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantOneData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantOneData.name}>${e=>e.viewModel.participantOneData.name}</div>
            ${e=>$(e.viewModel.participantOneData)}
        </div>

        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantTwoData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantTwoData.name}>${e=>e.viewModel.participantTwoData.name}</div>
            ${e=>$(e.viewModel.participantTwoData)}
        </div>
    </div>
`,w=v.qy`
    <img
        src="${e=>e.isSportsImageUnavailable?e.viewModel.headerImageFallback:e.viewModel.headerImage}"
        class="sport-icon"
        @error="${e=>e.onHeaderImageError()}"
    >
    <div class="sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
    <div class="event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
`,y=v.qy`
    <div class="table bg">
        ${(0,f.z)(e=>"_1x_1y"!==e.viewModel.cardSize,v.qy`
            <div class="sm-header bold">
                <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
                <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        <sports-table
            :viewModel="${e=>e.viewModel.tableData}"
        ></sports-table>
    </div>
`,k=v.qy`
    ${w}

    <div class="divider"></div>

    <div class="one-v-one ${e=>e.viewModel.phase?"":"no-phase"}">
        ${(0,f.z)(e=>e.viewModel.phase,v.qy`
            <div class="header">
                <div class="phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        ${b}
    </div>
`,z=v.qy`
    <div class="table-title truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
`,T=v.qy`
    ${e=>"_1x_1y"===e.viewModel.cardSize?F:z}
    ${(0,f.z)(e=>e.viewModel.isHeroCard,v.qy`<div class="divider-header"></div>`)}
    ${y}
`,S=v.qy`
    ${w}

    <div class="divider"></div>

    ${(0,f.z)(e=>e.viewModel.matchView,v.qy`
        <sports-match
            :viewModel="${e=>e.viewModel.matchView?.viewModel}"
        ></sports-match>
    `)}
`,F=v.qy`
    <div class="sm-header">
        <div class="sm-sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
        <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
        <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
    </div>
`,_=v.qy`
    ${F}

    <div class="simple-match-wrap bg">
        ${b}
    </div>
`,C=v.qy`
    <a
        class="wrap ${e=>e.viewModel.cardSize} ${e=>e.isFullCardBg()?"bg v-align-mid":""} ${e=>e.viewModel.isHeroCard?"hero":""}"
        data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.tabClickUrl}"
        target="blank"
    >
        ${e=>((e,t)=>{const i="_1x_1y"===t;switch(e){case"OneVsOneEventResult":return i?_:k;case"OneVsManyEventResult":return T;case"TeamVsTeamEventResult":return i?_:S;default:return null}})(e.viewModel.tabType,e.viewModel.cardSize)}
    </a>
`,I=v.qy`
    ${(0,f.z)(e=>e&&null!=e.viewModel,C)}
`;let M=class extends o{};M=(0,a.Cg)([(0,s.E)({name:"sports-event-results",template:I,styles:m,shadowOptions:{delegatesFocus:!0}})],M)},80195(e,t,i){i.r(t),i.d(t,{SportsMatch(){return oe}});var a=i(56911),r=i(52921),n=i(20517);class o extends n.z{constructor(){super(...arguments),this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(e,t,i,a){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();const n="keydown"===e.type||"keypress"===e.type||"keyup"===e.type;(0,r.LE)(e.currentTarget,n,t),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,t,a)}}}var s=i(92011),l=i(48751),d=i(62047),c=i(61138),p=i(41123),g=i(71157),h=i(62198),x=i(4283),m=i(70289),v=i(63033),f=i(50882),u=i(74849),$=i(4126),b=i(22131);const w="#CD3800",y="#E98F6D",k=u.A` .date,.nodate{width:auto}`,z=u.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${y}}.game-in-progress-text{color:${y}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${y};background-color:${y}}.standings-style{color:${l.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,T=u.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${m.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${l.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${l.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${l.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${l.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${l.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${l.l}}.foreground-rest-text-color{color:${l.l}}.top-game-detail{color:${l.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${l.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${l.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${c.k};line-height:${c.F};color:${l.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${p.K};line-height:${p.Z};font-weight:600;color:${l.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${l.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${w};font-size:${c.k};line-height:${c.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${w};font-size:${d.t}}.participant-name-style{font-size:${c.k};line-height:${c.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${g.T};line-height:${g.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${c.k};line-height:${c.F};max-width:100px}.game-score-notification-text-style{font-size:${g.T};line-height:${g.O}}.game-score-text-style{color:${l.l};line-height:${g.O};font-size:${h.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${w};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${l.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${d.t};line-height:${d.e};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${l.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${p.K};line-height:${p.Z};font-weight:900;color:${l.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${c.k};line-height:${c.F};font-weight:600;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${x.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${w};width:16px;height:0;left:126px;top:20px;position:absolute;background-color:${w}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${l.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${l.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${l.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${m.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new v.N(null,z),(0,b.mr)(u.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${f.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${f.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${f.A.LinkText}}.click-for-detail{border:1px solid;background-color:${f.A.LinkText}}.detail-live-animation{background-color:${f.A.LinkText}}.scores-line{overflow:hidden}}`),new $.o("isWindowsCopilot",!0,k));var S=i(11796),F=i(50180),_=i(96950),C=i(69259),I=i(36516),M=i(10500),j='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const D=(e,t)=>_.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,F.GP)(t?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",e.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:S.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:S.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||""):null}"
        data-t="${e=>e.viewModel?.followTelemetryTag}"
    >
        <div class="${e=>t?"icon-add":"icon-selected"}"> ${_.qy.partial(t?I.A:M.A)}</div>
    </div>
`,V=_.qy`
    <div class="game-details">
        ${_.qy`<div class="top-game-detail">${e=>e.viewModel.topDetailText}</div>`}
        ${e=>((e,t,i=null,a=null)=>{switch(e.getMatchData().gameStateCatetory){case S.Xp.preGame:return null==i?J():Q(i);case S.Xp.inprogressGame:return ae();case S.Xp.postGame:return t?ie():(0,F.oT)(e.viewModel.topDetailText)?ee(a||""):te();default:return J()}})(e,e.viewModel.shouldShowChampionPostGame,e.viewModel.preGameNotificationMessage,e.viewModel.postGameNotificationMessage)}
    </div>
`,O=_.qy`
    <div class="${e=>e.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${V}
        ${e=>U(e.getMatchData().additionalInfo)}
    </div>
`,A=()=>_.qy`
    <div class="g-dtl ${e=>e.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${e=>e.getMatchData().gameStateCatetory===S.Xp.inprogressGame?R:""}
            ${e=>e.getMatchData().gameStateCatetory===S.Xp.postGame?B:""}
            <div class="kscr-cntr">
                <span class="kscr ${e=>e.getMatchData().participantOne?.isWinner?"winner-team":""} part-left">
                    ${(0,C.z)(e=>e.getMatchData().participantOne?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(j)}</span>`)}
                    ${e=>e.getMatchData().participantOne?.score??""}
                </span>
                ${e=>(0,F.oT)(e.getMatchData().participantOne?.score||"")||(0,F.oT)(e.getMatchData().participantTwo?.score||"")?"":H}
                <span class="kscr ${e=>e.getMatchData().participantTwo?.isWinner?"winner-team":""}">
                    ${e=>e.getMatchData().participantTwo?.score??""}
                    ${(0,C.z)(e=>e.getMatchData().participantTwo?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(j)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,L=()=>_.qy`
    <div class="date">
        <div class="prehdr">${e=>e.viewModel.headerText?.rightHeaderText}</div>
        <div class="ktime">${e=>e.getMatchData().gameStartTime}</div>
    </div>
`,U=e=>e?_.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${e.round||""}
                </div>
                <div class="round-summary-info">
                    ${e.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${e.scores}
                </div>
            </div>
        `:null,H=_.qy`
    <span class="scores-line">${_.qy.partial(S.Z5)}</span>
`,E=_.qy`
    <span>${_.qy.partial("·")}</span>
`,R=_.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${e=>e.viewModel.liveIconUrl}" />
        <span class="r-live-text">${S.T0.Live}</span>
    </div>
`,B=_.qy`
    <div class="pghdr">
        <span>${S.T0.Final}</span>
        ${e=>e.getMatchData().gameDate?E:""}
        <span>${e=>e.getMatchData().gameDate}</span>
    </div>
`,N=_.qy`
    <div class="vert-noline">
        <div class="vert-header ${e=>e.getMatchData().gameStateCatetory===S.Xp.inprogressGame?"in-prog-vert":""}">
            ${e=>e.viewModel.headerText?.header}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>e.getMatchData().participantOne?.name}">
                        ${e=>e.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===S.Xp.preGame?"standings-style":""}">${e=>e.viewModel.headerText?.topScoreText}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>e.getMatchData().participantTwo?.name}">
                        ${e=>e.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===S.Xp.preGame?"standings-style":""}">${e=>e.viewModel.headerText?.bottomScoreText}</div>
            </div>
        </div>
    </div>
`,W=_.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>e.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>e.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${e=>e.viewModel.headerText?.leftHeaderText}</div>
            <div>${e=>e.viewModel.headerText?.rightHeaderText}</div>
        </div>
    </div>
`,P=_.qy`
    ${e=>e.viewModel.isSpotlightCard?Z:X}
`,G=_.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>e.getMatchData().participantOne?.name||""}"
                />
            </div>
            <div class="kname ${e=>!e.getMatchData().participantOne?.shortName&&e.getMatchData().participantOne?.name?"long-name":""}" title="${e=>e.getMatchData().participantOne?.name||""}">
                ${e=>e.getMatchData().participantOne?.shortName||e.getMatchData().participantOne?.name||""}
            </div>
        </div>
        ${e=>(e=>e.getMatchData().gameStateCatetory===S.Xp.inprogressGame||e.getMatchData().gameStateCatetory===S.Xp.postGame?A():L())(e)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>e.getMatchData().participantTwo?.name||""}"
                />
            </div>
            <div class="kname ${e=>!e.getMatchData().participantTwo?.shortName&&e.getMatchData().participantTwo?.name?"long-name":""}" title="${e=>e.getMatchData().participantTwo?.name||""}">
                ${e=>e.getMatchData().participantTwo?.shortName||e.getMatchData().participantTwo?.name||""}
            </div>
        </div>
    </div>
`,X=_.qy`
    <a class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}"
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${G}
    </a>
`,Z=_.qy`
    <div class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}">
        ${G}
    </div>
`,q=_.qy`
    ${e=>e.viewModel.needsVerticalLine?W:N}
`,K=_.qy`
    <a class="
        sports-match matchup-neutral-background
        ${e=>e.viewModel.noBackgrounds?"no-bg":""}
        ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>e.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${e=>`background-image: ${e.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${e=>e.viewModel.overrideStyleForMatch} ${e=>e.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${e=>e.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${e=>D(e.getMatchData().participantOne||{},!e.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${e=>e.getMatchData().participantOne?.name}">
                    ${e=>e.getMatchData().participantOne?.name||""}
                </div>
            </div>
            ${O}
            <div class="participant-container right-participant ${e=>e.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantTwoColor};`}">
                    ${(0,C.z)(e=>e.viewModel.isSpotlight2Card,_.qy`${e=>D(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,C.z)(e=>!e.viewModel.isSpotlight2Card,_.qy`${e=>D(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${e=>e.getMatchData().participantTwo?.name}">
                    ${e=>e.getMatchData().participantTwo?.name||""}
                </div>
            </div>
        </div>
    </a>
`,J=()=>_.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${e=>e.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gameDate} - ${e.getMatchData().tvChannel}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameDate||""}</span>
            ${e=>e.getMatchData().tvChannel&&e.getMatchData().gameDate?H:""}
        <span>${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,Q=e=>_.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime+"-"+e.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${e=>""+(e.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${e}">
        <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${e}
        </span>
    </div>
`,Y=()=>_.qy`
    <div class="middle-game-detail ${e=>e.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,C.z)(e=>e.getMatchData().participantOne?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(j)}</span>`)}
            ${e=>e.getMatchData().participantOne?.score??""}
        </span>
        ${e=>(0,F.oT)(e.getMatchData().participantOne?.score||"")||(0,F.oT)(e.getMatchData().participantTwo?.score||"")?"":H}
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantTwo?.score??""}
            ${(0,C.z)(e=>e.getMatchData().participantTwo?.isWinner,_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(j)}</span>`)}
        </span>
    </div>
`,ee=e=>_.qy`
    <div class="top-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?E:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
    ${Y()}
    ${(0,C.z)(!(0,F.oT)(e),_.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${e}">
            <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${e}
            </span>
        </div>
    `)}
`,te=()=>_.qy`
    ${Y()}
    <div class="bottom-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?E:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
`,ie=()=>_.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${e=>re(e)}
        </div>
        <div class="game-winner-description" title="${e=>e.viewModel.strings.champions||""}">
            ${e=>e.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantOne?.score??""}
        </span>
        ${e=>(0,F.oT)(e.getMatchData().participantOne?.score||"")||(0,F.oT)(e.getMatchData().participantTwo?.score||"")?"":H}
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantTwo?.score??""}
        </span>
    </div>
`,ae=()=>_.qy`
    <div class="middle-game-detail">
        ${e=>e.viewModel.enableLiveScores?_.qy`
    <span class="game-score-text-style">
        ${e=>e.getMatchData().participantOne?.score??""}
    </span>
    ${e=>(0,F.oT)(e.getMatchData().participantOne?.score||"")||(0,F.oT)(e.getMatchData().participantTwo?.score||"")?"":H}
    <span class="game-score-text-style">
        ${e=>e.getMatchData().participantTwo?.score??""}
    </span>
`:_.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${e=>(e.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.enableLiveScores?"live-scores-detail":""}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gamePeriodAndClock} - ${e.getMatchData().tvChannel}`:e.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${e=>e.getMatchData().gamePeriodAndClock}">
            ${e=>e.getMatchData().gamePeriodAndClock||""}
        </span>
        ${e=>e.getMatchData().gamePeriodAndClock&&e.getMatchData().tvChannel?H:""}
        <span title="${e=>e.getMatchData().tvChannel}">${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,re=e=>{const t=e.getMatchData();if(t&&t.gameStateCatetory==S.Xp.postGame){let e=t.participantOne?.isWinner?t.participantOne?.name?.toUpperCase():null;return e||(e=t.participantTwo?.isWinner?t.participantTwo?.name?.toUpperCase():null),e||""}return""},ne=_.qy`
    ${e=>e.isVertical()?_.qy` ${q} `:e.isCopilotTheme()?_.qy` ${P} `:e.viewModel?_.qy` ${K} `:void 0}
`;let oe=class extends o{};oe=(0,a.Cg)([(0,s.E)({name:"sports-match",template:ne,styles:T,shadowOptions:{delegatesFocus:!0}})],oe)},69620(e,t,i){i.r(t),i.d(t,{SportsTable(){return F}});var a=i(56911),r=i(92011),n=i(48751),o=i(62047),s=i(41123),l=i(61138),d=i(86856),c=i(74849),p=i(22131),g=i(70289),h=i(63033);const x=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,m=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,v=c.A` .table-container{text-decoration:none}.clickable{${g.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${n.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${n.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${o.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${o.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${o.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${s.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${o.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${s.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${l.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,m),new h.N(null,x),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var f=i(96950),u=i(39957),$=i(69259);const b=f.qy`
    ${e=>void 0!==e.viewModel.data.title?f.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?f.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?f.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,w=f.qy`
    ${(0,u.ux)(e=>e.getHeaderValues(),f.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?f.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,y=f.qy`
    ${(0,u.ux)(e=>e.getAllBodyCells(),()=>f.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?f.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?f.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?f.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>f.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?f.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>f.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,k=f.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?b:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":b}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?w:""}
                ${y}
            </div>
        </div>
    </a>
`,z=f.qy`
    ${(0,$.z)(e=>null!=e.viewModel,k)}
`;var T=i(71372);class S extends T.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(i=>{t.forEach(t=>e.push(i[t]))}),e}}}let F=class extends S{};F=(0,a.Cg)([(0,r.E)({name:"sports-table",template:z,styles:v,shadowOptions:{delegatesFocus:!0}})],F)},99657(e,t,i){i.d(t,{D(){return o},I(){return n}});var a=i(68136);const{create:r}=a.G,n=r("sloppy-click-z-index",1),o=r("click-z-index",1)},38817(e,t,i){i.d(t,{R7(){return m},e(){return h},kc(){return x},nH(){return g}});var a=i(57416),r=i(55153),n=i(95239),o=i(26920),s=i(48751),l=i(64187),d=i(22131),c=i(74849),p=i(50882);const g=c.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,h=c.A` ${(0,l.V)("flex")} :host{background:${n.p};outline:calc(${o.XA} * 1px) solid ${r.cu};border-radius:calc((${a.JU} - ${o.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${s.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${o.XA} * 1px) ${r.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${o.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${o.XA} * 1px) ${r.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${r.QG} * 1px);height:calc(${r.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${r.QG} * 1px);height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc((${r.l8} * 2px) + (${r.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${r.QG} * 2px) + (${r.Sn} * 1px));height:calc(${r.l8} * 1px)}::slotted(*){color:inherit}`,x=(0,d.mr)(c.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),m=c.A` ${h} ${g} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(x)},70289(e,t,i){i.d(t,{f(){return l}});var a=i(64187),r=i(74849),n=i(38817),o=i(99657),s=i(36452);const l=r.A.partial`position: relative; z-index: ${o.D};`;r.A` ${n.e} ${n.nH} ${(0,a.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${s.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${s.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${s.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(n.kc)}}]);