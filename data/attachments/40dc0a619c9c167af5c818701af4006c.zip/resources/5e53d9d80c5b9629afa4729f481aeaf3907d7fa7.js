"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-spotlight"],{70512(e,t,i){i.d(t,{O(){return s}});var a=i(67072),r=i(23305);class s extends r.Bc{constructor(){super(...arguments),this.getCardTitle=(e,t)=>t?this.transformerProvider.strings.teamStats:e?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(e){return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){const{cardSize:t,isFullCard:i,sportsGameStats:r,isSpotlight2Card:s,participants:o,isSeasonStats:n,isCopilotTheme:l,isMitUX:p}=e;let c=0;switch(t){case a.uE._1x_2y:c=i?5:3;break;case a.uE._1x_3y:c=7;break;case a.uE._2x_2y:c=4;break;case a.uE._15u:c=3}return{sportsGameStats:r.slice(0,c).map(e=>{const t=e.key;return{...e,leftText:this.getStatText(e.leftText,t),rightText:this.getStatText(e.rightText,t),left:this.getBarPercentage(e.left,e.right,t),right:this.getBarPercentage(e.right,e.left,t),key:this.transformerProvider.strings[t]||t}}),cardSize:t,isSpotlight2Card:s,isFullCard:i,participants:o,cardTitle:this.getCardTitle(n,l),isCopilotTheme:l,isMitUX:p,telemetryTag:""}}isPercentStats(e){return e?.includes("%")}getBarPercentage(e,t,i){const a=this.isPercentStats(i);return 0===e&&0===t?0:100*(a?e:e/(e+t))}getStatText(e,t){return e&&t?this.isPercentStats(t)?`${(100*parseFloat(e)).toFixed(1)}`:e:""}}},34959(e,t,i){i.d(t,{V(){return c}});var a=i(79811),r=i(23305),s=i(67072),o=i(33744),n=i(89757),l=i(87906),p=i(40450);class c extends r.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0},timeOfPossession:{isTime:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"totalYards",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame",timeOfPossession:"timeOfPossession"}}async transform(e){this.isCopilotTheme=e.isCopilotTheme||!1;const t={...e,spotlightData:this.transformSportsSpotlightData(e.spotlightData,e.tabClickThroughUrl,e.isSpotlightFRE)},i=await this.getCurrentViewModel(t);return{viewTemplate:n.qy`
                <sports-spotlight
                    :viewModel="${i}"
                ></sports-spotlight>`}}async getCurrentViewModel(e){if(!e||0===Object.keys(e).length)return void(0,l.vV)(p.K0b,"Spotlight metadata missing",`market=${o.T3.CurrentMarket}`,e);const{cardSize:t,tabClickThroughUrl:i}=e,a=t===s.uE._1x_1y||t===s.uE._05u,n=this.getPlayerEventCard(e);let c;n||a||!this.transformerProvider.config.enablePickWinner||(c=await this.getPolls(e));const d=c||n&&t===s.uE._1x_3y,g=await this.getMatches(e,Boolean(d));let h,y;n||!e.isSpotlightFRE&&a||null!=c||(h=this.getVideoInfo(e),y=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsSpotlightVideo}));const m=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsInfoSpotlight});let u,b;n||a||null!=h||null!=c||(u=await this.getGameStatsInfo(e)),g.length||(b=e.spotlightData.headerData,b.clickThroughUrl=e.tabClickThroughUrl);return{cardSize:t,tabClickThroughUrl:i,matches:g,sportsGameStatsCard:u,sportsPickWinnerCard:c,sportsVideo:h,headerData:b,spotsVideoTelemetry:y,telemetryTag:m,sportsGameLeadersCard:await this.getGameLeadersInfo(e),sportsPlayerEventCard:n,isCopilotTheme:this.isCopilotTheme,isMitUX:e.isMitUX}}async getPolls(e){const{pollOptionId:t,isSpotlight2Card:i,spotlightData:{poll:a,matchlist:s}={},cardSize:o}=e;if(!a?.pollId&&a?.type!==r.t9.PickWinner||!s?.length||!s[0].sportsMatchData)return null;const{participantOne:n,participantTwo:l}=s[0].sportsMatchData||{};if(!s||!n||!l)return null;if(t){a.userVote=t;const e=a.options?.find(e=>e.id===t);e?e.count=(parseInt(e.count)+1).toString():a.options?.push({id:t,count:"1"})}const p={poll:a,match:s[0].sportsMatchData,isSpotlight2Card:i,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,isCopilotTheme:this.isCopilotTheme,cardSize:o};return await this.transformerProvider.generateView(p,r.hi.SportsPickWinner)}getVideoInfo(e){const{video:t}=e.spotlightData||{},i=e.isSpotlightFRE?null:e.primaryEntityName||this.transformerProvider.strings.gameHighlights;return t?{...t,videoTagTitle:i}:null}async getGameStatsInfo(e){const{spotlightData:t,isSpotlight2Card:i}=e||{},{sportsGameStats:a,isSeasonStats:s=!1,matchlist:o,isGameStatsFull:n}=t||{};if(!a)return null;const{cardSize:l}=e,{participantOne:p,participantTwo:c}=o[0].sportsMatchData||{},d={cardSize:l,sportsGameStats:a,isSeasonStats:s,isSpotlight2Card:i,isFullCard:n,participants:[p,c],isCopilotTheme:this.isCopilotTheme,isMitUX:e.isMitUX};return await this.transformerProvider.generateView(d,r.hi.SportsGameStats)}async getGameLeadersInfo(e){const{gameLeaders:t,matchlist:i}=e.spotlightData||{},{sportsMatchData:s}=i.length?i[0]:{sportsMatchData:void 0},o={};if(s?.participantOne?.id&&(o[s.participantOne.id]=(0,a.gS)(s.participantOne.primaryColorHex)),s?.participantTwo?.id&&(o[s.participantTwo.id]=(0,a.gS)(s.participantTwo.primaryColorHex)),!t)return null;const{cardSize:n}=e,l={cardSize:n,sportsGameLeaders:t,teamColors:o,parentTelemetryObject:e.telemetryObject};return await this.transformerProvider.generateView(l,r.hi.SportsGameLeaders)}getPlayerEventCard(e){const{playerEvent:t}=e.spotlightData||{};if(!t)return null;return{playerEvent:t,imageUrl:(0,a.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoBig),teamImageUrl:(0,a.iK)(t.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo),fallbackIconText:(t.shortName||"").split(" ").map(e=>e[0]).join("").toUpperCase().slice(0,2),cardSize:e.cardSize,isCopilotTheme:this.isCopilotTheme,telemetryTag:""}}async getMatches(e,t){const{spotlightData:i,telemetryObject:s,telemetryConstants:o,isHeroCard:n,isSpotlight2Card:l,followedSports:p=new Map}=e,{matchlist:c}=i||{};if(!c)return[];const d=(0,a.Yo)(c),g=c.map(async i=>{const c=i.sportsMatchData,g=(0,a.gK)(c.participantOne,p),h=(0,a.gK)(c.participantTwo,p),y={matchData:i,parentTelemetryObject:s,telemetryConstants:o,participantOneFollowed:g,participantTwoFollowed:h,isContainLiveMatch:d,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:n,isSpotlight2Card:l,isSpotlightCard:Boolean(e.spotlightData.statistics),isCopilotTheme:this.isCopilotTheme,useLargeTeamIcon:t,isMitUX:e.isMitUX};return this.transformerProvider.generateView(y,r.hi.SportsMatch)});return(await Promise.all(g)).filter(a.z2)}transformSportsSpotlightData(e,t,i=!1){const{statistics:s,video:n,match:c,poll:d,headerData:g,gameLeaders:h,playerEvent:y}=e;let m,u=a.Zi,b=a.ZL;const x=[];if(c){const e=(0,a.yn)(c.gameStartDateTime);c.gameDate=(0,a.AL)(e,o.T3.CurrentMarket),c.gameStartTime=(c.gameStartDateTimeIsToBeAnnounced?null:(0,a.ry)(e,o.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,c.gameStateCatetory="string"!=typeof c.gameState?(0,a.m5)(c.gameState.state):c.gameStateCatetory,"string"!=typeof c.gameState&&(c.gamePeriodAndClock=(0,a.PH)(c.gameState)),c.participantOne&&(c.participantOne.scheduleUrl=(0,a.Ot)(c.participantOne.gameCenterUrl)),c.participantTwo&&(c.participantTwo.scheduleUrl=(0,a.Ot)(c.participantTwo.gameCenterUrl)),c.gameCenterUrl&&(c.matchClickthroughUrl=(0,a.Ot)(c.gameCenterUrl)),c.participantOne.imageUrl=(0,a.iK)(c.participantOne.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),c.participantTwo.imageUrl=(0,a.iK)(c.participantTwo.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),"string"==typeof c.gameState||c.gamePeriod||(c.gamePeriod=c.gameState.gamePeriod||c.gamePeriod),c.gameState=c.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:c.gameStateCatetory,this.adjustParticipantColors(c);const t=c.participantOne?.primaryColorHex===c.participantTwo?.primaryColorHex&&"ffffff"===c.participantOne?.primaryColorHex?.toLowerCase();!t&&c.participantOne?.primaryColorHex&&(u=(0,a.gS)(c.participantOne.primaryColorHex)),!t&&c.participantTwo?.primaryColorHex&&(b=(0,a.gS)(c.participantTwo.primaryColorHex)),c.matchClickthroughUrl?m=c.matchClickthroughUrl:c.gameCenterUrl&&(m=(0,a.Ot)(c.gameCenterUrl),c.matchClickthroughUrl=m),x.push({sportsMatchData:c})}const f=this.transformGameState(s,[u,b]),v=!(h&&0!==Object.keys(h).length||f&&0!==f.length||n||d||y);if(i||0!==x.length&&!v&&m){if(n){let e=m??"";i&&(e=(0,a.Ot)(t)),n.msnVideoEmbedLink=(0,a._S)(n,e)}return{gameLeaders:h,matchlist:x,sportsGameStats:f,video:n,poll:d,matchClickthroughUrl:m||"",isSeasonStats:s&&s.season&&2===s.season.length,isGameStatsFull:!!s?.isFullCard,headerData:g,playerEvent:y}}(0,l.vV)(p.K0b,"Spotlight metadata missing",`market=${o.T3.CurrentMarket}`,e)}transformGameState(e,t){if(!e||0===Object.keys(e).length)return;let i=[];e.season&&2===e.season.length?i=e.season:e.game&&2===e.game.length&&(i=e.game);const a=[];if(i[0]&&i[1]){const r=i[0],s=i[1],o=e.statsKeyOrder||Object.keys(r);for(const e of o){const i=Number(r[e]),o=Number(s[e]),n=this.gameStatsFormatMap[e],l=this.formatGameStatsNumber(i,n),p=this.formatGameStatsNumber(o,n),c=this.calculatePercentNumbers(i,o),d={key:this.gameStatsLocKeyMap[e]||e,left:i,right:o,leftText:l,rightText:p,leftColor:t[0],rightColor:t[1],...c};a.push(d)}}return a}formatGameStatsNumber(e,t){if(!t)return e.toString();let i="";return t.isPercent&&(i="%"),void 0!==t.toFix?`${e.toFixed(t.toFix)}${i}`:t.isTime?this.secondsToMinutes(e):`${e}${i}`}secondsToMinutes(e){return`${Math.floor(e/60)}:${Math.floor(e%60).toString().padStart(2,"0")}`}calculatePercentNumbers(e,t){let i=0,a=0,r=0;return 0!==e&&0!==t?(r=.7,i=e/(e+t)*99.3,a=t/(e+t)*99.3):0===e&&0===t?(i=0,a=0,r=0):0===e?(i=2.3,a=97,r=.7):0===t&&(i=97,a=2.3,r=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(a.toFixed(1)),gap:r}}adjustParticipantColors(e){if(!this.isCopilotTheme)return;const t=e.participantOne?.primaryColorHex.toLowerCase(),i=e.participantTwo?.primaryColorHex.toLowerCase(),r=this.isClashingColor(t),s=this.isClashingColor(i);r&&(e.participantOne.primaryColorHex=a.Zi),s&&(e.participantTwo.primaryColorHex=a.ZL)}isClashingColor(e){const t=(0,a.jJ)(),i=e.startsWith("#")?e.slice(1):e,r=parseInt(i.slice(0,2),16),s=parseInt(i.slice(2,4),16),o=parseInt(i.slice(4,6),16),n=r>200&&s>200&&o>200;return t?n||r<50&&s<50&&o<50:n}}},59682(e,t,i){i.d(t,{SportsGameStatsTransformer(){return a.O},SportsMatchTransformer(){return r.SportsMatchTransformer},SportsSpotlightTransformer(){return s.V}});var a=i(70512),r=i(82724),s=i(34959);Promise.resolve().then(i.bind(i,94138)),Promise.resolve().then(i.bind(i,9038)),Promise.resolve().then(i.bind(i,4708))},83546(e,t,i){i.d(t,{h(){return r}});var a=i(53128);function r(){return(0,a.oh)()}},46187(e,t,i){i.d(t,{WB(){return r},zv(){return a}});const a=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",bowling:"Bowling",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia",biathlon:"Biathlon",bobsledding:"Bobsledding",curling:"Curling",luge:"Luge",skating:"Skating",skiing:"Skiing",breaking:"Breaking"});new Set(["Soccer_InternationalIntFriendlyGames","Soccer_BelgiumSuperCup","Baseball_ChineseTaipeiCpbl","Soccer_InternationalClubsUefaEuropaConferenceLeague","Soccer_FranceCoupeDeFrance","Soccer_Turkey1Lig","Soccer_BelgiumSuperCup","Soccer_VietnamVLeague","Soccer_BrazilBrasileiroSerieC","Football_CanadaCfl","Soccer_BoliviaDivisionProfesional","Football_USAUSFL"]);const r=Object.freeze([a.football,a.basketball,a.baseball,a.cricket,a.soccer,a.icehockey])},57744(e,t,i){i.d(t,{UU(){return g},C9(){return w},OY(){return b},eU(){return f},Bk(){return y}});var a=i(54694),r=i(33744),s=i(25066),o=i(46187);const n=Object.freeze({sport:"sport",league:"league",team:"team",player:"player",flag:"flag",venue:"venue",background:"background",teaser:"teaser"});Object.freeze({[o.zv.baseball]:"OSB.26BE_Baseball.png",[o.zv.football]:"OSB.1F3C8_AmericanFootball.png",[o.zv.volleyballbeach]:"OSB.1F3D0_Volleyball.png",[o.zv.volleyballteam]:"OSB.1F3D0_Volleyball.png",[o.zv.tennis]:"OSB.Tennis.png",[o.zv.tabletennis]:"OSB.1F3DG_TableTennis.png",[o.zv.soccer]:"OSB.1F3D1_Soccer.png",[o.zv.rugbyleague]:"OSB.1F3C9_RugbyFootball.png",[o.zv.rugbyunion]:"OSB.1F3C9_RugbyFootball.png",[o.zv.golf]:"OSB.26F3_Golf.png",[o.zv.cricket]:"OSB.1F3CF_CricketGame.png",[o.zv.boxing]:"OSB.1F94A_Boxing.png",[o.zv.bowling]:"OSB.1F3B3_Bowling.png",[o.zv.basketball]:"OSB.1F3C0_Basketball.png",[o.zv.badminton]:"OSB.1F3F8_Badminton.png",[o.zv.icehockey]:"OSB.1F3D2_IceHockey.png"}),i(48566);var l=i(72627),p=i(50180),c=i(59010);const d="OSB.team_logo_placeholder.png",g=`${(0,r.rA)().StaticsUrl}/latest/sports/img/IPL/DefaultPlayerImage.svg`,h=`${(0,r.rA)().StaticsUrl}/latest/sports/img/flags/generic.svg`,y={width:28,height:28,enableDpiScaling:!0,devicePixelRatio:2,format:a.f5.PNG},m="sports/",u="MSports";function b(e,t,i,r=!0){let s=e;if((0,p.oT)(s)){if(!r)return"";switch(i){case n.player:s=g;break;case n.team:s=d;break;case n.flag:s=h;break;default:s=d}}return t.crop||(t.crop=0),t.padding||0===t.padding||(t.padding=1),s.indexOf(".")>0&&!s.startsWith("http")?(0,a.oQ)(`${a.Ro}?id=${s}&pid=${u}`,t):x(s,t)}function x(e,t){return e.startsWith("http")?(0,a.oQ)(e,t):(0,a.XP)(e,t)}function f(e,t){if(e||(e=m),e.startsWith("/")||(e=`/${e}`),t)for(const i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e=e.replace(`{${i}}`,t[i]));let i=`${r.T3.NavTargetUrlWithLocale}${e}`;if(i=(0,s.wY)(i),function(e){const t=new c.m(e||(0,l.iA)());return"1"===t.get("vptest")||"vp"===t.get("reqsrc")}())return i;const a=new URL(i),o=new URLSearchParams((0,l.iA)()),n=o.getAll("item");n?.length&&n.forEach(e=>{e&&a.searchParams.append("item",e)});const p=o.getAll("src");p?.length&&p.forEach(e=>{e&&a.searchParams.append("src",e)});const d=o.get("uxmode");return d&&a.searchParams.append("uxmode",d),a.href}const v={FullName:"FullName",ShortName:"ShortName",SchoolName:"SchoolName",Alias:"Alias",Abbreviation:"Abbreviation"};function w(e,t=[]){if(!e)return null;if(!t.length){if(!(0,p.oT)(e.name?.localizedName))return e.name.localizedName;if(!(0,p.oT)(e.name?.rawName))return e.name.rawName}for(const i of t)switch(i){case v.FullName:if(!(0,p.oT)(e.name?.localizedName)||!(0,p.oT)(e.name?.rawName))return e.name.localizedName??e.name.rawName;break;case v.ShortName:if(!(0,p.oT)(e.shortName?.localizedName))return e.shortName.localizedName;if(!(0,p.oT)(e.name?.localizedName))return e.name.localizedName;if(!(0,p.oT)(e.shortName?.rawName))return e.shortName.rawName;if(!(0,p.oT)(e.name?.rawName))return e.name.rawName;break;case v.SchoolName:if(!(0,p.oT)(e.schoolName?.localizedName))return e.schoolName.localizedName;if(!(0,p.oT)(e.schoolName))return e.schoolName;break;case v.Alias:if(!(0,p.oT)(e.alias?.localizedName))return e.alias.localizedName;if(!(0,p.oT)(e.alias))return e.alias;break;case v.Abbreviation:if(!(0,p.oT)(e.abbreviation?.localizedName))return e.abbreviation.localizedName;if(!(0,p.oT)(e.abbreviation))return e.abbreviation}return null}},46763(e,t,i){let a;i.d(t,{Nx(){return a}})},31870(e,t,i){i.r(t),i.d(t,{SportsGameStatsTransformer(){return d.O},SportsPickWinnerTransformer(){return m},SportsSpotlightTransformer(){return u.V},SportsMatchTransformer(){return g.SportsMatchTransformer},SportsGameLeadersTransformer(){return c}});var a=i(67072),r=i(23305),s=i(79811),o=i(87906),n=i(40450);const l=Object.freeze({points:"PTSAbbr",goals:"GAbbr",assists:"AAbbr",saves:"SVAbbr",hits:"HAbbr",atBats:"ABAbbr",strikeOuts:"KAbbr",yards:"YDSAbbr",receptions:"RECAbbr",rebounds:"REBAbbr",attempts:"FGAAbbr",redCards:"RCAbbr",yellowCards:"YCAbbr",powerPlayGoals:"PPGAbbr",powerPlayAssists:"PPAAbbr",fieldGoalsPercentage:"FGPerAbbr",freeThrowsPercentage:"FTPerAbbr",turnovers:"TOAbbr",defensiveRebounds:"DREBAbbr",offensiveRebounds:"OREBAbbr",runsBattedIn:"RBIAbbr",cmpPercValue:"CMPAbbr",touchdowns:"TDAbbr",interceptions:"INTAbbr",rating:"RTGAbbr",longest:"LGAbbr"}),p=Object.freeze({points:"points",rebounds:"rebounds",assists:"assists",passingYards:"passing",rushingYards:"rushing",receivingYards:"receiving",hits:"hits",rbi:"RBI",strikeOuts:"strikeouts",goals:"goals",saves:"saves",cards:"cards"});class c extends r.Bc{async transform(e){try{return{viewModel:await this.getCurrentViewModel(e)}}catch(t){(0,o.vV)(n.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(e)}`,void 0)}}async getCurrentViewModel(e){if(!e)return(0,o.vV)(n.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(e)}`,void 0),null;let t=0;switch(e.cardSize){case a.uE._1x_1y:t=1;break;case a.uE._1x_2y:t=3;break;case a.uE._1x_3y:t=5;break;case a.uE._2x_2y:t=4}const i=this.transformSportsGameLeadersToVM(e.sportsGameLeaders,e.teamColors).slice(0,t),r=e.parentTelemetryObject.getMetadataTag();return{sportsGameLeaders:{categories:i},cardSize:e.cardSize,cardTitle:this.transformerProvider.strings.gameLeaders,telemetryTag:r}}transformSportsGameLeadersToVM(e,t){if(!e?.categoryKeyOrder||!e?.categories)return(0,o.vV)(n.EfP,"GameLeaders object is not valid",`jsonData:${JSON.stringify(e)}`,void 0),[];return e.categoryKeyOrder.map(i=>{const a=e.categories[i];if(!a)return(0,o.vV)(n.EfP,"GameLeaders category data is missing",`jsonData:${JSON.stringify(e)}`,void 0),null;const r=a.players.map(e=>{const i=a.statsKeyOrder.map(t=>({abbreviation:this.transformerProvider.strings[l[t]]||t.slice(0,3).toLocaleUpperCase(),title:t,value:Number(e.playerStats[t]).toFixed(0)||0}));return t[e.teamId]||(0,o.vV)(n.khl,"GameLeaders player team color is missing",`jsonData:${JSON.stringify(e)}`,void 0),{playerImage:(0,s.iK)(e.playerImage||s.UU,!e.playerImage,this.transformerProvider.config.teamImageInfoEnhanced),playerName:e.playerName,playerNumber:e.playerNumber,teamColor:t[e.teamId],playerStats:i}});return{categoryTitle:this.transformerProvider.strings[p[i]]||i.toLocaleUpperCase(),players:r}}).filter(e=>e)}}var d=i(70512),g=i(82724),h=i(18633),y=i(50180);class m extends r.Bc{async transform(e){return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){const{poll:t,telemetryConstants:i,parentTelemetryObject:a,match:s,isSpotlight2Card:o}=e||{},{participantOne:n,participantTwo:l,gameState:p,gameId:c}=s||{},{strings:d,telemetryBuilder:g}=this.transformerProvider,m=[n,l];let u=0;Array.isArray(t.options)||(t.options=[]),t.options?.forEach(e=>{e.id!==m[0].id&&e.id!==m[1].id||(u+=parseInt(e.count))});const b=1===u?d.voteSingular:d.votesNumber;return{strings:{...d},isSpotlight2Card:o,isEntrypoint:!0,isCopilotTheme:e.isCopilotTheme,cardSize:e.cardSize,totalVotesString:u?(0,y.GP)(b||"",String(u)):"",teamsVoteData:m.map(e=>{const i=parseInt(t.options?.find(t=>t.id===e.id)?.count)||0;return{id:e.id,imageUrl:e.imageUrl,shortName:e.shortName||e.name,hasWon:e.isWinner,voteCount:i,votePercentage:Math.round(i/u*100)||0}}),gameState:"string"==typeof p?p:p.state,userVote:t.userVote,disableVoting:p!==r.Xp.preGame,telemetryContext:{rootTag:a.getMetadataTag(),voteButtonTag:g.createBehaviorTelemetryTag(a,{...i,name:r.BP.SportsPickWinner},h.YJ.Click)},recordUserVote:async e=>{this.transformerProvider.recordUserVote(c,r.t9.PickWinner,e)},telemetryTag:a.getMetadataTag()}}}var u=i(34959);Promise.resolve().then(i.bind(i,94138)),Promise.resolve().then(i.bind(i,9038)),Promise.resolve().then(i.bind(i,4708)),Promise.resolve().then(i.bind(i,70846)),Promise.resolve().then(i.bind(i,38584)),Promise.resolve().then(i.bind(i,811))},71372(e,t,i){i.d(t,{a(){return o}});var a=i(56911),r=i(92011),s=i(95144);let o=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([s.x],o)},38584(e,t,i){i.r(t),i.d(t,{SportsGameLeaders(){return Oe}});var a=i(56911),r=i(20517);class s extends r.z{}var o=i(92011),n=i(61138),l=i(63033),p=i(59669);const c=p.A` :host{--secondary-font-color:#999999}`,d=p.A` :host{--secondary-font-color:#707070}`,g=p.A` :host{display:inline-block;width:100%}.game-leaders{display:grid;gap:12px}.category-row{display:grid;justify-items:center;gap:4px}.category-title{font-size:${n.k};line-height:${n.F};font-weight:400;color:var(--secondary-font-color)}.player-cards{width:100%;display:grid;grid-template-columns:1fr 1fr}`.withBehaviors(new l.N(d,c));var h=i(89757),y=i(68835),m=i(69259),u=i(60815),b=i(9960);const x=Object.freeze({default:"default",lite:"lite"}),f=Object.freeze({Stack:"stack",SideBySide:"side-by-side"});class v extends o.L{constructor(){super(),this.type=x.default,this.name="",this.fullName="",this.nameDetail="",this.description="",this.image="",this.isDarkMode=(0,b.ud)(),this.playerInfoRenderMode=f.Stack,this.isRuby=!1,this.isCopilot=!1,this.isMai=!1,this.imageClickHandler=()=>{this.redirectLink&&open(this.redirectLink,"_blank")},this.colorSchemeChangeHandler=this.colorSchemeChangeHandler.bind(this)}connectedCallback(){super.connectedCallback();const e=window.matchMedia("(prefers-color-scheme: dark)");e.addEventListener&&e.addEventListener("change",this.colorSchemeChangeHandler)}disconnectedCallback(){super.disconnectedCallback();window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change",this.colorSchemeChangeHandler)}colorSchemeChangeHandler(){this.isDarkMode=(0,b.ud)()}get playerNameInitials(){if(!this.name||!this.name.trim())return"";const e=this.name.trim().split(/\s+/);if(e.length<2)return this.name.charAt(0);const t=e[0],i=e[1];return`${t.charAt(0)}${i.charAt(0)}`}get playerNameAndNameDetailsCombined(){return[this.name,this.nameDetail].filter(Boolean).join(" ")}}(0,a.Cg)([u.sH],v.prototype,"type",void 0),(0,a.Cg)([u.sH],v.prototype,"name",void 0),(0,a.Cg)([u.sH],v.prototype,"fullName",void 0),(0,a.Cg)([u.sH],v.prototype,"nameDetail",void 0),(0,a.Cg)([u.sH],v.prototype,"playerNumber",void 0),(0,a.Cg)([u.sH],v.prototype,"description",void 0),(0,a.Cg)([u.sH],v.prototype,"image",void 0),(0,a.Cg)([u.sH],v.prototype,"teamColor",void 0),(0,a.Cg)([u.sH],v.prototype,"teamImage",void 0),(0,a.Cg)([u.sH],v.prototype,"injuryInfo",void 0),(0,a.Cg)([u.sH],v.prototype,"statistics",void 0),(0,a.Cg)([u.sH],v.prototype,"statisticsLabel",void 0),(0,a.Cg)([u.sH],v.prototype,"isDarkMode",void 0),(0,a.Cg)([u.sH],v.prototype,"playerInfoRenderMode",void 0),(0,a.Cg)([u.sH],v.prototype,"redirectLink",void 0),(0,a.Cg)([u.sH],v.prototype,"isPlayerImageAvailable",void 0),(0,a.Cg)([u.sH],v.prototype,"columnLayout",void 0),(0,a.Cg)([u.sH],v.prototype,"isRuby",void 0),(0,a.Cg)([u.sH],v.prototype,"isCopilot",void 0),(0,a.Cg)([u.sH],v.prototype,"isMai",void 0);var w=i(49417),$=i(41123),k=i(63129),F=i(62047),S=i(83252),z=i(69809),C=i(89580),_=i(6032),T=i(22131),j=i(97747);j.G.create("cricket-win-color"),j.G.create("copilot-header-color"),j.G.create("ruby-border-radius"),j.G.create("copilot-container-fill-color"),j.G.create("sp-container-1-col-width"),j.G.create("sp-container-mobile-width"),j.G.create("sp-container-flyout-width"),j.G.create("sp-container-2-col-width"),j.G.create("sp-container-3-col-width"),j.G.create("sp-container-4-col-width"),j.G.create("sp-page-min-width"),j.G.create("sp-container-padding"),j.G.create("sp-container-one-col-padding"),j.G.create("sp-container-mobile-padding"),j.G.create("sp-container-margin"),j.G.create("sp-container-one-col-margin"),j.G.create("sp-container-mobile-margin"),j.G.create("sp-container-corner-radius"),j.G.create("sp-container-one-col-corner-radius"),j.G.create("sp-content-row-gap"),j.G.create("sp-content-row-gap-one-col"),j.G.create("sp-content-row-gap-mobile"),j.G.create("sp-content-column-gap"),j.G.create("sp-content-column-gap-one-col"),j.G.create("sp-content-column-gap-mobile"),j.G.create("sp-vertical-container-margin-bottom"),j.G.create("sp-vertical-container-margin-bottom-one-col"),j.G.create("sp-vertical-container-margin-bottom-mobile"),j.G.create("sp-container-title-margin"),j.G.create("sp-container-title-one-col-margin"),j.G.create("sp-container-title-mobile-margin"),j.G.create("sp-scroll-proxy-container-margin"),j.G.create("sp-scroll-proxy-container-one-col-margin"),j.G.create("sp-scores-schedule-container-padding"),j.G.create("sp-scores-schedule-container-one-col-padding"),j.G.create("sp-scores-schedule-container-mobile-padding"),j.G.create("sp-game-summary-container-padding"),j.G.create("sp-game-summary-container-one-col-padding"),j.G.create("sp-game-summary-container-mobile-padding"),j.G.create("sp-cricket-rankings-container-header-padding"),j.G.create("sp-cricket-rankings-container-header-one-col-padding"),j.G.create("sp-cricket-rankings-container-header-mobile-padding");const B=j.G.create("sp-text-base-font-size"),A=(j.G.create("sp-text-minus-1-font-size"),j.G.create("sp-text-minus-2-font-size"),j.G.create("sp-text-minus-3-font-size"),j.G.create("sp-text-plus-1-font-size")),D=(j.G.create("sp-text-plus-2-font-size"),j.G.create("sp-text-plus-3-font-size"),j.G.create("sp-text-plus-4-font-size"),j.G.create("sp-text-plus-5-font-size"),j.G.create("sp-text-minus-1-line-height"),j.G.create("sp-text-minus-2-line-height"),j.G.create("sp-text-minus-3-line-height"),j.G.create("sp-text-base-line-height")),P=(j.G.create("sp-text-plus-1-line-height"),j.G.create("sp-text-plus-2-line-height"),j.G.create("sp-font-color")),E=j.G.create("sp-font-color-sub"),O=(j.G.create("sp-cr-font-color-sub"),j.G.create("sp-mai-background-color"),j.G.create("section-header-color"),j.G.create("sp-cr-top-border-color"),j.G.create("sp-cr-live-color-lll"),j.G.create("sp-cr-live-color-ll"),j.G.create("sp-cr-live-color-l"),j.G.create("sp-cr-live-color"),j.G.create("sp-cr-delayed-color"),j.G.create("sp-copilot-divider-color"),j.G.create("sp-copilot-divider-border"),j.G.create("sp-tab-hover-background-color"),j.G.create("sp-tab-pressed-background-color"),j.G.create("sp-tab-pressed-font-color"),j.G.create("sp-button-hover-background-color"),j.G.create("sp-button-pressed-background-color"),j.G.create("sp-button-pressed-font-color"),j.G.create("sp-button-second-hover-background-color"),j.G.create("sp-button-second-pressed-background-color"),j.G.create("sp-button-second-pressed-font-color"),p.A`
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        white-space: nowrap;
        border-width: 0;
        clip-path: inset(100%);
    }

    .ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @supports (-webkit-line-clamp: 2) {
        .ellipsis.with-2-lines {
            white-space: normal;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    }
`),M=p.A` :host{--ruby-player-round-bg:rgba(255,255,255,5%);--ruby-player-team-shadow:#000000;--ruby-player-team-bg:#F6F9FC;--ruby-player-name-color:#FFFFFF;--ruby-stat-val-color:#FFFFFF;--ruby-player-desc-color:${E};--ruby-lite-round-bg:rgba(255,255,255,0.05);--ruby-copilot-lite-round-bg:rgba(157,168,217,0.05);--player-initials-bg:#6D585B;--player-initials-color:#F2DDCC}`,G=p.A` :host{--ruby-player-round-bg:rgba(0,0,0,5%);--ruby-player-team-shadow:#FFFFFF;--ruby-player-team-bg:#23272B;--ruby-player-name-color:#23272B;--ruby-stat-val-color:#23272B;--ruby-player-desc-color:${E};--ruby-lite-round-bg:rgba(0,0,0,0.05);--ruby-copilot-lite-round-bg:rgba(204,196,192,0.2);--player-initials-bg:#FFD79C;--player-initials-color:#33302E}`,I=p.A` .ruby .player-desc-wrapper .player-desc,.sports-player-card.lite.ruby.copilot .player-info .player-name{forced-color-adjust:auto}`,N=p.A` ${O} :host{display:inline-block;width:100%;border-bottom:1px solid ${w.hb}}.sports-player-card{object-fit:cover;width:100%;height:100%}.ruby.sports-player-card{column-gap:16px}.ruby.copilot.sports-player-card{column-gap:12px}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-info,.injury-info,.player-stat{flex-direction:column}.sports-player-card{display:flex;align-items:flex-start}.sports-player-card.lite{display:flex;align-items:center}.sports-player-card.lite .player-image{align-items:center}.sports-player-card .player-image{display:flex;flex-direction:row;height:100%}.sports-player-card .player-image .player-image-info{display:flex;flex-direction:column;justify-content:space-between;align-items:center}.player-image .player-image-info .player-info-team{height:${$.Z};width:${$.Z}}.player-image .player-image-info .player-info-number{font-size:${n.k};line-height:${n.F};color:${k.ls}}.player-image .player-image-info .player-info-number-small{font-size:${F.t};line-height:${F.e}}.sports-player-card .player-image .player-round-image{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${S.X4};overflow:hidden}.sports-player-card .player-image .player-round-image-clickable{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${S.X4};overflow:hidden;cursor:pointer}.sports-player-card .player-image .player-round-image,.sports-player-card .player-image .player-round-image-clickable{width:65px;height:65px}.sports-player-card.lite .player-image .player-round-image,.sports-player-card.lite .player-image .player-round-image-clickable{width:36px;height:36px}.sports-player-card .player-image .player-icon{height:100%;width:100%}.sports-player-card .player-image .player-image-link{width:100%;position:absolute;bottom:0;display:flex;justify-content:center;align-items:center;background:rgba(0,0,0,0.44);backdrop-filter:blur(1px)}.player-image-link image{fill:${z.m_}}.player-info{width:60%;flex-direction:column;padding:5px 15px 0 15px}.sports-player-card.lite .player-info{padding:5px}.player-info .player-name{font-size:${$.K};line-height:${$.Z};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.ruby .player-info .player-name{font-size:${C.Y};line-height:24px;font-weight:550;color:var(--ruby-player-name-color)}.sports-player-card.lite.ruby .player-info .player-name{font-size:${$.K}}.sports-player-card.lite.ruby.copilot .player-info .player-name{font-size:${B};line-height:${D};font-weight:410;color:${P}}.player-info .player-name .name-detail{font-weight:400;color:${_.c}}.sports-player-card .player-info{width:100%;min-width:0;flex-direction:column;display:flex;align-items:flex-start;padding:0 12px}.ruby.sports-player-card .player-info{width:unset;flex-grow:1;padding:0}.ruby.copilot.sports-player-card .player-info{width:calc(100% - 48px);align-items:unset;gap:2px}.sports-player-card .player-info .player-stats{width:100%;display:flex;justify-content:space-between;text-align:center}.sports-player-card .player-info .player-stats .player-stat{display:flex;flex-direction:column;align-items:flex-start}.sports-player-card.lite .player-info .player-name{font-size:${$.K}}.player-info .player-desc{font-size:${F.t};line-height:${F.e};color:${k.ls};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.injury-info,.player-stats{line-height:${$.Z};font-size:${$.K}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${C.Y};height:${C.Y};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-between;text-align:center}.stat-val,.injury-status{font-weight:600;font-size:${$.K};line-height:${$.Z}}.stat-title{font-size:${n.k};line-height:${n.F};color:${k.ls}}.ruby.sports-player-card{align-items:center}.ruby-player-image{position:relative;width:80px;height:80px}.layout-1 .ruby-player-image{width:60px;height:60px}.ruby-player-image.only-team-image,.layout-1 .ruby-player-image.only-team-image{align-self:flex-start;width:24px;height:24px}.ruby-player-round-image{width:100%;height:100%;background-color:var(--ruby-player-round-bg);border-radius:50%}.ruby-player-team-image{position:absolute;right:2px;bottom:2px;width:24px;height:24px;box-shadow:0 0 0 2px var(--ruby-player-team-shadow);background-color:var(--ruby-player-team-bg);border-radius:50%}.layout-1 .ruby-player-team-image{width:20px;height:20px}.player-desc-wrapper{display:flex;max-width:100%}.ruby .player-desc-wrapper{gap:8px}.ruby .player-desc-wrapper .player-info-number{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby.lite.copilot .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z}}.ruby .player-stats{margin-top:8px}.layout-1.ruby .player-stats{margin-top:4px}.ruby .player-stat{flex:1 1 0}.ruby .player-stat:last-child{flex:0 1 42px}.ruby.layout-2 .player-stat:last-child{flex:1 1 0}.ruby .stat-val{font-size:${C.Y};line-height:24px;font-weight:550;color:var(--ruby-stat-val-color)}.ruby .stat-title{font-weight:550;color:var(--ruby-player-desc-color)}.layout-4.ruby .stat-title{font-size:${$.K};line-height:${$.Z}}.ruby.lite.layout-4 .player-info .player-name{font-size:${C.Y};line-height:${C.v}}.ruby.lite.layout-4 .player-info .player-desc-wrapper{font-size:${$.K};line-height:${$.Z}}.ruby.lite .player-image .player-round-image,.ruby.lite .player-image .player-round-image-clickable{background:var(--ruby-lite-round-bg)}.ruby.copilot.lite .player-image .player-round-image,.ruby.copilot.lite .player-image .player-round-image-clickable{background:var(--ruby-copilot-lite-round-bg)}.ruby.lite.layout-4 .player-image .player-round-image,.ruby.lite.layout-4 .player-image .player-round-image-clickable{height:40px;width:40px}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--background-color,--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${A};line-height:${D};font-weight:400;letter-spacing:-0.01em;color:var(--font-color,--player-initials-color)}.layout-1 .player-initials > span{font-size:${B}}`.withBehaviors(new l.N(G,M),(0,T.mr)(I)),L=h.qy`
    <div class="injury-info">
        <span class="injury-status">
            ${(0,m.z)(e=>e.injuryInfo?.statusIconColor,h.qy`
                <i class="status-icon" style="background: ${e=>e.isDarkMode?e.injuryInfo?.statusIconColor?.dark:e.injuryInfo?.statusIconColor?.primary}"></i>
            `)}
            <span class="status-text" title="${e=>e.injuryInfo?.status}">
                ${e=>e.injuryInfo?.status}
            </span>
        </span>
        ${(0,m.z)(e=>e.injuryInfo?.injuryArea,h.qy`
            <span class="injury-area">${e=>e.injuryInfo?.injuryArea}</span>
        `)}
    </div>
`;var R=i(33744),U=i(57744);const V=`${(0,R.rA)().StaticsUrl}/latest/sports/icons/SportsImageExplorer.svg`,Y=h.qy`
    <div class="player-stats">
        ${(0,y.ux)(e=>e.statistics,h.qy`
            <div class="player-stat">
                <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                ${(0,m.z)(e=>!!e.abbreviation,h.qy`
                    <span class="stat-title" title="${e=>e.title}">${e=>e.abbreviation}</span>
                `)}
            </div>
        `)}
    </div>
`,H=h.qy`
    <div class="player-image">
        ${(0,m.z)(e=>e.type===x.default,h.qy`
            <div class="player-image-info">
                ${(0,m.z)(e=>e.teamImage,h.qy`
                    <img class="player-info-team" loading="lazy" role="presentation" src="${e=>e.teamImage||" "}" />
                `)}
                ${(0,m.z)(e=>e.playerNumber,h.qy`
                    <span class="${e=>e.isPlayerImageAvailable?"player-info-number":"player-info-number-small"}">
                        #${e=>e.playerNumber}
                    </span>
                `)}
            </div>
        `)}
        ${(0,m.z)(e=>e.isPlayerImageAvailable,h.qy`
            <div 
                class="${e=>e.redirectLink?"player-round-image-clickable":"player-round-image"}" 
                @click=${e=>e.imageClickHandler()}
            >
                ${(0,m.z)(e=>e.image&&""!==e.image,h.qy`
                    <img class="player-icon" loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}" />
                `,h.qy`
                    <span class="sr-only">${e=>e.fullName||e.name}</span>
                    <div
                        class="player-initials"
                        title=${e=>e.fullName||e.name}
                        aria-hidden="true"
                    >
                        <span>${e=>e.playerNameInitials}</span>
                    </div>
                `)}
                ${(0,m.z)(e=>e.redirectLink,h.qy`
                    <div class="player-image-link">
                        <img src=${V} alt="sportsImageExplorerIcon" loading="lazy" aria-hidden="true" />
                    </div>
                `)}
            </div>
        `)}
    </div>
`,W=h.qy`
    <img class="ruby-player-round-image" loading="lazy" src=${e=>(0,U.OY)(U.UU,U.Bk)} alt=${e=>e.fullName||e.name} />
`,X=h.qy`
    ${(0,m.z)(e=>e.isPlayerImageAvailable,h.qy`
        <div class="ruby-player-image" @click=${e=>e.imageClickHandler()}>
            <img class="ruby-player-round-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
            ${(0,m.z)(e=>e.teamImage,h.qy`
                <img class="ruby-player-team-image" loading="lazy" role="presentation" src=${e=>e.teamImage} />
            `)}
        </div>
    `,h.qy`
        ${(0,m.z)(e=>e.teamImage,h.qy`
            <div class="ruby-player-image only-team-image" @click=${e=>e.imageClickHandler()}>
                <img class="ruby-player-round-image" loading="lazy" src=${e=>e.teamImage} alt=${e=>e.fullName||e.name} />
            </div>
        `,W)}
    `)}
`,q=h.qy`
    <div class="sports-player-card ${e=>e.type} ${e=>e.columnLayout?`layout-${e.columnLayout}`:""} ${e=>e.isRuby?"ruby":""} ${e=>e.isCopilot?"copilot":""}">
        ${(0,m.z)(e=>e.isRuby&&e.type!==x.lite,X,H)}
        <div class="player-info">
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <span
                class="player-name"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                ${e=>e.name}
                <span class="name-detail"> ${e=>e.nameDetail}</span>
            </span>
            <div class="player-desc-wrapper">
                ${(0,m.z)(e=>e.playerNumber&&e.isRuby,h.qy`<span class="player-info-number">#${e=>e.playerNumber}</span>`)}
                <span class="player-desc">${e=>e.description}</span>
            </div>
            ${(0,m.z)(e=>e.injuryInfo,L)}
            ${(0,m.z)(e=>e.statistics?.length,Y)}
        </div>
    </div>
`;var J=i(33113);const K=p.A` ${O} :host{display:inline-block;width:100%}.sports-player-card{object-fit:cover;width:100%;height:100%;flex-direction:column;align-items:center}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-stats{flex-direction:row}.player-info,.injury-info,.player-stat{flex-direction:column}.player-stat{margin-inline-start:6px}.player-image{padding-bottom:5px;position:relative}.sports-player-card.grid-card .player-image{padding-bottom:0;align-items:center}.player-image img{width:40px;height:40px;border-radius:50px;border:1px solid ${J.I2}}.sports-player-card.grid-card .player-image img{width:36px;height:36px;border-radius:50%;background:unset;border:1px solid ${S.X4}}.player-image{bottom:5px;border-end-start-radius:5px;padding:2px 0}.player-info{width:60%;flex-direction:column;align-items:center}.player-info-text-content{flex-direction:column;align-items:center;display:flex}.sports-player-card.grid-card .player-info{padding:5px}.player-info .player-name{font-size:${n.k};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center}.player-desc{overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center;white-space:nowrap}.player-info .player-desc{font-size:${F.t};line-height:${F.e}}.injury-info,.player-stats{line-height:${F.e};font-size:${F.t}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${F.t};height:${F.e};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-around;text-align:center;width:100px}.stat-val,.injury-status{font-weight:600;font-size:${n.k}}.stat-title,.player-desc{color:${k.ls}}.sports-player-card.side-by-side{flex-direction:row}.sports-player-card.side-by-side .player-info{flex-direction:row;width:100%}.sports-player-card.side-by-side .player-info .player-info-text-content{margin-inline-start:10px}.sports-player-card.side-by-side .player-info .player-name{text-align:unset}.sports-player-card.side-by-side .player-image{bottom:unset}.sports-player-card.side-by-side .player-info .player-name{text-align:unset;width:150px}.sports-player-card.side-by-side .player-desc{text-align:unset;width:150px}.sports-player-card.side-by-side .injury-status .status-icon{height:7px;width:7px}.sports-player-card.side-by-side .injury-status .injury-info{padding-inline-start:10px}`.withBehaviors(),Q=h.qy`
    <div class="player-stats">
        ${(0,y.ux)(e=>e.statistics,h.qy`
            ${(0,m.z)(e=>!!e.abbreviation,h.qy`
                <div class="player-stat">
                    <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                    <span class="stat-title" title="${e=>e.title??e.abbreviation}">${e=>e.abbreviation}</span>
                </div>
            `)}
        `)}
    </div>
`,Z=h.qy`
    <div class="sports-player-card ${e=>e.type} ${e=>e.playerInfoRenderMode==f.SideBySide?"side-by-side":""}">
        <div class="player-image">
            <img loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}">
        </div>
        <div class="player-info">
            <div class="player-info-text-content">
                <span class="sr-only">${e=>e.fullName||e.name}</span>
                <span class="player-name" title="${e=>e.fullName||e.name}" aria-hidden="true">${e=>e.name}</span>
                <span class="player-desc">${e=>e.description+" "}
                    <span> ${e=>null==e.playerNumber?"":"#"+e.playerNumber}</span>
                </span>
            </div>
            ${(0,m.z)(e=>e.injuryInfo,L)}
            ${(0,m.z)(e=>e.statistics?.length,Q)}
        </div>
    </div>
`,ee=p.A` :host{--secondary-font-color:#999999;--image-border-color:#666666}`,te=p.A` :host{--secondary-font-color:#707070;--image-border-color:#D1D1D1}`,ie=p.A` ${O} :host{display:inline-block;width:100%;min-width:0}.sports-player-card{display:grid;grid-template-columns:max-content auto;align-items:center;gap:6px}.player-round-image{object-fit:cover;border-radius:50%;overflow:hidden}.image-border{border:1px solid var(--image-border-color)}.player-icon{width:36px;height:36px;display:block}.player-info{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-width:0}.player-name{font-weight:600;text-align:left;max-width:96px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:20px;font-size:${$.K};line-height:${$.Z};max-width:100%}.player-stats{display:flex;flex-wrap:nowrap;font-size:12px;height:20px;gap:2px;display:flex;align-items:center}.player-stats-vals{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.player-stats-titles{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.stat-val{font-weight:600}.stat-title{font-weight:400;color:var(--secondary-font-color)}`.withBehaviors(new l.N(te,ee)),ae=h.qy`
    <div class="player-stats">
        <div class="player-stats-vals">
            ${(0,y.ux)(e=>e.statistics,h.qy`
                <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                ${(0,m.z)((e,t)=>!t.isLast,h.qy`-`)}
            `,{positioning:!0})}
        </div>
        <div class="player-stats-titles">
            ${(0,y.ux)(e=>e.statistics,h.qy`
                ${(0,m.z)(e=>!!e.abbreviation,h.qy`
                    <span class="stat-title" title="${e=>e.title}">${e=>e.abbreviation}</span>
                `)}
                ${(0,m.z)((e,t)=>!t.isLast,h.qy`<span class="stat-title">-</span>`)}        
            `,{positioning:!0})}
        </div>
    </div>
`,re=h.qy`
<div class="sports-player-card ${e=>e.type}">
    ${(0,m.z)(e=>e.isPlayerImageAvailable,h.qy`
        <div class="player-round-image ${e=>e.teamColor?"image-border":""}" style="background-color:${e=>e.teamColor};">
            <img class="player-icon" loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}">
        </div>
    `)}
    <div class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span class="player-name" title="${e=>e.fullName||e.name}" aria-hidden="true">
            ${e=>e.name}
        </span>
        ${(0,m.z)(e=>e.statistics?.length,ae)}
    </div>
</div>
`;var se=i(37079),oe=i(62198),ne=i(32257);const le=p.A` .player-image,.player-stats{background-color:#9DA8D90D}.player-initials{background-color:#6D585B}.team-logo{box-shadow:0 0 0 2px #282F42;background-color:#282F42}`,pe=p.A` .player-image,.player-stats{background-color:#CCC4C033}.player-initials{background-color:#FFD79C}.team-logo{box-shadow:0 0 0 2px #F4EFED;background-color:#F4EFED}`,ce=p.A` ${O} .sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;flex-direction:column;align-items:center;width:100%;row-gap:12px;text-align:center}.layout-1.sports-player-card{row-gap:8px}.player-image-container{position:relative;width:90px;height:90px}.player-image{width:100%;height:100%;border-radius:50%}.mai .player-image{background-color:${ne.GEK}}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:50%}.player-initials > span{font-size:${se.F};line-height:${oe.b};font-weight:400;letter-spacing:-0.01em;color:${P}}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;border-radius:50%}.mai .team-logo{box-shadow:0 0 0 2px ${ne.GEK};background-color:${ne.GEK}}.player-info{display:flex;flex-direction:column;align-items:center;width:100%;padding-inline:4px}.player-name{width:100%;font-size:15px;line-height:${$.Z};font-weight:700;color:${P};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{width:100%;font-size:${n.k};line-height:${n.F};font-weight:650;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px}.mai .player-stats{border-radius:${ne.g6L};background-color:${ne.GEK}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${P};white-space:nowrap}.stat-title{display:block;font-size:${F.t};line-height:${F.e};font-weight:700;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new l.N(pe,le));var de=i(46763),ge=i(46187);const he=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(e=>e.isPlayerImageAvailable&&e.image&&!e.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
        `,h.qy`
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <div
                class="player-initials"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                <span>${e=>e.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(e=>e.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${e=>e.teamImage} alt="" />
        `)}
    </div>
`,ye=h.qy`
    <header class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span
            id=${e=>`header-${e.id}`}
            class="player-name"
            title=${e=>e.fullName||e.name}
            aria-hidden="true"
        >
            ${e=>e.name}
        </span>
        <span class="player-description">
            ${e=>e.playerNumber?`#${e.playerNumber} ${e.description}`:`${e.description}`}
        </span>
    </header>
`,me=h.qy`
    ${(0,m.z)(e=>e.abbreviation&&e.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${e=>`${e.value} ${e.title}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${e=>e.value}
            </span>
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        </div>
    `)}
`,ue=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${e=>`${e.value} ${e.title}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${e=>e.value}
        </span>
        ${(0,m.z)(e=>e.abbreviation,h.qy`
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        `)}
    </div>
`,be=h.qy`
    <div class="sports-player-card ${e=>e.isMai?"mai":""} layout-${e=>e.columnLayout}" role="article" aria-labelledby=${e=>e.id?`header-${e.id}`:""}>
        ${he}
        ${ye}
        <div class="player-stats" role="list" aria-label=${e=>e.statisticsLabel||""}>
            ${(0,y.ux)(e=>e.statistics,h.qy`
                ${(0,m.z)(e=>de.Nx?.Sport===ge.zv.soccer,me,ue)}
            `)}
        </div>
    </div>
`;var xe=i(25975);const fe=p.A` :host{--player-initials-bg:#6D585B}`,ve=p.A` :host{--player-initials-bg:#FFD79C}`,we=p.A` ${O} :host{--player-image-bg:${ne.GEK};--player-stats-bg:${ne.GEK};--player-initials-color:${P};--team-logo-shadow:${ne.GEK};--team-logo-bg:${ne.GEK}}.sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;align-items:flex-start;width:100%;gap:12px}.layout-1.sports-player-card{gap:8px}.player-content{flex:1;min-width:0;display:flex;flex-direction:column;gap:12px}.layout-1 .player-content{gap:8px}.player-image-container{position:relative;flex:0 0 80px;width:80px;height:80px}.player-image{width:100%;height:100%;background-color:var(--player-image-bg);border-radius:50%}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${se.F};line-height:${oe.b};font-weight:400;letter-spacing:-0.01em;color:var(--player-initials-color)}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;box-shadow:0 0 0 2px var(--team-logo-shadow);background-color:var(--team-logo-bg);border-radius:50%}.player-info{display:flex;flex-direction:row;align-items:center;justify-content:space-between;width:100%;gap:4px}.player-name{flex:0 0 auto;min-width:0;max-width:75%;font-size:15px;line-height:${$.Z};font-weight:700;color:${P};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{flex:1 1 auto;min-width:0;font-size:${n.k};line-height:${n.F};font-weight:650;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px;background-color:var(--player-stats-bg)}@supports (corner-shape:squircle){.player-stats{border-radius:calc(12px * ${xe.MU6});corner-shape:squircle}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${P};white-space:nowrap}.stat-title{display:block;font-size:${F.t};line-height:${F.e};font-weight:700;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new l.N(ve,fe)),$e=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(e=>e.isPlayerImageAvailable&&e.image&&!e.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
        `,h.qy`
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <div
                class="player-initials"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                <span>${e=>e.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(e=>e.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${e=>e.teamImage} alt="" />
        `)}
    </div>
`,ke=h.qy`
    <header class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span
            id=${e=>`header-${e.id}`}
            class="player-name"
            title=${e=>e.fullName||e.name}
            aria-hidden="true"
        >
            ${e=>e.name}
        </span>
        <span class="player-description">
            ${e=>e.playerNumber?`#${e.playerNumber} ${e.description}`:`${e.description}`}
        </span>
    </header>
`,Fe=h.qy`
    ${(0,m.z)(e=>e.abbreviation&&e.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${e=>e.title?`${e.value} ${e.title}`:`${e.value}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${e=>e.value}
            </span>
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        </div>
    `)}
`,Se=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${e=>e.title?`${e.value} ${e.title}`:`${e.value}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${e=>e.value}
        </span>
        ${(0,m.z)(e=>e.abbreviation,h.qy`
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        `)}
    </div>
`,ze=h.qy`
    <div class="sports-player-card layout-${e=>e.columnLayout}" role="article" aria-labelledby=${e=>e.id?`header-${e.id}`:""}>
        ${$e}
        <div class="player-content">
            ${ke}
            <div class="player-stats" role="list" aria-label=${e=>e.statisticsLabel||""}>
                ${(0,y.ux)(e=>e.statistics,h.qy`
                    ${(0,m.z)(e=>de.Nx?.Sport===ge.zv.soccer,Fe,Se)}
                `)}
            </div>
        </div>
    </div>
`;let Ce=class extends v{};Ce=(0,a.Cg)([(0,o.E)({name:"sports-player-card",template:q,styles:N})],Ce);let _e=class extends v{};_e=(0,a.Cg)([(0,o.E)({name:"sports-player-card-v2",template:Z,styles:K})],_e);let Te=class extends v{};Te=(0,a.Cg)([(0,o.E)({name:"sports-player-card-v3",template:re,styles:ie})],Te);let je=class extends v{};je=(0,a.Cg)([(0,o.E)({name:"sports-player-card-copilot",template:be,styles:ce})],je);let Be=class extends v{};Be=(0,a.Cg)([(0,o.E)({name:"sports-player-card-mai",template:ze,styles:we})],Be);const Ae=h.qy`
    <sports-player-card-v3
        class="player-card"
        :type=${e=>x.default}
        :name=${e=>e.playerName}
        :playerNumber=${e=>e.playerNumber}
        :image=${e=>e.playerImage}
        :teamColor=${e=>e.teamColor}
        :teamImage=${e=>e.playerImage}
        :isPlayerImageAvailable=${e=>e.playerImage}
        :statistics=${e=>e.playerStats}>
    </sports-player-card-v3>
`,De=h.qy`
    <div class="category-row">
        <div class="category-title">
            ${e=>e.categoryTitle}
        </div>
        <div class="player-cards">
            ${(0,y.ux)(e=>e.players,Ae)}
        </div>
    </div>
`,Pe=h.qy`
    <div class="game-leaders">
        ${(0,y.ux)(e=>e.viewModel.sportsGameLeaders.categories,De,{positioning:!0})}
    </div>
`,Ee=h.qy`
    ${(0,m.z)(e=>null!=e.viewModel,Pe)}
`;let Oe=class extends s{};Oe=(0,a.Cg)([(0,o.E)({name:"sports-game-leaders",template:Ee,styles:g,shadowOptions:{delegatesFocus:!0}})],Oe)},9038(e,t,i){i.r(t),i.d(t,{SportsGameStats(){return B}});var a=i(56911),r=i(20517),s=i(83546),o=i(60815);class n extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,s.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,a.Cg)([o.sH],n.prototype,"isMitUx",void 0);var l=i(92011),p=i(86856),c=i(63033),d=i(59669),g=i(4126),h=i(22131);const y=d.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,m=d.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,u=d.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,b=d.A` .game-stats-item-content{transform:scaleX(-1)}`,x=d.A` .game-stats-list{background:var(--button-light-rest)}.game-stats-item-header > span:nth-child(2){font-weight:550}@media (prefers-color-scheme:dark){.game-stats-list{background-color:#00000040}.game-stats-item{color:#fff}.game-stats-title{color:#fff}}`,f=d.A` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new p.t(null,b),new c.N(u,m),new g.o("isAdaptiveThemeEnabled",!0,y),new g.o("isMitUx",!0,x),(0,h.mr)(d.A` :host{forced-color-adjust:auto}`));var v=i(89757),w=i(69259),$=i(68835);const k=v.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${e=>e.leftText}
            </span>
            <span>
                ${e=>e.key}
            </span>
            <span>
                ${e=>e.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${e=>0!==e.gap?`background: linear-gradient(to right, ${e.leftColor} 0%, ${e.leftColor} ${e.leftPercent}%, #FFFFFF ${e.leftPercent}%, #FFFFFF ${e.leftPercent+e.gap}%, ${e.rightColor} ${e.leftPercent+e.gap}%, ${e.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,F=v.qy`
    <div class="team-container">
        ${(0,w.z)((e,t)=>0!==t.index,v.qy`<div class="team-name">${e=>e.name}</div>`)}
        <img class="team-icon" src="${e=>e.imageUrl}" alt="${e=>e.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,w.z)((e,t)=>0===t.index,v.qy`<div class="team-name">${e=>e.name}</div>`)}
    </div>
`,S=v.qy`
    <div class="game-team-icons">
        ${(0,$.ux)(e=>e.viewModel.participants,F,{positioning:!0})}
    </div>
`,z=v.qy`
<div class="game-stats-title">${e=>e.viewModel.cardTitle}</div>
`,C=v.qy`
    <div class="${e=>e.viewModel.isFullCard?"full-card":""} ${e=>e.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,w.z)(e=>e.viewModel.isFullCard&&e.viewModel.participants,S)}
        ${(0,w.z)(e=>!e.viewModel.isFullCard&&"_2x_2y"!==e.viewModel.cardSize,z)}
        <div class="game-stats-list ${e=>"1.5u"===e.viewModel.cardSize?"_15u":e.viewModel.cardSize}">
            ${(0,$.ux)(e=>e.viewModel.sportsGameStats,k)}
        </div>
    </div>
`,_=v.qy`
    <div class="s-dvrg">
        <div class="dtitle">${e=>e.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,$.ux)(e=>e.viewModel.sportsGameStats,v.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${e=>e.leftText}
                </span>
                <span>
                    ${e=>e.key}
                </span>
                <span class="right">
                    ${e=>e.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${e=>e.leftColor||"#A71930"};
                                width: ${e=>e.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${e=>e.rightColor||"#036779"};
                                width: ${e=>e.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,T=v.qy`${e=>e.viewModel?.isCopilotTheme?_:C}`,j=v.qy`
    ${(0,w.z)(e=>null!=e.viewModel,T)}
`;let B=class extends n{};B=(0,a.Cg)([(0,l.E)({name:"sports-game-stats",template:j,styles:f,shadowOptions:{delegatesFocus:!0}})],B)},70846(e,t,i){i.r(t),i.d(t,{SportsPickWinnerWC(){return L}});var a=i(56911),r=i(23305),s=i(60815),o=i(66591),n=i(71372),l=i(48566);class p extends n.a{constructor(){super(...arguments),this.handleCommentsButtonClick=e=>{const t=e.target;t?.closest(".comments-button")&&this.viewModel.handleCommentsClick?.(e)},this.handlePollOptionOnClick=e=>{this.viewModel.userVote||(this.viewModel.recordUserVote(e),this.viewModel.userVote=e,this.handleVoteDataBuffer(e),s.cP.notify(this,"viewModel"))},this.handleVoteDataBuffer=e=>{if(""!==e){this.viewModel.teamsVoteData.forEach((t,i)=>this.viewModel.teamsVoteData[i]=t.id===e?{...t,voteCount:(t.voteCount||0)+1}:t);const t=(this.viewModel.teamsVoteData[0].voteCount||0)+(this.viewModel.teamsVoteData[1].voteCount||0);this.viewModel.teamsVoteData.forEach((e,i)=>this.viewModel.teamsVoteData[i].votePercentage=this.getTeamPercent(e.voteCount||0,t))}}}connected(){super.connected(),this.viewModel.userVote&&this.handleVoteDataBuffer(this.viewModel.userVote),this.shadowRoot?.addEventListener?.("click",this.handleCommentsButtonClick)}get isEntrypoint(){return Boolean(this.viewModel?.isEntrypoint)}disconnected(){this.shadowRoot?.removeEventListener?.("click",this.handleCommentsButtonClick)}getPollResultText(e){return this.viewModel.gameState===r.T0.Final?e?.hasWon?this.viewModel.strings.winnerText:"":(this.viewModel.disableVoting||this.viewModel.userVote)&&void 0!==e.votePercentage?`${e.votePercentage}%`:""}getComponentString(e){const{gameState:t,strings:i,isEntrypoint:a,totalVotesString:s}=this.viewModel;if(a)return e?i.pickWinner:s||"";let o="";this.viewModel.userVote?t===r.T0.PreGame||t===r.Xp.preGame?o=e?i.postselPrimary:i.postselSecondaryPre:t===r.T0.InProgress||t===r.Xp.inprogressGame?o=e?i.postselPrimary:i.postselSecondaryLive:t===r.T0.Final&&(o=this.viewModel.teamsVoteData.find(e=>e.id===this.viewModel.userVote)?.hasWon?e?i.postselPrimaryWon:i.postselSecondaryPost:e?i.postselPrimaryLost:i.postselSecondaryPost):t===r.T0.PreGame||t===r.Xp.preGame?o=e?i.preselPrimary:i.preselSecondary:t===r.T0.InProgress||t===r.Xp.inprogressGame?o=e?i.preselPrimaryLive:i.preselSecondaryLive:t===r.T0.Final&&(o=e?i.preselPrimaryLive:i.postselSecondaryPost);const n=this.viewModel.teamsVoteData.find(e=>e.id===this.viewModel.userVote)?.shortName;return o?.includes("{teamName}")&&(o=n?l.Qf.Format(o,{teamName:n}):""),o}getTeamPercent(e,t){return Math.round(e/t*100)||0}getCanUserVote(){return!this.viewModel.userVote&&!this.viewModel.disableVoting}getTeamName(e){return this.viewModel.isRuby&&e.name&&(3===this.viewModel.columnLayout||4===this.viewModel.columnLayout)?e.name:e.shortName||""}get teamButtonClassNames(){return(0,o.x)("pick-winner-option",["voted",!!this.viewModel.userVote],["disabled",!!this.viewModel.disableVoting],["entrypoint",!!this.viewModel.isEntrypoint])}getTeamButtonStyles(e){return!this.getCanUserVote()&&this.viewModel.isRuby&&e.teamColor?`background: ${e.teamColor}0D;`:""}getTeamButtonAriaLabel(e){const t=this.getTeamName(e),i=t&&this.viewModel.userVote===e.id?this.viewModel.strings.selectedText.replace("{0}",t||""):t;return this.getCanUserVote()||void 0===e.votePercentage?i:`${i} ${e.votePercentage}%`}get totalVotes(){return this.viewModel.teamsVoteData.reduce((e,t)=>e+(t.voteCount||0),0)}isTeamWinningPoll(e,t){return t.reduce((e,t)=>e.votePercentage&&t.votePercentage&&e.votePercentage>t.votePercentage?e:t).id===e}getTeamButtonPercentageBarClassNames(e){return(0,o.x)("option-item-bar",["selected",!!this.viewModel.userVote&&this.viewModel.userVote===e||!!this.viewModel.disableVoting&&this.isTeamWinningPoll(e,this.viewModel.teamsVoteData)])}getTeamButtonPercentageBarStyles(e){if(!this.getCanUserVote()&&void 0!==e.votePercentage){let t=`width: ${e.votePercentage}%;`;return this.viewModel.isRuby&&e.teamColor&&(t+=` background: ${e.teamColor}33`),t}return"width: 0%;"}getOptionItemContentClassNames(e){return(0,o.x)("option-item-content",["entrypoint",!!this.viewModel.isEntrypoint],["selected",this.viewModel.userVote===e])}}(0,a.Cg)([s.sH],p.prototype,"viewModel",void 0);var c=i(92011),d=i(49417),g=i(95403),h=i(83252),y=i(61138),m=i(71157),u=i(6032),b=i(24496),x=i(59669),f=i(22131),v=i(4126),w=i(70289),$=i(32257);const k=x.A` .pick-winner-option.entrypoint{background:#1F1F1F;border-color:#6D6D6D}.option-item-bar{background:#FFFFFF1A}.option-item-bar.selected{background:#243966}.cplt .pick-winner-option.entrypoint{background:#323F60A6;border:1px solid #FFFFFF1A}.cplt .pick-winner-option.entrypoint:has(.selected){border-color:#242C46}.cplt .option-item-bar,.cplt .option-item-bar.selected{background:#01682633}.pick-winner-secondary-text{color:#999999}.cplt .pick-winner-secondary-text{color:#E5EBFA}.option-item-result{color:#FFFFFF}.cplt .option-item-result{color:#E5EBFA}.pick-winner-option:not(.voted):not(.disabled):hover{background-color:#FFFFFF49}`,F=x.A` .pick-winner-container.cplt{border-top:0px;color:${$.C6c}}.pick-winner-primary-text{font-size:14px;line-height:20px;font-weight:550}.pick-winner-secondary-text{color:#707070;;font-size:${y.k};white-space:nowrap}.cplt .pick-winner-secondary-text{color:inherit}.cplt .option-item-image{height:24px;width:24px}.pick-winner-option.entrypoint{box-sizing:border-box;border-radius:100px;height:36px;background:#FAFAFA;border-color:#D1D1D1;padding:0px 2px}.cplt .pick-winner-option.entrypoint{border-radius:12px;height:40px;background:transparent;border-color:#0000001A}.pick-winner-options{gap:8px}.cplt .pick-winner-options{gap:6px}.pick-winner-text-container{flex-direction:row;justify-content:space-between;align-items:center;position:relative}.option-item-content{font-weight:450}.option-item-text{font-size:14px;line-height:20px;font-weight:600}.cplt .option-item-text{}.option-item-text-container{align-items:center;gap:8px}.option-item-bar{background:#EEEEEE}.option-item-bar.selected{background:#E0EDFF}.cplt .option-item-bar.selected{background:#97DFA133}.cplt .option-item-bar,.cplt .option-item-bar.selected{background:#97DFA133}.option-item-result{align-self:center;font-size:14px;line-height:20px;font-weight:600}.cplt .option-item-result{color:#4C4642;font-weight:450}.pick-winner-container{padding-top:20px}.cplt.pick-winner-container{padding-top:36px}._1x_3y.pick-winner-container{padding-top:86px}`.withBehaviors((0,f.G2)(k)),S=x.A` .option-item-bar{background:var(--color-neutral-stroke-2,#EEEEEE)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#E0EDFF)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#D1D1D1)}`,z=x.A` .option-item-bar{background:var(--color-neutral-stroke-2,#3D3D3D)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#243966)}.like-icon{filter:invert(1)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#666666)}`,C=x.A` .pick-winner-container{border-top:1px solid ${d.hb};padding:8px 0;gap:8px;display:grid}.pick-winner-container.ruby{border:none;gap:16px;padding:0}.pick-winner-options{padding:unset;display:grid;gap:6px;margin-top:unset;margin-bottom:4px}.ruby .pick-winner-options{margin:unset;gap:16px}.pick-winner-option{all:unset;${w.f} display:flex;height:36px;align-items:center;border-radius:100px;overflow:hidden;background:${g.Wl}}.pick-winner-option:focus-visible{outline:-webkit-focus-ring-color auto 1px;outline-offset:2px}.ruby .pick-winner-option{height:56px;border:none}.pick-winner-option:not(.voted):not(.disabled):hover{cursor:pointer;background-color:${h.Xt}}.pick-winner-option.entrypoint{height:30px}.option-item-content{display:flex;justify-content:space-between;width:100%;position:relative;font-weight:600;padding:0 10px;font-size:14px}.ruby .option-item-content{padding:0 16px;align-items:center}.option-item-bar{position:absolute;height:100%;left:0;width:0%;transition:width 0.5s ease-in-out}.option-item-text-container{display:flex;gap:6px}.ruby .option-item-text-container{gap:12px;align-items:center}.option-item-text{-webkit-line-clamp:1;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all}.option-item-content.entrypoint:not(.selected){font-weight:400}.option-item-image{width:auto;height:24px}.ruby .option-item-image{height:40px}.like-button-container{align-items:center;display:flex}.pick-winner-text-container{display:flex;flex-direction:column;gap:2px}.pick-winner-primary-text{font-size:${y.k};font-weight:600}.ruby .pick-winner-primary-text,.ruby .option-item-text,.ruby .option-item-result{font-weight:550;font-size:18px;line-height:${m.O}}.ruby .option-item-result{display:flex;gap:4px}.pick-winner-secondary-text{font-size:${y.k};color:${u.c}}.comments-button{all:unset;font-size:inherit;${w.f} color:${b.W_};text-decoration:underline;cursor:pointer}.comments-button:hover{color:${b.YL}}.comments-button:focus-visible{outline:-webkit-focus-ring-color auto 1px}.ruby .like-icon{height:24px}`.withBehaviors((0,f.C7)(S),(0,f.G2)(z),new v.o("isEntrypoint",!0,F));var _=i(89757),T=i(69259),j=i(93809),B=i(68835),A=i(33744),D=i(30876);const P=`${(0,A.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_regular.svg`,E=`${(0,A.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_filled.svg`,O=e=>_.qy`
    <div class="like-button-container">
        <img class="like-icon" src="${t=>e?E:P}" alt="" />
    </div>
`,M=_.qy`
    <div class="option-item-result">
        ${(e,t)=>t.parent.getPollResultText(e)}
        ${(0,T.z)((e,t)=>t.parent.viewModel.isRuby&&!t.parent.viewModel.isEntrypoint&&t.parent.viewModel.gameState!==r.T0.Final,_.qy`
            ${(e,t)=>O(t.parent.viewModel.userVote===e.id)}
        `)}
    </div>
`,G=_.qy`
    <button
        type="button"
        id=${e=>e.id}
        class=${(e,t)=>t.parent.teamButtonClassNames}
        @click=${(e,t)=>t.parent.getCanUserVote()&&t.parent.handlePollOptionOnClick?.(e.id)}
        data-t=${(e,t)=>t.parent.getCanUserVote()?t.parent.viewModel.telemetryContext?.voteButtonTag:null}
        style=${(e,t)=>t.parent.getTeamButtonStyles(e)}
        aria-label=${(e,t)=>t.parent.getTeamButtonAriaLabel(e)}
    >
        <div
            class=${(e,t)=>t.parent.getTeamButtonPercentageBarClassNames(e.id)}
            style=${(e,t)=>t.parent.getTeamButtonPercentageBarStyles(e)}
        ></div>
        <div class=${(e,t)=>t.parent.getOptionItemContentClassNames(e.id)}>
            <div class="option-item-text-container">
                ${(0,T.z)(e=>!!e.imageUrl,_.qy`
                    <img class="option-item-image" alt="" src=${e=>e.imageUrl} />
                `)}
                <span class="option-item-text" aria-hidden="true">${(e,t)=>t.parent.getTeamName(e)}</span>
                ${(0,T.z)((e,t)=>!t.parent.viewModel.isRuby&&!t.parent.viewModel.disableVoting&&!t.parent.viewModel.isEntrypoint&&t.parent.viewModel.userVote===e.id,_.qy`
                    ${(e,t)=>O(t.parent.viewModel.userVote===e.id)}
                `)}
            </div>
            ${(0,T.z)((e,t)=>!t.parent.getCanUserVote(),M,_.qy`
                ${(0,T.z)((e,t)=>!t.parent.viewModel.isRuby&&!t.parent.viewModel.isEntrypoint,_.qy`
                    ${(e,t)=>O(t.parent.viewModel.userVote===e.id)}
                `)}
            `)}
        </div>
    </button>
`,I=_.qy`
    <div
        class="pick-winner-container ${e=>e.viewModel.isRuby?"ruby":""} ${e=>e.viewModel.cardSize||""} ${e=>e.viewModel.isCopilotTheme?"cplt":""}"
        data-t=${e=>e.viewModel.telemetryContext?.rootTag}
    >
        <div class="pick-winner-text-container">
            ${(0,T.z)(e=>!!e.getComponentString(!0),_.qy`
                <div class="pick-winner-primary-text">
                    ${e=>e.getComponentString(!0)}
                </div>
            `)}
            ${(0,T.z)(e=>!!e.getComponentString(!1),_.qy`
                <div
                    class="pick-winner-secondary-text"
                    role="status"
                    :innerHTML=${(0,j.U)(e=>e.getComponentString(!1),D.r)}
                ></div>
            `)}
        </div>
        <div class="pick-winner-options">
            ${(0,B.ux)(e=>e.viewModel.teamsVoteData,_.qy`
                ${G}
            `,{positioning:!0})}
        </div>
    </div>
`,N=_.qy`
    ${(0,T.z)(e=>!!e.viewModel,I)}
`;let L=class extends p{};L=(0,a.Cg)([(0,c.E)({name:"sports-pick-winner-wc",template:N,styles:C,shadowOptions:{delegatesFocus:!0}})],L)},811(e,t,i){i.r(t),i.d(t,{SportsPlayerEvent(){return f}});var a=i(56911),r=i(92011),s=i(32257),o=i(25975),n=i(59669),l=i(63033);const p=n.A` :host{--player-bg:#0000004D;--fallback-bg:#292929;--cplit-img-bg:#9DA8D91A;--cplt-player-bg:#9DA8D90D}.cplt .role,.cplt .time-label{color:${s.C6c}}`,c=n.A` :host{--player-bg:#FFFFFFB2;--cplt-player-bg:#CCC4C033;--cplit-img-bg:#FFFFFFCC;--fallback-bg:#EBEBEB;--player-icon-size:80px;container-type:inline-size}.trunc{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.wrap{position:relative}.title{font-size:${s.e1r};line-height:${s.HoW};text-align:center;margin:10px;font-weight:600}.content{display:flex;flex-direction:row;align-items:center;gap:16px;padding:10px;background:var(--player-bg);border-radius:6px;height:100px;box-sizing:border-box}.player-image-wrap{flex-shrink:0;width:var(--player-icon-size);height:var(--player-icon-size);border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;border:1px solid #0000000F;box-shadow:0px 2px 4px 0px #0000000A}.player-image-wrap.fallback{background:var(--fallback-bg);border:none;font-size:${s.bPr};line-height:${s.cZi};font-weight:600}.fallback-text{height:35px}.player-img{width:var(--player-icon-size);height:var(--player-icon-size);object-fit:cover}.fallback-wrap,.fallback-icon{width:40px;height:40px}.player-info{display:flex;flex-direction:column;gap:2px;overflow:hidden}.player-name{font-size:14px;font-weight:600;line-height:20px}.player-meta{display:flex;align-items:center;gap:4px;margin-bottom:8px}.team-flag{width:16px;height:16px;flex-shrink:0}.role{font-size:${s.CuR};line-height:${s.$LU}}.time-row{display:flex;align-items:center;gap:8px;font-size:${s.e1r};line-height:${s.HoW}}.time-value{font-weight:600}._1x_3y{.content{height:250px;flex-direction:column;gap:12px;justify-content:center}.player-info{align-items:center;max-width:100%}.player-name{max-width:100%}}.cplt{.title{text-align:unset;margin:14px 0px 12px;font-weight:${o.IH6}}.content{height:104px;background:var(--cplt-player-bg);border-radius:12px;padding:12px}.player-image-wrap{border:none;box-shadow:none;background:var(--cplit-img-bg);font-weight:450}}.cplt .role,.cplt .time-label{color:${o.Adh}}@container (width < 240px){.cplt{--player-icon-size:60px}}`.withBehaviors(new l.N(null,p));var d=i(89757),g=i(69259);const h=d.qy`
    <div class="player-image-wrap">
        <img
            class="player-img"
            src="${e=>e.viewModel.imageUrl}"
            alt="${e=>e.event.shortName}"
        />
    </div>
`,y=d.qy`
    <div class="player-image-wrap fallback">
        <div class="fallback-text">
            ${e=>e.viewModel.fallbackIconText}
        </div>
    </div>
`,m=d.qy`
    <div class="wrap ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isCopilotTheme?"cplt":""}">
        <div class="title trunc" title="${e=>e.event.title}">
            ${e=>e.event.title}
        </div>
        <div class="content">
            ${(0,g.z)(e=>!!e.viewModel.imageUrl,h,y)}
            <div class="player-info">
                <div class="player-name trunc" title="${e=>e.event.shortName}">
                    ${e=>e.event.shortName}
                </div>
                <div class="player-meta">
                    ${(0,g.z)(e=>!!e.viewModel.teamImageUrl,d.qy`
                        <img
                            class="team-flag"
                            src="${e=>e.viewModel.teamImageUrl}"
                            alt=""
                            role=""
                        />
                    `)}
                    <span class="role trunc">
                        ${e=>e.event.role.title} #${e=>e.event.role.number}
                    </span>
                </div>
                <div class="time-row trunc">
                    <span class="time-label">${e=>e.event.eventTimeLabel}</span>
                    <span class="time-value">${e=>e.event.eventTime}</span>
                </div>
            </div>
        </div>
    </div>
`,u=d.qy`
    ${(0,g.z)(e=>null!=e.viewModel,m)}
`;var b=i(71372);class x extends b.a{get event(){return this.viewModel.playerEvent}}let f=class extends x{};f=(0,a.Cg)([(0,r.E)({name:"sports-player-event",template:u,styles:c})],f)},94138(e,t,i){i.r(t),i.d(t,{SportsSpotlight(){return N}});var a=i(56911),r=i(20517),s=i(83546),o=i(60815);class n extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,s.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,a.Cg)([o.sH],n.prototype,"isMitUx",void 0);var l=i(92011),p=i(86856),c=i(59669),d=i(4126),g=i(22131),h=i(47810),y=i(63033),m=i(70289);const u=c.A` @container (min-width:180px) and (max-width:273px){.cop-video{.match-wrap{padding:40px 0 0px}}}`,b=c.A` .spotlight-video-tagtitle{right:16px}._1x_3y.spotlight-video-img{margin-right:-50%}`,x=c.A` .cop-video{.spotlight-video-tagtitle{background:var(--status-informative-tint-background,#1F2431);color:#FFFFFF}}`,f=c.A` ._1x_3y.spotlight-video{margin-top:12px}._1x_2y.spotlight-video{height:150px}._1x_3y.spotlight-video{height:296px}._1x_2y.spotlight-video .spotlight-video-tagtitle,._1x_3y.spotlight-video .spotlight-video-tagtitle{inset-inline-start:8px;top:8px;backdrop-filter:blur(25px);padding:1px 8px 3px}._1x_2y.spotlight-video .spotlight-video-title,._1x_3y.spotlight-video .spotlight-video-title{inset-inline-start:8px;bottom:4px;height:52px;font-weight:550;line-height:26px;max-width:252px}._1x_2y.spotlight-video .spotlight-video-icon{top:48px;transform:translateX(-50%)}._1x_2y.spotlight-video .spotlight-video-icon img{width:32px;height:32px}`,v=c.A` .spotlight-video{display:block;position:relative;margin-top:8px;border-radius:8px;overflow:hidden;z-index:1}._1x_1y.spotlight-video{height:56px;width:56px;margin-top:0px}._1x_3y.spotlight-video{height:308px}.spotlight-video-img{max-width:100%;object-fit:scale-down;overflow:hidden;border-radius:8px;display:block}._1x_1y.spotlight-video-img{width:100%;height:100%;object-fit:cover}._1x_3y.spotlight-video-img{max-height:100%;max-width:none;margin-left:-50%}.spotlight-video-tagtitle{position:absolute;left:16px;top:9px;width:fit-content;height:16px;line-height:16px;border-radius:6px;border:1px solid rgba(255,255,255,0.20);background:rgba(255,255,255,0.10);backdrop-filter:blur(12.5px);padding:0 8px;font-weight:400;font-size:12px;color:#FFFFFF}.spotlight-video-title{position:absolute;left:16px;bottom:16px;height:44px;line-height:22px;font-weight:600;font-size:16px;color:#FFFFFF;display:-webkit-box;max-width:236px;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;white-space:normal}.spotlight-video-icon{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}._1x_1y.spotlight-video-icon > img{width:24px;height:24px}.spotlight-video-overlay{position:absolute;width:100%;height:100%;left:0;bottom:0;transition:background 0.1s;background-image:linear-gradient(180deg,rgba(0,0,0,0.00) 0,rgba(0,0,0,0.50) 59px,rgba(0,0,0,0.50) 100%)}.spotlight-fre-container{position:relative;z-index:var(--click-z-index);margin-bottom:16px;display:flex;flex-direction:row;align-items:start;max-width:fit-content}.spotlight-video-overlay:hover{background:rgba(0,0,0,0.25)}.spotlight-fre-text{overflow:hidden;white-space:nowrap;color:${h.l};text-decoration:none;padding-right:6px}._1x_1y.spotlight-fre-text{width:206px}.fre-header{font-weight:600;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-header{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);margin-bottom:4px}.fre-content{font-weight:400;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-content{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);white-space:normal;max-height:32px;-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}.v2cntr{width:100%;height:266px;display:flex;flex-direction:column;gap:16px;margin-top:12px;sports-game-stats{margin-top:5px}}.cop-video{container-type:inline-size;.vidv3{height:196px;width:100%;display:block;position:relative;overflow:hidden;border-radius:var(--cstm-corner-media-in-card);corner-shape:squircle}.vidv3:focus-visible{outline-offset:-1px}.thumbnail{height:196px;width:100%;object-fit:cover;transition:transform 0.4s ease-out}.vidv3:hover .thumbnail{transform:scale(1.05)}.play-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px}.match-wrap{padding:40px 20px 0px}.spotlight-video-tagtitle{height:var(--ctrl-badge-size,24px);line-height:var(--ctrl-badge-size,24px);border-radius:var(--ctrl-badge-corner,8px);padding:0 var(--ctrl-badge-padding,6px);left:20px;top:20px;background:var(--status-informative-tint-background,#EFEAE7);color:#1F2431;border:none;backdrop-filter:none}}.wrap{text-decoration:none;color:inherit;${m.f}}.v2cntr:has(sports-pick-winner-wc),.v2cntr:has(sports-player-event){margin-top:30px}`.withBehaviors(new p.t(null,b),new y.N(null,x),new d.o("isAdaptiveThemeEnabled",!0,u),new d.o("isMitUx",!0,f),(0,g.mr)(c.A` :host{forced-color-adjust:auto}`));var w=i(89757),$=i(68835),k=i(69259),F=i(33744);const S=`${(0,F.rA)().StaticsUrl}latest/icons-wc/icons/PlayIconLarge.svg`,z=`${(0,F.rA)().StaticsUrl}latest/sports/icons/PlayIconCopilot.svg`,C=w.qy`
    <div>
        ${(0,$.ux)(e=>e.viewModel.matches,w.qy`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,_=w.qy`
    ${(0,k.z)(e=>null!=e.viewModel.headerData,w.qy`
        <div class="spotlight-fre-container">
            <a class="spotlight-fre-text ${e=>e.viewModel.cardSize}"
                data-t="${e=>e.viewModel.spotsVideoTelemetry}"
                href="${e=>e.viewModel.headerData?.clickThroughUrl}"
                target="_blank"
            >
                <div class="fre-header" title="${e=>e.viewModel.headerData?.headerTextLine1}">
                    ${e=>e.viewModel.headerData?.headerTextLine1}
                </div>
                <div class="fre-content" title="${e=>e.viewModel.headerData?.headerTextLine2}">
                    ${e=>e.viewModel.headerData?.headerTextLine2}
                </div>
            </a>
            ${(0,k.z)(e=>"_1x_1y"===e.viewModel.cardSize&&e.viewModel.sportsVideo?.msnVideoEmbedLink,w.qy`
                <a
                    class="spotlight-video ${e=>e.viewModel.cardSize}"
                    data-t="${e=>e.viewModel.spotsVideoTelemetry}"
                    href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
                    target="_blank"
                >
                    <img
                        class="spotlight-video-img ${e=>e.viewModel.cardSize}"
                        role="presentation"
                        src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
                    />
                    <div class="spotlight-video-overlay">
                        <div class="spotlight-video-icon ${e=>e.viewModel.cardSize}">
                            <img role="presentation" src=${S} alt="" />
                        </div>
                    </div>
                </a>
            `)}
        </div>
    `)}
`,T=w.qy`
    <sports-game-stats
        :viewModel="${e=>e.viewModel.sportsGameStatsCard?.viewModel}"
    >
    </sports-game-stats>
`,j=w.qy`
    <sports-game-leaders
        :viewModel="${e=>e.viewModel.sportsGameLeadersCard?.viewModel}"
    >
    </sports-game-leaders>
`,B=w.qy`
    <sports-player-event
        :viewModel="${e=>e.viewModel.sportsPlayerEventCard}"
    ></sports-player-event>
`,A=w.qy`
    <sports-pick-winner-wc
        :viewModel="${e=>e.viewModel.sportsPickWinnerCard?.viewModel}"
    >
    </sports-pick-winner-wc>
`,D=w.qy`
    <div class="spotlight-video-tagtitle">
        ${e=>e.viewModel.sportsVideo?.videoTagTitle}
    </div>
`,P=w.qy`
    ${(0,k.z)(e=>"_1x_1y"!==e.viewModel.cardSize,w.qy`
        <a
            class="spotlight-video ${e=>e.viewModel.cardSize}"
            data-t="${e=>e.viewModel.spotsVideoTelemetry}"
            href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
            target="_blank"
        >
            <img
                class="spotlight-video-img ${e=>e.viewModel.cardSize}"
                role="presentation"
                src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
            />
            <div class="spotlight-video-overlay">
                ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.videoTagTitle,D)}
                <div class="spotlight-video-title" title="${e=>e.viewModel.sportsVideo?.videoTitle||""}">
                    ${e=>e.viewModel.sportsVideo?.videoTitle||""}
                </div>
                <div class="spotlight-video-icon">
                    <img role="presentation" src=${S} alt="" />
                </div>
            </div>
        </a>
    `)}
`,E=w.qy`
    ${(0,k.z)(e=>e.viewModel.sportsGameStatsCard?.viewModel?.isFullCard,T,w.qy`
        ${(0,k.z)(e=>e.viewModel.matches.length,C,_)}
        ${(0,k.z)(e=>null!=e.viewModel.sportsPlayerEventCard,B)}
        ${(0,k.z)(e=>null!=e.viewModel.sportsPickWinnerCard,A)}
        ${(0,k.z)(e=>null!=e.viewModel.sportsGameStatsCard,T)}
        ${(0,k.z)(e=>null!=e.viewModel.sportsVideo,P)}
    `)}
`,O=w.qy`
    <a
        class="wrap"
        data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.tabClickThroughUrl}"
        target="_blank"
    >
        <div class="v2cntr">
            ${(0,k.z)(e=>e.viewModel.matches.length,C,_)}
            ${(0,k.z)(e=>null!=e.viewModel.sportsPlayerEventCard,B)}
            ${(0,k.z)(e=>e.viewModel.sportsGameStatsCard,T)}
            ${(0,k.z)(e=>e.viewModel.sportsPickWinnerCard,A)}
        </div>
    </a>
`,M=w.qy`
    <a
        class="vidv3"
        data-t="${e=>e.viewModel.spotsVideoTelemetry}"
        href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
        target="_blank"
    >
        <img
            class="thumbnail"
            role="presentation"
            src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
        />
        ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.videoTagTitle,D)}
        <img role="presentation" src=${z} alt="" class="play-icon"/>
    </a>
`,G=w.qy`
    <div class="cop-video">
        ${M}
        <div class="match-wrap">
            ${C}
        </div>
    </div>
`,I=w.qy`
    ${(0,k.z)(e=>null!=e.viewModel,w.qy`${e=>{return(t=e.viewModel).sportsGameLeadersCard?j:t.isCopilotTheme&&t.sportsVideo?G:t.isCopilotTheme?O:E;var t}}`)}
`;let N=class extends n{};N=(0,a.Cg)([(0,l.E)({name:"sports-spotlight",template:I,styles:v,shadowOptions:{delegatesFocus:!0}})],N)},63129(e,t,i){i.d(t,{ls(){return u},p4(){return m},vA(){return y},nF(){return h}});var a=i(97747),r=i(68009),s=i(95239);const{create:o}=a.G,n=o("neutral-stroke-strong-hover-delta",40),l=o("neutral-stroke-strong-active-delta",16),p=o("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:d}=a.G,g=d({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,a,s,o){const n=(0,r.F)(t),l=e.colorContrast(t,i),p=e.closestIndexOf(l);return{rest:l,hover:e.get(p+n*a),active:e.get(p+n*s),focus:e.get(p+n*o)}}(e(c.r),e(s.p),3,e(n),e(l),e(p))}}),h=d("neutral-stroke-strong-rest",e=>e(g).evaluate(e).rest),y=d("neutral-stroke-strong-hover",e=>e(g).evaluate(e).hover),m=d("neutral-stroke-strong-active",e=>e(g).evaluate(e).active),u=d("neutral-stroke-strong-focus",e=>e(g).evaluate(e).focus)},30876(e,t,i){i.d(t,{r(){return s}});var a=i(7686),r=i(42277);const s=i(68244).F.create({trustedType:{createHTML:e=>a.A.sanitize(e,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[r.D.property]:{innerHTML:(e,t,i,r)=>(e,t,i,...s)=>{const o=a.A.sanitize(i,{RETURN_TRUSTED_TYPE:!0});r(e,t,o,...s)}}}}})}}]);