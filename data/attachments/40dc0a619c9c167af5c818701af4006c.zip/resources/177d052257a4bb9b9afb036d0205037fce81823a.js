"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-cricket"],{79811(t,e,i){i.d(e,{AL(){return ct},B5(){return ut},CP(){return K},EZ(){return lt},F_(){return U},HX(){return k},Hn(){return J},Hv(){return P},IR(){return Q},K4(){return et},Lw(){return W},Ot(){return ot},PH(){return mt},UU(){return y},VQ(){return A},VY(){return Y},Yf(){return F},Yo(){return tt},ZL(){return w},Zi(){return b},_K(){return I},_S(){return St},bm(){return L},bw(){return O},d(){return ft},d$(){return $},gK(){return yt},gS(){return pt},iK(){return nt},jJ(){return it},ju(){return B},lb(){return N},m5(){return gt},nD(){return vt},or(){return G},p6(){return V},qM(){return H},ry(){return dt},s$(){return rt},sP(){return q},wB(){return R},ww(){return X},yl(){return j},yn(){return ht},z2(){return E},zy(){return xt}});var r=i(23305),s=i(54694),a=i(33335),n=i(87906),o=i(24656),l=i(33744),p=i(25066),c=i(58319),d=i(53128),h=i(18633),g=i(67072),u=i(70535),m=i(50180),v=i(9960),x=i(72627),f=i(83991),S=i(10279);const y="OSC.LBUDD745586EC750353FBC1F3971212F2F92540502D2A29306D4081FAD3D5858B79B",b="#A71930",w="#036779",$="#B10E1C",k="#DC626D",T="sportshero",C="sportsspotlight2",M=[r.v1.TeamVsTeamExploration,r.v1.CricketExploration,r.v1.TennisExploration],F=t=>{if(t){return _(t)}return""},_=t=>t?(D(t)?t+="&h=50&w=50&m=6&q=100&u=t&o=t&l=f&f=png":t.indexOf("//www.bing.com/th?")>=0&&t.indexOf("&w=")>0&&(t=t.split("&w=")[0]+"&w=100&h=100&qlt=100&c=0&rs=1"),t):t,D=t=>["//img-s-msn-com.akamaized.net/tenant/amp/entityid","//img-s.msn.cn/tenant/amp/entityid"].some(e=>t.indexOf(e)>=0);function E(t){return null!=t}const z=t=>!t||!t.trim(),P=t=>I(t,80,80,!0),I=(t="",e=40,i=40,r=!1)=>t?t.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${r?i+20:i}&h=${r?e+20:e}`):null,R=t=>t.get(r.kA.sportsData),H=t=>{const e=O(t);return h.aC.safeExecute(()=>e.tabContent?.league?.sportsMatches?.map(t=>({sportsMatchData:t}))||[],void 0,a.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(e.tabContent?.league?.sportsMatches)}; tabType=${e.tabType};`)},B=t=>{const e=O(t);return e.tabContent?.freTeams?.map(t=>({...t,id:t.id||t.satoriId}))},L=t=>O(t).reason||"-1",V=t=>{const e=O(t);return e.tabContent?.sportsSpotLightData},j=t=>t.get(r.kA.pollOptionId),O=t=>{const e=R(t),i=q(t)-1;return e.Model?.Tabs[i]},A=t=>Boolean(t)&&M.includes(t),N=t=>t===r.v1.Fre,U=t=>t===r.v1.SpotlightFRE,G=t=>t===r.v1.StandingsRankings,W=(t,e)=>{const i=t.get(r.kA.dislikedEntities);return i?.has(e)},q=t=>t.get(r.kA.tabCurrentPageIndex)||1,X=t=>{const e=O(t);return e?Z(e.tabType):r.v1.TeamVsTeam},Z=t=>{switch(t){case r.v1.TeamVsTeamExploration:case r.v1.CricketExploration:case r.v1.TennisExploration:case r.v1.EventBrief:case r.v1.TeamVsTeamWithBracket:case r.v1.SpotlightTennis:case r.v1.SpotlightRace:case r.v1.SpotlightGolf:case r.v1.SpotlightFRE:case r.v1.StandingsRankings:case r.v1.SportsMedal:case r.v1.LeagueEventResultOneVsOne:case r.v1.LeagueEventResultOneVsMany:case r.v1.LeagueEventResultTeamVsTeam:case r.v1.LeagueEvents:case r.v1.TeamStandingWithEvents:case r.v1.TeamStandingWithMedals:case r.v1.SpotlightCricket:case r.v1.TournamentsList:case r.v1.Spotlight2c:return t;case r.v1.SeasonStatistics:case r.v1.Video:case r.v1.Countdown:case r.v1.Spotlight:return r.v1.Spotlight;default:return r.v1.TeamVsTeam}};function J(t){return"boolean"==typeof t?t:!!t&&("1"===t||"true"===t.toLowerCase())}function K(t){switch(t){case g.uE._1x_1y:return"small";case g.uE._1x_3y:return"large";default:return"medium"}}const Y=(t,e)=>void 0!==t&&void 0!==e&&(e.get(t)||!1),Q=(t,e,i)=>{switch(t){case g.uE._15u:case g.uE._1x_2y:return 3;case g.uE._1x_3y:return e===r.aB.Cricket?4:i;default:return 1}},tt=t=>t.some(t=>t&&t.sportsMatchData&&t.sportsMatchData.gameStateCatetory===r.Xp.inprogressGame),et=(t,e,i,r)=>{const s=r;return s&&s[i]&&s[i][e.toString()]?(0,m.GP)((t=>{let e=146;return t===g.uE._1x_2y?e=304:t===g.uE._1x_3y&&(e=462),`https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w=300&h=${e}&q=90&m=6&f=jpg&u=t`})(i),s[i][e.toString()]):null},it=()=>l.T3.AppType===f.u.BingHomepage?S.y.appInDarkMode():o.F_?.get(o.nz.IsDarkMode)??(0,v.ud)(),rt=(t,e,i,s)=>{const a=+t;if(!s||Number.isNaN(a)||a<0)return"";if(1===a)return i===r.XR.League?e.followedReasonLeague:e.followedReasonTeam;const n=r.IG[t];return n&&e[n]||""},st="BB1dV8FG",at="MSports";function nt(t,e=!1,i){const r={format:s.f5.PNG,enableDpiScaling:!1,crop:0,...i};return z(t)?e?(0,s.XP)(st,r):null:t.indexOf(".")>0?(0,s.oQ)(`${s.Ro}?id=${t}&pid=${at}`,r):(0,s.XP)(t,r)}function ot(t){if(t?.startsWith("http"))return t;if(!t)return"";const e=(0,p.g2)((0,c.t7)(t));return(0,d.oh)()?function(t){if(!t)return t;try{const e=new URL((0,x.$N)()),i=new URL(t),r=e.searchParams.getAll("item").find(t=>t.startsWith("flights:"));return r&&i.searchParams.append("item",r),i.href}catch{return t}}(e):e}function lt(t,e){if(!t||!e)return t;try{const i=new URL(t),r=i.searchParams;return Object.keys(e).forEach(t=>{t&&e[t]&&r.set(t,e[t])}),i.toString()}catch{return t}}function pt(t){return t&&!t.startsWith("#")?`#${t}`:t}function ct(t,e){const i=new u.e;try{return i.localizedMonthDate(t,e)}catch(i){(0,n.vV)(a.Gu,"Sports card localizedMonthDate exception.",`date=${t} market=${e} error=${i&&i.message}`);let r=t.toLocaleDateString("en-us",{month:"short",day:"numeric"});return r||(r=t.toDateString()),r?r.replace(/\u200E/g,"").replace(/\u200F/g,""):r}}function dt(t,e){const i=new u.e;try{return i.formatTimeFromDate(t,e)}catch(i){return(0,n.vV)(a.Gu,"Sports card formatTimeFromDate exception.",`date=${t} market=${e} error=${i&&i.message}`),t.toTimeString()}}function ht(t){const e=60*(new Date).getTimezoneOffset()*1e3,i=new Date(t).valueOf();return new Date(i-e)}function gt(t){switch(t){case"PreGame":default:return r.Xp.preGame;case"InProgressGame":case"InProgress":return r.Xp.inprogressGame;case"Final":case"PostGame":return r.Xp.postGame}}function ut(t){return"string"!=typeof t.gameState?gt(t.gameState?.state):t.gameStateCatetory}function mt(t){if(!t||"string"==typeof t)return"";const{gamePeriod:e,gameClock:i}=t;return e&&i?`${e} ${i}`:e||i||""}function vt(t){return!t||"object"==typeof t&&0===Object.keys(t).length}function xt(t){return t.get(r.kA.cardType)?.toLowerCase().startsWith(T)||!1}function ft(t){return t.get(r.kA.cardType)?.toLowerCase().startsWith(C)||!1}function St(t,e){if(t.id&&e){const i=new URL(e);i.searchParams.append("videoId",t.id),e=i.toString()}return e}function yt(t,e){return!t.hasExplicitInterest||e?.has(t.satoriId)||e?.has(t.yId)?!0===e?.get(t.satoriId||"")||!0===e?.get(t.yId||""):(e?.set(t.satoriId,!0),!0)}},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},83991(t,e,i){var r,s;i.d(e,{u(){return r}}),function(t){t.BingHomepage="bingHomepage",t.ChannelMobile="channelmobile",t.Community="community",t.ContentTools="contentTools",t.EdgeChromium="edgeChromium",t.EdgeMobile="edgeMobile",t.Finance="finance",t.Gaming="gaming",t.CGHomePage="cgHomePage",t.HomePage="homePage",t.Hub="hub",t.KnowledgeAgents="knowledgeAgents",t.Office="office",t.Personalize="personalize",t.msn="msn",t.MSNStudio="msnStudio",t.SharedWidgets="sharedWidgets",t.SuperApp="superApp",t.Shopping="shopping",t.Sports="sports",t.Distribution="distribution",t.UGC="ugc",t.Views="views",t.Weather="weather",t.WeatherWidgets="weatherWidgets",t.WeatherLocal="weatherLocal",t.WindowsNewsPlus="windowsNewsPlus",t.WindowsNewsWidgets="winWidgets",t.WindowsShell="windowsShell",t.WindowsShellV2="windowsShellV2",t.WebWidgets="webWidgets"}(r||(r={})),function(t){t.Default="Default",t.WinDashboard="WinDashboard",t.Edge="Edge"}(s||(s={}))},83546(t,e,i){i.d(e,{h(){return s}});var r=i(53128);function s(){return(0,r.oh)()}},67072(t,e,i){var r,s;i.d(e,{_n(){return a},GH(){return l},CE(){return o},iD(){return n},uE(){return r}}),(s=r||(r={}))._1x_1y="_1x_1y",s._1x_2y="_1x_2y",s._1x_3y="_1x_3y",s._1x_4y="_1x_4y",s._1x_5y="_1x_5y",s._2x_1y="_2x_1y",s._2x_2y="_2x_2y",s._2x_3y="_2x_3y",s._2x_4y="_2x_4y",s._2x_6y="_2x_6y",s._3x_1y="_3x_1y",s._3x_2y="_3x_2y",s._4x_1y="_4x_1y",s._4x_2y="_4x_2y",s._5x_1y="_5x_1y",s._5x_2y="_5x_2y",s._125u="1.25u",s._15u="1.5u",s._05u="0.5u",s._2c="2c",s.pill="pill";const a={DefaultRecommendation:"default-recommendation",DefaultNotification:"default-notification",ExplorationTab:"exploration-tab",ExplorationReco:"exploration-recommendation"},n={dropdownHistory:"dropdownHistory",dismissHistory:"dismissHistory",suppressHistory:"suppressHistory"};function o(t,e){return 0!==t&&["_1x_3y","_1x_1y"].includes(e)&&304===t}class l{constructor(t){this.transformerProvider=t}}},18633(t,e,i){i.d(e,{Ai(){return p},dI(){return d},j8(){return g},ao(){return u},iJ(){return m},LE(){return h},Eh(){return c},x1(){return n},YJ(){return a},h9(){return v},aC(){return x}});var r=i(98378),s=i(12360);const a={Customize:r.MS.Customize,Paginate:r.MS.Paginate,Hide:r.MS.Hide,Cancel:r.MS.Cancel,Close:r.MS.Close,Dislike:r.MS.Dislike,Show:r.MS.Show,Click:r.MS.Click};class n{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,i,a){if(!t||!e)return;const{name:n,content:o,...l}=e,p={...o,type:o?.type||r.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},c={...this.ext,signature:i};a&&(c.previewType=a);const d={...l,ext:c,zone:this.zone};return(0,s.g)(n,p,d)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:r.EG.View,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Add,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Hover,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.MouseLeave,behavior:r.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(t,e,i){const s=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i?r.MS.Follow:r.MS.Unfollow,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(s)}createMenuDataProviderTelemetryTag(t,e,i){const s=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Undefined,type:r.MJ.ActionButton,content:{headline:e.headline},zone:i},e.signature,e.previewType);return this.createTelemetryObjectTag(s)}createNavClickWithTypeTelemetryTag(t,e,i){const s=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,type:i,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||r.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(s)}createBehaviorTelemetryTag(t,e,i){const s=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(s)}createBaseContentCardTelemetryContext(t,e){const i=this.createTelemetryObject(t,{name:e.name,type:r.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),s=this.createTelemetryObject(i,{name:e.name,type:r.MJ.Headline,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(i&&s)return{contentCard:i,destination:s}}initTelemetryBuilder(t,e,i,r,s){this.verticalName=t,this.categoryName=e,this.ext=i,this.zone=r,this.subCategoryName=s}updateExt(t){this.ext=t}}var o=i(7446),l=i(20421);function p(t){try{o.YT.sendActionEvent(t,r.EG.MouseLeave,r.MS.Close)}catch(t){return}}function c(t){try{o.YT.sendActionEvent(t,r.EG.Hover,r.MS.Show)}catch(t){return}}function d(t,e){try{o.YT.sendActionEvent(t,r.EG.Click,r.MS.Navigate,e)}catch(t){return}}function h(t,e,i){try{o.YT.sendActionEvent(t,e?r.EG.KeyPress:r.EG.Click,i?r.MS.Follow:r.MS.Unfollow)}catch(t){return}}function g(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");o.YT.sendContentViewEvent(t,l.ym.View)}catch(t){return}}function u(t,e){const i=e?`${e}`:"";o.YT.addOrUpdateTmplProperty(t,i)}function m(t){o.YT.removeTmplProperty(t)}function v(t){for(const e of t)m(e)}var x,f,S=i(87906);(f=x||(x={})).safeExecute=function(t,e,i,r,s,a={}){try{return t()}catch(t){return i&&(0,S.vV)(i,`${r}: ${t?.message}`,s,a),e}},f.safeExecuteAsync=async function(t,e,i,r,s,a={}){try{return await t()}catch(t){return i&&(0,S.vV)(i,`${r}: ${t?.message}`,s,a),Promise.resolve(e)}},f.logExceptionWithFormat=function(t,e,i,r,s,a={}){(0,S.c_)(t,e,`${r}${r?": ":""}${i}`,s,a)},f.logErrorWithFormat=function(t,e,i,r,s={}){(0,S.vV)(t,`${i}${i?": ":""}${e}`,r,s)}},22944(t,e,i){i.r(e),i.d(e,{SportsSpotlightCricketTransformer(){return p}});var r=i(23305),s=i(87906),a=i(33335),n=i(33744),o=i(79811),l=i(89757);class p extends r.Bc{constructor(){super(...arguments),this.getCricketMetaData=t=>({cardSize:this.cardSize,telemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,leagueId:"",matchData:[{sportsMatchData:{...t.sportsSpotlightCricketData.match}}],followedSports:t.followedSports})}async transform(t){const{cardSize:e}=t;this.cardSize=e,this.isInDarkMode=(0,o.jJ)();const i=await this.getCurrentViewModel(t);return{viewTemplate:l.qy`
                <sports-spotlight-cricket
                    :viewModel="${i}"
                ></sports-spotlight-cricket>
            `}}async getCurrentViewModel(t){try{if(!t.sportsSpotlightCricketData)return void(0,s.vV)(a.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,t);const{match:e,partnershipInfo:i,playerOfTheMatchInfo:l,recentMatches:p}=t.sportsSpotlightCricketData;((0,o.nD)(e)||(0,o.nD)(i)&&(0,o.nD)(l)&&(0,o.nD)(p))&&(0,s.vV)(a.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,t);const{telemetryBuilder:c}=this.transformerProvider,d=e.gameCenterUrl,h=d&&(0,o.Ot)(d);let g,u,m;const v=this.getCricketMetaData(t);let x;return u=await this.transformerProvider.generateView(v,r.hi.SportsCricket),(0,o.nD)(i)||(g=this.getPartnership(t)),(0,o.nD)(l)||(x=this.getPlayerOfMatch(t)),(0,o.nD)(p)||(m=this.getRecentMatches(t)),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:c.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsSpotlightCricketCard}),sportsSpotlightCricketData:t.sportsSpotlightCricketData,partnership:g,matchView:u?.viewTemplate,clickThroughUrl:h,playerOfMatch:x,recentMatches:m}}catch(e){return void(0,s.vV)(a.Ax,"Error in transforming Spotlight Cricket data",`market=${n.T3.CurrentMarket}`,t)}}getPlayerOfMatch(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{playerOfTheMatchInfo:s}=t.sportsSpotlightCricketData,a=(0,o.iK)(s.teamImageId||t.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),n=s.imageId?(0,o.iK)(s.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced):"";return{gameFormat:t.sportsSpotlightCricketData.match.gameFormat,cardSize:this.cardSize,playerOfTheMatchInfo:s,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsSpotlightCricketCard}),imageUrl:n,teamImageUrl:a,strings:i}}getPartnership(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{partnershipInfo:s}=t.sportsSpotlightCricketData;return s.batter1.imageUrl=(0,o.iK)(s.batter1.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),s.batter2.imageUrl=(0,o.iK)(s.batter2.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),s.batter1.teamImageUrl=(0,o.iK)(s.batter1.teamImageId||t.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.suggestionImageInfo),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,partnershipInfo:s,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsSpotlightCricketCard}),strings:{currentPartnership:i.currentPartnership,runs:i.runsScoredText,balls:i.ballsFacedText,strikeRate:i.strikeRateText}}}getParticipantIconUrl(t){return t?.replace(/w=([\d]*)?&h=([\d]*)?/,"w=70&h=70")}getRecentMatches(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{recentMatches:s}=t.sportsSpotlightCricketData;return s.forEach(t=>{t.teamImageUrl=t.teamImageId?(0,o.iK)(t.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo):null,t.matches=t.matches?.slice(0,5)}),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,recentMatches:s,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:r.BP.SportsSpotlightCricketCard}),strings:{recentMatches:i.recentMatches}}}}Promise.resolve().then(i.bind(i,22265)),Promise.resolve().then(i.bind(i,18937)),Promise.resolve().then(i.bind(i,30502)),Promise.resolve().then(i.bind(i,23501)),Promise.resolve().then(i.bind(i,98170))},23305(t,e,i){i.d(e,{pC(){return K},kA(){return A},hi(){return U},qz(){return _},T0(){return v},Xp(){return m},pA(){return E},D7(){return c},VO(){return a},XR(){return b},JH(){return tt},Z5(){return u},tX(){return W},X2(){return w},oL(){return o},BP(){return Q},sQ(){return S},Bc(){return J},aB(){return $},t9(){return B},rq(){return y},bo(){return d},v1(){return p.v},S_(){return R},mx(){return q},IG(){return T},JC(){return O},jx(){return f},Qy(){return G},kt(){return g},ci(){return Y},GC(){return C}});var r,s,a,n,o,l,p=i(48098);(s=r||(r={})).Initial="initial",s.Default="default",s.Settings="settings",s.ColdStart="coldstart",(n=a||(a={})).scheduledTournaments="GolfSchedule",n.leaderboard="GolfLeaderBoard",(l=o||(o={})).singleRace="MotorSportsSingleRace",l.raceList="MotorSportsRaceList";const c=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey","auto racing":"Racing",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia"});var d,h;(h=d||(d={})).Mentioned="Mentioned",h.Related="Related";const g="CHAMPIONS",u=" - ";var m,v,x;!function(t){t.preGame="pre-game",t.inprogressGame="inprogress-game",t.postGame="post-game",t.nonlive="non-live",t.toss="Toss",t.dinner="Dinner",t.drinks="Drinks",t.fog="Fog",t.innings="Innings",t.lunch="Lunch",t.stumps="Stumps",t.tea="Tea",t.break="Break",t.superover="SuperOver",t.abandoned="Abandoned",t.postponed="Postponed",t.BadWeatherCondition="BadWeatherCondition",t.delayed="Delayed"}(m||(m={})),(x=v||(v={})).PreGame="PreGame",x.InProgressGame="InProgressGame",x.InProgress="InProgress",x.Final="Final",x.PostGame="PostGame",x.Live="Live",x.Unknown="Unknown";const f={Badge:"Badge",Preview:"PreviewCard"},S="Sports",y="SportsFre",b={League:"League",Team:"Team"},w={Dislike:"Dislike",Follow:"Follow"};var $,k;(k=$||($={})).Leaderboard="Leaderboard",k.FRE="Fre",k.Tennis="Tennis",k.Cricket="Cricket",k.SportsSpotlight="SportsSpotlight",k.SideBySide="SideBySide",k.Countdown="Countdown";const T={0:"recommendationNone",1:"recommendationExplicit",2:"recommendationImplicit",3:"recommendationPopular",4:"recommendationLive",5:"recommendationMIT",6:"recommendationLocalPopular",7:"recommendationRecentSelect"},C="EntityId~";var M,F,_,D,E,z,P,I,R,H,B,L;(F=M||(M={})).Gold="Gold",F.Silver="Silver",F.Bronze="Bronze",F.Total="Total",(D=_||(_={})).Won="Won",D.Lost="Lost",D.Tied="Tied",(z=E||(E={})).none="None",z.unknown="Unknown",z.captain="Captain",z.batter="Batter",z.bowler="Bowler",z.wicketKeeper="WicketKeeper",z.allRounder="AllRounder",(I=P||(P={})).one="1",I.two="2",(H=R||(R={})).test="Test",H.odi="Odi",H.t20="T20",(L=B||(B={})).PickTheWinner="PickTheWinner",L.PickWinner="PickWinner",L.PlayerOfMatch="PlayerOfMatch";var V=i(91089),j=i(2018);const O="sportsInfoAppState";var A,N;(N=A||(A={}))[N.sportsInfoApiData=1]="sportsInfoApiData",N[N.sportsData=2]="sportsData",N[N.sportsSDCardView=3]="sportsSDCardView",N[N.sportsViewMode=4]="sportsViewMode",N[N.tabCurrentPageIndex=5]="tabCurrentPageIndex",N[N.currentTabEntityId=6]="currentTabEntityId",N[N.cardSize=7]="cardSize",N[N.cardType=8]="cardType",N[N.experienceName=9]="experienceName",N[N.entityDataMap=10]="entityDataMap",N[N.entityViewMap=11]="entityViewMap",N[N.sportsSuggestIDMap=12]="sportsSuggestIDMap",N[N.interestOptions=13]="interestOptions",N[N.allRecommendations=14]="allRecommendations",N[N.dislikedEntities=15]="dislikedEntities",N[N.followedSports=16]="followedSports",N[N.sportsConfig=17]="sportsConfig",N[N.sportsStrings=18]="sportsStrings",N[N.rootTelemetryObject=19]="rootTelemetryObject",N[N.telemetryExt=20]="telemetryExt",N[N.isPinned=21]="isPinned",N[N.isExplorationCard=22]="isExplorationCard",N[N.isHidePopupOpen=23]="isHidePopupOpen",N[N.widgetDimension=24]="widgetDimension",N[N.searchSuggestions=25]="searchSuggestions",N[N.toggleInterestManager=26]="toggleInterestManager",N[N.sportsFeedDataParsed=27]="sportsFeedDataParsed",N[N.feedDataTimestamp=28]="feedDataTimestamp",N[N.wpoMetadata=29]="wpoMetadata",N[N.currentSpotlightEntityId=30]="currentSpotlightEntityId",N[N.previewTypeInfo=31]="previewTypeInfo",N[N.isInit=32]="isInit",N[N.isV2Data=33]="isV2Data",N[N.skinnyDataConsumed=34]="skinnyDataConsumed",N[N.isCopilotTheme=35]="isCopilotTheme",N[N.IsRubyPill=36]="IsRubyPill",N[N.pollOptionId=37]="pollOptionId",N[N.isRubyMiniWidget=38]="isRubyMiniWidget",N[N.isImmersiveSd=39]="isImmersiveSd",N[N.explorationSettings=40]="explorationSettings",(0,V.G)({getInstance(){return j.vv.get("sportsStates",()=>new Map)}});const U={SportsInfo:"sports-sd-container",SportsInfoSpan:"sports-info-span",SportsMatchList:"sports-match-list",SportsMatch:"sports-match",Articles:"sports-articles",TeamExploration:"sports-team-exploration",TeamExplorationMatch:"sports-team-exploration-match",CricketExploration:"sports-cricket-exploration",TennisExploration:"sports-tennis-exploration",ExplorationHead:"sports-exploration-head",Standings:"sports-standings",Leaderboard:"sports-leaderboard",SportsCricket:"sports-cricket",SportsCricketV2:"sports-cricket-v2",SportsTennis:"sports-tennis",SportsMarchmadness:"sports-marchmadness",FeedsNotificationToast:"feeds-notification-toast",SportsHidePopup:"sports-hidepopup",SportsFre:"sports-fre",SportsEventBrief:"sports-event-brief",SportsEventCountry:"sports-event-country",SportsEventResults:"sports-event-results",SportsSpanMatch:"sports-span-match",SportsSpotlight:"sports-spotlight",AgentSpotlight:"agent-spotlight",SportsGameStats:"sports-game-stats",SportsGameLeaders:"sports-game-leaders",SportsCountdown:"sports-countdown",SportsAugmentCard:"sports-augment-card",SportsSpotlightRace:"sports-spotlight-race",SportsSpotlightTennis:"sports-spotlight-tennis",SportsTennisMatch:"sports-tennis-match",SportsSpotlightGolf:"sports-spotlight-golf",SharedHeroNewsCard:"shared-hero-news-card",SportsSimpleMatch:"sports-simple-match",SportsStandingsRankings:"sports-standings-rankings",SportsMedal:"sports-medal",SportsMedalV2:"sports-medal-v2",SportsEventSchedule:"sports-event-schedule",SportsRecentMedal:"sports-recent-medal",SportsRubyPill:"sports-ruby-pill",SportsInfoList:"sports-info-list",SportsSpotlightCricket:"sports-spotlight-cricket",SportsSpotlightCricketV2:"sports-spotlight-cricket-v2",SportsPickWinner:"sports-pick-winner-wc",SportsMatchWithScores:"sports-match-with-scores",SportsSpotlight2c:"sports-spotlight-2c",SportsUpcomingMatches:"sports-upcoming-matches",SportsTournamentsList:"sports-tournaments-list",SportsTournamentStatusRow:"tournament-status-row",SportsPlayerEvent:"sports-player-event"},G={TeamVsTeam:U.SportsMatchList,TeamVsTeamWithBracket:U.SportsMarchmadness,Standings:U.Standings,Articles:U.Articles,TeamVsTeamExploration:U.TeamExploration,EventBrief:U.SportsEventBrief,OneVsOneEventResult:U.SportsEventResults,OneVsManyEventResult:U.SportsEventResults,TeamVsTeamEventResult:U.SportsEventResults,TeamStandingWithEvents:U.SportsEventCountry,TeamStandingWithMedals:U.SportsEventCountry,CricketExploration:U.CricketExploration,TennisExploration:U.TennisExploration,Spotlight:U.SportsSpotlight,SpotlightFRE:U.SportsSpotlight,SpotlightRace:U.SportsSpotlightRace,SpotlightTennis:U.SportsSpotlightTennis,SpotlightGolf:U.SportsSpotlightGolf,StandingsRankings:U.SportsStandingsRankings,LeagueTodaysEvents:U.SportsEventSchedule,TeamStandings:U.SportsMedal,SpotlightCricket:U.SportsSpotlightCricket,TournamentsList:U.SportsTournamentsList,Spotlight2c:U.SportsSpotlight2c,AgentSpotlight:"AgentSpotlight"},W={SportsMatch:"SportsMatch",SportsTournamentStatusRow:"SportsTournamentStatusRow",EventSDCardSportsMIT1:"EventSDCardSportsMIT1",EventSDCardSportsMIT2:"EventSDCardSportsMIT2",EventSDCardSportsMIT3:"EventSDCardSportsMIT3",SportsSpans:"SportsSpans",SportsAugment:"SportsAugment",SportsHeroFre:"SportsHeroFre",SportsHeroLeagueTodaysEvents:"SportsHeroLeagueTodaysEvents",SportsHeroMatch1SeasonStats:"SportsHeroMatch1SeasonStats",SportsHeroMatch1Stats:"SportsHeroMatch1Stats",SportsHeroMatch2SeasonStats:"SportsHeroMatch2SeasonStats",SportsHeroMatch2Stats:"SportsHeroMatch2Stats",SportsHeroMatch3SeasonStats:"SportsHeroMatch3SeasonStats",SportsHeroMatch3Stats:"SportsHeroMatch3Stats",SportsHeroMatchStatistics:"SportsHeroMatchStatistics",SportsSpotlight2Match1:"SportsSpotlight2Match1",SportsSpotlight2Match2:"SportsSpotlight2Match2",SportsHeroNews:"SportsHeroNews",SportsHeroOneVsManyEventResult:"SportsHeroOneVsManyEventResult",SportsHeroOneVsOneEventResult:"SportsHeroOneVsOneEventResult",SportsMatchMiniWidget:"SportsMatchMiniWidget",SportsHeroSeasonStatistics:"SportsHeroSeasonStatistics",SportsHeroStandingsRankings:"SportsHeroStandingsRankings",SportsHeroTeamStandings:"SportsHeroTeamStandings",SportsHeroTeamStandingWithEvents:"SportsHeroTeamStandingWithEvents",SportsHeroTeamStandingWithMedals:"SportsHeroTeamStandingWithMedals",SportsHeroTeamVsTeam:"SportsHeroTeamVsTeam",SportsHeroTeamVsTeamEventResult:"SportsHeroTeamVsTeamEventResult",SportsHeroVideo:"SportsHeroVideo",SportsHeroMatchCard:"SportsHeroMatchCard"};var q,X;W.SportsMatch,W.EventSDCardSportsMIT1,W.EventSDCardSportsMIT2,W.EventSDCardSportsMIT3,W.SportsSpans,W.SportsAugment,(X=q||(q={}))[X.entityViewMap=0]="entityViewMap",X[X.sportsConfig=1]="sportsConfig",X[X.sportsStrings=2]="sportsStrings",X[X.rootTelemetryObject=3]="rootTelemetryObject",X[X.sportsFeedDataParsed=4]="sportsFeedDataParsed",(0,V.G)({getInstance(){return j.vv.get("sportsSpanStates",()=>new Map)}});var Z=i(67072);class J extends Z.GH{}class K extends Z.GH{}class Y extends Z.GH{}const Q=Object.freeze({SportsCard:"SportsCard",Game:"sports_game",Team:"sports_team",Vertical:"sports",DislikeSports:"HideSport",SportsSuggest:"suggestresult",SportsSuggestUrl:"suggesturl",FollowSports:"Follow",SportsFRE:"freexperience",FollowTeam:"follow_team",HeroGem:"HeroGem",SportsInfoSpotlight:"SportsInfoSpotlight",SportsDiscoverMore:"SportsDiscoverMore",ChangeLeagueTeam:"ChangeLeagueTeam",Feedback:"Feedback",PopupHideSport:"PopupHideSport",PopupHide:"popup_hide",PopupCancel:"popup_cancel",PopupClose:"popup_close",EventBriefClick:"event_brief",EventBriefContentClick:"EventBriefContent",MarchMadnessCard:"MarchMadnessCard",SportsArticle:"sports_article",SportsCarousel:"SportsCarousel",TeamVsTeam:"TeamVsTeam",ExplorationDislike:"ExplorationDislike",SportsTopSpan:"SportsTopSpan",SportsStickySpan:"SportsStickySpan",SportsTopSpanOverlay:"SportsTopSpanOverlay",SportsStickySpanOverlay:"SportsStickySpanOverlay",SeeDetails:"seedetails",SportsNotificationToast:"SportsNotificationToast",SportsNotificationToastLink:"SportsNotificationToastLink",SportsNotificationToastDismiss:"SportsNotificationToastDismiss",SportsNotificationToastYes:"SportsNotificationToastYes",SportsNotificationToastNo:"SportsNotificationToastNo",SportsAfterFollowDismiss:"SportsAfterFollowDismiss",SportsSpotlightVideo:"SpotlightVideo",Countdown:"Countdown",PinToDesk:"PinToDesk",Destination:"destination",Augment:"augment",SportsRubyClick:"SportsRubyClick",SportsSpotlightTennisCard:"SportsSpotlightTennisCard",SportsSpotlightRaceCard:"SportsSpotlightRaceCard",SportsSpotlightGolfCard:"SportsSpotlightGolfCard",SportsStandingsRankingsCard:"SportsStandingsRankingsCard",SportsStandingsRankingsTable:"SportsStandingsRankingsTable",SportsMedalCard:"SportsMedalCard",SportsAgentSpotlight:"SportsAgentSpotlight",SportsEventResults:"SportsEventResults",SportsEventScheduleCard:"SportsEventScheduleCard",SportsEventCountryCard:"SportsEventCountryCard",SportsSpotlightCricketCard:"SportsSpotlightCricketCard",SportsPickWinner:"SportsPickWinner",SportsSpotlightMatchCard2c:"SportsSpotlightMatchCard2c",SportsSpotlightScores2c:"SportsSpotlightScores2c",SportsUpcomingMatches2c:"SportsUpcomingMatches2c",SportsTournamentsListCard:"SportsTournamentsListCard",SportsInfoMiniWidget:"SportsInfoMiniWidget",SportsTournamentStatusRow:"SportsTournamentStatusRow"}),tt=Object.freeze({ChannelStoreLaunched:"ChannelStoreLaunched",Badge:"SportsBadge",TaskbarRotation:"SportsTBR",SportsFrePresent:"SportsFrePresent",SportsTabType:"SportsTabType",SportsLeagueName:"SportsLeagueName",SportsDefaultLeagueShown:"SportsDefaultLeagueShown",SportsUserFollowsDefaultLeague:"SportsUserFollowsDefaultLeague",SportsUserFollowsOtherteams:"SportsUserFollowsOtherteams",SportsDropdownChangedLeague:"SportsDropdownChangedLeague",SportsUserFollowsDropdownChangedLeague:"SportsUserFollowsDropdownChangedLeague",SportsUserGroup:"SportsUserGroup",SportsExplorationReason:"SportsExplorationReason",SportsDropdownChangedViewShown:"SportsDropdownChangedViewShown",SportsCardeSize:"SportsCardeSize",SportsReasonShown:"SportsReasonShown",SportsDfltRecoPopupShown:"SportsDefaultRecommendationPopupShown",SportsExplorationPopupShown:"SportsExplorationPopupShown",SportsExplorationCardShown:"SportsExplorationCardShown",SportsEventBriefShown:"SportsEventBriefShown",SpotlightCardPreviewType:"SpotlightCardPreviewType",SpotlightCardEntityId:"SpotlightCardEntityId",SportsNewSpotlightCard:"SportsNewSpotlightCard",SportsCardType:"SportsCardType",SportsVideoSpotlightShown:"SportsVideoSpotlightShown",SportsNewSpotlightCountdown:"SportsNewSpotlightCountdown",SportsPinToDeskShown:"SportsPinToDeskShown",SportsDataV2:"SportsDataV2",SportsPinToDeskEdgeFeatureEnabled:"SportsPinToDeskEdgeFeatureEnabled",SportsNewSpotlightExploration:"SportsNewSpotlightExploration",SportsNewSpotlightTennis:"SportsNewSpotlightTennis",SportsNewSpotlightRace:"SportsNewSpotlightRace",SportsNewSpotlightGolf:"SportsNewSpotlightGolf",SportsCardCurrentTabId:"SportsCardCurrentTabId",SportsCardCopilotCurrentTabId:"SportsCardCopilotCurrentTabId",SportsStandingsRankings:"SportsStandingsRankings",SportsCardIsInViewPort:"SportsCardIsInViewPort",SportsNewSpotlightCricket:"SportsSpotlightCricket",SportsCardFirstTagName:"SportsCardFirstTagName",SportsRubyPillShown:"SportsRubyPillShown",SportsTournamentsList:"SportsTournamentsList"})},23501(t,e,i){i.r(e),i.d(e,{PlayerOfMatchCard(){return U}});var r=i(56911),s=i(92011),a=i(41123),n=i(61138),o=i(62047),l=i(47810),p=i(59669);const c="600",d=`\n    display: flex;\n    flex-direction: column;\n    font-size: ${a.K};\n    justify-content: center;\n`,h=`\n    ${d}\n    height: 30px;\n`,g=p.A`
.pom-card{display:flex;flex-direction:column;gap:16px;padding:12px 12px 10px 12px;border-radius:8px;background:var(--sports-item-background);position:relative;max-height:125px}.pom-container{display:flex;flex-direction:column;align-items:center;padding:5px 0px 0px 0px;gap:5px;height:100%}.pom-info-container{display:flex;justify-content:space-between}.pom-title{font-size:${n.k};font-weight:${c};line-height:${n.F};position:relative}.player-stats-container{display:flex;justify-content:space-between}.stats-sub-container{${d} align-items:flex-start}.inning-container{${d}}.container-rt,.inning2-container{${d} align-items:center}.stats-container{${h} align-items:flex-start}.stats-container-inning2,.rt-stats-container{${h} align-items:center}.rt-stats-container-inning2{${h} align-items:flex-end}.empty-allrounder-summary-stats{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;font-size:${o.t};height:30px;font-weight:400}.stats-and-sub-container{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.divider{width:1px;background:${l.l};opacity:0.05}.player-stats{display:flex;justify-content:space-between;width:244px}.player-name{font-size:${o.e};font-weight:${c};line-height:${a.Z};max-height:20px;width:182px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.team-name{font-size:${o.t};font-weight:${c};line-height:${o.e}}.summary-stats-left{font-size:${n.k};font-weight:${c};line-height:${n.F};display:flex;flex-direction:column;align-items:flex-start;justify-content:space-between}.summary-stats{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;text-align:center;width:244px;justify-content:space-between}.detailed-summary-stats{font-size:${n.k};font-weight:600;line-height:${n.F};display:flex;flex-direction:row;justify-content:space-between;flex:2}.empty-summary-stats{font-size:${o.t};font-weight:400;line-height:${n.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.summary-stats-right{font-size:${n.k};font-weight:600;line-height:20px;display:flex;flex-direction:column;align-items:flex-end}.summary-stats-label{font-size:${o.t};font-weight:400;line-height:${o.e};text-align:center}.summary-stats-and-label{font-size:${n.k};font-weight:600;line-height:${o.e};text-align:center}.subtext-label{font-size:${o.t};font-weight:400;line-height:${o.e}}.player-role{font-size:${o.t};font-weight:400;line-height:${o.e}}.player-details-container{display:flex;flex-direction:column}.team-details-container{display:flex;gap:4px}.sport-with-subtext-title{text-wrap:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:justify;width:90px;font-weight:600;font-size:${n.k}}.team-image{width:16px;height:16px}.player-image{width:50px;height:50px}`;var u=i(89757),m=i(69259),v=i(23305);const x=u.qy`
    <div class="player-title-container">
        <div class="player-name">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.name}
        </div>
        <div class="player-role">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.role?.title}
        </div>
    </div>
`,f=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.oversBowled}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.oversBowledText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.maidenOvers}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.maidenOversText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.runsConceded}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.runsConcededText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.wicketsTaken}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.wicketsTakenText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.economyRate}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.economyRateText}</span>
        </div>
    </div>
`,S=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.runsScored}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.runsScoredText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.ballsFaced}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.ballsFacedText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.foursHit}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.foursHitText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.sixesHit}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.sixesHitText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.strikeRate}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.strikeRateText}</span>
        </div>
    </div>
`,y=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.runsScored}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.runsScoredText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.ballsFaced}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.ballsFacedText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            <span class="summary-stats-and-label">&</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.wicketsTaken}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.wicketsTakenText}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.runsConceded}
            <span class="summary-stats-label">${t=>t.viewModel?.strings.runsConcededText}</span>
        </div>
    </div>
`,b=u.qy`
    <div class="player-stats">
        ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics?.battingSummary?S:null}
        ${t=>t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?.bowlingSummary?f:null}
    </div>
`,w=u.qy`
    <div class="player-stats">
        ${y}
    </div>
`,$=u.qy`
    <div class="player-stats">
        ${t=>t.viewModel?.playerOfTheMatchInfo?.battingStatistics&&t.viewModel?.playerOfTheMatchInfo?.bowlingStatistics?w:b}
    </div>
`,k=(t,e)=>u.qy`
    <div class=${e?"container-rt":"inning-container"}>
        ${e=>e.getBattingStatsRunsScored(t)}
        <span class="summary-stats-label">${t=>t.viewModel?.strings.runsScoredText}</span>
    </div>
    <div class="divider"></div>
    <div class=${e?"inning-container":"inning2-container"}>
        ${e=>e.getBattingStatsBallsFaced(t)}
        <span class="summary-stats-label">${t=>t.viewModel?.strings.ballsFacedText}</span>
    </div>
`,T=(t,e)=>u.qy`
    <div class=${e?"container-rt":"inning-container"}>
        ${e=>e.getBowlingStatsWicketsTaken(t)}
        <span class="summary-stats-label">${t=>t.viewModel?.strings.wicketsTakenText}</span>
    </div>
    <div class="divider"></div>
    <div class=${e?"inning-container":"inning2-container"}>
        ${e=>e.getBowlingStatsRunsConceded(t)}
        <span class="summary-stats-label">${t=>t.viewModel?.strings.runsScoredText}</span>
    </div>
`,C=t=>u.qy`
    <div class="empty-summary-stats">
        <div class="placeholder-container">${t}</div>
    </div>
`,M=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>t.isBattingStatsAvailable("1")?k("1",!1):C(t.viewModel?.strings.didNotBat)}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>t.isBattingStatsAvailable("2")?k("2",!0):C(t.viewModel?.strings.didNotBat)}
        </div>
    </div>
`,F=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>t.isBowlingStatsAvailable("1")?T("1",!1):C(t.viewModel?.strings.didNotBowl)}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>t.isBowlingStatsAvailable("2")?T("2",!1):C(t.viewModel?.strings.didNotBowl)}
        </div>
    </div>
`,_=(t,e,i)=>u.qy`
    <div class="${i?"rt-":""}stats-container${e?"-inning2":""}">
        ${t}
    </div>
`,D=t=>u.qy`
    <div class="empty-allrounder-summary-stats">
        <div class="placeholder-container">${t}</div>
    </div>
`,E=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>t.isBattingStatsAvailable("1")?_(t.getBattingStatsSummary("1"),!1,!1):D(t.viewModel?.strings?.didNotBat)}
            <div class="divider"></div>
            ${t=>t.isBowlingStatsAvailable("1")?_(t.getBowlingStatsSummary("1"),!1,!0):D(t.viewModel?.strings.didNotBowl)}
            <div class="divider"></div>
            <div class="inning-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>t.isBattingStatsAvailable("2")?_(t.getBattingStatsSummary("2"),!0,!1):D(t.viewModel?.strings.didNotBat)}
            <div class="divider"></div>
            ${t=>t.isBowlingStatsAvailable("2")?_(t.getBowlingStatsSummary("2"),!0,!0):D(t.viewModel?.strings.didNotBowl)}
        </div>
    </div>
`,z=u.qy`
<div class="player-stats">
    ${t=>(t=>{switch(t){case v.pA.allRounder:return E;case v.pA.batter:return M;case v.pA.bowler:return F;default:return E}})(t.viewModel?.playerOfTheMatchInfo?.role?.primaryRole||"")}    
</div>
`,P=u.qy`
    <div class="player-stats-container">
        <div class="player-stats">
            ${t=>((t,e)=>{if(e===v.S_.test)return z;switch(t){case v.pA.allRounder:return $;case v.pA.batter:return R;case v.pA.bowler:return I;default:return $}})(t.viewModel?.playerOfTheMatchInfo?.role?.primaryRole||"",t.viewModel?.gameFormat||"")}
        </div>
    </div>
`,I=u.qy`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${f}
        </div>
    </div>
`,R=u.qy`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${S}
        </div>
    </div>
`,H=u.qy`
    <div class="player-image-container">
        <img class="player-image" src=${t=>t.viewModel?.imageUrl} alt=${t=>t.viewModel?.playerOfTheMatchInfo?.name}></img>
    </div>
`,B=u.qy`
    <div class="team-details-container">
        <img class="team-image" src=${t=>t.viewModel?.teamImageUrl} alt=${t=>t.viewModel?.playerOfTheMatchInfo?.teamShortName}></img>
        <span class="team-name">
            ${t=>t.viewModel?.playerOfTheMatchInfo?.teamShortName}
        </span>
    </div>
`,L=u.qy`
    <div class="player-details-container">
        ${B}
        ${x}
    </div>
`,V=u.qy`
    <div class="pom-info-container">
        ${L}
        ${t=>t.viewModel?.imageUrl?H:null}
    </div>
`,j=u.qy`
    <div class="pom-container">
        <span class="pom-title">
            ${t=>t.viewModel?.strings.playerOfTheMatchHeader}
        </span>
        <div class="pom-card" data-t="${t=>t.viewModel?.telemetryTag}">
            ${V}
            ${P}
        </div>
    </div>
`,O=u.qy`
    ${(0,m.z)(t=>null!=t.viewModel,j)}
`;var A=i(71372);class N extends A.a{constructor(){super(...arguments),this.isBattingStatsAvailable=t=>!!this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(e=>e.inningNumber===t),this.getBattingStatsRunsScored=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(e=>e.inningNumber===t)?.runsScored||"",this.getBattingStatsBallsFaced=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(e=>e.inningNumber===t)?.ballsFaced||"",this.getBattingStatsSummary=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.batting?.find(e=>e.inningNumber===t)?.battingSummary||"",this.getBowlingStatsWicketsTaken=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(e=>e.inningNumber===t)?.wicketsTaken||"",this.getBowlingStatsRunsConceded=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(e=>e.inningNumber===t)?.runsConceded||"",this.getBowlingStatsSummary=t=>this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(e=>e.inningNumber===t)?.bowlingSummary||"",this.isBowlingStatsAvailable=t=>!!this.viewModel?.playerOfTheMatchInfo?.statistics?.bowling?.find(e=>e.inningNumber===t)}}let U=class extends N{};U=(0,r.Cg)([(0,s.E)({name:"player-of-match-card",template:O,styles:g})],U)},71372(t,e,i){i.d(e,{a(){return n}});var r=i(56911),s=i(92011),a=i(95144);let n=class extends s.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,r.Cg)([a.x],n)},18937(t,e,i){i.r(e),i.d(e,{SportsCricketPartnership(){return T}});var r=i(56911),s=i(92011),a=i(59669),n=i(47810),o=i(61138),l=i(62047),p=i(33113),c=i(41123),d=i(63033);const h=a.A` .cricket-partnership{color:${n.l}}`,g=a.A` p{margin:0;font-family:"Segoe UI"}.cricket-partnership{width:268px}.ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.current-partnership{font-size:${o.k};line-height:${o.F};font-weight:600;margin:6px 0;text-align:center}.stats-item{height:28px;display:flex;justify-content:end;flex-direction:column;flex:1;padding:0 5px}.bar-title{height:14px;line-height:${l.e};font-size:${l.t};font-weight:600;display:flex;justify-content:center}.bar-title >div{display:inline-block;line-height:${o.F};font-size:${o.k}}.stats-bar{display:flex;height:8px;width:100%;border-radius:8px;justify-content:space-between;background:${p.I2};margin-top:6px}.left-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${p.I2};border-radius:8px 0 0 8px;justify-content:flex-end}.right-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${p.I2};border-radius:0 8px 8px 0;justify-content:flex-start}.left-bar-progress{height:8px;width:30%;border-radius:8px 0 0 8px;background:#EACF24}.right-bar-progress{height:8px;width:30%;border-radius:0 8px 8px 0;background:#9C8C26}.individual-partnership{flex-direction:row;flex-wrap:nowrap;justify-content:space-between;text-align:justify;position:relative;background:var(--sports-item-background);padding:12px;border-radius:8px;display:flex}.partnership-player{display:flex;flex-direction:column}.player-stats{height:20px;font-family:'Segoe UI';font-style:normal;font-weight:400;font-size:${o.k};;line-height:${o.F}}.player-name{font-style:normal;font-weight:600;font-size:${o.k};line-height:${o.F};max-width:70px}.left-player{text-align:left;flex:1 1 0}.right-player{text-align:right;flex:1 1 0}.horizontal-bar{box-sizing:border-box;width:100%;height:1px;background:var(--neutral-stroke-divider-rest);flex:0 0 auto;order:0}.stats-bar{text-align:center}._1x_3y{.current-partnership{margin:10px 0;font-size:${c.K};line-height:${c.Z}}.individual-partnership{padding:13px}.player-name{-webkit-line-clamp:2}}.player-image{width:50px;height:50px}.middle-section{width:118px;display:flex;flex-direction:column}.team-image{width:16px;height:16px}.team-name{font-size:${l.t};line-height:${l.e};font-weight:600;margin-left:6px}.team-image-container{display:flex;flex:1;justify-content:center;align-items:center}.individual-partnership.without-image{flex-direction:column;.partnership-player{flex-direction:row}.player-name-container{display:flex;flex:3 1 0;flex-direction:column;overflow:hidden}.player-stats{display:flex;flex:1 1 0;flex-direction:column;p{min-width:16px;max-width:35px;text-align:center}}.grid-stats{display:grid;grid-template-columns:1fr 1fr;column-gap:12px;width:100%}.header{font-weight:600}p{font-size:${o.k};line-height:${o.F}}.stats-header-row,.stats-row{display:flex}.player-name{max-width:none}.player1{padding-bottom:8px;padding-top:4px;border-bottom:1px solid rgba(0,0,0,0.05)}.player2{padding-top:8px}}.partnership-info{margin-left:auto;font-size:${l.t};line-height:${l.e};font-weight:600}`.withBehaviors(new d.N(null,h));var u=i(89757),m=i(69259);const v=t=>u.qy`
    <div class="partnership-player">
        <div class="player-image-container">
            <img class="player-image" src="${t.imageUrl}" alt="${t.name}" />
        </div>
        <p class="player-name ellipsis"  title="${t.name}">
            ${t.name}
        </p>
        <p class="player-stats ellipsis">
            ${e=>e.setPlayerStats(t.battingStatistics?.runsScored||"",t.battingStatistics?.ballsFaced||"")}
        </p>
    </div>
`,x=u.qy`
    <div class="stats-item">
        <div class="bar-title">
            <div>${t=>t.viewModel.partnershipInfo.runs} (${t=>t.viewModel.partnershipInfo.balls})</div>
        </div>
        <div class="stats-bar">
            <div class="left-bar"><div class="left-bar-progress" style="width: ${t=>t.partnershipPercentage("batter1")}"></div></div>
            <div class="right-bar"><div class="right-bar-progress" style="width: ${t=>t.partnershipPercentage("batter2")}"></div></div>
        </div>
    </div>
`,f=u.qy`
    <div class="cricket-partnership ${t=>t.viewModel.cardSize}" data-t="${t=>t.viewModel.telemetryTag}">
        <p class="current-partnership">${t=>t.viewModel.strings.currentPartnership}</p>
        ${t=>t.viewModel.partnershipInfo.batter1.imageUrl&&t.viewModel.partnershipInfo.batter2.imageUrl?y:S}
    </div>
`,S=u.qy`
    <div class="individual-partnership without-image">
        <div class="team-image-container">
            <img class="team-image" src="${t=>t.viewModel.partnershipInfo.batter1.teamImageUrl}" />
            <p class="team-name ellipsis" title="${t=>t.viewModel.partnershipInfo.batter1.teamName}">${t=>t.viewModel.partnershipInfo.batter1.teamShortName}</p>
            <p class="partnership-info">${t=>t.viewModel.partnershipInfo.runs}(${t=>t.viewModel.partnershipInfo.balls})</p>
        </div>
        <div class="player1">
            ${t=>b(t.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="player2">
            ${t=>b(t.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,y=u.qy`
    <div class="individual-partnership">
        <div class="left-player">
            ${t=>v(t.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="middle-section">
            <div class="team-image-container">
                <img class="team-image" src="${t=>t.viewModel.partnershipInfo.batter1.teamImageUrl}" />
                <p class="team-name ellipsis" title="${t=>t.viewModel.partnershipInfo.batter1.teamName}">${t=>t.viewModel.partnershipInfo.batter1.teamShortName}</p>
            </div>
            ${x}
        </div>
        <div class="right-player">
            ${t=>v(t.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,b=t=>u.qy`
    <div class="partnership-player">
        <div class="player-name-container">
            <p class="player-name ellipsis header" title="${t.name}">
                ${t.name}
            </p>
            <p class="player-role ellipsis" title="${t.role.title}">
                ${t.role.title}
            </p>
        </div>
        <div class="player-stats">
            <div class="grid-stats">
                <p class="stats-header header">${t=>t.viewModel.strings.runs}</p>
                <p class="stats-header header">${t=>t.viewModel.strings.balls}</p>
                <p class="stats ellipsis">${t.battingStatistics?.runsScored||""}</p>
                <p class="stats ellipsis">${t.battingStatistics?.ballsFaced||""}</p>
            </div>
        </div>
    </div>
`,w=u.qy`
    ${(0,m.z)(t=>null!=t.viewModel,f)}
`;var $=i(71372);class k extends $.a{constructor(){super(...arguments),this.setPlayerStats=(t,e)=>{if(!t)return"";if(!e)return t;return t+" ("+e+")"},this.partnershipPercentage=t=>{const e="batter1"===t?this.viewModel.partnershipInfo.batter1:this.viewModel.partnershipInfo.batter2,i=e.battingStatistics?.runsScored||"",r=this.viewModel.partnershipInfo.runs||"";if(this.isEmpty(i)||this.isEmpty(r))return"0%";return 100*parseInt(i)/parseInt(r)+"%"},this.isEmpty=t=>null===t||""===t}}let T=class extends k{};T=(0,r.Cg)([(0,s.E)({name:"sports-cricket-partnership",template:w,styles:g,shadowOptions:{delegatesFocus:!0}})],T)},98170(t,e,i){i.r(e),i.d(e,{SportsCricketRecentMatches(){return T}});var r=i(56911),s=i(92011),a=i(59669),n=i(22131),o=i(4126),l=i(47810),p=i(61138),c=i(62047);const d=a.A` .ruby{container-type:inline-size}@container (min-width:180px) and (max-width:233px){.ruby{.content{.team-info{min-width:55px;max-width:60px}.team-performance{gap:2px}}}}@container (min-width:234px) and (max-width:269px){.ruby{.content{.team-performance{gap:7px}}}}`,h=a.A` :host{--ruby-win-color:#6CC57B;--ruby-loss-color:#F98981;--ruby-tie-color:#8791B0;--ruby-win-bg-color:#09662033;--ruby-loss-bg-color:#9D192033;--ruby-tie-bg-color:#323F60A6}.recent-matches{color:${l.l}}.ruby .result-element .team-name{color:#D7DEEF}`,g=(0,n.G2)(h),u=a.A` :host{--ruby-win-color:#01712B;--ruby-loss-color:#AC1922;--ruby-tie-color:#635C57;--ruby-win-bg-color:#94DC7F33;--ruby-loss-bg-color:#FFB5AE33;--ruby-tie-bg-color:#F8F4F2}p{margin:0;font-family:"Segoe UI"}.team-info{margin-right:8px}.title{font-size:${p.k};line-height:${p.F};font-weight:600;margin:8px 0;text-align:center}.content{display:flex;flex-direction:column;background:var(--sports-item-background);padding:6px 12px;border-radius:8px}.team-performance{display:flex;flex-direction:row;gap:8px;&:first-child{padding-bottom:5px;margin-bottom:5px;border-bottom:1px solid rgba(0,0,0,0.05)}}.result-element{padding-top:4px;width:32px;display:flex;flex-direction:column;align-items:center;span{width:24px;text-align:center}.result{color:#fff;font-size:${p.k};line-height:${p.F};text-align:center;border-radius:6px;font-weight:600;height:24px;display:flex;justify-content:center;align-items:center;margin-bottom:6px}.winner{background-color:rgba(15,112,59,1)}.loss{background-color:rgba(209,52,56,1)}.tied{background-color:rgba(220,159,6,1)}}.team-name{font-size:${c.t};line-height:${c.e};font-weight:600;text-align:center}.team-image{height:32px}.underscore{width:12px;height:1px;position:absolute;bottom:6px;right:50%;transform:translateX(50%)}.ruby{.content{background:none;padding:0px 0px 18px}.title{display:none}.team-info{display:flex;align-items:center;width:70px;margin-right:0px}.team-image{width:20px;height:20px}.team-performance{gap:12px;&:first-child{margin-bottom:24px;border-bottom:0px}}.team-name{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:550;margin:0px 0px 0px 4px;max-width:44px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit}.result-element{position:relative;padding-top:0px;width:auto;.team-name{display:none}.winner{background-color:var(--ruby-win-bg-color);color:var(--ruby-win-color)}.loss{background-color:var(--ruby-loss-bg-color);color:var(--ruby-loss-color)}.tied{background-color:var(--ruby-tie-bg-color);color:var(--ruby-tie-color)}.underscore{&.winner{background-color:var(--ruby-win-color)}&.loss{background-color:var(--ruby-loss-color)}&.tied{background-color:var(--ruby-tie-color)}}}.result{margin-bottom:0px;border-radius:14px;height:28px;width:28px;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}}`.withBehaviors(g,new o.o("isAdaptiveThemeEnabled",!0,d));var m=i(89757),v=i(69259),x=i(68835);const f=m.qy`
    <div class="team-performance">
        <div class="team-info">
            <img class="team-image" src="${t=>t.teamImageUrl}" alt="${t=>t.teamName}" />
            <p class="team-name">${t=>t.teamName}</p>
        </div>
        ${(0,x.ux)(t=>t.matches,()=>m.qy`
    <div class="result-element">
        <span class="${(t,e)=>e.parentContext.parent.getResultClass(t.gameStatus)} result">
            ${t=>t.summary}
        </span>
        <span class="team-name">${t=>t.teamName}</span>
        ${(0,v.z)(t=>t.isLatest,m.qy`<div class="underscore ${(t,e)=>e.parentContext.parent.getResultClass(t.gameStatus)}"></div>`)}
    </div>
`)}
    </div>
`,S=m.qy`
    <div class="recent-matches ${t=>t.viewModel.isRubySpotlight?"ruby":""}" data-t="${t=>t.viewModel.telemetryTag}">
        <p class="title">${t=>t.viewModel.strings?.recentMatches}</p>
        <div class="content">
            ${(0,x.ux)(t=>t.viewModel.recentMatches,f)}
        </div>
    </div>
`,y=m.qy`
    ${(0,v.z)(t=>null!=t.viewModel,S)}
`;var b=i(23305),w=i(71372),$=i(83546);class k extends w.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,$.h)()}getResultClass(t){return t===b.qz.Won?"winner":t===b.qz.Lost?"loss":"tied"}}let T=class extends k{};T=(0,r.Cg)([(0,s.E)({name:"sports-cricket-recent-matches",template:y,styles:u,shadowOptions:{delegatesFocus:!0}})],T)},30502(t,e,i){i.r(e),i.d(e,{SportsCricket(){return H}});var r=i(56911),s=i(23305),a=i(71372),n=i(50180),o=i(18633);class l extends a.a{handleClickFollowIcon(t,e,i,r){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const s="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,o.LE)(t.currentTarget,s,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,r)}}getScoreClassName(t,e){return this.viewModel.scoreClassNameMap?.get(`${t}${e.satoriId}`)||""}getScoreLineByIndex(t,e,i){const r=this.viewModel.scoresMap.get(`${t}${e.satoriId}`),s=r&&r.length>i?r[i]:void 0;return s?.trim()}getMiddleTemplate(t){return t==s.Xp.preGame?"pre":t==s.Xp.postGame?"post":"live"}getMiddleTemplateClass(t){return t===s.Xp.superover?"state-top":t===s.Xp.postponed?"state-bottom":""}getParticipant(t,e){return this.viewModel.isRTL?t?e.participantTwo:e.participantOne:t?e.participantOne:e.participantTwo}getLiveText(t){return t==s.Xp.inprogressGame?this.viewModel.strings?.sportsLive:t}getFollowIconTitle(t,e){return(0,n.GP)((e?this.viewModel.strings?.followSports:this.viewModel.strings?.haveFollowed)||"",t.name||"")}getGameTime(t){return(t.tvChannel?`${t.gameStartTime}, ${t.tvChannel}`:t.gameStartTime)||""}isScoreMultiLine(t,e){const i=this.viewModel.scoresMap.get(`${t}${e.satoriId}`);return!!i&&i.length>1}shouldRenderResults(t){return t!=s.Xp.preGame&&t!=s.Xp.toss}shouldShowSuperOver(t){return t===s.Xp.superover}shouldShowPostPoned(t){return t===s.Xp.postponed}}var p=i(92011),c=i(86856),d=i(63033),h=i(59669),g=i(22131),u=i(70289);const m=h.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}.match-content{color:#FFFFFF}.ipl-super-over{background:rgba(255,255,255,0.09)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(255,255,255,0.3)}.cricket-final{color:#FFFFFF}.expl .cricket-final{background:rgba(255,255,255,0.3)}.winner-tag path{fill:#FFFFFF}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#0078d4}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.cricket-live-tag{background:rgba(36,214,87,1);color:#000000}.expl .cricket-live-tag{background-color:rgba(233,143,109)}.match-footer{color:#FFFFFF}.pin-to-desk-block{background:rgba(91,51,143,1);background-image:linear-gradient(45deg,rgb(255,0,165) 0,rgb(255,0,165) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgba(255,0,165,0.8) 87%,rgb(255,0,165) 100%);color:white}.pin-to-desk-button{border:1px solid white}.win-light{display:none}.win-dark{display:block}`,v=h.A` `,x=h.A` .flip-h .follow-icon{float:left}.match-footer{right:calc(50% - 90px)}.pin-to-desk-button > img{margin-left:4px}`,f=h.A` :host{--participant-height:55px;--match-content-height:54px;--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{text-align:center;align-items:center;display:grid;row-gap:4px;position:relative;height:100%}.match-content{background:var(--sports-item-background);display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:#000000;width:268px;backdrop-filter:blur(6px);height:54px;${u.f}}.match-content:hover,.match-content:focus-visible{background:var(--sports-item-hover-background)}.match-content:active{background:var(--sports-item-active-background)}._1x_1y .match-content{height:var(--match-content-height)}._1x_1y .participant-container{height:var(--match-content-height)}._1x_1y .participant-container .follow-icon{top:-5px;right:-8px}._1x_3y .match-content{height:72px}._1x_3y .participant-content{height:100%}._1x_3y .participant-score span{margin-top:3px}._1x_3y .participant-score{margin-top:10px}:host([isMobile=true]) .match-content{width:100%}:host([cardlayout="_1x_1y"]) .match-content{padding:0}:host([isMobile=true]) .match-content{margin:0 auto;margin-bottom:8px}:host([isMobile=true]) .participant-container{padding:20px;box-sizing:border-box}:host([cardlayout="_1x_1y"]) .participant-container{max-height:70px}:host([isMobile=true]),:host([isMobile=true]) *:active,:host([isMobile=true]) *:hover{border:none;outline:none;box-shadow:none;text-decoration:none;-webkit-tap-highlight-color:transparent;-webkit-highlight:none}.participant-container{width:108px;max-width:132px;margin:0 0 0 13px;height:100%}.participant-container.flip-h{margin:0 13px 0 0}.results{display:flex}.flip-h .results{flex-flow:row-reverse}.single{align-items:center}.single .participant-score span.score-line1{margin:0 0 5px 0}.participant-info{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}.participant-content{display:flex;column-gap:7px;height:var(--participant-height);position:relative}.flip-h .participant-content{flex-flow:row-reverse}.match-detail{height:var(--participant-height);display:flex;align-items:center}.ipl .match-detail.state-top{height:80px}._1x_1y .match-detail{height:var(--match-content-height)}.participant-icon{width:32px;height:auto;border-radius:8px}.participant-name{font-weight:600;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80px;margin:0 auto}.participant-score span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);max-width:62px}.participant-score{max-height:36px;text-align:start;display:flex;flex-direction:column}.participant-score span.score-line1{margin-top:5px;font-size:14px;font-weight:600;line-height:18px}.flip-h .participant-score{text-align:end}.winner{font-weight:600}.winner-tag{position:absolute;height:100%;display:flex;align-items:center;left:-5px;margin-top:-8px;transform:scaleX(-1)}.flip-h .winner-tag{transform:scaleX(1);right:-5px;left:auto}.winner-tag > svg{fill:currentColor}.middle-detail{align-items:center;display:flex;flex-direction:column;direction:ltr}.game-detail{margin-top:-15px}.game-date{font-weight:600;font-size:14px;line-height:20px}.game-time{font-weight:400;font-size:12px;line-height:16px}.pre-game{width:120px}.cricket-live-tag{display:inline-block;background:rgb(6,132,43);color:rgb(255,255,255);font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-line-height,16px);height:16px;padding:1px 6px;margin:0;border-radius:3px;font-weight:600;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-transform:uppercase}.status-text{font-size:12px;line-height:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ipl-super-over{background:rgba(255,255,255,0.4);display:flex;justify-content:center;align-items:center;border-radius:6px}.super-over-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0 4px 0 4px;font-size:10px;font-weight:400;line-height:14px}.state-top{flex-direction:column;justify-content:center}.state-top .middle-detail{flex:1;margin-top:15px}.state-bottom{flex-direction:column;justify-content:center;height:100%;margin-top:10px}.live-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;margin-top:1px}.detail-live-animation{height:1px;transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate;background:white}@keyframes liveAnimation{0%{width:20px}100%{width:4px}}.match-extended-details{width:180px;text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0px 10px;box-sizing:border-box}.match-footer{color:#1A1A1A;font-style:normal;font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:180px;display:inline-block;position:absolute;bottom:5px;left:calc(50% - 90px)}:host([cardlayout="_1x_1y"]) .match-footer{bottom:4px}.super-over-words{background:rgba(255,255,255,0.35);border-radius:3px;color:rgb(101,107,155);font-style:italic;font-weight:600;width:130px;height:30px;font-size:20px;transform:scale(0.5);line-height:14px;display:flex;align-items:center;justify-content:center;padding:0 3px 5px 0;box-sizing:border-box}.cricket-final{width:21px;height:21px;background:var(--sports-item-background);border-radius:21px;font-weight:400;font-size:10px;line-height:21px;color:#000000}.participant-hover{display:flex;align-items:center;justify-content:center;width:36px;height:28px}.ipl .participant-hover{border:0.5px solid rgba(186,186,186,0.22);border-radius:5px}.detail-live-animation .bottom-game-detail{line-height:14px}@keyframes liveAnimationCommon{0%{width:40px}100%{width:4px}}.participant-container .follow-icon{opacity:0;pointer-events:none;height:20px;position:absolute;bottom:35px;left:25px}.flip-h .follow-icon{float:right}.participant-container:hover .follow-icon,.match-content:focus-visible .follow-icon,.follow-icon:focus-visible{opacity:1;pointer-events:all}.match-content:focus-visible{outline-offset:-1px}._1x_1y.match-data:focus-visible{outline:none}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.pin-to-desk-block{background-color:rgb(255,241,250);background-image:linear-gradient(45deg,rgb(252,151,216) 0,rgb(252,151,216) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgb(252,151,216) 87%,rgb(252,151,216) 100%);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:6px;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:black;width:268px;backdrop-filter:blur(6px);height:54px}.pin-to-desk-block:hover{cursor:pointer}.pin-to-desk-des,.pin-to-desk-button{font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:16px}.pin-to-desk-button{display:flex;height:28px;padding:2px 10px;justify-content:center;align-items:center;border-radius:100px;border:1px solid black}.pin-to-desk-button > img{margin-right:4px}.win-dark{display:none}._1x_1y .pin-to-desk-block{height:var(--match-content-height)}._1x_3y .pin-to-desk-block{height:72px}:host([isMobile=true]) .pin-to-desk-block{width:100%}:host([cardlayout="_1x_1y"]) .pin-to-desk-block{padding:0}:host([isMobile=true]) .pin-to-desk-block{margin:0 auto;margin-bottom:8px}.detailed-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;padding:2px 6px;border-radius:3px;text-transform:uppercase;background:rgba(53,21,105,1)}.final-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);padding:2px 6px;border-radius:3px;background:rgba(53,21,105,0.5)}.expl._1x_2y .match-content,.expl._1x_3y .match-content{box-sizing:border-box;height:66px}.expl._1x_3y{row-gap:6px}.expl._1x_3y .participant-score{margin-top:0px}.expl .match-content{box-sizing:border-box;height:66px;background-color:var(--bg-color)}.expl .match-content:hover{background-color:var(--bg-color-hover)}.expl .cricket-final{background:rgba(26,26,26,0.1)}.expl .cricket-live-tag{background-color:rgb(196,43,28)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(26,26,26,0.1)}`.withBehaviors(new c.t(v,x),new d.N(null,m),(0,g.mr)(h.A` :host{forced-color-adjust:auto}`));var S=i(89757),y=i(69259),b=i(68835),w=i(10500),$=i(36516),k=i(33744);const T=S.qy`
    <img
        src="${()=>(0,k.rA)().StaticsUrl}latest/sports/icons/PinBlack.svg"
        class="win-light"
    >
    <img
        src="${()=>(0,k.rA)().StaticsUrl}latest/sports/icons/PinWhite.svg"
        class="win-dark"
    />
`,C=(t,e,i,r)=>S.qy`
<div class="participant-container${t=>e?"":" flip-h"}" title="${i?.name||""}">
<div class="participant-content" index="-1">
            <div class="winner-tag">    
                ${(0,y.z)(t=>i?.isWinner,S.qy`${S.qy.partial('<svg width="5" height="10" viewBox="0 0 5 10" fill="none"><path d="M5 0 0 5.22 5 10V0Z"/></svg>')}`)}
            </div>
            <div class="participant-info" index="-1">
                <div class="participant-hover">
                    <img class="participant-icon" role="presentation" src="${t=>i.imageUrl}"/>
                </div>
                <div class="participant-name">${i?.name||""}</div>
                ${(t,e)=>((t,e)=>S.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${(i,r)=>r.parent.getFollowIconTitle(t,e)}"
        @click="${(i,r)=>r.parent.handleClickFollowIcon(r.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:s.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,r)=>r&&r.event&&"Enter"===r.event.key?r.parent.handleClickFollowIcon(r.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:s.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${(t,e)=>e.parent.viewModel.followTelemetryTag}"
    >
    <div class="${t=>e?"icon-add":"icon-selected"}"> ${S.qy.partial(e?$.A:w.A)}</div>
    </div>
`)(i||{},1!=e.parent.viewModel.followedMap?.get(i.satoriId))}
            </div>
            ${(0,y.z)((t,e)=>e.parent.shouldRenderResults(r),((t,e,i)=>S.qy`
    <div class="results ${(e,r)=>r.parent.getScoreLineByIndex(t,i,1)?"":"single"}">
        <div class="${(e,r)=>r.parent.getScoreClassName(t,i)}">
            <span class="score-line1">${(e,r)=>r.parent.getScoreLineByIndex(t,i,0)}</span>
            ${(0,y.z)((e,r)=>r.parent.isScoreMultiLine(t,i),S.qy`
                        <span>${(e,r)=>r.parent.getScoreLineByIndex(t,i,1)}</span>`)}
        </div>
    </div>
`)(t,0,i))}
        </div>
    </div>
`,M=S.qy`
    <div class="cricket-live-detail">
        ${(0,y.z)(t=>t.detailedGameState!=s.Xp.nonlive,S.qy`
            <div class="cricket-live-tag">
                <span class="live-text">${(t,e)=>e.parent.getLiveText(t.detailedGameState)}</span>
            </div>
        `)}
    </div>
`,F=S.qy`
    <div class="game-detail pre-game">
        <div class="game-date">
            ${t=>t.gameDate}
        </div>
        <div class="game-time">
            ${(t,e)=>e.parent.getGameTime(t)}
        </div>
    </div>
`,_=S.qy`
    <div class="game-detail post-game">
        <div class="game-state cricket-final">
            ${(t,e)=>e.parent.viewModel.strings?.sportsVS||"VS"}
        </div>
    </div>
`,D=S.qy`
 <div class="middle-detail">
     ${(t,e)=>{switch(e.parent.getMiddleTemplate(t.detailedGameState)){case"pre":return F;case"post":return _;case"live":return M;default:return""}}}
 </div>
`,E=(S.qy`
<div class="detailed-game-state">
    ${t=>t.detailedGameState}
</div>
`,S.qy`
<div class="detailed-game-state">
    ${t=>s.Xp.postponed}
</div>
`,S.qy`
    <div class="match-detail ${(t,e)=>e.parent.getMiddleTemplateClass(t.detailedGameState)}">
        ${D}
    </div>
`),z=S.qy`  
    <a class="match-content"
        tabindex="0"
        href="${t=>t.matchClickthroughUrl?t.matchClickthroughUrl:void 0}"
        target="${(t,e)=>e.parent.viewModel.linkTarget}"
        data-t="${(t,e)=>e.parent.viewModel.telemetryTag}"
    >
        ${(t,e)=>C(t.gameId||"",!0,e.parent.getParticipant(!0,t)||{},t.detailedGameState)}
        ${E}
        ${(t,e)=>C(t.gameId||"",!1,e.parent.getParticipant(!1,t)||{},t.detailedGameState)}
        <div class="match-footer">${(t,e)=>{return i=e.parent.viewModel.matchSummaryMap.get(t.gameId),S.qy`
    <div>
        <div class="match-extended-details" title="${i||""}">
            ${i||""}
        </div>
    </div>
`;var i}}</div>
    </a>
`,P=S.qy`
    <a class="pin-to-desk-block"
        tabindex="0"
        role="button"
        @click="${t=>t.viewModel.pinToDeskClick&&t.viewModel.pinToDeskClick()}"
        data-t="${t=>t.viewModel.pinToDeskButtonTelemetryTag}"
    >
        <div class="pin-to-desk-des">
            ${t=>t.viewModel.strings.pinToDeskDesc||"Follow the latest games on desktop"}
        </div>
        <div class="pin-to-desk-button">
            ${T}${t=>t.viewModel.strings.pinToDeskButton||"Pin live score"}
        </div>
    </a>
`,I=S.qy`
    ${(0,y.z)(t=>t.viewModel.matchData.length>0,S.qy`
        <div class="match-data ${t=>t.viewModel.cardSize} ${t=>t.viewModel.isIPL?"ipl":""} ${t=>t.viewModel.isExploration?"expl":""}">
            ${(0,b.ux)(t=>t.viewModel.matchData.slice(0,t.viewModel.shouldShowPinToDesk?t.viewModel.showMatchCount-1:t.viewModel.showMatchCount),z,{positioning:!0})}
            ${(0,y.z)(t=>t.viewModel.shouldShowPinToDesk,P)}
        </div>`)}
`,R=S.qy`
    ${(0,y.z)(t=>null!=t.viewModel,I)}
`;let H=class extends l{};H=(0,r.Cg)([(0,p.E)({name:"sports-cricket",template:R,styles:f,shadowOptions:{delegatesFocus:!0}})],H)},22265(t,e,i){i.r(e),i.d(e,{SportsSpotlightCricket(){return b}});var r=i(56911),s=i(71372);class a extends s.a{}var n=i(92011),o=i(59669),l=i(22131),p=i(47810);const c=o.A` .sports-spotlight-content{color:${p.l}}`,d=(0,l.G2)(c),h=o.A` .sports-spotlight-content{text-decoration:none;color:${p.l};display:grid;position:relative;z-index:1;height:100%;margin-top:2px;grid-auto-rows:min-content}._1x_1y.sports-spotlight-content{outline:none}`.withBehaviors(d);var g=i(89757),u=i(69259);const m=g.qy`
<sports-cricket-partnership
    :viewModel="${t=>t.viewModel.partnership}"
></sports-cricket-partnership>
`,v=g.qy`
 ${g.qy`${t=>t.viewModel.matchView}`}
`,x=g.qy`
<player-of-match-card
    :viewModel="${t=>t.viewModel.playerOfMatch}"
    ></player-of-match-card>
`,f=g.qy`
<sports-cricket-recent-matches
    :viewModel="${t=>t.viewModel.recentMatches}"
></sports-cricket-recent-matches>
`,S=g.qy`
    <a
        class="sports-spotlight-content ${t=>t.viewModel.cardSize}"
        href="${t=>t.viewModel.clickThroughUrl}"
        target="_blank"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${v}
        ${x}
        ${(0,u.z)(t=>"_1x_1y"!==t.viewModel.cardSize,m)}
        ${f}
    </a>
`,y=g.qy`
    ${(0,u.z)(t=>null!=t.viewModel,S)}
`;let b=class extends a{};b=(0,r.Cg)([(0,n.E)({name:"sports-spotlight-cricket",template:y,styles:h,shadowOptions:{delegatesFocus:!0}})],b)},99657(t,e,i){i.d(e,{D(){return n},I(){return a}});var r=i(97747);const{create:s}=r.G,a=s("sloppy-click-z-index",1),n=s("click-z-index",1)},70289(t,e,i){i.d(e,{f(){return l}});var r=i(59669),s=i(64187),a=i(38817),n=i(99657),o=i(33113);const l=r.A.partial`position: relative; z-index: ${n.D};`;r.A` ${a.e} ${a.nH} ${(0,s.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${o.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${o.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${o.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(a.kc)}}]);