"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-countdown"],{57309(t,e,n){n.r(e),n.d(e,{SportsCountdownTransformer(){return a}});var i=n(11796),s=n(79811),o=n(41432),r=n(96950);class a extends i.Bc{constructor(){super(...arguments),this.getLeagueIconUrl=t=>{switch(t.cardSize){case o.uE._1x_1y:return(0,s._K)(t.leagueImgUrl,40,40,!0);case o.uE._1x_2y:return(0,s._K)(t.leagueImgUrl,70,70,!0);case o.uE._1x_3y:return(0,s._K)(t.leagueImgUrl,100,100,!0);default:return""}}}async transform(t){const e=this.getViewModel(t);return{viewTemplate:r.qy`
                <sports-countdown
                    :viewModel="${e}"
                ></sports-countdown>`}}getViewModel(t){return{cardSize:t.cardSize,countdownTo:t.countdown?t.countdown?.leagueStartDateTime:t.spotlightData.countdown?.leagueStartDateTime,leagueImgUrl:this.getLeagueIconUrl(t),strings:{...this.transformerProvider.strings},disableTimerContent:this.transformerProvider.config.disableTimerContent,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:i.BP.Countdown})}}}Promise.resolve().then(n.bind(n,19175))},20517(t,e,n){n.d(e,{z(){return r}});var i=n(56911),s=n(60815),o=n(92011);class r extends o.L{}(0,i.Cg)([s.sH],r.prototype,"viewModel",void 0)},19175(t,e,n){n.r(e),n.d(e,{SportsCountdown(){return b}});var i=n(56911),s=n(20517),o=n(60815),r=n(95144);let a=class extends s.z{constructor(){super(...arguments),this.timerTimes=[],this.getTimes=t=>{const e=6e4,n=36e5,i=864e5;return{days:Math.floor(t/i),hours:Math.floor(t%i/n),minutes:Math.floor(t%n/e),seconds:Math.floor(t%e/1e3)}},this.updateWithNewTime=(t,e,n,i)=>{this.timerTimes=[{time:t,title:this.viewModel.strings.days},{time:e,title:this.viewModel.strings.hours},{time:n,title:this.viewModel.strings.minutes},{time:i,title:this.viewModel.strings.seconds}]}}connected(){this.endTimestamp=this.viewModel.countdownTo,this.updateTimerStrings(),this.viewModel.disableTimerContent||!this.endTimestamp?this.updateWithNewTime(0,0,0,0):this.startTimer()}disconnected(){this.stopTimer()}startTimer(){this.endTimestamp&&(this.timerId=window.setInterval(()=>{this.updateTimerStrings()||this.stopTimer()},1e3))}stopTimer(){this.timerId&&(clearInterval(this.timerId),this.timerId=null)}updateTimerStrings(){const t=(new Date).getTime();if(t>this.endTimestamp)return this.updateWithNewTime(0,0,0,0),!1;const e=this.endTimestamp-t,{days:n,hours:i,minutes:s,seconds:o}=this.getTimes(e);return this.updateWithNewTime(n,i,s,o),!0}};(0,i.Cg)([o.sH],a.prototype,"timerTimes",void 0),a=(0,i.Cg)([r.x],a);var c=n(92011),l=n(22131),d=n(74849),p=n(63033);const u=d.A` .countdown-container{background:rgba(255,255,255,0.06)}.timer-box + .timer-box{border-left:solid 1px rgba(255,255,255,0.12)}`,h=d.A` .sports-countdown-content{display:flex;flex-direction:column;justify-content:center;align-content:center}.sports-countdown-content._1x_3y{row-gap:24px;margin-top:45px}.sports-countdown-content._1x_2y{row-gap:6px;margin-top:-10px}.sports-countdown-content._1x_1y{margin-top:-5px}.countdown-container{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;row-gap:4px;margin-right:auto;margin-left:auto;padding:8px 0;border-radius:4px;background:rgba(255,255,255,0.50);backdrop-filter:blur(2px)}._1x_3y .countdown-container{padding:4px 0}.countdown-title{font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height);font-weight:400;font-style:normal;text-align:center}.countdown-content{display:flex;flex-flow:row wrap;justify-content:space-between;list-style:none;padding:2px 0;margin:0}.timer-box{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;font-style:normal;flex:1 1 auto;padding:3px 12px;width:64px;height:40px;box-sizing:border-box}.timer-box + .timer-box{border-left:solid 1px rgba(0,0,0,0.12);line-height:var(--type-ramp-plus-5-line-height)}.timer-value{font-size:var(--type-ramp-plus-2-font-size);line-height:var(--type-ramp-base-line-height);font-weight:600}.timer-title{font-size:var(--type-ramp-minus-2-font-size);line-height:normal;font-weight:400}.upper-content{display:flex;flex-direction:column;justify-content:center;align-content:center;z-index:0}._1x_1y .upper-content{flex-direction:row}.icon-content{display:flex;justify-content:center;align-content:center}.league-icon{display:flex;justify-content:center;align-items:center;background:transparent}._1x_1y .league-icon{width:60px;height:60px;padding:4px}._1x_2y .league-icon{width:90px;height:90px;padding:6px}._1x_3y .league-icon{width:120px;height:120px;padding:8px}.season-description{display:flex;flex-direction:column;row-gap:4px;justify-content:center;align-content:center;text-align:center;font-style:normal}._1x_1y .season-description{text-align:left}.description-header{font-size:var(--type-ramp-plus-3-font-size);line-height:var(--type-ramp-plus-2-line-height);font-weight:600}._1x_1y .description-header{font-size:var(--type-ramp-plus-2-font-size)}.description-text{font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height);font-weight:400}`.withBehaviors(new p.N(null,u),(0,l.mr)(d.A` :host{forced-color-adjust:auto}`));var x=n(96950),g=n(69259),m=n(39957);const f=x.qy`
    <div class="timer-box">
        <div class="timer-value">${t=>t.time>=10?t.time:`0${t.time}`}</div>
        <div class="timer-title">${t=>t.title}</div>
    </div>
`,y=x.qy`
    <div class="countdown-container">
        ${(0,g.z)(t=>"_1x_3y"===t.viewModel.cardSize,x.qy`
            <div class="countdown-title">
                ${t=>t.viewModel.strings.countdownTo}
            </div>
        `)}
        <div class="countdown-content">
            ${(0,m.ux)(t=>t.timerTimes,f)}
        </div>
    </div>
`,v=x.qy`
    <div class="upper-content">
        <div class="icon-content">
            <img class="league-icon" role="presentation" src="${t=>t.viewModel.leagueImgUrl}" alt="league icon"/>
        </div>
        <div class="season-description">
            <div class="description-header">${t=>t.viewModel.strings.newSeasonStarting}</div>
            <div class="description-text">
                ${t=>"_1x_1y"===t.viewModel.cardSize?t.viewModel.strings.checkOutScheduleLong:t.viewModel.strings.checkOutSchedule}
            </div>
        </div>
    </div>
`,w=x.qy`
    <div class="sports-countdown-content ${t=>t.viewModel.cardSize}">
        ${v}
        ${(0,g.z)(t=>"_1x_1y"!==t.viewModel.cardSize,y)}
    </div>
`,_=x.qy`
    ${(0,g.z)(t=>null!=t.viewModel,w)}
`;let b=class extends a{};b=(0,i.Cg)([(0,c.E)({name:"sports-countdown",template:_,styles:h,shadowOptions:{delegatesFocus:!0}})],b)}}]);