"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-results"],{42550(e,t,a){a.r(t),a.d(t,{SportsEventResultsTransformer:()=>p,SportsMatchTransformer:()=>c.SportsMatchTransformer});var i=a(67072),r=a(23305),l=a(87906),s=a(33335),o=a(79811),n=a(33744),d=a(89757);class p extends r.Bc{async transform(e){let t=await this.getViewModel(e);return{viewTemplate:(0,d.qy)`
                <sports-event-results
                    :viewModel="${t}"
                ></sports-event-results>`}}async getViewModel(e){let{telemetryBuilder:t}=this.transformerProvider,a=e.cardSize,i=this.getFirstMatch(e),{sport:d,eventName:p,clickThroughUrl:c}=e.tabData.tabContent,h=await this.getMatchView(e),g=(0,o.jJ)()?i?.sport?.darkImageId:i?.sport?.imageId,v=(0,n.rA)().CurrentMarket,m=this.getHeaderImageFallback();return i||(0,l.vV)(s.Ax,"Sports Event Results error: empty match list",`market=${v}`,e),{tabType:e.tabData.tabType,headerImage:this.buildHeaderIconUrl(g),headerImageFallback:m,teamImageFallback:this.getTeamImageFallback(),sport:d||"",eventName:p,phase:i?.phaseName||"",tabClickUrl:(0,o.Ot)(c),cardSize:a,matchView:h,tableData:this.getTableData(e),winnerSvg:this.getWinnerSvgUrl(),participantOneData:this.getParticipantData(i?.participantOne||{}),participantTwoData:this.getParticipantData(i?.participantTwo||{}),isHeroCard:e.isHeroCard,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsEventResults})}}getFirstMatch(e){return e.matchData[0]?.sportsMatchData}buildTeamIconUrl(e){return e?this.buildIconUrl(e):this.getTeamImageFallback()}buildHeaderIconUrl(e){return e?(0,o._K)(this.buildIconUrl(e),100,100):this.getHeaderImageFallback()}buildIconUrl(e){return(0,o.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced)}getWinnerSvgUrl(){let e=(0,o.jJ)()?"Light":"Dark";return`${(0,n.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2${e}.svg`}getTeamImageFallback(){return`${(0,n.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}getHeaderImageFallback(){return`${(0,n.rA)().StaticsUrl}latest/sports/icons/Olympics2024.svg`}getParticipantData(e){return{imageUrl:this.buildTeamIconUrl(e.imageId),name:e.name,isWinner:(0,o.Hn)(e.isWinner),score:e.score||""}}async getMatchView(e){let t=this.getFirstMatch(e);if(!t||e.tabData.tabType!==r.v1.LeagueEventResultTeamVsTeam)return;let a=e.followedSports||new Map,i=a.get(t.participantOne?.satoriId||"")||a.get(t.participantOne?.yId||"")||!1,l=a.get(t.participantTwo?.satoriId||"")||a.get(t.participantTwo?.yId||"")||!1,s={matchData:{sportsMatchData:t},parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:i,participantTwoFollowed:l,reason:"",showMatchUXV2:!0,noBackgrounds:!0,useLargeTeamIcon:!0,enableLiveScores:this.transformerProvider.config.enableLiveScores};return await this.transformerProvider.generateView(s,r.hi.SportsMatch)}getRowHeight(e){return e.cardSize===i.uE._1x_2y?"28px":e.cardSize===i.uE._1x_3y?"29px":"22px"}getTableData(e){if(e.tabData.tabType!==r.v1.LeagueEventResultOneVsMany)return null;let t=this.getTableKey(e),a=this.getTableBody(e),i=this.getRowHeight(e),l=`repeat(${a.length}, ${i})`;return{telemetryTag:"",cardSize:e.cardSize,isDarkModeTheme:(0,o.jJ)(),tableStyles:this.getTableStyles(e),gridStyles:"width: auto;",data:{keys:t,body:a},columnStyle:`${this.hasRanking(e)?"minmax(auto, 20px)":""} minmax(0, 1fr) minmax(auto, 50px)`,rowStyle:l}}getTableKey(e){return this.hasRanking(e)?["rank","player","score"]:["player","score"]}hasRanking(e){let t=this.getFirstMatch(e),a=t?.participants||[];return!!a.length&&a.some(e=>e.overallRank)}getTableBody(e){let t=this.getFirstMatch(e),a=t?.participants||[];if(!a.length)return(0,l.vV)(s.Ax,"Sports Event Results error: empty participant list",`market=${(0,n.rA)().CurrentMarket}`,e),[];let r=this.getRowCount(e),o=e.cardSize===i.uE._1x_1y,d="font-size: 12px; line-height: 16px; font-weight: 600;",p=o?"icon-20":"icon-24";return a.slice(0,r).map(e=>({rank:{value:e.overallRank,cellClass:"no-border",textStyles:d},player:{icon:this.buildTeamIconUrl(e.imageId),iconClass:p,cellClass:"no-border",value:e.name,textStyles:d+`margin-inline-start: ${o?"6px":"8px"};`},score:{class:"right",cellClass:"no-border",value:e.score||"",textStyles:d}}))}getRowCount(e){return e.cardSize===i.uE._1x_2y?6:e.cardSize===i.uE._1x_3y?11:2}getTableStyles(e){let t=e.isHeroCard?"0px 8px":"2px 8px";return`
            margin-top: 0px;
            padding: ${t};
            background-color: rgba(0, 0, 0, 0);
        `}}var c=a(82724);Promise.resolve().then(a.bind(a,75747)),Promise.resolve().then(a.bind(a,13038)),Promise.resolve().then(a.bind(a,4708))},75747(e,t,a){a.r(t),a.d(t,{SportsEventResults:()=>q});var i=a(56911),r=a(71372),l=a(60815);class s extends r.a{constructor(){super(...arguments),this.isSportsImageUnavailable=!1}isFullCardBg(){return"_1x_1y"!==this.viewModel.cardSize&&(!!this.viewModel.isHeroCard||"OneVsManyEventResult"!==this.viewModel.tabType)}onHeaderImageError(){this.isSportsImageUnavailable=!0}}(0,i.Cg)([l.sH],s.prototype,"isSportsImageUnavailable",void 0);var o=a(92011),n=a(47810),d=a(86856),p=a(70289),c=a(63033),h=a(59669);let g=(0,h.A)` :host{--divider-color:rgba(255,255,255,0.1);--wrap-bg-color:rgba(26,26,26,0.5);--phase-color:rgb(214,214,214);--divider-hero-color:rgb(102,102,102)}`,v=(0,h.A)` .match .win-wrap img{transform:rotate(180deg)}`,m=(0,h.A)` :host{--divider-color:rgba(0,0,0,0.05);--wrap-bg-color:rgba(255,255,255,0.5);--phase-color:rgb(112,112,112);--divider-hero-color:rgba(0,0,0,0.08)}.wrap{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:${n.l};${p.f}}.bg{background:var(--sports-item-background);border-radius:8px}.table{border-radius:8px;margin-top:4px}.table-title{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;width:100%}.sport-icon{width:60px;height:60px;margin-top:16px}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bold{font-weight:600}.sport{font-weight:700;font-size:var(--type-ramp-plus-3-font-size,24px);line-height:var(--type-ramp-plus-3-line-height,32px);margin-top:4px;max-width:calc(100% - 16px)}.event{font-weight:600;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-2-font-size,20px);margin-top:2px;padding-bottom:2px;max-width:calc(100% - 16px)}.divider{margin:8px 0px 8px;width:calc(100% - 16px);height:1px;background-color:var(--divider-color)}.divider-header{width:calc(100% - 16px);height:1px;background-color:var(--divider-hero-color)}.match{width:100%}.match .team-icon{height:20px;width:20px;min-width:20px;margin-inline-end:6px}.match-line{display:flex;justify-content:flex-start;align-items:center;height:20px}.team-name{margin-inline-end:auto}.team-name,.score{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);margin-inline-start:4px}.simple-match-wrap{width:100%;padding:2px 8px;margin-top:4px;box-sizing:border-box}.match .win-wrap img{width:8px;height:8px}.win-wrap{width:14px;min-width:14px;display:flex;align-items:center;justify-content:flex-end}.sm-header{display:grid;grid-template-columns:min-content 1fr min-content;width:100%;column-gap:4px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden}.table .sm-header{width:252px;max-width:252px;margin:6px 8px 4px;display:flex;justify-content:space-between}.sm-sport{font-weight:600}.phase{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);color:var(--phase-color)}.one-v-one{padding:0px 12px 12px;width:100%;box-sizing:border-box}.one-v-one .header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;width:100%}.no-phase .match{height:46px;display:flex;flex-direction:column;justify-content:space-between;margin-top:8px}sports-match{pointer-events:none}._1x_2y.wrap{height:224px}._1x_3y.wrap.v-align-mid{height:334px;margin-top:20px}._1x_3y .one-v-one{padding-top:12px}._1x_1y .one-v-one .header{margin-bottom:4px}._1x_3y .sport-icon{width:108px;height:108px;margin-top:32px}._1x_3y .sport{margin-top:20px}._1x_3y .event{margin-top:6px}._1x_3y .divider{margin:28px 0px 12px}.hero._1x_2y.wrap{height:220px}.hero .table-title{padding:6px 8px;box-sizing:border-box}.hero .table{margin-top:0px}.hero .table .sm-header{margin-top:4px}.hero .divider{margin-bottom:4px;background-color:var(--divider-hero-color)}`.withBehaviors(new d.t(null,v),new c.N(null,g));var x=a(89757),b=a(69259);let w=(0,x.qy)`
    <img src="${e=>e.viewModel.winnerSvg}">
`,u=({score:e,isWinner:t})=>(0,x.qy)`
    <div class="score" title=${t=>e}>${t=>e}</div>
    <div class="win-wrap">
        ${e=>t?w:null}
    </div>
`,y=(0,x.qy)`
    <div class="match">
        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantOneData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantOneData.name}>${e=>e.viewModel.participantOneData.name}</div>
            ${e=>u(e.viewModel.participantOneData)}
        </div>

        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantTwoData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantTwoData.name}>${e=>e.viewModel.participantTwoData.name}</div>
            ${e=>u(e.viewModel.participantTwoData)}
        </div>
    </div>
`,f=(0,x.qy)`
    <img
        src="${e=>e.isSportsImageUnavailable?e.viewModel.headerImageFallback:e.viewModel.headerImage}"
        class="sport-icon"
        @error="${e=>e.onHeaderImageError()}"
    >
    <div class="sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
    <div class="event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
`,$=(0,x.qy)`
    <div class="table bg">
        ${(0,b.z)(e=>"_1x_1y"!==e.viewModel.cardSize,(0,x.qy)`
            <div class="sm-header bold">
                <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
                <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        <sports-table
            :viewModel="${e=>e.viewModel.tableData}"
        ></sports-table>
    </div>
`,M=(0,x.qy)`
    ${f}

    <div class="divider"></div>

    <div class="one-v-one ${e=>e.viewModel.phase?"":"no-phase"}">
        ${(0,b.z)(e=>e.viewModel.phase,(0,x.qy)`
            <div class="header">
                <div class="phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        ${y}
    </div>
`,T=(0,x.qy)`
    <div class="table-title truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
`,k=(0,x.qy)`
    ${e=>"_1x_1y"===e.viewModel.cardSize?S:T}
    ${(0,b.z)(e=>e.viewModel.isHeroCard,(0,x.qy)`<div class="divider-header"></div>`)}
    ${$}
`,z=(0,x.qy)`
    ${f}

    <div class="divider"></div>

    ${(0,b.z)(e=>e.viewModel.matchView,(0,x.qy)`
        <sports-match
            :viewModel="${e=>e.viewModel.matchView?.viewModel}"
        ></sports-match>
    `)}
`,S=(0,x.qy)`
    <div class="sm-header">
        <div class="sm-sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
        <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
        <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
    </div>
`,C=(0,x.qy)`
    ${S}

    <div class="simple-match-wrap bg">
        ${y}
    </div>
`,_=(0,x.qy)`
    <a
        class="wrap ${e=>e.viewModel.cardSize} ${e=>e.isFullCardBg()?"bg v-align-mid":""} ${e=>e.viewModel.isHeroCard?"hero":""}"
        data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.tabClickUrl}"
        target="blank"
    >
        ${e=>((e,t)=>{let a="_1x_1y"===t;switch(e){case"OneVsOneEventResult":return a?C:M;case"OneVsManyEventResult":return k;case"TeamVsTeamEventResult":return a?C:z;default:return null}})(e.viewModel.tabType,e.viewModel.cardSize)}
    </a>
`,I=(0,x.qy)`
    ${(0,b.z)(e=>e&&void 0!=e.viewModel,_)}
`,q=class extends s{};q=(0,i.Cg)([(0,o.E)({name:"sports-event-results",template:I,styles:m,shadowOptions:{delegatesFocus:!0}})],q)},13038(e,t,a){a.r(t),a.d(t,{SportsTable:()=>S});var i=a(56911),r=a(92011),l=a(47810),s=a(62047),o=a(41123),n=a(61138),d=a(86856),p=a(59669),c=a(22131),h=a(70289),g=a(63033);let v=(0,p.A)` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,m=(0,p.A)` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,x=(0,p.A)` .table-container{text-decoration:none}.clickable{${h.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${l.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${l.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${s.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${s.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${s.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${o.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${s.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${o.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${n.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,m),new g.N(null,v),(0,c.mr)((0,p.A)` :host{forced-color-adjust:auto}`));var b=a(89757),w=a(68835),u=a(69259);let y=(0,b.qy)`
    ${e=>void 0!==e.viewModel.data.title?(0,b.qy)`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?(0,b.qy)`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?(0,b.qy)`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,f=(0,b.qy)`
    ${(0,w.ux)(e=>e.getHeaderValues(),(0,b.qy)`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?(0,b.qy)`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,$=(0,b.qy)`
    ${(0,w.ux)(e=>e.getAllBodyCells(),()=>(0,b.qy)`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?(0,b.qy)`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?(0,b.qy)`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?(0,b.qy)`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>(0,b.qy)`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?(0,b.qy)`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>(0,b.qy)`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,M=(0,b.qy)`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?y:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":y}
            <div class="grid-table"
                style="${e=>`
                    grid-template-columns: ${e.viewModel.columnStyle};
                    grid-template-rows: ${e.viewModel.rowStyle};
                    ${e.viewModel.gridStyles};
                `}">
                ${e=>e.getHeaderValues().length>0?f:""}
                ${$}
            </div>
        </div>
    </a>
`,T=(0,b.qy)`
    ${(0,u.z)(e=>void 0!=e.viewModel,M)}
`;var k=a(71372);class z extends k.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{let{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{let e=[],t=this.getKeys();return this.viewModel.data.body.forEach(a=>{t.forEach(t=>e.push(a[t]))}),e}}}let S=class extends z{};S=(0,i.Cg)([(0,r.E)({name:"sports-table",template:T,styles:x,shadowOptions:{delegatesFocus:!0}})],S)}}]);