"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-marchmadness"],{37969(e,t,a){a.r(t),a.d(t,{SportsMatchTransformer(){return g.SportsMatchTransformer},SportsMarchmadnessTransformer(){return u}});var i=a(67072),n=a(23305),s=a(50180);const r="Match",o="Quarterfinal",c="SemiFinal",h="Championship",l="Champion",p=e=>{const t=e?"AA1dH5oj":"AA1dH0n8";return(0,s.GP)("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w={1}&h={2}&q=60&m=6&f=png&u=t",t,"28","30")};var m=a(79811),d=a(89757);class u extends n.Bc{constructor(){super(...arguments),this.getMediumCardMatchCount=()=>{switch(this.uxType){case h:case l:return 1;case c:case o:return 2;default:return 3}},this.getBigCardMatchCount=()=>{switch(this.uxType){case h:case l:return 1;case c:return 2;case o:return 4;default:return 5}},this.getShowMatchCount=()=>{switch(this.cardSize){case i.uE._1x_2y:return this.getMediumCardMatchCount();case i.uE._1x_3y:return this.getBigCardMatchCount();default:return 1}}}async transform(e){const t=await this.getViewModel(e);return{viewTemplate:d.qy`
                <sports-marchmadness
                    :viewModel="${t}"
                ></sports-marchmadness>`}}async getViewModel(e){this.cardSize=e.cardSize;const t=e.matchData[0].sportsMatchData;"string"!=typeof t.gameState&&(t.gameStateCatetory=(0,m.m5)(t.gameState.state));const a=t.gameStateCatetory,i=a===n.Xp.postGame,{bracketPhase:s,league:d}=e.tabContent||{};this.uxType=((e,t)=>{const{league:a}=t||{};return a&&a.contentHeaderLine1&&a.shouldShowContentHeaderImage?a.headerImage?c:o:a&&a.contentHeaderLine1?e===n.Xp.postGame?l:h:r})(a,e.tabContent);const u=(0,m.jJ)(),g=this.getHeaderImage(d.headerImage,i),f=await this.getMatchViews(e);return{bracketIconUrl:p(u),bracketPhase:s,cardSize:this.cardSize,headerImage:g,isPostGame:i,matchClickthroughUrl:this.getMatchClickthroughUrl(t,d),headerLine1:d.contentHeaderLine1,headerLine2:d.contentHeaderLine2,matchViews:f,uxType:this.uxType,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:n.BP.MarchMadnessCard})}}async getMatchViews(e){if(!e.matchData)return;const t=e.followedSports||new Map,a=this.getShowMatchCount(),i=e.matchData.slice(0,a),s=(0,m.Yo)(i),r=this.uxType===h||this.uxType===l,o=e.tabContent?.league?.clickThroughUrl,c=i.map(async a=>{const i=a.sportsMatchData;r&&o&&(i.gameCenterUrl=o);const c=(0,m.gK)(i.participantOne,t),h=(0,m.gK)(i.participantTwo,t),l={matchData:a,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:c,participantTwoFollowed:h,topDetailText:i.matchHeader,isContainLiveMatch:s,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores};return this.transformerProvider.generateView(l,n.hi.SportsMatch)});return(await Promise.all(c)).filter(m.z2)}getIconInfo(e){const t=this.cardSize===i.uE._1x_3y;return e?{width:t?108:70,height:t?108:70}:t?{height:108,width:153}:{height:80,width:114}}getHeaderImage(e,t){if(!e)return"";const a=this.getIconInfo(t);return(0,m.iK)(e,!1,a)}getMatchClickthroughUrl(e,t){return(this.uxType===h||this.uxType===l)&&t?.clickThroughUrl?(0,m.Ot)(t.clickThroughUrl):e.matchClickthroughUrl||""}}var g=a(82724);Promise.resolve().then(a.bind(a,16034)),Promise.resolve().then(a.bind(a,4708))},16034(e,t,a){a.r(t),a.d(t,{SportsMarchmadness(){return k}});var i=a(56911),n=a(20517);class s extends n.z{}var r=a(92011),o=a(47810),c=a(41123),h=a(61138),l=a(70289),p=a(63033),m=a(59669),d=a(22131);const u=m.A` .semifinal-name{color:#FFFFFF}`,g=m.A` .match-data{text-decoration:none;${l.f};display:flex;flex-direction:column;justify-content:space-around}._1x_3y .match-data{justify-content:normal}.match-list{display:flex;flex-direction:column;row-gap:12px}.content{display:grid;gap:12px;height:100%;position:relative}.tournament{display:flex;flex-direction:column;row-gap:40px;justify-content:center}._1x_2y .tournament{row-gap:20px}.header,.semifinal-top-icon,.champ-head{display:flex;align-items:center;justify-content:center;color:${o.l}}._1x_2y .semifinal-top-icon{display:none}.semifinal-top-icon img{height:82px}._1x_2y .header-image{display:none}._1x_3y .header-image{display:flex;justify-content:center}._1x_3y .header-image img{height:82px}.tournament-name{font-size:${c.K};line-height:${c.Z};font-weight:700}.tournament-icon{width:22px;height:18px}.tournament-phase{font-size:${h.k};line-height:${h.F}}.semifinal-icon,.quarterfinal-icon{height:24px}.semifinal-icon img,.quarterfinal-icon img{height:24px}.semifinal-name,.quarterfinal-name{font-size:16px;font-weight:900;line-height:24px;letter-spacing:0px;text-align:center;text-transform:uppercase;margin:0 2px}.icon-right{transform:scale(-1)}.final-header{height:36px}.champ-head{flex-direction:column;text-align:center;row-gap:6px}._1x_3y .champ-head{row-gap:16px;margin-bottom:28px;margin-top:24px}.desc{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);color:${o.l};overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:268px}.top-text{text-align:center;font-size:24px;text-transform:uppercase;font-weight:900;line-height:24px;max-width:268px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.top-text.one-line{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.champ-head.post-game{row-gap:0px}.post-game .desc{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);text-transform:uppercase;font-weight:600}`.withBehaviors(new p.N(null,u),(0,d.mr)(m.A` :host{forced-color-adjust:auto}`));var f=a(89757),x=a(68835),v=a(69259);const w=f.qy`
    <div class="match-list">
        ${(0,x.ux)(e=>e.viewModel.matchViews,f.qy`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,y=f.qy`
    ${(0,v.z)(e=>e.viewModel.headerImage,f.qy`
        <div class="header-image">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />
        </div>`)}
`,$=f.qy`
    <div class="tournament">
        <div>
            ${y}
            <div class="header final-header">
                <div class="quarterfinal-icon">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
                <div class="quarterfinal-name">
                    ${e=>e.viewModel.headerLine1?.toLowerCase()}
                </div>
                <div class="quarterfinal-icon icon-right">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
            </div>
        </div>
        ${w}
    </div>
`,_=f.qy`
    <div class="desc" title="${e=>e.viewModel.headerLine2}">${e=>e.viewModel.headerLine2}</div>
`,b=f.qy`
    <a class="match-data"
        href="${e=>e.viewModel.matchClickthroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}"
        target="_blank"
    >
        <div class="champ-head${e=>e.viewModel.isPostGame?" post-game":""}">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />

            <div>
                <div class="top-text${e=>e.viewModel.headerLine2?" one-line":""}" title="${e=>e.viewModel.headerLine1}">${e=>e.viewModel.headerLine1}</div>
                ${(0,v.z)(e=>e.viewModel.headerLine2,_)}
            </div>
        </div>
        ${w}
    </a>
`,M=f.qy`
    <div class="content ${e=>e.viewModel.cardSize}">
        ${e=>((e,t)=>{if("_1x_1y"===t)return w;switch(e){case"Match":default:return w;case"SemiFinal":case"Quarterfinal":return $;case"Champion":case"Championship":return b}})(e.viewModel.uxType,e.viewModel.cardSize)}
    </div>
`,F=f.qy`
    ${(0,v.z)(e=>null!=e.viewModel,M)}
`;let k=class extends s{};k=(0,i.Cg)([(0,r.E)({name:"sports-marchmadness",template:F,styles:g,shadowOptions:{delegatesFocus:!0}})],k)}}]);