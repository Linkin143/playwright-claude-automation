(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["libs_icons-wc_icons_ThumbDown_svg-libs_icons-wc_icons_ThumbDownFilled_svg-libs_icons-wc_icons-cd7402"],{96016(t,e){"use strict";e.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M12.35 15.85a.5.5 0 0 1-.7 0L6.16 10.4a.55.55 0 0 1 0-.78l5.49-5.46a.5.5 0 0 1 .7.7L7.2 10l5.16 5.15c.2.2.2.5 0 .7Z"/></svg>'},2399(t,e){"use strict";e.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M7.65 4.15c.2-.2.5-.2.7 0l5.49 5.46c.21.22.21.57 0 .78l-5.49 5.46a.5.5 0 0 1-.7-.7L12.8 10 7.65 4.85a.5.5 0 0 1 0-.7Z"/></svg>'},32558(t,e){"use strict";e.A='<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 16.7c.34.98 1.63 1.43 2.43.6.16-.17.33-.36.44-.52.32-.48.45-1.12.5-1.73.05-.63.02-1.3-.05-1.91-.06-.62-.16-1.18-.24-1.59v-.05H12a3 3 0 0 0 2.96-3.54l-.69-3.76A4.5 4.5 0 0 0 8.67.67l-5.6 1.52c-.92.25-1.62 1-1.8 1.92L.9 5.88c-.27 1.39.79 2.56 1.92 3 .32.13.61.3.84.5 1.7 1.5 2.32 2.72 3.38 4.84.36.71.72 1.68 1 2.49Zm1.96-5.58v.01l.01.03a8.94 8.94 0 0 1 .13.58c.08.4.17.92.23 1.5s.09 1.18.04 1.73c-.04.55-.16.98-.34 1.25-.05.1-.17.22-.32.39-.2.2-.63.16-.76-.23-.29-.82-.67-1.83-1.05-2.6-1.07-2.14-1.76-3.5-3.62-5.15-.34-.3-.74-.52-1.13-.68-.89-.34-1.45-1.14-1.3-1.87l.35-1.77c.1-.56.53-1 1.07-1.15l5.6-1.53a3.5 3.5 0 0 1 4.37 2.75l.68 3.76A2 2 0 0 1 12 10.5h-1.5a.5.5 0 0 0-.48.62Z"/></svg>'},56298(t,e){"use strict";e.A='<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48 17.3c-.8.83-2.09.38-2.43-.6-.28-.8-.64-1.77-1-2.48C6 12.1 5.37 10.9 3.67 9.37c-.23-.2-.52-.36-.84-.49C1.7 8.44.63 7.27.9 5.88l.36-1.77a2.5 2.5 0 0 1 1.8-1.92L8.66.66a4.5 4.5 0 0 1 5.6 3.54l.69 3.76A3 3 0 0 1 12 11.5h-.88l.01.05c.08.41.18.97.24 1.58.07.62.1 1.29.05 1.92a3.68 3.68 0 0 1-.5 1.73c-.11.16-.28.35-.44.52Z"/></svg>'},94725(t,e){"use strict";e.A='<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 1.3C8.4.31 9.68-.14 10.48.7c.16.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H12a3 3 0 0 1 2.96 3.54l-.69 3.76a4.5 4.5 0 0 1-5.6 3.53l-5.6-1.52a2.5 2.5 0 0 1-1.8-1.92L.9 12.12c-.27-1.39.79-2.56 1.92-3 .32-.13.61-.3.84-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49Zm1.96 5.58v-.01l.01-.03a9.08 9.08 0 0 0 .13-.58c.08-.4.17-.92.23-1.5s.09-1.18.04-1.73a2.73 2.73 0 0 0-.34-1.25 3.26 3.26 0 0 0-.32-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.89.34-1.45 1.14-1.3 1.87l.35 1.77c.1.56.53 1 1.07 1.15l5.6 1.53c1.98.54 4-.73 4.37-2.75l.68-3.76A2 2 0 0 0 12 7.5h-1.5a.5.5 0 0 1-.48-.62Z"/></svg>'},39677(t,e){"use strict";e.A='<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48.7c-.8-.83-2.09-.38-2.43.6-.28.8-.64 1.77-1 2.48C6 5.9 5.37 7.1 3.67 8.63c-.23.2-.52.36-.84.49-1.13.44-2.2 1.61-1.92 3l.36 1.77a2.5 2.5 0 0 0 1.8 1.92l5.6 1.52a4.5 4.5 0 0 0 5.6-3.53l.69-3.76A3 3 0 0 0 12 6.5h-.88l.01-.05c.08-.41.18-.97.24-1.59.07-.6.1-1.28.05-1.9a3.68 3.68 0 0 0-.5-1.74 4.16 4.16 0 0 0-.44-.52Z"/></svg>'},25854(t,e,a){"use strict";a.d(e,{n(){return T}});var i,n,r,o,s,l,c,d,p=a(13292);(n=i||(i={}))[n.Success=1]="Success",n[n.Error=2]="Error",(o=r||(r={})).LinkedIn="LinkedIn",o.Taboola="Taboola",o.Outbrain="Outbrain",o.Oath="Oath",o.MediaNet="MediaNet",o.MGID="MGID",o.Bing1="Bing1",o.Bing2="Bing2",o.TripleLift="TripleLift",o.Yengo="Yengo",o.AdYouLike="AdYouLike",o.Baidu="Baidu",o.Popin="Popin",o.AppNexus="AppNexus",o.InMobi="InMobi",(l=s||(s={}))[l.LinkedIn=804]="LinkedIn",l[l.Taboola=42]="Taboola",l[l.Outbrain=164]="Outbrain",l[l.Oath=25]="Oath",l[l.MediaNet=142]="MediaNet",l[l.MGID=358]="MGID",l[l.Bing1=1126]="Bing1",l[l.Bing2=1126]="Bing2",l[l.TripleLift=28]="TripleLift",l[l.Yengo=0]="Yengo",l[l.AdYouLike=259]="AdYouLike",l[l.Baidu=1020]="Baidu",l[l.Popin=0]="Popin",l[l.AppNexus=32]="AppNexus",l[l.InMobi=333]="InMobi",(d=c||(c={})).CookieSyncUrl="cookieSyncUrl",d.PixelSync="pixelSync";var g=a(96500),u=a(87906),h=a(40450),b=a(24318),m=a(94108),f=a(29270),v=a(33744),y=a(73632),x=a(72627),$=a(92170),k=a(7446),C=a(68018),w=a(66012),_=a(37521);class T{constructor(t){this.config=t,this.isCookieSyncExecuted=!1,this.cookieSyncExpiryName="CookieSyncExpiry",this.expiryTimeInMillis=2592e5,this.cookieService=new $.O}async processCookieSync(){if(await(0,w._0)())return;if(this.cookieService.getBrowserOptoutStatus())return;const t=this.cookieService.getMsaOptoutCookieData();if(t&&"1"===t)return;const e=this.config&&this.config.cookieSync;if(!e)return;if(!this.config.isCookieSyncEnabled)return;if(this.isCookieSyncExecuted)return;if((0,b.Lg)().supported){const t=new Date,e=(0,b.Lg)().getItem(this.cookieSyncExpiryName);if(e&&t.getTime()<+e+this.expiryTimeInMillis)return}const a=()=>{const t=this.getTCString(),a=Object.keys(e);for(const i of a){const a=(0,_.f)(m.Rb?.CurrentFlightSet?.has(p.Pg));this.partnerCookieHandler(i,e[i],a?"1":"0",t)}};if(window.__tcfapi?await window.__tcfapi("getTCData",2,(t,i)=>{if(i)if(t.gdprApplies){if("tcloaded"===t.eventStatus&&0!=Object.keys(t.vendor.consents).length){const a=Object.keys(e);for(const i of a){const a=(0,f.MI)(),{geo_country:n}=a;("CN"===(n?.toUpperCase()??"")&&["hongjing","songheng"].includes(i.toLowerCase())||t.vendor.consents[s[i]])&&this.partnerCookieHandler(i,e[i],t.gdprApplies?"1":"0",t.tcString)}}}else a();else g.v.log("tcData fectch failed")}):a(),(0,b.Lg)().supported){const t=(new Date).getTime();(0,b.Lg)().setItem(this.cookieSyncExpiryName,t.toString())}k.YT.sendClientLogEvent({message:`processed cookie sync. Locale: ${m.Rb.Locale}, AppType: ${v.T3.AppType}`,type:"information"}),this.isCookieSyncExecuted=!0}getTCString(){const t="eupubconsent-v2=",e=decodeURIComponent(document.cookie).split(";");for(let a=0;a<e.length;a++){const i=e[a].trim();if(0==i.indexOf(t))return i.substring(16).trim()}return""}async partnerCookieHandler(t,e,a,i){if(e&&e.cookieSyncUrl)try{this.disableSyncForPartner(t)||(!0===e.pixelSync?this.callPixelSync(t,e,a,i):this.downloadScript(e.cookieSyncUrl))}catch{k.YT.sendAppErrorEvent((0,u.$5)(h.A0k,`Cookie sync error while calling ${t}`))}else k.YT.sendAppErrorEvent((0,u.$5)(h.MpT,`${t} is missing cookie sync url`))}disableSyncForPartner(t){const e=t.toLocaleLowerCase(),a=m.Rb?.Locale?.toLowerCase()||"";if(["linkedin","bing1","bing2"].includes(e))return!1;if("taboola"===e){const t=["en-us","ja-jp","ko-kr"];return m.Rb?.CurrentFlightSet?.has("prg-ad-no-tabl")||!t.includes(a)}if("popin"===e){return!["ja-jp","ko-kr"].includes(a)}if("baidu"===e){return!["zh-cn","zh-hk","ja-jp","ko-kr"].includes(a)}if("hongjing"===e||"songheng"===e){return!["zh-cn"].includes(a)}return!0}async downloadScript(t){if(!t||!(0,y.S)())return;if(this.scriptAlreadyExists(t))return;const e=(0,x.C7)(t);e.onload=()=>{k.YT.sendClientLogEvent({message:`Successfully downloaded cookie sync script: ${t}`,type:"information"})},e.onerror=e=>{k.YT.sendAppErrorEvent((0,u.$5)(h.B8p,"Failed to download cookie sync JS",`source url: ${t}, error: ${e}`))},document.head.appendChild(e)}async callPixelSync(t,e,a,i){if(t){const t=this.formatPixelSyncUrl(e.cookieSyncUrl,a,i);this.fireImagePixel(t)}}formatPixelSyncUrl(t,e,a){if(location.href.toLowerCase().indexOf("native-ad.html")>-1){document.getElementsByTagName("head")[0].setAttribute("data-client-settings",'{"pagetype": "gallery", "browser": {"browserType":"chrome", "version":"62", "ismobile":"true"}, "locale":{"language":"en", "market":"us"}, "aid": "activity1"}'),m.Rb.initializeHeadData()}let i=0;m.Rb.ClientSettings&&m.Rb.ClientSettings.browser&&m.Rb.ClientSettings.browser.ismobile&&(i=1);let n=t.replace("<rid>",m.Rb.ClientSettings&&m.Rb.ClientSettings.aid?m.Rb.ClientSettings.aid:"").replace("<lang>",m.Rb.Locale?m.Rb.Locale:"").replace("<dgk>",m.Rb.ClientSettings&&m.Rb.ClientSettings.browser&&m.Rb.ClientSettings.browser.browserType?m.Rb.ClientSettings.browser.browserType:"").replace("<imd>",i.toString()).replace("<pn>",m.Rb.ClientSettings&&m.Rb.ClientSettings.pagetype?m.Rb.ClientSettings.pagetype:"").replace("<rf>",document.referrer).replace("<tp>",location.href).replace("<gdpr>",e).replace("<gdpr_consent>",a);const r=(0,C.ab)();return n=r?n.replace("<userid>",r):n.replace("<userid>",""),n}scriptAlreadyExists(t){const e=document.getElementsByTagName("script");for(let a=e.length;a--;)if(e[a].src===t)return!0;return!1}fireImagePixel(t){let e=new Image(1,1);e.src=t,e=null}}},37521(t,e,a){"use strict";a.d(e,{f(){return r}});var i=a(29270),n=a(47211);function r(t=!1){let e=!1;const a=(0,i.MI)(),{geo_country:r,geo_subdivision:o}=a,s=r?.toUpperCase()??"",l=o?.toUpperCase()??"",c=t?n.lR:n.XD;return s&&c.includes(s)&&("CA"===s&&"QUEBEC"!==l||(e=!0)),e}},66728(t,e,a){"use strict";a.d(e,{Jl(){return n},NZ(){return o},Om(){return r},ZO(){return l},eM(){return s}});var i=a(40450);(0,i.KR6)(53e3,i.XkX),(0,i.KR6)(53001,i.XkX),(0,i.KR6)(53002),(0,i.KR6)(53003),(0,i.KR6)(53004),(0,i.KR6)(53005,i.XkX),(0,i.KR6)(53006,i.XkX),(0,i.KR6)(53007,i.XkX),(0,i.KR6)(53008),(0,i.KR6)(53009),(0,i.KR6)(53010,i.XkX),(0,i.KR6)(53011,i.XkX),(0,i.KR6)(53012),(0,i.KR6)(53013,i.XkX),(0,i.KR6)(53014,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(53015,i.XkX),(0,i.KR6)(53016,i.XkX),(0,i.KR6)(53031,i.XkX),(0,i.KR6)(53032,i.XkX),(0,i.KR6)(53050),(0,i.KR6)(53051),(0,i.KR6)(53055),(0,i.KR6)(53062),(0,i.KR6)(53063),(0,i.KR6)(53064),(0,i.KR6)(53065),(0,i.KR6)(53099),(0,i.KR6)(53151,i.XkX),(0,i.KR6)(53156,i.XkX),(0,i.KR6)(53161,i.XkX),(0,i.KR6)(54001,i.XkX),(0,i.KR6)(54002),(0,i.KR6)(54003),(0,i.KR6)(54004),(0,i.KR6)(54005),(0,i.KR6)(54006,i.XkX),(0,i.KR6)(54007),(0,i.KR6)(54008),(0,i.KR6)(54009),(0,i.KR6)(54010),(0,i.KR6)(54011),(0,i.KR6)(54012),(0,i.KR6)(54013),(0,i.KR6)(54014),(0,i.KR6)(54015),(0,i.KR6)(54016),(0,i.KR6)(54017),(0,i.KR6)(54101,i.XkX),(0,i.KR6)(54102,i.XkX),(0,i.KR6)(54103),(0,i.KR6)(54104),(0,i.KR6)(54105),(0,i.KR6)(54106),(0,i.KR6)(56014),(0,i.KR6)(56015),(0,i.KR6)(56016),(0,i.KR6)(56017),(0,i.KR6)(56018),(0,i.KR6)(56019),(0,i.KR6)(56020),(0,i.KR6)(56021),(0,i.KR6)(56022),(0,i.KR6)(56023),(0,i.KR6)(56024),(0,i.KR6)(56025),(0,i.KR6)(56026),(0,i.KR6)(56027),(0,i.KR6)(56028),(0,i.KR6)(56029),(0,i.KR6)(56030),(0,i.KR6)(56031),(0,i.KR6)(56032),(0,i.KR6)(56033),(0,i.KR6)(56034),(0,i.KR6)(56035),(0,i.KR6)(56036),(0,i.KR6)(56037),(0,i.KR6)(60301,i.XkX),(0,i.KR6)(60302),(0,i.KR6)(60303),(0,i.KR6)(60304),(0,i.KR6)(60305),(0,i.KR6)(60306);const n=(0,i.KR6)(70100),r=(0,i.KR6)(70101),o=((0,i.KR6)(70102,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(70103)),s=((0,i.KR6)(70104),(0,i.KR6)(70105),(0,i.KR6)(224500,i.XkX,(0,i.N5g)(!0))),l=((0,i.KR6)(224501),(0,i.KR6)(224502))},2274(t,e,a){"use strict";a.d(e,{CI(){return p},bP(){return u},cX(){return g},gR(){return h}});var i=a(96500),n=a(10316);const r="DEFAULT";let o;const s=t=>o=setTimeout(t,200),l={},c={},d={};function p(t,e=r){const a=l[e];if(a&&a.has(t)){(()=>a&&a.delete(t)&&0===a.size&&c[e])()&&s(()=>0===a.size&&c[e](null)),n.M.singleMark(t),i.v.log(`[vpreadyHelper] resolveVpMark ${t} scope ${e} remainingMarkers ${a.size}`)}}function g(t,e=r){o&&clearTimeout(o),l[e]||(l[e]=new Set),l[e].add(t),i.v.log(`[vpreadyHelper] addVpMarker ${t} scope ${e} remainingMarkers ${l[e].size}`)}function u(t=r){return l[t]}function h(t=r){return d[t]=d[t]||new Promise(e=>{c[t]=e}),d[t]}},73559(t,e,a){"use strict";a.d(e,{BQ(){return x},R0(){return u},eW(){return y},mO(){return v},ns(){return f},qq(){return g},wT(){return b},zZ(){return h}});var i=a(61473),n=a(7446),r=a(62514),o=a(35150),s=a(40450),l=a(33744),c=a(98794),d=a(89757),p=a(94172);const g={[r.C.bingDailyQuizCard]:"bingDailyQuizCard",[r.C.casualGamesCard]:"casualGamesCard",[r.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[r.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[r.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[r.C.communityCard]:"communityCard",[r.C.dailyBriefCard]:"dailyBriefCard",[r.C.dailyGreetingCard]:"dailyGreetingCard",[r.C.dailyMomentsCard]:"dailyMomentsCard",[r.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[r.C.dailyWonderQuoteCard]:"dailyWonderCopilotCard",[r.C.donationNpoCard]:"donationNpoCard",[r.C.electionCard]:"electionCard",[r.C.entertainmentPremierCard]:"entertainmentPremierCard",[r.C.esportsCard]:"esportsCard",[r.C.healthCard]:"bingHealthCard",[r.C.horoscopeAnswerCard]:"horoscopeCard",[r.C.hotListCard]:"hotListCard",[r.C.mangaCard]:"mangaCard",[r.C.mangaCarousel]:"mangaCarousel",[r.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[r.C.onThisDayCard]:"onThisDayCard",[r.C.prismCarouselCard]:"prismCarouselCard",[r.C.qnaCard]:"qnaCard",[r.C.realEstateCard]:"realEstateCard",[r.C.recipesCard]:"recipesCard",[r.C.richCalendarCard]:"richCalendarCard",[r.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[r.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[r.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[r.C.shoppingCarouselCard]:"shoppingCarousel",[r.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[r.C.shoppingRiverCard]:"shoppingRiverCard",[r.C.shoppingSdCard]:"shoppingSdCard",[r.C.topCommentsCard]:"topCommentsCard",[r.C.trendingNowCard]:"trendingNowWC",[r.C.trendingSearchCard]:"trendingSearchCard",[r.C.weatherCard]:"weatherCard",[r.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[r.C.winAppCard]:"winAppCard"},u={[r.C.bingDailyQuizCard]:"bingDailyQuizCard",[r.C.boostAdCard]:"boostAdCard",[r.C.casualGamesCard]:"casualGamesCard",[r.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[r.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[r.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[r.C.communityCard]:"communityCard",[r.C.contentGroupCard]:"contentGroupCard",[r.C.creatorPromotionCarousel]:"watchCreatorPromotionCarousel",[r.C.creatorSpotlightCard]:"creatorSpotlightCard",[r.C.dailyBriefCard]:"dailyBriefCard",[r.C.dailyGreetingCard]:"dailyGreetingCard",[r.C.dailyMomentsCard]:"dailyMomentsCard",[r.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[r.C.dailyWonderQuoteCard]:"dailyWonderQuoteCard",[r.C.donationNpoCard]:"donationNpoCard",[r.C.electionCard]:"electionCard",[r.C.entertainmentPremierCard]:"entertainmentPremierCard",[r.C.entertainmentTakeover]:"watchEntertainmentTakeover",[r.C.esportsCard]:"esportsCard",[r.C.healthCard]:"bingHealthCard",[r.C.healthRiverCard]:"healthRiverCard",[r.C.healthTipCard]:"healthTipCard",[r.C.horoscopeAnswerCard]:"horoscopeCard",[r.C.hotListCard]:"hotListCard",[r.C.mangaCard]:"mangaCard",[r.C.mangaCarousel]:"mangaCarousel",[r.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[r.C.onThisDayCard]:"onThisDayCard",[r.C.prismCarouselCard]:"prismCarouselCard",[r.C.qnaCard]:"qnaCard",[r.C.quizCard]:"quizCard",[r.C.realEstateCard]:"realEstateCard",[r.C.recipesCard]:"recipesCard",[r.C.richCalendarCard]:"richCalendarCard",[r.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[r.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[r.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[r.C.shoppingCarouselCard]:"shopping-carousel",[r.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[r.C.shoppingRiverCard]:"shoppingRiverCard",[r.C.shoppingSdCard]:"shoppingSdCard",[r.C.shoppingTopSectionCard]:"shoppingTopSectionCard",[r.C.topCommentsCard]:"topCommentsCard",[r.C.trendingNowCard]:"trendingNowCard",[r.C.trendingSearchCard]:"trendingSearchCard",[r.C.weatherCard]:"weather",[r.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[r.C.winAppCard]:"winAppCard"},h=(t,e)=>{if(!e)return t;let a="";if("ext"in e.contract){const t=e.contract.ext;a=`${t.row}_${t.col}`}return`${t}_${a}`},b=d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{properties:{wpoMetadata:t.wpoMetadata,mapperArgs:t.mapperArgs,parentTelemetry:t.telemetryObject,feedLayoutCardSize:t.cardSize,hasLoadedCallback:t.hasLoadedCallback,cardType:t.cardType},attributes:{style:`grid-area:${t.gridArea};width:${t.mapperArgs?.displaySettings?.cardWidth}px;contain:unset;content-visibility:visible;`,class:`${t.cardSize}`,tabindex:t.customTabIndex??!1},telemetryObject:t.telemetryObject})}
`;function m(t){const e=t.configInfo?.configRef?.experienceType;return e===i.yXx||e===i.Ohn?";width:100%":""}d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{properties:{mapperArgs:t.mapperArgs,feedLayoutCardSize:t.cardSize},attributes:{style:`grid-area:${t.gridArea};`,class:`${t.cardSize}`,tabindex:t.customTabIndex??!1},telemetryObject:t.telemetryObject})}
`;const f=d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{attributes:{style:`grid-area:${t.gridArea}${m(t)}`,class:`${t.cardSize}`,tabindex:t.customTabIndex??!1},properties:{mapperArgs:t.mapperArgs,feedLayoutCardSize:t.cardSize},telemetryObject:t.telemetryObject})}
`,v=(d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{properties:{mapperArgs:t.mapperArgs,feedLayoutCardSize:t.cardSize,hasLoadedCallback:t.hasLoadedCallback},attributes:{style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible;`,class:`${t.cardSize}`,tabindex:t.customTabIndex??!1},telemetryObject:t.telemetryObject,memoize:"edgeChromium"===l.T3.AppType})}
`,d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{properties:{mapperArgs:t.mapperArgs,cardMetadata:t.mapperArgs?t.mapperArgs.cardMetadata.data:null,feedLayoutCardSize:t.cardSize,hasLoadedCallback:t.hasLoadedCallback},attributes:{style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible;`,tabindex:t.customTabIndex??!1},telemetryObject:t.telemetryObject,memoize:"edgeChromium"===l.T3.AppType})}
`),y=d.qy`
    ${t=>t.configInfo&&(0,p.yN)({...t.configInfo,instanceId:`${h(t.configInfo.instanceId,t.telemetryObject)}`},{properties:{mapperArgs:t.mapperArgs,feedLayoutCardSize:t.cardSize,hasLoadedCallback:t.hasLoadedCallback},attributes:{style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible;`,class:`${t.cardSize}`,tabindex:t.customTabIndex??!1},telemetryObject:t.telemetryObject,memoize:!1})}
`,x=(t,e)=>{const{configOptions:a,cardMetadata:i,hasLoadedCallback:r}=t;e||(e=o.G[i.type]),e||n.YT.sendAppErrorEvent({...s.ODw,message:"No card template type found",pb:{...s.ODw.pb,cardType:i.type}});const l=u[e],d={id:l,childTemplateType:e,mapperArgs:t,configInfo:a,hasLoadedCallback:r,cardType:i?.cardType};return(0,c.bw)({id:l,experienceType:(a&&a)?.configRef?.experienceType,mapperArgs:t},d,null,!0)}},83488(t,e,a){"use strict";a.d(e,{i(){return g},z(){return p}});var i=a(87906),n=a(40450),r=a(44978),o=a(69828),s=a(62514),l=a(98794),c=a(72287),d=a(82368);function p(t){const{cardMetadata:e,parentTelemetryObject:a,configOptions:s,layoutTemplateName:p,getReplacementCardsCallback:g,refreshFeedCallback:u,goToPersonalizeCallback:h,visualReadinessCallback:b,isArticleFreInInfoPane:m,cardActionClickHandler:f}=t,v=s&&s.childExperienceReferencesWC?s.childExperienceReferencesWC.articleFreCard:s;let y=[];y=e.subItems&&e.subItems.length?e.subItems:e.subCards,e.subCards=y,e.subItems=void 0;const x=(0,c.H8)(e,(r.J.dismiss<<1)-1),$=0!==(x&r.J.dismiss)?(0,d.Eb)(t,x,e.id,a):{id:e.id,childTemplateType:"article-fre-card",articleFreConfigInfo:v,parentTelemetryObject:a,subCards:y,getReplacementCardsCallback:g,refreshFeedCallback:u,goToPersonalizeCallback:h,cardActionClickHandler:f,visualReadinessCallback:b,isArticleFreInInfoPane:m};return(0,l.bw)({id:e.id,experienceType:v?.configRef?.experienceType,mapperArgs:t},$,(t,e)=>{const a=e.cardSize;return a!==o.uE._1x_2y&&a!==o.uE._2x_2y&&(0,i.vV)(n.Qhr,`Article Fre Card mapped as ${a} on ${t} in ${p}`),{}},!0)}function g(t,e){if(e===s.C.articleFreCard)return!0;if(e===s.C.recommendedInterestsCard)return!0;if(e===s.C.infopaneCard){let e=[];e=t.subItems&&t.subItems.length?t.subItems:t.subCards;for(const t of e)if("ArticleFre"===t.type&&"FreFeed"===t.id)return!0}return!1}},10371(t,e,a){"use strict";a.d(e,{Q(){return n}});var i=a(2375);const n=a(89757).qy`
    <fluent-card
        style="${t=>t.isArticleFreInInfoPane?"":"grid-area: "+t.gridArea}"
        class="${t=>t.cardSize}"
    >
        <article-fre
            config-instance-src=${t=>t.articleFreConfigInfo&&(0,i.v)(t.articleFreConfigInfo)}
            config-shared-ns=${t=>t.articleFreConfigInfo&&t.articleFreConfigInfo.configRef&&t.articleFreConfigInfo.configRef.sharedNs}
            instance-id=${t=>t.articleFreConfigInfo&&t.articleFreConfigInfo.instanceId}
            size=${t=>t.cardSize}
            :parentTelemetry=${t=>t.parentTelemetryObject}
            :subCards=${t=>t.subCards}
            :getReplacementCardsCallback=${t=>t.getReplacementCardsCallback}
            :refreshFeedCallback=${t=>t.refreshFeedCallback}
            :goToPersonalizeCallback=${t=>t.goToPersonalizeCallback}
            :visualReadinessCallback=${t=>t.visualReadinessCallback}
            :cardActionClickHandler=${t=>t.cardActionClickHandler}
        >
        </article-fre>
    </fluent-card>
`},59409(t,e,a){"use strict";a.d(e,{D(){return n},H(){return r}});var i=a(73559);const n={getFeedDataForCard(t){const e=t;return t.cardMetadata.renderFromHomePage&&(e.cardSlot.layouts={C4:"_1x_2y",C3:"_1x_2y",C2:"_1x_2y"}),e.cardMetadata.cardType=t?.activeBoard?`${t.cardMetadata.type}_${t?.activeBoard}`:t.cardMetadata.type,(0,i.BQ)(e)},viewTemplate:i.wT},r=i.wT},42537(t,e,a){"use strict";a.d(e,{B(){return x},f(){return y}});var i,n=a(40201),r=a(11803),o=a(69828),s=a(35177),l=a(62679),c=a(44776),d=a(26330),p=a(47517),g=a(60124),u=a(89757),h=a(69259),b=a(44978),m=a(86294),f=a(77833),v=a(9960);m.j,function(t){t.Long="long",t.Short="short"}(i||(i={}));const y=u.qy`
    <msft-article
        id="contentcard_${t=>t.id}"
        href=${t=>t.destinationUrl}
        target=${t=>t.openLinksInNewTab||t.openArticleInNewTab?"_blank":t.defaultAnchorTarget||"_self"}
        title=${t=>t.disableCardTitleTooltip?"":t.title}
        class="${t=>$(t)}"
        direction="${t=>t.dir}"
        :handleContentCardClickOverride=${t=>t.handleContentCardClickOverride}
        image-position=${t=>t.imagePosition?t.imagePosition:"end"}
        data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}"
        :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
        @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
        @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
        data-content-id=${t=>t.id}
        >
        ${(0,h.z)(t=>t.contentIndicator,t=>(0,n.Z)(t.contentIndicator))}
        ${(0,h.z)(t=>t.imageData,u.qy`
            <div slot="image" style="height: ${t=>t.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;">
            ${(0,h.z)(t=>t.isBlurred,u.qy`
                    <img
                        alt="${t=>t.imageData.altText}"
                        src="${t=>t.imageData.blurredSource}"
                        height="${t=>t.imageData.imageHeight}"
                        width="${t=>t.imageData.imageWidth}"
                        @load="${t=>t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback()}"
                        style="position: absolute; z-index: -1; filter: blur(50px);"
                    />
                `)}
                <img
                    alt="${t=>t.imageData.altText}"
                    src="${t=>t.imageData.source}"
                    height="${t=>t.imageData.imageHeight}"
                    width="${t=>t.imageData.imageWidth}"
                    @load="${t=>{t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(t.isBlurred?1:3,r.j.image)}}"
                />
            </div>
        `)}
        ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}}
        ${(0,h.z)(t=>t.feedFontSize,u.qy`
            ${(0,h.z)(t=>(t.cardSize===o.uE._1x_2y||t.cardSize===o.uE._1x_1y)&&t.imageData,u.qy`
                <span style="font-size: ${t=>t.feedFontSize}px; ${t=>t.headingLineHeight?`line-height: ${t.headingLineHeight}px`:""}">
                    ${t=>t.title}
                </span>`)}
            ${(0,h.z)(t=>t.cardSize===o.uE._2x_2y,u.qy`
                <span style="font-size: ${t=>t.twoColumnFeedFontSize||t.largeFeedFontSize||t.feedFontSize}px; ${t=>t.twoColumnHeadingLineHeight?`line-height: ${t.twoColumnHeadingLineHeight}px`:""}">
                    ${t=>t.title}
                </span>`)}
            ${(0,h.z)(t=>(t.cardSize===o.uE._1x_2y||t.cardSize===o.uE._1x_1y)&&!t.imageData,u.qy`<span style="font-size: ${t=>t.noImageFeedFontSize||t.feedFontSize}px;">${t=>t.title}</span>`)}
        `)}
        ${(0,h.z)(t=>!t.feedFontSize,u.qy`
            ${(0,h.z)(t=>!t.useLargeFontSize,u.qy`${t=>t.title}`)}
            ${(0,h.z)(t=>t.useLargeFontSize,u.qy`<span class="title${t=>t.cardSize}">${t=>t.title}</span>`)}
        `)}
        ${(0,h.z)(t=>k(t),u.qy`
            <p slot="abstract">${t=>t.abstract}</p>
        `)}
        ${(0,h.z)(t=>t.badge&&t.cardSize!==o.uE._1x_1y,t=>(0,s.w)(t.badge))}
        ${(0,h.z)(t=>t.providerData&&!t.isPublisherPage&&(!t.enableInfopaneLike2cCard||t.cardSize!==o.uE._2x_2y),l.vJ)}
        ${(0,h.z)(t=>t.isPublisherPage&&t.userSubscriptionData&&"Premium"==t.metadata?.subscriptionProductType,u.qy`
            <msn-subscription-badge
                slot="attribution"
                :userSubscriptionData="${t=>t.userSubscriptionData}"
                :cardSize="${t=>t.cardSize}"
            >
            </msn-subscription-badge>
        `)}
        <div slot="start-action" class="infopane-like-start-actions">
            ${(0,h.z)(t=>t.providerData&&t.enableInfopaneLike2cCard&&t.cardSize===o.uE._2x_2y,l.vJ)}
            ${(0,h.z)(t=>(!t.enableInfopaneLike2cCard||t.cardSize!==o.uE._2x_2y)&&(!t.isAnaheimDesign||t.enableRichSocialReaction),u.qy`
                ${(0,h.z)(t=>t.enableRichSocialReaction,t=>(0,c.nj)({}))}
                ${(0,h.z)(t=>t.cardActionStatus&b.J.enabled&&!t.enableRichSocialReaction,u.qy`
                    ${c.LW}
                    ${(0,h.z)(t=>!(t.cardActionStatus&b.J.showMore),c.tB)}
                `)}
            `)}
        </div>
        <div slot="end-action" class="infopane-like-end-actions">
            ${(0,h.z)(t=>t.enableRichSocialReaction&&t.enableInfopaneLike2cCard&&t.cardSize===o.uE._2x_2y,(0,c.nj)({}))}
            ${(0,h.z)(t=>t.cardActionStatus&b.J.enabled,u.qy`
                ${(0,h.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,u.qy`
                    ${(0,h.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&b.J.showMore,c.LW)}
                    ${(0,h.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&b.J.showFewer,c.tB)}
                `)}
                ${(0,h.z)(t=>t.enableWCCardAction,d.L)}
            `)}
        </div>
        ${(0,h.z)(t=>!t.disableHideOnHover&&t.cardActionStatus&b.J.enabled&&!t.isWebContent,p.C)}
    </msft-article>
`,x=u.qy`
<style>
    .card-button {
        border-radius: 100%;
    }

    @media (forced-colors:active) {
        .card-button {
            background: none;
        }

        msn-social-bar::part(button-bg),
        msn-social-bar::part(reactions-count-button),
        msn-social-bar::part(comments-count-button) {
            color: buttontext;
            background-color: buttonface;
        }

        msn-social-bar::part(button-bg):hover,
        msn-social-bar::part(button-bg):focus-visible,
        msn-social-bar::part(reactions-count-button):hover,
        msn-social-bar::part(reactions-count-button):focus-visible,
        msn-social-bar::part(comments-count-button):hover,
        msn-social-bar::part(comments-count-button):focus-visible {
            color: buttonface;
            background-color: highlight;
        }
    }

    @media (forced-colors: active) {
        @media (prefers-color-scheme: dark) {
            msft-article#contentcard_${t=>t.id} msft-content-indicator svg[width="40"] path {
                fill: rgb(0, 0, 0);
            }
        }
    }

    @media (prefers-color-scheme: dark) {
        msft-article#contentcard_${t=>t.id} {
            --article-background-color: ${t=>t.articleCardBackgroundColor?.find(t=>t.isDarkMode)?.hexColor};
        }
    }

    @media (prefers-color-scheme: light) {
        msft-article#contentcard_${t=>t.id} {
            --article-background-color: ${t=>t.articleCardBackgroundColor?.find(t=>!t.isDarkMode)?.hexColor};
        }
    }

    msft-article-card[size$="x_2y"] msft-article::part(heading):after {
        top: calc(100% - ${t=>t.fixedCardHeight?304:292+(t.layoutGap||12)}px) !important;
    }

    msft-article.no-image::part(heading) {
        font-size: var(--msft-article-heading-font-size, 20px);
        line-height: var(--msft-article-heading-line-height, 28px);
    }

    msft-article-card msft-content-indicator {
        pointer-events: none;
    }

    msft-article-card[size="_1x_1y"] msft-article[direction="rtl"]:not(.no-image) msft-content-indicator{
        right: 204px;
        left: auto;
    }

    msft-article-card[size="_1x_1y"] msft-article:not(.no-image) msft-content-indicator{
        top: 18px;
        left: 204px;
    }

    ${(0,h.z)(t=>t.contentType===f.pL.Video,u.qy`
        msft-article-card msft-article msft-content-indicator {
            color: transparent;
        }
        msft-article-card msft-article msft-content-indicator::after{
            background: transparent;
        }

        msft-article-card[size="_1x_1y"] msft-article msft-content-indicator{
            left: 233px !important;
            top: 44px !important;
        }

        msft-article-card[size="_1x_2y"] msft-article msft-content-indicator{
            left: 130px;
            top: 88px;
        }

        msft-article-card[size="_2x_2y"] msft-article msft-content-indicator{
            left: 286px;
            top: 88px;
        }

        msft-article-card[size$="x_2y"] msft-article.no-image msft-content-indicator::part(icon-container) {
            min-width: 40px;
        }

        ${(0,h.z)(t=>"rtl"==t.dir,u.qy`
            msft-article-card[size="_1x_1y"] msft-article msft-content-indicator{
                right: 233px !important;
                top: 44px !important;
            }

            msft-article-card[size="_1x_2y"] msft-article msft-content-indicator{
                right: 130px;
                top: 88px;
            }

            msft-article-card[size="_2x_2y"] msft-article msft-content-indicator{
                right: 286px;
                top: 88px;
            }
        `)}
    `)}

    msft-article-card[size="_1x_2y"] msft-article.no-image msft-attribution {
        margin-bottom: 18px;
    }

    msft-article.long-gradient::part(gradient) {
        top: -55px;
    }

    /* TODO: These hard-coded styles will be cleaned up later as tracked in this task:
     * Task 3620803 - [Anaheim] Migrate article card to an independent wc or wce
     * https://msasg.visualstudio.com/ContentServices/_workitems/edit/3620803
     */
    ${(0,h.z)(t=>t.isAnaheimDesign&&!t.enableVerticalGradientCard&&!t.isInfopane&&t.isImage43,u.qy`
        msft-article-card[size="_2x_2y"].contentCard msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient( ${t=>t.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 60px, var(--gradient-color) 96px );
            width: 344px;
        }
    `)}

    ${(0,h.z)(t=>t.isAnaheimDesign&&!t.enableVerticalGradientCard&&t.isInfopane&&t.isImage43,u.qy`
        msft-article-card[size="_2x_2y"].infopane msft-article:not(.no-image)::part(gradient) {
            /* Merged two linear-gradient into one:
             * 1. linear-gradient(270deg, rgba(122, 84, 80, 0) 0%, rgba(122, 84, 80, 0.8) 100%); on the element with width 60px
             * 2. linear-gradient(270deg, rgba(122, 84, 80, 0.8) 0%, #7A5450 46.88%); on one element with width 77px
             */
            background: linear-gradient( ${t=>t.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 60px, var(--gradient-color) 96px );
            width: 344px;
        }
    `)}

    ${(0,h.z)(t=>t.isAnaheimDesign&&t.enableVerticalGradientCard||t.enableLinearFeed2cVerticalGradientCard,u.qy`
        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-article::part(heading) {
            line-height: var(--heading-line-height, 28px);
        }

        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(heading) {
            margin-bottom: 40px;
        }

        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient( 180deg, transparent 0%, var(--gradient-mid-color) 62.5%, var(--gradient-color) 100% );
            width: 100%;
        }

        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(text) {
            height: auto;
            width: 100%;
        }

        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(attribution) {
            display: flex;
            align-self: end;
        }

        msft-article-card[size="_2x_2y"].${t=>t.isInfopane?"infopane":"contentCard"} msft-attribution {
            margin-bottom: 8px;
        }
    `)}

    msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
        bottom: ${t=>t.fixedCardHeight?77:65+(t.layoutGap||12)}px;
    }

    ${(0,h.z)(t=>t.alignFooters,u.qy`
        msft-article-card[size$="x_2y"] msft-article::part(heading):after {
            top: calc(100% - ${t=>t.fixedCardHeight?304:292+(t.layoutGap||12)}px - 8px) !important;
        }

        msft-article::part(text) {
            margin-bottom: -8px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
            top: -29px;
            bottom: calc(${t=>t.fixedCardHeight?78:66+(t.layoutGap||12)}px + 8px);
        }

        msft-article.no-image::part(actions) {
            bottom: calc(var(--msft-article-padding) * 1px - 8px);
        }
    `)}

    msft-article-card[size="_1x_2y"] msft-article[class*="zoom-ratio"]:not(.no-image)::part(gradient):after {
        content: "";
        height: 10px;
        width: 100%;
        bottom: -5px;
        position: absolute;
        background: var(--gradient-mid-color);
    }

    ${(0,h.z)(t=>t.layoutGap,u.qy`
        msft-article-card[size="_1x_2y"] msft-article.no-image::part(gradient),
        msft-article-card[size="_2x_2y"] msft-article::part(gradient) {
            bottom: 0px;
        }

        msft-article-card[size="_1x_2y"] {
            --card-height: ${t=>292+t.layoutGap}px;
            --card-width: 300px;
        }

        msft-article-card[size="_2x_2y"] {
            --card-height: ${t=>292+t.layoutGap}px;
            --card-width: ${t=>600+t.layoutGap}px;
        }
    `)}

    msft-article span.title_1x_2y,
    msft-article span.title_2x_2y {
        font-size: 20px;
    }

    ${(0,h.z)(t=>t.enableTitleClickableOnly,u.qy`
        msft-article-card:hover msft-article::part(heading) {
            position: relative;
        }
    `)}

    ${(0,h.z)(t=>t.useTitleFontSize,u.qy`
        msft-article-card {
            --msft-article-heading-font-size: ${t=>t.useTitleFontSize}px;
            --msft-article-heading-line-height: 26px;
        }

        msft-article-card msft-article::part(attribution) {
            height: 28px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(heading) {
            margin-bottom: 11px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 46%, var(--gradient-color) 100%);
            top: 5px;
        }

        ${(0,h.z)(t=>!t.isAnaheimDesign&&!t.enableLinearFeed2cVerticalGradientCard,u.qy`
            msft-article-card[size="_2x_2y"].contentCard msft-article:not(.no-image)::part(heading),
            msft-article.no-image::part(heading) {
                margin-bottom: 8px;
            }
        `)}
    `)}

    ${(0,h.z)(t=>!t.isAnaheimDesign&&t.isImage43&&!t.enableLinearFeed2cVerticalGradientCard,u.qy`
        msft-article-card[size="_2x_2y"] msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient(${t=>t.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 55px, var(--gradient-color) 120px);
            width: 347px;
        }
    `)}

    ${g.Y.getArticleCardHoverGradientStyle()}

    ${(0,h.z)(t=>!t.isAnaheimDesign&&!t.optedOutOfReactions,u.qy`
        msft-article-card[size="_1x_2y"].contentCard msft-article::part(text) {
            padding-bottom: 10px;
        }
        msft-article-card.contentCard msft-article::part(actions) {
            bottom: 10px;
        }
    `)}

    ${(0,h.z)(t=>!t.isAnaheimDesign&&!t.isHubDesign&&!t.optedOutOfReactions,u.qy`
        msft-article-card.contentCard msft-article div[slot="end-action"] {
            display: flex;
            height: 20px;
            margin: 6px 0;
        }
    `)}

    msft-article-card[size="_1x_1y"].contentCard msft-article:not(.no-image)::part(actions) {
        bottom: -2px;
    }

    ${(0,h.z)(t=>t.enableInfopaneLike2cCard,u.qy`
    msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-start-actions msft-attribution {
            margin-bottom: 0;
        }
        msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-start-actions,
        msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-end-actions {
            display: grid;
            gap: 0px;
            align-items: center;
            grid-auto-flow: column;
        }
    `)}

    msft-article[id="contentcard_${t=>t.id}"] div.infopane-like-end-actions {
        display: flex;
    }

    /* 
     * Here about 'from the web' attribution style
     */
    ${(0,h.z)(t=>t.enableInfopaneLike2cCard&&t.cardSize===o.uE._2x_2y,u.qy`
        msft-article[id="contentcard_${t=>t.id}"] .infopane-like-start-actions {
            flex:1;
        }
        msft-article[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-article[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
    `)}

    msft-article[id="contentcard_${t=>t.id}"] msft-attribution, msft-article[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
        width: calc(100%);
        ${t=>t.isProviderIconClickable?"display: flex":""};
    }
    msft-article[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
        width: calc(100%);
        min-height: var(--type-ramp-minus-1-line-height);
        position: relative;
        overflow: hidden;
        white-space: nowrap;
    }
    msft-article[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
        position:absolute;
        transition: all 0.5s ease-out;
    }

    ${(0,h.z)(t=>t.isDynamicFeed,u.qy`
        msft-article-card[size="_1x_1y"].contentCard msft-article::part(heading) {
            --msft-article-heading-font-size: 16px;
            --msft-article-heading-line-height: 22px;
            height: 66px;
            -webkit-line-clamp: 3;
            margin-top: -6px;
        }
        msft-article-card[size="_1x_1y"].contentCard msft-article:not(.no-image)::part(actions) {
            bottom: -12px;
        }
        msft-article-card[size="_1x_1y"].contentCard div[slot='image'] {
            border-radius: 6px;
        }
        msft-article-card[size="_1x_1y"],
        msft-article-card[size="_1x_2y"],
        msft-article-card[size="_2x_2y"] {
            border-radius: calc(var(--layer-corner-radius) * 2px);
        }
    `)}
</style>

<msft-article-card
    style="grid-area:${t=>t.gridArea};"
    size="${t=>t.cardSize}"
    card-fill-color="${t=>t.articleCardBackgroundColor?.find(t=>t.isDarkMode===(0,v.ud)())?.hexColor}"
    class="${t=>t.isInfopane?"infopane":"contentCard"}"
    data-badge-type="${t=>t.badge&&t.badge.type}"
>
    ${y}
</msft-article-card>
`,$=t=>{let e="";return t.imageData||(e+="no-image "),t.gradientType===i.Long&&(e+="long-gradient"),e},k=t=>t.abstract},19e3(t,e,a){"use strict";a.d(e,{m(){return r}});var i=a(37914),n=a(98669);const r={getFeedDataForCard(t){return(0,n.PB)(t)},viewTemplate:i.K}},37914(t,e,a){"use strict";a.d(e,{K(){return f}});var i=a(69828),n=a(40201),r=a(11803),o=a(62679),s=a(99381),l=a(44776),c=a(26330),d=a(21386),p=a(89757),g=a(69259),u=a(44978),h=a(77833);const b=(t,e)=>`${e}${t.cardSize!==i.uE._1x_2y&&t.cardSize!==i.uE._1x_3y||t.imageData?t.cardSize:t.cardSize+"_no_image"}`,m=p.qy`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        .msn-hp-external-link-abstract {
            font-size: 12px;
            z-index: 1;
            position: absolute;
            top: 25px;
            left: 8px; 
            user-select: none;
        }

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
            ${t=>t.isProviderIconClickable?"display: inline-flex":""}
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
        ${(0,g.z)(t=>t.contentType===h.pL.Video,p.qy`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
    </style>
    <msft-content-card
        exportparts="heading, abstract"
        id="contentcard_${t=>t.id}"
        class="${t=>t.isWebContent&&"web-content"}"
        href=${t=>t.destinationUrl}
        target=${t=>t.openLinksInNewTab?"_blank":"_self"}
        title=${t=>t.disableCardTitleTooltip?"":t.title}
        aria-label=${t=>t.ariaLabel}
        ?image-priority=${t=>t.imagePriority}
        style="--heading-max-lines: 3; --footer-start-padding: 8px;"
        :handleContentCardClickOverride=${t=>t.handleContentCardClickOverride}
        data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}"
        :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
        @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
        @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
    >
        ${(0,g.z)(t=>t.contentIndicator&&!(t.cardSize===i.uE._1x_1y&&!t.imageData),t=>(0,n.Z)(t.contentIndicator))}
        ${(0,g.z)(t=>!t.isAnaheimDesign,p.qy`${t=>t.title}`)}
        ${(0,g.z)(t=>t.isAnaheimDesign&&!t.useSmallFontSize,p.qy`<span class="${t=>b(t,"title")}">${t=>t.title}</span>`)}
        ${(0,g.z)(t=>t.isAnaheimDesign&&t.useSmallFontSize,p.qy`${t=>t.title}`)}
        ${(0,g.z)(t=>t.abstract,p.qy`
            <p slot="abstract" style="${t=>!t.isWebContent&&"color: var(--neutral-foreground-rest);"}" class="${t=>b(t,"abstract")} ${t=>t.isMsnHpExternalLinkCard?"msn-hp-external-link-abstract":""}">
                ${t=>t.abstract}
            </p>
        `)}
        <!-- Only use placeholder -->
        <!-- If image data exists && 1x_2y && image priority -->
        ${(0,g.z)(t=>!(!t.imageData||t.cardSize!==i.uE._1x_2y||!t.imagePriority),p.qy`
            <div slot="media" style="height: ${t=>t.imageData.imageHeight}px;width: ${t=>t.imageData.imageWidth}px;">
                <img
                    alt="${t=>t.imageData.altText}"
                    src="${t=>t.imageData.source}"
                    height="${t=>t.imageData.imageHeight}"
                    width="${t=>t.imageData.imageWidth}"
                    @load="${t=>{t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(3,r.j.image)}}"
                />
            </div>
        `)}
        ${(0,g.z)(t=>!(!t.imageData||t.cardSize===i.uE._1x_2y&&t.imagePriority),p.qy`
            <img
                slot="media"
                alt="${t=>t.imageData.altText}"
                src="${t=>t.imageData.source}"
                height="${t=>t.imageData.imageHeight}"
                width="${t=>t.imageData.imageWidth}"
                @load="${t=>{t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(3,r.j.image)}}"
            />
        `)}
        ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}}
        ${(0,g.z)(t=>t.providerData,p.qy`
            <msft-attribution slot="${t=>t.isProviderInFooter?"start-actions":"attribution"}" style="${t=>t.isProviderInFooter?"gap:0; z-index: 0":""}">
                ${(0,o.mt)()}
                <div class="attribution_container_${t=>t.id}" id="attribution_container">
                    <div class="attribution_Content_${t=>t.id}" style="${t=>"rtl"===t.dir?"right":"left"}:0px;">
                        ${(0,g.z)(t=>t.providerData&&t.providerData.name&&!t.isProviderIconClickable,p.qy`<span style="unicode-bidi: embed;">${t=>t.providerData.name}</span>`)}
                        ${(0,g.z)(t=>t.providerData&&t.providerData.name&&t.publishedDateTime,p.qy` · `)}
                        ${(0,g.z)(t=>t.publishedDateTime,p.qy`<span style="unicode-bidi: embed;">${t=>t.publishedDateTime}</span>`)}
                        ${(0,g.z)(t=>t.isWebContent&&t.crawledContentLabel,p.qy` · `)}
                        ${(0,g.z)(t=>t.isWebContent&&t.crawledContentLabel,p.qy`${t=>t.crawledContentLabel}`)}
                    </div>
                </div>
            </msft-attribution>
        `)}
        <!-- Workaround for bug in MsftContentCard: footer without end-actions will not be displayed. -->
        ${(0,g.z)(t=>t.providerData&&t.isProviderInFooter,p.qy`
            <div slot="end-actions"></div>
        `)}
        ${(0,g.z)(t=>t.cardActionStatus&u.J.enabled&&!t.disableHideOnHover,s.K)}
        ${(0,g.z)(t=>!t.isAnaheimDesign||t.enableRichSocialReaction,p.qy`
            <div slot="start-actions" style="gap:0">
                ${(0,g.z)(t=>t.enableRichSocialReaction,t=>(0,l.nj)({hideComments:t.hideComments}))}
                ${(0,g.z)(t=>t.cardActionStatus&u.J.enabled&&!t.enableRichSocialReaction,p.qy`
                    ${l.LW}
                    ${l.tB}
                `)}
            </div>
        `)}
        ${(0,g.z)(t=>!t.isAnaheimDesign||t.enableRichSocialReaction,p.qy`
            <div slot="end-actions" style="gap:0">
                ${(0,g.z)(t=>t.cardActionStatus&u.J.enabled,p.qy`
                    ${(0,g.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,p.qy`
                        ${(0,g.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&u.J.showMore,l.LW)}
                        ${(0,g.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&u.J.showFewer,l.tB)}
                    `)}
                    ${(0,g.z)(t=>t.enableWCCardAction,c.L)}
                `)}
            </div>
        `)}
        ${(0,g.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,d.p)}
    </msft-content-card>
 `,f=p.qy`
    <style>
        ${(0,g.z)(t=>t.articleCardBackgroundColor&&t.showColorfulHalfUContentCard,p.qy`
            .content-card-gradient-mask {
                padding: 0; 
                width: 100%; 
                height: 100%;
            }

            @media (prefers-color-scheme: dark) {
                .content-card-gradient-mask#contentcardmask_${t=>t.id} {
                    background: linear-gradient(160deg, #404040 0%, ${t=>t.articleCardBackgroundColor?.find(t=>t.isDarkMode)?.hexColor} 150%);
                }
            }

            @media (prefers-color-scheme: light) {
                .content-card-gradient-mask#contentcardmask_${t=>t.id} {
                    background: linear-gradient(160deg, #e5e5e5 0%, ${t=>t.articleCardBackgroundColor?.find(t=>!t.isDarkMode)?.hexColor} 150%);
                }
            }
        `)}

        msft-content-card .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card(:not(.web-content))::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card span.title_1x_2y_no_image {
            font-size: 24px;
            line-height: 32px;
        }
        msft-content-card span.title_1x_3y_no_image {
            font-size: 16px;
            line-height: 22px;
        }
        msft-content-card p.abstract_1x_2y_no_image {
            font-size: 16px;
            line-height: 22px;
            margin-top: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        msft-content-card p.abstract_1x_3y_no_image {
            font-size: 14px;
            line-height: 20px;
            margin-top: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 5;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        fluent-card._1x_3y msft-content-card::part(abstract) {
            padding-left: var(--abstract-start-padding, 16px);
        }
    </style>
    <fluent-card
        style="grid-area:${t=>t.gridArea}"
        class="${t=>t.cardSize}"
    >
        ${(0,g.z)(t=>t.articleCardBackgroundColor&&t.showColorfulHalfUContentCard,p.qy`
            <div class="content-card-gradient-mask"
                id="contentcardmask_${t=>t.id}"
            >
                ${m}
            </div>
        `)}
        ${(0,g.z)(t=>!t.articleCardBackgroundColor||!t.showColorfulHalfUContentCard,p.qy`
            ${m}
        `)}
    </fluent-card>
`},58034(t,e,a){"use strict";var i,n;a.d(e,{j(){return i},o(){return n}}),function(t){t.OneColumn="1_column",t.TwoColumn="2_column"}(i||(i={})),function(t){t.LightDefault="lightDefault",t.LightNarrow="lightNarrow",t.LightLarge="lightLarge",t.LightWide="lightWide",t.LightStyle2="light2"}(n||(n={}))},76971(t,e,a){"use strict";a.d(e,{ad(){return st},gC(){return dt}});var i=a(84289),n=a(87906),r=a(40450),o=a(83488),s=a(78518),l=a(98794),c=a(69828),d=a(46659),p=a(95402),g=a(35667),u=a(1792),h=a(25658),b=a(7446),m=a(98378),f=a(82368),v=a(52545),y=a(2568),x=a(22621),$=a(56233),k=a(50901),C=a(1480),w=a(58034),_=a(57152),T=a(83916),F=a(73632),S=a(72627),D=a(19110),A=a(72287),z=a(98669),I=a(94108),E=a(33744),B=a(72746),M=a(64859),R=a(44978),L=a(43922),N=a(77833),O=a(52323),P=a(20999),H=a(50180),j=a(54694),V=a(10173),U=a(12673),W=a(44916),G=a(81859),Z=a(12882),J=a(94623),X=a(18284),Q=a(60815),q=a(98670),Y=a(51907),K=a(86010);let tt=!1;const et={[c.uE._1x_2y]:d.L._300x304,[c.uE._1x_3y]:d.L._300x326,[c.uE._2x_2y]:d.L._612x304,[c.uE._2x_3y]:d.L._612x462},at={[c.uE._1x_2y]:d.L._300x180},it={[c.uE._1x_2y]:d.L._300x225,[c.uE._1x_3y]:d.L._300x225,[c.uE._2x_2y]:d.L._468x304,[c.uE._2x_3y]:d.L._468x304},nt={[c.uE._1x_2y]:d.L._300x304,[c.uE._1x_3y]:d.L._300x326,[c.uE._2x_2y]:d.L._628x372,[c.uE._2x_3y]:d.L._628x372},rt={[c.uE._1x_2y]:p.Sv.infoPane,[c.uE._1x_3y]:p.Sv.infoPane1x3y,[c.uE._2x_2y]:p.Sv.infoPane,[c.uE._2x_3y]:p.Sv.infoPane},ot={MorningDigest:!0,RegionalTrending:!0,TopicNews:!0};function st(t){(0,i.tD)("InfopaneDataMapping.Start",performance.now());const{activeIndicator:e,autoRotate:n,autoRotateIntervalMs:p,disableAutoRotate:S,firstAutoRotateIntervalMs:D,cardActionBitMask:E,cardActionClickHandler:B,cardMetadata:j,cardSlot:U,enableInfopaneSwipe:W,enableRichSocialReaction:G,focusinHandler:X,focusoutHandler:Q,getReplacementCardsCallback:Y,reactionCallback:K,shareActionHandler:et,initCardAction:at,localizedStrings:it,mouseenterHandler:nt,mouseleaveHandler:st,openLinksInNewTab:pt,parentTelemetryObject:gt,refreshFeedCallback:ut,setAutoRotate:ht,stockImageData:bt,visualReadinessCallback:mt,configOptions:ft,isAnaheimDesign:vt,isAdFeedbackV1Enabled:yt,isNarrowTitleFooterGap:xt,isProviderInFooter:$t,allowBlurScroll:kt,enableRotateAfterClick:Ct,rotateAfterClickIntervalMs:wt,enableRotateOnlyOnce:_t,rotateBackAfterClickPrevButton:Tt,rotateStopAfterClickPrevButton:Ft,enableInfopaneRefactoring:St,adTimerInMS:Dt,infoPaneProminentFlipper:At,infopaneThresholdSecondForNewFlag:zt,infopaneThresholdForCommentFlag:It,enableTabbedInfopane:Et,columnLayout:Bt,isIASEnabled:Mt,appendIdxForId:Rt}=t,{grid_area:Lt}=U,Nt=It??_.R3,Ot=zt??_.Rl,Pt=ft&&(ft.childExperienceReferencesWC&&ft.childExperienceReferencesWC.socialBarWC||ft.childExperienceReferences&&ft.childExperienceReferences.socialBarWC),Ht=j;let jt=[];if(Ht.subItems&&Ht.subItems.length?jt=Ht.subItems:(jt=Ht.subCards,Ht.subItems=jt),!jt.length)return;jt=function(t){const e=[];let a=[];for(let i=0;i<t.length;i++){const n=t[i];if(n.type==N.pL.TabbedInfopaneCardTab)a.push(n);else if(n.type==N.pL.TopicFeed)a.push(n);else{if(a.length>0){const t={type:N.pL.TabbedInfopaneCard,subCards:a};e.push(t),a=[]}e.push(n)}}return e}(jt);const Vt=(0,M.c)(gt);let Ut="",Wt=!1;const Gt="PersonalizedInfopane"===Ht.wpoMetadata?.contentType;if(Gt&&(0,M.b)(Vt),Ht.feed){const{sageFeedGroupName:t,feedName:e}=Ht.feed;e&&ot[t]&&(Ut=e,Wt=!0)}if(Ht.wpoMetadata){const{contentType:t}=Ht.wpoMetadata;if(""===Ut){const e=t===N.pL.WorkHeadlines;if(ft.enableImmersiveInfopane){const t=it.topStoriesHeadingText;it.topStoriesHeadingText=t.slice(0,1)+t.slice(1).toLowerCase()}Ut=function(t,e,a){const{topStoriesHeadingText:i,industryHeadlinesText:n,localNewsHealinesText:r}=a||{};return(0,J.YW)({isLocalNews:t,isWorkHeadlines:e}).with({isLocalNews:!0},()=>r).with({isWorkHeadlines:!0},()=>n).otherwise(()=>i)}((Zt=t,[N.pL.LocalNews,N.pL.LocalNewsFeed].includes(Zt)),e,it)}t!==N.pL.TopStories&&t!==N.pL.TopStoriesV2||(jt=jt.slice(0,6))}var Zt;const Jt=it?.cardActionsTooltips,Xt={id:"infopane",childTemplateType:"infopane-card",telemetryContext:Vt,slideContentData:[],isNarrowTitleFooterGap:xt,infoPaneFlipperStyle:ft.infoPaneFlipperStyle,enableDenseSlide:ft.enableDenseSlide,enableRotateOnlyOnce:_t,enableAdaptDarkMode:ft.enableAdaptDarkMode,infoPaneNextFlipperTitle:it?it.infoPaneNextFlipperTitle:"",infoPanePreviousFlipperTitle:it?it.infoPanePreviousFlipperTitle:"",useTitleFontSize:ft&&ft.useTitleFontSize,enableImmersiveInfopane:ft&&ft.enableImmersiveInfopane,autoRowHeights:vt&&ft.enableFlexCard,infopaneViewOptAdCount:ft.infopaneViewOptAdCount,enableInfopaneSwipe:W,cardActionsTooltips:Jt,disableImmersiveInfopaneTitle:Gt,enableVariableSpeed:ft.enableVariableInfopaneSpeed,parentContentId:ft.parentContentId},Qt=mt,qt=ft&&ft.adBeaconServiceConfig,Yt={};return(0,l.bw)({id:"infopane",experienceType:(ft&&ft.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t},Xt,(M,j)=>{const U=j.cardSize,W=[];let J;jt.forEach((e,i)=>{if(!e)return;const n=e.recoId||e.metadata&&e.metadata.recoId,p=e.ri||e.metadata&&e.metadata.ri,w=(0,l.uX)({id:"infopane",columnArrangement:M,experienceType:(ft&&ft.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t,recoId:n,ri:p,subCardIndex:i});J=w.telemetryExt;const S="ShoppingInfopane1"===e.type||"ShoppingInfopane2"===e.type||"ShoppingInfopane3"===e.type||"ShoppingInfopane4"===e.type,D="nativead"===e.type||"cmsad"===e.type||"directbuyad"===e.type||S,O="ArticleFre"===e.type&&"FreFeed"===e.id,j=e.type===N.pL.EventInfopaneShoppingAI;let X;const Q=(0,A.H8)(e,E),nt=0!==(Q&R.J.hide)||ft.enableHideStoryFeedback&&(0!==(Q&R.J.showFewer)||0!==(Q&R.J.hidden)),ot=e.visualReadinessCallback;if(D)if(S&&(J||(J={}),J={...J,cardName:"ShoppingInfopane",ShoppingCardType:"ShoppingNTPInfopane",clickUrl:e.placement?.items?.[0]?.destinationUrl}),Dt&&(Yt[i]=Dt),0===(Q&R.J.hide)){const i=(ft&&ft.enableNativeAdWCInfopane||e&&e.placement&&e.placement.enableNativeAdWC)&&ft?.childExperienceReferencesWC?.nativeAdWC;if(X=function(t,e,i,n,o,l,c,p,g,m,f,w,_,T,S,D,z,E,B,M,R,L,N=!1,O=!1,j,V,U,W,G,Z,J,X,Q,Y,K,et,at,it,nt,ot,st,lt,dt,pt,gt,ut,ht,bt){(0,u.Yu)(t,T);const mt=t.placement;if(!mt||!mt.items)return;const{crids:ft}=mt;(0,F.S)()&&!ht&&v.x.addDedupeIds(ft,mt.region);const vt=m?.cardActionsTooltips,yt=new P.Yg,xt=[];return mt.items.forEach((v,F)=>{const{destinationUrl:P,adChoiceIconUrl:q,clickBeacons:lt,imageWidth:ht,imageHeight:ft,feedbackUrl:yt,description:$t,assets:kt,adScenarioType:Ct,cashback:wt,verificationParameters:_t,noAdLabel:Tt,assetRanks:Ft,eventtrackers:St}=v||{};let{imageUrl:Dt,title:At,providerName:zt}=v||{};const It=(0,u.EJ)(P,{enableSafeAds:N});if(R&&L){const t=mt.region,e=mt.regionIndex,a={w:Number(v.originalImageWidth),h:Number(v.originalImageHeight)},i=L,n=(0,y.li)(Dt,i,a,It,t,e);if(n){const t=n.logInfo;b.YT.sendClientLogEvent({message:n.message,pb:{...r.Gq_.pb,logInfo:t},type:"warning"})}}const Et=(0,h.u)(t,i,"infopane",F,w),Bt="river-half-textonly"!==(mt.region&&mt.region.toLowerCase())?(0,x.cG)(mt,F):null;!tt&&Bt&&(Promise.all([a.e("node_modules_video_js_dist_video_es_js"),a.e("web-components_content-video-player_dist_index_js"),a.e("web-components_native-ad-video_dist_index_js")]).then(a.bind(a,30376)),tt=!0);let Mt=ht||d.L._300x156.width.toString(),Rt=ft||d.L._300x156.height.toString(),Lt=At,Nt=null,Ot=null,Pt=null,Ht=null,jt=!1;const Vt=G&&!Z&&kt&&Ct&&s.JP.includes(Ct),Ut=Z&&kt&&0!==Object.keys(kt).length&&X?.includes(Ct);Vt||Ut?(Mt=kt.img?.w.toString()??Mt,Rt=kt.img?.h.toString()??Rt,Dt=kt.img?.url??Dt,Lt=kt.img?.ext?.alt??Lt,At=kt.title??At,zt=kt.providerName??zt,Nt=kt.logo?.url,Vt?Ot=(0,u.Po)(kt,mt.region):Ut&&((0,$.FM)(kt),Pt=(0,$.Ng)(kt,Ft),b.YT.addOrUpdateTmplProperty("hasVAv2","1"),b.YT.addOrUpdateTmplString("hasVAv2"))):nt&&wt&&(At=(0,H.GP)(m?.nativeAdCashbackText,wt)??At,zt="Microsoft"),!et&&Q&&kt&&(Ht=kt.callToAction??Ht,Ht&&!it&&(jt=!0)),!at&&K&&kt&&(Nt=kt.logo?.url,Nt&&!it&&(jt=!0)),Q&&kt&&kt.callToAction&&(b.YT.addOrUpdateTmplProperty("hasCallToAction","1"),b.YT.addOrUpdateTmplString("hasCallToAction")),K&&kt&&kt.logo?.url&&(b.YT.addOrUpdateTmplProperty("hasLogo","1"),b.YT.addOrUpdateTmplString("hasLogo"));const Wt=t.id&&t.id.indexOf("amplifyad")>=0;if(At&&It){if(xt.push({...mt,cardActionsTooltips:vt,id:t.id,index:F,gridArea:e,childTemplateType:"native-ad-card",isNativeAd:!0,imagePriority:!0,cardSize:n,adTelemetryContext:Et,telemetryContext:Et,adChoiceIconUrl:q,clickBeacons:lt,destinationUrl:It,imageData:{altText:Lt,source:Dt,imageWidth:Mt,imageHeight:Rt,visualReadinessCallback:f},providerData:{logoImage:Nt,name:zt},title:At,description:$t,enableNativeAdDescription:j,maxDescriptionLines:V,enableProviderAlignmentV2:W,cardLayout:rt[n],isAnaheimDesign:!!o,toggleCardActionMenu(t,e){return(0,A.JE)(t,e,p,l)},feedbackUrl:yt,isAdFeedbackV1Enabled:c,useSmallFontSize:!!g,assets:kt,localizedStrings:m,videoProps:Bt,hoverState:ct(),nativeAdWC:_,adBeaconServiceConfig:T,noBackPlateOnRest:!!S,feedFontSize:D,adSlugGA:z,isGreyAdsLabelEnabled:E,adLabelFontSize:M,disableCardTitleTooltip:B,enableTitleForTruncate:pt,showAdLabel:!Wt,providerName:Wt?m.nativeAdPromotedByText:zt,attribution:Wt?$t:void 0,enableSafeAds:N,useLightShadow:O,lightShadowVal:U,enableVA:G,enableVAPhase2:Z,enableVAPhase2WithShimmer:J,supportedAdScenarioTypes:X,enableCTA:Q,enableCTAVariant:Y,enableLogo:K,callToAction:Ht,logoImageUrl:Nt,hasCTALogoAssets:jt,enableBlendInAdSlugStyle:dt,assetColumns:Ot,assetOrder:Pt,enableBuyDirectAd:gt,hideAdLabelAndAdChoice:(0,A.tO)(mt?.providerId,Tt),openAdInSameTab:ut,enableAdSponsoredText:bt}),ot&&t.id&&_t){const e=st?`native_ad_${t.id}_${F}`:`native_ad_${t.id}`,a=St?.find(t=>"IAS-omid"===t.ext?.vendorKey);a?(0,k.n$)(a,e,r.nxh):(0,k.nL)(_t,e,r.nxh)}const a=!I.Rb?.CurrentFlightSet?.has("prg-ad-dv-on-rf"),i=St&&t.id,s=!!mt?.isXandrPlacement;if(!St||a&&t?.id||(0,C.xs)(St,t?.id,a,s),a&&i){const e=st?`${t.id}_${F}`:`${t.id}`,a=(0,C.Q3)(St);s&&a.has("doubleverify.com-omid")?(0,C.Mb)(a.get("doubleverify.com-omid"),e,r.nxh,s):a.has("DV")&&(0,C.Mb)(a.get("DV"),e,r.nxh)}}}),yt.saveUserActionBeacon(t.id,mt.beaconsJson),xt.forEach(t=>(0,q.B)(t)),{id:t.id,gridArea:e,childTemplateType:"native-ad-card",isNativeAd:!0,imagePriority:!0,cardSize:n,nativeAds:xt,enableSafeAds:N}}(e,Lt,Vt&&Vt.infopane,U,vt,at,yt,B,ft.useSmallFontSize,ft?.localizedStrings,ot,J,i,qt,ft.noBackPlateOnRest,ft.twoColumnFeedFontSize||ft.feedFontSize,ft.adSlugGA,ft.isGreyAdsLabelEnabled,ft.disableCardTitleTooltip,ft.adLabelFontSize,ft.enableNativeAdImageVisualQualityChecker,ft.adTemplateConfig?.imageSizeConfig?.infopane,ft.enableSafeAds,ft.useLightShadow,ft.enableNativeAdDescription,ft.maxDescriptionLines,ft.lightShadowVal,ft.enableProviderAlignmentV2,ft.adTemplateConfig?.enableVA,ft.adTemplateConfig?.enableVAPhase2,ft.adTemplateConfig?.enableVAPhase2WithShimmer,ft.adTemplateConfig?.supportedAdScenarioTypes,ft.enableCTA,ft.enableCTAVariant,ft.enableLogo,ft.disableCTADisplay,ft.disableLogoDisplay,ft.ctaLogoSimplification,ft.enableCashback,Mt,Rt,ft&&ft.ipFlipperCustomSize,ft.enableBlendInAdSlugStyle,ft.enableTitleForTruncate,ft.enableBuyDirectAd,ft.openAdInSameTab,ft.adTemplateConfig?.enableBlockingQueue,ft.enableAdSponsoredText),t.configOptions.preloadInfopaneImages)for(const t of X?.nativeAds??[])(0,A.NN)(t.imageData?.source)}else{const a={...t,cardMetadata:e};X=(0,f.Eb)(a,Q,e.id,Vt&&Vt.infopane,yt,(0,u.ZA)(a))}else if(e.type===N.pL.Dense){const a=e?.subItems??e?.subCards;if(a.forEach(t=>{if(!t)return;const e=t.recoId||t.metadata&&t.metadata.recoId;e&&(J.recoId=e)}),4===a?.length)X=function(t,e,a,i){const{cardActionBitMask:n,cardActionClickHandler:r,cardMetadata:o,configOptions:s,enableRichSocialReaction:l,getReplacementCardsCallback:p,reactionCallback:u,shareActionHandler:h,goToPersonalizeSettingsCallback:b,initCardAction:f,isAnaheimDesign:v,isNarrowTitleFooterGap:y,localizedStrings:x,openLinksInNewTab:$,parentTelemetryObject:k,refreshFeedCallback:C,stockImageData:w,visualReadinessCallback:_}=t,T=o?.subItems??o?.subCards,F=k.addOrUpdateChild({name:"TopStoriesDenseSlide",type:m.MJ.Headline}),S=F.addOrUpdateChild({name:"MoreSetting",type:m.MJ.ActionButton}),D={moreSetting:{title:s.localizedStrings?.moreSettingOptStr||"More settings",telemetryTag:S.getMetadataTag(),onClick:b}};let I,E=T;if(e===c.uE._2x_2y){const t=T[0]??(0,A.cZ)(T[0]);E=T?.slice(1);const e=_,d=o.visualReadinessCallback;I={...lt({cardMetadata:t,cardSize:c.uE._1x_2y,cardActionStatus:(0,A.H8)(t,n),cardActionClickHandler:r,initCardAction:f,visualReadinessCallback(){e&&e(),d&&d()},localizedStrings:x,stockImageData:w,isAnaheimDesign:v,isNarrowTitleFooterGap:y,configOptions:s,openLinksInNewTab:$,socialBarWCConfigInfo:a,enableRichSocialReaction:l,useSmallFontSize:s.useSmallFontSize,refreshFeedCallback:C,getReplacementCardsCallback:p,reactionCallback:u,shareActionHandler:h,parentTelemetryObject:F,ext:i}),cardActionClickHandler:void 0,cardFillColor:"#333",cardSize:"_1x_2y",mediaType:L.z.image}}const B={heroNews:I,newsList:E?.map(t=>{const e=t.type===N.pL.WebContent,a=(0,z.po)(t,d.L._60x60,_,v,void 0,void 0,void 0,void 0,void 0,void 0,void 0,s.enableWebpFormat);t.cardContent||(t=(0,A.cZ)(t));const{destinationUrl:n,locale:r,id:o,provider:l,publishedDateTime:c,title:p}=t.cardContent;return{id:o,destinationUrl:n,title:p,ariaLabel:(0,A.yL)(p,l,s.localizedStrings),openLinksInNewTab:$,providerData:(0,A.p_)(l,e),publishedDateTime:!v&&s.enableArticleTimestamps&&(0,z.fL)(s.enableNewTimestampFormatForJAJP,new Date(c),r,s.localizedStrings),imageData:a,isNativeAd:!1,telemetryContext:(0,g.dj)(F,t.cardContent,t.metadata,i,e),isNarrowNewsItem:s.isNarrowNewsItem}})};return{id:"denseCard-infopane-1",childTemplateType:"dense-card",gridArea:"",telemetryObject:F,denseData:B,settingMenuConfig:D,localizedStrings:s.localizedStrings}}({...t,cardMetadata:e,parentTelemetryObject:Vt&&Vt.infopane},U,Pt,J);else if((0,Z.uC)(ft.childExperienceReferencesWC?.denseCard||ft.childExperienceReferences?.denseCard),X=dt(ft,e,pt,$t,()=>{Qt&&Qt(),ot&&ot()},vt,gt,U,ft.isGreyAdsLabelEnabled,i,J,Ot,Nt,Et),t.configOptions.preloadInfopaneImages){(0,A.NN)(X.denseData.heroNews?.imageData?.source),(0,A.NN)(X.denseData.heroNews?.providerData?.logoImage);for(const t of X.denseData.newsList||[])(0,A.NN)(t.providerData?.logoImage)}}else e.type===N.pL.TopStories?X=function(t){const e={...t};e.cardMetadata=e.cardMetadata.subItems[0];const a=(0,V.W)(e).defaultLayout[0];return a.isAnaheimInfopane=!0,a}(t):O?((0,Z.uC)(ft.childExperienceReferencesWC&&ft.childExperienceReferencesWC.articleFreCard),X=function(t,e){const a={...t,isArticleFreInInfoPane:!0};a.cardMetadata=a.cardMetadata.subItems[0],a.configOptions={...a.configOptions,enableHideStoryFeedback:!0,enableInstantHide:!0,enableDismissCallback:!0,useHideConfirmationNewStoryText:!0};const i=(0,o.z)(a),n={...i.defaultLayout[0],...i[e][0]};return n}(t,M)):nt?X=(0,f.Eb)(t,Q,e.id,Vt&&Vt.infopane):e.type===N.pL.TabbedInfopaneCard?X=function(t,e,a,i,n,r,o,s){const{configOptions:l,openLinksInNewTab:c,isProviderInFooter:d,visualReadinessCallback:p,isAnaheimDesign:g,parentTelemetryObject:u,localizedStrings:h}=t,b=e?.subItems??e?.subCards,m=(0,T.G)(u),f=b.map((t,e)=>(0,_.Ww)(l,t,c,d,()=>{a&&a(),p&&p()},g,u,m,i,l.isGreyAdsLabelEnabled,e,r,h,o,s)),v={id:`denseCard-infopane-${n+1}`,gridArea:"",childTemplateType:"tabbed-infopane-card",enableAdaptDarkMode:l.enableAdaptDarkMode,telemetryContext:m,slideContentData:f};return v}(t,e,Qt,U,i,J,Ot,Nt):(X=lt({cardMetadata:e,cardSize:U,openLinksInNewTab:pt,visualReadinessCallback(){Qt&&Qt(),ot&&ot()},cardActionStatus:Q,cardActionClickHandler:B,initCardAction:at,localizedStrings:it,parentTelemetryObject:Vt&&Vt.infopane,stockImageData:bt,enableRichSocialReaction:G,configOptions:ft,isAnaheimDesign:vt,useSmallFontSize:ft.useSmallFontSize,isNarrowTitleFooterGap:xt,refreshFeedCallback:ut,socialBarWCConfigInfo:Pt,getReplacementCardsCallback:Y,reactionCallback:K,shareActionHandler:et,ext:J,cardTitleText:Ut,enableDefaultNewsIcon:Wt,disableImmersiveInfopaneTitle:Gt,isShoppingArticleCard:j}),t.configOptions.preloadInfopaneImages&&((0,A.NN)(X.imageData?.source),(0,A.NN)(X.providerData?.logoImage)));X&&(e.type!==N.pL.TopStories&&(X.cardLayout=rt[U]),W.push(X))});const ot={...Vt};if(ft&&ft.addExtToNewsContainer&&J&&ot.infopane){const{row:t,col:e,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:s}=J;ot.infopane=new O.$({...ot.infopane.contract,ext:{row:t,col:e,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:s}})}const mt={activeIndicator:e,autoRotate:n,autoRotateIntervalMs:p,disableAutoRotate:S,allowBlurScroll:kt,firstAutoRotateIntervalMs:D,focusinHandler:X,layout:U===c.uE._2x_2y?w.j.TwoColumn:w.j.OneColumn,mouseenterHandler:nt,mouseleaveHandler:st,setAutoRotate:ht,slideContentData:W,isNarrowTitleFooterGap:xt,enableRotateAfterClick:Ct,rotateAfterClickIntervalMs:wt,enableRotateOnlyOnce:_t,rotateBackAfterClickPrevButton:Tt,rotateStopAfterClickPrevButton:Ft,enableInfopaneRefactoring:St,adTimerMap:Yt,infoPaneProminentFlipper:At,telemetryContext:ot};return Q&&(mt.focusoutHandler=function(t){return e=>{e.relatedTarget&&"fluent-menu-item"===e.relatedTarget.localName||t()}}(Q)),(0,i.tD)("InfopaneDataMapping.End",performance.now()),mt},!0)}function lt({cardMetadata:t,cardSize:e,openLinksInNewTab:a,visualReadinessCallback:i,cardActionStatus:o,cardActionClickHandler:s,initCardAction:l,localizedStrings:p,parentTelemetryObject:h,stockImageData:m,enableRichSocialReaction:f,configOptions:v,isAnaheimDesign:y,isHubDesign:x,useSmallFontSize:$,isNarrowTitleFooterGap:k,refreshFeedCallback:C,socialBarWCConfigInfo:w,getReplacementCardsCallback:_,reactionCallback:T,shareActionHandler:F,ext:S,cardTitleText:M,enableDefaultNewsIcon:R,disableImmersiveInfopaneTitle:L,isShoppingArticleCard:P}){const{cardContent:H,metadata:V,type:G}=(0,A.cZ)(t),Z=G===N.pL.WebContent,J=(0,g.dj)(h,H,V||t,S,Z),X=!("link"!==H.type||H.provider&&H.provider.id);v&&v.addExtToNewsContainer&&J&&(J.contentCard=new O.$({...J.contentCard.contract,ext:S}));const Q=(0,z.PS)(t,p,v.enablePanocard,v.panocardType),q=(0,A.Ie)(t);if((!q||!q.url)&&m){let e;e=v?.useImgGenerator?[{url:(0,j.XP)(m.id,{width:0,height:0,enableDpiScaling:!1,enableWebpFormat:v.enableWebpFormat}),width:m.width,height:m.height}]:[m],t.cardContent.images=e}const tt=v&&v.useArticleCardTemplate,rt=v&&v.useMsnHomepageCardTemplate;let ot;tt&&(ot=(0,z.uK)(q?.colorSamples,H.colorSamples,q?.url));let st=null;(X||e===c.uE._2x_3y||tt&&e!==c.uE._1x_2y)&&(st=H.abstract);const{locale:lt,publishedDateTime:ct,badges:dt,isWorkNewsContent:ut}=H,{enableResponsiveComponent:ht}=v||{},bt=V?.reasons,{badge:mt,reasonBadge:ft}=(0,D.bA)(p,dt,v&&v.enabledBadgeTypes,bt,v&&v.enabledReasonBadgeTypes,null),vt=(0,A.nN)(p,v,ft),yt=(0,z.Ew)(p),xt=V&&V.reactionSummary||t&&t.reactionSummary;t.metadata={...t.metadata,reactionSummary:xt};const $t=!xt;let kt;kt=tt?it[e]:rt?t.id.includes("InfoBuyDirectCard")?null:nt[e]:v.enableImmersiveInfopane?at[e]:v.enableFeed3Cards&&e===c.uE._2x_2y?d.L._612x328:et[e],tt&&e===c.uE._2x_2y&&v.isImage43&&(kt=d.L._406x304);const Ct=""!==I.Rb.MarketDir?I.Rb.MarketDir:"ltr",wt=V?.reasons&&(v.childExperienceReferencesWC?.publisherFollowButton||v.childExperienceReferences?.publisherFollowButton);let _t="",Tt=null;if(v?.enableArticleTimestamps){const{disable1MonPlusTimestamp:t,disableNDaysPlusTimestamp:e}=B.ew.getConfig()||{},a=(0,W.YS)(ct),i=(0,W.Tp)(ct,e);t&&a||i||(_t=(0,B._L)(ct,lt,void 0,v?.enableNewTimestampFormatForJAJP,v?.enableSimpleArticleTimestamp),Tt=v?.enableSimpleArticleTimestamp&&(0,B._L)(ct,lt,void 0,v.enableNewTimestampFormatForJAJP,!1,!0))}let Ft=(0,u.EJ)(H.destinationUrl,v);P&&(Ft=function(t){const e=new URL(t);return e.searchParams.set("entryPoint","msn"),e.searchParams.set("FORM","INFOBG"),e.searchParams.set("msnrid",b.YT.getRequestId()),e.searchParams.set("adunitId","378983"),e.searchParams.set("propertyId","316966"),e.toString()}(Ft));const St=G===N.pL.WebContent&&(t.metadata.videoMetadata||Boolean(t.metadata?.externalVideoFiles));St&&(Ft=(0,U.C)(encodeURIComponent(t.id),Ft)),H?.isPanoCard&&1==Q?.type&&(Q.articleDestinationUrl=Ft,Ft=Q.destinationUrl);const Dt=(0,z.po)(t,kt||{width:0,height:0},i,y,!1,!1,!1,!1,!1,!1,v.enableLowPowerDeviceImage,v.enableWebpFormat),At={ariaLabel:(0,A.yL)(H.title,H.provider,p,G),cardActionStatus:(!Z||v?.enableWCCardAction||v?.enableWCSaveButton)&&o,cardActionClickHandler:s,cardActionsTooltips:vt,cardTitleText:M,id:t.id,gridArea:"",isWebContent:Z,colorSamples:t.colorSamples,contentType:G,contentTypeLabel:(0,A.Ww)(p,G)?.toLocaleUpperCase(),customTransitionSpeed:H.customTransitionSpeed,spotlightBreakingNewsTagString:p?.topStoriesBreakingNewsTagString,contentIndicator:(0,z.WH)(G,y&&v?.miniMediaIndicatorsIcons,t.id),abstract:st,isWorkNewsContent:ut,isMsnHpExternalLinkCard:X,childTemplateType:"content-card",crawledContentLabel:v?.localizedStrings?.crawledContentLabel,dir:Ct,setDisplacementHandler:pt,removeDisplacementHandler:gt,title:H.title,titlePrefix:t.titlePrefix||"",badge:mt,reasonBadge:ft,openLinksInNewTab:a||X,isProviderIconClickable:v&&v.isProviderIconClickable,useArrowIcons:v&&v.useArrowIcons,openArticleInNewTab:v&&v.openArticleInNewTab,destinationUrl:Ft,imageData:Dt,locale:H.locale,providerData:(0,A.p_)(H.provider,Z),enableRichSocialReaction:(!Z||v?.enableWebContentSocialReactions||v?.enableWCCardAction||v?.enableWCSaveButton)&&f,disableOptedOutButton:v?.disableOptedOutButton,enableHoverCardAction:v?.enableHoverCardAction,optedOutOfReactions:$t,telemetryContext:J,toggleCardActionMenu(t,e,a){return(0,z.Sp)(t,e,s,l,null,!0,C,v?.openPersonalizeWithoutRouter,$t,a)},cardSize:e,useArticleCardTemplate:tt,articleCardBackgroundColor:ot,isAnaheimDesign:!!y,isHubDesign:!!x,isDynamicFeed:v.isDynamicFeed,useSmallFontSize:!!$,isNarrowTitleFooterGap:k,socialBarWCConfigInfo:w,metadata:V||t,enableSaveButton:v&&!1!==v.enableSaveButton||Z&&v?.enableWCSaveButton,publishedDateTime:_t,ariaDateTime:Tt,gradientDeg:v&&v.isImage43?(0,z.rs)():void 0,isInfopane:!0,noBackPlateOnRest:!!y||v&&v.noBackPlateOnRest,enableFilledIconOnHover:v&&v.enableFilledIconOnHover,enableNeutralFilledShowMoreIcon:v&&v.enableNeutralFilledShowMoreIcon,topQuestionsHeading:p&&p.topQuestionsHeading,topQuestionsNote:p&&p.topQuestionsNote,highlightsHeading:p&&p.highlightsBadgeLabel,highlightsNote:p&&p.highlightsNote,followTexts:yt,useTitleFontSize:v&&v.useTitleFontSize,enableWCSaveButton:!Z||v?.enableWCSaveButton,enableWCCardAction:!Z||v?.enableWCCardAction,actionsArrayOverride:Z&&v?.availableActions||void 0,disableCardTitleTooltip:v&&v.disableCardTitleTooltip,enableTitleForTruncate:v&&v.enableTitleForTruncate,disableImmersiveInfopaneTitle:L,publisherFollowButtonConfigInfo:wt?{...wt,instanceId:`${wt.instanceId}-${t.id}`}:void 0,enableHover:v&&v.enableHover,addExtToNewsContainer:v&&v.addExtToNewsContainer,getReplacementCardsCallback:_,reactionCallback:T,shareActionHandler:F,isSpotlightUX:t&&t.isFeatured,enableDefaultNewsIcon:R,useLightShadow:v&&v.useLightShadow,enableCardHideStoryIcon:v&&v.enableCardHideStoryIcon,lightShadowVal:v&&v.lightShadowVal,enableAttrOversizing:v&&v.enableAttrOversizing,useFollowPublisherButtonWC:v&&v.useFollowPublisherButtonWC,enableProviderAttrNav:!St&&v&&v.enableProviderAttrNav,panoCaption:Q,isPanoCard:H.isPanoCard,clickPanocardFooterHandler(t,e){return(0,A.s2)(t,e)},clickPanocardArticleHandler(t,e){return(0,A.$z)(t,e)},isShoppingArticleCard:P,externalVideoFiles:t.cardContent.videoFiles,socialBarInRight:v&&v.socialBarInRight&&!v.providerOnTopInfopane,providerAboveHeader:v&&v.providerOnTopInfopane};if(ht){let t=!1;At.mediaData={altText:Dt.altText,loadCallback:i,errorCallback(e,a){t||(t=!0,(0,n.vV)(r.qog,"Error fetching source","Source: "+e+", Article ID: "+a),i())},src:Dt.source};const e=At.providerData;At.attributionData={altText:e&&e.name,name:e&&e.name,publishedDateTime:_t,src:e&&e.logoImage,useFollowingButton:!0,errorImageCallback(){},providerChannelURL:e&&(0,Y.As)(e)};let a,o="";switch(ft?.type.toLowerCase()){case"trending":o=`${E.T3.StaticsUrl}latest/icons-wc/icons/TrendingLight.svg`;break;case"local":o=`${E.T3.StaticsUrl}latest/icons-wc/icons/LocationPin.svg`;break;case"followtopic":case"followpublisher":o=`${E.T3.StaticsUrl}latest/icons-wc/icons/CircleCompleted.svg`}ft?.type&&(a={iconSrc:o,onClickBadge(t,e){return(0,z.Sp)(t,e,s,l,null,!0,C,v?.openPersonalizeWithoutRouter,$t,K.hs.WhyAmISee)},telemetryTag_badge:J?.whyAmISee?.getMetadataTag(),text:ft?.localizedLabel||""}),At.badgeProps=a,At.visualReadinessCallback=i}return At}function ct(){const t={isHovered:!1};return(0,Q.sH)(t,"isHovered"),t}function dt(t,e,a,i,n,r,o,s,l,c,p,f,v,y){if(t?.enableInfopaneDenseCardInteraction||t?.infopaneDenseCardNoHeroNews){let a=t.childExperienceReferencesWC?.denseCard||t.childExperienceReferences?.denseCard,i=e?.subItems??e?.subCards;const r=7-1;if(i=i.filter((e,a)=>!(t.enableInfopaneDenseCardInteraction&&e.type!==N.pL.NativeAd&&e.type!==N.pL.CmsAd&&a>r)),a){const t=i[0]?.cardContent??(0,A.cZ)(i[0]).cardContent;a={...a,instanceId:`denseCard-${t.id}`}}const b=o.addOrUpdateChild({name:"DenseSlide",type:m.MJ.Headline}),f=(0,S.mZ)(),v=(0,G.h_)(),y={newsList:i?.map(e=>{const a=e.type===N.pL.NativeAd||e.type===N.pL.CmsAd;if(!a){const i=e.type===N.pL.WebContent;e.cardContent||(e=(0,A.cZ)(e));const{id:r,destinationUrl:o,title:s,provider:l}=e.cardContent,c=(0,z.D9)(e,d.L._240x129,f,n,v);return{id:r,destinationUrl:(0,u.EJ)((0,A.Dv)(o),t),title:s,ariaLabel:(0,A.yL)(s,l,t.localizedStrings),providerData:(0,A.p_)(l,i),isNativeAd:a,telemetryContext:(0,g.dj)(b,e.cardContent,e.metadata,p,i),isNarrowNewsItem:t.isNarrowNewsItem,imageData:c}}let i=e.placement?.items[0]||{};i=function(t){if(!t||!t.imageUrl)return t;const e=/https:\/\/images\.archive-digger\.com\/taboola\/image\/fetch\/f_jpg.+(http%3A%2F%2Fcdn.taboola.com%2F.+\.jpe?g)/,a=/^http:\/\/cdn.taboola.com\/.+\.jpe?g$/,i=t.imageUrl.trim(),n=(0,X.A)(t=>{if(0!==t.indexOf("https://images.archive-digger.com/taboola/"))return t;const i=t.match(e);if(!i||i.length<1)return t;const n=i[1],r=decodeURIComponent(n);return a.test(r)?r:t});return t.imageUrl=n(i),t}(i);const{beaconsJson:r,privacyUrl:o,adLabelText:s,geminiViewabilityDataJson:c}=e.placement||{};return{...i,beaconsJson:r,privacyUrl:o,adLabelText:s,geminiViewabilityDataJson:c,isNativeAd:a,adTelemetryContext:(0,h.u)(e,b,"infopane",0),isNarrowNewsItem:t.isNarrowNewsItem,isGreyAdsLabelEnabled:l}}),configOptions:t,cardSize:s,visualReadinessCallback:n};return{id:`denseCard-infopane-${c+1}`,childTemplateType:"dense-card",gridArea:"",telemetryObject:b,denseConfigInfo:a,denseData:y}}{let x=t.childExperienceReferencesWC?.denseCard||t.childExperienceReferences?.denseCard;const $=e?.subItems??e?.subCards,k=$[0]?.cardContent??(0,A.cZ)($[0]).cardContent,C=$[0]?.commentSummary?.totalCount??(0,A.cZ)($[0]).commentSummary?.totalCount??0,w=$[0]?.type===N.pL.WebContent,{id:T,destinationUrl:F,title:S,provider:D,type:I}=k,E=(0,A.Ie)($[0]),B=o.addOrUpdateChild({name:"DenseSlide",type:m.MJ.Headline}),M=(0,g.dj)(B,k,$[0].metadata,p,I===N.pL.WebContent),R=!0!==t.disableDenseArticleTemplate&&E?.width<E?.height;let L=d.L._240x129;R?L=d.L._240x253:t.useLargeHeroImageForDense&&(L=d.L._300x200);const O=(0,z.po)($[0],L,n,r,void 0,void 0,void 0,void 0,void 0,void 0,void 0,t.enableWebpFormat);let P=$?.slice(1);t?.enableDenseLayout1&&(P=[...$?.slice(0,$?.length-2),$[$?.length-1]]),P.length>_.Sl&&y&&(P=P.slice(0,_.Sl-1).concat(P[P.length-1])),x&&(x={...x,instanceId:`denseCard-${T}`});const H=w?ht(k):F,j={id:T,destinationUrl:(0,u.EJ)((0,A.Dv)(H),t),openLinksInNewTab:a,title:S,ariaLabel:(0,A.yL)(S,D,t.localizedStrings),imagePriority:!1,providerData:(0,A.p_)(D,w),isProviderInFooter:i,imageData:O,useArticleCardTemplate:R,telemetryContext:M,commentCount:Math.min(C,_.kZ),commentFlag:C>=v,newFlag:(0,_.IT)(k.publishedDateTime,f)},V={heroNews:!t.enableVideoOnDenseIp||I!==N.pL.Video&&"VideoPreview"!==I?j:(b.YT.addOrUpdateTmplString("densecard-hero-video"),{...j,videoMetadata:k.videoMetadata??{},externalVideoFiles:k.videoFiles??k.externalVideoFiles}),newsList:P?.map(a=>{const i=a.type===N.pL.NativeAd||a.type===N.pL.CmsAd;if(!i){const e=a.type===N.pL.WebContent;a.cardContent||(a=(0,A.cZ)(a));const n=a.metadata?.commentSummary?.totalCount??0,r=e?ht(a.cardContent):a.cardContent.destinationUrl;return{destinationUrl:(0,u.EJ)((0,A.Dv)(r),t),title:a.cardContent.title,ariaLabel:(0,A.yL)(S,a.cardContent.provider,t.localizedStrings),providerData:(0,A.p_)(a.cardContent.provider,e),isNativeAd:i,telemetryContext:(0,g.dj)(B,a.cardContent,a.metadata,p,e),isNarrowNewsItem:t.isNarrowNewsItem,commentCount:Math.min(n,_.kZ),commentFlag:n>=v,newFlag:(0,_.IT)(a.cardContent.publishedDateTime,f)}}const n=a.placement?.items[0]||{},{beaconsJson:r,privacyUrl:o,adLabelText:s,geminiViewabilityDataJson:d}=a.placement||{};return{...n,beaconsJson:r,privacyUrl:o,adLabelText:s,geminiViewabilityDataJson:d,isNativeAd:i,adTelemetryContext:(0,h.u)(a,B,"infopane",0),isNarrowNewsItem:t.isNarrowNewsItem,isGreyAdsLabelEnabled:l,enableInfopaneDVBeacon:t?.enableInfopaneDVBeacon,isXandrPlacement:!!e?.placement?.isXandrPlacement,id:`denseCard-infopane-${c+1}`}}),configOptions:t,cardSize:s};return{id:`denseCard-infopane-${c+1}`,childTemplateType:"dense-card",gridArea:"",telemetryObject:B,denseConfigInfo:x,denseData:V}}}function pt(t,e){if(ut(t.event.target,"MSFT-ATTRIBUTION"))for(const a of ut(t.event.target,"MSFT-ATTRIBUTION").children)if("attribution_container"===a.id){const t=a?.clientWidth,i=a?.children[0].clientWidth,n=a?.children[0],r=t-i<0?t-i:0;"ltr"===e?n.style.left=r+"px":n.style.right=r+"px"}}function gt(t,e){if(ut(t.event.target,"MSFT-ATTRIBUTION"))for(const a of ut(t.event.target,"MSFT-ATTRIBUTION").children)if("attribution_container"===a.id){const t=a.children[0];"ltr"===e?t.style.left="0px":t.style.right="0px"}}function ut(t,e){if(!t.children||0===t.children.length)return null;let a=null;const i=function(t,e){if(t.children&&0!==t.children.length)for(const n of t.children)n.nodeName===e&&(a=n),i(n,e)};return i(t,e),a}const ht=t=>{const{destinationUrl:e,id:a}=t||{},i=e?.includes("youtube.com");return i?(0,U.C)(encodeURIComponent(a),e):e}},64859(t,e,a){"use strict";a.d(e,{b(){return r},c(){return n}});var i=a(98378);const n=t=>{if(!t)return;const e=t.addOrUpdateChild({name:"InfopaneHeader",type:i.MJ.Headline}),a=t.addOrUpdateChild({name:"Infopane",type:i.MJ.Headline}),n=a.addOrUpdateChild({name:"previousSlideArrow",behavior:i.MS.More,content:{headline:"previousSlideArrow"},type:i.MJ.ActionButton}),r=a.addOrUpdateChild({name:"nextSlideArrow",behavior:i.MS.More,content:{headline:"nextSlideArrow"},type:i.MJ.ActionButton}),o=a.addOrUpdateChild({name:"playTransition",behavior:i.MS.More,content:{headline:"playTransition"},type:i.MJ.ActionButton}),s=a.addOrUpdateChild({name:"pauseTransition",behavior:i.MS.More,content:{headline:"pauseTransition"},type:i.MJ.ActionButton}),l=a.addOrUpdateChild({name:"seeMore",behavior:i.MS.More,content:{headline:"seeMore"},type:i.MJ.ActionButton}),c=a.addOrUpdateChild({name:"articledestination",behavior:i.MS.Navigate,content:{headline:"articledestination"},type:i.MJ.ActionButton}),d=a.addOrUpdateChild({name:"infopanetab",behavior:i.MS.More,content:{headline:"infopanetab"},type:i.MJ.ActionButton});return{componentRoot:t,infopaneHeader:e,infopane:a,nextSlideArrow:r,previousSlideArrow:n,playTransitionButton:o,pauseTransitionButton:s,articledestination:c,seeMoreButton:l,tabTelemetry:d}},r=t=>{t&&t.infopane&&(t.personalTelemetry=t.infopane.addOrUpdateChild({name:"PersonalizedInfopane",type:i.MJ.Headline}),t.singleTelemetry=t.infopane.addOrUpdateChild({name:"single",type:i.MJ.Headline}))}},41483(t,e,a){"use strict";a.d(e,{dU(){return Ce},RT(){return xe}});var i=a(89757),n=a(69259),r=a(68835),o=a(87906),s=a(40450),l=a(40201),c=a(67453),d=a(62679),p=a(44776),g=a(26330),u=a(47517),h=a(35177),b=a(99381),m=a(21386),f=a(69828),v=a(94664),y=a(91277),x=a(77387),$=a(94164),k=a(82521),C=a(54084),w=a(58623),_=a(89228),T=a(98728),F=a(71733),S=a(31157);const D="\nmsft-content-card.native-ad-infopane-pattern-overlay .info-pane-slide-title {\n    font-size: 16px;\n}\nmsft-content-card.native-ad-infopane-pattern-overlay::part(media) {\n    height: 100%;\n    border-radius: 0px;\n    overflow: hidden;\n}\nmsft-content-card:hover.native-ad-infopane-pattern-overlay::part(media) {\n    filter: unset;\n}\nmsft-content-card:hover.native-ad-infopane-pattern-overlay img {\n    filter: brightness(0.9);\n}\n",A=t=>!(!t.template||"msn-info-pane-pattern-overlay-1-by-1"!==t.template.templateType&&"msn-info-pane-pattern-overlay-4-by-3"!==t.template.templateType&&"msn-info-pane-horizontal-1-by-1"!==t.template.templateType&&"msn-info-pane-horizontal-3-by-4"!==t.template.templateType&&"msn-info-pane-horizontal-4-by-3"!==t.template.templateType&&"msn-info-pane-horizontal-9-by-16"!==t.template.templateType);var z,I,E,B,M,R,L=a(44978),N=a(9960),O=a(94172),P=a(56911),H=a(92011),j=a(55230),V=a(5096),U=a(38493),W=a(60815),G=a(73632),Z=a(72691);(I=z||(z={}))._1_column="1_column",I._2_column="2_column",(B=E||(E={})).LightDefault="lightDefault",B.LightNarrow="lightNarrow",B.LightLarge="lightLarge",B.LightWide="lightWide",B.LightStyle2="light2",(R=M||(M={})).vertical="vertical",R.horizontal="horizontal";class J extends H.L{constructor(){super(),this.slideKeyPressHandler=(t,e)=>{this.adjust(e),this.autoScrollHandler()},this.onPrevButtonClicked=()=>{this.adjust(-1),this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"),this.autoScrollHandler()},this.onNextButtonClicked=()=>{this.adjust(1),this.rotateDirection="forward",this.autoScrollHandler()},this.layout=z._2_column,this.freWelcomeAnimationRunning=!1,this.orientation=M.horizontal,this.activeindicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.touchStart=!1,this.touchStartX=0,this.touchStartTabpanelLayoutX=0,this.touchDeltaX=0,this.touchStartTime=0,this.handleSwipeMove=t=>{this.touchDeltaX=t-this.touchStartX,0==this.activeTabIndex&&this.touchDeltaX>=0||this.activeTabIndex==this.tabIds.length-1&&this.touchDeltaX<=0?this.touchStart=!1:(this.touchStart=!0,this.tabpanelLayout.style.transform=`translateX(${this.touchStartTabpanelLayoutX+this.touchDeltaX}px)`)},this.handleSwipeEnd=t=>{if(!this.touchStart)return;const e=this.clientWidth,a=(this.touchStartX-t)/e,i=((new Date).getTime()-this.touchStartTime)/1e3;Math.abs(a)>.5||Math.abs(a)>.1&&i<.15?this.adjust(a>0?1:-1,!1):this.moveToTabpanelByIndex(this.activeTabIndex,!0),this.touchStart=!1,this.touchStartX=0,this.touchDeltaX=0,this.touchStartTime=0},this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isFocusableElement=t=>!this.isDisabledElement(t),this.setTabs=()=>{const t=this.isHorizontal()?"gridColumn":"gridRow";this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.tabs.forEach((e,a)=>{if("tab"===e.slot&&this.isFocusableElement(e)){this.activeindicator&&(this.showActiveIndicator=!0);const t=this.tabIds[a],i=this.tabpanelIds[a];e.setAttribute("id","string"!=typeof t?`tab-${a+1}`:t),e.setAttribute("aria-selected",this.activeTabIndex===a?"true":"false"),e.setAttribute("aria-controls","string"!=typeof i?`panel-${a+1}`:i),e.addEventListener("click",this.handleTabClick),e.addEventListener("keydown",this.handleTabKeyDown),e.setAttribute("tabindex",this.activeTabIndex===a?"0":"-1"),this.activeTabIndex===a&&(this.activetab=e)}else this.showActiveIndicator=!1;e.style[t]=`${a+1}`,this.isHorizontal()?e.classList.remove("vertical"):e.classList.add("vertical")}),this.tabsShowOrNot&&this.activeTabIndex>=0&&(this.tabsShowOrNot[this.activeTabIndex]=!0)},this.setTabPanels=()=>{this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds();const t=this.clientWidth;if(this.tabpanels.forEach((e,a)=>{const i=this.tabIds[a],n=this.tabpanelIds[a];e.setAttribute("id","string"!=typeof n?`panel-${a+1}`:n),e.setAttribute("aria-labelledby","string"!=typeof i?`tab-${a+1}`:i),this.enableInfopaneSwipe?e.style.width=0==a&&0==t?"100%":`${t}px`:this.activeTabIndex!==a?e.setAttribute("hidden",""):e.removeAttribute("hidden")}),this.enableInfopaneSwipe){const t=1==Math.abs(this.prevActiveTabIndex-this.activeTabIndex);this.moveToTabpanelByIndex(this.activeTabIndex,t)}},this.handleTabClick=t=>{const e=t.currentTarget;1===e.nodeType&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(e),this.setComponent())},this.handleTabKeyDown=t=>{const e=t.key;if(this.isHorizontal())switch(e){case j.kT:t.preventDefault(),this.adjustBackward(t),this.enableInfopaneRefactoring&&(this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"));break;case j.bb:t.preventDefault(),this.adjustForward(t),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}else switch(e){case j.I5:t.preventDefault(),this.adjustBackward(t),this.enableInfopaneRefactoring&&(this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"));break;case j.HX:t.preventDefault(),this.adjustForward(t),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}switch(e){case"Home":t.preventDefault(),this.adjust(-this.activeTabIndex),this.enableInfopaneRefactoring&&(this.rotateDirection="forward");break;case"End":t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}},this.adjustForward=t=>{const e=this.tabs;let a=0;for(a=this.activetab?e.indexOf(this.activetab)+1:1,a===e.length&&(a=0);a<e.length&&e.length>1;){if(this.isFocusableElement(e[a])){this.moveToTabByIndex(e,a);break}if(this.activetab&&a===e.indexOf(this.activetab))break;a+1>=e.length?a=0:a+=1}},this.adjustBackward=t=>{const e=this.tabs;let a=0;for(a=this.activetab?e.indexOf(this.activetab)-1:0,a=a<0?e.length-1:a;a>=0&&e.length>1;){if(this.isFocusableElement(e[a])){this.moveToTabByIndex(e,a);break}a-1<0?a=e.length-1:a-=1}},this.moveToTabByIndex=(t,e)=>{const a=t[e];this.activetab=a,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=e,a.focus(),this.setComponent()},this.canAutoRotate=()=>this.enableInfopaneRefactoring?(this.enableRotateOnlyOnce&&!this.stopRotateDueShownAll&&0===this.activeTabIndex&&this.tabsShowOrNot&&this.tabsShowOrNot.every(t=>t)&&(this.stopRotateDueShownAll=!0),(!this.enableRotateAfterClick||!this.isFocusedOverAPeriodOfTime)&&(!this.stopRotateDueShownAll&&(!(!this.allowBlurScroll&&!this.isWindowFocused)&&(!(this.isFocused&&!this.enableRotateAfterClick)&&(!this.isMouseOver&&("visible"===document.visibilityState&&!!this.isInViewport)))))):!this.isFocused&&!this.isMouseOver&&(this.allowBlurScroll||!this.allowBlurScroll&&this.isWindowFocused)&&"visible"===document.visibilityState&&this.isInViewport,this.updateAutoRotateState=()=>{const t=this.canAutoRotate();t&&!this.timer?this.autoScrollHandler():!t&&this.timer&&this.clearAutoScrollHandler()},this.focusInHandler=(()=>(this.enableInfopaneRefactoring?(this.updateIsFocusedOverAPeriodOfTime(),this.isFocused=!0,this.updateAutoRotateState()):this.isFocused=!0,!0)).bind(this),this.focusOutHandler=(()=>(this.enableInfopaneRefactoring?(this.clearIsFocusedOverAPeriodOfTime(),this.isFocused=!1,this.updateAutoRotateState()):(this.isFocused=!1,this.autoScrollHandler()),!0)).bind(this),this.windowFocusHandler=(()=>{this.enableInfopaneRefactoring?(this.isWindowFocused=!0,this.updateAutoRotateState()):(this.isWindowFocused=!0,this.autoScrollHandler())}).bind(this),this.windowBlurHandler=(()=>{this.enableInfopaneRefactoring?(this.isWindowFocused=!1,this.updateAutoRotateState()):this.isWindowFocused=!1}).bind(this),this.mouseInHandler=(()=>(this.enableInfopaneRefactoring?(this.isMouseOver=!0,this.updateAutoRotateState()):(this.isMouseOver=!0,this.autoScrollHandler()),!0)).bind(this),this.mouseOutHandler=(()=>(this.enableInfopaneRefactoring?(this.isMouseOver=!1,this.updateAutoRotateState()):(this.isMouseOver=!1,this.autoScrollHandler()),!0)).bind(this),this.windowVisiabilityChange=(()=>{this.updateAutoRotateState()}).bind(this),this.touchStartHandler=(t=>{this.tabpanelLayout.classList.remove("tappanel-scroll-anim"),this.handleSwipeStart(t.touches[0].clientX)}).bind(this),this.touchMoveHandler=(t=>{t.preventDefault(),this.handleSwipeMove(t.touches[0].clientX)}).bind(this),this.touchEndHandler=(t=>{this.handleSwipeEnd(t.changedTouches[0].clientX)}).bind(this)}handleChange(){this.direction=Z.o.getValueFor(this)}connectedCallback(){super.connectedCallback(),this.direction=Z.o.getValueFor(this),(0,G.S)()&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.isFocused=!1,this.isWindowFocused=!0,this.isMouseOver=!1,this.rotateDirection="forward",Z.o.subscribe(this),this.activeindicator||(this.activeindicator=!1),this.addEventListeners(),this.autoScrollHandler(),this.setIntersectionObserver())}disconnectedCallback(){super.disconnectedCallback(),this.enableInfopaneRefactoring?this.clearAutoScrollHandler():window.clearTimeout(this.timer),Z.o.unsubscribe(this),this.removeEventListeners(),this.unsetIntersectionObserver(),this.tabs.forEach(t=>{t.removeEventListener("click",this.handleTabClick),t.removeEventListener("keydown",this.handleTabKeyDown)})}updateIsFocusedOverAPeriodOfTime(){this.isFocusedOverAPeriodOfTime=!0,this.focusTimer&&(window.clearTimeout(this.focusTimer),this.focusTimer=null),this.focusTimer=window.setTimeout(()=>{this.isFocusedOverAPeriodOfTime=!1,this.updateAutoRotateState(),this.focusTimer=null},(this.rotateAfterClickIntervalMs||1e4)-(this.autoScrollIntervalMs||6e3))}clearIsFocusedOverAPeriodOfTime(){this.focusTimer&&(window.clearTimeout(this.focusTimer),this.focusTimer=null),this.isFocusedOverAPeriodOfTime=!1}clearAutoScrollHandler(){this.timer&&window.clearTimeout(this.timer),this.timer=null}autoScrollHandler(t=0){if(this.enableInfopaneRefactoring){if(this.disableAutoScroll||this.freWelcomeAnimationRunning)return void this.clearAutoScrollHandler();let e=0;e=t||(0===this.activeTabIndex&&void 0!==this.firstAutoScrollIntervalMs?this.firstAutoScrollIntervalMs:this.adTimerMap&&this.adTimerMap[this.activeTabIndex]?(this.autoScrollIntervalMs||6e3)+this.adTimerMap[this.activeTabIndex]:this.autoScrollIntervalMs||6e3),this.clearAutoScrollHandler(),this.timer=window.setTimeout(()=>{if(this.timer=null,this.canAutoRotate()){switch(this.rotateDirection){case"forward":this.adjust(1,!0);break;case"backward":this.adjust(-1,!0)}performance.mark("InfoPaneAR"),this.autoScrollHandler()}},e)}else{if(this.disableAutoScroll||this.freWelcomeAnimationRunning)return void window.clearTimeout(this.timer);let t=0;t=0===this.activeTabIndex&&void 0!==this.firstAutoScrollIntervalMs?this.firstAutoScrollIntervalMs:this.adTimerMap&&this.adTimerMap[this.activeTabIndex]?(this.autoScrollIntervalMs||6e3)+this.adTimerMap[this.activeTabIndex]:this.autoScrollIntervalMs||6e3,this.timer&&window.clearTimeout(this.timer),this.timer=window.setTimeout(()=>{this.canAutoRotate()&&(this.adjust(1,!0),performance.mark("InfoPaneAR")),this.autoScrollHandler()},t)}}activeidChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(t,e){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition()),e&&(this.tabsShowOrNot=e.map(()=>!1),this.stopRotateDueShownAll=!1)}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition(),this.activeid=this.tabIds[this.activeTabIndex])}getTabpanelLayoutX(){const t=this.tabpanelLayout.style.transform,e=parseInt(t.replace("translateX(","").replace("px",""));return isNaN(e)?0:e}handleSwipeStart(t){this.touchStartTime=(new Date).getTime(),this.touchStartX=t,this.touchStartTabpanelLayoutX=this.getTabpanelLayoutX(),this.touchDeltaX=0}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}moveToTabpanelByIndex(t,e){const a=this.clientWidth;e?this.tabpanelLayout.classList.add("tappanel-scroll-anim"):this.tabpanelLayout.classList.remove("tappanel-scroll-anim"),this.tabpanelLayout.style.transform=`translateX(${-a*t}px)`}getTabIds(){return this.tabs.map(t=>t.getAttribute("id"))}getTabPanelIds(){return this.tabpanels.map(t=>t.getAttribute("id"))}setComponent(t){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.change(),this.setTabs(),this.handleActiveIndicatorPosition(),this.setTabPanels(),t||this.focusTab(),this.change())}isHorizontal(){return this.orientation===M.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",e=this.isHorizontal()?"translateX":"translateY",a=this.isHorizontal()?"offsetLeft":"offsetTop",i=this.activeIndicatorRef[a];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const n=this.activeIndicatorRef[a]-i;0!=n&&(this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`),this.activeIndicatorRef.style.transform=`${e}(${n}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${e}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")},{once:!0})}adjust(t,e){this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=(0,V.Vf)(0,this.tabs.length-1,this.activeTabIndex+t),this.setComponent(e)}focusTab(){this.tabs[this.activeTabIndex].focus()}addEventListeners(){this.allowBlurScroll||(this.enableInfopaneRefactoring&&document.addEventListener("visibilitychange",this.windowVisiabilityChange,!0),window.addEventListener("focus",this.windowFocusHandler,!0),window.addEventListener("blur",this.windowBlurHandler,!0))}removeEventListeners(){this.allowBlurScroll||(this.enableInfopaneRefactoring&&document.removeEventListener("visibilitychange",this.windowVisiabilityChange,!0),window.removeEventListener("focus",this.windowFocusHandler,!0),window.removeEventListener("blur",this.windowBlurHandler,!0))}setIntersectionObserver(){if(this.intersectionObserver)return;this.intersectionObserver=new IntersectionObserver(t=>{this.isInViewport=t[0].intersectionRatio>0,this.enableInfopaneRefactoring&&this.updateAutoRotateState()},{threshold:[0]}),this.intersectionObserver.observe(this)}unsetIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}}(0,P.Cg)([U.CF],J.prototype,"layout",void 0),(0,P.Cg)([(0,U.CF)({attribute:"auto-scroll",mode:"boolean"})],J.prototype,"autoScroll",void 0),(0,P.Cg)([(0,U.CF)({attribute:"disable-auto-scroll",mode:"boolean"})],J.prototype,"disableAutoScroll",void 0),(0,P.Cg)([(0,U.CF)({attribute:"enable-rotate-after-click",mode:"boolean"})],J.prototype,"enableRotateAfterClick",void 0),(0,P.Cg)([U.CF],J.prototype,"rotateAfterClickIntervalMs",void 0),(0,P.Cg)([(0,U.CF)({attribute:"auto-scroll-interval-ms"})],J.prototype,"autoScrollIntervalMs",void 0),(0,P.Cg)([(0,U.CF)({attribute:"first-auto-scroll-interval-ms"})],J.prototype,"firstAutoScrollIntervalMs",void 0),(0,P.Cg)([(0,U.CF)({attribute:"allow-blur-scroll",mode:"boolean"})],J.prototype,"allowBlurScroll",void 0),(0,P.Cg)([(0,U.CF)({attribute:"use-windows-styles",mode:"boolean"})],J.prototype,"useWindowsStyles",void 0),(0,P.Cg)([(0,U.CF)({attribute:"enable-rotate-only-once",mode:"boolean"})],J.prototype,"enableRotateOnlyOnce",void 0),(0,P.Cg)([(0,U.CF)({attribute:"enable-infopane-refactoring",mode:"boolean"})],J.prototype,"enableInfopaneRefactoring",void 0),(0,P.Cg)([(0,U.CF)({attribute:"enable-infopane-swipe",mode:"boolean"})],J.prototype,"enableInfopaneSwipe",void 0),(0,P.Cg)([(0,U.CF)({attribute:"infopane-prominent-flipper",mode:"boolean"})],J.prototype,"infoPaneProminentFlipper",void 0),(0,P.Cg)([(0,U.CF)({attribute:"rotate-prev-after-click-prev-button",mode:"boolean"})],J.prototype,"rotateBackAfterClickPrevButton",void 0),(0,P.Cg)([(0,U.CF)({attribute:"rotate-stop-after-click-prev-button",mode:"boolean"})],J.prototype,"rotateStopAfterClickPrevButton",void 0),(0,P.Cg)([W.sH],J.prototype,"infoPaneFlipperStyle",void 0),(0,P.Cg)([W.sH],J.prototype,"previousFlipperTitle",void 0),(0,P.Cg)([W.sH],J.prototype,"nextFlipperTitle",void 0),(0,P.Cg)([W.sH],J.prototype,"nextFlipperTelemetryTag",void 0),(0,P.Cg)([W.sH],J.prototype,"previousFlipperTelemetryTag",void 0),(0,P.Cg)([W.sH],J.prototype,"direction",void 0),(0,P.Cg)([W.sH],J.prototype,"tabpanelLayout",void 0),(0,P.Cg)([U.CF],J.prototype,"orientation",void 0),(0,P.Cg)([U.CF],J.prototype,"activeid",void 0),(0,P.Cg)([W.sH],J.prototype,"tabs",void 0),(0,P.Cg)([W.sH],J.prototype,"tabpanels",void 0),(0,P.Cg)([(0,U.CF)({mode:"boolean"})],J.prototype,"activeindicator",void 0),(0,P.Cg)([W.sH],J.prototype,"activeIndicatorRef",void 0),(0,P.Cg)([W.sH],J.prototype,"showActiveIndicator",void 0);var X=a(43799),Q=a(93809),q=a(82774),Y=a(60402),K=a(96016),tt=a(2399),et=a(26106),at=a.n(et),it=a(30961),nt=a.n(it);const rt=i.qy`<span aria-hidden="true" part="next" class="next"><slot name="next"><svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z" /></svg></slot></span>`,ot=i.qy`<span aria-hidden="true" part="previous" class="previous"><slot name="previous"><svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z" /></svg></slot></span>`,st=i.qy`<span part="next" class="filled-next"><slot name="filled-next">${i.qy.partial(nt())}</slot></span>`,lt=i.qy`<span part="previous" class="filled-previous"><slot name="filled-previous">${i.qy.partial(at())}</slot></span>`,ct=t=>t.infoPaneProminentFlipper||[E.LightStyle2,E.LightDefault,E.LightLarge,E.LightNarrow,E.LightWide].includes(t.infoPaneFlipperStyle),dt=t=>`${t.useWindowsStyles?"windows":""} ${t.infoPaneFlipperStyle===E.LightNarrow?"flipper-light-narrow":""} ${t.infoPaneFlipperStyle===E.LightLarge?"flipper-light-large":""} ${t.infoPaneFlipperStyle===E.LightWide?"flipper-light-wide":""} ${t.infoPaneFlipperStyle===E.LightDefault?"flipper-light":""} ${t.infoPaneFlipperStyle===E.LightStyle2?"flipper-light2":""}`,pt=i.qy`<template @mouseenter=${(0,Q.F)(t=>t.mouseInHandler(),{capture:!0})} @focusin=${(0,Q.F)(t=>t.focusInHandler(),{capture:!0})} @focusout=${(0,Q.F)(t=>t.focusOutHandler(),{capture:!0})} @mouseleave=${(0,Q.F)(t=>t.mouseOutHandler(),{capture:!0})}><slot name="previous-flipper"><button title="${t=>t.previousFlipperTitle}" part="previous-flipper" class="previous-flipper ${t=>t.infoPaneProminentFlipper?"opacity-one-previous-flipper":""} ${t=>dt(t)}" tabIndex="0" @keypress="${(t,e)=>t.enableInfopaneRefactoring?t.onPrevButtonClicked():t.slideKeyPressHandler(e.event,-1)}" @click="${(t,e)=>t.enableInfopaneRefactoring?t.onPrevButtonClicked():t.slideKeyPressHandler(e.event,-1)}" data-t="${t=>t.previousFlipperTelemetryTag}">${(0,n.z)(t=>t.direction===S.O.rtl,i.qy` ${(0,n.z)(t=>t.useWindowsStyles,i.qy`${i.qy.partial(tt.A)}`)} ${(0,n.z)(t=>!t.useWindowsStyles,t=>ct(t)?st:rt)} `)} ${(0,n.z)(t=>t.direction===S.O.ltr,i.qy` ${(0,n.z)(t=>t.useWindowsStyles,i.qy`${i.qy.partial(K.A)}`)} ${(0,n.z)(t=>!t.useWindowsStyles,t=>ct(t)?lt:ot)} `)}</button></slot>${X.p}<div class="tablist ${t=>t.useWindowsStyles?"windows":""}" part="tablist" role="tablist"><slot class="tab" name="tab" part="tab" ${(0,q.e)("tabs")}></slot>${(0,n.z)(t=>t.activeindicator,i.qy`<div ${(0,Y.K)("activeIndicatorRef")} class="activeIndicator" part="activeIndicator"></div>`)}</div><slot name="next-flipper"><button title="${t=>t.nextFlipperTitle}" part="next-flipper" class="next-flipper ${t=>t.infoPaneProminentFlipper?"opacity-one-next-flipper":""} ${t=>dt(t)}" tabIndex="0" @keypress="${(t,e)=>t.enableInfopaneRefactoring?t.onNextButtonClicked():t.slideKeyPressHandler(e.event,1)}" @click="${(t,e)=>t.enableInfopaneRefactoring?t.onNextButtonClicked():t.slideKeyPressHandler(e.event,1)}" data-t="${t=>t.nextFlipperTelemetryTag}">${(0,n.z)(t=>t.direction===S.O.rtl,i.qy` ${(0,n.z)(t=>t.useWindowsStyles,i.qy`${K.A}`)} ${(0,n.z)(t=>!t.useWindowsStyles,t=>ct(t)?lt:ot)} `)} ${(0,n.z)(t=>t.direction===S.O.ltr,i.qy` ${(0,n.z)(t=>t.useWindowsStyles,i.qy`${tt.A}`)} ${(0,n.z)(t=>!t.useWindowsStyles,t=>ct(t)?st:rt)} `)}</button></slot>${X.S}<div class=${t=>t.enableInfopaneSwipe?"tabpanelscroll":"tabpanel"} ${(0,Y.K)("tabpanelLayout")} @touchstart=${(0,Q.F)((t,e)=>(t.enableInfopaneRefactoring&&t.touchStartHandler(e.event),!0),{capture:!0})} @touchmove=${(0,Q.F)((t,e)=>(t.enableInfopaneRefactoring&&t.touchMoveHandler(e.event),!0),{capture:!0})} @touchend=${(0,Q.F)((t,e)=>(t.enableInfopaneRefactoring&&t.touchEndHandler(e.event),!0),{capture:!0})} @on-welcome-animation=${(t,e)=>{t.freWelcomeAnimationRunning=!0,t.autoScrollHandler()}} @after-welcome-animation=${(t,e)=>{t.freWelcomeAnimationRunning=!1,t.autoScrollHandler()}}><slot name="tabpanel" part="tabpanel" ${(0,q.e)("tabpanels")}></slot></div></template>`;var gt=a(7896),ut=a(41123),ht=a(47810),bt=a(57416),mt=a(37998),ft=a(95403),vt=a(64835),yt=a(86856),xt=a(64187),$t=a(22131),kt=a(50882),Ct=a(59669),wt=a(73477),_t=a(49991);const Tt="M12.2676 15.793C11.9677 16.0787 11.493 16.0672 11.2073 15.7672L6.20597 10.5168C5.93004 10.2271 5.93004 9.77187 6.20597 9.4822L11.2073 4.23173C11.493 3.93181 11.9677 3.92028 12.2676 4.20597C12.5676 4.49166 12.5791 4.96639 12.2934 5.26631L7.78483 9.99949L12.2934 14.7327C12.5791 15.0326 12.5676 15.5073 12.2676 15.793Z",Ft="M7.73271 4.20694C8.03263 3.92125 8.50737 3.93279 8.79306 4.23271L13.7944 9.48318C14.0703 9.77285 14.0703 10.2281 13.7944 10.5178L8.79306 15.7682C8.50737 16.0681 8.03263 16.0797 7.73271 15.794C7.43279 15.5083 7.42125 15.0336 7.70694 14.7336L12.2155 10.0005L7.70694 5.26729C7.42125 4.96737 7.43279 4.49264 7.73271 4.20694Z",St=Ct.A` .previous-flipper.windows:hover > svg > path,.previous-flipper.windows:focus-visible > svg > path{d:path("${Tt}")}.next-flipper.windows:hover > svg > path,.next-flipper.windows:focus-visible > svg > path{d:path("${Ft}")}`,Dt=Ct.A` .previous-flipper.windows:hover > svg > path,.previous-flipper.windows:focus-visible > svg > path{d:path("${Ft}")}.next-flipper.windows:hover > svg > path,.next-flipper.windows:focus-visible > svg > path{d:path("${Tt}")}`,At=Ct.A` ${(0,xt.V)("grid")} :host{--elevation:4;box-sizing:border-box;font-family:${gt.O};font-size:${ut.K};line-height:${ut.Z};color:${ht.l};background:${_t.dR};border-radius:calc(${bt.JU} * 1px);${mt.ET};overflow:hidden;height:100%;grid-template-columns:auto 1fr auto;grid-template-rows:auto 1fr;width:100%}:host(:hover) ::slotted([slot="previous-flipper"]),:host(:hover) .previous-flipper,:host(:hover) ::slotted([slot="next-flipper"]),:host(:hover) .next-flipper{opacity:1;transition:opacity 0.2s ease-in-out}:host(.light:hover) .previous-flipper:before,:host(.light:hover) .next-flipper:before{opacity:1;background:${ht.l}}.tappanel-scroll-anim{transition:transform .3s}.tablist{display:grid;grid-template-rows:auto auto;grid-template-columns:auto;position:absolute;bottom:6px;left:50%;transform:translate(-50%);width:max-content;align-self:center;justify-self:center;grid-row:1;grid-column:1 / span 3;z-index:3;cursor:pointer}.tablist.windows{display:none}.previous-flipper.windows,.next-flipper.windows{margin:0 8px;width:32px;height:32px;border-radius:16px;display:flex;align-items:center;justify-content:center;border:0px;--elevation:8;${mt.ET};background:${ht.l};fill:${ft.Wl}}.previous-flipper.windows:hover,.next-flipper.windows:hover,.previous-flipper.windows:focus-visible,.next-flipper.windows:focus-visible{--elevation:16}::slotted([slot="previous-flipper"]),.previous-flipper:not(.windows),::slotted([slot="next-flipper"]),.next-flipper:not(.windows){width:30px;height:56px;display:flex;justify-content:center;align-items:center;margin:0;position:relative;fill:${ht.l};color:${ht.l};background:transparent;border:none;padding:0}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-narrow:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-narrow:not(.windows){width:24px;height:72px;fill:currentColor;color:${ft.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-wide:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-wide:not(.windows){width:32px;height:72px;fill:currentColor;color:${ft.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-large:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-large:not(.windows){width:32px;height:64px;fill:currentColor;color:${ft.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-narrow:not(.windows),.previous-flipper.flipper-light-large:not(.windows),.previous-flipper.flipper-light-wide:not(.windows){inset-inline-start:4px}::slotted([slot="previous-flipper"]),.next-flipper.flipper-light-narrow:not(.windows),.next-flipper.flipper-light-large:not(.windows),.next-flipper.flipper-light-wide:not(.windows){inset-inline-end:4px}::slotted([slot="previous-flipper"]),.previous-flipper{grid-column:1;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}::slotted([slot="next-flipper"]),.next-flipper{grid-column:3;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}.previous-flipper.flipper-light2{margin-inline-start:2px}.next-flipper.flipper-light2{margin-inline-end:2px}.previous-flipper.flipper-light2,.next-flipper.flipper-light2{width:24px;height:48px;opacity:1}.previous-flipper.flipper-light2,.next-flipper.flipper-light2,.previous-flipper.flipper-light,.next-flipper.flipper-light,.previous-flipper.flipper-light-narrow,.next-flipper.flipper-light-narrow,.previous-flipper.flipper-light-large,.next-flipper.flipper-light-large,.previous-flipper.flipper-light-wide,.next-flipper.flipper-light-wide{fill:currentColor;color:${ft.wO}}::slotted([slot="previous-flipper"])::before,.previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper:not(.windows)::before{content:"";opacity:0.3;background:${ft.Wl};position:absolute;top:0;right:0;left:0;bottom:0;transition:all 0.1s ease-in-out}.previous-flipper.flipper-light:focus-visible::before,.next-flipper.flipper-light:focus-visible::before,.previous-flipper.flipper-light::before,.next-flipper.flipper-light::before{background:${ht.l};box-shadow:rgba(0,0,0,0.1) 0px 2px 4px;opacity:0.5}.previous-flipper.flipper-light2:focus-visible::before,.next-flipper.flipper-light2:focus-visible::before,.previous-flipper.flipper-light-narrow:focus-visible::before,.next-flipper.flipper-light-narrow:focus-visible::before,.previous-flipper.flipper-light-large:focus-visible::before,.next-flipper.flipper-light-large:focus-visible::before,.previous-flipper.flipper-light-wide:focus-visible::before,.next-flipper.flipper-light-wide:focus-visible::before,.previous-flipper.flipper-light2::before,.next-flipper.flipper-light2::before,.previous-flipper.flipper-light-narrow::before,.next-flipper.flipper-light-narrow::before,.previous-flipper.flipper-light-large::before,.next-flipper.flipper-light-large::before,.previous-flipper.flipper-light-wide::before,.next-flipper.flipper-light-wide::before{border-radius:2px;background:${ht.l};box-shadow:rgba(0,0,0,0.1) 0px 2px 4px;opacity:0.5;transition:opacity 0.3s linear 0s}.previous-flipper.flipper-light-narrow::after,.next-flipper.flipper-light-narrow::after,.previous-flipper.flipper-light-wide::after,.next-flipper.flipper-light-wide::after{content:"";position:absolute;top:-4px;right:-4px;left:-4px;bottom:-4px}::slotted([slot="previous-flipper"])::before,.previous-flipper.opacity-one-previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper.opacity-one-next-flipper:not(.windows)::before{opacity:1}.next,.previous{position:relative;${""} width:16px;height:16px}.filled-next,.filled-previous{position:relative;width:24px;height:24px}::slotted([slot="previous-flipper"]:hover),.previous-flipper:hover,::slotted([slot="next-flipper"]:hover),.next-flipper:hover{cursor:pointer}::slotted([slot="previous-flipper"]:${wt.N}),.previous-flipper:${wt.N},::slotted([slot="next-flipper"]:${wt.N}),.next-flipper:${wt.N}{opacity:1}::slotted([slot="previous-flipper"]:${wt.N})::before,.previous-flipper:${wt.N}::before,::slotted([slot="next-flipper"]:${wt.N})::before,.next-flipper:${wt.N}::before{background:${ft.oO};opacity:1}::slotted([slot="previous-flipper"]:hover)::before,.previous-flipper:hover::before,::slotted([slot="next-flipper"]:hover)::before,.next-flipper:hover::before{background:${ft.oO};opacity:1}:host([layout="1-column"]){--heading-font-size:${ut.K};--heading-line-height:${ut.Z}}.activeIndicator{grid-row:2;grid-column:1;width:20px;height:3px;border-radius:calc(${bt.Pb} * 1px);justify-self:center;background:${vt.IR}}.activeIndicatorTransition{transition:transform 0.2s ease-in-out}.tabpanel{grid-row:1/3;grid-column-start:1;grid-column-end:4;position:relative}.tabpanelscroll{position:absolute;height:100%;display:flex}`.withBehaviors(new yt.t(St,Dt),(0,$t.G2)(Ct.A` ::slotted([slot="previous-flipper"]),.previous-flipper:not(.windows),::slotted([slot="next-flipper"]),.next-flipper:not(.windows){fill:${ft.Wl};color:${ft.Wl}}::slotted([slot="previous-flipper"])::before,.previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper:not(.windows)::before{background:${ht.l}}::slotted([slot="previous-flipper"]:hover)::before,.previous-flipper:hover::before,::slotted([slot="next-flipper"]:hover)::before,.next-flipper:hover::before{background:${ht.l}}.previous-flipper.windows,.next-flipper.windows{fill:${ht.l};background:${_t.dR}}`),(0,$t.mr)(Ct.A` .activeIndicator{forced-color-adjust:none;background:${kt.A.Highlight}}.previous-flipper.windows,.next-flipper.windows{background:${kt.A.ButtonFace}}.previous-flipper.windows:hover,.next-flipper.windows:hover,.previous-flipper.windows:focus-visible,.next-flipper.windows:focus-visible{background:${kt.A.Highlight};fill:${kt.A.HighlightText}}`));var zt=a(34897),It=a(13660),Et=a(651);let Bt=class extends J{};Bt=(0,P.Cg)([(0,H.E)({name:"msn-info-pane",template:pt,styles:At})],Bt),zt.L.define(Et.i.registry),It.K.define(Et.i.registry);var Mt=a(37903),Rt=a(66864);class Lt extends Rt.t{constructor(){super(...arguments),this.effectId="",this.isEnabled=!1,this.intersectionRootMargin="0px 0px 0px 0px",this.animationType="",this.showMultiTimes=!1,this.isAnimationValid=!1,this.updateAnimStatus=(t,e)=>{this.isAnimationValid!==t&&(this.isAnimationValid=t,t&&e&&setTimeout(()=>{e()},this.animationConfig.duration))}}connectedCallback(){if(super.connectedCallback(),this.animationType){this.effectGroup=Mt.t.getEffectGroup();const t={root:this.intersectionRoot,rootMargin:this.intersectionRootMargin};this.effectGroup.register(this.effectId,this.animContainer,this.updateAnimStatus,t,this.showMultiTimes,this.animationConfig.delayTimeMs)}}disconnectedCallback(){super.disconnectedCallback(),this.animationType&&this.effectGroup.unregister(this.effectId)}}(0,P.Cg)([U.CF],Lt.prototype,"effectId",void 0),(0,P.Cg)([(0,U.CF)({mode:"boolean"})],Lt.prototype,"isEnabled",void 0),(0,P.Cg)([U.CF],Lt.prototype,"intersectionRoot",void 0),(0,P.Cg)([U.CF],Lt.prototype,"intersectionRootMargin",void 0),(0,P.Cg)([U.CF],Lt.prototype,"animationType",void 0),(0,P.Cg)([U.CF],Lt.prototype,"animationConfig",void 0),(0,P.Cg)([(0,U.CF)({mode:"boolean"})],Lt.prototype,"showMultiTimes",void 0),(0,P.Cg)([W.sH],Lt.prototype,"isAnimationValid",void 0);const Nt={"scale-up":"animation1","scale-down":"animation1","scale-up-down":"animation2","opacity-up":"opacity-up-animation","move-up":"move-up-animation","move-up2":"move-up-animation2"},Ot=i.qy`<style>.anim-container { overflow: hidden; width: 100%; height: 100%; } .anim-container div { transform: scale(${t=>t.animationConfig?.scaleFrom||1}); } .anim-wrapper { animation: ${t=>Nt[t.animationType]} ${t=>t.animationConfig?.durationString} forwards; } .anim-wrapper-initial { opacity: ${t=>t.animationConfig?.initialOpacity?t.animationConfig?.initialOpacity:1}; } @keyframes animation1 { 0% { transform: scale(${t=>t.animationConfig?.scaleFrom}); } 100% { transform: scale(${t=>t.animationConfig?.scaleTo}); } } @keyframes animation2 { 0% { transform: scale(${t=>t.animationConfig?.scaleFrom}); } 50% { transform: scale(${t=>t.animationConfig?.scaleTo}); } 100% { transform: scale(${t=>t.animationConfig?.scaleFrom}); } } @keyframes opacity-up-animation { 0% { opacity: 0; } 66% { opacity: 0; } 100% { opacity: 1; } } @keyframes move-up-animation { 0% { transform: translate(0px, 100%); opacity: 0; } 33% { transform: translate(0px, 0px); opacity: 1; } 66% { transform: translate(0px, 0px); opacity: 1; } 100% { transform: translate(0px, -100%); opacity: 0; } } @keyframes move-up-animation2 { 0% { transform: translate(0px, 100%); opacity: 0; } 66% { transform: translate(0px, 100%); opacity: 0; } 100% { transform: translate(0px, 0px); opacity: 1; } }</style><div class="anim-container">${(0,n.z)(t=>t.animationType&&t.animationConfig,i.qy`<div class=${t=>t.isAnimationValid?"anim-wrapper":"anim-wrapper-initial"} ${(0,Y.K)("animContainer")}><span part="anim-content"><slot name="anim-content"></slot></span></div>`)} ${(0,n.z)(t=>!t.animationType,i.qy`<slot name="anim-content"></slot>`)}</div>`;var Pt=a(16559);const Ht=Ct.A``.withBehaviors(new Pt.e("layoutStyle"));let jt=class extends Lt{};jt=(0,P.Cg)([(0,H.E)({name:"msn-animation-decorator",template:Ot,styles:Ht})],jt);var Vt=a(30383),Ut=a(30337),Wt=a(66459),Gt=a(82988),Zt=a(2188),Jt=a(77833),Xt=a(10371),Qt=a(42537),qt=a(60941),Yt=a(14097),Kt=a(58034);Wt.j,Vt._t;const te=i.qy`
    <msn-info-pane-tab id="tab_${t=>t.id}" aria-label="${t=>t.title}"></msn-info-pane-tab>
`,ee=i.qy`
<msn-info-pane-panel id="tab_panel_${t=>t.id}">
    <msft-info-pane-slide>
        ${Qt.B}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,ae=i.qy`
    <style>
        .card-button {
            border-radius: 100%;
        }

        /* 
         * Here about 'from the web' attribution style
         */
        msft-article[id="contentcard_${t=>t.id}"]::part(start-actions) {
            flex:1;
            padding-inline-end: 6px;
        }
        msft-article[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-article[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
        msft-article[id="contentcard_${t=>t.id}"] msft-attribution, msft-article[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
            ${t=>t.isProviderIconClickable?"display: inline-flex":""}
        }
        msft-article[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-article[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }   
    </style>
    <msn-info-pane-panel id="tab_panel_${t=>t.id}">
        <msft-info-pane-slide>
            <msft-article-card
                size="${t=>t.cardSize}"
                card-fill-color="${t=>t.articleCardBackgroundColor?.find(t=>t.isDarkMode===(0,N.ud)())?.hexColor}"
                class="infopane"
            >
                <msft-article
                    id="contentcard_${t=>t.id}"
                    href=${t=>t.destinationUrl}
                    target=${t=>t.openLinksInNewTab||t.openArticleInNewTab?"_blank":"_self"}
                    title=${t=>t.disableCardTitleTooltip?"":t.title}
                    aria-label=${t=>t.ariaLabel}
                    data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}"
                    :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
                    :handleContentCardClickOverride=${t=>t.handleContentCardClickOverride}
                    @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
                    @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
                >
                    ${(0,n.z)(t=>t.contentIndicator,t=>(0,l.Z)(t.contentIndicator))}
                    ${(0,n.z)(t=>t.imageData,i.qy`
                        <img
                            slot="image"
                            alt="${t=>t.imageData.altText}"
                            src="${t=>t.imageData.source}"
                            @load="${t=>t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback()}"
                        />
                    `)}
                    ${c.y}
                    ${(0,n.z)(t=>t.abstract&&!t.isMsnHpExternalLinkCard,i.qy`
                        <p slot="abstract" style="display: -webkit-box; -webkit-line-clamp: ${t=>t.contentIndicator?"3":"4"}; -webkit-box-orient: vertical; overflow: hidden;">
                            ${t=>t.abstract}
                        </p>
                    `)}
                    ${(0,d.fn)("start-action")}
                    ${(0,n.z)(t=>!t.isAnaheimDesign,i.qy`
                        <div slot="start-action" style="gap:0">
                            ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled&&!t.enableRichSocialReaction,i.qy`
                                ${p.LW}
                                ${p.tB}
                            `)}
                            ${(0,n.z)(t=>t.enableRichSocialReaction,()=>(0,p.nj)({}))}
                        </div>
                    `)}
                    <div slot="end-action" style="gap:0">
                        ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled,i.qy`
                            ${(0,n.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,i.qy`
                                ${(0,n.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&L.J.showMore,p.LW)}
                                ${(0,n.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&L.J.showFewer,p.tB)}
                            `)}
                            ${(0,n.z)(t=>t.enableWCCardAction,g.L)}
                        `)}
                    </div>
                    ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled,u.C)}
                </msft-article>
            </msft-article-card>
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,ie=i.qy`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-info-pane-slide {
            width: 100%;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        
        ${(0,n.z)(t=>t.contentType===Jt.pL.Video,i.qy`
            msft-content-card[id="contentcard_${t=>t.id}"] msft-content-indicator {
                color: transparent;
                left: 286px;
                top: 100px;
            }
            msft-content-card[id="contentcard_${t=>t.id}"] msft-content-indicator::after{
                background: transparent;
            }
        `)}

        /* 
         * Here and elsewhere about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"]::part(start-actions) {
            flex:1;
            padding-inline-end: 6px;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <msn-info-pane-panel id="tab_panel_${t=>t.id}">
        <msft-info-pane-slide>
            <msft-content-card
                id="contentcard_${t=>t.id}"
                class="${t=>Ce(t)}"
                href=${t=>t.destinationUrl}
                target=${t=>t.openLinksInNewTab||t.openArticleInNewTab?"_blank":"_self"}
                :handleContentCardClickOverride=${t=>t.handleContentCardClickOverride}
                title=${t=>t.disableCardTitleTooltip?"":t.id.includes("BuyDirectCard")?t.abstract:t.title}
                aria-label=${t=>t.ariaLabel}
                layout=${t=>t.cardLayout}
                data-t="${t=>t.telemetryContext&&t.telemetryContext.contentCard&&t.telemetryContext.contentCard.getMetadataTag()}"
                :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
                @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
            >
            ${c.y}
            ${(0,n.z)(t=>t.contentIndicator,t=>(0,l.Z)(t.contentIndicator))}
            ${(0,n.z)(t=>t.imageData,i.qy`
                <img
                    slot="background-image"
                    alt="${t=>t.imageData.altText}"
                    src="${t=>t.imageData.source}"
                    @load="${t=>t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback()}"
                    @error="${t=>{return e=t.imageData.source,void(0,o.vV)(s.zfe,"Error fetching source","Source: "+e);var e}}"
                />
            `)}
            ${(0,n.z)(t=>t.abstract&&!t.isMsnHpExternalLinkCard,i.qy`
                <p slot="abstract" style="display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden;">
                    ${t=>t.abstract}
                </p>
            `)}
            ${(0,n.z)(t=>t.badge,t=>(0,h.w)(t.badge))}
            ${(0,n.z)(t=>!t.isMsnHpExternalLinkCard,t=>(0,d.fn)(t.providerAboveHeader?"attribution":"start-actions"))}
            ${(0,n.z)(t=>t.isMsnHpExternalLinkCard,i.qy`
                <msft-attribution slot="attribution" style="--design-unit: 1.5; position: absolute; bottom: 10px;">
                    <span style="unicode-bidi:embed">${t=>t.abstract}</span>
                </msft-attribution>
            `)}
            ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled,b.K)}
            ${(0,n.z)(t=>!t.isAnaheimDesign,i.qy`
                <div slot="start-actions" style="gap:0">
                    ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled&&!t.enableRichSocialReaction,i.qy`
                        ${p.LW}
                        ${p.tB}
                    `)}
                </div>
            `)}
            <div slot="${t=>t.providerAboveHeader?"start-actions":"end-actions"}" style="gap:0">
                ${(0,n.z)(t=>t.enableRichSocialReaction,()=>(0,p.nj)({}))}
                ${(0,n.z)(t=>t.cardActionStatus&L.J.enabled,i.qy`
                    ${(0,n.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,i.qy`
                        ${(0,n.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&L.J.showMore,p.LW)}
                        ${(0,n.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&L.J.showFewer,p.tB)}
                    `)}
                    ${(0,n.z)(t=>t.enableWCCardAction,g.L)}
                `)}
            </div>
            ${(0,n.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,m.p)}
            </msft-content-card>
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,ne=i.qy`
        <div class="info-pane-slide-title" part="info-pane-slide-title" style="display: flex; align-items: end;">
            <h3 class="info-pane-slide-title" style="pointer-events: none; flex: 1;" part="info-pane-slide-title">
                ${t=>t.title}
            </h3>
            <div class="cta-button" style="margin-inline-start: 4px; z-index: 2; height: 34px;">
                <msn-native-ad-call-to-action 
                    text=${t=>t.localizedStrings.nativeAdLearnMoreText||"learn more"}
                    default-background-color="#C6C0BA"
                    background-color="${t=>t.layoutColor}"
                    color="#000000"
                    is-hovered=${t=>t.hoverState&&t.hoverState.isHovered}
                    cta-mode="default"
                    destination-url=${t=>t.destinationUrl}
                    tel-metadata=${t=>t?.adTelemetryContext?.destination?.getMetadataTag()}
                    ${(0,Zt.Ib)(!0,!1)}
                >
                </msn-native-ad-call-to-action>
            </div>
        </div>
    `,re=t=>t?oe(t):c.y,oe=t=>i.qy`
    <div class="info-pane-slide-title" part="info-pane-slide-title" style="display: flex; align-items: end;">
        <h3 class="info-pane-slide-title" style="pointer-events: none; flex: 1;" part="info-pane-slide-title">
            ${t=>t.title}
        </h3>
        <msn-native-ad-call-to-action
            text=${()=>t}
            title=${()=>t}
            aria-label=${()=>t}
            :layoutConfig=${()=>({marginBottom:"6px",zIndex:2,marginInlineStart:"10px"})}
            background-color="${t=>t.layoutColor}"
            destination-url=${t=>t.destinationUrl}
            tel-metadata=${t=>t.adTelemetryContext?.destination?.getMetadataTag()}
            ${(0,Zt.Ib)(!0,!1)}
        >
        </msn-native-ad-call-to-action>
    </div>   
`,se=i.qy`
    <style>
        msft-info-pane-slide {
            width: 100%;
        }
        msft-content-card.native-ad-infopane-content-card::part(body) {
            grid-template-rows: 1fr 40px;
        }
        msft-content-card.native-ad-infopane-content-card::part(footer) {
            position: absolute;
            bottom: 0px;
            width: calc(100% - 32px);
        }
        msft-content-card.native-ad-infopane-content-card msft-attribution.info-pane-card-deco {
            top: -55px;
        }
        msft-content-card.native-ad-infopane-content-card.hasInlineDecoration msft-attribution[slot="start-actions"] {
            margin-top: 0px;
        }
        msft-content-card.native-ad-infopane-content-card msft-attribution[slot="start-actions"] .provider-name{
            vertical-align: middle;
        }
        msft-content-card.native-ad-infopane-content-card.hasInlineDecoration div[slot="end-actions"] {
            margin-top: 0px;
        }
        msft-content-card.hasInlineDecoration msft-attribution[slot="call-to-action"] {
            bottom: 50px;
            z-index: unset;
        }
        msft-content-card.native-ad-infopane-content-card .info-pane-card-deco msn-inline-group::part(group-container) {
            height: fit-content;
            transition: height  0.5s;
        }
        msft-info-pane-slide msft-ad-label {
            margin-right: 0;
        }
        msft-content-card a.ad-choice-icon {
            display: inline-flex;
            justify-content: center;
            min-width: calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px);
        }

        msft-content-card a.ad-choice-hidden {
            max-width: 0px;
            min-width: 0px;
            visibility: hidden;
            width: 0;
            padding: 0;
            margin: 0;
            border: 0;
        }

        msft-content-card.native-ad h3.info-pane-slide-title, msft-content-card.${(0,y.nP)("native-ad")} h3.info-pane-slide-title {
            -webkit-line-clamp: 2;
        }

        ${t=>(t=>{if(!t||!t.template)return"";const e=[];switch(A(t)&&e.push('\nmsft-content-card.native-ad-infopane-horizontal::part(body) {\n    display: block;\n    background: var(--fill-color);\n}\nmsft-content-card.native-ad-infopane-horizontal::part(footer) {\n    position: absolute;\n    bottom: 0px;\n    width: calc(100% - 32px);\n}\nmsft-content-card.native-ad-infopane-horizontal.hasInlineDecoration msft-attribution[slot="start-actions"]{\n    margin-top: 0;\n}\nmsft-content-card.native-ad-infopane-horizontal.hasInlineDecoration msft-attribution[slot="end-actions"]{\n    margin-top: 0;\n}\nmsft-content-card.native-ad-infopane-horizontal::part(heading-container) {\n    width: 258px;\n    margin-top: 24px;\n    margin-left: 16px;\n}\nmsft-content-card.native-ad-infopane-horizontal .info-pane-slide-title {\n    font-size: 20px;\n    line-height: 30px;\n}\nmsft-content-card.native-ad-infopane-horizontal msft-attribution.info-pane-card-deco {\n    width: 258px;\n    margin-left: 32px;\n    margin-top: 68px;\n}\nmsft-content-card.native-ad-infopane-horizontal msft-attribution .shop-now {\n    background: red;\n    margin-top:20px;\n    height: 32px;\n    line-height: 32px;\n    width: 102px;\n    border-radius: 20px;\n    text-align: center;\n    background: rgba(255, 255, 255, 0.14);\n    color: rgba(255, 255, 255, 0.8);\n}\n\nmsft-content-card.native-ad-infopane-horizontal msn-inline-group::part(inline-item) {\n    line-height: 25px;\n}\n'),t.template.templateType){case"msn-info-pane-horizontal-1-by-1":e.push("\nmsft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-1-by-1::part(media-wrapper) {\n    background: var(--fill-color);\n    border: 10px solid #fff;\n    position: absolute;\n    width: 180px;\n    height: 180px;\n    right: 46px;\n    top: 40px;\n}\nmsft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-1-by-1::part(media-wrapper) {\n    left: 46px;\n    right: unset;\n}");break;case"msn-info-pane-horizontal-3-by-4":e.push("\nmsft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-3-by-4::part(media-wrapper) {\n    background: var(--fill-color);\n    border: 10px solid #fff;\n    position: absolute;\n    width: 150px;\n    height: 200px;\n    right: 68px;\n    top: 30px;\n}\nmsft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-3-by-4::part(media-wrapper) {\n    left: 68px;\n    right: unset;\n}");break;case"msn-info-pane-horizontal-4-by-3":e.push("\nmsft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-4-by-3::part(media-wrapper) {\n    background: var(--fill-color);\n    border: 10px solid #fff;\n    position: absolute;\n    width: 208px;\n    height: 156px;\n    right: 38px;\n    top: 50px;\n}\nmsft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-4-by-3::part(media-wrapper) {\n    left: 38px;\n    right: unset;\n}");break;case"msn-info-pane-horizontal-9-by-16":e.push("\nmsft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-9-by-16::part(media-wrapper) {\n    background: var(--fill-color);\n    border: 10px solid #fff;\n    position: absolute;\n    width: 123px;\n    height: 220px;\n    right: 38px;\n    top: 20px;\n}\nmsft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-9-by-16::part(media-wrapper) {\n    left: 38px;\n    right: unset;\n}");break;case"msn-info-pane-pattern-overlay-1-by-1":e.push(D),e.push("\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(heading-container) {\n    width: 248px;\n}\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1 msft-attribution.info-pane-card-deco {\n    width: 248px;\n}\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(media-wrapper) {\n    background: #fff;\n    position: absolute;\n    width: 304px;\n    height: 100%;\n    right: 8px;\n    top: 0px;\n}\nmsft-content-card.rtl.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(media-wrapper) {\n    left: 8px;\n    right: unset;\n}\n");break;case"msn-info-pane-pattern-overlay-4-by-3":e.push(D),e.push("\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(heading-container) {\n    width: 144px;\n}\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3 msft-attribution.info-pane-card-deco {\n    width: 144px;\n}\nmsft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(media-wrapper) {\n    background: #fff;\n    position: absolute;\n    width: 384px;\n    height: 100%;\n    right: 8px;\n    top: 0px;\n}\nmsft-content-card.rtl.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(media-wrapper) {\n    left: 8px;\n    right: unset;\n}\n")}return e.join(" ")})(t)}
    </style>
    
    <msft-content-card
        id="${t=>(0,y.s4)(t.enableSafeAds,`native_ad_${t.id}_${t.index}`)}"
        class="${t=>Ce(t)} ${t=>(t=>{const e=[(0,y.s4)(t.enableSafeAds,"native-ad")];if(t.template&&t.template.progressiveDisplay&&e.push("native-ad-infopane-content-card"),document.dir===S.O.rtl&&e.push("rtl"),t.template&&t.template.templateType)switch(t.template.templateType){case"msn-info-pane-horizontal-1-by-1":e.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-1-by-1");break;case"msn-info-pane-horizontal-3-by-4":e.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-3-by-4");break;case"msn-info-pane-horizontal-4-by-3":e.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-4-by-3");break;case"msn-info-pane-horizontal-9-by-16":e.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-9-by-16");break;case"msn-info-pane-pattern-overlay-1-by-1":e.push("native-ad-infopane-horizontal native-ad-infopane-pattern-overlay native-ad-infopane-pattern-overlay-1-by-1");break;case"msn-info-pane-pattern-overlay-4-by-3":e.push("native-ad-infopane-horizontal native-ad-infopane-pattern-overlay native-ad-infopane-pattern-overlay-4-by-3")}return e.join(" ")})(t)}"
        href=${t=>t.destinationUrl}
        target="_blank"
        title=${t=>t.disableCardTitleTooltip?"":t.title}
        layout=${t=>t.cardLayout}
        data-t="${t=>t.id&&t.adTelemetryContext&&t.adTelemetryContext.nativeAdCard&&t.adTelemetryContext.nativeAdCard.getMetadataTag()}"
        :anchorTelemetryTag=${t=>t.adTelemetryContext&&t.adTelemetryContext.destination&&t.adTelemetryContext.destination.getMetadataTag()}
        ${(0,Zt.Ib)()}
        @mouseenter=${t=>we(t,!0)}
        @mouseleave=${t=>we(t,!1)}
    >
        ${(t,e)=>Fe(t.template,t.localizedStrings,e.parent?.nativeAds)}
        ${(0,n.z)(t=>t.hasAnyInlineDecoration,i.qy`
            ${t=>(0,Ut.zN)(t,!0)}               
        `)}
        ${(0,n.z)(t=>t.videoProps,i.qy`
            <native-ad-video-controls
                region="infopane"
                :destinationUrl=${t=>t.destinationUrl}
                :localizedStrings=${t=>t.localizedStrings}
            ></native-ad-video-controls>
            <div slot="${t=>A(t)?"media":"background-image"}" style="height: 100%; width: 100%">
                <native-ad-video-player
                    :videoProps=${t=>t.videoProps}
                    :backgroundImg=${t=>t.imageData}
                    region="infopane"
                ></native-ad-video-player>
            </div>
        `)}
        ${(0,n.z)(t=>t.imageData&&!t.videoProps,i.qy`         
            <div slot="${t=>A(t)?"media":"background-image"}" style="height: 100%; width: 100%">
                <img
                    style="height: 100%; width: 100%; object-fit: cover;"
                    slot="anim-content"
                    id="${t=>t.id}-img"
                    alt="${t=>t.imageData.altText}"
                    src="${t=>t.imageData.source}"
                    @load="${(t,e)=>(0,x.mQ)(t,e,"InfopaneCardTemplate")}"
                    @error="${(t,e)=>{(0,x.mQ)(t,e,"InfopaneCardTemplate"),(0,$.T)({id:`native_ad_${t.id}_${t.index}`,rLink:t.destinationUrl,imgLink:t.imageData.source})}}"
                />
            </div>
        `)}
        ${(0,n.z)(t=>t.providerData,i.qy`
            <msft-attribution slot="start-actions" id="start-actions" style="color: var(--neutral-foreground-rest);--design-unit: 0;">
                ${F.pK}
                ${t=>(0,F.Bq)(t.destinationUrl)}
                ${(0,n.z)(t=>t.assets&&t.assets.localInventory,i.qy`
                    &bull;<span id="in-store">${t=>t.localizedStrings.nativeAdInStoreText}</span>
                `)}
            </msft-attribution>
        `)}
        <div 
            slot="end-actions" 
            style="max-height: 32px;
            gap: 0; 
            position: relative"
        >
            ${(0,Gt.UN)()}
            ${(0,n.z)(t=>t.adChoiceIconUrl,i.qy`
            <a href="${t=>t.adChoiceIconUrl}" target="_blank"
                    class="${t=>ce(t)} ad-choice-icon"
                    id="${t=>t.id}-ad-choice"
                    data-t="${t=>t.adTelemetryContext?.adChoice?.getMetadataTag()}"
                >
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter:invert(71%) sepia(0%) saturate(0%) hue-rotate(332deg) brightness(95%) contrast(97%);">
                        <path d="M4.52344 5.69531C4.70573 5.69531 4.86198 5.63542 4.99219 5.51562C5.1224 5.39062 5.1875 5.24219 5.1875 5.07031C5.1875 4.89844 5.1224 4.7526 4.99219 4.63281C4.86198 4.50781 4.70573 4.44531 4.52344 4.44531C4.33594 4.44531 4.17708 4.50781 4.04688 4.63281C3.91667 4.7526 3.85156 4.89844 3.85156 5.07031C3.85156 5.24219 3.91667 5.39062 4.04688 5.51562C4.17708 5.63542 4.33594 5.69531 4.52344 5.69531ZM1.44531 0.921875V0.929688C1.33594 0.861979 1.21875 0.828125 1.09375 0.828125C0.90625 0.828125 0.747396 0.890625 0.617188 1.01562C0.486979 1.13542 0.421875 1.28125 0.421875 1.45312V11.375C0.421875 11.5469 0.486979 11.6953 0.617188 11.8203C0.747396 11.9401 0.90625 12 1.09375 12C1.19271 12 1.28906 11.9792 1.38281 11.9375H1.39062L1.40625 11.9219L3.20312 11.0625C3.48958 10.9635 3.63281 10.7708 3.63281 10.4844C3.63281 10.3073 3.56771 10.1589 3.4375 10.0391C3.30729 9.91406 3.15104 9.85156 2.96875 9.85156C2.85417 9.85156 2.74479 9.8776 2.64062 9.92969C2.63542 9.9401 2.61979 9.95052 2.59375 9.96094C2.51042 10.0026 2.42188 10.0234 2.32812 10.0234C2.17188 10.0234 2.03906 9.97396 1.92969 9.875C1.82031 9.77083 1.76302 9.64844 1.75781 9.50781V3.375C1.76302 3.22917 1.82031 3.10677 1.92969 3.00781C2.03906 2.90365 2.17188 2.85156 2.32812 2.85156C2.41667 2.85156 2.5 2.8724 2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L8.53906 5.92188L8.64844 5.97656C8.8099 6.08594 8.89062 6.23177 8.89062 6.41406C8.89062 6.60677 8.80469 6.75521 8.63281 6.85938L8.5625 6.89844L5.1875 8.60938V6.67969C5.1875 6.5026 5.1224 6.35417 4.99219 6.23438C4.86198 6.11458 4.70573 6.05469 4.52344 6.05469C4.33594 6.05469 4.17708 6.11458 4.04688 6.23438C3.91667 6.35417 3.85156 6.5026 3.85156 6.67969V9.65625C3.85156 9.83333 3.91667 9.98177 4.04688 10.1016C4.17708 10.2214 4.33594 10.2812 4.52344 10.2812C4.65885 10.2812 4.78385 10.2448 4.89844 10.1719L11.125 7.00781C11.4271 6.90885 11.5781 6.71094 11.5781 6.41406C11.5781 6.14844 11.4453 5.95833 11.1797 5.84375L1.44531 0.921875ZM2.59375 9.96094C2.61979 9.95052 2.63542 9.9401 2.64062 9.92969L2.59375 9.96094ZM2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L2.57812 2.91406Z" fill="#00aecd"/>
                    </svg>
                </a>
            `)}
            ${(0,n.z)(t=>t.isAdFeedbackV1Enabled&&!!t.feedbackUrl,i.qy`
                <div class="see-more-telemetry-wrapper"
                    data-t="${t=>t.adTelemetryContext?.seeMore?.getMetadataTag()}"
                >
                    ${g.L}
                </div>
            `)}
        </div>
    </msft-content-card>
`,le=i.qy`
    <msn-native-ad-wc
        id="${t=>(0,y.s4)(t.enableSafeAds,`native_ad_${t.id}_${t.index}`)}"
        style="z-index:0; position:relative"
        data-t="${t=>t.id&&t.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
        ${(0,Zt.Ib)(!1,!0)}
        :configRef=${t=>t.nativeAdWC?.configRef}
        :localizedStrings=${t=>t.localizedStrings}
        :adData=${t=>t}
        :isInfopane=${()=>!0}
    ></msn-native-ad-wc>
`,ce=t=>t.hideAdLabelAndAdChoice?"ad-choice-hidden":"",de=i.qy`
    <style>
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.nativeAdVideo-infopane::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 50px;
            height: auto;
        }
        msft-content-card.nativeAdVideo-infopane::part(mask) {
            visibility: hidden;
        }
        msft-content-card.nativeAdVideo-infopane::part(heading)::after {
            top: unset;
            bottom: 50px;
            right: 60px;
            width: 545px;
            height: 247px;
        }
        msft-content-card.nativeAdVideo-infopane::part(heading-container) {            
            width: 530px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        msft-attribution.info-pane-card-deco {
            z-index: unset;
            top: -65px;
            margin-bottom: -10px;
        }
        msft-attribution[slot="start-actions"] #in-store {
            margin-left: 3px;
        }
    </style>
    <msn-info-pane-panel id="tab_panel_${t=>(0,y.s4)(t.enableSafeAds,t.id)}">
        <style>
            msft-info-pane-slide {
                gap: 2px;
                background: linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(255,255,255,1) 50%, rgba(0,0,0,1) 100%);
            }
            .no-gap {
                gap: 0px;
            }
        </style>
        <msft-info-pane-slide
            layout="${t=>["single","double","triple"][Math.min(2,t.nativeAds.length-1)]}" 
            class="${t=>(0,y.s4)(t.enableSafeAds,`title-ad-${["single","double","triple"][Math.min(2,t.nativeAds.length-1)]}`)}"
        >
            ${(0,r.ux)(t=>t.nativeAds.slice(0,3),i.qy`${t=>t.nativeAdWC?le:se}`)}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,pe=i.qy`
 <msn-info-pane-panel id="tab_panel_${t=>t.id}">
     <style>
         msft-info-pane-slide msn-hide-story-card.hide-story-card {
             padding-top: 20px;
         }
         msft-info-pane-slide msn-hide-story-card.hide-story-card fluent-button {
             width: 48%;
             margin: 0 0 8px 0;
             display: flex;
         }
         msn-hide-story-card.hide-story-card::part(content-region) {
             display: inline-flex;
             align-items: center;
             padding: 16px 16px 0px;
             cursor: default;
         }
         msn-hide-story-card.hide-story-card::part(action-region) {
             display: flex;
             position: absolute;
             padding: 0px 16px 16px;
             justify-content: space-around;
             bottom: 0px;
             width: 100%;
             box-sizing: border-box;
             align-items: center;
             margin: 0;
         }
     </style>
     <msft-info-pane-slide>
         ${k.u}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,ge=i.qy`
<msn-info-pane-panel id="tab_panel_${t=>t.id}">
    <msft-info-pane-slide>
        ${C.F}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,ue=i.qy`
<msn-info-pane-panel id="tab_panel_${t=>t.id}">
    <msft-info-pane-slide>
        ${w.X}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,he=i.qy`
    <msn-info-pane-panel id="tab_panel_${t=>t.id}">
        <style>
            @media (prefers-color-scheme: light) {
                msft-info-pane-slide msn-hide-story-card.report-ad {
                    --neutral-foreground-rest: #2B2B2B;
                    --neutral-fill-input-rest: #FFFFFF;
                    --neutral-fill-rest: #EDEDED;
                    --neutral-fill-hover: #E5E5E5;
                    padding-top: 0px;
                    background: #FFFFFF;
                }
            }

            @media (prefers-color-scheme: dark) {
                msft-info-pane-slide msn-hide-story-card.report-ad {
                    --neutral-foreground-rest: #FFFFFF;
                    --neutral-fill-input-rest: #2B2B2B;
                    --neutral-fill-rest: #3D3D3D;
                    --neutral-fill-hover: #454545;
                    padding-top: 0px;
                    background: #2B2B2B;
                }
            }
            msft-info-pane-slide msn-hide-story-card.report-ad::part(content-region) {
                flex-direction: row;
                margin: 0;
                text-align: left;
                padding: 16px 16px 0px 24px;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad::part(action-region) {
                display: block;
                position: static;
                margin: 26px 0px 0px 0px;
                padding: 0px 16px 16px 24px;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button {
                width: 45%;
                display: inline-block;
                margin: 34px 5px 8px;
                text-align: center;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-radio {
                padding: 8px 0px 8px 0px;
                margin: 0;
                display: flex;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button::part(content) {
                text-overflow: ellipsis;
                overflow: hidden;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button::part(control) {
                width: 100%;
            }
        </style>
        <msft-info-pane-slide>
            ${_.j}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,be=i.qy`
    <msn-info-pane-panel id="tab_panel_${t=>t.id}">
        <style>
            @media (prefers-color-scheme: light) {
                msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation {
                    padding-top: 20px;
                    --neutral-foreground-rest: #2B2B2B;
                    --neutral-fill-input-rest: #FFFFFF;
                    --neutral-fill-rest: #EDEDED;
                    --neutral-fill-hover: #E5E5E5;
                    background: #FFFFFF;
                }
            }

            @media (prefers-color-scheme: dark) {
                msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation {
                    padding-top: 20px;
                    --neutral-foreground-rest: #FFFFFF;
                    --neutral-fill-input-rest: #2B2B2B;
                    --neutral-fill-rest: #3D3D3D;
                    --neutral-fill-hover: #454545;
                    background: #2B2B2B;
                }
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button {
                width: 150px;
                text-align: center;
                display: block;
                margin: 54px auto 8px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button:hover {
                background: var(--button-hover-color);
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation::part(content-region) {
                margin: 0 auto;
                text-align: center;
                padding: 110px 16px 0px 16px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation::part(action-region) {
                display: block;
                position: static;
                margin: 0;
                padding: 0px 16px 16px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button::part(control) {
                width: 100%;
            }
        </style>
        <msft-info-pane-slide>
            ${T.L}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,me=i.qy`
    <msn-info-pane-panel id="tab_panel_${t=>(0,y.s4)(t.enableSafeAds,t.id)}">
        <msft-info-pane-slide>
            ${t=>(0,O.yN)(t.denseConfigInfo,{properties:{denseData:t.denseData,telemetryObject:t.telemetryObject},memoize:!1})}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,fe=i.qy`
    <msn-info-pane-panel id="tab_panel_${t=>t.id}">
        <msft-info-pane-slide>
            ${qt.M}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,ve=i.qy`
 <msn-info-pane-panel id="tab_panel_${t=>(0,y.s4)(t.enableSafeAds,t.id)}">
     <msft-info-pane-slide class="no-gap">
         ${Yt.z}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,ye=i.qy`
 <msn-info-pane-panel id="tab_panel_${t=>t.id}">
     <msft-info-pane-slide class="no-gap">
         ${Xt.Q}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,xe=i.qy`
<style>
    :host fluent-card {
        content-visibility: auto;
    }
</style>
<fluent-card style="grid-area:${t=>t.gridArea}; ${t=>t.autoRowHeights?"height: 304px;":""}"  class="${t=>t.cardSize}">
    <fluent-design-system-provider 
        fill-color="#333"
        style="height: 100%;"
    >
        <style>
            msft-content-card fluent-button::part(control) {
                padding: 0;
            }
            msn-info-pane.dense-slide msft-info-pane-slide {
                background: #fff;
            }
            msn-info-pane.dense-slide msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] ~ msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane.dense-slide[activeid^="tab_denseCard-"] msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane.dense-slide msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] {
                background: #2B2B2B;
            }
            msn-info-pane msn-info-pane-tab#tab_topStories[aria-selected="true"] ~ msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane msn-info-pane-tab#tab_topStories[aria-selected="true"] {
                background: #2B2B2B;
            }
            msn-info-pane[activeid^="tab_FreFeed"] msn-info-pane-tab {
                display: none;
            }
            @media (prefers-color-scheme: dark) {
                msn-info-pane.dense-slide.adapt-dark-mode msft-info-pane-slide {
                    background: #2b2b2b;
                }
                msn-info-pane.dense-slide.adapt-dark-mode msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] {
                    background: #fff;
                }
                msn-info-pane.dense-slide.adapt-dark-mode msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] ~ msn-info-pane-tab {
                    background: #fff;
                }
            }
        </style>
        ${c.j}
        <msn-info-pane id="infopane" layout="${t=>t.layout}" ?activeindicator="${t=>void 0===t.activeIndicator||t.activeIndicator}"
            data-t="${t=>t.telemetryContext?.infopane?.getMetadataTag()}"
            :nextFlipperTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.infopane&&t.telemetryContext.nextSlideArrow.getMetadataTag()}
            :previousFlipperTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.infopane&&t.telemetryContext.previousSlideArrow.getMetadataTag()}
            :previousFlipperTitle=${t=>t.infoPanePreviousFlipperTitle}
            :nextFlipperTitle=${t=>t.infoPaneNextFlipperTitle}
            style="${t=>$e(t)}"
            ?auto-scroll="${t=>t.autoRotate}"
            :autoScrollIntervalMs=${t=>t.autoRotateIntervalMs}
            ?disable-auto-scroll="${t=>t.disableAutoRotate}"
            ?enable-rotate-after-click=${t=>t.enableRotateAfterClick}
            :rotateAfterClickIntervalMs=${t=>t.rotateAfterClickIntervalMs}
            ?allow-blur-scroll="${t=>t.allowBlurScroll}"
            class="${t=>Te(t)}"
            :firstAutoScrollIntervalMs=${t=>t.firstAutoRotateIntervalMs}
            ?enable-rotate-only-once=${t=>t.enableRotateOnlyOnce}
            ?rotate-prev-after-click-prev-button=${t=>t.rotateBackAfterClickPrevButton}
            ?rotate-stop-after-click-prev-button=${t=>t.rotateStopAfterClickPrevButton}
            ?enable-infopane-refactoring=${t=>t.enableInfopaneRefactoring}
            ?enable-infopane-swipe=${t=>t.enableInfopaneSwipe}
            :adTimerMap=${t=>t.adTimerMap}
            ?infopane-prominent-flipper=${t=>t.infoPaneProminentFlipper}
            ?infopane-narrow-flipper=${t=>t.infoPaneNarrowFlipper}
            ?infopane-light-flipper=${t=>t.infoPaneLightFlipper}
            :infoPaneFlipperStyle=${t=>t.infoPaneFlipperStyle}
            @mouseenter=${(t,e)=>e.event&&_e.onMouseEnter(e.event.target,t.slideContentData&&t.slideContentData[0]&&t.slideContentData[0].enableHover)}
            @mouseleave=${(t,e)=>e.event&&_e.onMouseLeave(e.event.target,t.slideContentData&&t.slideContentData[0]&&t.slideContentData[0].enableHover)}
        >
            ${(0,r.ux)(t=>t.slideContentData,te)}
            ${(0,r.ux)(t=>t.slideContentData,i.qy`${t=>ke(t)}`,{positioning:!0})}
        </msn-info-pane>
    </fluent-design-system-provider>
</fluent-card>
`,$e=t=>t.cardSize===f.uE._2x_2y||t.cardSize===f.uE._2x_3y?" --heading-font-size: 20px; --heading-line-height: 28px;":"",ke=t=>{const e=0!==(t.cardActionStatus&L.J.hide)||!!t.enableHideStoryFeedback&&(0!==(t.cardActionStatus&L.J.showFewer)||0!==(t.cardActionStatus&L.J.hidden));return"top-stories-card"===t.childTemplateType?ve:"article-fre-card"===t.childTemplateType?ye:"dense-card"===t.childTemplateType?me:t.isNativeAd?de:t.showAdFeedback?t.cardActionStatus&L.J.hidden?ue:t.cardActionStatus&L.J.adFeedbackSubmitted?be:he:"tabbed-infopane-card"===t.childTemplateType?fe:e?t.enableHideStoryFeedback&&t.cardSize!==f.uE._2x_3y?t.cardActionStatus&L.J.hidden?ue:ge:pe:t.useArticleCardTemplate&&t.cardSize!==f.uE._2x_3y?t.isAnaheimDesign?ee:ae:ie},Ce=t=>{const e=[];return t.isNarrowTitleFooterGap&&e.push("narrowTitleGap"),t.hasAnyInlineDecoration&&e.push("hasInlineDecoration"),t.videoProps&&e.push("nativeAdVideo-infopane"),e.join(" ")},we=(t,e)=>{t.template&&t.template.progressiveDisplay&&t.hoverState&&t.hoverState.isHovered!==e&&(t.hoverState.isHovered=e)},_e=new v.w,Te=t=>{let e="";return t.enableDenseSlide&&(e+="dense-slide"),t.enableAdaptDarkMode&&(e+=" adapt-dark-mode"),[Kt.o.LightStyle2,Kt.o.LightDefault,Kt.o.LightNarrow,Kt.o.LightLarge,Kt.o.LightWide].includes(t.infoPaneFlipperStyle)&&(e+=" light"),e},Fe=(t,e,a)=>{const{enableNativeAdCTALearnMoreInfopane:i,enableNativeAdCTAOpenInfopane:n,templateType:r}=t||{};return["msn-call-to-action-v3","msn-call-to-action-v3-pa"].includes(r)?ne:i&&1===a?.length?re(e?.nativeAdLearnMoreText):n&&1===a?.length?re(e?.nativeAdOpenText):c.y}},52600(t,e,a){"use strict";a.d(e,{j(){return d}});var i,n,r=a(65455),o=a(98794);(n=i||(i={})).full="full",n.half="half",n.tall="tall";var s=a(87906),l=a(40450),c=a(69828);const d={getFeedDataForCard(t){return function(t){const{configOptions:e,parentTelemetryObject:a,cardMetadata:n,openLinksInNewTab:r,refreshSDCardSection:d,goToPersonalizeSettingsCallback:p,flattenedRightRail:g,sdCardActionClickHandler:u,supportedSdCardActionMenuItems:h,dismissSDCardMenuCallback:b,refreshFeedCallback:m,visualReadinessCallback:f,hasLoadedCallback:v,activeBoard:y,isWidgetRegion:x,onSDCardClick:$,turnOffWidgetsRegionCallback:k,manageWidgetsRegionCallback:C}=t;if(!n?.data)return null;const w=e&&e;let _;try{_=JSON.parse(n.data)}catch(t){return(0,s.vV)(l.V8E,"exception while parsing feed money card data from data mapper"),null}const T=`moneyInfoCard_${n.type}`,F=`${n.type}${y?`_${y}`:""}${n.metadata?.isSpotlightUX?"_spotlight":""}`,S={cardFeedDataJson:_,childTemplateType:"money-info-card",cardLayout:i.full,goToPersonalizeSettingsCallback:p,id:T,moneyCardConfigInfo:w,noGradient:g,openLinksInNewTab:r,parentTelemetryObject:a,refreshSDCardSection:d,refreshFeedCallback:m,visualReadinessCallback:f,sdCardActionClickHandler:u,supportedSdCardActionMenuItems:h,dismissSDCardMenuCallback:b,cardType:F,experienceName:`${F}${n.id?`_${n.id}`:""}`,isSpotlightUX:n.metadata&&n.metadata.isSpotlightUX,previewType:n.metadata&&n.metadata.previewType,feedData:n.data,cardId:n.cardId,hasLoadedCallback:v,isWidgetRegion:x,onSDCardClick:$,turnOffWidgetsRegionCallback:k,manageWidgetsRegionCallback:C};return S.isWidgetRegion&&(S.cardSize="_1x_1y"),(0,o.bw)({id:T,experienceType:w?.configRef?.experienceType,mapperArgs:t},S,(t,e)=>{const a=e.cardSize;let n=i.full;return a===c.uE._1x_1y?n=i.half:a===c.uE._1x_3y&&(n=i.tall),{cardLayout:n,sdCardActionClickHandler:u,supportedSdCardActionMenuItems:h}},!0)}(t)},viewTemplate:r.P}},65455(t,e,a){"use strict";a.d(e,{P(){return d}});var i=a(69828),n=a(91748),r=a(89757),o=a(94172),s=a(33744);const l=r.qy`
<fluent-card
        style="grid-area:${t=>t.gridArea};contain:unset;content-visibility:visible"
        class="${t=>t.cardLayout}">
    <fluent-design-system-provider style="padding: 0; height: 100%; margin: 0;">
        ${t=>t.moneyCardConfigInfo&&(0,o.yN)(t.moneyCardConfigInfo,{properties:{cardLayout:t.cardLayout,openLinksInNewTab:t.openLinksInNewTab,noGradient:t.noGradient,supportedSdCardActionMenuItems:t.supportedSdCardActionMenuItems,wpoMetadata:t.wpoMetadata,parentTelemetry:t.parentTelemetryObject,refreshSDCardSection:t.refreshSDCardSection,visualReadinessCallback:t.visualReadinessCallback,sdCardActionClickHandler:t.sdCardActionClickHandler,dismissActionMenu:t.dismissSDCardMenuCallback,cardSize:t.cardSize,cardType:t.cardType,cardFeedDataJson:t.cardFeedDataJson},attributes:{style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible`},events:{goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback},memoize:"windowsShellV2"!==s.T3.AppType})}
    </fluent-design-system-provider>
</fluent-card>`,c=r.qy`${t=>t.moneyCardConfigInfo&&(0,o.yN)(t.moneyCardConfigInfo,{properties:{cardSize:t.cardSize===n.Go._1u?i.uE._1x_2y:t.cardSize,shellV2PreviewType:"windowsShellV2"===s.T3.AppType?t.previewType:"",feedData:t.feedData,cardType:t.cardType,experienceName:t.experienceName,wpoMetadata:t.wpoMetadata,isSpotlight:t.isSpotlightUX,cardId:t.cardId,parentTelemetryObject:t.parentTelemetryObject,refreshSDCardSection:t.refreshSDCardSection,refreshFeedCallback:t.refreshFeedCallback,visualReadinessCallback:t.visualReadinessCallback,dismissActionMenu:t.dismissSDCardMenuCallback,sdCardActionClickHandler:t.sdCardActionClickHandler,supportedSdCardActionMenuItems:t.supportedSdCardActionMenuItems,hasLoadedCallback:t.hasLoadedCallback,isWidgetRegion:t.isWidgetRegion,onSDCardClick:t.onSDCardClick,turnOffWidgetsRegionCallback:t.turnOffWidgetsRegionCallback,manageWidgetsRegionCallback:t.manageWidgetsRegionCallback},attributes:{style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible`,initialPreviewType:t.previewType},events:{goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback},memoize:"windowsShellV2"!==s.T3.AppType})}`,d=r.qy`
    ${t=>"MoneyInfo"===t.moneyCardConfigInfo.configRef?.experienceType?c:l}
`},33485(t,e,a){"use strict";a.d(e,{$(){return r}});var i=a(71733),n=a(1792);const r={getFeedDataForCard(t){return(0,n.M8)(t)},viewTemplate:i.DO}},18176(t,e,a){"use strict";a.d(e,{M(){return r}});var i=a(90466),n=a(98794);const r={getFeedDataForCard(t){return function(t){const{cardMetadata:e}=t,{id:a}=e,i={id:a,childTemplateType:"placeholder-card"};return(0,n.bw)({id:a,experienceType:null,mapperArgs:t},i)}(t)},viewTemplate:i.u}},90466(t,e,a){"use strict";a.d(e,{u(){return i}});const i=a(89757).qy`
    <fluent-card 
        style="grid-area:${t=>t.gridArea}"
        class="${t=>t.cardSize}"
    >
        <div class="placeholder-card" style="height: 100%;" />
    </fluent-card>
`},34900(t,e,a){"use strict";a.d(e,{N(){return r}});var i=a(26144),n=a(98794);const r={getFeedDataForCard(t){return function(t){const{configOptions:e,parentTelemetryObject:a,cardMetadata:i,pollsCardConfigInfo:r,goToPersonalizeSettingsCallback:o,refreshSDCardSection:s}=t,l=r||e&&e,c={id:"pollsCard",childTemplateType:"polls-card",parentTelemetryObject:a,pollsCardConfigInfo:l,fetchedData:i.data,goToPersonalizeSettingsCallback:o,refreshSDCardSection:s};return(0,n.bw)({id:"pollsCard",experienceType:l?.configRef?.experienceType,mapperArgs:t},c)}(t)},viewTemplate:i.d}},26144(t,e,a){"use strict";a.d(e,{d(){return r}});var i=a(89757),n=a(94172);const r=i.qy`
    <fluent-card
        style="grid-area:${t=>t.gridArea}"
        class="${t=>t.cardSize}"
    >
        ${t=>(0,n.yN)(t.pollsCardConfigInfo,{properties:{fetchedData:t.fetchedData,telemetryExt:t.telemetryExt,goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback,refreshSDCardSection:t.refreshSDCardSection},telemetryObject:t.telemetryObject})}
    </fluent-card>
`;i.qy`
    <cs-card
        style="grid-area:${t=>t.gridArea}; border-radius: 8px;"
        class="${t=>t.cardSize}"
        size="${t=>t.cardSize}"
    >
    ${t=>(0,n.yN)(t.pollsCardConfigInfo,{properties:{fetchedData:t.fetchedData,telemetryExt:t.telemetryExt,goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback,refreshSDCardSection:t.refreshSDCardSection,cardSize:t.cardSize},telemetryObject:t.telemetryObject})}
    </cs-card>
`},23897(t,e,a){"use strict";a.d(e,{W(){return u}});var i=a(89757),n=a(60402),r=a(69259),o=a(33744),s=a(2375),l=a(44978),c=a(2188),d=a(4670);const p={_1x_2y:"1u",_2x_2y:"_2x_2y",_1x_1y:"0.5u"},g=i.qy`
    <span slot="action-row-start">
        <social-bar-wc
            config-instance-src=${t=>t.socialBarWCConfigInfo&&(0,s.v)(t.socialBarWCConfigInfo)}
            instance-id=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.configRef&&t.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${t=>t.id}
            :url=${t=>t.feedbackUrl}
            :destinationUrl=${t=>t.destinationUrl}
            :title=${t=>t.title}
            :imageData=${t=>t.imageData}
            :abstract=${t=>t.abstract||t.metadata&&t.metadata.abstract}
            :locale=${t=>o.T3.CurrentMarket||t.locale}
            :theme=${"ads"}
            :rootTelemetryObject=${t=>t.adTelemetryContext?.nativeAdCard}
            :getReplacementCardsCallback=${t=>t.getReplacementCardsCallback}
            :reactionCallback=${t=>t.reactionCallback}
            :shareActionHandler=${t=>t.shareActionHandler}
            :cardActionHideHandler=${t=>()=>t.openAdReportDialog(t)}
            :isInfoPane=${t=>t.isInfopane}
            :socialMetadata=${t=>({...t.metadata,imageData:t.imageData,providerData:t.providerData,title:t.title})}
        ></social-bar-wc>
    </span>
`,u=i.qy`
<cs-responsive-card
    ad=true
    ${(0,c.Ib)(!1,!0)}
    ?ad-va="${t=>t.adVA}"
    ?ad-va2="${t=>t.adVA2}"
    ?ruby-va="${t=>t.enableRubyVerticalAds&&t.adVA2}"
    ?ad-pa="${t=>t.template?.adPA}"
    ?enable-ad-social-bar="${t=>t.enableAdSocialBar}"
    :adAttributes=${t=>t.adAttributes}
    :abstract=${t=>t.abstract}
    ad-dts-style-key="${t=>t.adDTSStyleKey}"
    :adDTSTemplateConfig=${t=>t.adDTSTemplateConfig}
    :adDTSComponentDataMap=${t=>t.adDTSComponentDataMap}
    ?use-ad-dts-template=${t=>t.shouldUseAdDTSTemplate}
    :attributionData=${t=>t.attributionData}
    :adSelectionCriteria=${t=>t.adSelectionCriteria}
    :badgeProps="${t=>t.badgeProps}"
    :callToAction="${t=>t.callToAction}"
    :data="${t=>t}"
    data-t="${t=>t.id?t.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
    :heading="${t=>t.title}"
    ?hide-card-actions="${t=>t.hideCardActions||!t.feedbackUrl}"
    :href="${t=>t.destinationUrl}"
    :href_adButton="${t=>(0,d.lW)(t)}"
    :href_adChoiceButton="${t=>t.adChoiceIconUrl}"
    id="${t=>t.id}"
    ?immersive="${t=>!(!("_2x_2y"==t.cardSize||"_1x_2y"==t.cardSize&&t.immersiveCard)||t.isIntraNativeAd)||void 0}"
    :intraArticle=${t=>t.isIntraNativeAd}
    :isIntraFeedAd=${t=>t.isIntraNativeAd}
    :isIntraClassicAd="${t=>t.isIntraClassicAd}"
    :mediaData=${t=>t.mediaData}
    media-type="${t=>t.imageData?.source?"image":""}"
    @mouseenter="${(t,e)=>t.mouseEnterCallback(e.event.currentTarget)}"
    @mouseleave="${(t,e)=>t.mouseLeaveCallback(e.event.currentTarget)}"
    :onClickLink="${t=>t.onClickLink}"
    :onClickCardActions="${t=>t.toggleCardActionMenu}"
    :onRightClick="${t=>t.toggleCardActionMenu}"
    :onClickHideCard="${(t,e)=>()=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^l.J.hide^l.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")}"
    :popoverData="${t=>t.popoverData}"
    size="${t=>p[t.cardSize]||t.cardSize}"
    style="grid-area:${t=>t.gridArea};"
    target="${t=>t.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${t=>t.adTelemetryContext?.nativeAdCard}"
    :telemetryTag_adButton="${t=>(0,d.j1)(t.adTelemetryContext)}"
    :telemetryTag_adChoiceButton="${t=>t.adTelemetryContext?.adChoice?.getMetadataTag()}"
    :telemetryTag_anchor="${t=>t.adTelemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_moreActions="${t=>t.adTelemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_adDisclaimerButton="${t=>t.adTelemetryContext?.adDisclaimer?.getMetadataTag()}"
    :telemetryTag_callToAction="${t=>t.adTelemetryContext?.callToAction?.getMetadataTag()}"
    :telemetryTag_undoHide="${t=>t.adTelemetryContext?.cancelButton?.getMetadataTag()}"
    title="${t=>t.title}"
    :visualReadinessCallback="${t=>t.visualReadinessCallback}"
    ?wide="${t=>"_2x_2y"==t.cardSize||void 0}"
    ?ruby="${t=>t.ruby}"
    ?loading="${t=>t.loading}"
    ${(0,n.K)("cardElement")}
>
    ${(0,r.z)(t=>t.enableAdSocialBar&&t.feedbackUrl,g)}
</cs-responsive-card>`},88466(t,e,a){"use strict";a.d(e,{v(){return r}});var i=a(32460),n=a(51907);const r={getFeedDataForCard(t){return(0,n.y5)(t)},viewTemplate:i.t}},51907(t,e,a){"use strict";a.d(e,{As(){return N},y5(){return R},uh(){return L}});var i=a(44978),n=a(98794),r=a(69828),o=a(10071),s=a(35667),l=a(46659),c=a(11803),d=a(86010),p=a(56216),g=a(80119),u=a(82368),h=a(77833),b=a(87906),m=a(40450),f=a(98378),v=a(7446),y=a(94108),x=a(33744),$=a(60763),k=a(45519),C=a(19110),w=a(72287),_=a(72746),T=a(52323),F=a(72106),S=a(54694),D=a(72627),A=a(44916),z=a(12673),I=a(50180),E=a(59010);const B=["ocid","pc","cvid","ei","copilot_traceid"];function M(t,e,a){try{const i=new URL(t);return i.searchParams.set(e,a),i.toString()}catch(e){return t}}function R(t){const{cardMetadata:e,configOptions:a,immersiveCard:i,visualReadinessCallback:s,ruby:l,overrideTelemetryExtArgs:c}=t,d=e.type,{childExperienceReferencesWC:p={},childExperienceReferences:g={}}=a,u=p.socialBarWC||g.socialBarWC,b=p.videoCardWC,m=L(t,{socialBarWCConfigInfo:u,videoCardConfigInfo:b},s),{id:v,metadata:y,telemetryContext:x}=m,$=y?!y.reactionSummary:m&&!m.reactionSummary;o.R.setContentIdCandidateIfNeeded(v,d,$);const k=a&&a,C=e&&e.ri||y&&y.ri,_=e&&e.recoId||y&&y.recoId;t.configOptions.preloadImages&&(0,w.NN)(m.attributionData?.src);const F=(0,n.bw)({id:v,experienceType:k?.configRef?.experienceType,mapperArgs:t,recoId:_,ri:C},m,(n,o)=>{const c=o.cardSize;let d;(m.usePortraitImage||m.useSquareImage)&&(d=m.usePortraitImage?"portrait":"square");const p=Boolean(t.cardMetadata.feedMetadata?.segment),g=O(m,c,s,i,{segment_1_1:p},a);let u=r.uE._1u;switch(c){case"_1x_1y":u=r.uE._05u;break;case"_1x_2y":u=r.uE._1u;break;case"_2x_2y":u=l?"2c":r.uE._2c;break;default:u=c||r.uE._1u}"shorts"===e.size&&(u="shorts"),a.useInfopaneSlideTemplate&&(u=r.uE._1u);const b=g?function(t){const e=t.contentType,a=e===h.pL.WebContent,i=a&&Boolean(t.metadata?.videoMetadata),n=i||e===h.pL.Video;return n?"video":"image"}(m):void 0;t.configOptions.preloadImages&&(0,w.NN)(g?.src);const v=o.telemetryExt;a.logThumbnailUrl&&(v.tmb=g?.src),c!==r.uE._05u&&(v.height=a.isWaterfallFeed&&a.enableDynamicWaterfall?void 0:304);const y={...x};return y&&y.contentCard&&(y.destination&&(y.destination=y.contentCard.addOrUpdateChild({...y.destination.contract,type:f.MJ.Headline,ext:v,action:f.EG.Click})),y.contentCard=new T.$({...y.contentCard.contract,ext:v})),{visualReadinessCallback:s,mediaData:g,mediaType:b,telemetryContext:y,responsiveCardSize:u,hideComments:!(!a.hideCommentsInHalfUCards||u!==r.uE._05u)}},!0,c);return F}function L(t,e,a,n=!1,r){const{cardActionBitMask:o,cardActionClickHandler:l,cardMetadata:c,cardSlot:p,configOptions:g={},enableRichSocialReaction:k,shareActionHandler:F,initCardAction:S,isNarrowTitleFooterGap:R,isPublisherPage:L,cardActionMenuClickCallback:j,getReplacementCardsCallback:V,goToPersonalizeSettingsCallback:U,heightReadyCallback:W,hideCardCallback:G,reactionCallback:Z,refreshFeedCallback:J,visualReadinessCallback:X,localizedStrings:Q,mouseenterHandler:q,mouseleaveHandler:Y,openLinksInNewTab:K,parentTelemetryObject:tt,getSpotlightMenuItems:et,supportedSdCardActionMenuItems:at,sdCardActionClickHandler:it,isSpotlightZone:nt,userSubscriptionData:rt,displaySettings:ot,preventDefaultClick:st,actionMenuLocalizedStrings:lt,feedbackHandler:ct,shareHandler:dt,immersiveCard:pt,feedName:gt,notificationMetadata:ut,openLinksInCurrentTab:ht,renderContentIndicator:bt,ruby:mt,underlineTitle:ft,waterfallCardSlot:vt}=t,{availableActions:yt,enableEverGreenWebContent:xt=!1,enableNewTimestampFormatForJAJP:$t,enableHideStoryFeedback:kt,openPersonalizeWithoutRouter:Ct,telemetryConstants:wt={},enabledBadgeTypes:_t,enabledReasonBadgeTypes:Tt,disableCardTitleTooltip:Ft,enableTitleForTruncate:St,disablePublishTime:Dt,useStatSocialTemplate:At,enableRubyBottomSocialBar:zt,enableHoverFollowButton:It}=g,{socialBarWCConfigInfo:Et,videoCardConfigInfo:Bt}=e,Mt=(0,w.cZ)(c),Rt=Mt.metadata?.reasons&&g.childExperienceReferencesWC.publisherFollowButton,{cardContent:Lt,dynamicCardSize:Nt,metadata:Ot,isFirstSectionCard:Pt,type:Ht}=Mt,{grid_area:jt}=p,{abstract:Vt,id:Ut,destinationUrl:Wt,locale:Gt,title:Zt,publishedDateTime:Jt,provider:Xt,defaultAnchorTarget:Qt,videoFiles:qt,isWorkNewsContent:Yt,badges:Kt}=Lt,te=Ht===h.pL.WebContent,ee=(0,w.H8)(Mt,o),ae="following"===gt?void 0:Mt?.metadata?.reasons,{badge:ie,reasonBadge:ne}=(0,C.bA)(Q,Kt,_t,ae,Tt),re=(0,w.nN)(Q,g,ne);Wt||(0,b.vV)(m.Okb,"Missing destinationUrl for content card","Article ID: "+Ut);const oe=c.recoReasonTag??Ot.recoReasonTag;c&&c.recoId&&Ot&&(Ot.recoId=c.recoId);const se=(0,s.dj)(tt,Lt,Ot,void 0,te,{...s.ZZ,...wt});se&&se.hide&&se.hide.contract&&(se.showFewer=new T.$({...se.hide.contract,name:"showFewer",action:f.EG.Click,behavior:f.MS.Dislike,type:f.MJ.ActionButton,content:{...se?.hide.contract?.content}}),se.hide.contract.ext={recoReasonTag:oe});const le=0!==(ee&i.J.hide)||kt&&(0!==(ee&i.J.showFewer)||0!==(ee&i.J.hidden)),ce=Ot?.videoMetadata||c?.videoMetadata,de=te&&Boolean(ce),pe=Ht===h.pL.Video,ge="shorts"===c?.size,ue=ge,he=Ot?!Ot.reactionSummary:Mt&&!Mt.reactionSummary;let be=null;const{disable1MonPlusTimestamp:me,disableNDaysPlusTimestamp:fe}=_.ew.getConfig()||{},ve=(0,A.YS)(Jt),ye=(0,A.Tp)(Jt,fe);me&&ve||ye||(be=(0,_._L)(Jt,Gt,void 0,$t,!0)),be=te&&xt&&(0,w.xk)(Jt)?null:be,(0,w.Be)(Jt,g);const xe=""!==y.Rb.MarketDir?y.Rb.MarketDir:"ltr";!(!oe||!oe.tag)&&v.YT.addOrUpdateTmplProperty("recoReasonTag","1");const $e=c?.containerType===h.pL.TrendingNowCarousel||c?.containerType===h.pL.NewsTrendingNow,ke=(0,w.p_)(Xt,te,void 0,de),Ce={altText:ke&&ke.name,name:ke&&ke.name,publishedDateTime:Dt||$e?null:be,viewCount:$e?P(c):null,src:ke&&ke.logoImage,useFollowingButton:!0,providerChannelURL:ke&&N(ke)};let we,_e,Te="";switch(ne?.type.toLowerCase()){case"trending":Te=`${x.T3.StaticsUrl}latest/icons-wc/icons/TrendingLight.svg`;break;case"local":Te=`${x.T3.StaticsUrl}latest/icons-wc/icons/LocationPin.svg`;break;case"followtopic":case"followpublisher":Te=`${x.T3.StaticsUrl}latest/icons-wc/icons/CircleCompleted.svg`}ie?we={isNonInteractive:!0,iconSrc:"",onClickBadge(){},telemetryTag_badge:"",text:ie?.localizedLabel||""}:ne?.type&&(we={iconSrc:Te,onClickBadge(t,e){return H(t,e,l,S,null,!kt,J,Ct,he,d.hs.WhyAmISee)},telemetryTag_badge:se?.whyAmISee?.getMetadataTag(),text:ne?.localizedLabel||""});const Fe=Boolean(Mt.feedMetadata?.segment);n&&(_e=O(Mt,a,r,pt,{segment_1_1:Fe},g));let Se=Wt;de&&(Se=(0,z.C)(encodeURIComponent(Ut),Se)),(0,$.vM)()&&(Se=function(t,e){const a=new E.m((0,D.iA)());let i="?";if(t.indexOf("?")>-1){const e=new E.m(t).getAllSearchParams();for(const t in e)a.delete(t);i=Object.keys(e).length>0?"&":"?"}return e&&B.forEach(t=>{a.delete(t)}),0===Object.keys(a.getAllSearchParams()).length?t:t+i+a.toString()}(Se,!0)),ge&&(Se=M(Se,"category","shorts")),(0,w.FU)(Ot)&&(Se=M(Se,"cgfrom","cg_ruby_ntp_carousel_item"));const De=le?(0,u.Eb)(t,ee,Ut,tt):{id:Ut,dir:xe,isWorkNewsContent:Yt,gridArea:jt,telemetryContext:se,defaultAnchorTarget:Qt,abstract:Vt,cardContent:Lt,cardActionStatus:ee,cardActionClickHandler:l,cardActionsTooltips:re,externalVideoFiles:pe?qt:void 0,videoMetadata:pe?ce:void 0,title:Zt,titlePrefix:Mt.isFeatured&&Q.topStoriesBreakingNewsTagString,contentType:Ht,sdCardActionClickHandler:it,imagePriority:!1,isWebContent:te,isFirstSectionCard:Pt,metadata:Ot||Mt,openLinksInNewTab:K,enableRichSocialReaction:k,optedOutOfReactions:he,userSubscriptionData:rt,isPublisherPage:L,locale:Gt,immersiveCard:ue||pt,isNarrowTitleFooterGap:R,mouseenterHandler:q,mouseleaveHandler:Y,actionsArrayOverride:te&&yt||void 0,displaySettings:ot,actionMenuLocalizedStrings:lt,cardActionMenuClickCallback:j,getReplacementCardsCallback:V,goToPersonalizeSettingsCallback:U,heightReadyCallback:W,hideCardCallback:G,preventDefaultClick:st,reactionCallback:Z,refreshFeedCallback:J,visualReadinessCallback:r??X,shareActionHandler:F,feedbackHandler:ct,shareHandler:dt,destinationUrl:Se,wpoMetadata:Ot?.wpoMetadata||Mt?.wpoMetadata,wpoRank:Ot?.wpoRank||Mt?.wpoRank,cardId:Ot?.cardId||Mt?.cardId,type:Ot?.type||Mt?.type,subType:Ot?.subType||Mt?.subType,childTemplateType:"responsive-card",attributionData:Ce,providerData:(0,w.p_)(Xt,te),toggleCardActionMenu(t,e,a,i,n){return H(t,e,l,S,null,!kt,J,Ct,he,a,void 0,i,n,zt,It)},mediaData:_e,socialBarWCConfigInfo:Et,videoCardConfigInfo:Bt,badgeProps:we,publisherFollowButtonConfigInfo:Rt&&{...Rt,instanceId:`${Rt.instanceId}-${Ut}`},enableCardHideStoryIcon:g&&g.enableCardHideStoryIcon,badge:ie,reasonBadge:ne,slides:c?.slides||Ot?.slides,disableCardTitleTooltip:Ft,enableTitleForTruncate:St,openLinksInCurrentTab:ht,renderContentIndicator:bt,useStatSocialTemplate:At,order:vt?.order??0};if(ut?.spotlightPreviewTypes?.length&&Ot?.isSpotlightUX){const{additionalLabelText:t,followedEntity:e,followedType:a,spotlightCardTitle:i}=ut;if(De.childTemplateType="article-breaking-news-card",De.cardTitle=i,De.additionalLabelText=t,De.followedType=a,De.followedEntity=e,De.getSpotlightMenuItems=et,De.supportedSdCardActionMenuItems=at,De.isSpotlightZone=nt,De.recoId=c&&c.recoId||Ot&&Ot.recoId,Q){const{bingVideoNoPreviewStr:t,bingVideoPreviewStr:a,disableNotification:i,followingText:n,followConfirmationText:r}=Q;De.followButtonTitle=n,De.followingButtonHoverTip=r&&(0,I.GP)(r,e),De.disableNotificationText=i,De.videoNoPreviewLabel=t,De.videoPreviewLabel=a}}if(De.ruby=mt,De.underlineTitle=ft,De.segment=Boolean(Mt.feedMetadata?.segment),mt&&zt){const{reactionSummary:t,commentSummary:e,commentStatus:a}=Ot;De.rubySocialBarData=(0,w.Qw)(t,e,a)}return mt&&(0,w.FU)(Ot)&&(De.hideLikeButton=!0),De}function N(t){const e=t?.name??"page",a=t?.profileId??"";return(0,F.Hg)(a,e,"source")}function O(t,e,a,i,n,o){if(!e)return;let s=!1,d=p.n._268x140;e!==r.uE._05u&&e!==r.uE._1x_1y||(d=o.enableHomePageStyle?i?p.n._306x256:p.n._104x84:p.n._90x90),e===r.uE._075u&&(d=p.n._268x94),e===r.uE._2x_2y&&(d=o?.enableHomePageStyle?p.n._628x372:p.n._612x304),e===r.uE._1x_2y&&(d=i?p.n._300x304:l.L._300x156),o.kumoStyle&&(d=(0,g.F)(e,i)||{width:260,height:136},n.segment_1_1&&(d={width:260,height:260}));const u=()=>a(3,c.j.image);return function(t,e,a,i,n,r){const o=(0,w.Ie)(t);if(!o)return null;const s=(0,S.oQ)(o?.url,{width:e.width,height:e.height,focalRegion:o.focalRegion,enableDpiScaling:!0,devicePixelRatio:(0,D.mZ)(),enableWebpFormat:r});return{altText:t.cardContent?.title,loadCallback:a,errorCallback:i,src:s}}(t,d,u,(t,e)=>{s||(s=!0,(0,b.vV)(m.qog,"Error fetching source","Source: "+t+", Article ID: "+e),u())},0,o.enableWebpFormat)}function P(t){return(0,k.ZV)(t?.metadata?.consumptionSummary?.totalViews)}function H(t,e,a,n,r=!1,o=!1,s,l,c,p,g,u,h,b,m){let f=e,v=t;e.detail&&e.detail.event&&e.detail.data&&(f=e.detail.event,v=this.getListCardMetadata(e.detail.data),r=!0),(v.isLauncher||v.isThirdParty)&&v.useMobile&&(f.preventDefault(),f.stopPropagation());const{cardSize:y,id:x,title:$,destinationUrl:k,mediaData:C,providerData:_,cardActionStatus:T,telemetryContext:{seeMore:F},actionsArrayOverride:S,metadata:D,isLauncher:A,isThirdParty:z,shareHandler:I,feedbackHandler:E,panoCaption:B,isShoppingArticleCard:M,locale:R,ruby:L}=v,N=g?.overrideReasonsDisplay?[{type:d.QK.trending,rank:0},{type:d.QK.u2u,rank:1}]:D.reasons,O={cardSize:y,enabled:!0,buttonElement:f.currentTarget,fromRightClick:h,article:{id:x,headlineTitle:$,href:k,locale:R,image:{alt:C&&C.altText,src:C&&C.src},provider:{id:_.id,profileId:_.profileId,name:_.name,image:{alt:_.name,src:_.logoImage}},abstract:D.abstract,reasons:N,source:D.source},parentTelemetryObject:F,onStatusChange:a,cardStatus:T,updateFeedOnHide:r,disableHoverSquare:!0,showToast:o,refreshFeedCallback:s,openPersonalizeWithoutRouter:l,actionsArrayOverride:S,isReactionsOptedOut:c,isLauncher:A,isThirdParty:z,shareHandler:I,feedbackHandler:E,debugId:D.debugId,dialogToOpen:p,interactCard:u,useCommunityReactionsForShowMoreLess:L,showAiDisclaimerAttribution:D?.displayAttributes?.showTitleDisclaimer};if(B||M)O.actionsArrayOverride=[i.X.ManageInterests,i.X.Divider,i.X.Report];else if(L&&(0,w.FU)(D))O.actionsArrayOverride=[i.X.WhyAmISee,i.X.Report];else if(L&&(m||b)){const t=[i.X.ShowFewer];m?t.push(i.X.ManageInterests):t.push(i.X.FollowPublisher),t.push(i.X.Mute,i.X.Save,i.X.Divider,i.X.WhyAmISee,i.X.Report),O.actionsArrayOverride=t}h?window.dispatchEvent(new CustomEvent("contentCardRightClick",{detail:{actionState:O,event:f,initCardAction:n}})):n(O)}},32460(t,e,a){"use strict";a.d(e,{t(){return h}});var i=a(69828),n=a(44776),r=a(89757),o=a(69259),s=a(60402),l=a(44978),c=a(33744),d=a(2375),p=a(94172);const g=r.qy`
    ${t=>(0,p.yN)(t.publisherFollowButtonConfigInfo,{attributes:{slot:"following-button"},properties:{contentId:t.id,publisherName:t.providerData.name,publisherProfileId:t.providerData.profileId,profileId:t.providerData.id,getReplacementCardsCallback:t.getReplacementCardsCallback,enableFollowToast:!0,cardActionStatus:t.cardActionStatus,usingResponsiveCard:!0}})}
`,u=r.qy`
    <span slot="action-row-start">
    ${(0,o.z)(t=>t.useStatSocialTemplate,r.qy`
        <social-bar-wc
            config-instance-src=${t=>t.socialBarWCConfigInfo&&(0,d.v)(t.socialBarWCConfigInfo)}
            instance-id=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.configRef&&t.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${t=>t.id}
            :hideComments=${t=>t.hideComments||!1}
            :canShowOneLineComments=${t=>!t.isInfopane&&t.cardSize===i.uE._2x_2y}
            :destinationUrl=${t=>t.destinationUrl}
            :title=${t=>t.title}
            :imageData=${t=>t.imageData}
            :abstract=${t=>t.abstract||t.metadata&&t.metadata.abstract}
            :locale=${t=>c.T3.CurrentMarket||t.locale}
            :theme=${t=>t.socialBarTheme||"default"}
            :rootTelemetryObject=${t=>t.telemetryContext&&(t.telemetryContext.contentCardTelemetryObject||t.telemetryContext.contentCard)}
            :getReplacementCardsCallback=${t=>t.getReplacementCardsCallback}
            :reactionCallback=${t=>t.reactionCallback}
            :shareActionHandler=${t=>t.shareActionHandler}
            :cardActionHideHandler=${t=>t.cardActionClickHandler&&((...e)=>t.cardActionClickHandler(t.id,t.cardActionStatus^l.J.hide,...e))}
            :isInfoPane=${t=>t.isInfopane}
            :socialMetadata=${t=>({...t.metadata,imageData:t.imageData,providerData:t.providerData,title:t.title})}
        ></social-bar-wc>
        `,r.qy`${t=>(0,n.nj)({theme:t.socialBarTheme,hideComments:t.hideComments})}`)}
    </span>
`,h=r.qy`
<cs-responsive-card
    :abstract=${t=>t.abstract}
    :attributionData=${t=>t.attributionData}
    :badgeProps="${t=>t.badgeProps}"
    :overlayBadgeProps="${t=>t.overlayBadgeProps}"
    :contentIndicator="${t=>t.renderContentIndicator}"
    :data="${t=>t}"
    :heightReadyCallback="${t=>t.heightReadyCallback}"
    :heading="${t=>t.title}"
    :href="${t=>t.destinationUrl}"
    id="${t=>t.id}"
    ?immersive="${t=>!("_2x_2y"!=t.cardSize&&("_1x_2y"!=t.cardSize&&"_1x_1y"!=t.cardSize&&"shorts"!==t.responsiveCardSize||!t.immersiveCard))||void 0}"
    :mediaData=${t=>t.mediaData}    
    media-type="${t=>t.mediaType}"
    :preventDefaultClick="${t=>t.preventDefaultClick}"
    :onClickCardActions="${t=>t.toggleCardActionMenu}"
    :onRightClick="${t=>t.toggleCardActionMenu}"
    :onClickHideCard="${(t,e)=>()=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^l.J.hide^l.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")}"
    :onClickLink=${(t,e)=>t.onClickLink}
    :onClickCompanionButton=${(t,e)=>t.onClickCompanionButton}
    size="${t=>t.responsiveCardSize}"
    style="${t=>t.ruby?void 0:(t=>{const e=`grid-area:${t.gridArea};`;return t.predictedHeight?`${e} --placeholder-intrinsic-height: ${t.predictedHeight-32}px;`:e})(t)}"
    :rubySocialBarData="${t=>t.rubySocialBarData}"
    target="${t=>t.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${t=>t.telemetryContext?.contentCard}"
    :telemetryTag_anchor="${t=>t.telemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_hideCard="${t=>t.telemetryContext?.showFewer?.getMetadataTag()}"
    :telemetryTag_undoHide="${t=>t.telemetryContext?.undoShowFewer?.getMetadataTag()}"
    :telemetryTag_moreActions="${t=>t.telemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_showMore="${t=>t.telemetryContext?.upvote?.getMetadataTag()}"
    :telemetryTag_undoShowMore="${t=>t.telemetryContext?.undoUpvote?.getMetadataTag()}"
    :telemetryTag_companion="${t=>t.telemetryContext?.companion?.getMetadataTag()}"
    :telemetryTag_commentButton="${t=>t.telemetryContext?.commentsButton?.getMetadataTag()}"
    title="${t=>t.title}"
    ?underline-title="${t=>t.underlineTitle}"
    :headingPrefix="${t=>t.titlePrefix}"
    :visualReadinessCallback="${t=>t.visualReadinessCallback}"
    ?wide="${t=>"_2x_2y"==t.cardSize||void 0}"
    ?ruby="${t=>t.ruby}"
    ?segment="${t=>t.segment}"
    ?companion="${t=>t.companion}"
    :companionButtonText="${t=>t.companionButtonText}"
    ${(0,s.K)("cardElement")}
>
    ${(0,o.z)(t=>t.publisherFollowButtonConfigInfo,g)}
    ${(0,o.z)(t=>t.enableRichSocialReaction,u)}
</cs-responsive-card>
`},41291(t,e,a){"use strict";a.d(e,{V(){return T}});var i=a(69828),n=a(95402),r=a(77833),o=a(98794),s=a(90948),l=a(51907),c=a(58034),d=a(64859),p=a(52323),g=a(98378),u=a(7446),h=a(25658),b=a(50866),m=a(84289),f=a(91748),v=a(76971),y=a(72287),x=a(33744),$=a(94108),k=a(12867);const C={[i.uE._1x_2y]:n.Sv.infoPane,[i.uE._1x_3y]:n.Sv.infoPane1x3y,[i.uE._2x_2y]:n.Sv.infoPane,[i.uE._2x_3y]:n.Sv.infoPane};function w(t){(0,m.tD)("InfopaneDataMapping.Start",performance.now());let e=[];const{cardActionBitMask:a,cardActionClickHandler:n,cardMetadata:w,cardSlot:_,configOptions:T,enableRichSocialReaction:F,enableRotateOnlyOnce:S,preventDefaultClick:D,handleAdFeedbackSubmit:A,hideStoryEntryPointMap:z,isAdFeedbackV1Enabled:I,initCardAction:E,getReplacementCardsCallback:B,localizedStrings:M,notificationMetadata:R,openLinksInNewTab:L,openLinksInCurrentTab:N,parentTelemetryObject:O,reactionCallback:P,visualReadinessCallback:H,underlineTitle:j}=t,V=w,{grid_area:U}=_,W=H;if(V.subItems&&V.subItems.length?e=V.subItems:(e=V.subCards,V.subItems=e),!e.length)return;const G=(0,d.c)(O),Z=T&&T,J=T&&(T.childExperienceReferencesWC&&T.childExperienceReferencesWC.socialBarWC||T.childExperienceReferences&&T.childExperienceReferences.socialBarWC),X=T&&T.childExperienceReferencesWC&&T.childExperienceReferencesWC.publisherFollowButton;if(V.wpoMetadata){const{contentType:t}=V.wpoMetadata;t!==r.pL.TopStories&&t!==r.pL.TopStoriesV2||(e=e.slice(0,6))}let Q=!1;T?.enablePauseInfopaneOnSpot&&V.wpoMetadata&&V.wpoMetadata.contentType===r.pL.TopStories&&V.metadata&&!0===V.metadata.isSpotlightUX&&V.metadata.previewType&&V.metadata.previewType.startsWith("News_BreakingNews")&&(Q=!0);const q=M?.cardActionsTooltips,Y=T?.enableChevronFlipper,K={id:"infopane",childTemplateType:T.useResponsiveInfopane?"responsive-infopane":"infopane-card",slideContentData:[],enableRotateOnlyOnce:S,enableAdaptDarkMode:T&&T.enableAdaptDarkMode,infoPaneNextFlipperTitle:M?M.infoPaneNextFlipperTitle:"",infoPanePreviousFlipperTitle:M?M.infoPanePreviousFlipperTitle:"",useTitleFontSize:T&&T.useTitleFontSize,enableImmersiveInfopane:T&&T.enableImmersiveInfopane,infopaneViewOptAdCount:T&&T.infopaneViewOptAdCount,cardActionsTooltips:q,enablePauseInfopaneOnSpot:Q,telemetryContext:G,parentContentId:T.parentContentId,underlineTitle:j,flipperCaretIcon:Y?`${(0,x.rA)()?.StaticsUrl}latest/fluent-icons/chevron_left_24_regular.svg`:void 0,enableChevronFlipper:Y};return(0,o.bw)({id:"infopane",experienceType:(T&&T.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t},K,(d,x)=>{const w=[],H=x.cardSize;let V;e.forEach((e,i)=>{const c=e.recoId||e.metadata&&e.metadata.recoId,b=e.ri||e.metadata&&e.metadata.ri,m=(0,o.uX)({id:"infopane",columnArrangement:d,experienceType:Z?.configRef?.experienceType,mapperArgs:t,recoId:c,ri:b,subCardIndex:i});V=m.telemetryExt,e.segmentMetadata?.signature&&(V.signature=e.segmentMetadata.signature);const x=e.visualReadinessCallback,k=()=>{W&&W(),x&&x()},S=$.Rb?.CurrentFlightSet?.has("prg-ad-iasv2ra"),U=!1===$.Rb?.CurrentFlightSet?.has("prg-ad-iasv3ratt-rf");let Q;if("nativead"===e.type||"cmsad"===e.type||"directbuyad"===e.type)Q=(0,s.tc)({cardActionBitMask:a,cardMetadata:e,cardSlot:_,configOptions:T,cardActionClickHandler:n,handleAdFeedbackSubmit:A,immersiveCard:!0,initCardAction:E,isAdFeedbackV1Enabled:I,localizedStrings:M,enableIASResponsiveAdCardFix:S,enableResponsiveAdAndTrustedTypes:U}),Q.adTelemetryContext=(0,h.u)(e,G&&G.infopane,"infopane",0,V),Q.telemetryContext=Q.adTelemetryContext,t.configOptions.preloadInfopaneImages&&((0,y.NN)(Q.imageData?.source),(0,y.NN)(Q.providerData?.logoImage));else if(e.type===r.pL.Dense){if((e?.subItems??e?.subCards).forEach(t=>{if(!t)return;const e=t.recoId||t.metadata&&t.metadata.recoId;e&&(V.recoId=e)}),Q=(0,v.gC)(T,e,L,!0,k,!0,O,H,T.isGreyAdsLabelEnabled,i,V),t.configOptions.preloadInfopaneImages){(0,y.NN)(Q.denseData.heroNews?.imageData?.source),(0,y.NN)(Q.denseData.heroNews?.providerData?.logoImage);for(const t of Q.denseData.newsList||[])(0,y.NN)(t.providerData?.logoImage)}}else Q=(0,l.uh)({cardActionBitMask:a,cardActionClickHandler:n,cardMetadata:e,cardSlot:_,configOptions:T,enableRichSocialReaction:F,getReplacementCardsCallback:B,hideStoryEntryPointMap:z,immersiveCard:!0,initCardAction:E,preventDefaultClick:D,localizedStrings:M,notificationMetadata:R,openLinksInNewTab:L,openLinksInCurrentTab:N,parentTelemetryObject:G&&G.infopane,reactionCallback:P,underlineTitle:j},{socialBarWCConfigInfo:J,publisherFollowButtonConfigInfo:X},H,!0,k),t.configOptions.preloadInfopaneImages&&((0,y.NN)(Q.mediaData?.src),(0,y.NN)(Q.providerData?.logoImage));if(T&&T.addExtToNewsContainer&&Q.telemetryContext&&(Q.telemetryContext.destination&&Q.telemetryContext.contentCard&&(Q.telemetryContext.destination=Q.telemetryContext.contentCard.addOrUpdateChild({...Q.telemetryContext.destination.contract,type:g.MJ.Headline,ext:V})),Q.telemetryContext.contentCard=new p.$({...Q.telemetryContext.contentCard?.contract,ext:V})),e.type===r.pL.EventSDCardSportsMIT3){Q.enableCardHideStoryIcon=!1;const t=M?.worldCupCoverage||"";t&&(Q.overlayBadgeProps={text:t})}const q=e.type===r.pL.EventInfopaneShoppingAI;q&&(Q.destinationUrl=function(t){const e=new URL(t);return e.searchParams.set("entryPoint","msn"),e.searchParams.set("FORM","INFOBG"),e.searchParams.set("msnrid",u.YT.getRequestId()),e.searchParams.set("adunitId","378983"),e.searchParams.set("propertyId","316966"),e.toString()}(Q.destinationUrl)),Q={...Q,...Q.attributionData,cardSize:H,responsiveCardSize:"_1x_2y"==H?f.Go._1u:f.Go._2c,enableProviderAlignmentV2:T&&T.enableProviderAlignmentV2,enableAttrOversizing:T&&T.enableAttrOversizing,imageData:{imageWidth:Q.mediaData?.width?.toString(),imageHeight:Q.mediaData?.height?.toString(),source:Q.mediaData?.src,visualReadinessCallback:Q.mediaData?.loadCallback},isInfopane:!0,isShoppingArticleCard:q,mediaType:e.type===r.pL.Video?"video":"image",addExtToNewsContainer:T&&T.addExtToNewsContainer,useLightShadow:T&&T.useLightShadow,enableAdSponsoredText:T&&T.enableAdSponsoredText},Q&&(e.type!==r.pL.TopStories&&(Q.cardLayout=C[H]),w.push(Q))});const q={...G};if(T&&T.addExtToNewsContainer&&V&&q.infopane){const{row:t,col:e,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:s}=V;q.infopane=new p.$({...q.infopane.contract,ext:{row:t,col:e,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:s}})}const Y=T.autoRotateIntervalMs??t.autoRotateIntervalMs,K=T.autoRotateIntervalMs?void 0:t.autoRotateIntervalMs/1e3,tt=T.enableOneCInfopaneNav&&H===b.qJ._1x_2y,et=(0,k.a)().get("vpFreeze"),at={autoRotateIntervalMs:t.autoRotateIntervalMs,firstAutoRotateIntervalMs:t.firstAutoRotateIntervalMs,layout:H===i.uE._2x_2y?c.j.TwoColumn:c.j.OneColumn,gridArea:U,slideContentData:w,enableFlippersOnRest:T.enableInfopaneFlippersOnRest,enableTransparentFlippersOnRest:T.enableTransIfpFlippersOnRest,enableNoMarginFlippers:T.enableNoMarginFlippers,enableSlideShow:!T.disableSlideShow&&!et,enablePlayPauseButton:!T.disableInfopanePlayPauseButton,disableNavAnimation:T.disableNavAnimation,shiftIpNavToRight:T.shiftIpNavToRight,rotationDuration:Y?Y/1e3:3,enableSingleRotation:S,disableInfopaneComplexAds:T.disableInfopaneComplexAds,enableIpTransform:T.enableIpTransform,enableInfopaneDenseCardInteraction:T.enableInfopaneDenseCardInteraction,restartRotationTimer:T.useResponsiveInfopane&&T.infopaneRestartRotationBuffer>0&&K?K+T.infopaneRestartRotationBuffer:T.restartRotationTimer,wpoRotationDuration:T.useResponsiveInfopane?K:void 0,flipperSize:T.ipFlipperCustomSize??"large",flipperColorInverted:T.invertIpFlipperColor,enablePauseInfopaneOnSpot:Q,seeMoreOverride:T.seeMoreOverride,enableLazyInfopane:!!T.enableLazyInfopane,lazyInfopanePreloadCount:T.lazyInfopanePreloadCount,navPosition:T.enableBottomNav&&!tt?"bottom":"top",tabCount:T.enableMaxInfopaneSlider&&!tt?99:5,telemetryContext:q,parentContentId:T.parentContentId};return(0,m.tD)("InfopaneDataMapping.End",performance.now()),at},!0)}var _=a(37899);const T={getFeedDataForCard(t){return w(t)},viewTemplate:_.P}},37899(t,e,a){"use strict";a.d(e,{P(){return C}});var i=a(89757),n=a(69259),r=a(68835),o=a(66591),s=a(32460),l=a(81244),c=a(7446),d=a(98378),p=a(44978),g=a(23897),u=a(33744),h=a(58623),b=a(98728),m=a(89228),f=a(54084),v=a(94172);const y=i.qy`
    <card-flipper class="previousFlipper" 
        slot="previous-flipper"
        caretIcon="${(0,u.rA)()?.StaticsUrl}latest/fluent-icons/caret_left_24_filled.svg" 
        direction="previous"
        invert-color=${t=>t.flipperColorInverted}
        aria-hidden="${t=>!t.enableFlippersOnRest||!t.enableTransparentFlippersOnRest}"
        size=${t=>t.flipperSize}
        data-t="${t=>t.telemetryContext?.previousSlideArrow?.getMetadataTag()}"
        title=${t=>t.infoPanePreviousFlipperTitle}
    >
    </card-flipper>
`,x=i.qy`
    <card-flipper class="nextFlipper" 
        slot="next-flipper"
        caretIcon="${(0,u.rA)()?.StaticsUrl}latest/fluent-icons/caret_left_24_filled.svg"
        direction="next"
        invert-color=${t=>t.flipperColorInverted}
        aria-hidden="${t=>!t.enableFlippersOnRest||!t.enableTransparentFlippersOnRest}"
        size=${t=>t.flipperSize}
        data-t="${t=>t.telemetryContext?.nextSlideArrow?.getMetadataTag()}"
        title=${t=>t.infoPaneNextFlipperTitle}
    >
    </card-flipper>
`,$=i.qy`
        ${y}
        ${x}
        `,k=new WeakMap,C=i.qy`
                <cs-responsive-infopane
                    class="${t=>D(t)}"
                    duration="${t=>t.rotationDuration}"
                    media-controls="${t=>t.enablePlayPauseButton}"
                    navigation-position="${t=>t.navPosition}"
                    :enableSingleRotation="${t=>t.enableSingleRotation}"
                    :hasSlideShow="${t=>t.enableSlideShow}"
                    :parentContentId="${t=>t.parentContentId}"
                    size="${t=>t.cardSize}"
                    tab-count=${t=>t.tabCount}
                    transition-strategy=${t=>t.enableIpTransform?"transform":"position"}
                    :restartRotationTimer="${t=>t.restartRotationTimer}"
                    :wpoRotationDuration="${t=>t.wpoRotationDuration}"
                    style="grid-area:${t=>t.gridArea}"
                    data-t="${t=>t.telemetryContext?.infopane?.getMetadataTag()}"
                    play-telemetry="${t=>t.telemetryContext?.playTransitionButton?.getMetadataTag()}"
                    pause-telemetry="${t=>t.telemetryContext?.pauseTransitionButton?.getMetadataTag()}"
                    tab-telemetry="${t=>t.telemetryContext?.tabTelemetry?.getMetadataTag()}"
                    @mouseenter=${(t,e)=>{e.event&&w(e.event.currentTarget)}}
                    @mouseleave=${(t,e)=>{e.event&&_(e.event.currentTarget)}}
                    preload-panels=${t=>t.lazyInfopanePreloadCount}
                    :enableVariableSpeed=${t=>t.enableVariableSpeed}
                    :variableTransitionMap=${t=>t.enableVariableSpeed&&t.slideContentData.map(t=>({id:t.id,slideDuration:t.customTransitionSpeed}))}
                    :lazyPanels=${t=>t.enableLazyInfopane?t.slideContentData.map(t=>({id:t.id,data:t})):void 0}
    :lazyPanelTemplate=${(t,e)=>(k.has(e.parent)||k.set(e.parent,i.qy`${t=>S(t)}`),k.get(e.parent))}
                    >
                    ${(0,n.z)(t=>!t.disableInfopaneFlippers,$)}
                    ${(0,r.ux)(t=>t.enableLazyInfopane?[]:t.slideContentData,i.qy`${(t,e)=>S(t)}`)}
                </cs-responsive-infopane>
    `,w=t=>{(0,l.kM)("SuperInfopaneCard",()=>c.YT.sendActionEvent(t,d.EG.Hover,d.MS.Open))},_=t=>{(0,l.pS)("SuperInfopaneCard",()=>c.YT.sendActionEvent(t,d.EG.MouseLeave,d.MS.Open))},T=i.qy.partial("style='height: 100%; width: 100%;'"),F=i.qy`
    <div class="dense-card-container">
        ${t=>(0,v.yN)(t.denseConfigInfo,{properties:{denseData:t.denseData,telemetryObject:t.telemetryObject},memoize:!1})}
    </div>
`,S=t=>{const e=0!==(t.cardActionStatus&p.J.hide)||!!t.enableHideStoryFeedback&&(0!==(t.cardActionStatus&p.J.showFewer)||0!==(t.cardActionStatus&p.J.hidden));return t.isNativeAd?g.W:e?(t=>t.cardActionStatus&p.J.hidden?i.qy`<div class="infopane-hide-story" ${T}>
            ${h.X}
        <div>`:t.cardActionStatus&p.J.adFeedbackSubmitted?i.qy`<div class="infopane-hide-story" ${T}>
            ${b.L}
        <div>`:i.qy`<div class="infopane-hide-story" ${T}>
        ${"nativead"===t.currentCardData?.type?m.j:f.F}
    </div>`)(t):"dense-card"===t.childTemplateType?F:s.t},D=t=>(0,o.x)("infopane mid-button infopaneCardWrapper",["no-nav-anim",t.disableNavAnimation],["immersive-infopane",t.enableImmersiveInfopane],["show-flippers",t.enableFlippersOnRest],["tsp-flippers",t.enableTransparentFlippersOnRest],["no-margin-flippers",t.enableNoMarginFlippers],["has-dense-card",t.slideContentData?.some(t=>"dense-card"===t.childTemplateType)])},57152(t,e,a){"use strict";a.d(e,{Ww(){return k},kZ(){return y},Rl(){return f},R3(){return v},Sl(){return m},u(){return $},IT(){return x}});var i,n,r=a(98794),o=a(98378),s=a(69828),l=a(35667),c=a(46659);(n=i||(i={})).OneColumn="1_column",n.TwoColumn="2_column";var d=a(83916),p=a(1792),g=a(25658),u=a(72287),h=a(98669),b=a(77833);const m=8,f=7200,v=1,y=99;function x(t,e){const a=(new Date).getTime(),i=new Date(t).getTime();if(isNaN(i))return!1;return a-i<1e3*e}function $(t){const{cardMetadata:e,cardSlot:a,openLinksInNewTab:n,parentTelemetryObject:o,visualReadinessCallback:l,isAnaheimDesign:c,isProviderInFooter:p,localizedStrings:g,configOptions:u,infopaneThresholdSecondForNewFlag:h,infopaneThresholdForCommentFlag:b}=t,m="tabbedInfopaneCard",y=b??v,x=h??f,$=e;let C=[];if($.subItems&&$.subItems.length?C=$.subItems:(C=$.subCards,$.subItems=C),!C.length)return;const w=(0,d.G)(o),_={id:m,childTemplateType:"tabbed-infopane-card",enableAdaptDarkMode:u.enableAdaptDarkMode,telemetryContext:w,slideContentData:[]},T=l;return(0,r.bw)({id:m,experienceType:(u&&u.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t},_,(e,a)=>{const l=a.cardSize,d=[];return C.forEach((a,i)=>{if(!a)return;const s=a.recoId||a.metadata&&a.metadata.recoId,h=a.ri||a.metadata&&a.metadata.ri,b=(0,r.uX)({id:m,columnArrangement:e,experienceType:(u&&u.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t,recoId:s,ri:h,subCardIndex:i}).telemetryExt,f=a.visualReadinessCallback,v=k(u,a,n,p,()=>{T&&T(),f&&f()},c,o,w,l,!1,i,b,g,x,y);v&&d.push(v)}),{layout:l===s.uE._2x_2y?i.TwoColumn:i.OneColumn,slideContentData:d}})}function k(t,e,a,i,n,r,s,d,f,v,$,k,C,w,_){let T=t.childExperienceReferencesWC?.denseCard||t.childExperienceReferences?.denseCard;const F=e?.subItems??e?.subCards,S=F[0]?.cardContent??(0,u.cZ)(F[0]).cardContent,D=F[0]?.commentSummary?.totalCount??(0,u.cZ)(F[0]).commentSummary?.totalCount??0;T={...T,instanceId:`denseCard-${S.id}`};const A=F[0]?.type===b.pL.WebContent,{id:z,destinationUrl:I,title:E,provider:B,type:M}=S,R=(0,u.Ie)(F[0]),L=s.addOrUpdateChild({name:"DenseSlide",type:o.MJ.Headline}),N=(0,l.dj)(L,S,F[0].metadata,k,M===b.pL.WebContent),O=!0!==t.disableDenseArticleTemplate&&R?.width<R?.height;let P=c.L._240x129;O?P=c.L._240x253:t.useLargeHeroImageForDense&&(P=c.L._300x200);const H=(0,h.po)(F[0],P,n,r,!1);let j=F?.slice(1);j.length>m&&(j=j.slice(0,m-1).concat(j[j.length-1]));const V={heroNews:{id:z,destinationUrl:(0,p.EJ)((0,u.Dv)(I)),openLinksInNewTab:a,title:E,ariaLabel:(0,u.yL)(E,B,null),imagePriority:!1,providerData:(0,u.p_)(B,A,null),isProviderInFooter:i,imageData:H,useArticleCardTemplate:O,telemetryContext:N,commentCount:Math.min(D,y),commentFlag:D>=_,newFlag:x(S.publishedDateTime,w)},newsList:j?.map(e=>{const a=e.type===b.pL.NativeAd||e.type===b.pL.CmsAd;if(!a){const i=e.type===b.pL.WebContent;e.cardContent||(e=(0,u.cZ)(e));const n=e.metadata.commentSummary?.totalCount??0;return{destinationUrl:(0,p.EJ)((0,u.Dv)(e.cardContent.destinationUrl)),title:e.cardContent.title,ariaLabel:(0,u.yL)(E,e.cardContent.provider,null),providerData:(0,u.p_)(e.cardContent.provider,i,null),isNativeAd:a,telemetryContext:(0,l.dj)(L,e.cardContent,e.metadata,k,i),isNarrowNewsItem:t.isNarrowNewsItem,commentCount:n<=y?n:y,commentFlag:n>=_,newFlag:x(e.cardContent.publishedDateTime,w)}}const i=e.placement?.items[0]??{},{beaconsJson:n,privacyUrl:r,adLabelText:o,geminiViewabilityDataJson:s}=e.placement??{};return{...i,beaconsJson:n,privacyUrl:r,adLabelText:o,geminiViewabilityDataJson:s,isNativeAd:a,adTelemetryContext:(0,g.u)(e,L,"infopane",0),isNarrowNewsItem:t.isNarrowNewsItem,isGreyAdsLabelEnabled:v}}),configOptions:t,cardSize:f,isTabbedInfopane:!0};let U;U=e.feed?.feedName?e.feed.feedName:C?.tabNameAll?C.tabNameAll:"総合";const W=function(t,e){switch(t){case"CanonicalName-entertainment":return e.tabEntertainment;case"CanonicalName-sports":return e.tabSports;case"CanonicalName-news-national":return e.tabNewsNational;case"CanonicalName-news-world":return e.tabNewsWorld;case"CanonicalName-finance-business":return e.tabFinanceBusiness;case"CanonicalName-lifestyle":return e.tabLifestyle;case"CanonicalName-businessnews":return e.tabBusinessNews;case"CanonicalName-scienceandtechnology":return e.tabScienceAndTechnology;default:return e.tabAll}}(e.id,d);return{id:$.toString(),denseConfigInfo:T,childTemplateType:"tabbed-infopane-card",gridArea:"",telemetryObject:L,denseData:V,tabLabel:U,tabTelemetry:W}}},83916(t,e,a){"use strict";a.d(e,{G(){return n}});var i=a(98378);const n=t=>{if(!t)return;const e=t.addOrUpdateChild({name:"TabbedInfopane",type:i.MJ.Headline}),a=e.addOrUpdateChild({name:"taball",behavior:i.MS.Show,content:{headline:"taball"},type:i.MJ.ActionButton}),n=e.addOrUpdateChild({name:"tabentertainment",behavior:i.MS.Show,content:{headline:"tabentertainment"},type:i.MJ.ActionButton}),r=e.addOrUpdateChild({name:"tabsports",behavior:i.MS.Show,content:{headline:"tabsports"},type:i.MJ.ActionButton}),o=e.addOrUpdateChild({name:"tabnewsnational",behavior:i.MS.Show,content:{headline:"tabnewsnational"},type:i.MJ.ActionButton}),s=e.addOrUpdateChild({name:"tabnewsworld",behavior:i.MS.Show,content:{headline:"tabnewsworld"},type:i.MJ.ActionButton}),l=e.addOrUpdateChild({name:"tabfinancebusiness",behavior:i.MS.Show,content:{headline:"tabfinancebusiness"},type:i.MJ.ActionButton}),c=e.addOrUpdateChild({name:"tablifestyle",behavior:i.MS.Show,content:{headline:"tablifestyle"},type:i.MJ.ActionButton}),d=e.addOrUpdateChild({name:"tabbusinessnews",behavior:i.MS.Show,content:{headline:"tabbusinessnews"},type:i.MJ.ActionButton}),p=e.addOrUpdateChild({name:"tabscienceandtechnology",behavior:i.MS.Show,content:{headline:"tabscienceandtechnology"},type:i.MJ.ActionButton});return{componentRoot:t,tabbedInfopane:e,tabAll:a,tabEntertainment:n,tabSports:r,tabNewsNational:o,tabNewsWorld:s,tabFinanceBusiness:l,tabLifestyle:c,tabBusinessNews:d,tabScienceAndTechnology:p}}},60941(t,e,a){"use strict";a.d(e,{L9(){return l},M(){return s}});var i=a(89757),n=a(68835),r=a(94172);const o=i.qy`
<fluent-tab id="tab_panel_${t=>t.id}" data-t=${t=>t.tabTelemetry?.getMetadataTag()} aria-label=${t=>t.tabLabel}>${t=>t.tabLabel}</fluent-tab>
<fluent-tab-panel data-t=${t=>t.tabTelemetry?.getMetadataTag()}>
${t=>(0,r.yN)(t.denseConfigInfo,{properties:{denseData:t.denseData,telemetryObject:t.telemetryObject},memoize:!1})}
</fluent-tab-panel>
`,s=i.qy`
<style>
    .tabbed-infopane {
        background: #fff;
        height: 304px;
    }
    .tabbed-infopane fluent-tabs {
        background: #E5E5E5;
    }
    .tabbed-infopane fluent-tab-panel {
        padding: 0px;
    }
    .tabbed-infopane fluent-tab {
        color: #222222;
        font-size: 14px;
        font-family: "Segoe UI", Arial, Sans-Serif;
        font-weight: 400;
        align-items: center;
        line-height: 20px;
        background: #E5E5E5;
        text-align: center;
        padding: 8.2px;
        border-radius: 0px 0px 0px 0px;
    }
    /* Change selected tab's design */
    .tabbed-infopane fluent-tab[aria-selected="true"] {
        background-color: #fff;
        color: rgba(0, 0, 0, 0.83);
        font-weight: 700;
        border-radius: 6px 6px 0px 0px;
        box-shadow: 0px -2.02314px 4.0462px rgba(0, 0, 0, 0.05);
    }
    /* Show underline when hovering unselected tabs */
    .tabbed-infopane fluent-tab[aria-selected="false"]:hover {
        text-decoration: underline;
    }
    /* Change dense-card's design for tabbed-infopane */
    .tabbed-infopane dense-card::part(dense-card-part) {
        margin-top: 0px;
        background: #fff;
    }
    /* Disable fluent-tabs' active-indicator */
    .tabbed-infopane fluent-tabs::part(active-indicator) {
        display: none;
    }

    @media (prefers-color-scheme: dark) {
        .tabbed-infopane.adapt-dark-mode {
            background: #424242;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tabs {
            background: #757575;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tab {
            color: #FFFFFF;
            background: #757575;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tab[aria-selected="true"] {
            background-color: #424242;
            color: #FFFFFF;
        }
        .tabbed-infopane.adapt-dark-mode dense-card::part(dense-card-part) {
            background: #424242;
        }
    }
</style>
<div class="${t=>c(t)}"
     data-t="${t=>t.telemetryContext?.tabbedInfopane?.getMetadataTag()}">
    <fluent-tabs orientation="horizontal">
        ${(0,n.ux)(t=>t.slideContentData,o,{positioning:!0})}
    </fluent-tabs>
</div>
`,l=i.qy`
<style>
    :host fluent-card {
        content-visibility: auto;
    }
</style>
<fluent-card style="grid-area:${t=>t.gridArea}; ${t=>t.autoRowHeights?"height: 304px;":""}"  class="${t=>t.cardSize}">
    <fluent-design-system-provider 
        fill-color="#333"
        style="height: 100%;"
    >
    ${s}
    </fluent-design-system-provider>
</fluent-card>
`,c=t=>{let e="tabbed-infopane";return t.enableAdaptDarkMode&&(e+=" adapt-dark-mode"),e}},10173(t,e,a){"use strict";a.d(e,{W(){return _}});var i,n,r,o,s=a(44978),l=a(69828),c=a(35667),d=a(98794),p=a(98378),g=a(58319),u=a(25066),h=a(33744),b=a(98669),m=a(77833),f=a(29307),v=a(54694),y=a(72287);(n=i||(i={})).Header="header",n.Vertical="homepage",n.HeaderLinkHL="TopStories",n.TopStoriesCard="TopStoriesCard",n.CardVersion="single",n.FlipperNext="FlipperNext",n.FlipperPrevious="FlipperPrevious",n.SubCard="topstories",(o=r||(r={})).Header="trendingnow_header",o.Vertical="homepage",o.HeaderLinkHL="TrendingNow",o.TrendingNowCard="TrendingNow",o.CardVersion="single",o.FlipperNext="FlipperNext",o.FlipperPrevious="FlipperPrevious",o.SubCard="trendingnow";const x=(t,e)=>{if(!t)return;let a,n;e===m.pL.TopicFeedTrendingNow||e===m.pL.TopicFeed?(a=t.addOrUpdateChild({name:r.TrendingNowCard,type:p.MJ.ContentGroup}),n=r):(a=t.addOrUpdateChild({name:i.TopStoriesCard,type:p.MJ.ContentGroup}),n=i);const o=a.addOrUpdateChild({name:n.CardVersion,type:p.MJ.ContentGroup}),s=o.addOrUpdateChild({name:n.SubCard}),l=a.addOrUpdateChild({name:n.Header,action:p.EG.Click,behavior:p.MS.Navigate,type:p.MJ.ContentGroup,content:{id:n.Header,type:p.b5.Feed,vertical:n.Vertical,headline:n.HeaderLinkHL}}),c=a.addOrUpdateChild({name:n.FlipperPrevious,action:p.EG.Click,behavior:p.MS.Show,content:{id:n.FlipperPrevious},type:p.MJ.ContentGroup}),d=a.addOrUpdateChild({name:n.FlipperNext,action:p.EG.Click,behavior:p.MS.Show,content:{id:n.FlipperNext},type:p.MJ.ContentGroup}),{zone:g}=t.contract||{};g&&(a.contract.zone=g,l.contract.zone=g);return{componentRoot:t,topStoriesCard:a,cardVersion:o,subCard:s,headingClick:l,flipperNextClick:d,flipperPreviousClick:c}};var $,k,C,w;function _(t){const{cardMetadata:e,parentTelemetryObject:a,localizedStrings:i,openLinksInNewTab:n,cardActionClickHandler:r,cardActionBitMask:o,initCardAction:k,enableRichSocialReaction:C,visualReadinessCallback:w,configOptions:_,refreshFeedCallback:S,isAnaheimDesign:D,additionalHeaders:A}=t,{topStoriesHeadingText:z,workHeadlinesHeadingText:I,workHeadlinesTooltipText:E}=i,B=x(a,e.type),M=_&&_.topStoryCardConfig;let R;if(M&&M.topStoriesLandingPageLink){const t=(0,g.bI)(M.topStoriesLandingPageLink);R=(0,u.wY)(t)}const L=_&&(_.childExperienceReferencesWC&&_.childExperienceReferencesWC.socialBarWC||_.childExperienceReferences&&_.childExperienceReferences.socialBarWC),N=e.type===m.pL.WorkHeadlines,O=N?[s.X.Report]:null,P=function(t,e,a,i,n,r,o,s,l,d,p,g,u){if(!t)return[];return t.map(t=>{const{locale:f,provider:x,publishedDateTime:$,title:k,url:C,destinationUrl:w,id:_,abstract:T,type:F}=t,S=C||w;let D;if(r){const e=(0,c.dj)(r,t,null,null,F===m.pL.WebContent);e&&(D={contentCard:e.contentCard,contentCardTelemetryObject:e.contentCard&&e.contentCard,button:e.seeMore&&e.seeMore.getMetadataTag(),destination:e.destination,buttonTelemetryObject:e.seeMore,seeMore:e.seeMore})}const A=(0,y.H8)(t,a),{cardActionsTooltips:z,crawledContentLabel:I}=e,E=F===m.pL.WebContent;let B,M;if(l&&(l.useThumbnailTopStories||l.useRightRailTopStories||l.useTopStoriesRibbonCarousel)){let e;e=l?.useImgGenerator?l.stockImageData&&{url:(0,v.XP)(l.stockImageData.id,{width:0,height:0,enableDpiScaling:!1}),width:l.stockImageData.width,height:l.stockImageData.height}:l.stockImageData;const a=t.images&&t.images[0]||e,i=a&&a.colorSamples,n=t&&t.colorSamples;B=function(t,e){if(!t)return;const{attribution:a,title:i=e,url:n}=t;if(!n)return null;const r=[];i&&r.push(i);a&&r.push(a);let o;r.length&&(o=r.join(" - "));return{source:n,altText:o}}(a,t.title),M=(0,b.uK)(i,n,!0)}let R=(0,y.Dv)(S);return"winWidgets"!==h.T3.AppType&&"windowsNewsPlus"!==h.T3.AppType||(R=(0,c._l)(R)),{id:_,abstract:T,articleCardBackgroundColor:M,gridArea:null,childTemplateType:null,cardActionStatus:!E&&A,cardActionClickHandler:i,cardActionsTooltips:z,crawledContentLabel:I,isWebContent:E,destinationUrl:R,enableRichSocialReaction:!E&&o,isProviderIconClickable:l&&l.isProviderIconClickable,locale:f,imageData:B,title:k,providerData:(0,y.p_)(x,E),publishedDateTime:l&&l.enableArticleTimestamps&&`${(0,b.fL)(l.enableNewTimestampFormatForJAJP,new Date($),f,e)}`,toggleCardActionMenu(t,e){return(0,b.Sp)(t,e,i,n,!0,!0,d,l?.openPersonalizeWithoutRouter)},telemetryContext:D,openLinksInNewTab:s,openArticleInNewTab:l&&l.openArticleInNewTab,ariaLabel:(0,y.yL)(k,x,e),actionsArrayOverride:p,socialBarWCConfigInfo:g,metadata:t,enableFilledIconOnHover:l&&l.enableFilledIconOnHover,additionalHeaders:u,disableCardTitleTooltip:l&&l.disableCardTitleTooltip,disableTitleOnArticleCardOnly:l&&l.disableTitleOnArticleCardOnly}})}(e.subCards,i,o,r,k,B&&B.topStoriesCard,!N&&C,n,_,S,O,L,A),H=N?I:z,j={id:"topStories",childTemplateType:"top-stories-card",listCardData:P,openLinksInNewTab:n,topStoriesHeadingText:_&&!0===_.disableTopStoriesCardHeading?"":H,tooltip:N?E:null,telemetryContext:B,cardLayout:T(_,P.length),cardBackground:F(_),headingLink:R,isAnaheimDesign:D,disableTopStoriesInlineAction:_?.disableTopStoriesInlineAction,isDynamicFeed:_&&_.isDynamicFeed,useGradientBackground:M&&M.useGradientBackground,disableCardTitleTooltip:_&&_.disableCardTitleTooltip,disableTitleOnArticleCardOnly:_&&_.disableTitleOnArticleCardOnly,enableFeeds2TopStoriesCarousel:_&&_.enableFeeds2TopStoriesCarousel,isSpotlightUX:e.subCards&&e.subCards[0]&&e.subCards[0].isFeatured,spotlightBreakingNewsTagString:i?.topStoriesBreakingNewsTagString},V=(0,d.bw)({id:"topStories",experienceType:(_&&_.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:t},j,(t,e)=>{const a=(0,f.A)(P);a.forEach((t,a)=>{if(t.telemetryContext&&t.telemetryContext.contentCard&&t.telemetryContext.destination){const i={...e.telemetryExt};t.metadata.recoId&&(i.recoId=t.metadata.recoId),t.metadata.ri&&(i.ri=t.metadata.ri),i.sco=a+1,i.cid=`${i.co}.${i.sco}`,t.telemetryContext.destination=t.telemetryContext.contentCard.addOrUpdateChild({...t.telemetryContext.destination.contract,type:p.MJ.Headline,ext:i})}});const i={listCardData:a},n=e.cardSize;return n===l.uE._1x_2y&&(i.cardLayout=_&&_.useThumbnailTopStories?$.CompactThumbnail:$.Compact),_&&_.useRightRailTopStories&&(i.cardLayout=n===l.uE._1x_3y?$.TallRightRail:$.RightRail),i});return w&&w(),V}function T(t,e){return t&&t.useRightRailTopStories?$.RightRail:t&&t.useTopStoriesRibbonCarousel?$.RibbonCarousel:t&&t.useThumbnailTopStories?e>3?$.Thumbnail:$.CompactThumbnail:t&&t.useStackedTopStories?$.Stacked:e>3?$.Normal:$.Compact}function F(t){return t&&t.useSectionHeaderTopStories?C.InheritSection:t&&t.useGradientTopStories?C.Gradient:C.Normal}(k=$||($={})).Compact="compact",k.CompactThumbnail="compactthumb",k.TallRightRail="tallrightrail",k.RightRail="rightrail",k.Normal="normal",k.Stacked="stacked",k.Thumbnail="thumb",k.RibbonCarousel="ribbonCarousel",(w=C||(C={})).Normal="normal",w.Gradient="gradient",w.InheritSection="inheritSection"},14097(t,e,a){"use strict";a.d(e,{z(){return at}});var i=a(56911),n=a(47810),r=a(95403),o=a(6032),s=a(83252),l=a(86856),c=a(22131),d=a(59669),p=a(73477),g=a(16215),u=a(63033);const h=d.A`
:host{--background-gradient-angle:44.24deg;--inline-actions-gradient-angle:270deg;--inline-actions-dynamic-gradient-angle:90deg;--feeds-2-light-background-gradient-angle:93.96deg;--feeds-2-dark-background-gradient-angle:138.52deg}:host msft-article .inline-actions{right:0}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{right:88px}:host([layout="thumb"][card-size="_2x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_2x_2y"]) msft-article .inline-actions{right:72px}:host([layout="thumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="thumb"][card-size="_1x_3y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_3y"]) msft-article .inline-actions{right:65px}:host .icon-tooltip{left:15px}`,b=d.A`
:host{--background-gradient-angle:-44.24deg;--inline-actions-gradient-angle:-270deg;--feeds-2-light-background-gradient-angle:-93.96deg;--feeds-2-dark-background-gradient-angle:-138.52deg}:host msft-article .inline-actions{left:0}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{left:88px}:host([layout="thumb"][card-size="_2x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_2x_2y"]) msft-article .inline-actions{left:72px}:host([layout="thumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="thumb"][card-size="_1x_3y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_3y"]) msft-article .inline-actions{left:65px}:host msft-article .inline-actions .actions-button{margin:4px 0 4px 8px}:host .icon-tooltip{right:15px}`,m=d.A`
:host([layout="ribbonCarousel"]){border-radius:0}:host([layout="ribbonCarousel"][background="gradient"]){background:linear-gradient(var(--ribbon-carousel-gradient-background))}:host([layout="ribbonCarousel"][background="inheritSection"]) fluent-horizontal-scroll{display:block;margin:0 16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) fluent-horizontal-scroll{margin-inline:16px}:host([layout="ribbonCarousel"][card-size="_1x_1y"]) .inner-content{width:300px}:host([layout="ribbonCarousel"][card-size="_2x_1y"]) .inner-content{width:612px}:host([layout="ribbonCarousel"][card-size="_3x_1y"]) .inner-content{width:924px}:host([layout="ribbonCarousel"][card-size="_4x_1y"]) .inner-content{width:1236px}:host([layout="ribbonCarousel"]) .inner-content{overflow:visible}:host([layout="ribbonCarousel"][background="inheritSection"]) .inner-content{width:100%}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .inner-content{padding-bottom:16px}:host([layout="ribbonCarousel"]) .heading-container{padding-top:10px;padding-bottom:2px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading-container{padding-bottom:0;padding-top:0}:host([layout="ribbonCarousel"][card-size="_1x_2y"]) .heading-container{padding-top:12px}:host([layout="ribbonCarousel"]) .heading{font-size:var(--type-ramp-plus-1-font-size);font-weight:600;line-height:var(--type-ramp-plus-1-line-height)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-heigh,16px);display:inline-flex;padding:16px 16px;font-weight:400}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading-container{align-items:baseline}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading svg{margin-inline-end:8px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading::after{content:"";position:absolute;top:0px;right:0px;left:0px;height:160px;width:612px;z-index:1}:host([layout="ribbonCarousel"]) fluent-horizontal-scroll{max-width:-webkit-fill-available;max-width:-moz-available;--scroll-item-spacing:0}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) fluent-horizontal-scroll{z-index:2}:host([layout="ribbonCarousel"]) msft-article{height:102px;min-width:300px;white-space:initial}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article{height:96px;width:272px;min-width:272px;background:var(--article-backplate);border-radius:8px;margin-inline-end:8px}:host([layout="ribbonCarousel"]) msft-article,:host([layout="ribbonCarousel"][background="inheritSection"]) msft-article{margin-inline-end:12px}:host([layout="ribbonCarousel"]) msft-article:last-child,:host([layout="ribbonCarousel"][background="inheritSection"]) msft-article:last-child{margin-inline-end:0}:host([layout="ribbonCarousel"]) msft-article .image{height:60px;margin-top:4px;width:60px}:host([layout="ribbonCarousel"]) msft-article .image{height:80px;margin-top:0px;width:68px}:host([layout="ribbonCarousel"]) msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,3)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(heading){--msft-article-heading-font-size:14px;--msft-article-heading-line-height:20px;margin-top:20px;width:180px}:host([layout="ribbonCarousel"]) msft-article::part(article){height:88px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(article){height:80px;padding:8px}:host([layout="ribbonCarousel"]) msft-article::part(attribution){position:absolute;bottom:4px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(attribution),:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(actions){top:8px}:host([layout="ribbonCarousel"]) msft-article .inline-actions{bottom:0}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article .inline-actions{top:-8px;inset-inline-end:72px}:host([layout="ribbonCarousel"][background="gradient"]) msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(var(--inline-actions-ribbon-carousel-gradient-background))}:host([layout="ribbonCarousel"][background="gradient"]) social-bar-wc::part(reaction-menu-container){background:var(--background-ribbonCarousel-social-bar)}:host([layout="ribbonCarousel"][background="gradient"][feeds-2-carousel="true"]) social-bar-wc::part(reaction-menu-container){top:0px;animation:none}:host .card-content{display:flex;overflow-x:hidden}:host .card-content msft-article.carousel{display:block}:host([layout="ribbonCarousel"][background="inheritSection"]) ::part(viewport){overflow-y:hidden}:host([layout="ribbonCarousel"]) .next,:host([layout="ribbonCarousel"]) .previous{width:32px;height:32px;border-color:transparent;border-radius:999px;box-shadow:0px 3.2px 7.2px rgb(0 0 0 / 13%),0px 0px 3.8px rgb(0 0 0 / 11%);background:var(--neutral-fill-stealth-rest)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{height:38px;width:16px;fill:var(--neutral-foreground-hint);backdrop-filter:blur(60px);border-radius:3px;box-shadow:none}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{opacity:1}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next:hover,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous:hover{fill:var(--neutral-foreground-rest)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next{margin-inline-start:16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{margin-inline-end:16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next::before,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous::before{border-radius:3px;background:var(--feeds-2-flipper-background)}:host([layout="ribbonCarousel"][background="inheritSection"]) .previous{margin-inline-start:10px}:host([layout="ribbonCarousel"][background="inheritSection"]) .next{margin-inline-end:10px}:host([layout="ribbonCarousel"][background="gradient"]):not([feeds-2-carousel="true"]) .previous{margin-inline-start:36px}:host([layout="ribbonCarousel"][background="gradient"]):not([feeds-2-carousel="true"]) .next{margin-inline-end:36px}:host([layout="ribbonCarousel"]) .next::before,:host([layout="ribbonCarousel"]) .previous::before{border-color:transparent}`,f=d.A`
:host([layout*="rightrail"]) .heading{font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height);color:var(--neutral-foreground-hint)}:host([layout="rightrail"]) msft-article .image{height:62px;width:62px}:host([layout="tallrightrail"]) msft-article .image{height:76px;width:76px}:host([layout="tallrightrail"]) msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,3)}:host([layout*="rightrail"]) .heading-container{text-transform:uppercase}:host([layout*="rightrail"]) .heading{padding-left:16px;padding-right:16px}:host([layout="tallrightrail"]) msft-article{height:92px}:host([layout*="rightrail"]) msft-article::part(article){padding:8px 16px}:host([layout*="rightrail"]) social-bar-wc::part(button-bg):hover,:host([layout*="rightrail"]) social-bar-wc::part(button-bg):hover{background-color:initial}:host([layout="tallrightrail"]) msft-article.social-reaction-enabled .inline-actions{min-width:76px}:host([layout="rightrail"]) msft-article.social-reaction-enabled .inline-actions{min-width:62px}`,v=d.A`
:host([background="gradient"]){--neutral-fill-stealth-hover:var(--gradient-hover);background:linear-gradient(var(--gradient-background));background-color:var(--background-color-dark-mode)}:host([background="gradient"][layout="ribbonCarousel"][feeds-2-carousel="true"]){background:linear-gradient(var(--feeds-2-gradient-background))}:host([layout="normal"][background="gradient"][card-size="_3x_2y"]) msft-article{--neutral-fill-stealth-hover:transparent;--inline-actions-gradient-background:transparent;--inline-actions-alt-gradient-background:transparent}:host([layout="normal"][background="gradient"]) msft-article::part(actions){background:transparent}:host([layout="thumb"][background="gradient"]) msft-article:hover .inline-actions,:host([layout="thumb"][background="gradient"]) msft-article:focus-within .inline-actions,:host([layout="thumb"][background="gradient"]) msft-article:hover .inline-actions social-bar-wc::part(social-bar),:host([layout="thumb"][background="gradient"]) msft-article:focus-within .inline-actions social-bar-wc::part(social-bar){background:none}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-1))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-2))}:host([background="gradient"][card-size="_1x_3y"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions,:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-3))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-4))}:host([background="gradient"][card-size="_1x_3y"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions,:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-5))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-6))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-1))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-2))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-3))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-1))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-3))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-5))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-1))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-2))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-3))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-4))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-5))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-6))}:host([layout="ribbonCarousel"][background="gradient"][feeds-2-carousel="true"]) msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(var(--inline-actions-feeds-2-gradient-background))}:host([background="gradient"]):host msft-article .inline-actions .actions-button:${p.N}{background:transparent}:host([background="gradient"]) msft-article .inline-actions .divider{border-left:1px solid rgba(0,0,0,0.09);margin-top:2px}:host([background="gradient"]) msft-article:hover,:host([background="gradient"]) msft-article:focus-within,:host([background="gradient"]) social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article .inline-actions .actions-button:hover{background:var(--gradient-hover)}:host([background="gradient"]) social-bar-wc::part(reaction-menu-container){background:var(--background-social-bar)}:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(comments-count-button):hover,:host([background="gradient"]) msft-article.filled-icon-hover .inline-actions .actions-button:hover{background:transparent}`,y=d.A`
:host{--msft-article-heading-line-height:22px;display:flex;height:100%;border-radius:calc(var(--layer-corner-radius) * 1px)}:host .inner-content{display:flex;flex-wrap:wrap;justify-content:space-between;margin:0 auto;overflow:var(--overflow,hidden)}:host msft-article .image{border-radius:4px;margin-inline-start:6px;overflow:hidden}:host msft-article .image{height:72px;width:72px}:host([card-size="_2x_2y"]) msft-article .image{height:59px;width:59px}:host([card-size="_1x_2y"]) msft-article .image,:host([card-size="_1x_3y"]) msft-article .image{height:52px;width:52px}:host([layout="normal"]),:host([layout="thumb"]),:host([layout*="rightrail"]){padding-left:3px;padding-right:3px}:host([layout="normal"][class="infopane-anaheim-design"]),:host([layout="thumb"][class="infopane-anaheim-design"]),:host([layout*="rightrail"][class="infopane-anaheim-design"]){padding-left:2px;padding-right:2px}:host([card-size="_3x_2y"]){padding-left:9px;padding-right:9px}:host([card-size="_3x_2y"]) msft-article{width:444px}:host([layout="compact"]),:host([layout="compactthumb"]),:host([layout*="rightrail"]){--msft-article-heading-font-size:14px;--msft-article-heading-line-height:20px}:host([layout="compact"]) msft-article{height:80px}:host([layout="ribbonCarousel"]) msft-article,:host([layout*="rightrail"]) msft-article{padding-bottom:0px}:host([layout="normal"]) msft-article,:host([layout="thumb"]) msft-article{padding-bottom:0px;margin-bottom:6px}:host msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,2)}:host msft-article::part(heading)::after{height:100%;width:100%}:host msft-article.crawled-content::part(heading){-webkit-line-clamp:var(--heading-max-lines,1)}:host .heading-container{width:100%;position:relative;display:flex;align-items:center}:host .heading-container.anaheim-infopane{padding-top:12px;padding-bottom:6px}:host .anaheim-infopane-bottom-padding{height:8px;width:100%}:host([card-size="_3x_2y"]) .heading-container{padding-left:3px;padding-right:3px}:host .heading{font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);font-weight:600;color:${n.l};margin:0;padding:16px 12px 10px;width:100%}:host([layout="normal"]) .heading,:host([layout="thumb"]) .heading{padding-left:9px;padding-right:9px}:host .heading-link{text-decoration:none}:host .heading-icon-container{cursor:pointer;display:inline-block;fill:${n.l};padding:0 8px;height:18px}:host .heading-icon-container:hover .icon-tooltip,:host .heading-icon-container:focus .icon-tooltip{visibility:visible;opacity:1}:host .icon-tooltip{background-color:${r.wO};border-radius:4px;color:${n.l};font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);opacity:0;padding:8px;position:absolute;text-transform:initial;top:40px;transition:opacity 0.3s;visibility:hidden;width:200px;z-index:1}:host([layout="compact"]) .heading{text-transform:uppercase;color:${o.c};font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}:host([layout="compact"]) .heading-icon-container{fill:${o.c}}:host msft-article{border-radius:0;height:80px;padding-bottom:6px;width:300px;z-index:0}:host([layout="stacked"]) msft-article::part(text){display:inline-flex}:host([layout="stacked"]) msft-article::part(abstract){margin-inline-start:0px;width:90px}:host([layout="stacked"][card-size="_2x_2y"]) msft-article.stacked-fromweb::part(heading){max-width:470px}:host([layout="stacked"][card-size="_3x_2y"]) msft-article.stacked-fromweb::part(heading){max-width:770px}:host([layout="stacked"]) msft-article{height:36px;margin:0 9px;padding:0;width:100%}:host([layout="stacked"]) msft-article:nth-of-type(6){margin-bottom:6px;padding:0}:host([layout="stacked"]) msft-article::part(heading){display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:300px;margin-inline-start:4.5px}:host([layout="stacked"][card-size="_2x_2y"]) msft-article::part(heading){width:542px}:host([layout="stacked"][card-size="_3x_2y"]) msft-article::part(heading){width:832px}:host msft-article::part(article){border-radius:0;grid-gap:0;grid-template-columns:1fr auto;padding:8px 12px;overflow:visible}:host([layout="normal"]) msft-article::part(article),:host([layout="thumb"]) msft-article::part(article){height:64px}:host([layout="thumb"][card-size="_3x_2y"]) msft-article::part(article){padding:4px 12px}:host([layout="normal"]) msft-article::part(text),:host([layout="thumb"]) msft-article::part(text){max-height:calc(var(--msft-article-heading-line-height,24px) * 2);overflow:hidden}:host([layout="normal"]) msft-article::part(attribution),:host([layout="stacked"]) msft-article::part(attribution),:host([layout="compactthumb"]) msft-article::part(attribution),:host([layout="thumb"]) msft-article::part(attribution){display:inline-block;margin-inline-end:4px;vertical-align:top;width:16px}:host([layout="normal"]) msft-article::part(heading),:host([layout="compactthumb"]) msft-article::part(heading),:host([layout="thumb"]) msft-article::part(heading),:host([layout*="rightrail"]) msft-article::part(heading){width:calc(100% - 31px);display:-webkit-inline-box;margin-inline-start:3.5px}:host([layout*="rightrail"]) msft-article::part(heading){width:calc(100% - 26px)}:host msft-article::part(abstract){margin-inline-start:24px;-webkit-line-clamp:var(--abstract-max-lines,1);margin-top:-2px;color:var(--msft-card-font-color)}:host([layout="compact"][card-size="_1x_2y"]) msft-article::part(abstract){margin-inline-start:0}:host msft-article.crawled-content::part(abstract){color:${o.c};font-size:12px;line-height:16px;margin-top:4px}:host([layout="thumb"]) msft-article.crawled-content::part(abstract),:host([layout*="rightrail"]) msft-article.crawled-content::part(abstract){margin-top:0}:host([layout="normal"]) msft-article::part(actions),:host([layout="thumb"]) msft-article::part(actions),:host([layout="ribbonCarousel"]) msft-article::part(actions){position:absolute;bottom:0;padding-bottom:4px;padding-top:1px;width:calc(100% - 20px);background:var(--fill-color)}:host([layout="normal"]) msft-article:hover::part(actions),:host([layout="normal"]) msft-article:focus-within::part(actions),:host([layout="thumb"]) msft-article::part(actions),:host([layout="thumb"]) msft-article:hover::part(actions),:host([layout="thumb"]) msft-article:focus-within::part(actions),:host([layout="ribbonCarousel"]) msft-article::part(actions),:host([layout="ribbonCarousel"]) msft-article:hover::part(actions),:host([layout="ribbonCarousel"]) msft-article:focus-within::part(actions){background:transparent}:host([layout="thumb"][card-size="_3x_2y"]) msft-article::part(actions){bottom:10px}:host msft-article msft-attribution{display:grid;grid-template-columns:16px auto auto;grid-gap:8px;margin-bottom:4px;position:relative}:host([layout="normal"]) msft-article msft-attribution,:host([layout="thumb"]) msft-article msft-attribution{height:20px;padding-top:4px}:host([layout="thumb"]) msft-article msft-attribution{grid-template-columns:16px auto 65px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article msft-attribution{max-width:180px}:host msft-article .inline-actions{align-items:center;background:${r.oO};display:grid;gap:4px;grid-template-columns:auto auto auto;height:28px;justify-content:end;margin:4px 0;opacity:0;padding:0;padding-inline-start:40px;position:absolute;width:auto;z-index:10}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{height:23px;margin:0}:host([layout="compact"]) msft-article .inline-actions,:host([layout="stacked"]) msft-article .inline-actions,:host([layout*="rightrail"]) msft-article .inline-actions{top:0}:host([layout="normal"]) msft-article .inline-actions{bottom:0;margin-bottom:5px;height:24px}:host([layout="compact"]) msft-article .inline-actions,:host([layout*="rightrail"]) msft-article .inline-actions{margin-inline-end:4px}:host([layout="stacked"]) msft-article .inline-actions{background:var(--neutral-fill-stealth-hover);margin-inline-end:12px}:host msft-article:hover,:host msft-article:focus-within{background:${r.oO};border-radius:4px}:host msft-article:hover .inline-actions,:host msft-article:focus-within .inline-actions{opacity:1}:host msft-article .inline-actions .actions-button{background:transparent;border:none;border-radius:4px;color:currentColor;cursor:pointer;fill:currentColor;height:24px;justify-content:center;min-width:24px;padding:0;width:24px}:host msft-article .inline-actions .actions-button svg{width:16px;height:16px}:host msft-article .inline-actions .actions-button:hover,:host msft-article .inline-actions .actions-button:${p.N}{background:${s.Xt}}:host msft-article .inline-actions .divider{height:11px;margin:-3px 0 0;border-left:1px solid ${s.Xt}}:host([layout="compact"]) msft-article .inline-actions .divider{margin-top:-2px}:host social-bar-wc::part(social-bar){align-self:start;opacity:1;background:none;height:24px}:host([layout="normal"]) social-bar-wc::part(react-button-container),:host([layout="normal"]) social-bar-wc::part(active-button-container){height:24px;padding:0;border-radius:16px}:host([layout="normal"]) social-bar-wc::part(button-bg){padding-top:4px;height:24px}:host msft-article.filled-icon-hover .inline-actions .actions-button:hover > svg > path:nth-child(1){transition:all 0.5s;d:path("${g.i_}")}:host msft-article.filled-icon-hover .inline-actions .actions-button svg{width:20px;height:20px}.attribution-provider-clickable{z-index:4;display:flex;margin:0 -23px}.attribution-icon-clickable{color:unset;text-decoration:none}.attribution-provider-name{unicode-bidi:embed}.attribution-provider-name:hover{text-decoration:underline}.attribution-provider-name .attribution-provider-logo-available:hover{text-decoration:underline}.attribution-provider-logo-available{margin-inline-start:10px}.attribution-published-time{margin:0 3px}.attribution-provider-not-clickable{margin:0 5px}.ts-breaking-news-tag{background-color:var(--accent-fill-rest);border-radius:3px;color:white;padding:0 5px}.breaking-news-red-tag{background-color:#C50F1F !important}.spotlight-flash-bg{animation:spotlight-ts-bg-animation 2000ms cubic-bezier(0,0,1,1) 667ms}@keyframes .spotlight-ts-bg-animation{0%{border:2px solid #8FA2FF;background-color:#8FA2FF26;transition-timing-function:cubic-bezier(0,0,1,1)}100%{transition-timing-function:cubic-bezier(0,0,1,1)}}${m} ${f}
`.withBehaviors(new l.t(h,b),(0,c.mr)(d.A` :host msft-article .inline-actions{background:currentColor !important;padding-inline-start:12px !important}.attribution-provider-logo{forced-color-adjust:none;background:#FFFFFF}`),(0,c.C7)(d.A` :host(.infopane-anaheim-design){--neutral-foreground-rest:#2B2B2B;--fill-color:#FFFFFF;--neutral-fill-hover:#E5E5E5;--neutral-fill-stealth-hover:#F2F2F2;background:#FFFFFF}`)),x=d.A` :host msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(270deg,rgb(var(--neutral-fill-stealth-hover-rgb)) 0.01%,rgb(var(--neutral-fill-stealth-hover-rgb)) 76.82%,rgba(var(--neutral-fill-stealth-hover-rgb),0.8) 88.69%,rgba(var(--neutral-fill-stealth-hover-rgb),0) 100%)}`.withBehaviors((0,c.C7)(d.A` :host{--neutral-fill-stealth-hover-rgb:242,242,242}`),(0,c.G2)(d.A` :host{background:#3b3b3b;--fill-color:#3b3b3b;--neutral-foreground-hint:#a7a7a7;--neutral-foreground-rest:#ffffff;--neutral-fill-stealth-hover:#474747}:host msft-article:hover,:host msft-article:focus-within{background:#474747}:host{--neutral-fill-stealth-hover-rgb:71,71,71}.spotlight-flash-bg{animation:spotlight-bg-animation 2000ms cubic-bezier(0,0,1,1) 667ms}@keyframes spotlight-bg-animation{0%{border:2px solid #8FA2FF;background-color:#8FA2FF4D;transition-timing-function:cubic-bezier(0,0,1,1)}100%{transition-timing-function:cubic-bezier(0,0,1,1)}}`)),$=d.A`
${v}
`.withBehaviors((0,c.mr)(d.A` :host{forced-color-adjust:auto}@media (forced-colors:active){:host([background="gradient"]) social-bar-wc::part(button-bg):hover,:host([background="gradient"]) social-bar-wc::part(button-bg):focus-within,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):focus-within{color:buttonface;background-color:highlight}}`),new u.N(d.A` :host{--article-backplate:rgba(255,255,255,0.7);--background-color-dark-mode:unset;--background-social-bar:#FFFFFF;--background-ribbonCarousel-social-bar:#FFFFFF;--gradient-background:var(--background-gradient-angle),#C2CEE8 0%,rgba(241,246,255,0.6) 100%;--ribbon-carousel-gradient-background:var(--background-gradient-angle),rgba(194,206,232,0.4) 0%,rgba(241,246,255,0.24) 100%;--feeds-2-gradient-background:var(--feeds-2-light-background-gradient-angle),rgba(59,199,225,0.16) 0%,rgba(53,138,220,0.2) 98.88%;--feeds-2-flipper-background:#f1f6fb;--gradient-hover:rgba(0,0,0,0.05);--stacked-gradient-hover:242,242,242;--inline-actions-gradient-background:var(--inline-actions-gradient-angle),#D9D8F2 77.54%,rgba(208,214,242,0.8) 90.62%,rgba(208,214,242,0) 100%;--inline-actions-alt-gradient-background:var(--inline-actions-gradient-angle),#E6E2EF 0.01%,#E3DEEE 76.82%,rgba(227,222,238,0.8) 88.69%,rgba(227,222,238,0) 100%;--inline-actions-thumb-gradient-background-1:var(--inline-actions-gradient-angle),#d3dae8 0.01%,#ccd4e5 76.82%,rgba(202,211,228,0.8) 88.69%,rgba(201,210,228,0) 100%;--inline-actions-thumb-gradient-background-2:var(--inline-actions-gradient-angle),#e4e8ef 0.01%,#dde2ec 76.82%,rgba(219,225,235,0.8) 88.69%,rgba(218,224,235,0) 100%;--inline-actions-thumb-gradient-background-3:var(--inline-actions-gradient-angle),#ced6e6 0.01%,#c7d0e3 76.82%,rgba(198,207,226,0.8) 88.69%,rgba(196,206,225,0) 100%;--inline-actions-thumb-gradient-background-4:var(--inline-actions-gradient-angle),#dfe4ed 0.01%,#d8deea 76.82%,rgba(214,220,233,0.8) 88.69%,rgba(214,219,233,0) 100%;--inline-actions-thumb-gradient-background-5:var(--inline-actions-gradient-angle),#cad3e4 0.01%,#c3cce1 76.82%,rgba(194,203,224,0.8) 88.69%,rgba(193,202,224,0) 100%;--inline-actions-thumb-gradient-background-6:var(--inline-actions-gradient-angle),#d9dfea 0.01%,#d3d9e8 76.82%,rgba(210,216,232,0.8) 88.69%,rgba(208,215,230,0) 100%;--inline-actions-compact-gradient-background-1:var(--inline-actions-gradient-angle),#e6e9f0 0.01%,#dadfeb 76.82%,rgba(215,222,233,0.8) 88.69%,rgba(214,220,233,0) 100%;--inline-actions-compact-gradient-background-2:var(--inline-actions-gradient-angle),#dee3ed 0.01%,#d3dae8 76.82%,rgba(209,216,231,0.8) 88.69%,rgba(208,215,231,0) 100%;--inline-actions-compact-gradient-background-3:var(--inline-actions-gradient-angle),#d7ddea 0.01%,#cbd3e4 76.82%,rgba(202,210,228,0.8) 88.69%,rgba(199,208,227,0) 100%;--inline-actions-stacked-gradient-background-1:var(--inline-actions-gradient-angle),#e6e9f0 0.01%,#e3e7ee 76.82%,rgba(224,229,237,0.8) 88.69%,rgba(220,225,235,0) 100%;--inline-actions-stacked-gradient-background-2:var(--inline-actions-gradient-angle),#e5e9f0 0.01%,#e2e6ee 76.82%,rgba(222,227,236,0.8) 88.69%,rgba(219,224,235,0) 100%;--inline-actions-stacked-gradient-background-3:var(--inline-actions-gradient-angle),#e2e6ee 0.01%,#dfe4ed 76.82%,rgba(220,225,235,0.8) 88.69%,rgba(215,222,233,0) 100%;--inline-actions-stacked-gradient-background-4:var(--inline-actions-gradient-angle),#dfe4ed 0.01%,#dce1eb 76.82%,rgba(216,222,233,0.8) 88.69%,rgba(214,220,233,0) 100%;--inline-actions-stacked-gradient-background-5:var(--inline-actions-gradient-angle),#dee3ed 0.01%,#dae0eb 76.82%,rgba(215,221,233,0.8) 88.69%,rgba(213,219,233,0) 100%;--inline-actions-stacked-gradient-background-6:var(--inline-actions-gradient-angle),#dbe0eb 0.01%,#d7dde9 76.82%,rgba(213,219,233,0.8) 88.69%,rgba(209,216,231,0) 100%;--inline-actions-ribbon-carousel-gradient-background:var(--inline-actions-gradient-angle),#E5E8ED 0.01%,#E4E7ED 76.82%,rgba(227,231,237,0.8) 88.69%,rgba(227,230,237,0) 100%;--inline-actions-feeds-2-gradient-background:var(--inline-actions-gradient-angle),#f5fbfd 0.01%,#f5fcfe 76.82%,rgba(245,252,254,0.8) 88.69%,rgba(245,252,254,0) 100%}:host msft-article msft-attribution{--neutral-foreground-hint:#5f5f5f}`,d.A` :host{--article-backplate:rgba(255,255,255,0.0512);--background-color-dark-mode:#424242;--background-social-bar:#2B3C59;--background-ribbonCarousel-social-bar:#2B3C59;--gradient-background:var(--background-gradient-angle),#2B3C59 0%,rgba(43,60,89,0.6) 100%;--ribbon-carousel-gradient-background:var(--background-gradient-angle),#2B3C59 0%,rgba(43,60,89,0.6) 100%;--feeds-2-gradient-background:var(--feeds-2-dark-background-gradient-angle),#0F384D 0.44%,#0F2E4D 85.15%;--feeds-2-flipper-background:#173549;--gradient-hover:rgba(255,255,255,0.07);--stacked-gradient-hover:72,72,72;--inline-actions-gradient-background:var(--inline-actions-gradient-angle),#716583 0.01%,#665879 76.82%,rgba(100,86,119,0.8) 88.69%,rgba(98,84,118,0) 100%;--inline-actions-alt-gradient-background:var(--inline-actions-gradient-angle),#716583 0.01%,#665879 76.82%,rgba(100,86,119,0.8) 88.69%,rgba(98,84,118,0) 100%;--inline-actions-thumb-gradient-background-1:var(--inline-actions-gradient-angle),#3e4b60 0.01%,#3d4b62 76.82%,rgba(61,75,99,0.8) 88.69%,rgba(61,75,99,0) 100%;--inline-actions-thumb-gradient-background-2:var(--inline-actions-gradient-angle),#404c5d 0.01%,#404c5f 76.82%,rgba(63,75,95,0.8) 88.69%,rgba(64,76,96,0) 100%;--inline-actions-thumb-gradient-background-3:var(--inline-actions-gradient-angle),#3e4b62 0.01%,#3c4b63 76.82%,rgba(60,74,99,0.8) 88.69%,rgba(60,75,100,0) 100%;--inline-actions-thumb-gradient-background-4:var(--inline-actions-gradient-angle),#404c5f 0.01%,#3f4b60 76.82%,rgba(63,76,96,0.8) 88.69%,rgba(63,75,97,0) 100%;--inline-actions-thumb-gradient-background-5:var(--inline-actions-gradient-angle),#3d4c63 0.01%,#3b4a64 76.82%,rgba(60,75,101,0.8) 88.69%,rgba(59,75,101,0) 100%;--inline-actions-thumb-gradient-background-6:var(--inline-actions-gradient-angle),#404c5f 0.01%,#3e4b61 76.82%,rgba(62,75,97,0.8) 88.69%,rgba(62,76,98,0) 100%;--inline-actions-compact-gradient-background-1:var(--inline-actions-gradient-angle),#414c5c 0.01%,#404b5e 76.82%,rgba(64,76,95,0.8) 88.69%,rgba(63,75,95,0) 100%;--inline-actions-compact-gradient-background-2:var(--inline-actions-gradient-angle),#404c5e 0.01%,#3f4b60 76.82%,rgba(63,75,96,0.8) 88.69%,rgba(62,75,96,0) 100%;--inline-actions-compact-gradient-background-3:var(--inline-actions-gradient-angle),#404c60 0.01%,#3d4a61 76.82%,rgba(61,74,97,0.8) 88.69%,rgba(60,74,97,0) 100%;--inline-actions-stacked-gradient-background-1:var(--inline-actions-gradient-angle),#424c5c 0.01%,#414c5d 76.82%,rgba(64,76,93,0.8) 88.69%,rgba(64,75,94,0) 100%;--inline-actions-stacked-gradient-background-2:var(--inline-actions-gradient-angle),#424d5d 0.01%,#414d5e 76.82%,rgba(64,76,94,0.8) 88.69%,rgba(64,76,94,0) 100%;--inline-actions-stacked-gradient-background-3:var(--inline-actions-gradient-angle),#404b5c 0.01%,#404b5d 76.82%,rgba(64,76,94,0.8) 88.69%,rgba(63,75,94,0) 100%;--inline-actions-stacked-gradient-background-4:var(--inline-actions-gradient-angle),#404b5d 0.01%,#404b5e 76.82%,rgba(64,76,95,0.8) 88.69%,rgba(64,76,96,0) 100%;--inline-actions-stacked-gradient-background-5:var(--inline-actions-gradient-angle),#404c5e 0.01%,#404c5f 76.82%,rgba(64,75,95,0.8) 88.69%,rgba(63,75,96,0) 100%;--inline-actions-stacked-gradient-background-6:var(--inline-actions-gradient-angle),#404c5e 0.01%,#3f4b5f 76.82%,rgba(63,75,95,0.8) 88.69%,rgba(62,74,95,0) 100%;--inline-actions-ribbon-carousel-gradient-background:var(--inline-actions-gradient-angle),#3E4C61 0.01%,#3E4C62 76.82%,rgba(62,76,98,0.8) 88.69%,rgba(62,76,98,0) 100%;--inline-actions-feeds-2-gradient-background:var(--inline-actions-gradient-angle),#1b3d55 0.01%,#1b3f56 76.82%,rgba(27,64,86,0.8) 88.69%,rgba(27,64,86,0) 100%}:host msft-article msft-attribution{--neutral-foreground-hint:#b9b9b9}`)),k=d.A` :host([background="inheritSection"]){background:inherit}:host([background="inheritSection"]) msft-article .inline-actions,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:hover,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:focus-visible{background-color:rgba(255,255,255,0.8)}:host([background="inheritSection"]) msft-article,:host([background="inheritSection"]) msft-article:hover,:host([background="inheritSection"]) msft-article:focus-within{background-color:rgba(255,255,255,0.9);border-radius:4px}:host([background="inheritSection"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="inheritSection"]) msft-article.filled-icon-hover social-bar-wc::part(comments-count-button):hover{background:transparent}`.withBehaviors((0,c.C7)(d.A` :host{--neutral-fill-stealth-hover-rgb:242,242,242}`),(0,c.G2)(d.A` :host([background="inheritSection"]) msft-article .inline-actions,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:hover,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:focus-visible{background-color:rgba(0,0,0,0.3)}:host([background="inheritSection"]) msft-article,:host([background="inheritSection"]) msft-article:hover,:host([background="inheritSection"]) msft-article:focus-within{background-color:rgba(0,0,0,0.4)}`)),C=d.A` :host .inner-content.dynamic-gradient-morning,:host([background="gradient"]) .inner-content.dynamic-gradient-morning social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-morning)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-morning-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-morning-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-morning-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-morning-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-morning-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-morning-6)}:host .inner-content.dynamic-gradient-day,:host([background="gradient"]) .inner-content.dynamic-gradient-day social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-day)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-day-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-day-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-day-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-day-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-day-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-day-6)}:host .inner-content.dynamic-gradient-sunset,:host([background="gradient"]) .inner-content.dynamic-gradient-sunset social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-sunset)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-sunset-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-sunset-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-sunset-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-sunset-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-sunset-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-sunset-6)}:host .inner-content.dynamic-gradient-night,:host([background="gradient"]) .inner-content.dynamic-gradient-night social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-night)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-night-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-night-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-night-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-night-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-night-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-night-6)}`.withBehaviors(new u.N(d.A` :host{--background-color-dynamic-gradient-morning:linear-gradient(140.53deg,#FFFEDC 9.32%,#FFF4D7 58.45%);--background-color-dynamic-gradient-day:linear-gradient(140.53deg,#F5F7E1 9.32%,#CDF0FF 58.45%);--background-color-dynamic-gradient-sunset:linear-gradient(140.56deg,#F0E1F7 5.42%,#FFE9E1 51.68%);--background-color-dynamic-gradient-night:linear-gradient(140.53deg,#F0E1F7 9.32%,#CDDFFF 58.45%);--inline-actions-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(237,233,203,0) 0.01%,#F2EECF 7.81%,#F2ECCE 66.67%,#F2ECCE 100%);--inline-actions-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(242,233,205,0) 0.01%,#F2E9CD 7.81%,#F2E8CC 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,235,206,0) 0.01%,#F2EBCE 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(242,233,205,0) 0.01%,#F2E9CD 7.81%,#F2E8CC 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,232,204,0) 0.01%,#F2E8CC 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,232,204,0) 0.01%,#F2E8CC 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-compact-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,233,203,0) 0.01%,#EDE9CB 7.81%,#EDE6CA 66.67%,#EDE4C9 100%);--inline-actions-compact-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,229,201,0) 0%,#EDE5C9 7.81%,#EDE4C8 66.67%,#EDE3C8 100%);--inline-actions-compact-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,227,200,0) 0%,#EDE3C8 7.81%,#EDE3C8 66.67%,#EDE3C8 100%);--inline-actions-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(219,233,224,0) 0%,#DBE9E0 7.81%,#D4E8E6 66.67%,#D3E7E7 100%);--inline-actions-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(204,230,237,0) 0%,#CCE6ED 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,231,234,0) 0%,#CFE7EA 7.81%,#C7E5EF 66.67%,#C5E5F2 100%);--inline-actions-background-gradient-day-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,229,242,0) 0%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-background-gradient-day-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,231,234,0) 0%,rgba(196,229,242,0) 0.01%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C5E5F2 100%);--inline-actions-background-gradient-day-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,229,242,0) 0%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-compact-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,#D3E3DE 7.81%,#CCE2E5 66.67%,#C1E0EC 100%);--inline-actions-compact-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(198,225,233,0) 0%,#C6E1E9 7.81%,#C1E0EC 66.67%,#C0E0ED 100%);--inline-actions-compact-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(192,224,237,0) 0%,#C0E0ED 7.81%,#C0E0ED 66.67%,#C0E0ED 100%);--inline-actions-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,218,223,0) 0%,#EDDADF 7.81%,#EEDBDC 66.67%,#EFDBDB 100%);--inline-actions-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(239,220,218,0) 0%,#EFDCDA 7.81%,#F1DDD8 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-compact-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(233,214,218,0) 0%,#E9D6DA 7.81%,#EAD8D6 66.67%,#EDDAD1 100%);--inline-actions-compact-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(236,216,213,0) 0%,#ECD8D5 7.81%,#EDDAD1 66.67%,#EDDAD1 100%);--inline-actions-compact-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,218,209,0) 0%,#EDDAD1 7.81%,#EDDAD1 66.67%,#EDDAD1 100%);--inline-actions-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(218,214,238,0) 0%,#DAD6EE 7.81%,#D1D5EF 66.67%,#CFD5F0 100%);--inline-actions-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(199,213,242,0) 0%,#C7D5F2 7.81%,#C6D5F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,213,240,0) 0%,#CFD5F0 7.81%,#C7D5F2 66.67%,#C5D5F2 100%);--inline-actions-background-gradient-night-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,212,242,0) 0%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,213,240,0) 0%,rgba(196,212,242,0) 0.01%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,212,242,0) 0%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-compact-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(208,209,233,0) 0%,#D0D1E9 7.81%,#CAD0EB 66.67%,#C1D0ED 100%);--inline-actions-compact-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(200,208,236,0) 0%,#C8D0EC 7.81%,#C0CFED 66.67%,#C0CFED 100%);--inline-actions-compact-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(192,207,237,0) 0%,#C0CFED 7.81%,#C0CFED 66.67%,#C0CFED 100%)}`,d.A` :host{--background-color-dynamic-gradient-morning:linear-gradient(140.02deg,#464706 -2.33%,#3F2807 84.75%);--background-color-dynamic-gradient-day:linear-gradient(138.52deg,#464706 0.44%,#203A49 83.53%);--background-color-dynamic-gradient-sunset:linear-gradient(139.03deg,#371F42 5.05%,#4A2517 63.37%);--background-color-dynamic-gradient-night:linear-gradient(138.52deg,#512C2C -1.32%,#252C4E 85.77%);--inline-actions-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(81,74,24,0) 0%,#514A18 7.81%,#504718 66.67%,#504618 100%);--inline-actions-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(79,66,24,0) 0%,#4F4218 7.81%,#4F4118 66.67%,#4E3F18 100%);--inline-actions-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(79,69,24,0) 0%,#4F4518 7.81%,#4F4318 66.67%,#4F4118 100%);--inline-actions-background-gradient-morning-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(78,62,24,0) 0%,#4E3E18 7.81%,#4D3B18 66.67%,#4D3A19 100%);--inline-actions-background-gradient-morning-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(78,63,24,0) 0%,#4E3F18 7.81%,#4E3E18 66.67%,#4D3D18 100%);--inline-actions-background-gradient-morning-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(76,56,25,0) 0%,#4C3819 7.81%,#4C3819 66.67%,#4C3819 100%);--inline-actions-compact-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(81,74,24,0) 0.01%,#514A18 7.81%,#504618 66.67%,#4F4118 100%);--inline-actions-compact-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(79,69,24,0) 0.01%,#4F4518 7.81%,#4E4018 66.67%,#4E3E18 100%);--inline-actions-compact-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(78,63,24,0) 0.01%,#4E3F18 7.81%,#4D3D18 66.67%,#4D3919 100%);--inline-actions-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(73,81,43,0) 0.01%,#49512B 7.81%,#455031 66.67%,#424F36 100%);--inline-actions-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(62,77,63,0) 0.01%,#3E4D3F 7.81%,#3A4C45 66.67%,#394C47 100%);--inline-actions-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(63,77,60,0) 0.01%,#424E37 7.81%,#3E4D3D 66.67%,#3D4C41 100%);--inline-actions-background-gradient-day-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(55,76,74,0) 0.01%,#374C4A 7.81%,#354B4D 66.67%,#324A52 100%);--inline-actions-background-gradient-day-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(58,76,70,0) 0.01%,#3A4C46 7.81%,#384C48 66.67%,#354B4D 100%);--inline-actions-background-gradient-day-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(49,73,86,0) 0.01%,#314956 7.81%,#314957 66.67%,#314957 100%);--inline-actions-compact-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(70,80,48,0) 0.01%,#465030 7.81%,#414E38 66.67%,#3D4C40 100%);--inline-actions-compact-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(63,78,59,0) 0.01%,#3F4E3B 7.81%,#3C4C42 66.67%,#364B4C 100%);--inline-actions-compact-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(58,76,70,0) 0.01%,#3A4C46 7.81%,#344A50 66.67%,#314955 100%);--inline-actions-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(77,49,62,0) 0.01%,#4D313E 7.81%,#4F3239 66.67%,#503237 100%);--inline-actions-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(83,51,49,0) 0.01%,#533331 7.81%,#55332E 66.67%,#583428 100%);--inline-actions-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(82,51,51,0) 0.01%,#523234 7.81%,#523234 66.67%,#55332E 100%);--inline-actions-background-gradient-sunset-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(88,52,39,0) 0.01%,#583427 7.81%,#583427 66.67%,#583428 100%);--inline-actions-background-gradient-sunset-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(85,51,45,0) 0.01%,#55332D 7.81%,#583427 66.67%,#583427 100%);--inline-actions-background-gradient-sunset-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(88,52,39,0) 0.01%,#583427 7.81%,#583427 66.67%,#583427 100%);--inline-actions-compact-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(77,49,62,0) 0.01%,#4D313E 7.81%,#513235 66.67%,#55342D 100%);--inline-actions-compact-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(82,51,51,0) 0.01%,#523333 7.81%,#56342B 66.67%,#583428 100%);--inline-actions-compact-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(87,52,42,0) 0.01%,#57342A 7.81%,#583428 66.67%,#583428 100%);--inline-actions-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(80,59,69,0) 0.01%,#503B45 7.81%,#4C3B49 66.67%,#4A3B4B 100%);--inline-actions-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(70,59,77,0) 0.01%,#463B4D 7.81%,#403B51 66.67%,#403B51 100%);--inline-actions-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(73,59,75,0) 0.01%,#493B4B 7.81%,#453B4D 66.67%,#433B4F 100%);--inline-actions-background-gradient-night-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(63,59,83,0) 0.01%,#3F3B53 7.81%,#3C3B55 66.67%,#383B58 100%);--inline-actions-background-gradient-night-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(67,59,79,0) 0.01%,#433B4F 7.81%,#3E3B54 66.67%,#3D3B54 100%);--inline-actions-background-gradient-night-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(54,59,89,0) 0.01%,#363B59 7.81%,#353B5A 66.67%,#353B5A 100%);--inline-actions-compact-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(77,59,72,0) 0.01%,#4D3B48 7.81%,#483B4C 66.67%,#433B4F 100%);--inline-actions-compact-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(73,59,76,0) 0.01%,#493B4C 7.81%,#433B4F 66.67%,#3F3B52 100%);--inline-actions-compact-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(67,59,79,0) 0.01%,#433B4F 7.81%,#3B3B57 66.67%,#363B59 100%)}`));var w,_,T,F,S=a(69828),D=a(92011),A=a(38493),z=a(60815);class I extends D.L{constructor(){super(...arguments),this.cardActionMenuHandler=(t,e)=>{t.toggleCardActionMenu&&t.toggleCardActionMenu(t,e)},this.supportedCardSizeTopStoriesCarousel=["_1x_1y","_2x_1y","_3x_1y","_4x_1y"]}layoutChanged(t,e){this.isImageLayout=!1,this.isAttributionLayout=!1,e!==w.RibbonCarousel||this.supportedCardSizeTopStoriesCarousel.find(t=>t===this.cardSize)||(this.cardSize===S.uE._1x_2y?this.layout=w.Compact:this.layout=w.Normal),e!==w.Thumbnail&&e!==w.CompactThumbnail&&e!==w.RibbonCarousel&&e!==w.TallRightRail&&e!==w.RightRail||(this.isImageLayout=!0),e!==w.Normal&&e!==w.Thumbnail&&e!==w.CompactThumbnail&&e!==w.RibbonCarousel||(this.isAttributionLayout=!0)}backgroundChanged(t,e){t!==e&&(t&&this.$fastController.removeStyles(this.getBackgroundStyles(t)),this.$fastController.addStyles(this.getBackgroundStyles(e)))}getBackgroundStyles(t){switch(t){case T.InheritSection:return k;case T.Gradient:return $;default:return x}}getDynamicGradientColor(){if(!this.useGradientBackground)return"";this.$fastController.addStyles(C);const t=(new Date).getHours();let e;return e=t>=6&&t<12?"dynamic-gradient-morning":t>=12&&t<17?"dynamic-gradient-day":t>=17&&t<22?"dynamic-gradient-sunset":"dynamic-gradient-night",e}connectedCallback(){super.connectedCallback()}disconnectedCallback(){super.disconnectedCallback()}scrollToPrevious(){if(this.enableFeeds2Carousel){const t=this.getCurrentScrollIndex(),e=t-2>0?t-2:0;this.horizontalScroll.scrollToPosition(this.scrollStops[e],this.horizontalScroll.scrollContainer.scrollLeft)}else this.horizontalScroll.scrollToPrevious()}scrollToNext(){if(this.enableFeeds2Carousel){const{scrollItems:t,scrollContainer:{scrollLeft:e}}=this.horizontalScroll,a=this.getCurrentScrollIndex(),i=a+2<t.length-1?a+2:t.length-1;this.horizontalScroll.scrollToPosition(this.scrollStops[i],e)}else this.horizontalScroll.scrollToNext()}getCurrentScrollIndex(){const{scrollContainer:t}=this.horizontalScroll,e=t.scrollLeft;return!this.scrollStops&&this.saveScrollStops(),this.scrollStops.findIndex(t=>Math.abs(t)>=Math.abs(e))}saveScrollStops(){const{scrollItems:t}=this.horizontalScroll;this.scrollStops=t.map((t,e)=>280*e),this.scrollStops.push(280*(t.length-1)+272)}}(0,i.Cg)([(0,A.CF)({attribute:"is-anaheim-design",mode:"boolean"})],I.prototype,"isAnaheimDesign",void 0),(0,i.Cg)([(0,A.CF)({attribute:"is-anaheim-infopane",mode:"boolean"})],I.prototype,"isAnaheimInfopane",void 0),(0,i.Cg)([(0,A.CF)({attribute:"disable-inline-action",mode:"boolean"})],I.prototype,"disableTopStoriesInlineAction",void 0),(0,i.Cg)([(0,A.CF)({attribute:"card-heading"})],I.prototype,"cardHeading",void 0),(0,i.Cg)([(0,A.CF)({attribute:"card-heading-link"})],I.prototype,"cardHeadingLink",void 0),(0,i.Cg)([(0,A.CF)({attribute:"card-tooltip"})],I.prototype,"tooltip",void 0),(0,i.Cg)([(0,A.CF)({attribute:"feeds-2-carousel",mode:"boolean"})],I.prototype,"enableFeeds2Carousel",void 0),(0,i.Cg)([(0,A.CF)({attribute:"prong2-dynamic-feed",mode:"boolean"})],I.prototype,"isDynamicFeed",void 0),(0,i.Cg)([(0,A.CF)({attribute:"prong2-dynamic-gradient-background",mode:"boolean"})],I.prototype,"useGradientBackground",void 0),(0,i.Cg)([A.CF],I.prototype,"target",void 0),(0,i.Cg)([z.sH],I.prototype,"cardData",void 0),(0,i.Cg)([z.sH],I.prototype,"headingTelemetryTag",void 0),(0,i.Cg)([z.sH],I.prototype,"flipperNextTelemetryTag",void 0),(0,i.Cg)([z.sH],I.prototype,"fliperPreviousTelemetryTag",void 0),(0,i.Cg)([z.sH],I.prototype,"cardVersionTelemetryTag",void 0),(0,i.Cg)([z.sH],I.prototype,"subCardTelemetryTag",void 0),(0,i.Cg)([z.sH],I.prototype,"isSpotlightUX",void 0),(0,i.Cg)([z.sH],I.prototype,"spotlightBreakingNewsTagString",void 0),(0,i.Cg)([(0,A.CF)({attribute:"card-size"})],I.prototype,"cardSize",void 0),(0,i.Cg)([A.CF],I.prototype,"layout",void 0),(0,i.Cg)([A.CF],I.prototype,"background",void 0),(_=w||(w={})).Compact="compact",_.CompactThumbnail="compactthumb",_.TallRightRail="tallrightrail",_.RightRail="rightrail",_.Normal="normal",_.Stacked="stacked",_.Thumbnail="thumb",_.RibbonCarousel="ribbonCarousel",(F=T||(T={})).Normal="normal",F.Gradient="gradient",F.InheritSection="inheritSection";var E=a(44776),B=a(89757),M=a(69259),R=a(60402),L=a(68835),N=a(44978),O=a(58759),P=a.n(O),H=a(30576),j=a.n(H),V=a(33307),U=a(33744),W=a(54694),G=a(9960);const Z={[w.Compact]:3,[w.CompactThumbnail]:3,[w.RightRail]:3,[w.TallRightRail]:4,[w.Normal]:6,[w.Stacked]:6,[w.Thumbnail]:6},J={[S.uE._1x_2y]:[52,52],[S.uE._1x_3y]:[76,76],[S.uE._2x_2y]:[59,59],[S.uE._3x_2y]:[72,72]},X=B.qy`
${(0,M.z)(t=>t.enableRichSocialReaction,B.qy`<span class="divider"></span>`)}<fluent-button class="actions-button" aria-expanded="false" aria-label="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.seeMore}" role="button" title="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.seeMore}" @click=${(t,e)=>e.parent.cardActionMenuHandler&&e.parent.cardActionMenuHandler(t,e.event)} @keypress=${(t,e)=>e.parent.cardActionMenuHandler&&e.parent.cardActionMenuHandler(t,e.event)} data-t="${t=>t.telemetryContext?.seeMore?.getMetadataTag()}">${t=>B.qy`${B.qy.partial(V.A)}`}</fluent-button>`,Q=B.qy`<div id="inline-actions" class="inline-actions">${(0,M.z)(t=>t.enableRichSocialReaction,(0,E.nj)({theme:"topStories"}))} ${(0,M.z)(t=>t.cardActionStatus&N.J.enabled,X)}</div>`,q=B.qy`<msft-article role="listitem" href=${t=>t.destinationUrl} title=${t=>t.disableCardTitleTooltip&&!t.disableTitleOnArticleCardOnly?"":t.title} target=${t=>t.openLinksInNewTab||t.openArticleInNewTab?"_blank":t.defaultAnchorTarget||"_self"} data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}" :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()} :handleContentCardClickOverride=${t=>t.handleContentCardClickOverride} class=${(t,e)=>`${t.isWebContent?"crawled-content":""} ${t.enableRichSocialReaction?"social-reaction-enabled":""} ${t.isWebContent?"stacked-fromweb":""} ${t.enableFilledIconOnHover?"filled-icon-hover":""}`}>${(t,e)=>{return(a=e.parent.layout)===w.Normal||a===w.Stacked||a===w.CompactThumbnail||a===w.Thumbnail||a===w.RibbonCarousel?B.qy`<span slot="attribution">${(0,M.z)(t=>t.providerData&&t.providerData.logoImage,B.qy`<img slot="image" class="attribution-provider-logo" src="${t=>t.providerData.logoImage}" alt="${t=>t.providerData.name}" />`)}</span>`:B.qy`<msft-attribution slot="attribution" class="${t=>t.isProviderIconClickable?"attribution-provider-clickable":""}">${(0,M.z)(t=>t.providerData&&t.providerData.logoImage,B.qy` ${(0,M.z)(t=>t.isProviderIconClickable&&t.providerData.profileId,B.qy`<a class="attribution-icon-clickable" tabindex="-1" title="${t=>t.providerData.name}" href=${t=>Y(t.providerData.profileId)} target="_blank" data-t="${t=>t.telemetryContext?.clickableProviderIcon?.getMetadataTag()}"><div style="display: inline-flex;align-items: center"><img slot="image" tabindex="0" class="attribution-provider-logo" src="${t=>t.providerData.logoImage}" alt="${t=>t.providerData.name}" /><span class="attribution-provider-name attribution-provider-logo-available" tabindex="0">${t=>t.providerData.name}</span><span class="attribution-published-time">·</span><span>${t=>t.publishedDateTime}</span></div></a>`)} ${(0,M.z)(t=>!t.isProviderIconClickable||!t.providerData.profileId,B.qy`<img slot="image" class="attribution-provider-logo" src="${t=>t.providerData.logoImage}" alt="${t=>t.providerData.name}" /></a>`)} `)} ${(0,M.z)(t=>t.isProviderIconClickable&&t.providerData&&!t.providerData.logoImage,B.qy` ${(0,M.z)(t=>t.providerData.name&&t.providerData.profileId,B.qy`<a class="attribution-icon-clickable" tabindex="-1" title="${t=>t.providerData.name}" href=${t=>Y(t.providerData.profileId)} target="_blank" data-t="${t=>t.telemetryContext?.clickableProviderIcon?.getMetadataTag()}"><div style="display: inline-flex;align-items: center"><span class="attribution-provider-name" tabindex="0">${t=>t.providerData.name}</span>${(0,M.z)(t=>t.publishedDateTime,B.qy`<span class="attribution-published-time">·</span><span>${t=>t.publishedDateTime}</span>`)}</div></a>`)} `)} ${(0,M.z)(t=>!t.isProviderIconClickable||!t.providerData.profileId,B.qy`<span class="attribution-provider-not-clickable">${(0,M.z)(t=>t.providerData&&t.providerData.name,B.qy`<span style="unicode-bidi:embed">${t=>t.providerData.name}</span>`)} ${(0,M.z)(t=>t.providerData&&t.providerData.name&&t.publishedDateTime,B.qy` · `)} ${(0,M.z)(t=>t.publishedDateTime,B.qy`${t=>t.publishedDateTime}`)}</span>`)}</msft-attribution>`;var a}}<div slot="start-action" style="gap:0">${(0,M.z)((t,e)=>!e.parent.disableTopStoriesInlineAction,Q)}</div>${(0,M.z)((t,e)=>e.parent.isDynamicFeed&&e.parent.isSpotlightUX&&0===e.index,B.qy`<fluent-badge class="ts-breaking-news-tag" appearance="accent">${(t,e)=>e.parent.spotlightBreakingNewsTagString}</fluent-badge>`)} ${t=>t.title} ${(0,M.z)((t,e)=>t.isWebContent,B.qy`<span slot="abstract">${t=>t.crawledContentLabel}</span>`)} ${(0,M.z)((t,e)=>!(t.isWebContent&&e.parent.cardSize!==S.uE._3x_2y)&&(e.parent.layout===w.Thumbnail||e.parent.layout===w.Normal)&&t.abstract,B.qy`<p slot="abstract">${t=>t.abstract}</p>`)} ${(0,M.z)((t,e)=>t.imageData&&e.parent.isImageLayout,B.qy` ${(t,e)=>function(t,e,a,i){const{articleCardBackgroundColor:n,imageData:r}=t;let o=J[e]||[72,72];a===w.RightRail&&(o=[62,62]);a===w.RibbonCarousel&&(o=i?[68,80]:[60,60]);const s=n&&n.find(t=>t.isDarkMode===(0,G.ud)())?.hexColor,l=(0,W.oQ)(r.source,{width:o[0],height:o[1],enableDpiScaling:!1,quality:90});return B.qy`<div slot="image" class="image"><img style="background: ${s}" height=${o[1]}, width=${o[0]}, alt="${r.altText}" src="${l}" /></div>`}(t,e.parent.cardSize,e.parent.layout,e.parent.enableFeeds2Carousel)} `)} ${(0,M.z)((t,e)=>e.parent.isAttributionLayout,B.qy`<msft-attribution slot="start-action"><span>${(0,M.z)(t=>t.providerData&&t.providerData.name,B.qy`<span style="unicode-bidi:embed">${t=>t.providerData.name}</span>`)} ${(0,M.z)((t,e)=>t.providerData&&t.providerData.name&&t.isWebContent&&e.parent.cardSize===S.uE._3x_2y,B.qy` · `)} ${(0,M.z)((t,e)=>t.isWebContent&&e.parent.cardSize===S.uE._3x_2y,B.qy`${t=>t.crawledContentLabel}`)} ${(0,M.z)((t,e)=>(t.providerData&&t.providerData.name||t.isWebContent&&e.parent.cardSize===S.uE._3x_2y)&&t.publishedDateTime,B.qy` · `)} ${(0,M.z)(t=>t.publishedDateTime,B.qy`${t=>t.publishedDateTime}`)}</span></msft-attribution>`)}</msft-article>`;function Y(t){return`https://www.msn.com/${U.T3.CurrentMarket}/community/channel/${t}`}const K=B.qy`<fluent-horizontal-scroll aria-hidden="false" class="horizontal-scroll" speed="1500" easing="ease-in-out" ${(0,R.K)("horizontalScroll")}><fluent-flipper slot="previous-flipper" direction="previous" part="flipper-previous" class="previous" @click="${t=>t.scrollToPrevious()}" data-t="${t=>t.fliperPreviousTelemetryTag}">${(0,M.z)(t=>"rtl"===document.dir&&!t.enableFeeds2Carousel,B.qy`<svg slot="previous" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"></path></svg>`)} ${(0,M.z)(t=>t.enableFeeds2Carousel,B.qy`<div slot="previous">${t=>"rtl"===document.dir?B.qy`${B.qy.partial(j())}`:B.qy`${B.qy.partial(P())}`}</div>`)}</fluent-flipper><fluent-flipper slot="next-flipper" direction="next" part="flipper-next" class="next" @click="${t=>t.scrollToNext()}" data-t="${t=>t.flipperNextTelemetryTag}">${(0,M.z)(t=>"rtl"===document.dir&&!t.enableFeeds2Carousel,B.qy`<svg slot="next" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"></path></svg>`)} ${(0,M.z)(t=>t.enableFeeds2Carousel,B.qy`<div slot="next">${t=>"rtl"===document.dir?B.qy`${B.qy.partial(P())}`:B.qy`${B.qy.partial(j())}`}</div>`)}</fluent-flipper>${(0,L.ux)(t=>t.cardData,q)}</fluent-horizontal-scroll>`,tt=B.qy`<div data-t="${t=>t.cardVersionTelemetryTag}" style="display: flex; width: 100%;" class="${t=>t.isDynamicFeed&&t.isSpotlightUX?"spotlight-flash-bg":""}" animation-name="${t=>t.isDynamicFeed?"spotlight-ts-bg-animation, none":""}"><div :classList="inner-content ${t=>t.getDynamicGradientColor()}" data-t="${t=>t.subCardTelemetryTag}">${(0,M.z)(t=>t.cardHeading,B.qy`<div :classList="heading-container ${t=>t.isAnaheimInfopane?"anaheim-infopane":""}">${t=>!!t.cardHeadingLink?B.qy`<a class="heading heading-link" href=${t=>t.cardHeadingLink} target=${t=>t.target} data-t="${t=>t.headingTelemetryTag}">${(0,M.z)(t=>t.enableFeeds2Carousel,B.qy`${B.qy.partial('<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2.5" y="4.33" width="12.67" height="8.67" rx="2" fill="url(#paint0_linear_1770_321358)"/><rect x="2.5" y="4.33" width="12.67" height="8.67" rx="2" fill="url(#paint1_linear_1770_321358)" fill-opacity=".5"/><path d="M.5 4.33c0-1.1.9-2 2-2h8.73a2 2 0 0 1 2 2v7.49c0 1.12.6 1.18.6 1.18H2.5a2 2 0 0 1-2-2V4.33Z" fill="url(#paint2_linear_1770_321358)"/><rect x="7.83" y="6.33" width="4" height="1.33" rx=".67" fill="#EDFCFF"/><rect x="7.83" y="9" width="4" height="2" rx="1" fill="#EDFCFF"/><rect x="1.83" y="6.33" width="4.67" height="4.67" rx="1" fill="#EDFCFF"/><rect x="1.83" y="3.67" width="10" height="1.33" rx=".67" fill="#EDFCFF"/><defs><linearGradient id="paint0_linear_1770_321358" x1="6.5" y1="4.62" x2="13.94" y2="14.21" gradientUnits="userSpaceOnUse"><stop stop-color="#007BBC"/><stop offset="1" stop-color="#155AA8"/></linearGradient><linearGradient id="paint1_linear_1770_321358" x1="13.39" y1="10.09" x2="15.21" y2="9.98" gradientUnits="userSpaceOnUse"><stop/><stop offset=".27" stop-opacity="0"/></linearGradient><linearGradient id="paint2_linear_1770_321358" x1="13.17" y1="13" x2="-.64" y2="3.74" gradientUnits="userSpaceOnUse"><stop stop-color="#358ADC"/><stop offset="1" stop-color="#20B2C6"/></linearGradient></defs></svg>')}`)} ${t=>t.cardHeading}</a>`:B.qy`<h3 class="heading">${t=>t.cardHeading}</h3>`} ${(0,M.z)(t=>t.tooltip,B.qy`<div class="heading-icon-container" role="tooltip" tabindex="0" aria-describedby="#tooltip">${B.qy.partial('<svg viewBox="0 0 12 12" width="14" height="13" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 0H8.5C8.77614 0 9 0.223858 9 0.5V3H10C11.1046 3 12 3.89543 12 5V10C12 11.1046 11.1046 12 10 12H2C0.89543 12 0 11.1046 0 10V5C0 3.89543 0.895431 3 2 3H3V0.5C3 0.223858 3.22386 0 3.5 0ZM8 3V1H4V3H8ZM2 4C1.44772 4 1 4.44772 1 5V10C1 10.5523 1.44772 11 2 11H10C10.5523 11 11 10.5523 11 10V5C11 4.44772 10.5523 4 10 4H2Z"/></svg>')}<span id="tooltip" class="icon-tooltip">${t=>t.tooltip}</span></div>`)}</div><slot name="ngbutton"></slot><slot name="ngmenu"></slot>`)} ${(0,M.z)(t=>t.layout===w.RibbonCarousel,K)} ${(0,M.z)(t=>!(t.layout===w.RibbonCarousel),B.qy`<div role="list" style="display: contents;">${(0,L.ux)(t=>Z[t.layout]?t.cardData.slice(0,Z[t.layout]):t.cardData,q,{positioning:!0})}</div>${(0,M.z)(t=>t.isAnaheimInfopane,B.qy`<div class="anaheim-infopane-bottom-padding"></div>`)} `)}</div></div>`;let et=class extends I{};et=(0,i.Cg)([(0,D.E)({name:"msn-top-stories",template:tt,styles:y})],et);const at=B.qy`
<fluent-card style="grid-area:${t=>t.gridArea}; ${t=>t.isDynamicFeed?"border-radius: 8px":""}">
    <msn-top-stories
        class=${t=>t.isAnaheimDesign?"infopane-anaheim-design":""}
        card-size=${t=>t.cardSize}
        card-heading=${t=>t.topStoriesHeadingText}
        card-tooltip=${t=>t.tooltip}
        card-heading-link=${t=>t.headingLink}
        is-anaheim-design=${t=>t.isAnaheimDesign}
        is-anaheim-infopane=${t=>t.isAnaheimInfopane}
        disable-inline-action=${t=>t.disableTopStoriesInlineAction}
        feeds-2-carousel=${t=>t.enableFeeds2TopStoriesCarousel}
        prong2-dynamic-feed=${t=>t.isDynamicFeed}
        prong2-dynamic-gradient-background=${t=>t.useGradientBackground}
        layout=${t=>t.cardLayout}
        background=${t=>t.cardBackground}
        target=${t=>t.openLinksInNewTab?"_blank":"_self"}
        :cardData=${t=>t.listCardData}
        :headingTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.headingClick&&t.telemetryContext.headingClick.getMetadataTag()}
        :flipperNextTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.flipperNextClick&&t.telemetryContext.flipperNextClick.getMetadataTag()}
        :fliperPreviousTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.flipperPreviousClick&&t.telemetryContext.flipperPreviousClick.getMetadataTag()}
        :cardVersionTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.cardVersion&&t.telemetryContext.cardVersion.getMetadataTag()}
        :subCardTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.subCard&&t.telemetryContext.subCard.getMetadataTag()}
        :isSpotlightUX=${t=>t.isSpotlightUX}
        :spotlightBreakingNewsTagString=${t=>t.spotlightBreakingNewsTagString}
        data-t="${t=>t.telemetryContext?.topStoriesCard?.getMetadataTag()}"
    >
    </msn-top-stories>
</fluent-card>
`},96245(t,e,a){"use strict";a.d(e,{t(){return l}});var i=a(56525),n=a(87906),r=a(40450),o=a(98794),s=a(3006);const l={getFeedDataForCard(t){return function(t){try{const{cardMetadata:e,configOptions:a,parentTelemetryObject:i,hasLoadedCallback:s}=t,l=a&&a,c={id:"travelDestination",childTemplateType:"travel-destination-card",configInfo:l,mapperArgs:t,parentTelemetryObject:i,hasLoadedCallback:s};try{return(0,o.bw)({id:"travelDestination",experienceType:l?.configRef?.experienceType,mapperArgs:t},c,null,!0)}catch(e){(0,n.vV)(r.OV,`Error in populating layouts and position telemetry = ${JSON.stringify(t)}`)}}catch(e){(0,n.vV)(r.OV,`Error in feed layout mapperargs = ${JSON.stringify(t)}`)}return(0,s.wc)()}(t)},viewTemplate:i.T}},56525(t,e,a){"use strict";a.d(e,{T(){return r}});var i=a(89757),n=a(94172);const r=i.qy`
${t=>(0,n.yN)(t.configInfo,{includeTelemetryTag:!1,properties:{parentTelemetry:t.parentTelemetryObject,wpoMetadata:t.wpoMetadata,cardSize:t.cardSize,mapperArgs:t.mapperArgs,refreshSDCardSection:t.mapperArgs?.refreshSDCardSection,goToPersonalizeSettingsCallback:t.mapperArgs?.goToPersonalizeSettingsCallback,hasLoadedCallback:t.hasLoadedCallback},attributes:{style:`grid-area:${t.gridArea};contain: unset;content-visibility: visible;`,class:`${t.cardSize} travel-destination-card-container`}})}
`},95583(t,e,a){"use strict";a.d(e,{O(){return r}});var i=a(13162),n=a(98794);const r={getFeedDataForCard(t){return function(t){const{cardMetadata:e,parentTelemetryObject:a,configOptions:i}=t,r=i&&(i.childExperienceReferencesWC&&(i.childExperienceReferencesWC.videoCard||i.childExperienceReferencesWC.videoCardWC)||i.childExperienceReferences&&(i.childExperienceReferences.videoCard||i.childExperienceReferences.videoCardWC)),o=i&&(i.childExperienceReferencesWC&&i.childExperienceReferencesWC.socialBarWC||i.childExperienceReferences&&i.childExperienceReferences.socialBarWC),s={childTemplateType:"video-card",contentId:e?.cardContent?.id,id:e?.cardContent?.id??"videoCard",parentTelemetryObject:a,videoCardConfigInfo:r,socialBarWCConfigInfo:o,videoCardProps:{posterUrl:Array.isArray(e?.cardContent?.images)?e.cardContent.images[0]?.url:void 0}};return(0,n.bw)({id:"video-card",experienceType:r?.configRef?.experienceType,mapperArgs:t},s)}(t)},viewTemplate:i.Q}},13162(t,e,a){"use strict";a.d(e,{Q(){return R}});var i=a(56911),n=a(92011);const r=a(59669).A` msft-article-card.mobile,msft-article-card.mobile *{-webkit-tap-highlight-color:transparent;outline:none;-ms-touch-action:manipulation;touch-action:manipulation}.card-button{border-radius:100%}msft-article.vertical-gradient::part(text){margin-bottom:0px;height:148px;padding:12px calc(var(--msft-article-padding) * 1px) 16px}@media (forced-colors:active){.card-button{background:none}msn-social-bar::part(button-bg),msn-social-bar::part(reactions-count-button),msn-social-bar::part(comments-count-button){color:buttontext;background-color:buttonface}msn-social-bar::part(button-bg):hover,msn-social-bar::part(button-bg):focus-visible,msn-social-bar::part(reactions-count-button):hover,msn-social-bar::part(reactions-count-button):focus-visible,msn-social-bar::part(comments-count-button):hover,msn-social-bar::part(comments-count-button):focus-visible{color:buttonface;background-color:highlight}}msft-article span.title_1x_2y,msft-article span.title_2x_2y{font-size:20px}msft-article.no-image::part(heading){font-size:var(--msft-article-heading-font-size,20px);line-height:var(--msft-article-heading-line-height,28px)}msft-article-card[size="_1x_2y"] msft-article.no-image msft-attribution{margin-bottom:18px}msft-article.long-gradient::part(gradient){top:-55px}msft-article-card[size="_1x_2y"] .video-card-embed{position:relative}msft-article-card[size="_2x_2y"] .video-card-embed{position:relative}msft-article-card[size="_1x_2y"] msft-article.videocard .video-card-embed .hover-mask{display:none;width:100%;height:79px;background:var(--fill-color);position:absolute;bottom:0px;z-index:10}msft-article-card[size="_1x_2y"] msft-article.videocard.videocard-hover .video-card-embed .hover-mask{display:block}msft-article-card msft-article.hide-non-image::part(text),msft-article-card msft-article.hide-non-image::part(hide-story-wrapper){display:none}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient::part(heading){line-height:var(--heading-line-height,28px)}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(heading){margin-bottom:40px}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(gradient){background:linear-gradient( 180deg,transparent 0%,var(--gradient-mid-color) 62.5%,var(--gradient-color) 100% );width:100%}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(text){height:auto;width:100%}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(attribution){display:flex;align-self:end}msft-article-card[size="_2x_2y"].contentCard msft-attribution{margin-bottom:8px}msft-article div.infopane-like-end-actions{display:flex}.video-play-button-container{border-radius:50%;display:block;height:40px;left:50%;opacity:1;padding:0;position:absolute;top:50%;transform:translate(-50%,-50%);transition:all 0.4s ease 0s;width:40px}.video-play-button{align-items:center;display:flex;height:100%;justify-content:center;width:100%}.video-experience-placeholder{background:0px 0px rgba(0,0,0,0.6);display:block;left:0;position:relative;top:0;z-index:1}msft-article-card[size="_2x_2y"].no-gradient .video-experience-placeholder{height:304px}.video-experience-placeholder.hidden{z-index:0;opacity:0}.video-experience-container{position:absolute;right:0px;top:0px;z-index:0}msft-article-card.mobile msft-article::part(image){width:100%;opacity:1}msft-article-card.mobile msft-article::part(text){margin-bottom:-6px;padding-top:0}msft-article-card.mobile .infopane-like-end-actions{border-radius:50%;border:none;background-color:transparent;fill:var(--neutral-foreground-rest);margin-top:0px;margin-inline:4px -5px}msft-article-card.mobile .infopane-like-start-actions{height:32px;margin-inline-start:-8px}msft-article-card.mobile msft-article::part(heading){fill:currentcolor;display:-webkit-box;outline:0px;overflow:hidden;text-decoration:none;-webkit-line-clamp:3;-webkit-box-orient:vertical;font-weight:600;height:72px;margin-bottom:10px}msft-article-card.mobile msft-article .heading-title-content{font-size:18px !important;line-height:24px !important}msft-article-card.mobile msft-article .video-experience-placeholder{height:170px;overflow:hidden}msft-article-card.mobile msft-article msft-attribution{margin-bottom:8px}`;var o=a(11803),s=a(62679),l=a(69828),c=a(35177),d=a(44776),p=a(26330),g=a(47517),u=a(89757),h=a(69259),b=a(68835),m=a(9960),f=a(44978),v=a(94172);const y=(t,e)=>{if(globalThis.videoCards||(globalThis.videoCards={}),globalThis.videoCards[t.id])return globalThis.videoCards[t.id];{const a=`${t.cardSize} vertical_gradient`,i=(0,v.yN)(t.videoCardConfigInfo,{memoize:!1,properties:{id:t.id,context:{cardData:t,customStyleClass:a,eventsCallback:e.parent.eventsCallback,previewEndCallback:e.parent.previewEndCallback}}});return globalThis.videoCards[t.id]=i,i}},x=t=>{let e;return e=t.disableColorSampling?(0,m.ud)()?"#333":"#FFF":t.enableFeedSuperCardsSingleColor?(0,m.ud)()||(0,m.r0)(t)?"#292929":"#FFFFFF":t.articleCardBackgroundColor?.find(e=>e.isDarkMode===((0,m.ud)()||(0,m.r0)(t)))?.hexColor,e},$=u.qy`<div><span class="video-play-button-container"><svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" slot="icon"><g filter="url(#filter0_b_1234_35012)"><circle cx="20" cy="19.9991" r="19" fill="url(#paint0_linear_1234_35012)" /><circle cx="20" cy="19.9991" r="19.5" stroke="url(#paint1_linear_1234_35012)" /></g><path d="M27.2221 18.6837C28.2586 19.2535 28.2586 20.7429 27.2221 21.3127L17.2226 26.8096C16.2229 27.3591 15 26.6359 15 25.4951L15 14.5013C15 13.3605 16.2229 12.6373 17.2226 13.1868L27.2221 18.6837Z" fill="white" /><defs><filter id="filter0_b_1234_35012" x="-10" y="-10.0009" width="60" height="60" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix" /><feGaussianBlur in="BackgroundImage" stdDeviation="5" /><feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_1234_35012" /><feBlend mode="normal" in="SourceGraphic" in2="effect1_backgroundBlur_1234_35012" result="shape" /></filter><linearGradient id="paint0_linear_1234_35012" x1="1" y1="0.999146" x2="39" y2="38.9991" gradientUnits="userSpaceOnUse"><stop stop-opacity="0.5" /><stop offset="1" stop-opacity="0.7" /></linearGradient><linearGradient id="paint1_linear_1234_35012" x1="20" y1="0.999146" x2="20" y2="38.9991" gradientUnits="userSpaceOnUse"><stop stop-color="white" stop-opacity="0.4" /><stop offset="1" stop-color="white" stop-opacity="0.2" /></linearGradient></defs></svg></span><img alt="${t=>t.imageData&&t.imageData.altText}" src="${t=>t.imageData&&t.imageData.source}" height="${t=>t.imageData&&k(t)}" width="${t=>t.imageData&&t.imageData.imageWidth}" @load="${(t,e)=>{t.imageData&&t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(3,o.j.image),e.parent.setPlaceholderRendered()}}" @error="${(t,e)=>{t.imageData&&t.imageData.source&&e.parent.error(t.imageData.source)}}" /></div>`,k=t=>{if(t.useMobile){const{imageHeight:e}=t.displaySettings;return document.body.style.setProperty("--displaySettingsImageHeight",`${e}px`),e}return t.imageData.imageHeight},C=u.qy`<div slot="image" class="video-card-embed" style="height: ${t=>t.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;"><div class="hover-mask"></div><div class="video-experience-placeholder ${(t,e)=>e.parent.playerPlaying?"hidden":""}" style="${t=>`height: ${k(t)}px`}">${$}</div><div class="video-experience-container">${(0,h.z)((t,e)=>e.parent.placeholderRendered,y)}</div></div>`,w=u.qy`<fluent-card class="${t=>t.cardSize}">${(t,e)=>y(t,e)}</fluent-card>`,_=u.qy`<style>msft-article-card[size$="x_2y"] msft-article::part(heading):after { top: calc(100% - ${t=>t.fixedCardHeight?304:292+(t.layoutGap||12)}px - 8px) !important;
} msft-article::part(text) { margin-bottom: -8px;
} msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) { top: -29px; bottom: ${t=>t.fixedCardHeight?78:66+(t.layoutGap||12)}px;
} msft-article.no-image::part(actions) { bottom: calc(var(--msft-article-padding) * 1px - 8px);
}</style><msft-article-card size="${t=>t.cardSize}" card-fill-color="${t=>x(t)}" class="contentCard no-gradient ${t=>t.useMobile?"mobile":""}" data-badge-type="${t=>t.badge&&t.badge.type}" style="${t=>(t=>t.useMobile?`--card-height:${t.displaySettings.cardHeight}px;--card-width:${t.displaySettings.cardWidth}px`:"")(t)}"><msft-article id="contentcard_${t=>t.id}" href=${t=>t.destinationUrl} target="_blank" title=${t=>t.disableCardTitleTooltip?"":t.title} style="--heading-max-lines: 2;" class="vertical-gradient ${(t,e)=>e.parent.useVideoTemplate?"videocard":""} ${(t,e)=>e.parent.isHoverVideo?"videocard-hover":""} ${(t,e)=>e.parent.useVideoTemplate&&!e.parent.isHoverVideo?"hide-non-image":""}" data-t="${t=>t.telemetryContext&&t.telemetryContext.contentCard&&t.telemetryContext.contentCard.getMetadataTag()}" :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()} @mouseover="${(t,e)=>e.parent.mouseenterHandler&&e.parent.mouseenterHandler(e.event)}" @mouseleave="${(t,e)=>e.parent.mouseleaveHandler&&e.parent.mouseleaveHandler(e.event)}" @click="${(t,e)=>e.parent.clickHandler(t,e)}">${(0,h.z)(t=>t.providerData,u.qy`<msft-attribution slot="${t=>t.isProviderInFooter?"start-actions":"attribution"}" style="${t=>t.isProviderInFooter?"gap:0":""}">${(0,s.mt)()}<div class="attribution_container_${t=>t.id}" id="attribution_container"><div class="attribution_Content_${t=>t.id}" style="${t=>"rtl"===t.dir?"right":"left"}:0px;">${(0,h.z)(t=>t.providerData&&t.providerData.name&&!t.isProviderIconClickable,u.qy`<span style="unicode-bidi: embed;">${t=>t.providerData.name}</span>`)} ${(0,h.z)(t=>t.providerData&&t.providerData.name&&t.publishedDateTime,u.qy` · `)} ${(0,h.z)(t=>t.publishedDateTime,u.qy`<span style="unicode-bidi: embed;">${t=>t.publishedDateTime}</span>`)} ${(0,h.z)(t=>t.isWebContent&&t.crawledContentLabel,u.qy` · `)} ${(0,h.z)(t=>t.isWebContent&&t.crawledContentLabel,u.qy`${t=>t.crawledContentLabel}`)}</div></div></msft-attribution>`)} ${(0,h.z)((t,e)=>!e.parent.isPreviewable(t.metadata),u.qy`<div slot="image" class="video-card-embed" style="height: ${t=>t.imageData&&t.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;">${$}</div>`)} ${(0,h.z)((t,e)=>e.parent.isPreviewable(t.metadata),C)} ${(0,h.z)(t=>t.feedFontSize,u.qy` ${(0,h.z)(t=>(t.cardSize===l.uE._1x_2y||t.cardSize===l.uE._1x_1y)&&t.imageData,u.qy`<span class="heading-title-content" style="font-size: ${t=>t.feedFontSize}px; ${t=>t.headingLineHeight?`line-height: ${t.headingLineHeight}px`:""}">${t=>t.title}</span>`)} ${(0,h.z)(t=>t.cardSize===l.uE._2x_2y,u.qy`<span style="font-size: ${t=>t.twoColumnFeedFontSize||t.largeFeedFontSize||t.feedFontSize}px; ${t=>t.twoColumnHeadingLineHeight?`line-height: ${t.twoColumnHeadingLineHeight}px`:""}">${t=>t.title}</span>`)} ${(0,h.z)(t=>(t.cardSize===l.uE._1x_2y||t.cardSize===l.uE._1x_1y)&&!t.imageData,u.qy`<span style="font-size: ${t=>t.noImageFeedFontSize||t.feedFontSize}px;">${t=>t.title}</span>`)} `)} ${(0,h.z)(t=>!t.feedFontSize,u.qy` ${(0,h.z)(t=>!t.useLargeFontSize,u.qy`${t=>t.title}`)} ${(0,h.z)(t=>t.useLargeFontSize,u.qy`<span class="title${t=>t.cardSize}">${t=>t.title}</span>`)} `)} ${(0,h.z)(t=>t.badge&&t.cardSize!==l.uE._1x_1y,t=>(0,c.w)(t.badge,!0,!1))}<div slot="start-action" class="infopane-like-start-actions">${(0,h.z)(t=>t.providerData&&t.enableInfopaneLike2cCard&&t.cardSize===l.uE._2x_2y,s.QQ)} ${(0,h.z)(t=>(!t.enableInfopaneLike2cCard||t.cardSize!==l.uE._2x_2y)&&(!t.isAnaheimDesign||t.enableRichSocialReaction),u.qy` ${(0,h.z)(t=>t.enableRichSocialReaction&&!t.isLauncher,t=>(0,d.nj)({theme:t.useMobile&&!t.isMsnMobile&&"superappDefaultNewFeed",hideComments:t.useMobile&&!t.isMsnMobile}))} ${(0,h.z)(t=>t.cardActionStatus&f.J.enabled&&!t.enableRichSocialReaction,u.qy` ${d.LW} ${(0,h.z)(t=>!(t.cardActionStatus&f.J.showMore),d.tB)} `)} `)}</div><div slot="end-action" class="infopane-like-end-actions">${(0,h.z)(t=>t.enableRichSocialReaction&&t.enableInfopaneLike2cCard&&t.cardSize===l.uE._2x_2y,(0,d.nj)({}))} ${(0,h.z)(t=>t.cardActionStatus&f.J.enabled,u.qy` ${(0,h.z)(t=>t.enableRichSocialReaction,u.qy` ${(0,h.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&f.J.showMore,d.LW)} ${(0,h.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&f.J.showFewer,d.tB)} `)} ${(0,h.z)(t=>!1!==t.enableWCCardAction&&!t.isMsnMobile,p.L)} `)}</div>${(0,h.z)(t=>!t.disableHideOnHover&&t.cardActionStatus&f.J.enabled,g.C)}</msft-article></msft-article-card>`,T=u.qy`${(t,e)=>e.parent.selectTemplate()}`,F=u.qy` ${(0,b.ux)(t=>[t.cardData],T)}
`;var S=a(38493),D=a(60815),A=a(77833),z=a(81859),I=a(87906),E=a(40450);class B extends n.L{constructor(){super(...arguments),this.placeholderRendered=!1,this.shouldRenderVideo=!0,this.playerPlaying=!1,this.playingCallbackRegistered=!1,this.mouseenterHandler=t=>{this.showCardInfoWhenHover&&this.useVideoTemplate&&(this.isHoverVideo=!0)},this.mouseleaveHandler=t=>{this.showCardInfoWhenHover&&(this.isHoverVideo=!1)},this.previewEndCallback=t=>{this.useVideoTemplate=!t},this.setPlaceholderRendered=()=>{this.shouldRenderVideo&&(this.placeholderRendered=!0)},this.eventsCallback=(t,e)=>{this.playerPlaying||this.playingCallbackRegistered||"play"!==e||(this.playingCallbackRegistered=!0,t.one("playing",()=>{this.playerPlaying=!0}))}}connectedCallback(){super.connectedCallback(),(0,z.h_)()&&(this.shouldRenderVideo=!1)}selectTemplate(){return void 0===this.previewVideo?w:_}isPreviewable(t){return!!this.previewVideo&&(t&&t.videoFiles&&0!==t.videoFiles.length)}clickHandler(t,e){return!(t.useMobile&&!t.isMsnMobile)||(t.mobileCardClickCallback(e.event,A.pL.Video,t,"video card"),!1)}error(t){(0,I.vV)(E.FPh,"Error fetching source","Source: "+t)}}(0,i.Cg)([(0,S.CF)({attribute:"preview-video",mode:"boolean"})],B.prototype,"previewVideo",void 0),(0,i.Cg)([D.sH],B.prototype,"cardData",void 0),(0,i.Cg)([D.sH],B.prototype,"isHoverVideo",void 0),(0,i.Cg)([D.sH],B.prototype,"useVideoTemplate",void 0),(0,i.Cg)([D.sH],B.prototype,"placeholderRendered",void 0),(0,i.Cg)([D.sH],B.prototype,"playerPlaying",void 0),(0,i.Cg)([D.sH],B.prototype,"showCardInfoWhenHover",void 0);let M=class extends B{};M=(0,i.Cg)([(0,n.E)({name:"msn-video-card",template:F,styles:r})],M);const R=u.qy`
    <msn-video-card
        class="${t=>t.cardSize}"
        style="grid-area:${t=>t.gridArea}"
        :cardData=${t=>t}
        :showCardInfoWhenHover=${t=>t.showCardInfoWhenHover}
        preview-video=${t=>t.useVideoPreviewTemplate}
    >
    </msn-video-card>
`},27970(t,e,a){"use strict";a.d(e,{j(){return r}});var i=a(94972),n=a(65949);const r={getFeedDataForCard(t){return(0,n._C)(t)},viewTemplate:i.p,getPreviewForCard(t){return(0,n.E_)(t)}}},65949(t,e,a){"use strict";a.d(e,{_C(){return l},E_(){return s},QC(){return c}});const i="http://adaptivecards.io/schemas/adaptive-card.json";var n=a(98794),r=a(69828),o=a(33744);function s(t){if(!t)return null;if(function(t){if(!t.body||!t.body[0]||!t.body[0].columns||t.body[0].columns.length<3)return!1;const e=t.body[0].columns[2].items&&t.body[0].columns[2].items[0];return!(!e||!e.text)}(t)){const e=t.body[0].columns[2].items[0].text,a={$schema:i,version:t.version,type:"AdaptiveCard",body:[{type:"ColumnSet",columns:[{type:"Column",items:[{type:"TextBlock",id:"WidgetsOverlayText",text:e.slice(0,e.length-1),size:"small",horizontalAlignment:"center"}]}]}]};return t.widgetsOverlay=a,t.timeToLiveInSeconds=1800,t.contentType="Weather",t}return t}function l(t){const{cardMetadata:e,configOptions:a,supportedSdCardActionMenuItems:i}=t,o=a&&a;let s;e?.data&&(s=function(t){const{configOptions:e,parentTelemetryObject:a,cardMetadata:i,openLinksInNewTab:n,hideCardCallback:r,goToPersonalizeSettingsCallback:o,sdCardActionClickHandler:s,dismissSDCardMenuCallback:l,refreshSDCardSection:c,supportedSdCardActionMenuItems:d,refreshFeedCallback:p,visualReadinessCallback:g,hasLoadedCallback:u,isDynamicFeed:h,activeBoard:b,isWidgetRegion:m,onSDCardClick:f}=t,v=e&&e;return{id:"weather",childTemplateType:"weather-card",parentTelemetryObject:a,weatherCardConfigInfo:v,cardMetadata:i.data,openLinksInNewTab:n,hideWeatherCardCallback:r,goToPersonalizeSettingsCallback:o,dismissSDCardMenuCallback:l,refreshSDCardSection:c,sdCardActionClickHandler:s,supportedSdCardActionMenuItems:d,refreshFeed:p,visualReadinessCallback:g,hasLoadedCallback:u,isDynamicFeed:h,isSpotlightUX:i.metadata&&i.metadata.isSpotlightUX,activeBoard:b,previewType:i.metadata&&i.metadata.previewType,isProngReclaim:i.metadata&&i.metadata.isProngReclaim,isWidgetRegion:m,onSDCardClick:f}}(t));return(0,n.bw)({id:"weather",experienceType:o?.configRef?.experienceType,mapperArgs:t},s,(t,e)=>({cardLayout:e.cardSize===r.uE._1x_1y?"half":"full",supportedSdCardActionMenuItems:i}),!0)}function c(){return"edgeChromium"===o.T3.AppType}},94972(t,e,a){"use strict";a.d(e,{p(){return l}});var i=a(73632),n=a(89757),r=a(65949),o=a(94172);const s=n.qy`
    ${(t,e)=>{const a=function(t){if("{}"===t.cardMetadata)return t.cardLayout;return"_1x_1y"===t.cardSize?"half":"_1x_2y"===t.cardSize?"full":"_1x_3y"===t.cardSize?"large":t.cardLayout}(t),n={cardSize:a,openLinksInNewTab:t.openLinksInNewTab,cardMetadata:t.cardMetadata,wpoMetadata:t.wpoMetadata,parentTelemetry:t.parentTelemetryObject,sdCardActionClickHandler:t.sdCardActionClickHandler,hideWeatherCardCallback:t.hideWeatherCardCallback,goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback,dismissActionMenu:t.dismissSDCardMenuCallback,refreshSDCardSection:t.refreshSDCardSection,supportedSdCardActionMenuItems:t.supportedSdCardActionMenuItems,refreshFeed:t.refreshFeed,visualReadinessCallback:t.visualReadinessCallback,hasLoadedCallback:t.hasLoadedCallback,isDynamicFeed:t.isDynamicFeed,isSpotlightUX:t.isSpotlightUX,cardLayout:t.activeBoard,previewType:t.previewType,isProngReclaim:t.isProngReclaim,isWidgetRegion:t.isWidgetRegion,onSDCardClick:t.onSDCardClick},s={cardSize:a,style:`grid-area:${t.gridArea};contain:unset;content-visibility:visible`};return t.weatherCardConfigInfo?(0,o.yN)(t.weatherCardConfigInfo,{properties:n,attributes:s,memoize:(0,r.QC)()&&!(0,i.S)()}):void 0}}
`,l=n.qy`
    ${s}
`},45519(t,e,a){"use strict";a.d(e,{ZV(){return i},g_(){return n}});const i=t=>{if(null==t)return"";const e=Number(t);if(isNaN(e)||!isFinite(e))return"";if(e<1e3)return e.toString();const a=["K","M","B","T"];let i=-1,n=e;for(;n>=1e3&&i<a.length-1;)n/=1e3,i++;n=Math.round(10*n)/10;return(n%1==0?n.toFixed(0):n.toFixed(1))+a[i]},n=t=>{if(null==t)return"";const e=Number(t);if(isNaN(e)||!isFinite(e))return"";if(e<1e4)return e.toString();let a=e/1e4;a=Math.round(10*a)/10;return(a%1==0?a.toFixed(0):a.toFixed(1))+"w"}},13186(t,e,a){"use strict";a.d(e,{P(){return i}});const i="#0078D4"},34897(t,e,a){"use strict";a.d(e,{L(){return p}});var i=a(10103);class n extends i.y{}var r=a(5675),o=a(7896),s=a(61138),l=a(59669),c=a(64187);const d=l.A` ${(0,c.V)("flex")} :host{box-sizing:border-box;font-family:${o.O};font-size:${s.k};line-height:${s.F};height:100%}`,p=n.compose({name:"msn-info-pane-panel",template:(0,r.S)(),styles:d})},13660(t,e,a){"use strict";a.d(e,{K(){return m}});var i=a(99751);class n extends i.s{}var r=a(60347),o=a(59669),s=a(50882),l=a(64187),c=a(73477),d=a(22131),p=a(7896),g=a(47810),u=a(26920),h=a(14996);const b=o.A` ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${p.O};min-height:6px;min-width:6px;background-color:${g.l};border-radius:20px;opacity:0.4;grid-row:1;z-index:1;margin:0px 2px}:host([aria-selected="true"]){z-index:2;opacity:1;min-width:30px}:host(:hover),:host(:active){background:${g.l};opacity:1}:host(:${c.N}){outline:none;box-shadow:0 0 0 calc((${u.vd} - ${u.XA}) * 1px) rgba(0,0,0,1),0 0 0 calc((${u.vd} + ${u.XA}) * 1px) ${h.WN}}:host(:focus){outline:none}`.withBehaviors((0,d.mr)(o.A` :host{forced-color-adjust:none;border-color:transparent;color:${s.A.ButtonText};fill:${s.A.ButtonText}}:host(:hover),:host([aria-selected="true"]:hover){background:${s.A.Highlight};color:${s.A.HighlightText};fill:${s.A.HighlightText}}:host([aria-selected="true"]){background:${s.A.HighlightText};color:${s.A.Highlight};fill:${s.A.Highlight}}:host(:${c.N}){border-color:${s.A.ButtonText};box-shadow:0 0 0 calc((${u.vd} - ${u.XA}) * 1px) rgba(0,0,0,1),0 0 0 calc((${u.vd} + ${u.XA}) * 1px) ${s.A.ButtonText}}`)),m=n.compose({name:"msn-info-pane-tab",template:(0,r.M)(),styles:b})},86294(t,e,a){"use strict";a.d(e,{j(){return v}});var i=a(56911),n=a(4174),r=a(37180),o=a(45046),s=a(92011),l=a(38493);class c extends s.L{}(0,i.Cg)([l.CF],c.prototype,"userSubscriptionData",void 0),(0,i.Cg)([l.CF],c.prototype,"cardSize",void 0);var d=a(59669),p=a(9960),g=a(69809);const u=d.A`
.badge{border-radius:4px;font-size:8px}.badge svg{margin-inline-end:6px}.true{background:linear-gradient(90deg,#5051D1 0%,#797AF5 100%);padding:2px 6px 3px 8px;color:#FFFFFF}.false{background:${(0,p.ud)()?"linear-gradient(90deg, rgba(255, 255, 255, 0.88) 0%, rgba(255, 255, 255, 0.78) 100%)":"linear-gradient(90deg, rgba(0, 0, 0, 0.64) 0%, rgba(0, 0, 0, 0.46) 100%)"};display:flex;padding:2px 6px 3px 8px;color:${g.m_}}._1x_2y{display:inline-flex;margin-bottom:6px}._2x_2y{position:absolute;top:16px}`;var h=a(89757),b=a(69259);const m=h.qy`<svg width="8" height="10" xmlns="http://www.w3.org/2000/svg"><path d="M3.874.816 4 .813c1.097 0 1.994.856 2.059 1.936l.003.126v.375h.563c.621 0 1.125.504 1.125 1.125v4.5C7.75 9.496 7.246 10 6.625 10h-5.25A1.125 1.125 0 0 1 .25 8.875v-4.5c0-.621.504-1.125 1.125-1.125h.563v-.375c0-1.097.856-1.994 1.936-2.059L4 .813l-.126.003ZM4 5.875a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm.096-3.933L4 1.938a.938.938 0 0 0-.933.841l-.005.096v.375h1.876v-.375a.938.938 0 0 0-.842-.933L4 1.938l.096.004Z" fill="currentColor"/></svg>`,f=h.qy`<div class="badge ${t=>t.userSubscriptionData.isSubscribed?"true":"false"} ${t=>"_1x_2y"==t.cardSize?"_1x_2y":"_2x_2y"}">${(0,b.z)(t=>!t.userSubscriptionData.isSubscribed,h.qy` ${m}<b>${t=>t.userSubscriptionData?.subscribeToViewText?.toLocaleUpperCase()}</b>`)} ${(0,b.z)(t=>t.userSubscriptionData.isSubscribed,h.qy`<b>${t=>t.userSubscriptionData?.subscribedText?.toLocaleUpperCase()}</b>`)}</div>`;let v=class extends c{};v=(0,i.Cg)([(0,s.E)({name:"msn-subscription-badge",template:f,styles:u})],v),n.m.define(r.c.registry),o.m.define(r.c.registry)},74826(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 2h5c.28 0 .5.22.5.5V5h1a2 2 0 012 2v5a2 2 0 01-2 2H4a2 2 0 01-2-2V7c0-1.1.9-2 2-2h1V2.5c0-.28.22-.5.5-.5zM10 5V3H6v2h4zM4 6a1 1 0 00-1 1v5a1 1 0 001 1h8a1 1 0 001-1V7a1 1 0 00-1-1H4z"></path></svg>'},58759(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M9.43 11.84a1 1 0 001.57-.82V4.98a1 1 0 00-1.57-.82L5.64 6.78c-.85.59-.85 1.85 0 2.44l3.79 2.62z"></path></svg>'},26106(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M15 17.9a1.25 1.25 0 01-2.07.94l-6.31-5.52c-.8-.7-.8-1.94 0-2.64l6.3-5.52c.82-.7 2.08-.13 2.08.94v11.8z"></path></svg>'},30576(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M7.57 11.84A1 1 0 016 11.02V4.98a1 1 0 011.57-.82l3.79 2.62c.85.59.85 1.85 0 2.44l-3.79 2.62z"></path></svg>'},30961(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 17.9a1.25 1.25 0 002.07.94l6.31-5.52c.8-.7.8-1.94 0-2.64l-6.3-5.52C10.25 4.46 9 5.03 9 6.1v11.8z"></path></svg>'},86203(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11.14 2.53a1.5 1.5 0 00-2.28 0l-6.62 7.8A1 1 0 003 11.98h3V17a1 1 0 001 1h6a1 1 0 001-1v-5.02h3a1 1 0 00.76-1.65l-6.62-7.8z"></path></svg>'},48493(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.86 2.53c.6-.7 1.68-.7 2.28 0l6.62 7.8a1 1 0 01-.76 1.65h-3V17a1 1 0 01-1 1H7a1 1 0 01-1-1v-5.02H3a1 1 0 01-.76-1.65l6.62-7.8zm1.52.65a.5.5 0 00-.76 0L3 10.98h3.5c.28 0 .5.23.5.5V17h6v-5.52c0-.27.22-.5.5-.5H17l-6.62-7.8z"></path></svg>'},10103(t,e,a){"use strict";a.d(e,{y(){return n}});var i=a(92011);class n extends i.L{}},5675(t,e,a){"use strict";a.d(e,{S(){return n}});var i=a(89757);function n(){return i.qy`
        <template slot="tabpanel" role="tabpanel">
            <slot></slot>
        </template>
    `}},99751(t,e,a){"use strict";a.d(e,{s(){return l}});var i=a(56911),n=a(92011),r=a(38493),o=a(35106),s=a(88458);class l extends n.L{}(0,i.Cg)([(0,r.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],l.prototype,"disabled",void 0),(0,s.X)(l,o.qw)},60347(t,e,a){"use strict";a.d(e,{M(){return r}});var i=a(89757),n=a(35106);function r(t={}){return i.qy`
        <template slot="tab" role="tab" aria-disabled="${t=>t.disabled}">
            ${(0,n.LT)(t)}
            <slot></slot>
            ${(0,n.aO)(t)}
        </template>
    `}},49991(t,e,a){"use strict";a.d(e,{h3(){return u},aK(){return m},Ed(){return h},Gs(){return b},dR(){return y}});var i=a(97747),n=a(5291),r=a(83252),o=a(31023),s=a(6032),l=a(356),c=a(47691),d=a(95239),p=a(88397);const{create:g}=i.G,u=g("gradient-white-fill").withDefault(t=>(0,p.u)(.8,1,n.q.create(1,1,1),t(r.F7))),h=g("gradient-background-fill").withDefault(t=>(0,p.u)(0,1,null,t(r.F7))),b=g("neutral-fill-bubble-on-rest").withDefault(t=>function(t,e){const a=t.closestIndexOf(e);return t.get(a-5)}(t(o.r),t(r.F7))),m=g("neutral-foreground-hint-on-bubble-on-rest").withDefault(t=>t(s.g).evaluate(t,t(b)));function f(t,e,a){return t.get(t.closestIndexOf((i=e,n.q.create(i,i,i)))-a);var i}const v=g({name:"neutral-layer-card-recipe",cssCustomPropertyName:null}).withDefault({evaluate(t){return f(t(o.r),t(l.l),t(c.E))}}),y=g("neutral-layer-card").withDefault(t=>t(v).evaluate(t)),x=g("neutral-fill-bubble-rest-delta",6),$=g("neutral-fill-bubble-hover-delta",9);g("neutral-fill-bubble-rest",t=>{const e=t(o.r),a=e.closestIndexOf(t(d.p)),i=a>=10?-1:1;return e.get(a+i*t(x))}),g("neutral-fill-bubble-hover",t=>{const e=t(o.r),a=e.closestIndexOf(t(d.p)),i=a>=10?-1:1;return e.get(a+i*t($))})},88397(t,e,a){"use strict";a.d(e,{u(){return r}});var i=a(33045),n=a(87122);function r(t=0,e=1,a,r){const o=r.toColorString(),{r:s,g:l,b:c}=(0,i.Hs)(o),d=`linear-gradient(160deg, ${new n.M(s,l,c,t).toStringWebRGBA()}, ${new n.M(s,l,c,e).toStringWebRGBA()})`;if(a){const t=a?.toColorString();return[d,t].join()}return d}}}]);