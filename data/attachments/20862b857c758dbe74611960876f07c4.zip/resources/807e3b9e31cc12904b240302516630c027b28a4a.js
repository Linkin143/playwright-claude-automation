"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-2c"],{70512(t,e,a){a.d(e,{O:()=>s});var i=a(67072),r=a(23305);class s extends r.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){let{cardSize:e,isFullCard:a,sportsGameStats:r,isSpotlight2Card:s,participants:o,isSeasonStats:n,isCopilotTheme:l,isMitUX:d}=t,c=0;switch(e){case i.uE._1x_2y:c=a?5:3;break;case i.uE._1x_3y:c=7;break;case i.uE._2x_2y:c=4;break;case i.uE._15u:c=3}return{sportsGameStats:r.slice(0,c).map(t=>{let e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:s,isFullCard:a,participants:o,cardTitle:this.getCardTitle(n,l),isCopilotTheme:l,isMitUX:d,telemetryTag:""}}isPercentStats(t){return t?.includes("%")}getBarPercentage(t,e,a){let i=this.isPercentStats(a);return 0===t&&0===e?0:(i?t:t/(t+e))*100}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},83546(t,e,a){a.d(e,{h:()=>r});var i=a(53128);function r(){return(0,i.oh)()}},35044(t,e,a){a.r(e),a.d(e,{SportsGameStatsTransformer:()=>i.O,SportsMatchWithScoresTransformer:()=>d,SportsMatchTransformer:()=>r.SportsMatchTransformer,SportsSpotlight2cTransformer:()=>p});var i=a(70512),r=a(82724),s=a(23305),o=a(87906),n=a(40450),l=a(33744);class d extends s.Bc{async transform(t){return{viewModel:await this.getViewModel(t)}}async getViewModel(t){let e=t.matchMetadata,a=await this.transformerProvider.generateView(e,s.hi.SportsMatch),i=e.matchData.sportsMatchData,r=this.getTableViewModel(t),o={...e.telemetryConstants,name:s.BP.SportsSpotlightMatchCard2c},n=i?.gameInfo,l=this.getGameInfoStrings(i);return{match:a.viewModel,gameInfo:n,tableView:r,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,o),gameInfoStrings:l}}getTableViewModel(t){try{let e=t.matchMetadata,a=e.matchData.sportsMatchData,i=a.detailedScore;if(!i)return;if(!i.game||i.game?.length<2)return void(0,o.vV)(n.BfS,"Sports scores table detailedScored game data missing",`market=${l.T3.CurrentMarket}`,t);let r=i.game,d=i.scoreKeyOrder;if(d.length>12)return;let c=[];a.participantOne&&(a.participantOne?.shortName&&c.push(a.participantOne.shortName),a.participantTwo?.shortName&&c.push(a.participantTwo.shortName));let g=c.map((t,e)=>({gameScore:Object.values(r[e]).slice(0,d.length),participantName:t}));if(0===g.length)return;let p={...e.telemetryConstants,name:s.BP.SportsSpotlightScores2c},m=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,p),h=this.getTableStyle(d,12),v=d.length>=5;return{headerRow:d,participants:g,maxElements:12,tableStyle:h,isLarge:v,telemetryTag:m}}catch(e){(0,o.vV)(n.BfS,`Error generating sports scores table view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t);return}}getGameInfoStrings(t){let e=t?.gameInfo,a={venueTitle:"",venueValue:"",streamTitle:"",streamValue:"",leagueTitle:"",leagueValue:""};return e&&(a.venueTitle=this.transformerProvider.strings.venue,a.venueValue=t.gameInfo.venueInfo,a.streamTitle=this.transformerProvider.strings.liveStream,a.streamValue=t.gameInfo.streamInfo,a.leagueTitle=this.transformerProvider.strings.league,a.leagueValue=t.gameInfo.league),a}getGap(t,e){let a=Math.round(3*(e-t));return`gap: ${a}px;`}getTableStyle(t,e){let a=t.length;return a<5?`grid-template-columns: repeat(auto-fit, minmax(16px, max-content)); ${this.getGap(a,e)}`:"grid-template-columns: repeat(auto-fit, minmax(16px, 1fr));"}}var c=a(79811),g=a(89757);class p extends s.Bc{constructor(){super(...arguments),this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"yardsPerGame",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame"}}async transform(t){let e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.upcomingMatches)},a=await this.getCurrentViewModel(e);return{viewTemplate:(0,g.qy)`
                <sports-spotlight-2c
                    :viewModel="${a}"
                ></sports-spotlight-2c>`}}async getCurrentViewModel(t){if((0,c.nD)(t))return void(0,o.vV)(n.BfS,"2c spotlight metadata missing",`market=${l.T3.CurrentMarket}`,t);try{let e,a,i,r,s=t.spotlightData?.matchlist,d=this.getMatchesMetadata(t,s),c=await this.getMatchWithScoresViews(d);0===c.length&&(0,o.vV)(n.BfS,"2c spotlight match data missing",`market=${l.T3.CurrentMarket}`,t);let{cardSize:g}=t;if(t.spotlightData?.sportsGameStats?.length>0)e=await this.getGameStatsInfo(t),i=t.spotlightData?.isSeasonStats?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.matchStatistics;else{let e=t.spotlightData?.upcomingMatchList,i=this.getMatchesMetadata(t,e).map(t=>({...t,hasVerticalLine:!0}));a=await this.getMatchViews(i),r=this.transformerProvider.strings.upcomingGames}return{matchesWithScores:c,upcomingMatches:a,cardSize:g,sportsGameStatsCard:e,sportsGameStatsTitle:i,sportsUpcomingMatchesTitle:r,telemetryTag:""}}catch(e){(0,o.vV)(n.BfS,`Error generating sports spotlight 2c view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}async getGameStatsInfo(t){let{sportsGameStats:e,isSeasonStats:a=!1}=t.spotlightData||{},{cardSize:i}=t;return await this.transformerProvider.generateView({cardSize:i,sportsGameStats:e,isSeasonStats:a},s.hi.SportsGameStats)}getMatchesMetadata(t,e){if(!e)return[];let a=(0,c.nD)(t.followedSports)?new Map:t.followedSports,i=(0,c.Yo)(e);return e.map(e=>{let r=e.sportsMatchData,s=a.get(r.participantOne?.satoriId||"")||a.get(r.participantOne?.yId||"")||!1,o=a.get(r.participantTwo?.satoriId||"")||a.get(r.participantTwo?.yId||"")||!1;return{matchData:e,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,participantOneFollowed:s,participantTwoFollowed:o,isContainLiveMatch:i,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:t.isHeroCard,isVertical:!0}})}async getMatchViews(t){let e=t.map(t=>this.transformerProvider.generateView(t,s.hi.SportsMatch));return(await Promise.all(e)).filter(c.z2)}async getMatchWithScoresViews(t){let e=t.map(t=>this.transformerProvider.generateView({matchMetadata:t},s.hi.SportsMatchWithScores));return(await Promise.all(e)).filter(c.z2)}transformSportsSpotlightData(t,e){let a,{statistics:i}=t,r=t.match&&this.transformMatchData(t.match),s=c.Zi,d=c.ZL,g=[];if(r){let t=r.participantOne?.primaryColorHex===r.participantTwo?.primaryColorHex&&r.participantOne?.primaryColorHex?.toLowerCase()==="ffffff";!t&&r.participantOne?.primaryColorHex&&(s=(0,c.gS)(r.participantOne.primaryColorHex)),!t&&r.participantTwo?.primaryColorHex&&(d=(0,c.gS)(r.participantTwo.primaryColorHex)),r.matchClickthroughUrl?a=r.matchClickthroughUrl:r.gameCenterUrl&&(a=(0,c.Ot)(r.gameCenterUrl),r.matchClickthroughUrl=a),g.push({sportsMatchData:r})}let p=[];e&&(p=e.map(t=>(!(t=this.transformMatchData(t)).matchClickthroughUrl&&t.gameCenterUrl&&(t.matchClickthroughUrl=(0,c.Ot)(t.gameCenterUrl)),{sportsMatchData:t})));let m=this.transformGameState(i,[s,d]);return m||0!==p.length?{matchlist:g,upcomingMatchList:p,sportsGameStats:m,matchClickthroughUrl:a||"",isSeasonStats:i&&i.season&&2===i.season.length}:void(0,o.vV)(n.BfS,"Missing both game stats and upcoming match data",`market=${l.T3.CurrentMarket}`,t)}transformMatchData(t){let e=(0,c.yn)(t.gameStartDateTime);return t.gameDate=(0,c.AL)(e,l.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,c.ry)(e,l.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,t.gameStateCatetory="string"!=typeof t.gameState?(0,c.m5)(t.gameState.state):t.gameStateCatetory,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,c.PH)(t.gameState)),t.participantOne&&(t.participantOne.scheduleUrl=(0,c.Ot)(t.participantOne.gameCenterUrl)),t.participantTwo&&(t.participantTwo.scheduleUrl=(0,c.Ot)(t.participantTwo.gameCenterUrl)),t.gameCenterUrl&&(t.matchClickthroughUrl=(0,c.Ot)(t.gameCenterUrl)),t.participantOne.imageUrl=(0,c.iK)(t.participantOne.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.participantTwo.imageUrl=(0,c.iK)(t.participantTwo.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.gameState=t.gameStateCatetory===s.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:t.gameStateCatetory,t}transformGameState(t,e){if((0,c.nD)(t))return;let a=[];t.season&&2===t.season.length?a=t.season:t.game&&2===t.game.length&&(a=t.game);let i=[];if(a[0]&&a[1]){let r=a[0],s=a[1];for(let a of t.statsKeyOrder||Object.keys(r)){let t=Number(r[a]),o=Number(s[a]),n=this.gameStatsFormatMap[a],l=this.formatGameStatsNumber(t,n),d=this.formatGameStatsNumber(o,n),c=this.calculatePercentNumbers(t,o),g={key:this.gameStatsLocKeyMap[a]||a,left:t,right:o,leftText:l,rightText:d,leftColor:e[0],rightColor:e[1],...c};i.push(g)}}return i}formatGameStatsNumber(t,e){if(!e)return t.toString();let a="";return(e.isPercent&&(a="%"),void 0!==e.toFix)?`${t.toFixed(e.toFix)}${a}`:`${t}${a}`}calculatePercentNumbers(t,e){let a=0,i=0,r=0;return 0!==t&&0!==e?(r=.7,a=t/(t+e)*99.3,i=e/(t+e)*99.3):0===t&&0===e?(a=0,i=0,r=0):0===t?(a=2.3,i=97,r=.7):0===e&&(a=97,i=2.3,r=.7),{leftPercent:Number(a.toFixed(1)),rightPercent:Number(i.toFixed(1)),gap:r}}}Promise.resolve().then(a.bind(a,71817)),Promise.resolve().then(a.bind(a,9038)),Promise.resolve().then(a.bind(a,4708)),Promise.resolve().then(a.bind(a,88502)),Promise.resolve().then(a.bind(a,58669))},20517(t,e,a){a.d(e,{z:()=>o});var i=a(56911),r=a(92011),s=a(60815);class o extends r.L{}(0,i.Cg)([s.sH],o.prototype,"viewModel",void 0)},9038(t,e,a){a.r(e),a.d(e,{SportsGameStats:()=>q});var i=a(56911),r=a(20517),s=a(83546),o=a(60815);class n extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,s.h)()}viewModelChanged(){this.isMitUx=this.viewModel?.isMitUX===!0}}(0,i.Cg)([o.sH],n.prototype,"isMitUx",void 0);var l=a(92011),d=a(86856),c=a(63033),g=a(59669),p=a(4126),m=a(22131);let h=(0,g.A)` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,v=(0,g.A)` :host{--mit-game-stats-list-bg:#00000040}.game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,u=(0,g.A)` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,x=(0,g.A)` .game-stats-item-content{transform:scaleX(-1)}`,f=(0,g.A)` .game-stats-list{background:var(--mit-game-stats-list-bg)}.game-stats-item-header > span:nth-child(2){font-weight:550}`,w=(0,g.A)` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70);--mit-game-stats-list-bg:var(--button-light-rest)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new d.t(null,x),new c.N(u,v),new p.o("isAdaptiveThemeEnabled",!0,h),new p.o("isMitUx",!0,f),(0,m.mr)((0,g.A)` :host{forced-color-adjust:auto}`));var y=a(89757),b=a(69259),S=a(68835);let M=(0,y.qy)`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,$=(0,y.qy)`
    <div class="team-container">
        ${(0,b.z)((t,e)=>0!==e.index,(0,y.qy)`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,b.z)((t,e)=>0===e.index,(0,y.qy)`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,T=(0,y.qy)`
    <div class="game-team-icons">
        ${(0,S.ux)(t=>t.viewModel.participants,$,{positioning:!0})}
    </div>
`,C=(0,y.qy)`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,k=(0,y.qy)`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,b.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,T)}
        ${(0,b.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,C)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,S.ux)(t=>t.viewModel.sportsGameStats,M)}
        </div>
    </div>
`,P=(0,y.qy)`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,S.ux)(t=>t.viewModel.sportsGameStats,(0,y.qy)`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,F=(0,y.qy)`${t=>t.viewModel?.isCopilotTheme?P:k}`,A=(0,y.qy)`
    ${(0,b.z)(t=>void 0!=t.viewModel,F)}
`,q=class extends n{};q=(0,i.Cg)([(0,l.E)({name:"sports-game-stats",template:A,styles:w,shadowOptions:{delegatesFocus:!0}})],q)},88502(t,e,a){a.r(e),a.d(e,{SportsMatchWithScores:()=>M});var i=a(56911),r=a(20517);class s extends r.z{shouldShowTable(){return void 0!==this.viewModel.tableView}}var o=a(92011),n=a(47810),l=a(86856),d=a(63033),c=a(59669),g=a(22131);let p=(0,c.A)` :host{--line-style:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,m=(0,c.A)`
`,h=(0,c.A)`
`,v=(0,c.A)` :host{--line-style:#F2F2F2;--background-color:#FAFAFA}.vert-match{display:flex;height:216px;padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:12px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.match-cntnr,.game-info,.line,.scores-table{width:100%}.game-info{display:flex;flex-direction:column;align-items:flex-start;padding:4px 0px;gap:6px;border-radius:8px}.game-item{display:flex;justify-content:space-between;align-items:flex-start;align-self:stretch;gap:20px}.game-title,.game-value{line-height:var(--type-ramp-minus-1-line-height,16px);font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;white-space:nowrap;color:${n.l}}.game-value{text-align:right;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.line{height:1px;background:var(--line-style)}.scores-table{min-height:1px}`.withBehaviors(new l.t(m,h),new d.N(null,p),(0,g.mr)((0,c.A)` :host{forced-color-adjust:auto}`));var u=a(89757);let x=(0,u.qy)`
    <sports-match class="match-cntnr"
        :viewModel="${t=>t.viewModel.match}"
    ></sports-match>
`,f=(0,u.qy)`
    <div class="game-info">
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.leagueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.leagueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                 ${t=>t.viewModel.gameInfoStrings.venueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.venueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.streamTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.streamValue}
            </div>
        </div>
    </div>
`,w=(0,u.qy)`
    <sports-scores-table class="scores-table"
        :viewModel="${t=>t.viewModel.tableView}"
    ></sports-scores-table>
`,y=(0,u.qy)`
<div class="vert-match">
    ${x}
    <div class="line"></div>
    ${w}
</div>
`,b=(0,u.qy)`
    <div class="vert-match">
        ${x}
        <div class="line"></div>
        ${f}
    </div>
`,S=(0,u.qy)`
    ${t=>t.shouldShowTable()?y:b}
`,M=class extends s{};M=(0,i.Cg)([(0,o.E)({name:"sports-match-with-scores",template:S,styles:v,shadowOptions:{delegatesFocus:!0}})],M)},58669(t,e,a){a.r(e),a.d(e,{SportsScoresTable:()=>b});var i=a(56911),r=a(71372);class s extends r.a{}var o=a(92011),n=a(47810),l=a(86856),d=a(59669),c=a(22131),g=a(63033);let p=(0,d.A)`
`,m=(0,d.A)`
`,h=(0,d.A)`
.table-cntnr{display:flex;gap:6px;align-self:stretch;justify-content:space-between}.part-row,.header-row{display:grid;align-self:stretch;justify-content:end}.header-row:last-child{gap:0}.item-cntnr{align-items:center;justify-content:end}.score-item,.header-item{text-align:center;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:16px;max-width:16px;color:${n.l}}.header-item{font-weight:400}.title-item{display:grid;text-align:left;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:24px;height:16px;color:${n.l};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bold-items{font-weight:600}.title-cntnr,.item-cntnr{display:flex;flex-direction:column;gap:6px}`.withBehaviors(new l.t(null,m),new g.N(null,p),(0,c.mr)((0,d.A)` :host{forced-color-adjust:auto}`));var v=a(89757),u=a(68835),x=a(69259);let f=(0,v.qy)`
    ${t=>{let e;return e=t.viewModel?.tableStyle,(0,v.qy)`
        ${(0,u.ux)(t=>t.viewModel.participants??[],(0,v.qy)`<div class="part-row" style=${e}>
                ${(0,u.ux)(t=>t.gameScore??[],(0,v.qy)`<div class="score-item">
                    ${t=>t}
                </div>`)}
        </div>`)}
    `}}
`,w=(0,v.qy)`
    <div class="table-cntnr">
            <div class ="title-cntnr">
                <div class="title-item"></div>
                ${(0,u.ux)(t=>t.viewModel.participants??[],(0,v.qy)`<div class="title-item">
                    ${t=>t.participantName}
                </div>
                `)}
            </div>
            <div class="item-cntnr" style="${t=>t.viewModel?.isLarge?"width: 100%;":"width: 70%;"}">
                <div class="header-row" style="${t=>t.viewModel?.tableStyle}">
                    ${(0,u.ux)(t=>t.viewModel.headerRow??[],(0,v.qy)`<div class="header-item">
                        ${t=>t}
                    </div>`)}
                </div>
                    ${f}
            </div>
    </div>
`,y=(0,v.qy)`
    ${(0,x.z)(t=>void 0!==t.viewModel,w)}
`,b=class extends s{};b=(0,i.Cg)([(0,o.E)({name:"sports-scores-table",template:y,styles:h,shadowOptions:{delegatesFocus:!0}})],b)},71817(t,e,a){a.r(e),a.d(e,{SportsSpotlight2c:()=>P});var i=a(56911),r=a(20517);class s extends r.z{constructor(){super(...arguments),this.shouldShowGameStats=()=>!!this.viewModel.sportsGameStatsCard}}var o=a(92011),n=a(47810),l=a(86856),d=a(59669),c=a(22131),g=a(63033);let p=(0,d.A)`
`,m=(0,d.A)` :host{--line-color:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,h=(0,d.A)` :host{--line-color:#F2F2F2;--background-color:#FAFAFA;--width-1c:278px;--card-height:216px}.game-stats2c,.game-stats-teams-container,.upcmng-matches2c{display:flex;justify-content:space-between}.title,.name{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal;font-weight:600;color:${n.l}}.game-stats2c{width:580px;align-items:center}.game-stats{display:flex;width:var(--width-1c);height:var(--card-height);padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:10px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.line{width:254px;height:0px;border:1px solid var(--line-color)}.game-stats-teams-container{align-items:center;align-self:stretch}.game-stats-teams-container > div{display:flex;align-items:center;gap:6px}.icon{width:16px;height:16px}.name{max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.icon img{max-width:100%;max-height:100%;width:auto;height:auto}.upcmng-matches2c{flex-direction:row;align-items:center;padding:0px;gap:24px}.upcmng-matches{display:flex;flex-direction:column;align-items:flex-start;padding:8px 12px 12px;gap:12px;width:var(--width-1c);height:var(--card-height);background:var(--background-color);border-radius:8px;box-sizing:border-box}.1c{display:flex;justify-content:center;align-items:center;width:268px}.upcmng-matches2c > div:first-of-type{width:var(--width-1c)}.game-stats2c > div:first-of-type{width:var(--width-1c)}`.withBehaviors(new l.t(null,p),new g.N(null,m),(0,c.mr)((0,d.A)` :host{forced-color-adjust:auto}`));var v=a(89757),u=a(68835),x=a(69259);let f=(0,v.qy)`
    ${(0,u.ux)(t=>t.viewModel.matchesWithScores??[],(0,v.qy)`<sports-match-with-scores style="width: 100%;"
        :viewModel="${t=>t.viewModel}"
    ></sports-match-with-scores>`,{positioning:!0})}
`,w=(0,v.qy)`
    ${t=>{let e=t?.viewModel?.matchesWithScores?.[0]?.viewModel?.match;if(!e)return"";return(0,v.qy)`
    <div class="title">
        ${t=>t.viewModel.sportsGameStatsTitle||""}
    </div>
    <div class="line">
    </div>
    <div class="game-stats-teams-container">
        <div>
            <span class="icon">
                <img
                    role="presentation"
                    src="${e.participantOneImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
            <span class="name" title="${e.matchData.sportsMatchData.participantOne?.name||""}">
                    ${e.matchData.sportsMatchData.participantOne?.name||""}
            </span>
        </div>
        <div>
            <span class="name" title="${e.matchData.sportsMatchData.participantTwo?.name||""}">
                    ${e.matchData.sportsMatchData.participantTwo?.name||""}
            </span>
            <span class="icon">
                <img
                    role="presentation"
                    src="${e.participantTwoImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
        </div>
    </div>
`}}
`,y=(0,v.qy)`
    <div class="game-stats">
        ${w}
        <sports-game-stats :viewModel="${t=>t.viewModel.sportsGameStatsCard?.viewModel}">
        </sports-game-stats>
    </div>
`,b=(0,v.qy)`
    <div class=upcmng-matches>
        <div class="title">${t=>t.viewModel.sportsUpcomingMatchesTitle}</div>
        ${(0,u.ux)(t=>t.viewModel.upcomingMatches??[],(0,v.qy)`
            <div class="line"></div>
            <sports-match
                :viewModel="${t=>t.viewModel}"
            ></sports-match>`,{positioning:!0})}
    </div>
`,S=(0,v.qy)`
    <div class="game-stats2c">
        <div>
            ${f}
        </div>
        ${y}
    </div>
`,M=(0,v.qy)`
    <div class="upcmng-matches2c">
        <div>
            ${f}
        </div>
        ${b}
    </div>
`,$=(0,v.qy)`
    <div class="1c">
        ${f}
    </div>
`,T=(0,v.qy)`
    ${t=>t.shouldShowGameStats()?S:M}
`,C=(0,v.qy)`
    ${t=>"_2x_2y"===t.viewModel.cardSize?T:$}
`,k=(0,v.qy)`
    ${(0,x.z)(t=>void 0!=t.viewModel,C)}
`,P=class extends s{};P=(0,i.Cg)([(0,o.E)({name:"sports-spotlight-2c",template:k,styles:h,shadowOptions:{delegatesFocus:!0}})],P)}}]);