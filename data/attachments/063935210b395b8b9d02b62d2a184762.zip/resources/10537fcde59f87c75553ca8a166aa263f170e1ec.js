"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-tournaments-list"],{91014(e,t,n){n.d(t,{_(){return i}});var a=n(11796);class i extends a.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}async getViewModel(e){const t={...e.telemetryConstants,name:a.BP.SportsTournamentStatusRow};return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,t),...e}}}},40577(e,t,n){n.r(t),n.d(t,{SportsTournamentStatusRowTransformer(){return c._},SportsTournamentsListTransformer(){return m}});var a=n(41432),i=n(11796),r=n(87906),s=n(33335),o=n(32150),l=n(79811),d=n(96950);class m extends i.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,l.jJ)();const n=await this.getCurrentViewModel(e);return{viewTemplate:d.qy`
                <sports-tournaments-list
                    :viewModel="${n}"
                ></sports-tournaments-list>
            `}}async getCurrentViewModel(e){try{if(!e.data)return void(0,r.vV)(s.Ax,"Tournaments data missing",`market=${o.T3.CurrentMarket}`,e);e.data;const{telemetryBuilder:t}=this.transformerProvider,n=e?.gameCenterUrl,a=n&&(0,l.Ot)(n),d=await this.getTournamentsData(e);return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsTournamentsListCard}),tournaments:d,clickThroughUrl:a}}catch(t){return void(0,r.vV)(s.Ax,"Error in transforming tournament list data",`market=${o.T3.CurrentMarket}`,e)}}async getTournamentsData(e){const{strings:t}=this.transformerProvider,n=this.getEndIndex(this.cardSize),a=e.data.slice(0,n).map(async n=>{n.imageUrl=n.imageId?(0,l.iK)(n.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced):null,n.winnerDetails&&!n.winnerDetails?.imageUrl&&(n.winnerDetails.imageUrl=n.winnerDetails?.imageId?(0,l.iK)(n.winnerDetails?.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced):null),n.gameCenterUrl&&(n.gameCenterUrl=(0,l.Ot)(n.gameCenterUrl)),n.gameScheduleString=n.gameStartDateTime?this.getScheduleString(n.gameStartDateTime,n.gameEndDateTime,n.gameState?.state):null,n.strings=t;const a={parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,...n};return this.transformerProvider.generateView(a,i.hi.SportsTournamentStatusRow)});return(await Promise.all(a)).filter(l.z2)}getScheduleString(e,t,n){const a=(0,l.yn)(e),r=t?(0,l.yn)(t):null,s=a.toLocaleString(o.T3.CurrentMarket||"en-us",{month:"short"}),d=r?r.toLocaleString(o.T3.CurrentMarket||"en-us",{month:"short"}):null,m=`${s} ${a.getDate()}`;let c="";return r&&(r.getDate()===a.getDate()&&s===d||(c=s===d?` - ${r.getDate()}`:` - ${d} ${r.getDate()}`),n!==i.T0.PreGame.toString()&&"Pre-game"!==n||(c+=`, ${r.getUTCFullYear()}`)),`${m}${c}`}getEndIndex(e){switch(e){case a.uE._1x_1y:return 1;case a.uE._1x_2y:return 3;case a.uE._1x_3y:return 5;default:return 1}}}var c=n(91014);Promise.resolve().then(n.bind(n,50385)),Promise.resolve().then(n.bind(n,99674))},71372(e,t,n){n.d(t,{a(){return s}});var a=n(56911),i=n(92011),r=n(95144);let s=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,a.Cg)([r.x],s)},99674(e,t,n){n.r(t),n.d(t,{TournamentStatusRow(){return T}});var a=n(56911),i=n(92011),r=n(48751);const s="\n    font-size: var(--type-ramp-minus-1-font-size, 12px);\n    font-weight: 600;\n    line-height: var(--type-ramp-minus-1-line-height, 16px);\n",o="\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n",l=n(74849).A`
.tournament-container{display:flex;flex-direction:column;gap:2px;padding:5px 8px;border-radius:8px;background:var(--sports-item-background);position:relative;max-width:252px;text-decoration:none;color:${r.l};z-index:1}.tournament-container:hover{background:var(--sports-item-hover-background)}.winner-image-container{height:16px;width:16px;display:flex;justify-content:center;align-items:flex-end}.live-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.pregame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.postgame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.inprogress-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.tournament-location{${o} font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px);max-width:260px;height:100%}.tournament-title-container{display:flex;flex-direction:row;height:100%;align-items:flex-start;gap:6px;align-self:stretch}.tournament-details-container{display:flex;flex-direction:column;height:100%;gap:2px}.tournament-image{height:20px;width:20px}.tournament-title{font-size:var(--type-ramp-base-font-size,14px);font-weight:${"600"};line-height:var(--type-ramp-base-line-height,20px);${o} max-width:260px;height:100%}.winner-details-container{display:flex;justify-content:space-between;align-items:center}.winner-name-container{display:flex;flex-direction:row;align-items:center}.winner-score{${s} ${o} max-width:19px}.winner-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;margin-right:2px}.winner-name{${s} ${o} max-width:128px}.winner-image{height:12px;width:12px}`;var d=n(96950),m=n(69259);Object.freeze({unknown:"unknown",preGame:"pre-game",inprogressGame:"inprogress-game",postGame:"post-game",tba:"tba"});const c=Object.freeze({unknown:"Unknown",preGame:"PreGame",inProgress:"InProgress",inProgressBreak:"InProgressBreak",postponed:"Postponed",suspended:"Suspended",cancelled:"Cancelled",forfeited:"Forfeited",delayed:"Delayed",final:"Final",bye:"Bye",abandoned:"Abandoned",live:"Live"});Object.freeze({Unknown:"Unknown",Invalid:"Invalid",PreGame:"PreGame",AboutToStart:"AboutToStart",ParticipantsAreNotKnownYet:"ParticipantsAreNotKnownYet",InProgress:"InProgress",InProgressBreak:"InProgressBreak",Postponed:"Postponed",Suspended:"Suspended",Cancelled:"Cancelled",Unscheduled:"Unscheduled",ForfeitedByBothTeams:"ForfeitedByBothTeams",ForfeitedByAwayTeam:"ForfeitedByAwayTeam",ForfeitedByHomeTeam:"ForfeitedByHomeTeam",ForfeitedByAwayTeamVacatedByHome:"ForfeitedByAwayTeamVacatedByHome",ForfeitedByHomeTeamVacatedByAway:"ForfeitedByHomeTeamVacatedByAway",VacatedByBothTeams:"VacatedByBothTeams",VacatedByAwayTeam:"VacatedByAwayTeam",VacatedByHomeTeam:"VacatedByHomeTeam",Delayed:"Delayed",StartDelayed:"StartDelayed",Final:"Final",Bye:"Bye",Retired:"Retired",Abandoned:"Abandoned",Unnecessary:"Unnecessary",Tea:"Tea",Lunch:"Lunch",InningsBreak:"InningsBreak",Stumps:"Stumps",RainDelay:"RainDelay",BadLight:"BadLight",CrowdTrouble:"CrowdTrouble",PitchCondition:"PitchCondition",FloodlightFailure:"FloodlightFailure",Drinks:"Drinks",SuperOver:"SuperOver",BadGroundCondition:"BadGroundCondition",BadWeatherCondition:"BadWeatherCondition",Dinner:"Dinner",Fog:"Fog",PlayHalted:"PlayHalted",StrategicTimeout:"StrategicTimeout",SuperOverInProgress:"SuperOverInProgress",WetGroundCondition:"WetGroundCondition",WetPitchCondition:"WetPitchCondition",DayWashedOut:"DayWashedOut",Toss:"Toss",MatchAbandonedWithoutToss:"MatchAbandonedWithoutToss",MatchAbandonedWithoutSingleBallBeingBowled:"MatchAbandonedWithoutSingleBallBeingBowled",MatchConceded:"MatchConceded",MatchAwarded:"MatchAwarded",Maintenance:"Maintenance"}),Object.freeze({full:"full",extendedBoxscore:"extended_boxscore",boxscore:"boxscore"}),Object.freeze({Unknown:"Unknown",PreGame:"PreGame",LiveGame:"LiveGame",PostGame:"PostGame"});const u=d.qy`
    <div class="live-tournament-status-title">
            ${e=>`${e.viewModel?.strings?.sportsLive} • ${e.viewModel?.gameState?.name}`}
    </div>
`,p=d.qy`
    <div class="pregame-tournament-status-title">
            ${e=>e.viewModel?.gameScheduleString}
    </div>
`,h=d.qy`
    <div class="postgame-tournament-status-title">
            ${e=>`${e.viewModel?.gameScheduleString} • ${e.viewModel?.strings?.sportsStateFinal}`}
    </div>
`,g=d.qy`
    <div class="inprogress-tournament-status-title">
            ${e=>e.viewModel?.strings?.inProgress}
    </div>
`,y=d.qy`
    <div class="winner-details-container">
        <div class="winner-name-container">
            <span class="winner-text">${e=>e.viewModel?.strings?.winner}</span>
            <div class="winner-image-container">
                <img class="winner-image" src=${e=>e.viewModel?.winnerDetails?.imageUrl} alt=${e=>e.viewModel?.winnerDetails?.name}></img>
            </div>
            <span class="winner-name">${e=>e.viewModel?.winnerDetails?.name}</span>
        </div>
        <div class="winner-score">
            ${e=>e.viewModel?.winnerDetails?.score}
        </div>
    </div>
`,w=d.qy`
    <div class="tournament-location">
        ${e=>e.viewModel?.locationName}
    </div>
`,v=d.qy`
    <div class="tournament-details-container">
        <div class="tournament-title-container">
            <img class="tournament-image" src=${e=>e.viewModel?.imageUrl} alt=${e=>e.viewModel?.name}></img>
            <span class="tournament-title" title=${e=>e.viewModel?.name}>
                ${e=>e.viewModel?.name}
            </span>
        </div>
        ${(0,m.z)(e=>e.viewModel?.gameState?.state!==c.final,w)}
        ${(0,m.z)(e=>e.viewModel?.gameState?.state===c.final&&e.viewModel?.winnerDetails,y)}
    </div>
`,x=d.qy`
<a
    class="tournament-container"
    href="${e=>e.viewModel.gameCenterUrl}"
    target="_blank"
    data-t="${e=>e.viewModel.telemetryTag}"
    tabindex="0"
    >
    ${e=>(e=>{switch(e){case c.live:return u;case c.preGame:return p;case c.final:return h;case c.inProgress:return g;default:return p}})(e.viewModel?.gameState?.state||"")}
    ${v}
</a>
`,f=d.qy`
    ${(0,m.z)(e=>null!=e.viewModel,x)}
`;var $=n(71372);class B extends $.a{}let T=class extends B{};T=(0,a.Cg)([(0,i.E)({name:"tournament-status-row",template:f,styles:l})],T)},50385(e,t,n){n.r(t),n.d(t,{SportsTournamentsList(){return w}});var a=n(56911),i=n(71372);class r extends i.a{}var s=n(92011),o=n(74849),l=n(22131),d=n(48751);const m=o.A` .sports-tournament-list-content{color:${d.l}}`,c=(0,l.G2)(m),u=o.A` .sports-tournament-list-content{text-decoration:none;color:${d.l};display:flex;flex-direction:column;position:relative;height:100%;gap:10px}`.withBehaviors(c);var p=n(96950),h=n(39957);const g=p.qy`
    <a
        class="sports-tournament-list-content ${e=>e.viewModel.cardSize}"
        href="${e=>e.viewModel.clickThroughUrl}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
        >
        ${(0,h.ux)(e=>e.viewModel.tournaments,p.qy`
            <tournament-status-row
                :viewModel="${e=>e.viewModel}"
            ></tournament-status-row>
        `)}
    </a>
`,y=p.qy`
    ${e=>null!=e.viewModel?g:null}
`;let w=class extends r{};w=(0,a.Cg)([(0,s.E)({name:"sports-tournaments-list",template:y,styles:u,shadowOptions:{delegatesFocus:!0}})],w)}}]);