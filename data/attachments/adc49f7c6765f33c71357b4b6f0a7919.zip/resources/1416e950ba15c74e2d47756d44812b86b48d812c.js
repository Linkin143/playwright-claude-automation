"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["stripe-wc"],{36478:function(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M7.73 4.2a.75.75 0 0 1 1.06.03l5 5.25c.28.3.28.75 0 1.04l-5 5.25a.75.75 0 1 1-1.08-1.04L12.2 10l-4.5-4.73a.75.75 0 0 1 .02-1.06Z" fill="currentcolor"/></svg>'},12688:function(e,t,a){a.d(t,{$:function(){return s}});var r=a(89757),i=a(14475),o=a(33744);let s=e=>(0,r.qy)`<a class="ad-choice" data-t=${e.telemetryTag||""} href=${e.href||""} target="${i.z._blank}" title=${e.text||""}><img alt=${e.text||""} aria-hidden="true" src="${(0,o.rA)().StaticsUrl}/latest/responsive-card/adChoiceIcon.svg"></img></a>`},61666:function(e,t,a){a.d(t,{Q:function(){return c}});var r=a(89757),i=a(69259),o=a(14475),s=a(4670),n=a(2188);let l=(e,t)=>{t.event.preventDefault(),window.dispatchEvent(new CustomEvent("dsaClick",{detail:{adSelectionCriteria:e.adSelectionCriteria,anchorElement:t.event.target,strings:e.config.localizedStrings},bubbles:!0,composed:!0}))},d=(e,t)=>("Enter"===t.event.key&&l(e,t),!0),c=e=>(0,r.qy)` ${(0,i.z)(!!e.enableDSADialog,(0,r.qy)`<a class="ad-label dsa" data-t=${e.telemetryTag||""} title=${e.dsaDialogTooltip||""} ?no-border=${!!e.noBorder} @click=${l} @keydown=${d} tabindex="0">${e.text||"Ad"}</a>`)} ${(0,i.z)(!e.enableDSADialog,(0,r.qy)`<a class="ad-label" data-t=${e.telemetryTag||""} href=${e.href||""} target="${o.z._blank}" title=${!(0,s.jj)()?"":e.text||""} ?no-border=${!!e.noBorder} ${!(0,s.jj)()&&(0,n.Ib)(!0,!1)}>${e.text||"Ad"}</a>`)} `},33537:function(e,t,a){a.r(t),a.d(t,{StripeWCRiverStyles:function(){return aq},templateStyles:function(){return aL},ToolingInfo:function(){return ry},StripeWC:function(){return a5},topStripeStyles:function(){return aB},StripeWCFlippersStyles:function(){return az},templateDarkStyles:function(){return aU},StripeWCTemplate:function(){return rg},StripeWCStyles:function(){return aO}});var r,i,o,s,n,l,d=a(4174),c=a(37180),p=a(75003),u=a(69329),h=a(65614),g=a(42320),y=a(651),m=a(12165),f=a(58757),C=a(55461),v=a(97964),x=a(56911),b=a(38493),_=a(60815),w=a(55230),S=a(56863),E=a(92011);class A extends E.L{}class $ extends(0,S.rf)(A){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class I extends ${onTitleClicked(){this.$emit("action-title-clicked")}handleTextInput(){this.inputControl&&(this.value=this.inputControl.value,this.$emit("action-text-input",this.inputControl.value))}addToWatchlist(e){this.inputControl&&(this.inputControl.value="",this.value=""),this.$emit("action-add-to-watchlist",e)}handleOnKeyDownSearchBox(e){if(!this.moneyCardContentData.showSuggestions)return!0;switch(e.key){case w.I5:e.preventDefault(),this.activeSuggestion=this.searchSuggestions.length-1,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;case w.HX:e.preventDefault(),this.activeSuggestion=0,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement()}return!0}focusSelectedElement(){this.selectedSuggestion.querySelectorAll("li").forEach(e=>{e.id===this.activeId&&e.focus()})}handleOnKeyDownAutoSuggestBox(e){switch(e.key){case w.HX:e.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case w.I5:e.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+this.searchSuggestions.length-1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case" ":case"Enter":e.preventDefault(),this.searchSuggestions.length>0&&(this.inputControl.value="",this.activeSuggestion=-1,this.selectedSuggestion.querySelectorAll("li").forEach(e=>{e.id===this.activeId&&e.click()}));break;case"Escape":e.preventDefault(),this.activeSuggestion=-1,this.inputControl.value="",this.$emit("action-text-input",this.inputControl.value);break;default:return}}getSuggestionClass(e,t,a){return e===this.activeId?a:t}}(0,x.Cg)([(0,b.CF)({attribute:"layout"})],I.prototype,"layout",void 0),(0,x.Cg)([_.sH],I.prototype,"moneyCardContentData",void 0),(0,x.Cg)([_.sH],I.prototype,"searchSuggestions",void 0),(0,x.Cg)([_.sH],I.prototype,"goBackTelemetryTag",void 0),(0,x.Cg)([_.sH],I.prototype,"addToWatchlistTelemetryTag",void 0),(0,x.Cg)([_.sH],I.prototype,"activeSuggestion",void 0),(0,x.Cg)([_.sH],I.prototype,"activeId",void 0);var P=a(89757),k=a(60402),D=a(69259),T=a(68835);let R=(0,P.qy)`<li id="${e=>e.quoteId}" tabindex="0" active=${(e,t)=>e.quoteId===t.parent.activeId||null} class="${(e,t)=>t.parent.getSuggestionClass(e.quoteId,"suggestion-entry","suggestion-entry-selected")}" part="${(e,t)=>t.parent.getSuggestionClass(e.quoteId,"suggestion-entry","suggestion-entry-selected")}" aria-label="${e=>e.longName} ${e=>e.exchangeName}" @click="${(e,t)=>t.parent.addToWatchlist(e.quoteId)}" data-t="${(e,t)=>t.parent.addToWatchlistTelemetryTag}"><div class="suggestion-item" part="suggestion-item"><div class="suggestion-company" part="suggestion-company"><span class="suggestion-symbol" part="suggestion-symbol">${e=>e.equitySymbol}</span><span class="suggestion-name" part="suggestion-name">${e=>e.longName}</span></div><div class="suggestion-market" part="suggestion-market"><span class="suggestion-market-str">${e=>e.exchangeName}</span></div><div class="suggestion-add-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17 9.53v.94h-6.53V17h-.94v-6.53H3v-.94h6.53V3h.94v6.53H17z" /></svg></div></div></li>`,M=(0,P.qy)`<div class="search-area" part="search-area"><div class="search-icon" part="search-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 3a5.5 5.5 0 014.23 9.02l4.12 4.13a.5.5 0 01-.63.76l-.07-.06-4.13-4.12A5.5 5.5 0 118.5 3zm0 1a4.5 4.5 0 100 9 4.5 4.5 0 000-9z" /></svg></div><input class="search-input" part="search-input" type="search" autofocus="autofocus" @input=${e=>e.handleTextInput()} @keydown="${(e,t)=>e.handleOnKeyDownSearchBox(t.event)}" aria-label="${e=>e.moneyCardContentData?.searchPlaceholder}" placeholder="${e=>e.moneyCardContentData?.searchPlaceholder}" :value="${e=>e.value}" ${(0,k.K)("inputControl")} />${(0,D.z)(e=>e.moneyCardContentData?.showSuggestions===!0,(0,P.qy)`<ul class="suggestions-list" part="suggestions-list" tabindex="-1" @keydown="${(e,t)=>e.handleOnKeyDownAutoSuggestBox(t.event)}" ${(0,k.K)("selectedSuggestion")}>${(0,T.ux)((e,t)=>e.searchSuggestions,R)}</ul>`)} ${(0,D.z)(e=>e.moneyCardContentData?.noSuggestion===!0,(0,P.qy)`<div class="suggestions-list" part="suggestions-list"><div class="no-suggestion-str">${e=>e.moneyCardContentData?.noSuggestionHint}</div></div>`)}</div>`,F=(0,P.qy)`<div class="title" part="title"><button class="title-button" part="title-button" @click="${e=>e.onTitleClicked()}" aria-label="${e=>e.moneyCardContentData?.goBackLabel}" data-t="${e=>e.goBackTelemetryTag}"><span class="title-content">&lrm;${e=>e.moneyCardContentData?.titleContent}</span></button></div>${M}
`;var O=a(59669),B=a(64187),L=a(22131),U=a(73477),z=a(61138),q=a(6032),N=a(48196),W=a(33113),H=a(47810),j=a(41123),V=a(95403),G=a(37998),K=a(7896),J=a(83252),Q=a(86856),Y=a(50882);let X=(0,O.A)` .suggestion-add-icon{padding-left:10px}`,Z=(0,O.A)` .suggestion-add-icon{padding-right:10px}`,ee=(0,O.A)` ${(0,B.V)("grid")} :host{box-sizing:border-box;position:relative;width:100%;outline:none;padding:12px 16px;height:100%;grid-template-rows:auto 1fr}:host([layout="full"]) .title{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:1fr auto;height:24px;margin-bottom:11px}:host([layout="half"]) .title{align-items:center;display:grid;grid-template-columns:1fr auto;grid-column-gap:8px;margin-bottom:8px;height:16px}.title-button{border:none;display:flex;font-size:${z.k};line-height:${z.F};font-weight:500;color:${q.c};background-color:transparent;outline:none;cursor:pointer;padding:0px}.title-button:focus{text-decoration:underline}.title-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-inline-end:12px}.search-area{display:grid;grid-template-columns:auto 1fr;height:calc(${N.D} * 1px);position:relative;border:1px solid ${W.I2}}.search-icon{width:20px;padding:6px 10px}svg path{fill:${H.l}}.search-input{color:${H.l};background:transparent;font-size:${j.K};line-height:${j.Z};height:calc(${N.D} * 1px);border:none;outline:none}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.suggestion-add-icon{padding-left:10px}.suggestions-list{margin:0px;display:block;position:absolute;box-sizing:border-box;top:40px;width:100%;padding:4px;background:${V.Wl};--elevation:10;${G.ET};z-index:9999;border:1px solid transparent}.no-suggestion-str{margin:3px 9px;font-size:${j.K};line-height:${j.Z}}.suggestion-entry-selected{font-family:${K.O};outline:none;list-style:none;border:none;width:258px;height:47px;padding:0px;background:${J.Xt};text-decoration:none;cursor:pointer}.suggestion-entry{border:none;outline:none;list-style:none;width:258px;height:47px;padding:0px;background:${V.Wl};text-decoration:none;cursor:pointer}.suggestion-entry:hover .suggestion-item{background:${J.Xt}}.suggestion-entry,.search-input,.title-button{font-family:${K.O}}.suggestion-item{display:grid;grid-template-columns:140px 66px 32px;grid-column-gap:2px;height:40px;padding:5px 8px 2px 8px}.suggestion-company{display:grid;text-align:start;grid-template-rows:20px 20px}.suggestion-add-icon{padding-top:9px}.suggestion-symbol{display:block;font-weight:800;font-size:${j.K};line-height:${j.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}.suggestion-name{display:block;font-weight:600;font-size:${z.k};line-height:${z.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}.suggestion-market{display:flex;position:relative;padding-top:8px}.suggestion-market-str{position:absolute;right:0px;font-weight:600;text-align:end;font-size:${z.k};line-height:${z.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}`.withBehaviors(new Q.t(X,Z),(0,L.mr)((0,O.A)` :host{forced-color-adjust:auto}svg path{fill:${Y.A.ButtonText}}.suggestion-entry:hover .suggestion-item,.suggestion-entry:${U.N} .suggestion-item{forced-color-adjust:none;background:${Y.A.Highlight}}.suggestion-entry:hover .suggestion-item *,.suggestion-entry:hover .suggestion-item svg path,.suggestion-entry:${U.N} .suggestion-item *,.suggestion-entry:${U.N} .suggestion-item svg path{color:${Y.A.HighlightText};fill:currentcolor}`)),et=I.compose({name:`${y.i.prefix}-add-watchlist-money-card`,template:F,styles:ee});var ea=a(47131),er=a(61851),ei=a(34897),eo=a(81606),es=a(85981),en=a(19511),el=a(61473),ed=a(2684),ec=a(47211);(r=s||(s={})).AutosEntityList="AutosEntityList",r.AutosCarousel="AutosCarousel",(i=n||(n={})).AnaheimNtpFeeds="anaheim-ntp-feeds",i.MSNArticle="articles-startshop-feeds",i.MSNHomePage="hponeservicefeed";var ep=a(87906),eu=a(40450),eh=a(33744),eg=a(43672),ey=a(12776),em=a(23057),ef=a(83826);let eC='{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';async function ev(e,t=n.AnaheimNtpFeeds,a,r){let i=function(e){switch(e){case n.AnaheimNtpFeeds:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";case n.MSNArticle:return"TUvfxJjXdl3YnnSTtb4nTd6OHIbDUzhvcgJt26A7Bi";case n.MSNHomePage:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";default:return""}}(t),o=new URL(`https://assets.msn.com/service/news/feed/segments/autosMarketplace?apikey=${i}&ocid=${t}`),s=await (0,em.XK)()===2?ey.WR.getOneServiceParamsWithAuth((0,eh.rA)().UserId,t):ey.WR.getOneServiceParamsWithoutAuth((0,eh.rA)().UserId,t),l=new Set(["apikey","ocid"]);r&&s.push({key:"contentId",value:r}),s&&s.forEach(e=>{e.value&&!l.has(e.key)&&o.searchParams.set(e.key,e.value)});let d=await (0,ef.w)(()=>fetch(o.href),"GetAutosEntityList"),c=3;if(!d.ok&&!e)return"{}";if(!d.ok&&e)switch(eh.T3.CurrentMarket){case eg.DX.ENUS:return eC;case eg.DX.ENCA:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';case eg.DX.ENGB:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';default:return eC}for(;c>0&&d?.status!==200;){try{d=await (0,ef.w)(()=>fetch(o.href),"GetAutosEntityList")}catch(e){(0,ep.c_)(Error("Response Fetch Error"),eu.uqN,"send request to segments api failed")}c--}if(!d.ok)throw Error(d.statusText);let p=await d.json(),u=p&&p[0]&&p[0].data;if(a&&p.length>0){let e=p.filter(e=>e.type==a);u=e&&e[0]&&e[0].data}return u}var ex=a(32247),eb=a(13507),e_=a(2274),ew=a(10316),eS=a(84289),eE=a(44646),eA=a(45596),e$=a(52226),eI=a(37125),eP=a(5977);(o=l||(l={})).casualGamesCard="casual-games-card",o.casualGamesStripeCarouselCard="casual-games-stripe-carousel-card",o.contentCard="content-card",o.contentCardPreview1x="content-card-preview-1x",o.denseCard="dense-card",o.displayAdCard="display-ad-card",o.infopaneCard="infopane-card",o.infopaneSlideCard="infopane-slide-card",o.moneyInfoCardWC="money-info-card",o.healthArticlesCardWC="health-articles-card",o.nativeAdCard="native-ad-card",o.placeholderCard="placeholder-card",o.pollsCard="polls-card",o.shoppingCarouselCard="shopping-carousel-card",o.shoppingVideoCarousel="shopping-video-carousel-card",o.superappUpsellCard="superapp-upsell-card",o.trendingNowCard="trending-now-card",o.weatherCard="weather-card",o.webContentCard="web-content-card",o.videoCard="video-card",o.travelDestinationCard="travel-destination";var ek=a(77833);let eD={[ek.pL.Article]:l.contentCard,[ek.pL.CasualGamesStripeCarousel]:l.casualGamesStripeCarouselCard,[ek.pL.EsportsCasualGames]:l.casualGamesCard,[ek.pL.Slideshow]:l.contentCard,[ek.pL.ExternalLink]:l.contentCard,[ek.pL.Video]:l.contentCard,[ek.pL.WebContent]:l.contentCard,[ek.pL.Infopane]:l.infopaneCard,[ek.pL.ShoppingCarousel]:l.shoppingCarouselCard,[ek.pL.Dense]:l.denseCard,[ek.pL.TrendingInTenMinutes]:l.trendingNowCard,[ek.pL.NativeAd]:l.nativeAdCard};var eT=a(69828);let eR=(0,O.A)`

:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),eM={cardCount:4,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eR},eF=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
  
`.withBehaviors(),eO={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eF},eB=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot6"
        "slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eL={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eB},eU=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot7"
        "slot1 slot2 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ez={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eU},eq=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot6"
        "slot1 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eN={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eq},eW=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot7"
        "slot1 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eH={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eW},ej=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot8"
        "slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eV={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:ej},eG=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot10"
        "slot3 slot6 slot9 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eK={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eG},eJ=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot9"
        "slot1 slot4 slot7 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eQ={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot9",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot10",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eJ},eY=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),eX={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:eT.uE._2x_3y,C3:eT.uE._2x_3y,C2:eT.uE._2x_3y}}],styles:eY},eZ=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),e0={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:eT.uE._3x_3y,C3:eT.uE._3x_3y,C2:eT.uE._3x_3y}}],styles:eZ},e1=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),e2={cardCount:2,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y,C1:eT.uE._1x_3y}}],styles:e1},e3=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot5";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e4={cardCount:5,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._2x_3y,C3:eT.uE._2x_3y,C2:eT.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:e3},e5=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot6"
        "slot1 slot1 slot2 slot4 slot6"
        "slot1 slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e6={cardCount:6,cardSlots:[{grid_area:"slot1",layouts:{C5:eT.uE._2x_3y,C4:eT.uE._2x_3y,C3:eT.uE._2x_3y,C2:eT.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:eT.uE._1x_3y,C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}},{grid_area:"slot3",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:eT.uE._1x_3y,C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}}],styles:e5},e8=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot4 slot7";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e7={cardCount:7,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._2x_3y,C3:eT.uE._2x_3y,C2:eT.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:e8},e9=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot8"
        "slot1 slot1 slot3 slot6 slot8"
        "slot1 slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),te={cardCount:8,cardSlots:[{grid_area:"slot1",layouts:{C5:eT.uE._2x_3y,C4:eT.uE._2x_3y,C3:eT.uE._2x_3y,C2:eT.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot3",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot7",layouts:{C5:eT.uE._1x_1y,C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y}},{grid_area:"slot8",layouts:{C5:eT.uE._1x_3y,C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y}}],styles:e9};var tt=a(47300);let ta=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas: 
        "slot1 slot1 slot1 slot2"
        "slot1 slot1 slot1 slot2";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0 16px;
}

${(0,tt.H5)(tt.j1.c3)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2";
    };
}

${(0,tt.H5)(tt.j1.c2)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),tr={cardCount:2,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._3x_2y,C3:eT.uE._2x_2y,C2:eT.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_2y,C3:eT.uE._1x_2y,C2:eT.uE._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[1,2]}}],styles:ta},ti=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
${(0,tt.H5)(tt.j1.c3)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot1"
            "slot1 slot1 slot1"
            "slot1 slot1 slot1";
    };
}

${(0,tt.H5)(tt.j1.c2)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),to={cardCount:1,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._4x_2y,C3:eT.uE._3x_2y,C2:eT.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:ti},ts=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
`.withBehaviors(),tn={cardCount:1,cardSlots:[{grid_area:"slot1",layouts:{C5:eT.uE._5x_2y,C4:eT.uE._4x_2y,C3:eT.uE._3x_2y,C2:eT.uE._2x_2y}}],styles:ts},tl=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),td={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tl},tc=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot7"
        "slot3 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),tp={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:tc},tu=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot8"
        "slot2 slot4 slot6 slot8"
        "slot3 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),th={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tu},tg=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot8"
        "slot2 slot5 slot7 slot8"
        "slot3 slot6 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ty={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_3y,C3:eT.uE._1x_3y,C2:eT.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tg},tm=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot11"
        "slot3 slot6 slot9 slot12";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot10"],
:host fluent-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot11"],
:host fluent-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot10"],
:host cs-responsive-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot11"],
:host cs-responsive-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),tf={cardCount:12,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot11",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot12",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:tm},tC=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot7"
        "slot2 slot3 slot12 slot7"
        "slot4 slot5 slot13 slot7";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C4"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot3"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot5"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot3"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot5"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}
    
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot7"
        "slot2 slot3 slot7"
        "slot4 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot7"
        "slot4 slot7"
        "slot8 slot7";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),tv={cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._2x_2y,C3:eT.uE._2x_2y,C2:eT.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_4y,C3:eT.uE._1x_4y,C2:eT.uE._1x_4y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C2:[6,1]}},{grid_area:"slot9",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:9}},{grid_area:"slot10",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:10}},{grid_area:"slot11",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:tC},tx=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot8"
        "slot2 slot3 slot12 slot9"
        "slot4 slot5 slot13 slot10";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot8"
        "slot2 slot3 slot9"
        "slot4 slot5 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot3"
        "slot4 slot5"
        "slot8 slot9";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),tb={"msn-home-page-river-section-1111":eM,"msn-home-page-river-section-1113":eO,"msn-home-page-river-section-1131":eL,"msn-home-page-river-section-1133":ez,"msn-home-page-river-section-1311":eN,"msn-home-page-river-section-1313":eH,"msn-home-page-river-section-1331":eV,"msn-home-page-river-section-1333":eQ,"msn-home-page-river-section-3331":eK,"msn-home-page-river-section-1W13":e4,"msn-home-page-river-section-1W131":e6,"msn-home-page-river-section-1WWW":to,"msn-home-page-river-section-1WWWW":tn,"msn-home-page-river-section-1WW1":tr,"msn-home-page-river-section-1W33":e7,"msn-home-page-river-section-1W331":te,"msn-home-page-river-section-3111":td,"msn-home-page-river-section-3113":tp,"msn-home-page-river-section-3131":th,"msn-home-page-river-section-3333":tf,"msn-home-page-river-section-3311":ty,"msn-home-page-river-section-111W":eX,"msn-home-page-river-section-111WW":e0,"msn-home-page-river-section-11WW":e2,"msn-home-page-top-stripe-view-no-segment":{cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:eT.KF,gutterPx:eT.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:eT.uE._2x_2y,C3:eT.uE._2x_2y,C2:eT.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[4,2]}},{grid_area:"slot4",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C4:[2,4],C3:[2,3],C2:[6,1]}},{grid_area:"slot9",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:9},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[6,2]}},{grid_area:"slot10",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:10},telemetryRowCol:{C4:[4,4],C3:[4,3]}},{grid_area:"slot11",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:eT.uE._1x_1y,C3:eT.uE._1x_1y,C2:eT.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:tx},"msn-home-page-top-stripe-view-big-forth-col-no-segment":tv};var t_=a(72287),tw=a(37914),tS=a(7961),tE=a(60640),tA=a(19e3),t$=a(10862),tI=a(9039),tP=a(50365),tk=a(18420),tD=a(65455),tT=a(52600),tR=a(71733),tM=a(33485),tF=a(90466),tO=a(18176),tB=a(26144),tL=a(34900),tU=a(18755),tz=a(59409),tq=a(245),tN=a(71084),tW=a(56525),tH=a(96245),tj=a(8097),tV=a(32361),tG=a(13162),tK=a(95583),tJ=a(94972),tQ=a(27970),tY=a(37899),tX=a(41291),tZ=a(32460),t0=a(88466),t1=a(94172);let t2=(0,P.qy)`
<fluent-card
    id="health-articles-card"
    style="grid-area:${e=>e.gridArea};border-radius:6px"
    class="${e=>e.cardSize}"
>
    ${e=>e.healthArticlesConfigInfo&&(0,t1.yN)(e.healthArticlesConfigInfo,{includeTelemetryTag:!1,properties:{parentTelemetryObject:e.parentTelemetryObject,telObjectBase:e.parentTelemetryObject,healthArticleData:e.healthArticleData,refreshSDCardSection:e.refreshSDCardSection,sdCardActionClickHandler:e.sdCardActionClickHandler,refreshFeed:e.refreshFeed,cardSize:e.cardSize},events:{goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback}})}

</fluent-card>
`;var t3=a(66728),t4=a(98794),t5=a(7074);function t6(e){try{if(!e)throw Error(`Invalid color string = ${e}`);let t=e?.substr(1),a=parseInt(t?.substr(0,2),16),r=parseInt(t?.substr(2,2),16),i=parseInt(t?.substr(4,2),16);if(!(0,t5.A)(a)||!(0,t5.A)(r)||!(0,t5.A)(i))throw Error(`Could not extract color from = ${e}`);return`${a}, ${r}, ${i}`}catch(e){return"58, 52, 45"}}function t8(e){let t,a=e.length;for(;0!=a;)t=Math.floor(Math.random()*a),a--,[e[a],e[t]]=[e[t],e[a]];return e}let t7={"casual-games-card":tz.H,"casual-games-stripe-carousel-card":tU.K,"content-card":tw.K,"content-card-preview-1x":tS.T,"infopane-card":tY.P,"infopane-slide-card":tE.g,"dense-card":t$.e,"display-ad-card":tP.s,"money-info-card":tD.P,"health-articles-card":t2,"native-ad-card":tR.DO,"placeholder-card":tF.u,"polls-card":tB.d,"shopping-carousel-card":tq.j,"weather-card":tJ.p,"web-content-card":tS.T,"video-card":tG.Q,"trending-now-card":tj.A,"travel-destination-card":tW.T,"responsive-card":tZ.t},t9={[l.casualGamesCard]:tz.D,[l.casualGamesStripeCarouselCard]:tU.O,[l.contentCard]:t0.v,[l.contentCardPreview1x]:t0.v,[l.denseCard]:tI.o,[l.infopaneCard]:tX.V,[l.infopaneSlideCard]:t0.v,[l.displayAdCard]:tk.E,[l.moneyInfoCardWC]:tT.j,[l.healthArticlesCardWC]:{getFeedDataForCard:e=>(function(e){try{let{configOptions:t,parentTelemetryObject:a,cardMetadata:r,refreshSDCardSection:i,sdCardActionClickHandler:o,refreshFeedCallback:s,goToPersonalizeSettingsCallback:n}=e,l=t&&t,d=r&&r.data&&function(e){let t=null;if(!e)return t;let a=JSON.parse(e);if(!a)return t;let r=[],i=[];if(a.items)for(let e=0;e<a.items.length;e++)a.items[e].imageUrl&&r.push(a.items[e]);if(a.randomItems)for(let e=0;e<a.randomItems.length;e++)i.push(a.randomItems[e]);r=t8(r),i=t8(i),(r.length>0||i.length>0)&&(t=[]);for(let e=0;e<r.length&&e<2;e++)t.push(function(e){let t=e.title,a=e.url,r=e.imageUrl,i=e.additionalAttributes.find(e=>"ProviderLogo"==e.key).value,o=e.additionalAttributes.find(e=>"ProviderName"==e.key).value,s=t6(e.additionalAttributes.find(e=>"DarkModeColor"==e.key).value);return{title:t,clickUrl:a,mainImageUrl:r,brandLogoUrl:i,brandName:o,gradientColor:s,category:"recommendation"}}(r[e]));for(let e=0;e<i.length&&t.length<4;e++)t.push(function(e){let t=e.title,a=e.url,r=e.imageUrl,i=e.additionalAttributes.find(e=>"ProviderLogo"==e.key).value,o=e.additionalAttributes.find(e=>"ProviderName"==e.key).value,s=t6(e.additionalAttributes.find(e=>"DarkModeColor"==e.key).value);return{title:t,clickUrl:a,mainImageUrl:r,brandLogoUrl:i,brandName:o,gradientColor:s,category:"suggestion"}}(i[e]));return t}(r.data);return(0,t4.bw)({id:"healthArticlesCard",experienceType:l?.configRef?.experienceType,mapperArgs:e},{id:"healthArticlesCard",childTemplateType:"health-articles-card",parentTelemetryObject:a,telObjectBase:a,healthArticlesConfigInfo:l,healthArticleData:d,sdCardActionClickHandler:o,refreshFeed:i||s,goToPersonalizeSettingsCallback:n,refreshSDCardSection:i})}catch(t){(0,ep.vV)(t3.NZ,`Error in feed layout: ${t}, mapperargs = ${JSON.stringify(e)}`)}return null})(e),viewTemplate:t2},[l.nativeAdCard]:tM.$,[l.placeholderCard]:tO.M,[l.pollsCard]:tL.N,[l.shoppingCarouselCard]:tN.f,[l.trendingNowCard]:tV.Q,[l.weatherCard]:tQ.j,[l.webContentCard]:tA.m,[l.videoCard]:tK.O,[l.travelDestinationCard]:tH.t};var ae=a(29871),at=a(94108),aa=a(58319),ar=a(96897),ai=a(83756),ao=a(66546),as=a(69846),an=a(7446),al=a(98378),ad=a(87283);let ac=(e,t)=>{let a=document.createElement("style");a.innerHTML=t,e.prepend(a)};var ap=a(87440),au=a(63456),ah=a(29307),ag=a(12867);let ay="local",am="promotions",af="fromOurPartners",aC="bannerAd",av="quizCardWC",ax={"ar-ae":"BBlFCyr","ar-eg":"BBlmAAj","ar-sa":"BBlFPtc","bn-in":"BBU7Qw4","da-dk":"BBlrVvd","de-at":"BBlROe9","de-ch":"BBZ1dPy","de-de":"BB19Lup4","el-gr":"BBlpx0F","en-ae":"BBlFzXn","en-au":"BB12Wlad","en-ca":"BB15zxqh","en-gb":"BB131KqR","en-ie":"BBlSybW","en-in":"BBlJDWj","en-my":"BBnmzKF","en-nz":"BBloYCJ","en-ph":"BBpkImc","en-sg":"BBnkfV1","en-xl":"BBJLSPs","en-za":"BBlq660","es-ar":"BBnlJDa","es-cl":"BBlrlMA","es-co":"BBloOIy","es-es":"BB12XBRm","es-mx":"BBu6hpo","es-pe":"BBlqzW8","es-us":"BBlsKCT","es-ve":"BBloH3J","es-xl":"BBlsFUm","fi-fi":"BBltzSJ","fr-be":"BBltAia","fr-ca":"BBHSUQ1","fr-ch":"BBm7onJ","fr-fr":"BB1fEVKT","he-il":"BBlrTD9","hi-in":"BBH8j5q","id-id":"BBqRsFe","it-it":"BB1334rQ","ja-jp":"CChcKo","ko-kr":"AAfBokA","mr-in":"AAEnx4n","nb-no":"BBlG6uP","nl-be":"BBltzP7","nl-nl":"BBlpya4","pl-pl":"BBls505","pt-br":"BBlrUUd","pt-pt":"AAg0WfA","sv-se":"BBlu2g8","te-in":"AAEns3L","th-th":"BBot3Jh","tr-tr":"BBlppGp","vi-vn":"BBov02b","zh-cn":"AAFsW17","zh-hk":"BBlBHZI"};function ab(e,t,a,r,i,o,s){if(!s)return;let n=e.indexOf(s);if(-1===n)return;let l=new Date,d=l.getDay(),c="#"+Math.trunc(l.getHours()).toString()+"#";if(r&&(d>=1&&d<=5&&r.includes(c)||(i=-1)),a&&d>=1&&d<=5&&a.includes(c)&&(i=1),null!=i&&!(i<0)&&!(i>=e.length)&&!(i>=t.length))if("1"===o)for(let a=i;a<n;a++){let{cardProviderConfig:r}=t[a]||{},{initialRequest:i}=r||{},{feedId:o,_:s}=i||{};if(o===aC||o===am||o===af);else{let r=e[a];e[a]=e[n],e[n]=r;let i=t[a];t[a]=t[n],t[n]=i}}else if("2"===o){let a=e[i];e[i]=e[n],e[n]=a;let r=t[i];t[i]=t[n],t[n]=r}else{let a=e.splice(n,1)[0];e.splice(i,0,a);let r=t.splice(n,1)[0];t.splice(i,0,r)}}function a_(e,t){return e.personalizedStripeConfig?.[t]}var aw=a(25854),aS=a(59010),aE=a(36597),aA=a(49371);let a$=(0,aE.wg)("debugalert");class aI{static getServiceUrl(e,t,a){let r=new URL((0,aA.e3)()?this.baseUrlForBot:this.baseUrl),i=new aS.m;return i.set(eh.T3.OneServiceContentMarketQspKey,t),i.set("ocid","health-verthp-feeds"),i.set("apikey","FywQv6H345wNCU4yKWraF2esI9qiMQFx90v53mMHrm"),i.set("$top","20"),eh.T3?.UserId&&i.set("user",eh.T3.UserId),eh.T3.ShouldUseFdheadQsp&&i.set("fdhead","prg-wpo-healthcs"),i.set("noCache","true"),i.set("$select",e),!1===a&&i.set("ranid",`${Math.random().toString().replace("0.","")}`),r.search=i.toString(),r.href}static async getDataFromOneService(e,t,a){try{if(!t)throw Error("Null or empty market");if("1"===a$)throw Error("this is a test alert");let r={method:"GET",headers:{accept:"application/json"}};t&&5===t.length&&t.substr(0,2);let i=this.getServiceUrl(e,t,a),o=await (0,ef.w)(async()=>{let e=await fetch(i,r);if(e){if(!e.ok)throw Error(`Status:${e.status} Url = ${i}`)}else throw Error(`Null response. Url = ${i}`);return e.json()},"getContentFromOneService");if(!o||!o.length||!o[0]||!o[0].data)throw Error(`Null, empty or invalid response Json. Url = ${i}`);return JSON.parse(o[0].data)}catch(t){let e;throw"object"==typeof t?e=t.message:"string"==typeof t&&(e=t),Error(`Error in one service call. ${e}`)}}}aI.baseUrl="https://api.msn.com/news/feed/segments/health",aI.baseUrlForBot="https://assets.msn.com/service/news/feed/segments/health";var aP=a(94818),ak=a(72627),aD=a(47616);let aT=(0,a(73632).S)()?window.fetch.bind(window):(e,t)=>(0,aD.hv)(e,800,t);class aR{async getUserPreferences(){let e,t=eh.T3.CurrentMarket||"en-us",a=eh.T3.UserId,r=`/api/v1/getpref/${a}?market=${t}`;try{if(!(e=await aT(this.getFalconServiceUrl("userpreferencefetcher","bing-shopping",r),this.getFalconRequestInit("GET")))||!e.ok)return[];let t=await e.json();if(!(t&&t.orderedVerticals))return[];return(t&&t.orderedVerticals&&{orderedVerticals:t.orderedVerticals.map(e=>({...e,name:e.name}))}).orderedVerticals.map(e=>e.name)}catch(e){return(0,ep.c_)(e,eu.QyC,"Error fetching user preference data",`usermuid: ${a}`),[]}}getFalconServiceUrl(e,t,a){return((0,ak.ou)().startsWith("localhost.msn.com")?`https://${e}.${t}.microsoft-testing-falcon.io`:`https://services.bingapis.com/${t}.${e}`)+a}getFalconRequestInit(e){return{method:e}}}let aM=(0,O.A)`
.stripe-slider-container{left:-52px}`,aF=(0,O.A)`
.title-arrow{-moz-transform:scale(-1,1);-webkit-transform:scale(-1,1);-o-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.stripe-slider-container{right:-52px}.scrollDownButtonContainerRight{right:inherit;left:25px}`,aO=(0,O.A)`
:host{--border-color:#e6e6e6;--heading-font-size:14px;--heading-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--heading-line-height:20px;--heading-start-padding:8px;--abstract-start-padding:8px;--dense-card-hero-width:300px;--dense-card-news-list-width:263px;--dense-list-item-height:39px;--dense-list-item-title-opacity:1;--dense-list-item-title-line-height:19px;--dense-card-new-layout1-margin-top:2px;--dense-card-new-layout1-width:280px;--dense-card-new-layout1-margin:0 11px;--dense-new-layout1-list-item-height:36px;--dense-new-layout1-list-item-max-width:261px;--dense-new-layout1-list-item-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--dense-new-layout1-list-item-font-size:15px;--fill-color:#fff;--heading-max-lines:2}.stripe-feed{height:100%;padding:0px 0px 60px;box-sizing:border-box}.river-section{margin-bottom:8px;display:flex;flex-flow:column;position:relative}.progress-ring-wrapper{display:flex;justify-content:center}.river-section-header-group{align-items:baseline;border-top:2px solid var(--border-color,#e6e6e6);display:flex;width:100%}.river-section-footer-group{align-items:baseline;display:flex;justify-content:space-between;width:100%}.stripe-title{padding-top:5px}.stripe-title h2{font-size:20px;font-weight:600;margin-top:unset;margin-bottom:20px;white-space:nowrap;display:inline-flex;align-items:center}msft-ad-label{min-width:32px;height:13px;margin-right:8px}.stripe-title h2 a{border-bottom:none;color:${H.l};position:relative;text-decoration:none}.stripe-title h2 a:hover{text-decoration:underline}.stripe-title h2 a span{position:absolute;top:.29rem}.stripe-title svg path{stroke:currentColor;stroke-width:1px}.sub-nav{display:grid;grid-template-columns:minmax(0,1fr);margin-inline-start:33px;writing-mode:horizontal-tb}.see-more{min-width:max-content;margin-top:5px;position:absolute;right:0;bottom:-4px}.see-more a{color:#0070c9;font-size:12px;font-weight:600;letter-spacing:0.64px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;text-decoration:none}.in-stripe-banner-ad{width:auto;height:auto;display:flex;justify-content:center;overflow:hidden}.pagination-sentinel{position:absolute;bottom:0;left:0;right:0;z-index:-1;height:200px}.stripe-slider-container{box-sizing:border-box;width:calc(100% + 106px);padding:0px 50px 0px}.stripe-slider-container.more-space{padding-bottom:16px}.stripe-slider-container-rail{padding-right:49px !important;padding-left:49px !important}.stripe-river-section{margin-right:3px}cs-feed-layout:part(heading){font-family:var(--heading-font-family)}msft-ad-label{--ad-label-fill-green:#1E6525;--ad-label-color-white:#FFF}msft-ad-label::part(control){box-sizing:border-box;display:inline-block;border-radius:2px;border-color:transparent;vertical-align:bottom}#liveshopping{display:none}#secondaryStripe{margin-top:-12px}`.withBehaviors(new Q.t(aM,aF),(0,L.G2)((0,O.A)` :host{--fill-color:#2b2b2b}`)),aB=`
:host{--heading-start-padding:16px;--heading-max-lines:2;--heading-line-height:28px}`,aL=' fluent-card,fluent-card msn-info-pane{position:relative}fluent-card .placeholder-card{animation:placeholder-animation 1s linear infinite;background-image:linear-gradient(90deg,#fafafa 0%,white 50%,#fafafa 100%);background-size:100px 100%;background-color:#fafafa;background-repeat:no-repeat;background-position:-50%}fluent-card msn-info-pane::part(previous-flipper),fluent-card msn-info-pane::part(next-flipper){opacity:1}@keyframes placeholder-animation{to{background-position:150%}}:host([data-section="finance"]) fluent-card[class="full"]:nth-of-type(1){background:none}:host([data-section="weather"]) fluent-card money-info-card::part(money-card),:host([data-section="tools"]) fluent-card money-info-card::part(money-card),:host([data-section="finance"]) fluent-card money-info-card::part(money-card){height:100%;width:100%;border-radius:4px;display:flex;justify-content:center}:host(cs-feed-layout[data-section="liveshopping"]){width:1271px;margin-right:0px !important;margin-left:0px !important}:host([data-section="partners"]) fluent-card msft-content-card img[slot="media"],:host([data-section="promotions"]) fluent-card msft-content-card img[slot="media"]{width:306px;height:200px;object-fit:cover}#displayAdCard{--elevation:4;display:flex;justify-content:center;height:var(--card-height,100%);width:var(--card-width,100%);padding-top:3px;box-sizing:border-box;background:var(--fill-color);border-radius:calc(var(--layer-corner-radius) * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))))}.info-pane-slide-title{-webkit-line-clamp:2 !important}',aU=" @media (prefers-color-scheme:dark){fluent-card .placeholder-card{background:#2b2b2b !important}}",az=' .next-arrow,.previous-arrow{height:45px;width:45px}.next::part(next),.previous::part(previous){height:45px;width:45px}.next-arrow:before,.previous-arrow:before{content:"";opacity:0;position:absolute;inset:0px;transition:all 0.1s ease-in-out 0s}',aq=`
.msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.msft-horizontal-card-slider::part(arrow-container){padding:5px 10px}.msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}`;var aN=a(44704);let aW={topStripe:{name:"today.Hero",action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Section},secondaryStripe:{name:"today.Hero.standaloneEP",action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Section},headlineItemViewModel:{name:"HeadlineItemViewModel",action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Headline},todayHeadlines:{name:"todayHeadlines",action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Headline},todayStripeHeadlines:{name:"todayStripeHeadlines",action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Headline},title:{name:"title",action:al.EG.Click,behavior:al.MS.Navigate,type:al.MJ.NavBar},seeMore:{name:"seeMore",action:al.EG.Click,behavior:al.MS.Navigate}};class aH{getSectionTelemetryTag(e,t){return e in aW?this.getTelemetryTag(aW[e]):this.getTelemetryTag({name:t||`stripe.${e}`,action:al.EG.View,behavior:al.MS.Show,type:al.MJ.Section})}getTelemetryTag(e){return(0,aN.N)(e.name,e.behavior,e.action,e.type).getMetadataTag()}}var aj=a(65794),aV=a(12673),aG=a(12882),aK=a(4934),aJ=a(31216);let aQ=(e,t)=>{let a=t.findIndex(e=>(0,aJ.RD)((0,aJ.qK)(e)));if(-1!==a){let e=[...t],r=e[a];return e.splice(a,1),e.unshift(r),{backfillMetadata:e,backfillTemplateId:void 0,backfillCardTypeSlot:void 0}}return{backfillMetadata:t,backfillTemplateId:e?.templateId,backfillCardTypeSlot:[]}},aY=new Map([["video",aQ],["video_stripe",aQ]]),aX=(e,t,a)=>{let r={backfillMetadata:void 0,backfillTemplateId:void 0,backfillCardTypeSlot:void 0};try{let i=aY.get(e);if(!i||!a)return r;return i(a,t)}catch{return r}};var aZ=a(38118);let a0=(0,ag.a)().get("vptest"),a1=(0,ex.ZF)(),a2="AdServiceCall.StripeWC",a3="inserted-card";function a4(e){return`stripewc.${e}`}class a5 extends aj.U{constructor(){super(...arguments),this.isFetchingStripes=!1,this.riverSectionLayoutData=[],this.ttvrFired=!1,this.isFeedExhausted=!1,this.enableRail=!1,this.visualReadinessCallbackSet=!1,this.appliedStyles=[],this.defaultLoadCount=2,this.infopaneSubItems=[],this.loadedWebComponents=[],this.nativeAdPlacementsMap={},this.pollsData={poll:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null},quiz:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null}},this.autosData={fallbackToContentCard:!1,data:null,enableStaticResponse:!1},this.riverSectionIndex=0,this.riverSectionResponses={},this.retryCountRecord={},this.nativeAdIsLoaded={},this.nativeAdIndiceRegionFilters=[],this.ttvrLogInfo={topStripeStartAt:[],topStripeFetchedAt:[],topStripeRetryAt:[],topStripeRenderedAt:void 0,topStripeAdsReadyAt:void 0,aboveThefoldReadyAt:void 0,ttvrFiredAt:void 0,ttvrBoundedImage:[]},this.hasSectionInterest={},this.dynamicRankingInterests=[],this.dynamicInterestsFetched=!1,this.shoppingCarouselData={data:[],fallbackToContentCard:!1},this.replacementInfopaneCards={},this.shouldOverrideInfopaneCards=!1,this.customInsertedCards={},this.overrideHasSlideShow=!1,this.dependencies=new Set,this.onBreakpointCallback=e=>{this.columnArrangement=e.toUpperCase(),window.setTimeout(()=>{this.updateShowDot(),this.updateStripes()})},this.initCardAction=e=>{this.cardActionRef||(this.cardActionRef=this.shadowRoot.querySelector?.("card-action")),this.cardActionRef?.updateCardActionProps({...e})},this.getVisualReadinessCallback=(e,t,a)=>{let r=t===l.infopaneCard?l.infopaneCard:e?.cardContent?.id,i=this.riverSectionIds[0];return this.getSectionAdPlacementIndices(i).includes(a)||this.dependencies.add(r),()=>{this.dependencies.has(r)&&this.dependencies.delete(r),0===this.dependencies.size&&this.setVisuallyReadyMarkers()}},this.getSectionAdPlacementIndices=e=>{let t=[...this.config?.adPlacements?.[e]?.placements||[],...this.config?.cmsAdPlacements?.[e]?.placements||[]],a=[];return t.forEach(e=>{e.region!==ek.pL.Infopane&&e.indices?.length&&a.push(...e.indices)}),a},this.setVisuallyReadyMarkers=()=>{this.ttvrFired||(this.ttvrFired=!0,(0,eb.D)(()=>{this.markVisuallyReady(),this.ttvrLogInfo.ttvrFiredAt=performance.now(),this.config.enableBulkFetch?this.updateStripes():this.updateStripes(this.riverSectionIds[this.riverSectionLayoutData.findIndex(e=>void 0!==e)]),this.initTopStripeNativeAds().then(()=>{let e=(0,ai.Kl)();e&&ao.m?.updateVisuallyReadyTiming?.getActionSender(e)?.send((0,ai.ez)(el.p_1,void 0,void 0,void 0,window.performance.now()))})}))},this.setPaginationObserver=()=>{"IntersectionObserver"in window&&this.paginationSentinelRef&&(this.sentinelObserver=new IntersectionObserver(this.onSentinelChange),window.requestAnimationFrame(()=>{this.sentinelObserver.observe(this.paginationSentinelRef)}))},this.onSentinelChange=e=>{!e||e.length<1||!this.ttvrFired||e[0].isIntersecting&&this.onUserPaginate()},this.onUserPaginate=()=>{this.riverSectionIndex<this.riverSections.length?this.fetchStripes(this.config.lazyLoadCount):this.isFeedExhausted=!0},this.isPaginationVisible=()=>{if(!this.paginationSentinelRef)return!1;let{y:e,height:t}=this.paginationSentinelRef.getBoundingClientRect();return e-t<Math.max(document.documentElement.clientHeight,window.innerHeight)},this.processLayoutStyles=()=>{let{stripeStyles:e={}}=this.config;Object.keys(e).forEach(t=>{if(!this.appliedStyles.includes(t)){var a,r,i;let o,s,n,l;a=e[t],r=t,i=this,s=r.split(" "),n=i,((e,t)=>{let a=e?.shadowRoot||e;if(!a||a.querySelector("style.stripe-style"))return;let r=document.createElement("style");r.className="stripe-style",Object.keys(t).forEach(e=>{r.innerHTML+=`${e} { ${t[e]} }
`}),a.prepend(r)})(o=(l=()=>{let e=s.shift();return(n=n?.shadowRoot?.querySelector?.(e)||n?.querySelector?.(e),s.length&&n)?l():n})(),a),o&&this.appliedStyles.push(t)}})},this.onDisplayAdHeightChange=e=>{let{htmlId:t,height:a}=e?.detail||{};if(t?.startsWith("rectangle1")&&a&&!this.enableRail){let{longDisplayAdLayoutTemplate:e}=this.config,t=this.riverSectionIds[0];if(!e)return;this.riverSectionLayoutData[0].templateId=600===a?e:this.riverSections[0].riverSectionTemplate,this.updateStripes(t)}}}isFeedExhaustedChanged(e,t){if(!t)return;this.sentinelObserver?.disconnect();let a=this.config?.cardProviderConfig?.initialRequest?.count||30;this.onFeedEndCb?.({cardCount:a})}async enableRailChanged(e){if("boolean"!=typeof e||!this.config)return;await new Promise(e=>window.setTimeout(e));let{longDisplayAdLayoutTemplate:t}=this.config;this.enableRail&&t&&this.riverSectionLayoutData[0]?.templateId===t&&(this.riverSectionLayoutData[0].templateId=this.riverSections[0].riverSectionTemplate,this.updateStripes(this.riverSectionIds[0]))}async experienceConnected(){this.stripeWCTelemetry||(this.stripeWCTelemetry=new aH),await aZ.D.initConfig(),(0,eo.registerCSResponsiveCard)(),(0,es.C)(),en.T.define(h.G.registry),this.initRiverSectionAndId(),a0&&(this.riverSectionIds.forEach(e=>(0,e_.cX)(a4(e))),(0,e_.gR)().then(()=>{Object.assign(a1,{vpready:performance.now()}),performance.mark("vpready")})),this.initFeedLayoutData(),this.topStripeCardProvider=new as.f(this.config.cardProviderConfig),this.config.paginationSentinelHeight&&(this.sentinelHeight=`height: ${this.config.paginationSentinelHeight}px;`);let{nativeAdIndiceRegionFilters:e=[]}=this.config;if(this.nativeAdIndiceRegionFilters=e.map(e=>e.toLowerCase()),this.fetchStripes(this.config.initialLoadCount),this.config.buyDirectInfopaneCard?.primaryServiceClientSettings&&this.config.buyDirectInfopaneCard?.shoppingCarouselAPISettings)try{this.shoppingPrimaryServiceClient=this.shoppingPrimaryServiceClient||new aP.J(window.fetch.bind(window),this.config.buyDirectInfopaneCard.primaryServiceClientSettings,this.config.buyDirectInfopaneCard.shoppingCarouselAPISettings,null,location.href)}catch(e){an.YT.sendAppErrorEvent({...eu.PxO,message:"Failed to initialize buy direct infopane service client",pb:{...eu.PxO.pb,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}}async initFinanceUserService(){try{let e={experienceType:el.ahW,instanceSrc:"default"};if(this.moneyInfoCardWCConfig=(await ae.L.getConfig(e)).properties,!this.financeUserService){let{FinanceServices:e,getFinanceDataConnector:t}=await Promise.all([a.e("node_modules_crypto-js_index_js"),a.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),a.e("libs_finance-service-library_dist_index_js")]).then(a.bind(a,43818));t().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=e.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)}}catch(e){(0,ep.vV)(eu.yIP,`Failed to initialize finance services: ${e.message}`)}}async initBuyDirectUserService(){try{let e={experienceType:el.Yeu,instanceSrc:"index_Buydirect"};this.buyDirectConfig=(await ae.L.getConfig(e)).properties,this.buyDirectServiceClient||(this.buyDirectServiceClient=new aP.J(window.fetch.bind(window),this.buyDirectConfig.primaryServiceClientSettings,this.buyDirectConfig.shoppingCarouselAPISettings,null,location.href))}catch(e){(0,ep.vV)(eu.$oH,`Failed to initialize buy direct services: ${e.message}`)}}async initUserPreferenceFetcherService(){try{this.userPreferenceFetcherService||(this.userPreferenceFetcherService=new aR)}catch(e){(0,ep.vV)(eu.QyC,`Failed to initialize user reference service: ${e.message}`)}}initRiverSectionAndId(){if(this.config.stripePlacementOverwrite){let e=new Set(this.config.stripePlacementOverwrite);Object.entries(this.config.childExperienceReferencesWC).forEach(([t,{hide:a}])=>{a||e.has(t)||an.YT.sendAppErrorEvent({...eu.nlb,message:"stripe key from childExperienceReferencesWC does not exist in stripePlacementOverwrite",pb:{...eu.nlb.pb,customMessage:`stripe key: ${t}`}})});let t=[];for(let e of this.config.stripePlacementOverwrite){let a=this.config.childExperienceReferencesWC[e];a?a.hide||t.push(e):an.YT.sendAppErrorEvent({...eu.nlb,message:"stripe key from stripePlacementOverwrite does not exist in childExperienceReferencesWC",pb:{...eu.nlb.pb,customMessage:`stripe key: ${e}`}})}this.riverSectionIds=t}else{let e=[];Object.keys(this.config.childExperienceReferencesWC).forEach(t=>{this.config.childExperienceReferencesWC[t].hide||e.push(t)}),this.riverSectionIds=e}let e=this.config.riverSectionCardProviderConfig;this.riverSections=this.riverSectionIds.map(t=>{let a=this.config.childExperienceReferencesWC[t];return{...a,riverCardProvider:new as.f((0,ap.A)({},e,a.cardProviderConfig))}})}getExperienceType(){return el.p_1}shadowDomPopulated(){this.columnArrangement=(0,eE.TU)().currentColumnArrangement.toUpperCase(),(0,eE.TU)().subscribe(this.onBreakpointCallback),this.updateShowDot(),window.addEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange),this.config&&this.config.adCookieSyncConfig&&this.config.adCookieSyncConfig.isCookieSyncEnabled&&(this.cookieSyncService=new aw.n(this.config.adCookieSyncConfig||{}),this.cookieSyncService.processCookieSync()),this.setPaginationObserver()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange)}updateShowDot(){let e=this.getDisplayedColumnLayout();this.isShowDot=["C2","C3"].includes(e)||"C4"===e&&this.config.isC5Enabled}async refreshFeed(){this.riverSections.forEach(({riverCardProvider:e})=>e.clearCache()),this.nativeAdPlacementsMap={},this.riverSectionIndex=0,this.initFeedLayoutData(),this.fetchStripes(this.config.initialLoadCount)}initFeedLayoutData(){this.riverSectionLayoutData=Array(this.riverSectionIds.length).fill(void 0)}async fetchStripes(e=this.defaultLoadCount){if(this.isFetchingStripes)return;let t=0;this.isFetchingStripes=!0;let a=()=>{this.isFetchingStripes=!1,(this.isPaginationVisible()||this.config.enableBulkFetch)&&this.riverSectionIndex<this.riverSections.length&&this.fetchStripes(this.config.lazyLoadCount),this.riverSectionIndex>=this.riverSections.length&&(ew.M.singleMark("StripeWC-FullPageLoaded"),this.isFeedExhausted=!0)},r=a_(this.config,"finance"),i=a_(this.config,"buydirect"),o=a_(this.config,"dynamicStripe"),s=[];if((r?.moveStripePosition||r?.personalizeInsertCard)&&s.push(this.fetchFinanceInterests()),o?.enabled&&s.push(this.fetchDynamicInterests()),await Promise.all(s),o?.runBeforeFinanceRanking&&this.updateDynamicSectionRanking(o),o?.skipFinanceRanking&&0!=this.dynamicRankingInterests.length||this.updateFinanceSectionRanking(r),o?.runBeforeFinanceRanking||this.updateDynamicSectionRanking(o),i?.moveStripePosition&&(await this.initBuyDirectUserService(),this.buyDirectServiceClient&&(void 0==this.hasSectionInterest.buydirect&&await this.updateUserBuyDirectInterest(),this.hasSectionInterest.buydirect>0&&(ab(this.riverSectionIds,this.riverSections,void 0,void 0,i.newStripePositionIndex,"1","buydirect"),an.YT.addOrUpdateTmplString("BuyDirectStripeMovedToTop")))),this.riverSectionIndex>0&&this.config.enableBulkFetch){let t=[],r=this.riverSectionIndex;for(let a=r;a<Math.min(this.riverSections.length,r+e);a++){let e=this.riverSectionIds[a],r=this.riverSections[a],{feedId:i,count:o}=r.cardProviderConfig.initialRequest;i===aC||i===am||i===af?t.push(new Promise(e=>e(void 0))):i===ay?t.push(this.fetchLocalNewsRiverContent(o)):t.push(this.fetchRiverContent(e,r))}Promise.all(t).then(async t=>{for(let a=r;a<Math.min(this.riverSections.length,r+e);a++){let e=this.riverSectionIds[a];this.riverSectionResponses[e]=t[a-r],await this.fetchStripe(this.riverSectionIndex++)}this.isFetchingStripes=!1}).catch(async e=>{console.error(e)}).finally(()=>{a()})}else{let r=async()=>{if(this.riverSectionIndex<this.riverSections.length&&t<e){try{await this.fetchStripe(this.riverSectionIndex++),this.riverSectionLayoutData[this.riverSectionIndex-1]&&t++}catch(e){console.error(e)}!this.ttvrFired&&this.riverSectionLayoutData[this.riverSectionIndex-1]&&((0,ai.Qc)().then(async()=>{this.ttvrLogInfo.aboveThefoldReadyAt=performance.now(),this.ttvrFired||(this.setVisuallyReadyMarkers(),an.YT.sendAppErrorEvent({...eu.HR1,message:"TTVR is blocked due to the first image is not available.",pb:{...eu.HR1.pb,customMessage:JSON.stringify(this.ttvrLogInfo)}}))}),await (0,eS.dT)()),await r()}};await r(),a()}}async fetchFinanceInterests(){await this.initFinanceUserService(),this.financeUserService&&(void 0==this.hasSectionInterest.finance||void 0==this.hasSectionInterest.casualGames)&&await this.updateUserFinanceInterest()}async fetchDynamicInterests(){await this.initUserPreferenceFetcherService(),this.userPreferenceFetcherService&&!this.dynamicInterestsFetched&&this.updateDynamicRankingInterests()}updateFinanceSectionRanking(e){e?.moveStripePosition&&this.hasSectionInterest.finance>e.financeInterestScore&&ab(this.riverSectionIds,this.riverSections,e.moveStripeToTopHours,e.moveStripeToIndexHours,e.newStripePositionIndex,e.adsLocStrategy,"finance")}updateDynamicSectionRanking(e){if(this.dynamicRankingInterests.length>0){let t=e.newStripePositionIndex;for(let a=0;a<this.dynamicRankingInterests.length;a++){let r=this.dynamicRankingInterests[a];ab(this.riverSectionIds,this.riverSections,void 0,void 0,t,e.adsLocStrategy,r),-1!=this.riverSectionIds.indexOf(r)&&(t=this.riverSectionIds.indexOf(r)+1)}}}async getWeatherData(e){let t={};t.requestInfo={isStaleRefresh:e};let{PageBase:r}=await a.e("libs_experiences-page-base-wc_dist_index_js").then(a.bind(a,40817));this.weatherDataConnector=await r.getInstance().rootReducer.getDataConnector(ed.ni),this.weatherDataConnector&&(this.activeLocation=await this.weatherDataConnector.fetchActiveStateforWeather(null,null,t))}async fetchAutosData(e){try{let t=await ev(this.autosData.enableStaticResponse,n.MSNHomePage);t.includes("Listing")?(this.autosData.data=t,this.updateStripes(e)):this.autosData.fallbackToContentCard=!0}catch(e){this.autosData.fallbackToContentCard=!0,(0,ep.c_)(e,eu.uqN,"send request to segments api failed")}}async fetchStripe(e){let t,a=this.riverSections[e],r=this.riverSectionIds[e],{feedId:i,count:o}=a.cardProviderConfig.initialRequest,s=!1,n=[];if(0===e&&this.ttvrLogInfo.topStripeStartAt.push(performance.now()),this.hasMoneyInfoCardWC(r)&&!this.loadedWebComponents.includes[l.moneyInfoCardWC]?this.fetchMoneyInfoCardData(r):this.hashealthArticleInfoCardWC(r)&&!this.loadedWebComponents.includes[l.healthArticlesCardWC]?this.fetchHealthInfoCardData(r):this.hasTravelDestinationCardWC(r)&&!this.loadedWebComponents.includes[l.travelDestinationCard]&&this.fetchTravelDestinationCardData(r),i===aC)n=Array(o).fill({type:ek.pL.Article});else if(i===am||i===af)n=this.createStripeAdCardDefaultMetadata(o),this.config.cmsAdPlacements?.[r]&&this.loadNativeAd(r,!0),this.loadNativeAd(r),s=!0;else if(i===ay){await this.getWeatherData(),t=this.riverSectionResponses[r]||await this.fetchLocalNewsRiverContent(o);let e=at.Rb.Locale;if(at.Rb.ClientSettings.locale.market===this.activeLocation.isoCode.toLowerCase()){let{locality:r,displayName:i}=this.activeLocation;(0,au.A)(t,"value[0].subCards[0].feed.feedName",r),a.riverSectionTitle=i,"es-ar"!=e&&(a.seeMoreUrl+="local"),n=t.subCards||[]}}else t=this.riverSectionResponses[r]||await this.fetchRiverContent(r,a),t?.cardMetadata?.length?(ey.WR.removeOcidFromRiverCardProviderResponse(t),n=t.cardMetadata,this.loadNativeAd(r),0===e&&this.ttvrLogInfo.topStripeFetchedAt.push(performance.now())):this.retryFetchingStripe(e),s=!0;this.addRiverSection(e,a,n,s)}async retryFetchingStripe(e){let t=this.config.retryTimeOutMs&&this.config.retryTimeOutMs>=0?this.config.retryTimeOutMs:1e3,a=this.config.maxRetryTimes&&this.config.maxRetryTimes>=0?this.config.maxRetryTimes:0,r=this.riverSectionIds[e];this.retryCountRecord[r]||(this.retryCountRecord[r]=0),this.retryCountRecord[r]>=a||(this.retryCountRecord[r]++,an.YT.sendAppErrorEvent({...eu.sOF,message:`Start retrying to fetch [${r}] in ${t}ms.`,pb:{...eu.sOF.pb,customMessage:`Retry count: ${this.retryCountRecord[r]}`}}),window.setTimeout(async()=>{0===e&&this.ttvrLogInfo.topStripeRetryAt.push(performance.now()),await this.fetchStripe(e),0===e&&await this.initTopStripeNativeAds()},t))}addRiverSection(e,t,a=[],r=!0){let i=a.filter(e=>{if(eD[e.type])return e;an.YT.sendAppErrorEvent({...eu.vES,message:"Unsupported content card type in OneService metadata.",pb:{...eu.vES.pb,customMessage:`Card type [${e.type}] needs to be added to MSNHomepageOneServiceMetadataTypeToCardTypeMap`}})});if(!i?.length)return;let o=this.riverSectionIds[e],s=t.riverSectionTemplate,n=i,d=[],{adPlacements:c={},cmsAdPlacements:p={},insertCardInSlot:u={}}=this.config,h=this.config.slotToCardType||{},g=(0,ah.A)(h[o])||[],{backfillMetadata:y,backfillCardTypeSlot:m,backfillTemplateId:f}=aX(o,n,this.config.childExperienceReferencesWC?.[o]?.backfillConfigs);n=y||n,g=m||g;let C=tb[s=f||s]||{},v=a_(this.config,o);v?.personalizeInsertCard&&this.hasSectionInterest[o]>0&&(u[o]=u[o].filter(e=>e?.cardType!==v.cardToDisable));let x=[...c[o]?.placements||[],...p[o]?.placements||[]],b=[...g||[],...u[o]||[]];x.forEach(e=>{e&&e.region!==ek.pL.Infopane&&e?.indices.forEach(e=>{let t=e-1;d.includes(t)||d.push(t)})});let _=[];b.forEach(e=>{if(e&&e?.cardType!==l.contentCard&&e?.cardType!==l.videoCard&&e?.cardType!==l.pollsCard){if(e?.cardType===l.denseCard)return void e.positions?.forEach(t=>{let a=parseInt(t.slot.replace("slot",""))-1;_.push({index:a,count:e.args?.denseListSize||0})});e.positions?.forEach(e=>{let t=parseInt(e.slot.replace("slot",""))-1;_.forEach(e=>{e.index<t&&(t+=e.count-1)}),d.includes(t)||d.push(t)})}}),(d=d.sort((e,t)=>e>t?1:e<t?-1:0)).forEach(e=>{let t=n.pop();n.splice(e,0,t)}),this.riverSectionLayoutData[e]={cardMetadataList:n,feedData:this.mapFeedData(o,n,C,this.config.openLinksInNewTab,this.telemetryObject,g,e),hasPlaceHolderAds:r,insertBannerAd:t?.insertBannerAd,pivotsNav:t?.pivotsNav,riverSectionTitle:t?.riverSectionTitle,riverSectionTitleUrl:(0,aa.bI)(t?.riverSectionTitleUrl?t.riverSectionTitleUrl:t?.seeMoreUrl),riverSectionTitleColor:t?.riverSectionTitleColor,seeMoreUrl:(0,aa.bI)(t?.seeMoreUrl),seeMoreText:t?.seeMoreText,adLabel:t?.adLabel,sectionId:o,telemetryName:t?.telemetryName,templateId:s,adSlugGA:this.config.adSlugGA,isMsnHPAdSlug:this.config.isMsnHPAdSlug,enableSafeAds:!!this.config?.enableSafeAds,disableSlider:this.config.disableStripeSlider,leftArrow:this.config.localizedStrings.previousArrow,rightArrow:this.config.localizedStrings.nextArrow,disableStripeTheme:this.config.disableStripeTheme,isC5Enabled:this.config.isC5Enabled,isDVEnabled:this.config?.isDVEnabled},0===e&&((0,eS.yi)(`${this.getExperienceType()}TopStripeRendered`),this.ttvrLogInfo.topStripeRenderedAt=performance.now()),"shopping"===o&&this.config.overrideBingUrlsAugmentations&&(this.riverSectionLayoutData[e].riverSectionTitleUrl=eA.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[e].riverSectionTitleUrl,"msn"),this.riverSectionLayoutData[e].seeMoreUrl=eA.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[e].seeMoreUrl,"msn")),this.riverSectionLayoutData=[...this.riverSectionLayoutData]}async addFlipperStyles(){let e,t=await (e=this.shadowRoot,new Promise(t=>{let a=new MutationObserver((0,ad.A)(()=>{t(e.querySelectorAll("msft-horizontal-card-slider")),a.disconnect()}));a.observe(e,{childList:!0,subtree:!0})}));if(t?.length&&t[0].shadowRoot)for(let e=0;e<t.length-1;e++)ac(t[e].shadowRoot,az)}async fetchRiverContent(e,t){let a,r=this.riverSectionIds[0],i="";e===r&&(i=` TTVR log: ${JSON.stringify(this.ttvrLogInfo)}`);try{if(e===r){if(ar.WD&&t.enableWebWorker&&!this.config.disableWWForTopStripe){let e=this.config?.cardProviderConfig?.initialRequest?.timeoutMs||1e3;a=await t.riverCardProvider.fetchFromWebWorker("myfeed",e)}else window.enableEarlyRiverRequest&&window.topStripeResponse&&(window.enableEarlyRiverRequest=!1,a=window.topStripeResponse);a?.cardMetadata?.length||(a=await this.topStripeCardProvider.fetch())}else a=await t.riverCardProvider.fetch({})}catch(t){an.YT.sendAppErrorEvent({...eu.sOF,message:`Content fetch failed for Stripe WC river section when loading ${e}`,pb:{...eu.sOF.pb,customMessage:`Failed with exception : ${JSON.stringify(t)} ${i}`}})}if(a?.cardMetadata?.length){if(e!==r&&a.cardMetadata[0]?.type===ek.pL.Infopane)a.cardMetadata=a.cardMetadata.filter(e=>e.type!==ek.pL.Infopane);else if(e===r&&a.cardMetadata[0]?.type===ek.pL.Infopane){let e=this.config.cardProviderConfig?.initialRequest?.infopaneItemCount;e&&a.cardMetadata[0].subItems.length>e&&(a.cardMetadata[0].subItems=a.cardMetadata[0].subItems.slice(0,e))}"esports"===e&&a?.cardMetadata?.length<8&&an.YT.sendAppErrorEvent({...eu.nZM,message:`Content fetch content is less than 8 for Stripe WC river section when loading ${e}`,pb:{...eu.nZM.pb,customMessage:`Returned response: ${JSON.stringify(a)} ${i}`}})}else an.YT.sendAppErrorEvent({...eu.uIm,message:`Content fetch failed for invalid empty Stripe WC river section when loading ${e}`,pb:{...eu.uIm.pb,customMessage:`Returned response: ${JSON.stringify(a)} ${i}`}});return a}async fetchLocalNewsRiverContent(e){let t,r,{PageBase:i}=await a.e("libs_experiences-page-base-wc_dist_index_js").then(a.bind(a,40817));this.weatherDataConnector=await i.getInstance().rootReducer.getDataConnector(ed.ni);let{latitude:o,longitude:s}=this.weatherDataConnector.getCurrentState().currentLocation||this.activeLocation,n=`${o}|${s}`,{apikey:l}=this.config,{ocid:d}=this.config.riverSectionCardProviderConfig.initialRequest,c=eh.T3.CurrentMarket;r=`${eh.T3.AssetsUrl}/service/MSN/Feed/me?$top=${e}&cm=${c}&location=${n}&ocid=${d}&apikey=${l}&cipenabled=false&DisableTypeSerialization=true&query=localnews&queryType=myfeed&wrapodata=false&responseSchema=cardview`,this.has1SFlight("1s-viewurldomain")&&(r=`${r}&fdhead=1s-viewurldomain`);try{t=await fetch(r)}catch(e){an.YT.sendAppErrorEvent({...eu.sOF,message:"Content fetch failed for Local News River section.",pb:{...eu.sOF.pb,url:r,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}return t?.json()}async fetchShoppingCarouselData(e){try{this.shoppingCarouselData.data?.length?this.updateStripes(e):this.shoppingCarouselData.fallbackToContentCard=!0}catch(e){this.shoppingCarouselData.fallbackToContentCard=!0}}async fetchShoppingCarouselBDData(e){let t=await e.getShoppingEntitiesDataUsing1S(!0,1e3);return t||null}async getBuyDirectCard(){let e=await this.fetchShoppingCarouselBDData(this.shoppingPrimaryServiceClient);if(!e||!e.shoppingEntities||!e.shoppingEntities.length)return an.YT.sendAppErrorEvent({...eu.ca0,message:"No buy direct infopane card data from 1S.",pb:{...eu.ca0.pb,customMessage:"No buy direct infopane card data from 1S."}}),null;let t=e.shoppingEntities[0];if(!t.globalOfferId||!t.title||!t.imageInfo.sourceImageUrl)return an.YT.sendAppErrorEvent({...eu.ca0,message:"Invalid buy direct infopane card data data from 1S.",pb:{...eu.ca0.pb,customMessage:"Invalid buy direct infopane card data from 1S."}}),null;let a=this.config.buyDirectInfopaneCard.formcode,r=this.config.buyDirectInfopaneCard.trafsrc,i=this.config.bwmCampaignCode??"",o=this.config.bdBlurredBackground?"InfoBuyDirectCard":"BuyDirectCard";o+=this.config.buyDirectEventDecoration?this.config.buyDirectEventDecoration:"",o+=this.config.disableBuyDirectCashback?"_NoCashback":"";let s=e$.u.buildAbsoluteUrl({market:eh.T3.CurrentMarket,pid:t.globalOfferId,title:t.title,trafsrc:r,ocid:r,formCode:a,isBing:this.config.bdDirectToBing,isBWM:this.config.isBWM,campaignCode:i}),n=t.cashbackInfo?.cashbackPercentage&&t.cashbackInfo?.cashbackPercentage>0?`${t.cashbackInfo.cashbackPercentage}%`:void 0;this.config?.enableForumCashback&&!n&&an.YT.sendAppErrorEvent({...eu.LOQ,message:"Buy Direct stripe offer failed to fetch dynamic cashback",pb:{...eu.LOQ.pb,customMessage:"Empty cashback info"}});let l=(0,eI.Yd)((0,eI.Lm)()),d=n||l,c=d?`Buy with Microsoft - ${d} Cash back and free shipping on all orders`:"Buy with Microsoft - Earn Cash back";return{type:"link",cardContent:{abstract:c=this.config.disableBuyDirectCashback?"Buy with Microsoft - Free shipping on all orders":c,destinationUrl:`${s}`,id:`${t.id}`,kicker:`${t.title}`,title:`${t.priceInfo?.price?t.priceInfo.price+" ":""}${t.title}`,type:"link",category:{product:"news"},images:[{id:`${t.globalOfferId}`,url:`${t.imageInfo.sourceImageUrl}`}]},id:o}}getInfopaneCardOverride(e,t,a,r,i,o){return{type:"link",cardContent:{destinationUrl:r,title:i,type:"link",category:{product:"news"},images:[{url:(0,eP.Je)(o,a,t)}]},id:e}}mapFeedData(e,t,a,r,i,o,s){if(!t||!t.length||!a)return null;let n={defaultLayout:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]},{rowHeightPx:d,colWidthPx:c,gutterPx:p,cardSlots:u=[]}=a,h=s>2?s-2:s-1,g="topStripe"===e?{C5:0,C4:0,C3:0,C2:0}:{C5:4+3*h,C4:4+3*h,C3:4+3*h,C2:6+3*h},y=this.columnArrangement.toLowerCase(),{slotToCardType:m={},insertCardInSlot:f={}}=this.config,C={...this.config.infopaneConfig||{}},v={};return f[e]&&f[e].forEach(({cardType:a,positions:r,args:i})=>{let o=r.find(e=>!e.column||e.column===y);if(o){let r=u.findIndex(e=>e.grid_area===o.slot);if(v[o.slot]=a,r>-1){let o={type:a3,cardContent:{insertedCardType:a,insertedCardArgs:i},id:`${a}-slot-${r+1}`};if(t[r]?.id===o.id)return;if(a===l.pollsCard){let a=i.pollsCardConfigInfo.instanceId===av,s=a?this.pollsData.quiz:this.pollsData.poll;!s.fallbackToContentCard&&(s.fetchingTriggered?s.data&&(t[r]&&t.push(t[r]),t[r]=o):this.fetchQuizData(e,a))}else if(a===l.denseCard){let{denseListSize:e,denseDataConfigOptions:a}=i,s=t.splice(r,e);a?.enableDenseLayout1&&s.unshift(s[0]),o.subItems=s,t.splice(r,0,o)}else if(a===l.shoppingCarouselCard){let a=["index_LiveShopping_Shopping","index_LiveShopping_Lifestyle"];a.includes(i.configOptions.configRef.instanceSrc)&&!this.shoppingCarouselData?.fallbackToContentCard&&(this.shoppingCarouselData.data?.length?(t[r]&&t.push(t[r]),t[r]=o):this.fetchShoppingCarouselData(e)),(this.shoppingCarouselData.data?.length||!a.includes(i.configOptions.configRef.instanceSrc))&&(t[r]&&t.push(t[r]),t[r]=o)}else t[r]&&(t.push(t[r]),this.customInsertedCards[a]={metadataIndex:r,cardData:t[r],backupIndex:t.length-1}),t[r]=o}}else if(this.customInsertedCards[a]){let{metadataIndex:e,cardData:r,backupIndex:i}=this.customInsertedCards[a];t.splice(i,1),t[e]=r,this.customInsertedCards[a]=void 0}}),u.forEach((a,s)=>{let u=t[s];if(!u)return;let h=u.cardContent?.insertedCardType||eD[u.type],f=o||m[e],x=f?f.find(({positions:e})=>e.some(e=>(!e.column||e.column&&e.column===y)&&e.slot===a?.grid_area)):null;if(x&&(h=x.cardType),!h)return;let b=parseFloat(a?.grid_area?.replace("slot","")),_=null,w=()=>this.config.enableNewTTVR?this.getVisualReadinessCallback(u,h,b):this.setVisuallyReadyMarkers;if(!this.ttvrFired){if(e===this.riverSectionIds[0]){if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&h===l.infopaneCard)this.visualReadinessCallbackSet=!0,_=w(),u.subItems=u.subItems.map(e=>({...e,visualReadinessCallback:_})),this.ttvrLogInfo.ttvrBoundedImage.push(`today hero infopane: ${u.subItems[0]?.cardContent?.images[0]?.url}`);else if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&h===l.contentCard){this.visualReadinessCallbackSet=!0;let e=(0,t_.Ie)(u);e&&(this.ttvrLogInfo.ttvrBoundedImage.push(`today hero content: ${e.url}`),_=w())}}else if(h===l.contentCard){let e=(0,t_.Ie)(u);e&&(this.ttvrLogInfo.ttvrBoundedImage.push(`river content: ${e.url}`),_=this.setVisuallyReadyMarkers)}}let S={...this.config,...this.config.childExperienceReferencesWC[e],isMsnHpExternalLinkCard:"link"===u.type},E=this.nativeAdPlacementsMap[e];(h===l.nativeAdCard||h===l.infopaneCard)&&E?.length&&(S.isGreyAdsLabelEnabled=E[0]?.isGreyAdsLabelEnabled),u.type===ek.pL.Infopane&&(S.useMsnHomepageCardTemplate=!0,this.ttvrFired||(C.disableAutoRotate=!0));let A=u?.cardContent?.insertedCardArgs?.pollsCardConfigInfo?.instanceId===av?this.pollsData.quiz:this.pollsData.poll;(!this.ttvrFired&&u.type===a3||this.getSectionAdPlacementIndices(e).includes(b)&&!this.nativeAdIsLoaded[e]||v[a?.grid_area]===l.pollsCard&&A.isFetching)&&(h=l.placeholderCard);let $=(u?.cardContent?.type||u?.type)===ek.pL.WebContent,I={cardMetadata:u,cardSlot:a,parentTelemetryObject:i,openLinksInNewTab:r||S.isMsnHpExternalLinkCard,openLinksInCurrentTab:!r&&!S.isMsnHpExternalLinkCard,isAnaheimDesign:!0,refreshFeedCallback:()=>this.refreshFeed(),visualReadinessCallback:_,localizedStrings:this.config.localizedStrings||{},isProviderInFooter:!0,hideComments:$,enableRichSocialReaction:!!this.config.childExperienceReferences?.socialBarWC,initCardAction:this.initCardAction,configOptions:{...S,disableOptedOutButton:!0,enableWCCardAction:!0,enableHoverCardAction:!!this.config.childExperienceReferences?.cardAction,useSmallFontSize:h!==l.infopaneCard,isImage32:!0,useHomepageTelemetry:!0,enableWebContentSocialReactions:!0,socialBarInRight:!0,providerOnTop:!0,providerOnTopInfopane:!0,hideCommentsInHalfUCards:!0,disableSlideShow:!this.overrideHasSlideShow&&this.config.disableSlideShow},isIASEnabled:this.config.isIASEnabled,appendIdxForId:this.config.appendIdxForId,rowHeightPx:d,colWidthPx:c,gutterPx:p,rowCount:g};if(u.cardContent?.insertedCardArgs&&(I=(0,ap.A)({},I,u.cardContent.insertedCardArgs)),x&&(I=(0,ap.A)({},I,x.args)),I.configOptions.useInfopaneSlideTemplate&&(I.immersiveCard=!0),h===l.infopaneCard){if(!this.infopaneSubItems?.length&&u?.subItems?.length&&(this.infopaneSubItems=u.subItems.slice()),this.ttvrFired||(this.config.enableDenseSlide&&this.config.denseListSize?u.subItems=u.subItems.slice(0,this.config.denseListSize+1):u.subItems=u.subItems.slice(0,1)),I=(0,ap.A)({},I,C),this.config.enableDenseSlide&&this.config.denseListSize){let e=this.config.denseCardCount||1,t=this.config.denseListSize+1,a=I.cardMetadata.subItems,r=[];for(let i=0;i<e;i++){let e=i*t,o=(i+1)*t,s={size:0,subItems:a.slice(e,o).map(e=>({...e,visualReadinessCallback:void 0})),type:"densetab",visualReadinessCallback:a&&a[0].visualReadinessCallback};s.subItems.length>0&&r.push(s)}a.splice(e*t).forEach(e=>{r.push(e)}),I.cardMetadata.subItems=r}else if(I.cardMetadata?.subItems?.length){let e=I.cardMetadata.subItems;I.cardMetadata.subItems=e.map(e=>e?.subItems&&e?.subItems.length>0?e.subItems[0]:e)}}if((h===l.contentCard||h===l.infopaneCard)&&this.ttvrFired&&this.config.childExperienceReferences?.socialBarWC&&(0,aG.uC)(this.config.childExperienceReferences.socialBarWC),"video"===e&&h===l.contentCard&&u.type===ek.pL.WebContent){let e=I.cardMetadata&&I.cardMetadata.cardContent;if(e){let{destinationUrl:t,title:a,id:r}=e;I.cardMetadata.cardContent.destinationUrl=(0,aV.C)(r,t,a)}}if(this.ttvrFired&&h===l.trendingNowCard&&!this.loadedWebComponents.includes(l.trendingNowCard))try{(0,aG.uC)(I.configOptions),this.loadedWebComponents.push(l.trendingNowCard)}catch(e){an.YT.sendAppErrorEvent({...eu.oUl,message:"Failed to load Trending Now WC",pb:{...eu.oUl.pb,errorMessage:JSON.stringify(e)}})}if(this.ttvrFired&&h===l.pollsCard){let e=u.cardContent.insertedCardArgs.pollsCardConfigInfo.instanceId===av;I.cardMetadata.data=e?this.pollsData.quiz.data:this.pollsData.poll.data}if(this.ttvrFired&&h===l.moneyInfoCardWC&&(this.moneyInfoCardWCData?I.cardMetadata.data=this.moneyInfoCardWCData:I.cardMetadata.data="{}",this.loadedWebComponents.includes(l.moneyInfoCardWC)||((0,aG.uC)(I.configOptions),this.loadedWebComponents.push(l.moneyInfoCardWC))),this.ttvrFired&&h===l.healthArticlesCardWC&&(I.cardMetadata.data=this.healthInfoCardWCData||"{}",this.loadedWebComponents.includes(l.healthArticlesCardWC)||((0,aG.uC)(I.configOptions),this.loadedWebComponents.push(l.healthArticlesCardWC))),this.ttvrFired&&h===l.travelDestinationCard){let e;I.cardMetadata={...I.cardMetadata,...this.travelDestinationCardWCData};let t=this.travelDestinationCardWCData?.dataType;e=["HotelList","HotelListingResult"].includes(t)?el.S6:e,e=["FlightPriceTrends","FlightPriceTrendsList"].includes(t)?el.aJb:e,e=["ThemeCardList","ThemeInspiration"].includes(t)?el.znl:e,(e=["DestinationList","Destination"].includes(t)?el.Qs5:e)&&I.configOptions.configRef?.experienceType&&(I.configOptions.configRef.experienceType=e),this.loadedWebComponents.includes(l.travelDestinationCard)||((0,aG.uC)(I.configOptions),this.loadedWebComponents.push(l.travelDestinationCard))}let P=t9[h].getFeedDataForCard(I);h===l.denseCard&&u.cardContent.insertedCardArgs?.denseDataConfigOptions&&(P.defaultLayout[0].denseData.configOptions=u.cardContent.insertedCardArgs?.denseDataConfigOptions),Object.keys(P).forEach(e=>{n[e]&&(n[e]=n[e].concat(P[e]))})}),n}async fetchQuizData(e,t){let r;r=this.config.disableQuizCard?t?null:this.config.pollsCardWCConfig:t?this.config.quizCardWCConfig:this.config.pollsCardWCConfig;let i=t?"quiz":"poll";if(this.pollsData[i].fetchingTriggered=!0,this.pollsData[i].isFetching=!0,r)try{let{contentId:o,timezoneDiffToUTC:s}=r,{PollsCardWCActionServiceClient:n}=await a.e("polls-service").then(a.bind(a,50612)),l=new n(window.fetch.bind(window)),d=await l.getPollsData(o,t,s);d?.length>0?this.pollsData[i].data=d:this.pollsData[i].fallbackToContentCard=!0,ew.M.singleMark("StripeWC-PollsCardLoadEnd"),this.pollsData[i].isFetching=!1,this.updateStripes(e)}catch(t){this.pollsData[i].fallbackToContentCard=!0;let e={...eu.V9L,message:"Failed fetching Poll/Quiz data for stripe wc",pb:{...eu.V9L.pb,customMessage:t.message}};an.YT.sendAppErrorEvent(e)}else this.pollsData[i].fallbackToContentCard=!0}async initTopStripeNativeAds(){let e=this.riverSectionIds[0];try{if(!this.ttvrFired||!this.riverSectionLayoutData[0])return;await this.initNativeAdService();let t=[this.fetchNativeAdsContent(e),this.fetchNativeAdsContent(e,!0)];Promise.all(t).then(t=>{let[a=[],r=[]]=t;this.updateAdPlacementData(e,[...a,...r]),ew.M.singleMark("StripeWC-topStripeReady"),this.startInfopaneAutoRotation(),this.ttvrLogInfo.topStripeAdsReadyAt=performance.now()})}catch(t){an.YT.sendAppErrorEvent({...eu.sHf,message:"Error when fetching top stripe nativeAds data",pb:{...eu.sHf.pb,errorMessage:JSON.stringify(t)}}),this.updateStripes(e),this.startInfopaneAutoRotation();return}}hasTravelDestinationCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.travelDestinationCard&&(a=!0)}),a}hashealthArticleInfoCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.healthArticlesCardWC&&(a=!0)}),a}hasMoneyInfoCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.moneyInfoCardWC&&(a=!0)}),a}async updateUserFinanceInterest(){let e=await this.financeUserService.getFinanceInterest();e&&(this.hasSectionInterest.finance=0,e.explicit?.length>0&&(this.hasSectionInterest.finance+=1e3),e.implicit?.length>0&&(this.hasSectionInterest.finance+=1))}async updateDynamicRankingInterests(){this.dynamicRankingInterests=await this.userPreferenceFetcherService.getUserPreferences(),this.dynamicInterestsFetched=!0}async updateUserBuyDirectInterest(){await this.buyDirectServiceClient.hasBuyDirectInterest()&&(this.hasSectionInterest.buydirect=1)}async fetchTravelDestinationCardData(e){await aK.Iw.GetSDCardData().then(t=>{t&&Array.isArray(t)&&t.length>0&&(this.travelDestinationCardWCData=t[0],this.travelDestinationCardWCData&&this.travelDestinationCardWCData.length>0&&this.updateStripes(e))})}async fetchHealthInfoCardData(e){let t=eh.T3.CurrentMarket,a=`recommendations|articleData|1|${t}`;await aI.getDataFromOneService(a,t,!0).then(t=>{t&&(this.healthInfoCardWCData=JSON.stringify(t),this.healthInfoCardWCData&&this.healthInfoCardWCData.length>0&&this.updateStripes(e))})}async fetchMoneyInfoCardData(e){let t={experienceType:el.ahW,instanceSrc:"default"};this.moneyInfoCardWCConfig=(await ae.L.getConfig(t)).properties;try{if(!this.financeUserService||!this.financeAutoSuggestService||!this.financeService){let{FinanceServices:e,getFinanceDataConnector:t}=await Promise.all([a.e("node_modules_crypto-js_index_js"),a.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),a.e("libs_finance-service-library_dist_index_js")]).then(a.bind(a,43818));this.financeUserService||(t().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=e.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)),this.financeAutoSuggestService=e.getAutoSuggestService(),this.financeService=e.getCachedFinanceService()}let t={userSignedIn:!1,dataFrom:"watchlist",dataTimestamp:null,data:null,fullWatchlistQuoteIds:null};if(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)t.userSignedIn=!0;else{let{getUserSignInState:e}=await a.e("libs_auth_dist_index_js").then(a.bind(a,9788));t.userSignedIn=await e()===2}let r=[];(t.userSignedIn||this.moneyInfoCardWCConfig.enableUnsignedWatchlist)&&(t.fullWatchlistQuoteIds=r=await this.financeUserService.getWatchlist(!1)),r&&0!==r.length||this.moneyInfoCardWCConfig.enableUnsignedWatchlist?t.dataFrom="watchlist":t.dataFrom="market";let i="watchlist"===t.dataFrom?r:this.moneyInfoCardWCConfig.apiConfig.marketQuoteIds;this.financeService.cleanCache();let o=await this.financeService.getRecommendation()||this.moneyInfoCardWCConfig.apiConfig.recommendedQuoteIds,s=[i,o],n=[].concat(...s),l=await this.financeService.getQuoteSummary(n),d={};l.forEach(e=>{e?.id&&(d[e.id]=e)});let[c,p]=s.map(e=>e.map(e=>d[e]).filter(e=>e));t.data={recommend:{quoteItems:p,quoteIds:p.map(e=>e.id)},[t.dataFrom]:{quoteItems:c,quoteIds:c.map(e=>e.id)}},t.data.watchlist||(t.data.watchlist={quoteItems:[],quoteIds:[]}),t.dataTimestamp=new Date().getTime();let u=[...this.moneyInfoCardWCConfig.defaultTabs];"watchlist"!==t.dataFrom&&u.splice(u.indexOf("watchlist"),1);let h={userSignedIn:t.userSignedIn,dataFrom:t.dataFrom,fullWatchlistQuoteIds:"watchlist"===t.dataFrom?i:[],recommendQuoteItems:p,tabListDetails:t.data,notifications:null,tabs:u};this.moneyInfoCardWCData=JSON.stringify(h),this.updateStripes(e)}catch(e){an.YT.sendAppErrorEvent({...eu.B0w,message:"MoneyInfoCard content fetch failed",pb:{...eu.B0w.pb,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}}getDisplayedColumnLayout(){let e=this.columnArrangement;if(!this.enableRail||!e)return e;let t=parseInt(e.replace("C",""),10);return Number.isNaN(t)?e:`C${t-1}`}updateStripes(e){this.updateRiverSections(e),this.config.stripeStyles&&this.processLayoutStyles(),a0&&e&&(0,e_.CI)(a4(e))}updateRiverSections(e){this.riverSectionLayoutData=this.riverSectionLayoutData.map((t,a)=>{if(!t)return;let{templateId:r,sectionId:i}=t,o=tb[r];if(void 0!==e&&e!==i)return t;let s=(0,ah.A)(this.config.slotToCardType?.[i]||[])||[],n=t.cardMetadataList,{backfillCardTypeSlot:d,backfillMetadata:c,backfillTemplateId:p}=aX(i,n,this.config.childExperienceReferencesWC?.[i]?.backfillConfigs);if(n=c||n,s=d||s,o=p?tb[p]:o,!t.hasPlaceHolderAds&&e!==i)return{...t,feedData:this.mapFeedData(i,t.cardMetadataList,o,this.config.openLinksInNewTab,this.telemetryObject,s,a)};{let r=this.nativeAdPlacementsMap[i];if(r&&t?.cardMetadataList?.length===r.length){let e=!1;if(r.forEach(t=>e=e||this.hasAdsContent(t)),!e)return void(0,ep.vV)(eu.Koy,"No ads content for entire stripe",`sectionId: ${i}, adsConfig: ${this.config.adPlacements?.[i]}, cmsConfig: adsConfig: ${this.config.adPlacements?.[i]}`)}let d=r?.filter(e=>e.region===ek.pL.Infopane),c=r?.filter(e=>e.region!==ek.pL.Infopane),p=n.map((a,r)=>{if(a.type===ek.pL.Infopane){if(!this.ttvrFired||!this.nativeAdIsLoaded[e])return a;if(a.subItems=this.infopaneSubItems.slice(),d?.length){let e=d.sort((e,t)=>e.regionIndex>t.regionIndex?1:e.regionIndex<t.regionIndex?-1:0),t=[];e.forEach(e=>{let r=e.regionIndex-1;!t.includes(r)&&a.subItems[r]&&this.hasAdsContent(e)&&(t.push(r),a.subItems.splice(r,0,this.createNativeAdCardMetadata(e)))})}if(this.shouldOverrideInfopaneCards&&this.ttvrFired&&"topStripe"==e)for(let e=0;e<a?.subItems?.length;e++){let t=a.subItems[e];if(t?.id&&this.replacementInfopaneCards[t.id]){let r=this.replacementInfopaneCards[t.id];a.subItems[e]=r.card,r.tmplStringPrefix&&an.YT.addOrUpdateTmplString(`${r.tmplStringPrefix}-${t.cardContent.id}`)}}return a}{let e,i=0;for(let e=0;e<r;e++)t.cardMetadataList[e].type===a3&&t.cardMetadataList[e].subItems?.length?i+=t.cardMetadataList[e].subItems.length-1:i++;return(a.cardContent?.insertedCardType===l.denseCard?c?.forEach(e=>{if(this.hasAdsContent(e)&&e.regionIndex>i){let t=e.regionIndex-i,r=a.subItems?.[t];r&&r.type!==ek.pL.NativeAd&&(a.subItems[t]=this.createNativeAdCardMetadata(e))}}):e=c?.find(e=>e.regionIndex===i+1),e&&this.hasAdsContent(e))?this.createNativeAdCardMetadata(e):a}});return{...t,feedData:this.mapFeedData(i,p,o,this.config.openLinksInNewTab,this.telemetryObject,s,a),hasPlaceHolderAds:!1,cardMetadataList:(0,ah.A)(p)}}})}updateAdPlacementData(e,t){let a=this.nativeAdPlacementsMap[e];a?.length&&t?.length&&a.forEach((e,r)=>{let i=t.filter(t=>t.region===e.region&&t.regionIndex===e.regionIndex)[0];i?.items?.length&&(a[r]=i)}),this.updateStripes(e)}async fetchNativeAdsContent(e,t){let a=this.getAdRequestForRiver(e,t),r=at.Rb.Locale,i=ax[r]||ec.F3[r];if(!a)return;r&&(a.locale=r);let o=[];try{await this.initNativeAdService(),a.placements?.length&&(a=(0,ah.A)(a)).placements.forEach(e=>{this.nativeAdIndiceRegionFilters.length&&!this.nativeAdIndiceRegionFilters.includes(e.region.toLowerCase())&&(e.indices=e.indices.map((e,t)=>t+1))}),ew.M.startMark(a2);let{placements:r,adLabelText:s,isGreyAdsLabelEnabled:n}=t?await this.nativeAdService.fetchCmsAds(a,i,[]):await this.nativeAdService.fetchNativeAds(a);r?.length&&r.forEach(a=>{e===this.riverSectionIds[0]||this.nativeAdIndiceRegionFilters.includes(a.region.toLowerCase())||(t?this.config.cmsAdPlacements?.[e]:this.config.adPlacements?.[e]).placements.forEach(e=>{e.region===a.region&&(a.regionIndex=e.indices[a.regionIndex-1])}),a.adLabelText=s,a.isGreyAdsLabelEnabled=n,this.config.isMsnHPAdSlug&&(a.isGreyAdsLabelEnabled=!1),o.push(a)})}catch(t){this.nativeAdIsLoaded[e]=!0,(0,ep.c_)(t,eu.sHf,"Call to Ad Service failed")}finally{ew.M.endMark(a2),this.nativeAdIsLoaded[e]=!0}return o}async initNativeAdService(){if(!this.nativeAdService){let{NativeAdService:e}=await a.e("libs_ad-service_dist_index_js").then(a.bind(a,73487));this.nativeAdService=new e(void 0,this.config&&this.config.adServiceConfig)}}loadNativeAd(e,t){this.ttvrFired&&this.fetchNativeAdsContent(e,t).then(t=>{this.updateAdPlacementData(e,t)})}createStripeAdCardDefaultMetadata(e){let t=[];for(let a=1;a<=e;a++)t.push({type:ek.pL.NativeAd,regionIndex:a,placement:{items:[]}});return t}createNativeAdCardMetadata(e){if(e?.items?.length)return{type:ek.pL.NativeAd,id:`${ek.pL.NativeAd}-${e.regionIndex}`,placement:e}}hasAdsContent(e){return Object.keys(e?.items[0]||{}).length>0}getAdRequestForRiver(e,t){let a,r=t?this.config.cmsAdPlacements?.[e]:this.config.adPlacements?.[e];if(r){if(r?.placements){let t=[];if(r.placements.forEach(e=>{if(e.region.indexOf(ek.pL.Infopane)>=0)t.push({...e,img:this.config.adTemplateConfig?.imageSizeConfig?.infopane});else{let a=e.indices;if(a.length){let r={...e,indices:a};t.push(r)}}}),t.length){let i=this.getDefaultAdPlaceholderPlacements(t);this.nativeAdPlacementsMap[e]?this.nativeAdPlacementsMap[e].push(...i):this.nativeAdPlacementsMap[e]=i,a={placements:t,pageType:r.pageType}}}return a}}getDefaultAdPlaceholderPlacements(e){let t=[];return e&&e.forEach(e=>{let a=e.indices.map(t=>({...e,regionIndex:t,items:[{}]}));t=t.concat(a)}),t}getNavigationButonTelemetryTag(e){return(0,aN.N)(e,al.MS.Paginate,al.EG.Click,al.MJ.ActionButton).getMetadataTag()}startInfopaneAutoRotation(){let e=this.config.infopaneConfig||{};if(e.autoRotate&&!e.disableAutoRotate){let e=this.riverSectionIds[0],t=this.shadowRoot.querySelector?.(`#${e} cs-feed-layout`)?.shadowRoot,a=t?.querySelector("cs-responsive-infopane");a&&window.setTimeout(()=>{a.hasSlideShow=!0,this.overrideHasSlideShow=!0},1e3)}}has1SFlight(e){let t=eh.T3.CurrentRequestTargetScope&&eh.T3.CurrentRequestTargetScope.pageExperiments;return!!t&&t.includes("1s-viewurldomain")}handleContentOverlap(e,t){let a=e.target.getBoundingClientRect();a.top<160&&window.scrollBy(0,a.top-160)}overrideInfopaneSlideCardToElectionCard(e){e.cardMetadata={id:"electionCard",cardContent:{abstract:"US Elections: Latest news, results and more",destinationUrl:"https://www.msn.com/en-us/channel/topic/US%20Elections/tp-Y_cc072da4-ecb2-413a-9ffe-5ec5ad54ca41",id:"electionCard",images:[{id:"USElectionCard",caption:"US Elections: Latest news, results and more",url:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sKqsZ.img"}],type:"ArticlePreview",title:"US Elections: Latest news, results and more"},metadata:{},type:"article"}}}(0,x.Cg)([_.sH],a5.prototype,"columnArrangement",void 0),(0,x.Cg)([_.sH],a5.prototype,"isShowDot",void 0),(0,x.Cg)([_.sH],a5.prototype,"isFetchingStripes",void 0),(0,x.Cg)([_.sH],a5.prototype,"requestContext",void 0),(0,x.Cg)([_.sH],a5.prototype,"riverSectionLayoutData",void 0),(0,x.Cg)([_.sH],a5.prototype,"ttvrFired",void 0),(0,x.Cg)([_.sH],a5.prototype,"cardActionRef",void 0),(0,x.Cg)([_.sH],a5.prototype,"isFeedExhausted",void 0),(0,x.Cg)([_.sH],a5.prototype,"onFeedEndCb",void 0),(0,x.Cg)([_.sH],a5.prototype,"enableRail",void 0);var a6=a(66591),a8=a(36478),a7=a(72691),a9=a(31157),re=a(36042);let rt=(0,O.A)` .container{left:3px}`,ra=(0,O.A)` .container{right:3px}`,rr=(0,O.A)`
.arrow-container-rail{display:none}${(0,tt.H5)(tt.j1.c3)}{.arrow-container.arrow-container-rail{width:697px}}${(0,tt.H5)(tt.j1.c4)}{.arrow-container.arrow-container-rail{width:1019px}}${(0,tt.H5)(tt.j1.c5)}{.arrow-container.arrow-container-rail{width:1341px}}`,ri=(0,O.A)`
:host{--viewport-width:auto;--viewport-height:auto;--element-gap:16px;height:var(--viewport-height);width:var(--viewport-width);position:relative;display:flex}.arrow-container{position:absolute;display:flex;justify-content:space-between;align-items:flex-end;align-self:end;pointer-events:none;z-index:0;right:20px;bottom:4px}${(0,tt.H5)(tt.j1.c2)}{.arrow-container{width:697px}}${(0,tt.H5)(tt.j1.c3)}{.arrow-container{width:1019px}}${(0,tt.H5)(tt.j1.c4)}{.arrow-container{width:1341px}}.viewport{height:303px;overflow-x:hidden;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.viewport-weather{height:303px;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.disable-overflow-hidden{overflow:visible;height:var(--viewport-height)}.page-indicator{font-size:var(--page-number-font-size,12px);color:var(--page-number-color);line-height:16px;pointer-events:all}.page-indicator span{background:#c2c2c2;border-radius:50%;height:6px;width:6px;display:inline-block;margin:0 4px;cursor:pointer}.page-indicator span.active{background:#333;cursor:default}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content;height:100%;left:3px;position:relative}.slider-arrow{pointer-events:all;z-index:2;outline:none;background:var(--flipper-background,transparent);width:var(--flipper-width,20px);height:var(--flipper-height,20px);display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;border:none;margin-bottom:162px;width:28px}.slider-arrow.hide{pointer-events:none;visibility:hidden}.slider-arrow svg{width:var(--flipper-icon-width);color:var(--flipper-icon-color,buttonText);fill:#9b9b9b}${rr}
`.withBehaviors(new Q.t(rt,ra)),ro=(0,P.qy)`<svg width="24" height="24" viewBox="0 0 5 8" style="transform: scale(-1, 1);" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,rs=(0,P.qy)`<svg width="24" height="24" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,rn=(0,P.qy)` ${(0,T.ux)(e=>e.pageIndicatorData,(0,P.qy)`<span class="${e=>e.active?"active":""}" id=${e=>e.pageIndex} @click=${(e,t)=>t.parent.handlePageIndicatorClick(t.event)} data-t="${(e,t)=>t.parent.pageIndicatorTelemetryTag}"></span>`)}
`,rl=(0,P.qy)`<div ${(0,k.K)("viewport")} class="${e=>"weather"==e.sectionId?"viewport-weather":"viewport"}" part="viewport" direction="${e=>e.direction?e.direction:"ltr"}"><div class="container" part="container" ${(0,k.K)("container")}><slot ${(0,k.K)("viewportSlot")} @slotchange=${e=>e.setCurrentSlotWidth()}></slot></div></div><div class="${e=>(0,a6.x)("arrow-container",["arrow-container-rail",e.isRailEnabled])}" part="arrow-container"><slot ${(0,k.K)("previousArrow")} name="previous-arrow"><button class="slider-arrow previous-arrow" @mousedown="${(e,t)=>t.event&&e.mouseDownHandler(t.event)}" @click="${e=>e.slideKeyPressHandler(-1)}" aria-label="${e=>e.leftArrow}" data-t="${e=>e.previousArrowTelemetryTag}" hidden tabindex="-1">${(0,D.z)(e=>e.renderSlider&&"ltr"===e.direction,ro)} ${(0,D.z)(e=>e.renderSlider&&"rtl"===e.direction,rs)}</button></slot><div class="page-indicator">${(0,D.z)(e=>e.renderSlider,rn)}</div><slot ${(0,k.K)("nextArrow")} name="next-arrow"><button class="slider-arrow next-arrow" @mousedown="${(e,t)=>t.event&&e.mouseDownHandler(t.event)}" @click="${e=>e.slideKeyPressHandler(1)}" aria-label="${e=>e.rightArrow}" data-t="${e=>e.nextArrowTelemetryTag}" hidden tabindex="-1">${(0,D.z)(e=>e.renderSlider&&"ltr"===e.direction,rs)} ${(0,D.z)(e=>e.renderSlider&&"rtl"===e.direction,ro)}</button></slot></div>`,rd=class extends E.L{columnArrangementChanged(e,t){e&&this.container&&this.handleBreakpointChange()}constructor(){super(),this.direction=a9.O.ltr,this.nextArrowTelemetryTag="",this.previousArrowTelemetryTag="",this.pageIndicatorTelemetryTag="",this.columnArrangement="C4",this.currentPageIndex=1,this.totalNumPages=1,this.pageIndicatorData=[],this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.handleBreakpointChange=()=>{this.setSliderStates(),this.refreshSliderControls(this.viewport.scrollLeft)},this.handleBreakpointChange=(0,re.A)(this.handleBreakpointChange,200)}connectedCallback(){super.connectedCallback(),this.direction=a7.o.getValueFor(this),this.setSliderStates(),this.refreshSliderControls(0)}setCurrentSlotWidth(){let e=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=e?Number(e.replace(/px/,"")):0,this.viewportSlot.assignedElements().length>0&&("C4"===this.columnArrangement&&this.isC5Enabled?this.currentSlotElementWidth=1273:"C3"===this.columnArrangement?this.currentSlotElementWidth=951:"C2"===this.columnArrangement?this.currentSlotElementWidth=629:this.currentSlotElementWidth=0)}slideKeyPressHandler(e){if(this.disableSliderInColumnArrangement())return;let t=this.viewport.clientWidth,a=this.container.clientWidth;if(t<=0||a<=0)return;let r="rtl"!==this.direction,i=this.viewport.scrollLeft;if(r||(e*=-1),!r&&e>0&&0===i||r&&e<0&&0===i)return;let o=e*this.getScrollDistance();if(i+o>a)return;this.currentPageIndex=Math.floor(Math.abs(i+o)/t)+1,this.currentPageIndex<=0&&(this.currentPageIndex=1),this.onSlideIndexChange?.(this.currentPageIndex-1);let s=i+o;window.requestAnimationFrame(()=>{this.viewport.scrollTo(s,0),this.refreshSliderControls(s)})}mouseDownHandler(e){e.preventDefault(),e.stopPropagation()}setArrowVisibility(e){let t=e*("ltr"===this.direction?1:-1);t<=0?this.setArrowsHiddenVisibility(!0,!1):this.viewport.clientWidth+t>this.container.clientWidth?this.setArrowsHiddenVisibility(!1,!0):this.setArrowsHiddenVisibility(!1,!1)}hideNextArrow(e){e?this.nextArrow.children[0].classList.add("hide"):this.nextArrow.children[0].classList.remove("hide")}hidePreviousArrow(e){e?this.previousArrow.children[0].classList.add("hide"):this.previousArrow.children[0].classList.remove("hide")}setArrowsHiddenVisibility(e,t){this.hidePreviousArrow(e),this.hideNextArrow(t)}getScrollDistance(){return this.currentSlotElementWidth+this.currentContentGapSize}refreshSliderControls(e){this.setPageIndicator(),this.setArrowVisibility(e)}setSliderStates(){this.calculateTotalNumPages(),this.setCurrentSlotWidth(),this.setSliderVisibility()}calculateTotalNumPages(){return"C4"===this.columnArrangement&&this.isC5Enabled||["C2","C3"].includes(this.columnArrangement)?this.totalNumPages=2:this.totalNumPages=0}setSliderVisibility(){this.renderSlider=!(this.disableSlider||"C5"===this.columnArrangement||"C4"===this.columnArrangement&&!this.isC5Enabled||["topStripe","buydirect","shopping"].includes(this.sectionId)),"topStripe"!==this.sectionId&&this.disableSliderInColumnArrangement?this.viewport.classList.remove("disable-overflow-hidden"):this.viewport.classList.add("disable-overflow-hidden")}disableSliderInColumnArrangement(){let e=["C2","C3"];return this.isC5Enabled&&e.push("C4"),this.disableSlider||!e.includes(this.columnArrangement)}setPageIndicator(){this.pageIndicatorData=[];for(let e=1;e<=this.totalNumPages;e++){let t={active:this.currentPageIndex===e,pageIndex:e};this.pageIndicatorData.push(t)}}handlePageIndicatorClick(e){if(this.disableSliderInColumnArrangement())return;let t="ltr"===this.direction?1:-1,a=Number(e?.target.id),r=(a-1)*this.getScrollDistance();this.currentPageIndex=a,window.requestAnimationFrame(()=>{this.viewport.scrollTo(r*t,0),this.refreshSliderControls(r)})}};(0,x.Cg)([_.sH],rd.prototype,"direction",void 0),(0,x.Cg)([_.sH],rd.prototype,"nextArrowTelemetryTag",void 0),(0,x.Cg)([_.sH],rd.prototype,"previousArrowTelemetryTag",void 0),(0,x.Cg)([_.sH],rd.prototype,"pageIndicatorTelemetryTag",void 0),(0,x.Cg)([_.sH],rd.prototype,"columnArrangement",void 0),(0,x.Cg)([_.sH],rd.prototype,"currentPageIndex",void 0),(0,x.Cg)([_.sH],rd.prototype,"totalNumPages",void 0),(0,x.Cg)([_.sH],rd.prototype,"sectionId",void 0),(0,x.Cg)([_.sH],rd.prototype,"disableSlider",void 0),(0,x.Cg)([_.sH],rd.prototype,"isC5Enabled",void 0),(0,x.Cg)([_.sH],rd.prototype,"leftArrow",void 0),(0,x.Cg)([_.sH],rd.prototype,"rightArrow",void 0),(0,x.Cg)([_.sH],rd.prototype,"renderSlider",void 0),(0,x.Cg)([_.sH],rd.prototype,"pageIndicatorData",void 0),(0,x.Cg)([_.sH],rd.prototype,"isRailEnabled",void 0),rd=(0,x.Cg)([(0,E.E)({name:"stripe-slider",template:rl,styles:ri,shadowOptions:{delegatesFocus:!0}})],rd);let rc=(0,P.qy)` ${(e,t)=>(0,t1.yN)(e.pivotsNav,{properties:{parentTelemetry:t.parent.telemetryObject}})}
`,rp=(0,P.qy)`<div class="river-section-header-group" style="${e=>e.riverSectionTitleColor&&!e.disableStripeTheme?`border-color: ${e.riverSectionTitleColor};`:""} ${e=>e.seeMoreText?"border-width: 1px;":""}"><div class="stripe-title"><h2>${(0,D.z)(e=>e.adLabel,(0,P.qy)`<msn-native-ad-ad-label type="${e=>e.adSlugGA?"defaultLabel":"greenLabel"}" ad-label-text=${e=>e.adLabel} ad-label-text-opacity="${e=>e.adSlugGA?"0.81":"0.7"}" should-adjust-gap is-msn-hp-ad-slug=${e=>e.isMsnHPAdSlug} enable-safe-ads=${e=>e.enableSafeAds}></msn-native-ad-ad-label>`)}<a href="${e=>e.riverSectionTitleUrl}" target="${(e,t)=>t.parent.config.openLinksInNewTab?"_blank":"_self"}" style="${e=>e.riverSectionTitleColor&&!e.disableStripeTheme?`color: ${e.riverSectionTitleColor}`:""};${e=>e.riverSectionTitleUrl?"":"text-decoration: none;"}" data-t="${(e,t)=>t.parent.stripeWCTelemetry.getTelemetryTag(aW.title)}" title="${e=>e.seeMoreText}" aria-label="${e=>e.seeMoreText}">${e=>e.riverSectionTitle} ${(0,D.z)(e=>e.riverSectionTitleUrl||e.adLabel,(0,P.qy)`<span class="title-arrow">${P.qy.partial(a8.A)}</span>`)}</a></h2></div><div class="sub-nav">${(0,D.z)(e=>e.pivotsNav,rc)}</div></div>`,ru=(0,P.qy)`<div class="feed-section">${(0,T.ux)(e=>e.riverSectionLayoutData.filter(e=>null!=e),(0,P.qy)` ${(0,D.z)(e=>e.insertBannerAd,(0,P.qy)`<div class="in-stripe-banner-ad" id="${(e,t)=>e.sectionId}"><display-ads config-instance-src="default" instance-id="banner2"></display-ads></div>`)} ${(0,D.z)(e=>!e.insertBannerAd,(0,P.qy)`<div class="river-section" data-t="${(e,t)=>t.parent.stripeWCTelemetry.getSectionTelemetryTag(e.sectionId,e.telemetryName)}" id="${(e,t)=>e.sectionId}" @focusin="${(e,t)=>t.parent.handleContentOverlap(t.event,e.sectionId)}">${(0,D.z)(e=>e.riverSectionTitle,rp)}<stripe-slider class="${(e,t)=>(0,a6.x)("stripe-slider-container",["stripe-slider-container-rail",t.parent.enableRail],["more-space","topStripe"===e.sectionId||t.parent.isShowDot])}" part="stripe-slider-container" :isRailEnabled=${(e,t)=>t.parent.enableRail} :previousArrowTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("leftarrow")} :nextArrowTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("rightarrow")} :pageIndicatorTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("pageIndicator")} :leftArrow=${e=>e.leftArrow||{}} :rightArrow=${e=>e.rightArrow||{}} :columnArrangement=${(e,t)=>t.parent.getDisplayedColumnLayout()} :disableSlider=${e=>e.disableSlider} :isC5Enabled=${e=>e.isC5Enabled} :sectionId=${e=>e.sectionId}><cs-feed-layout class="stripe-river-section" data-section=${e=>e.sectionId} layout=${(e,t)=>t.parent.getDisplayedColumnLayout()} :data=${e=>e.feedData} :childTemplateMap=${e=>t7} :layoutStyles=${e=>{var t;let a,r;return a=tb[t=e.templateId].styles,r=aU+aL,t.indexOf("top-stripe-view")>=0?(0,O.A)`${a}${r}${aB}`:(0,O.A)`${a}${r}`}} data-t="${(e,t)=>"topStripe"===e.sectionId?t.parent.stripeWCTelemetry.getTelemetryTag(aW.todayHeadlines):null}"></cs-feed-layout></stripe-slider></div>`)} `)}<div ${(0,k.K)("paginationSentinelRef")} style=${e=>e.sentinelHeight} class="pagination-sentinel"></div></div>`,rh=(0,P.qy)` ${e=>e.config.childExperienceReferences?.cardAction&&(0,t1.yN)(e.config.childExperienceReferences.cardAction)}
`,rg=(0,P.qy)`<fluent-design-system-provider id="sf-design-system" style="background: transparent" fill=""><div class="stripe-feed" style="${e=>e.config.noPaddingEnd&&e.isFeedExhausted?"padding-bottom: 4px":null}">${(0,D.z)(e=>e.riverSectionLayoutData,ru)} ${(0,D.z)(e=>e.isFetchingStripes&&e.ttvrFired,(0,P.qy)`<div class="progress-ring-wrapper"><fluent-progress-ring></fluent-progress-ring></div>`)}</div>${(0,D.z)(e=>e.ttvrFired,rh)}</fluent-design-system-provider>`;d.m.define(c.c.registry),p.m.define(c.c.registry),u.m.define(c.c.registry),er.m.define(h.G.registry),g.Ob.define(y.i.registry),m.Id.define(y.i.registry),f.Af.define(y.i.registry),C.yr.define(y.i.registry),v.rX.define(y.i.registry),et.define(y.i.registry),ea.Bb.define(y.i.registry),ei.L.define(y.u.registry);let ry={experienceConfigSchema:void 0}},18755:function(e,t,a){a.d(t,{K:function(){return s},O:function(){return n}});var r=a(89757),i=a(94172),o=a(73559);let s=(0,r.qy)`
    ${e=>e.configInfo&&(0,i.yN)(e.configInfo,{properties:{mapperArgs:e.mapperArgs,parentTelemetry:e.telemetryObject,feedLayoutCardSize:e.cardSize},attributes:{style:`grid-area:${e.gridArea}`,class:`${e.cardSize}`},telemetryObject:e.telemetryObject})}
`,n={getFeedDataForCard:e=>(0,o.BQ)(e),viewTemplate:s}},7961:function(e,t,a){a.d(t,{T:function(){return u}});var r=a(11803),i=a(44776),o=a(46659),s=a(21386),n=a(89757),l=a(69259),d=a(33744),c=a(2375);let p=(0,n.qy)`      
    <msft-attribution slot="attribution">
    ${(0,l.z)(e=>e.providerData.logoImage,(0,n.qy)`
        <img 
            slot="image" 
            src="${e=>e.providerData.logoImage}" 
            alt="${e=>e.providerData.name}" 
            @load=${e=>{e.imageData&&e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(1,r.j.provider)}} />
    `)}
    <div class="attribution_container_${e=>e.id}" id="attribution_container">
        <div class="attribution_Content_${e=>e.id}" style="${e=>"rtl"===e.dir?"right":"left"}:0px;">
            ${(0,l.z)(e=>e.providerData&&e.providerData.name,(0,n.qy)`<span style="unicode-bidi: embed;">${e=>e.providerData.name}</span>`)}
            ${(0,l.z)(e=>e.providerData&&e.providerData.name&&e.publishedDateTime,(0,n.qy)` · `)}
            ${(0,l.z)(e=>e.publishedDateTime,(0,n.qy)`<span style="unicode-bidi: embed;">${e=>e.publishedDateTime}</span>`)}
            ${(0,l.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,n.qy)` · `)}
            ${(0,l.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,n.qy)`${e=>e.crawledContentLabel}`)}
        </div>
    </div>
    </msft-attribution>

`,u=(0,n.qy)`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card.msft-content-card-preview {
            height: 100px;
        }
        msft-content-card.msft-content-card-preview::part(body) {
            height: 100%;
        }
        msft-content-card.msft-content-card-preview .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card.msft-content-card-preview fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.msft-content-card-preview::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.msft-content-card-preview msft-attribution {
            position: relative;
            overflow: hidden;
            margin-top: 0;
            margin-bottom: 0;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl msft-attribution {
            margin-right: 5px;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            padding: 8px;
            display: flex;
            flex-flow: column-reverse;
            height: 100%;
            box-sizing: border-box;
            justify-content: space-between;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            height: 100%;
        }

        ${e=>"end"===e.imagePosition?`
            msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: right;
                margin-top: unset;
                margin: 8px 8px 8px 0px;
            }
            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: left;
                margin: 8px 0px 8px 8px;
            }
            `:`        
            msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: left;
                margin-top: unset;
                margin: 8px 0 8px 8px;
            }
            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: right;
                margin: 8px 8px 8px 0;
            }
            `}
        msft-content-card.msft-content-card-preview::part(media),
        msft-content-card.msft-content-card-preview::part(media) img {
            border-radius: unset;
        }
        msft-content-card.msft-content-card-preview::part(heading) {
            font-size: 14px;
            line-height: 20px;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper {
            display: flex;
            gap: 8px;
        }

        msft-content-card.msft-content-card-preview .attribution-wrapper .social-bar-wrapper {
            position: relative;
            z-index: 99999;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl .social-bar-wrapper::before {
            left: unset;
            right: 0px;
            transform: translateX(100%);
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper {
            height: 100%;
            position: absolute;
            top: 0;
            right: 0;
            width: calc(100% - 120px);
            padding: 8px 0;
            box-sizing: border-box;
            display: flex;
            flex-flow: column;
            justify-content: space-between;
            z-index: 2;
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper.image-end {
            right: unset;
            left: 0;
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-attribution-wrapper.no-image {
            width: 100%; 
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-container {
            padding-right: 8px;
            height: 60px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }
        msft-content-card.msft-content-card-preview .image-end .title-container {
            padding-right: 0;
        }
            
        msft-content-card.msft-content-card-preview .provider-top .title-container {
            height:40px;
            -webkit-line-clamp: 2;
            padding-top: 4px;
        }  

        msft-content-card.msft-content-card-preview .title-container:hover {
            text-decoration: underline;
        }
        msft-content-card.msft-content-card-preview .title-container:focus {
            outline: none;
            text-decoration: underline;
        }
        /* 
         *  Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position: absolute;
            transition: all 0.5s ease-out;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }

    /**
    *  To support high contrast mode for accessibility
    **/
    @media (forced-colors: active) {
        msft-content-card.msft-content-card-preview .title-container {
            color: linktext;
        }
    }
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize} msft-content-card-preview-wrapper"
    >
        <msft-content-card
            exportparts="heading"
            id="contentcard_${e=>e.id}"
            href=${e=>e.destinationUrl}
            target=${e=>e.openLinksInNewTab?"_blank":"_self"}
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            style="--heading-max-lines: 2;"
            class="msft-content-card-preview"
            data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
            @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
            @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
        >
            ${(0,l.z)(e=>e.imageData,(0,n.qy)`
                <img
                    slot="media"
                    src="${e=>e.imageData.source}"
                    alt="${e=>e.imageData.altText}"
                    height="${o.L._104x84.height}"
                    width="${o.L._104x84.width}"
                    @load="${e=>{e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(3,r.j.image)}}"
                />
            `)}
            ${e=>{!e.imageData&&e.visualReadinessCallback&&e.visualReadinessCallback()}}
            <div class="title-attribution-wrapper ${e=>e.imageData?.source?"":"no-image"} ${e=>"end"===e.imagePosition?"image-end":""} ${e=>e.providerAboveHeader?"provider-top":""}">
                ${(0,l.z)(e=>e.providerData&&e.providerAboveHeader,p)}
                <div class="title-wrapper">
                    <div class="title-container" tabindex="0" role="link" @keypress="${(e,t)=>"Enter"==t.event.key&&t.event.target.click()}">${(0,n.qy)`${e=>e.title}`}</div>
                    ${(0,l.z)(e=>e.abstract,(0,n.qy)`
                        <p slot="abstract" style="color: var(--neutral-foreground-rest);">${e=>e.abstract}</p>
                    `)}
                </div>
                <div class="attribution-wrapper ${e=>"rtl"===e.dir?"attribution-rtl":""}">
                    ${(0,l.z)(e=>e.providerData&&!e.providerAboveHeader,p)}
                    ${(0,l.z)(e=>e.enableRichSocialReaction,e=>(0,n.qy)`
 <div class="social-bar-wrapper" style="display: flex; gap: 4px; margin-right: 5px;">
     ${(0,l.z)(e=>e.optedOutOfReactions,(0,n.qy)`
         ${i.LW}
         ${i.tB}
     `)}
     <social-bar-wc
         config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,c.v)(e.socialBarWCConfigInfo)}
         instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
         config-shared-ns=${e=>e.socialBarWCConfigInfo?.configRef?.sharedNs}
         :contentId=${e=>e.id}
         :destinationUrl=${e=>e.destinationUrl}
         :locale=${e=>d.T3.CurrentMarket||e.locale}
         :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
         :hideComments=${()=>!0}
         :isRightPos=${e=>e.socialBarInRight}
         :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        theme="superappListCard"
    ></social-bar-wc>
 </div>
 `)}
                </div>
            </div>
            ${(0,l.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,s.p)}
        </msft-content-card>
    </fluent-card>
`},60640:function(e,t,a){a.d(t,{g:function(){return f}});var r=a(36880),i=a(51122),o=a(40201),s=a(62679),n=a(99381),l=a(44776),d=a(26330),c=a(21386),p=a(69828),u=a(89757),h=a(69259),g=a(44978),y=a(77833),m=a(41483);r.m,i.m;let f=(0,u.qy)`
    <style>
        :host fluent-card {
            content-visibility: auto;
        }
        ${(0,h.z)(e=>e.contentType===y.pL.Video,(0,u.qy)`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            fluent-card._1x_1y msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card span.infopane-title {
            font-size: var(--infopane-title-font-size, 28px);
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        ${e=>v(e)}

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea};"
        class="${e=>e.cardSize}"
    >
        <fluent-design-system-provider
            fill-color="#333333"
            style="display: flex; padding: 0; height: 100%;"
        >
            <msft-content-card
                id="contentcard_${e=>e.id}"
                class="${e=>(0,m.dU)(e)}"
                href=${e=>e.destinationUrl}
                target=${e=>e.openLinksInNewTab?"_blank":"_self"}
                title=${e=>e.disableCardTitleTooltip?"":e.title}
                layout="infoPane"
                style="${e=>C(e)}"
                data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
                :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
                @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
            >
            ${(0,h.z)(e=>e.contentIndicator,e=>(0,o.Z)(e.contentIndicator))}
            ${(0,h.z)(e=>!e.isAnaheimDesign,(0,u.qy)`${e=>e.title}`)}
            ${(0,h.z)(e=>e.isAnaheimDesign,(0,u.qy)`<span class="infopane-title">${e=>e.title}</span>`)}
                <img
                    slot="background-image"
                    alt="${e=>e.imageData&&e.imageData.altText}"
                    src="${e=>e.imageData&&e.imageData.source}"
                    @load="${e=>e.imageData&&e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}"
                />
                ${e=>(0,s.fn)(e.isProviderInFooter?"start-actions":"attribution")}
                ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled,n.K)}
                ${(0,h.z)(e=>!e.isAnaheimDesign,(0,u.qy)`
                    <div slot="start-actions" style="gap:0">
                        ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled&&!e.enableRichSocialReaction,(0,u.qy)`
                            ${l.LW}
                            ${l.tB}
                        `)}
                    </div>
                `)}
                <div slot="${e=>e.isProviderInFooter?"end-actions":"start-actions"}" style="gap:0">
                    <style>
                        .card-button:not(:hover) {
                            background: transparent;
                        }
                        msft-content-card fluent-button::part(control) {
                            padding: 0;
                        }
                    </style>
                    ${(0,h.z)(e=>e.enableRichSocialReaction,(0,l.nj)({}))}
                    ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled,(0,u.qy)`
                        ${(0,h.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,u.qy)`
                            ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&g.J.showMore,l.LW)}
                            ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&g.J.showFewer,l.tB)}
                        `)}
                        ${(0,h.z)(e=>e.enableWCCardAction,d.L)}
                    `)}
                </div>
                ${(0,h.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,c.p)}
            </msft-content-card>
        </fluent-design-system-provider>
    </fluent-card>
`,C=e=>{let t="width: 100%;";return(e.cardSize===p.uE._2x_2y||e.cardSize===p.uE._2x_3y)&&(t+=" --heading-font-size: 20px; --heading-line-height: 28px;"),(e.cardSize===p.uE._1x_1y||e.cardSize===p.uE._1x_2y)&&e.useInfopaneSlideTemplate&&(t+=" --infopane-title-font-size: 20px;"),t},v=e=>{let t="";return(e.cardSize===p.uE._1x_1y||e.cardSize===p.uE._1x_2y)&&e.useInfopaneSlideTemplate&&(t+=`
            msft-content-card[layout="infoPane"]::part(footer) {
                padding: 0 16px 4px;
                margin-bottom: 0;
                height: 40px;
            }
        `),t}},9039:function(e,t,a){a.d(t,{o:function(){return u}});var r=a(10862),i=a(46659),o=a(35667),s=a(98669),n=a(77833),l=a(98794),d=a(3006),c=a(72287),p=a(25658);let u={getFeedDataForCard:e=>(function(e){let{cardSlot:t,configOptions:a,parentTelemetryObject:r,cardMetadata:u,openLinksInNewTab:h,visualReadinessCallback:g,isAnaheimDesign:y,isProviderInFooter:m,enableArticleTimestamps:f,localizedStrings:C,enableNewTimestampFormatForJAJP:v}=e;if(!u||!u.subItems||0===u.subItems.length)return(0,d.wc)();let x=u?.subItems[0]?.type===n.pL.WebContent,b=a&&a,_=u.subItems[0].cardContent,{id:w,destinationUrl:S,title:E,provider:A,type:$}=_;b&&(b.instanceId=`denseCard-${w}`);let I={id:w,destinationUrl:S,openLinksInNewTab:h,title:E,ariaLabel:(0,c.yL)(E,A,a?.localizedStrings),imagePriority:!1,providerData:(0,c.p_)(A,x),isProviderInFooter:m,imageData:(0,s.po)(u.subItems[0],i.L._240x129,g,y),publishedDateTime:f&&`${(0,s.fL)(v,new Date(_.publishedDateTime),_.locale,C)}`},P=u.subItems.slice(1),k={heroNews:I,newsList:P?.map(e=>{let t=e.type===n.pL.NativeAd||e.type===n.pL.CmsAd,l=e?.cardContent;if(!t){let d=e.type===n.pL.WebContent;return{abstract:e.cardContent.abstract,imageData:(0,s.po)(e,i.L._240x129,g,y),destinationUrl:e.cardContent.destinationUrl,title:e.cardContent.title,ariaLabel:(0,c.yL)(e.cardContent.title,e.cardContent.provider,a?.localizedStrings),providerData:(0,c.p_)(e.cardContent.provider,d),isNativeAd:t,telemetryContext:(0,o.dj)(r,e.cardContent,e.metadata,null,d),isNarrowNewsItem:a?.isNarrowNewsItem,publishedDateTime:f&&`${(0,s.fL)(v,new Date(l.publishedDateTime),l.locale,C)}`}}let d=e.placement?.items[0]||{},{beaconsJson:u,privacyUrl:h,adLabelText:m,isGreyAdsLabelEnabled:x,geminiViewabilityDataJson:b}=e.placement||{};return{...d,beaconsJson:u,privacyUrl:h,adLabelText:m,geminiViewabilityDataJson:b,isNativeAd:t,adTelemetryContext:(0,p.u)(e,r,"river",0),isNarrowNewsItem:a?.isNarrowNewsItem,isGreyAdsLabelEnabled:x}})},D={id:b?.instanceId,childTemplateType:"dense-card",telemetryObject:r,denseConfigInfo:b,denseData:k,visualReadinessCallback:g};return(0,l.bw)({id:"denseCard",experienceType:b?.configRef?.experienceType,mapperArgs:e},D,(e,t)=>{let a=t.telemetryExt;return k.newsList.forEach((e,t)=>{if(!e.isNativeAd&&e.telemetryContext?.destination&&!e.telemetryContext.destination?.contract?.ext){let r=P[t],{traceIdIndex:i}=r||{},{recoId:o,ri:s}=r?.metadata||{},n={...a,recoId:o,ri:s,traceIdIndex:i};e.telemetryContext.destination=e.telemetryContext.contentCard.addOrUpdateChild({...e.telemetryContext.destination.contract,ext:n})}}),{denseData:k}})})(e),viewTemplate:r.e}},10862:function(e,t,a){a.d(t,{e:function(){return o}});var r=a(89757),i=a(94172);let o=(0,r.qy)`
<fluent-card
    style="grid-area:${e=>e.gridArea};contain:unset"
    class="${e=>e.cardSize}"
>
    ${e=>(0,i.yN)(e.denseConfigInfo,{properties:{denseData:e.denseData,telemetryObject:e.telemetryObject},memoize:!1,includeTelemetryTag:!1})}
</fluent-card>
`},18420:function(e,t,a){a.d(t,{E:function(){return n}});var r=a(50365),i=a(98794),o=a(94108),s=a(68866);let n={getFeedDataForCard:e=>(function(e){var t;let{configOptions:a={},cardMetadata:r}=e,n=(t=a,!(0,o.Th)().CurrentFlightSet?.has("prg-hp-fvrf")&&t.isWaterfallFeed&&(0,o.Th)().ClientSettings?.pagetype==="hp"),l=r.instanceId||(n?"rectangle1":void 0),d=(0,s.$q)(window.location.href),c="hp2";(0,s._f)(d)?c="hp2lock":(0,s.AO)(d)&&(c="winweb");let p={id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",type:r.type,enableSafeAds:!!a.enableSafeAds,childTemplateType:"display-ad-card",configInstanceSrc:r.configInstanceSrc||(n?"waterfall":"default"),instanceId:l,pageTypeOverride:n?c:void 0,shimmerIdOverride:n?"rectangle1":void 0,batchCallAdCountOverride:a.displayAdBatchCountOverride,enableExtraAdSlug:"rectangle1"===l&&!!n||void 0};return(0,i.bw)({id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",experienceType:a?.configRef?.experienceType,mapperArgs:e},p)})(e),viewTemplate:r.s}},50365:function(e,t,a){a.d(t,{s:function(){return i}});var r=a(89757);let i=(0,r.qy)`
<div 
    id="${e=>e.id}"
    style="grid-area:${e=>e.gridArea};
    ${e=>"DisplayAdBanner"===e.type?"display: flex; justify-content: center; overflow: hidden;":""}
    ${e=>"DisplayAdBanner"===e.type&&"_1x_2y"===e.cardSize?"max-width: 300px;":""}
    ${e=>"DisplayAdBanner"===e.type&&"_2x_2y"===e.cardSize?"max-width: 612px;":""}"
    class="${e=>e.cardSize}"
> 
    <display-ads 
        config-instance-src="${e=>e.configInstanceSrc}" 
        instance-id="${e=>e.instanceId}" 
        :enableExtraAdSlug="${e=>e.enableExtraAdSlug}"
        :shimmerIdOverride="${e=>e.shimmerIdOverride}"
        :batchCallAdCountOverride="${e=>e.batchCallAdCountOverride}"
        :pageTypeOverride="${e=>e.pageTypeOverride}"
    >
    
    </display-ads>
</div>
`},71084:function(e,t,a){a.d(t,{f:function(){return n}});var r=a(245),i=a(87906),o=a(40450),s=a(98794);let n={getFeedDataForCard:e=>(function(e){try{let{configOptions:t,cardMetadata:a,parentTelemetryObject:r,openLinksInNewTab:i,sdCardActionClickHandler:o,useInlineSvgIcons:n,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d}=e,c="shopping-carousel",p={id:c,childTemplateType:"shopping-carousel-card",openLinksInNewTab:i,sdCardActionClickHandler:o,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d,parentTelemetryObject:r,shoppingCardMetadata:a,shoppingCarouselCardConfigInfo:t&&t,useInlineSvgIcons:n};return(0,s.bw)({id:c,experienceType:p.shoppingCarouselCardConfigInfo?.configRef?.experienceType,mapperArgs:e},p)}catch(e){(0,i.c_)(e,o.Odo,"Error in Shopping Carousel Mapper")}})(e),viewTemplate:r.j}},245:function(e,t,a){a.d(t,{j:function(){return o}});var r=a(89757),i=a(94172);let o=(0,r.qy)`
    ${e=>(0,i.yN)(e.shoppingCarouselCardConfigInfo,{attributes:{style:`grid-area:${e.gridArea}`,class:`${e.cardSize}`,tabindex:e.customTabIndex??0},properties:{parentTelemetry:e.parentTelemetryObject,openLinksInNewTab:e.openLinksInNewTab,sdCardActionClickHandler:e.sdCardActionClickHandler,goToPersonalizeCallback:e.goToPersonalizeSettingsCallback,refreshFeedCallback:e.refreshFeedCallback,shoppingCardMetadata:e.shoppingCardMetadata,useInlineSvgIcons:e.useInlineSvgIcons,cardSize:e.cardSize}})}
`},32361:function(e,t,a){a.d(t,{Q:function(){return s}});var r=a(8097),i=a(98794),o=a(73559);let s={getFeedDataForCard:e=>(function(e){let{cardMetadata:t,configOptions:a,parentTelemetryObject:r,visualReadinessCallback:s}=e;if(a&&a.useSharedTelemetry)return(0,o.BQ)(e,"trending-now-card");let n=a&&a;return(0,i.bw)({id:"trendingNowCard",experienceType:n?.configRef?.experienceType,mapperArgs:e},{id:"trendingNowCard",childTemplateType:"trending-now-card",parentTelemetryObject:r,visualReadinessCallback:s,trendingNowCardConfigInfo:n,trendingNowCardMetadata:t},null,!0)})(e),viewTemplate:r.A}},8097:function(e,t,a){a.d(t,{A:function(){return o}});var r=a(2375),i=a(89757);let o=(0,i.qy)`
<fluent-card
    style="grid-area:${e=>e.gridArea};"
    class="${e=>e.cardSize}"
>
    <trending-now-card
        config-instance-src=${e=>e.trendingNowCardConfigInfo&&(0,r.v)(e.trendingNowCardConfigInfo)}
        config-shared-ns=${e=>e.trendingNowCardConfigInfo&&e.trendingNowCardConfigInfo.configRef&&e.trendingNowCardConfigInfo.configRef.sharedNs}
        instance-id=${e=>e.trendingNowCardConfigInfo&&e.trendingNowCardConfigInfo.instanceId}
        :feedLayoutCardSize=${e=>e.cardSize}
        :parentTelemetry=${e=>e.parentTelemetryObject}
        :trendingNowCardMetadata=${e=>e.trendingNowCardMetadata}
        :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    >
    </trending-now-card>
</fluent-card>
`},36597:function(e,t,a){a.d(t,{g8:function(){return s},gq:function(){return n},wg:function(){return i}});var r=a(83593);function i(e,t=""){let a=new URLSearchParams(window.location.search).get(e);return a&&""!==a?String(a):t}a(68866);let o=new r.bb().data;function s(e,t,a){if(e&&e.length>0){let i=(0,r.KP)(o.devicePixelRatio,"devicePixelRatio"),s=a*(i=i&&i>0?i:1),n=1;if(s<100?n=1.5:s<350&&(n=1.2),e.startsWith("https://www.bing.com/th?id=")||e.startsWith("https://bing.com/th?id=")||e.startsWith("https://th.bing.com/th?id=")){let r=new URLSearchParams(e.substring(e.indexOf("?")+1)).get("id");e=e.substring(0,e.indexOf("?"));let o=Math.floor(a*i*n);e=`${e}?id=${r}&${t}=${o}&p=0`}else if(e.startsWith("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/")){e.includes("?")&&(e=e.substring(0,e.indexOf("?")));let r=Math.floor(a*i*n);e=`${e}?${t}=${Math.floor(r)}`}}return e}function n(e,t,a,r){return(e&&""!==e||(e="ABT748875623C1C490A64E339BEF5741D0A4D98E2E4B21323BED0D12971212C1C24"),e.startsWith("https://www.bing.com/th?id=")||e.startsWith("https://bing.com/th?id=")||e.startsWith("https://th.bing.com/th?id="))?`${e}${t?"&w="+t:""}${a?"&h="+a:""}${r}`:`https://www.bing.com/th?id=${e}${t?"&w="+t:""}${a?"&h="+a:""}${r||""}`}},94818:function(e,t,a){a.d(t,{J:function(){return v}});var r,i,o,s,n=a(33744),l=a(42826),d=a(53128),c=a(96882);(r=o||(o={}))[r.ntp=0]="ntp",r[r.dhp=1]="dhp";var p=a(87906),u=a(40450),h=a(96500);(i=s||(s={})).MIT="MIT",i.Topic="Topic",i.Category="category";var g=a(7446),y=a(68018),m=a(12776),f=a(52306);let C="XGP6bGECtXattHPaMTSEtXAJpanIfDLqAumdUN8Bpi";class v{constructor(e,t,a,r,i){this.fetchImpl=e,this.ocid="Peregrine",this.serviceClientSettings=t,this.APISettings=a,this.formCodes=r,this.generateServiceClientSettings(i)}generateServiceClientSettings(e){let t=(0,n.rA)();(0,y.ab)();let a=l._3.getQueryParameterByName("userid",e),r=l._3.getQueryParameterByName("testhooks",e),{enableLocalization:i,addFlightParam:o,queryParamsToForward:s}=this.APISettings;if(this.ocid="Peregrine",this.serviceClientSettings.queryParams){if(this.queryParamsMap=new Map(Object.entries(this.serviceClientSettings.queryParams)),this.queryParamsMap.set("apikey",this.serviceClientSettings.queryParams.apiKey||t.OneServiceApiKey),this.queryParamsMap.set(t.OneServiceContentMarketQspKey,t.CurrentMarket),this.queryParamsMap.set("ocid",this.ocid),this.queryParamsMap.set("trackingid",t.ActivityId),this.queryParamsMap.set("testhooks",r),"1"===r&&a&&this.queryParamsMap.set("userid",a),i&&t.Latitude&&t.Longitude&&(this.queryParamsMap.set("lat",t.Latitude),this.queryParamsMap.set("long",t.Longitude)),t.ShouldUseFdheadQsp){let e=o&&t.CurrentRequestTargetScope&&t.CurrentRequestTargetScope.pageExperiments,a=e&&e.join(",");this.queryParamsMap.set("fltids",a)}if(s){let t=new Set(s),a=new URL(e);a&&a.search&&new URLSearchParams(a.search).forEach((e,a)=>{t.has(a)&&this.queryParamsMap.set(a,e)})}}this.serviceClientSettings.pathComponents?this.pathComponentsMap=new Map(Object.entries(this.serviceClientSettings.pathComponents)):this.pathComponentsMap=new Map,this.pathComponentsMap.set(t.OneServiceContentMarketQspKey,t.CurrentMarket),this.pathComponentsMap.set("version","v1")}async getShoppingEntitiesData(e=null){let t=null;return await this.getShoppingEntitiesDataJson(e).then(e=>{t=this.TryGetShoppingEntitiesData(e)}).catch(e=>{(0,p.c_)(e,u.xkP,"Failed to fetch Shopping entities response")}),t}async getShoppingEntitiesDataJson(e=null){let{pathComponents:t,queryParams:a,serviceBaseUrl:r,servicePath:i}=this.serviceClientSettings,o=[];if(a)for(let e of this.queryParamsMap.entries())o.push({key:e[0],value:e[1]});if(t)for(let e of this.pathComponentsMap.entries())i=i.replace(`{${e[0]}}`,e[1]);let s=new URL(i,r);if(s.search=l._3.keyValueArrayToQueryString(o),this.serviceClientSettings.additionalUrlAugmentations&&(s.search=s.search.concat(this.serviceClientSettings.additionalUrlAugmentations)),e&&e.data)try{let t=JSON.parse(e.data);return h.v.log("shoppingEntitiesData provided by parent in serviceContextMetadata"),t}catch(e){return(0,p.c_)(e,u.ECJ,"Error in getShoppingEntitiesDataJson, unable to parse serviceContextMetadata"),null}{let e=await this.fetchImpl(s.href,{method:"GET",headers:{accept:"application/json"}});return e.ok?e.json():(g.YT.sendAppErrorEvent({...u.xkP,message:"Shopping carousel response not ok.",pb:{...u.xkP.pb,customMessage:`Shopping carousel response not ok. Status: ${e.status}, StatusText: ${e.statusText}`}}),null)}}convertBlackJackDealsDataToShoppingEntitiesData(e){let t=e.shoppingEntities.map(e=>({...e,communityInfo:this.ensureSocialBarDataForBlackjackDealsCommunityInfo(e.communityInfo,e.title,e.id),viewsCount:e.productInsightsData.uxInsightDecoration.find(e=>e.startsWith("ViewCountInsight"))?.match(/--(.+)/)?.[1]})).filter(e=>0!==Object.keys(e).length);return t.length>0?{shoppingEntities:t}:null}ensureSocialBarDataForBlackjackDealsCommunityInfo(e,t,a){let{itemId:r,itemUrl:i}=e??{};if(r&&i)return e;let o=f.E.buildAbsoluteUrl(t,void 0,a),s={itemId:o,itemUrl:o};return e?{...e,...s}:s}TryGetShoppingEntitiesData(e){let t,{enablemsnsdcardcms:a}=this.APISettings;if(!e)return g.YT.sendAppErrorEvent({...u.Fjq,message:"Received empty ShoppingEntitiesData response.",pb:{...u.Fjq.pb,customMessage:JSON.stringify(e)}}),null;if(e.prongCards&&e.prongCards.length>0)return this.GetProngCardItems(e);if(e.productCards&&e.productCards.length>0)return e;if(e.shopping&&e.shopping.length>0)return JSON.parse(e.shopping[0].data);if(e.length>0&&e[0]?.type=="ShoppingCard")return JSON.parse(e[0].data);if(e.length>0&&e[0]?.type=="ShoppingCarousel"){let t=JSON.parse(e[0].data);if(t.topics&&t.topics.some(e=>"Blackjack"===e.title&&e.shoppingEntities?.length>0))return this.convertBlackJackDealsDataToShoppingEntitiesData(t.topics.find(e=>"Blackjack"===e.title))}let r=[];if(e[0]?.type=="ShoppingBuyDirectCard"?(t=e[0].type,(r=JSON.parse(e[0].data)).forEach(e=>{e&&e.imageInfo&&""==e.imageInfo.sourceImageUrl&&e.imageInfo.images&&(e.imageInfo.sourceImageUrl=e.imageInfo.images[0].url)})):e[0]?.type=="ShoppingFeedResponse"&&a?(t=e[0].type,(r=JSON.parse(e[0].data)?.categories).forEach(e=>{e&&e.backgroundImage&&void 0==e.imageInfo&&(e.imageInfo=e.backgroundImage,e.clickUrl=e.backgroundImage.clickUrl)})):r=e[0]?.type=="ShoppingFeedResponse"?JSON.parse(e[0].data)?.trendingProducts:e.shoppingEntities,!r||0==r.length)return g.YT.sendAppErrorEvent({...u.dMO,message:"Missing required fields in ShoppingEntitiesData response.",pb:{...u.dMO.pb,customMessage:JSON.stringify(e)}}),null;let{enbaleFirstCarouselItems:i,enbaleSecondCarouselItems:o,minCarouselItems:s,maxCarouselItems:n,randomizeCarouselItems:l}=this.APISettings;if(l&&(r=r.sort(()=>.5-Math.random())),r.length<s)return g.YT.sendAppErrorEvent({...u.c7V,message:"Insufficient shoppingEntities items in shoppingEntitiesData response.",pb:{...u.c7V.pb,customMessage:`MinimumRequired=${s}, shoppingEntitiesCount=${r.length}`}}),null;r.length>n&&(r=r.slice(0,n)),r.length>1&&i&&(r=r.slice(0,Math.ceil(r.length/2))),r.length>1&&o&&(r=r.slice(Math.ceil(r.length/2)));let d=this.GetFormCode("shoppingEntities");return r.forEach(e=>{e&&e.clickUrl&&(e.clickUrl=`${e.clickUrl}&FORM=${d}`)}),e.shoppingEntities=r,e.type=t,e}GetFormCode(e){let t=d.U0.isDhpPage()?o.dhp:o.ntp;return this.formCodes&&this.formCodes[e]&&this.formCodes[e][o[t]]}GetProngCardItems(e){if(!this.serviceClientSettings.usingPreviewTable&&!this.serviceClientSettings.usingProductionTable){let t=e.prongCards.filter(e=>e.type===s.Category).sort(()=>.5-Math.random()),a=e.prongCards.filter(e=>e.type!==s.Category).sort(()=>.5-Math.random());e.prongCards=t.concat(a).slice(0,10)}return e}getDealsSDCardRequestBody(){return JSON.stringify({categoryId:"All",getProductDeals:!0,skip:0,take:this.serviceClientSettings.queryParams.take||30,userMuid:(0,y.ab)()})}async getShoppingEntitiesDataUsing1S(e=!0,t,a=u.xkP){let r=null,i="shopping/blackjack/getblackjackdeals"===this.serviceClientSettings.servicePath?await this.fetchFrom1S(t,"POST",this.getDealsSDCardRequestBody()):await this.fetchFrom1S(t,"GET");return i?r=this.TryGetShoppingEntitiesData(i):e&&(0,p.c_)(Error("Failed to fetch Shopping entities response"),a,`Failed to fetch Shopping entities response, with filter ${this.serviceClientSettings?.queryParams?.filter}`),r}async fetchFrom1S(e,t="GET",a=null){let r=(0,n.rA)(),i={method:t,headers:await m.WR.getOneServiceHeaders(),body:a,timeoutMs:e},o=[];if((0,y.ab)()&&!this.APISettings.skipUserMUID&&(o.push({key:"user",value:"m-"+(0,y.ab)()}),i.headers||(i.headers={MUID:(0,y.ab)()}),i.headers.MUID=(0,y.ab)()),this.serviceClientSettings.queryParams){o.push({key:"apikey",value:this.serviceClientSettings.queryParams.apikey||C}),o.push({key:r.OneServiceContentMarketQspKey,value:r.CurrentMarket}),this.serviceClientSettings.queryParams.ocid&&o.push({key:"ocid",value:this.serviceClientSettings.queryParams.ocid}),this.serviceClientSettings.queryParams.top&&o.push({key:"$top",value:this.serviceClientSettings.queryParams.top}),this.serviceClientSettings.queryParams.contentType&&o.push({key:"contentType",value:this.serviceClientSettings.queryParams.contentType});let e="";r.ShouldUseFdheadQsp&&r.CurrentRequestTargetScope?.pageExperiments&&(e=r.CurrentRequestTargetScope.pageExperiments.join()),r.ShouldUseFdheadQsp&&this.serviceClientSettings.queryParams.fdhead&&(e=e+","+this.serviceClientSettings.queryParams.fdhead),e&&o.push({key:"fdhead",value:e}),this.serviceClientSettings.queryParams.select&&o.push({key:"$select",value:this.serviceClientSettings.queryParams.select}),this.serviceClientSettings.queryParams.filter&&o.push({key:"$filter",value:this.serviceClientSettings.queryParams.filter}),this.serviceClientSettings.queryParams.setactivityid&&o.push({key:"activityId",value:(0,c.G)()})}else o.push({key:"apikey",value:C});let s=new URL(this.serviceClientSettings.servicePath,this.serviceClientSettings.serviceBaseUrl);s.search=l._3.keyValueArrayToQueryString(o);try{let e=await this.fetchImpl(s.href,i);if(e.ok)return await e.json()}catch(e){(0,p.c_)(e,u.F6z,`MSN homepage shopping carousel fetch data failed, request url: ${s.href}`)}o.pop(),s.search=l._3.keyValueArrayToQueryString(o);try{let e=await this.fetchImpl(s.href,i);if(e.ok)return await e.json()}catch(e){return(0,p.c_)(e,u.F6z,`MSN homepage shopping carousel second call fetch data failed, request url: ${s.href}`),null}}async hasBuyDirectInterest(){let e=await this.getShoppingEntitiesDataUsing1S(!0);if(!e||!e.shoppingEntities||!e.shoppingEntities.length)return!1;let t=e.shoppingEntities[0];return!!(t.id&&t.id.startsWith("Reco-"))}}},50880:function(e,t,a){a.d(t,{rF:function(){return k},Cb:function(){return function e(t){return f(t,function(a,r,i){a[Array.isArray(t)?i:(0,C.A)(""+i)]=(0,y.A)(r)?e(r):r})}},os:function(){return S},nt:function(){return P},eJ:function(){return E},py:function(){return x},B:function(){return A},VN:function(){return $},z7:function(){return w},KA:function(){return I},Y6:function(){return D},yA:function(){return b},HU:function(){return v}});var r,i,o=a(33744),s=a(43672),n=a(54837),l=a(12420),d=a(93653),c=a(56018),p=a(87827),u=a(78285),h=a(53867),g=a(9790),y=a(6809),m=a(26888),f=function(e,t,a){var r=(0,u.A)(e),i=r||(0,h.A)(e)||(0,m.A)(e);if(t=(0,c.A)(t,4),null==a){var o=e&&e.constructor;a=i?r?new o:[]:(0,y.A)(e)&&(0,g.A)(o)?(0,l.A)((0,p.A)(e)):{}}return(i?n.A:d.A)(e,function(e,r,i){return t(a,e,r,i)}),a},C=a(96883);function v(e){if(!e)return"";let t=e.split("-");return 2===t.length?t[1]:e}function x(e){return!isNaN(Number(v(e)))}function b(e){if(!e)return"";let t=e.split("-");return 2===t.length?t[1]:e}function _(e,t){if(e){var a;return(a=e,e=o.T3.CurrentMarket===s.DX.JAJP&&(a+"").indexOf(".00")>-1?(a+"").replace(".00",""):a+"",t&&-1==e.indexOf(t))?t+e:e}return""}function w(e,t,a=s.DX.ENUS){if(e){let r,i=(-1!==(e+="").indexOf(t)?e.replace(t,""):e).replace(/,/g,""),o=parseFloat(i);if(o+"00"!==(r=i.length,i.slice(0,r-3)+i.slice(r-2,r))&&o+""!==i);else if(a===s.DX.JAJP)return _(o.toLocaleString(a),t);else return _(o.toLocaleString(a,{minimumFractionDigits:2,maximumFractionDigits:2}),t)}return e}function S(e,t){return e&&t?String(e)+"+"+t:""}function E(e,t,a){if(!e||!t||!(e>=t))return"";{let r=(e-t)/1e3,i=String(parseInt(String(r/60/60%24)));i=10>Number(i)?"0"+i:i;let o=String(parseInt(String(r/60%60)));o=10>Number(o)?"0"+o:o;let s=String(parseInt(String(r%60)));return a+String(i+":"+o+":"+(s=10>Number(s)?"0"+s:s))}}function A(e){let t=[],a=[];return e&&e.length>0&&e.forEach(e=>{if(e&&e.id&&e?.imageInfo?.sourceImageUrl){let r=new URLSearchParams(new URL(e.imageInfo.sourceImageUrl).search);r.has("id")&&(t.push(v(e.id)),a.push(r.get("id")))}}),[t,a]}function $(e=new Date().getHours(),t=new Date().toLocaleDateString(),a=72e5){return new Date(t+(e>=10?" "+e:" 0"+e)+":00:00").getTime()+a}function I(e){return btoa(Array.from(new TextEncoder().encode(e)).map(e=>String.fromCharCode(e)).join(""))}function P(e,t,a){if(!e||!t||!a)return;let r=+e.replace(a,"").replace(",",""),i=+t.replace(a,"").replace(",","");if(!r||!i)return;let o=r-i;if(!(o<=0))return o}function k(e,t,a,r=!1){let i=P(e,t,a);if(!i)return;let o=100*i/e.replace(a,"").replace(",","");return(r?Math.ceil(o):Math.floor(o))+"%"}function D(e,t){if(e){let a=e;return t?.forEach(e=>{a=a.replace(RegExp(e+"$"),"")}),a=a.replace(/[^a-z0-9]/gi,"").toLowerCase()}return e}(r=i||(i={})).el="el",r.es="es",r.da="da",r.fi="fi",r.fr="fr",r.hu="hu",r.it="it",r.ja="ja",r.nl="nl",r.pl="pl",r.pt="pt"},37125:function(e,t,a){a.d(t,{Lm:function(){return i},Yd:function(){return o}});var r=a(69326);function i(e=!1){let t,a,o;return(a=(t=new Date).getUTCDay(),o=t.getUTCHours(),!(1==a&&o>=18||5==a&&o<22||a>=2&&a<=4)||(0,r.kg)()||e)?30:20}function o(e){return e.toString()+"%"}},5977:function(e,t,a){a.d(t,{AO:function(){return d},Ep:function(){return h},Je:function(){return l},iD:function(){return c}});var r=a(33744),i=a(45596),o=a(87906),s=a(40450);function n(e,t){(0,o.c_)(e,s.Wbw,`url: ${t}`)}function l(e,t,a,r,i){try{if(!e||!t&&!a||0===t||0===a)return"";let o=new URL(e),s=o.searchParams.get("bw"),n=s?parseInt(s):0;n&&(t=t?t-2*n:t,a=a?a-2*n:a),t&&o.searchParams.set("h",t.toString()),a&&o.searchParams.set("w",a.toString()),void 0===r||o.searchParams.get("c")||o.searchParams.set("c",r),null!=i&&""!==i?o.searchParams.set("rs",i):o.searchParams.set("rs","1");let l=o.toString();t&&o.searchParams.set("h",(2*t).toString()),a&&o.searchParams.set("w",(2*a).toString()),n&&o.searchParams.set("bw",(2*n).toString());let d=o.toString();return`${l} 1x, ${d} 2x`}catch(t){return n(t,e),`${e} 1x`}}function d(e){let t=e.imageInfo?.images;if(t&&t.length>1){let a=t.map(e=>({...e,sourceImageUrl:(0,i.zt)(e.url)}));e.imageInfo.sourceImageUrl||(e.imageInfo.sourceImageUrl=a[0].sourceImageUrl),e.images=a.filter(t=>t.sourceImageUrl!==e.imageInfo.sourceImageUrl)}}function c(e,t=0){let a=e.imageInfo?.sourceImageUrl;a&&(e.imageInfo.sourceImageUrl=p(u(a,t),"17"))}function p(e,t){try{let a=new URL(e);return a.searchParams.set("c",t.toString()),a.toString()}catch(t){return n(t,e),e}}function u(e,t=0,a="FFFFFF"){if(!t||!a)return e;try{let r=new URL(e);return r.searchParams.set("bw",t.toString()),r.searchParams.set("bc",a),r.toString()}catch(t){return n(t,e),e}}async function h(e,t="",a="",r=1,i=0){if(!t&&!a||!e.imageInfo?.sourceImageUrl)return;let o=await g(e),s="";o&&t&&(s=t),!o&&a&&(r=function(e){try{let t=new URL(e),a=t.searchParams.get("w"),r=t.searchParams.get("h"),i=a?parseInt(a):0,o=r?parseInt(r):0;if(!i||!o)return;return i/o}catch(t){n(t,e);return}}(e.imageInfo.sourceImageUrl)||r,e.imageInfo.ratio&&.2>Math.abs(e.imageInfo.ratio-r)&&(s=a)),e.imageInfo.hasWhiteBackground=o,s&&(e.imageInfo.sourceImageUrl=p(e.imageInfo.sourceImageUrl,s),i&&o&&(e.imageInfo.sourceImageUrl=u(e.imageInfo.sourceImageUrl,i)))}async function g(e){try{let t=e.imageInfo?.sourceImageUrl;if(!t)return!0;let a=await y(function(e,t=50){let a=new URL(e);return a.searchParams.set("w",t.toString()),a.searchParams.delete("h"),a.toString()}(t)),r=a.naturalWidth,i=a.naturalHeight;if(!r||!i)return!0;return e.imageInfo.ratio=r/i,function(e){try{e.crossOrigin="anonymous";let t=document.createElement("canvas"),a=e.naturalWidth,r=e.naturalHeight;t.width=a,t.height=r;let i=t.getContext("2d");i?.drawImage(e,0,0);let o=i?.getImageData(0,0,t.width,t.height),s=o?.data;if(!s)return!0;return function(e,t,a,r=5,i=20){let o=0;for(let s=0;s<a;s++)for(let n=0;n<t;n++)if(n<r||n>=t-r||s<r||s>=a-r){let a=(s*t+n)*4,r=e[a],l=e[a+1],d=e[a+2],c=255-i;r>c&&l>c&&d>c&&o++}return o/(2*r*(t+a-2*r))*100}(s,a,r)>=25}catch(t){return n(t,e.src),!0}}(a)}catch(e){return!0}}async function y(e){let t=new Image;return t.crossOrigin="anonymous",t.src=e,await t.decode(),t}(0,r.rA)().StaticsUrl},52306:function(e,t,a){a.d(t,{E:function(){return o}});var r=a(45596),i=a(50880);class o extends r.dN{static buildAbsoluteUrl(e,t,a,r,o=!0,s){a=(0,i.yA)(a);let n=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(n,"msnembedded",t,o),n.searchParams.append("filters",this.getFiltersQueryParam(a,s)),n.searchParams.append("q",e),n.searchParams.append("productpage","true"),r&&n.searchParams.set("overlay","true"),n.href}static getFiltersQueryParam(e,t){let a=new URLSearchParams(window?.location?.search||""),r=`pdprecocache:"true" scenario:"17" gType:"12" gId:"${e}" gGlobalOfferIds:"${e}"`;return t&&(r+=' brqenabled:"true"'),e?r:a.get("filters")||""}}o.bingBaseUrl="https://www.bing.com/shop/productpage"},52226:function(e,t,a){a.d(t,{u:function(){return o}});var r=a(45596),i=a(7446);class o extends r.X9{static buildAbsoluteUrl({market:e,pid:t,title:a,clickSource:o,trafsrc:s,ocid:n,formCode:l,isBing:d,isBWM:c,campaignCode:p,addEntrypoint:u=!0}){if(d){let o=new URLSearchParams;if(a){let e=a.split(" ");a=e.length>2?e.slice(0,-2).join(" "):e.join(" "),o.set("q",a??"")}t&&(u&&o.set("entrypoint","buydirect"),o.set("productpage","true"),o.set("browse","true"),o.set("filters",`scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`)),e&&o.set("setmkt",e),s&&o.set("trafsrc",s),n&&o.set("ocid",n),l&&o.set("FORM",l),p&&o.set("CBC",p),o.set("msnrid",i.YT?i.YT.getRequestId():"Telemetry not initialized"),o.set("adunitId","378983"),o.set("propertyId","316966");let d=(0,r.wW)(o);return t?`https://www.bing.com/shop/productpage${d?"?"+d:""}`:`https://www.bing.com/shop/buywithmicrosoft${d?"?"+d:""}`}{let i=new URLSearchParams;t&&i.set("pid",t),o&&i.set(r.Ts.ClickSourceQueryParam,o),a&&i.set("title",a),n&&i.set("ocid",n),s&&i.set("trafsrc",s),l&&i.set("FORM",l);let d=(0,r.wW)(i);return t?`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/product${d?"?"+d:""}`:`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/superdeals${d?"?"+d:""}`}}static addSearchParams({url:e,pid:t,title:a,clickSource:i,trafsrc:o,ocid:s,formCode:n},l){if(!e)return e;let d=new URLSearchParams;a&&d.set("title",a),t&&d.set("pid",t),i&&d.set(r.Ts.ClickSourceQueryParam,i),s&&d.set("ocid",s),o&&d.set("trafsrc",o),n&&d.set("FORM",n);let[c,p]=e.split("?"),u=(0,r.$c)(new URLSearchParams(p),d),h=(0,r.wW)(u);if(l&&!t){let e=c.indexOf("/buydirect");if(-1!==e){let t=c.slice(e+10);return`https://www.bing.com/shop/buywithmicrosoft${t}${h?`?${h}`:""}`}}return c+(h?`?${h}`:"")}}},45596:function(e,t,a){a.d(t,{$c:function(){return h},DH:function(){return x},F7:function(){return v},Ts:function(){return i},X9:function(){return g},dN:function(){return m},eA:function(){return y},h3:function(){return C},wA:function(){return p},wQ:function(){return b},wW:function(){return u},zt:function(){return f}});var r,i,o=a(72627),s=a(7446),n=a(33744),l=a(43672),d=a(69326),c=a(50880);function p(e){return new URLSearchParams((0,o.iA)()).get(e)}function u(e,t=!1,a=!1){let r=new URLSearchParams(location.search);t&&function(e){let t=["modal-offer-ids","modal-image-ids","pid","title","clksrc","modal-ec-ids"];for(let a=0;a<t.length;a++){let r=t[a];e.delete(r)}}(r),a&&r.delete("disableheader"),e&&e.forEach((e,t)=>{r.set(t,e)});let i=new URLSearchParams;return r.getAll("item").forEach(e=>i.append("item",e)),r.delete("item"),`${r}${i.getAll("item").length>0?"&"+decodeURIComponent(i.toString()):""}`}function h(e,t){let a=new URLSearchParams(e);return t&&t.forEach((e,t)=>{a.set(t,e)}),a}(r=i||(i={})).ClickSourceQueryParam="clksrc",r.ModalCarouselOfferIdsQueryParam="modal-offer-ids",r.ModalCarouselImageIdsQueryParam="modal-image-ids",r.ModalCarouselECIdsQueryParam="modal-ec-ids",r.gameFirstPositionQueryParam="game-first-position",r.itemQueryParam="item",r.AutoShowEdgeSidePane="auto_show_edge_shopping_pane",r.FeaturedComponentKey="featc",r.FeaturedComponentIndex="feati";class g{static getSchemeAndDomain(){return window.location.origin.indexOf("localhost")>-1?window.location.origin:`https://${n.T3.NavTargetHostName}`}}let y=Object.freeze({NtpSdCard:"SDPDP1",NtpEventCard:"NTPMIT",NtpEventCard2:"NTPMIF",NtpCarousel:"CARPDP",NtpToL2Overlay:"STPDPI",NtpToL2OverlayWithoutOfferIds:"STPDPF",NtpToL2OverlayWithBRQ:"STPDPK",NtpAugmentCard:"SHAUG1",NtpSdCardControl:"STPDPG",NtpCarouselControl:"STPDPH",NtpToL2OverlayControl:"STPDPJ",Bing:"SHOPHP",Start:"SSPD01",FullPage:"ANNTS2",BingSDCardclick:"bhshpc",MeStripe:"msmstb",TopNav:"mstntb",AtfTitle:"mscatft",AtfCard:"msatfc",ShoppingTopSpan:"TOPARC",ShoppingViewsCarousel:"arcarc",ShoppingViewsCarousel2:"SHCAR2",ShoppingViewsCarousel1:"SHCAR1",Prong2Pivot:"P2SHPV",Prong2:"P2SHOP",Prong2Fashion:"P2SHFS",Prong2BGPremium:"P2BGPM",Prong2BGPremiumProduct:"P2BGPD",Prong1:"PRSHOP",Prong1BGPremium:"P1BGPM",Prong1BGPremiumProduct:"P1BGPD",MITSHP:"MITSHP",BuyingGuide1:"BGPDP1",BuyingGuideRelatedSearch:"BGLIRS",BuyingGuideInfoPane:"INFOBG",BuyingGuideAds:"SSBG01"});class m{static getBingShoppingQueryParameters(e,t,a=!0){let r=new URLSearchParams;return r.set("entryPoint",e),t&&r.set("FORM",t),"msn"!==e||(0,d.kg)()||r.set("msnrid",s.YT.getRequestId()),a&&n.T3.CurrentMarket!==l.DX.FRFR&&(r.set("adunitId","378983"),r.set("propertyId","316966")),r}static updateBingShoppingQueryParameters(e,t,a,r=!0,i){return e.searchParams.delete("adunitid"),e.searchParams.delete("propertyid"),this.getBingShoppingQueryParameters(t,a,r).forEach((t,a)=>e.searchParams.set(a,t)),i&&e.searchParams.set("ocid",i),e.toString()}static updateUrlIfBingShopping(e,t){return e?.startsWith("https://www.bing.com/shop")?m.updateBingShoppingQueryParameters(new URL(e),t):e}}function f(e){return e?e.replace("?id=/th?","?"):""}function C(){return"1"===p("isembedded")||"1"===p("disableheader")}function v(e){return!e.find(e=>e&&!(0,c.py)(e))}function x(e,t){let a=new URL(e);return Object.keys(t).forEach(e=>{a.searchParams.set(e,t[e])}),a.toString()}function b(e,t,a,r=!0){let i=new URL(e);i.searchParams.delete("adunitid"),i.searchParams.delete("propertyid");let o=new URLSearchParams;return o.set("entryPoint",t),a&&o.set("FORM",a),"msn"!==t||(0,d.kg)()||o.set("msnrid",s.YT.getRequestId()),r&&n.T3.CurrentMarket!==l.DX.FRFR&&(o.set("adunitId","378983"),o.set("propertyId","316966")),o.forEach((e,t)=>i.searchParams.set(t,e)),i.toString()}},31216:function(e,t,a){a.d(t,{H8:function(){return n},RD:function(){return o},Wr:function(){return l},qK:function(){return d}});var r=a(40450),i=a(87906);let o=(e,t,a)=>e?.title?(e?.thumbnail?.image||l(r.r5T,`Video ID [${n(e?.id,t,a)}] has an empty headline image but the content is valid.`),s(e,t,a)):(l(r.Ta7,`Video ID [${n(e?.id,t,a)}] has an empty headline.`),!1),s=(e,t,a)=>{if(e?.videoMetadata?.externalVideoFiles?.length){let i=e.videoMetadata.externalVideoFiles;if(!i?.find(e=>!e.url&&!e.format))return!0;l(r.WWk,`Video ID [${n(e.id,t,a)}] has an invalid 1pp video file.`)}return!1},n=(e,t,a)=>`${e??t??"N/A"}${a?" (playlist) ":""}`,l=(e,t)=>{(0,i.vV)(e,"Data returned by content view does not contain expected video data.",t,{...e.pb})},d=e=>{let{cardContent:t,metadata:a}=e;return{id:e.id,title:t?.title,thumbnail:{image:t?.images?.[0]},videoMetadata:{playTime:a?.videoMetadata.playTime,externalVideoFiles:t?.videoFiles},sourceId:t?.sourceId||""}}},49371:function(e,t,a){a.d(t,{e3:function(){return o},fR:function(){return i}});var r=a(72627);function i(e=(0,r.$t)()){return/^python-requests|^CriteoBot|^ias-|GrapeshotCrawler/.test(e)}function o(e=(0,r.$t)()){if(!e)return!1;let t=(0,r.iA)(),a=t&&t.includes("reqsrc=vp");return -1!==e.indexOf("Yahoo")||-1!==e.indexOf("Yandex")||-1!==e.indexOf("Baiduspider")||-1!==e.indexOf("Bingbot")||-1!==e.indexOf("Googlebot")||-1!==e.indexOf("Google-InspectionTool")||-1!==e.indexOf("msnbot")||!a&&-1!==e.indexOf("HeadlessChrome")}},9723:function(e,t,a){a.d(t,{B:function(){return s}});var r=a(59669),i=a(63033);let o=(0,r.A)`
.ad-choice{filter:var(--filter-color)}`,s=(0,r.A)`
:host{--filter-color:invert(99%) sepia(10%) saturate(0%) hue-rotate(244deg) brightness(120%) contrast(100%)}.ad-choice{align-items:center;display:flex;width:12px;z-index:${"1"}}@media (forced-colors:active){.ad-choice{filter:invert(1) !important}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice{filter:var(--filter-color) !important}}`.withBehaviors(new i.N(null,o))},27742:function(e,t,a){a.d(t,{E:function(){return s}});var r=a(59669),i=a(4126);let o=(0,r.A)`
.ad-label{font-size:12px;border:unset;padding:unset}`,s=(0,r.A)`
.ad-label{align-items:center;border-radius:4px;border:0.5px solid var(--color-neutral-stroke-1,var(--neutral-foreground-rest));color:inherit;display:flex;font-size:11px;padding:0 4px 1px 4px;text-decoration:none;z-index:${"1"}}a[no-border]{border:unset;padding:unset;display:inline-flex}.dsa:hover{text-decoration:underline}`.withBehaviors(new i.o("ruby",!0,o))},75003:function(e,t,a){a.d(t,{m:function(){return n}});var r=a(37180),i=a(72526),o=a(46439),s=a(38380);let n=i.L.compose({name:`${r.c.prefix}-card`,template:s.v,styles:o.R})},72526:function(e,t,a){a.d(t,{L:function(){return g}});var r=a(56911),i=a(96193),o=a(33045),s=a(47429),n=a(60815),l=a(38493),d=a(95239),c=a(31023),p=a(69809),u=a(5291),h=a(99758);class g extends i.z{cardFillColorChanged(e,t){if(t){let e=(0,o.Hs)(t);null!==e&&(this.neutralPaletteSource=t,d.p.setValueFor(this,u.q.create(e.r,e.g,e.b)))}}neutralPaletteSourceChanged(e,t){if(t){let e=(0,o.Hs)(t),a=u.q.create(e.r,e.g,e.b);c.r.setValueFor(this,h.p.create(a))}}handleChange(e,t){this.cardFillColor||d.p.setValueFor(this,e=>e(p.M3).evaluate(e,e(d.p)))}connectedCallback(){super.connectedCallback();let e=(0,s.Zo)(this);if(e){let t=n.cP.getNotifier(e);t.subscribe(this,"fillColor"),t.subscribe(this,"neutralPalette"),this.handleChange(e,"fillColor")}}}(0,r.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,r.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},38380:function(e,t,a){a.d(t,{v:function(){return r}});let r=(0,a(25717).T)()},69329:function(e,t,a){a.d(t,{m:function(){return v}});var r=a(75261);class i extends r.t{}var o=a(37180),s=a(59669),n=a(64187),l=a(22131),d=a(50882),c=a(48196),p=a(83252),u=a(64835),h=a(6032);let g=(0,s.A)` ${(0,n.V)("flex")} :host{align-items:center;outline:none;height:calc(${c.D} * 1px);width:calc(${c.D} * 1px);margin:calc(${c.D} * 1px) 0}.progress{height:100%;width:100%}.background{stroke:${p.F7};fill:none;stroke-width:2px}.determinate{stroke:${u.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out}.indeterminate-indicator-1{stroke:${u.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out;animation:spin-infinite 2s linear infinite}:host([paused]) .indeterminate-indicator-1{animation-play-state:paused;stroke:${p.F7}}:host([paused]) .determinate{stroke:${h.c}}@keyframes spin-infinite{0%{stroke-dasharray:0.01px 43.97px;transform:rotate(0deg)}50%{stroke-dasharray:21.99px 21.99px;transform:rotate(450deg)}100%{stroke-dasharray:0.01px 43.97px;transform:rotate(1080deg)}}`.withBehaviors((0,l.mr)((0,s.A)` .indeterminate-indicator-1,.determinate{stroke:${d.A.FieldText}}.background{stroke:${d.A.Field}}:host([paused]) .indeterminate-indicator-1{stroke:${d.A.Field}}:host([paused]) .determinate{stroke:${d.A.GrayText}}`));var y=a(89757),m=a(69259),f=a(18893);let C=function(e={}){return(0,y.qy)`
        <template
            role="progressbar"
            aria-valuenow="${e=>e.value}"
            aria-valuemin="${e=>e.min}"
            aria-valuemax="${e=>e.max}"
        >
            ${(0,m.z)(e=>"number"==typeof e.value,(0,y.qy)`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${e=>`${44*e.percentComplete/100}px 44px`}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,(0,y.qy)`
                    <slot name="indeterminate">
                        ${(0,f.R)(e.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:(0,y.qy)`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),v=i.compose({name:`${o.c.prefix}-progress-ring`,template:C,styles:g})},25717:function(e,t,a){a.d(t,{T:function(){return i}});var r=a(89757);function i(){return(0,r.qy)`
        <slot></slot>
    `}},75261:function(e,t,a){a.d(t,{t:function(){return n}});var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){let e="number"==typeof this.min?this.min:0,t="number"==typeof this.max?this.max:100,a="number"==typeof this.value?this.value:0,r=t-e;this.percentComplete=0===r?0:Math.fround((a-e)/r*100)}}(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Object)],n.prototype,"value",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"min",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"max",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],n.prototype,"paused",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Number)],n.prototype,"percentComplete",void 0)},34054:function(e,t,a){var r=a(15420);t.A=function(e,t,a){var i=e.length;return a=void 0===a?i:a,!t&&a>=i?e:(0,r.A)(e,t,a)}},82393:function(e,t,a){a.d(t,{A:function(){return M}});var r,i=a(6574),o=(r={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},function(e){return null==r?void 0:r[e]}),s=a(57842),n=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,l=RegExp("[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]","g"),d=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,c=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,p="\\ud800-\\udfff",u="\\u2700-\\u27bf",h="a-z\\xdf-\\xf6\\xf8-\\xff",g="A-Z\\xc0-\\xd6\\xd8-\\xde",y="\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",m="['’]",f="["+y+"]",C="["+h+"]",v="[^"+p+y+"\\d+"+u+h+g+"]",x="(?:\\ud83c[\\udde6-\\uddff]){2}",b="[\\ud800-\\udbff][\\udc00-\\udfff]",_="["+g+"]",w="(?:"+C+"|"+v+")",S="(?:"+_+"|"+v+")",E="(?:"+m+"(?:d|ll|m|re|s|t|ve))?",A="(?:"+m+"(?:D|LL|M|RE|S|T|VE))?",$="(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?",I="[\\ufe0e\\ufe0f]?",P="(?:\\u200d(?:"+["[^"+p+"]",x,b].join("|")+")"+I+$+")*",k="(?:"+["["+u+"]",x,b].join("|")+")"+(I+$+P),D=RegExp([_+"?"+C+"+"+E+"(?="+[f,_,"$"].join("|")+")",S+"+"+A+"(?="+[f,_+w,"$"].join("|")+")",_+"?"+w+"+"+E,_+"+"+A,"\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])|\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])|\\d+",k].join("|"),"g"),T=function(e,t,a){if(e=(0,s.A)(e),void 0===(t=a?void 0:t)){var r;return(r=e,c.test(r))?e.match(D)||[]:e.match(d)||[]}return e.match(t)||[]},R=RegExp("['’]","g"),M=function(e){return function(t){var a;return(0,i.A)(T((a=t,(a=(0,s.A)(a))&&a.replace(n,o).replace(l,"")).replace(R,"")),e,"")}}},16670:function(e,t){var a=RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");t.A=function(e){return a.test(e)}},29952:function(e,t,a){a.d(t,{A:function(){return g}});var r=a(16670),i="\\ud800-\\udfff",o="[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",s="\\ud83c[\\udffb-\\udfff]",n="[^"+i+"]",l="(?:\\ud83c[\\udde6-\\uddff]){2}",d="[\\ud800-\\udbff][\\udc00-\\udfff]",c="(?:"+o+"|"+s+")?",p="[\\ufe0e\\ufe0f]?",u="(?:\\u200d(?:"+[n,l,d].join("|")+")"+p+c+")*",h=RegExp(s+"(?="+s+")|"+("(?:"+[n+o+"?",o,l,d,"["+i+"]"].join("|"))+")"+(p+c+u),"g"),g=function(e){return(0,r.A)(e)?e.match(h)||[]:e.split("")}},96883:function(e,t,a){a.d(t,{A:function(){return o}});var r=a(57842),i=a(33610),o=(0,a(82393).A)(function(e,t,a){var o;return t=t.toLowerCase(),e+(a?(o=t,(0,i.A)((0,r.A)(o).toLowerCase())):t)})},33610:function(e,t,a){a.d(t,{A:function(){return n}});var r=a(34054),i=a(16670),o=a(29952),s=a(57842),n=function(e){e=(0,s.A)(e);var t=(0,i.A)(e)?(0,o.A)(e):void 0,a=t?t[0]:e.charAt(0),n=t?(0,r.A)(t,1).join(""):e.slice(1);return a.toUpperCase()+n}},12165:function(e,t,a){a.d(t,{Id:function(){return b}});var r=a(56911),i=a(92011),o=a(38493);class s extends i.L{constructor(){super(...arguments),this.appearance="primary"}}(0,r.Cg)([o.CF],s.prototype,"appearance",void 0),(0,r.Cg)([(0,o.CF)({attribute:"fill"})],s.prototype,"fill",void 0),(0,r.Cg)([(0,o.CF)({attribute:"color"})],s.prototype,"color",void 0),(0,r.Cg)([o.CF],s.prototype,"download",void 0),(0,r.Cg)([o.CF],s.prototype,"href",void 0),(0,r.Cg)([o.CF],s.prototype,"hreflang",void 0),(0,r.Cg)([o.CF],s.prototype,"ping",void 0),(0,r.Cg)([o.CF],s.prototype,"referrerpolicy",void 0),(0,r.Cg)([o.CF],s.prototype,"rel",void 0),(0,r.Cg)([o.CF],s.prototype,"target",void 0),(0,r.Cg)([o.CF],s.prototype,"type",void 0);var n=a(89757);let l=(0,n.qy)`<a class="control" part="control" download="${e=>e.download}" href="${e=>e.href}" hreflang="${e=>e.hreflang}" ping="${e=>e.ping}" referrerpolicy="${e=>e.referrerpolicy}" rel="${e=>e.rel}" target="${e=>e.target}" type="${e=>e.type}" style="${e=>e.fill&&e.color?`background-color: var(--ad-label-fill-${e.fill}); color: var(--ad-label-color-${e.color})`:void 0}"><slot></slot></a>`;var d=a(59669),c=a(64187),p=a(73477),u=a(22131),h=a(7896),g=a(62047),y=a(57416),m=a(26920),f=a(47810),C=a(14996);let v=(0,d.A)` ${(0,c.V)("inline-block")} :host{box-sizing:border-box;font-family:${h.O};font-size:${g.t};font-weight:400;${""} z-index:4}.control{text-align:center;border-radius:calc(${y.Pb} * 1px);padding:0 6px;min-width:24px;text-decoration:none;height:16px;border:calc(${m.XA} * 1px) solid ${f.l};color:${f.l}}.control:${p.N}{outline:none;border:calc(${m.XA} * 1px) solid ${C.WN}}`.withBehaviors((0,u.mr)((0,d.A)` :host{forced-color-adjust:auto}`));var x=a(651);let b=s.compose({name:`${x.i.prefix}-ad-label`,template:l,styles:v,shadowOptions:{delegatesFocus:!0}})},36880:function(e,t,a){a.d(t,{m:function(){return i}});var r=a(92011);class i extends r.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},58757:function(e,t,a){a.d(t,{Af:function(){return f}});var r=a(36880),i=a(89757),o=a(60402);let s=(0,i.qy)`<span part="image" ${(0,o.K)("imageContainer")}><slot name="image" ${(0,o.K)("image")} @slotchange=${e=>e.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var n=a(59669),l=a(64187),d=a(22131),c=a(7896),p=a(61138),u=a(6032),h=a(74838),g=a(50882);let y=(0,n.A)` ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};font-size:${p.k};font-weight:400;line-height:${p.F};align-items:center;color:${u.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${h.vR} * 2px)}`.withBehaviors((0,d.mr)((0,n.A)` :host,.content{color:${g.A.CanvasText};fill:currentcolor}`));var m=a(651);let f=r.m.compose({name:`${m.i.prefix}-attribution`,template:s,styles:y})},51122:function(e,t,a){a.d(t,{S:function(){return i},m:function(){return c}});var r,i,o=a(56911),s=a(92011),n=a(38493),l=a(60815),d=a(93856);(r=i||(i={})).default="default",r.condensed="condensed",r.infoPane="infoPane",r.infoPane1x3y="infoPane1x3y",r.infoPaneSplitVertical="infoPaneSplitVertical",r.infoPaneSplitHorizontal="infoPaneSplitHorizontal";class c extends s.L{constructor(){super(...arguments),this.layout=i.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(e){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(e):(this.$emit("link-invoked",e),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(e=>e instanceof d.L)}setExpanded(e){this.filteredContentIndicator().forEach(t=>t.expanded=e)}}(0,o.Cg)([n.CF],c.prototype,"layout",void 0),(0,o.Cg)([(0,n.CF)({attribute:"heading-level",mode:"fromView",converter:n.R$})],c.prototype,"headinglevel",void 0),(0,o.Cg)([(0,n.CF)({mode:"fromView"})],c.prototype,"href",void 0),(0,o.Cg)([l.sH],c.prototype,"isGrid",void 0),(0,o.Cg)([l.sH],c.prototype,"anchorTelemetryTag",void 0),(0,o.Cg)([l.sH],c.prototype,"mediaNodes",void 0),(0,o.Cg)([l.sH],c.prototype,"hasAbstract",void 0),(0,o.Cg)([l.sH],c.prototype,"abstract",void 0),(0,o.Cg)([l.sH],c.prototype,"iconSlottedNodes",void 0),(0,o.Cg)([(0,n.CF)({attribute:"image-priority",mode:"boolean"})],c.prototype,"imagePriority",void 0),(0,o.Cg)([n.CF],c.prototype,"target",void 0),(0,o.Cg)([l.sH],c.prototype,"hoverActionsSlottedNodes",void 0),(0,o.Cg)([l.sH],c.prototype,"handleContentCardClickOverride",void 0),(0,o.Cg)([l.sH],c.prototype,"contentIndicatorNodes",void 0)},55461:function(e,t,a){a.d(t,{yr:function(){return L}});var r=a(51122),i=a(89757),o=a(60402),s=a(69259),n=a(416),l=a(10108),d=a(82774),c=a(33744);let p=(0,a(69326).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),u=(0,i.qy)`<div class="footer ${e=>e.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,o.K)("startActionsContainer")}><slot name="start-actions" ${(0,o.K)("startActions")} @slotchange=${e=>e.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,o.K)("endActionsContainer")}><slot name="end-actions" ${(0,o.K)("endActions")} @slotchange=${e=>e.handleEndActionsContentChange()}></slot></span></div>`,h=(0,i.qy)`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,y=(0,i.qy)`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${e=>(e.title&&e.title.match(g)?.[0])??"Earn cash back"}</span></div>`,m=(e,t)=>(0,i.qy)`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${t}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${e.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${e}</span></div>`,f=(0,i.qy)`<div style="display: flex;">${e=>e.id.includes("__")?(0,i.qy)` ${(0,s.z)(e=>e.id.includes("_Christmas"),m("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,s.z)(e=>e.id.includes("_BlackFriday"),m("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,s.z)(e=>e.id.includes("_CyberMonday"),m("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:(0,i.qy)` ${(0,s.z)(e=>e&&!e.id.includes("_NoCashback"),y)} ${(0,s.z)(e=>e,h)} `}</div>`,C=(0,i.qy)`<div style="background: no-repeat center url('${e=>e.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,v=(0,i.qy)`<div class="logo-container"><img src=${p} alt="Microsoft Logo" aria-hidden="true" /></div>`,x=(0,i.qy)`<template ${(0,n.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${e=>e.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,s.z)(e=>e.id.includes("contentcard_tripleCashback"),v)} ${(0,s.z)(e=>e.id.includes("contentcard_edgeReclaim"),v)} ${(0,s.z)(e=>e.id.includes("contentcard_InfoBuyDirectCard"),C)}<slot name="background-image" ${(0,o.K)("backgroundImage")}></slot></span>${(0,s.z)(e=>e.id.includes("BuyDirectCard"),f)}<div class="mask" part="mask"></div><div class="body ${e=>e.hasAbstract?"has-abstract":""} ${e=>e.isGrid?"grid":""}" part="body">${(0,s.z)(e=>e?.mediaNodes?.length>0,(0,i.qy)`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,o.K)("mediaContainer")}><slot name="media" ${(0,o.K)("media")} @slotchange=${e=>e.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,o.K)("iconContainer")} class="${e=>e.iconSlottedNodes&&e.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,o.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,s.z)(e=>e?.mediaNodes?.length===0,(0,i.qy)`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${e=>e.headinglevel} name="heading"><a class="heading" part="heading" href=${e=>e.href?e.href:void 0} target=${e=>e.target?e.target:void 0} @click=${(e,t)=>e.handleContentCardLinkClick(t.event)} data-t="${e=>e.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,s.z)(e=>e.layout!==r.S.default,u)}</div>${(0,s.z)(e=>e.layout===r.S.default,u)}<span part="hover-actions" class="${e=>e.hoverActionsSlottedNodes&&e.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var b=a(64187),_=a(73477),w=a(22131),S=a(59669),E=a(50882),A=a(7896),$=a(61138),I=a(6032),P=a(41123),k=a(47810),D=a(89580),T=a(95239),R=a(86856);let M=(0,S.A)` :host([layout="default"]) .media-wrapper{float:right}`,F=(0,S.A)` :host([layout="default"]) .media-wrapper{float:left}`,O=(0,S.A)` ${(0,b.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${A.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${$.k});line-height:var(--footer-line-height,${$.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${I.c};fill:${I.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${P.K});line-height:var(--abstract-line-height,${P.Z});font-weight:400;grid-column:span 2;box-sizing:content-box;color:${I.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${I.c};fill:${I.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${k.l};font-size:var(--heading-font-size,${D.Y});line-height:var(--heading-line-height,${D.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${_.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${T.p};box-shadow:0px -25px 15px ${T.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${k.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${k.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${T.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${T.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new R.t(M,F),(0,w.mr)((0,S.A)` .heading{color:${E.A.LinkText};background:${E.A.ButtonFace}}.abstract{color:${E.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${E.A.ButtonText};background:${E.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${E.A.ButtonFace};color:${E.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${E.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${E.A.ButtonFace}}`));var B=a(651);let L=r.m.compose({name:`${B.i.prefix}-content-card`,template:x,styles:O,shadowOptions:{delegatesFocus:!0}})},93856:function(e,t,a){a.d(t,{L:function(){return n}});var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,r.Cg)([(0,o.CF)({mode:"boolean"})],n.prototype,"expanded",void 0),(0,r.Cg)([s.sH],n.prototype,"defaultItems",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean",attribute:"animate"})],n.prototype,"shouldanimate",void 0)},97964:function(e,t,a){a.d(t,{rX:function(){return _}});var r=a(93856),i=a(89757),o=a(82774);let s=(0,i.qy)`<span class="icon-container" part="icon-container" aria-hidden="true"><slot name="icon"></slot></span><span class="label-container" part="label-container"><span class="label" part="label"><slot ${(0,o.e)({property:"defaultItems",filter:e=>e instanceof HTMLElement&&null!==e.offsetParent||e instanceof Text&&!!e.textContent?.trim().length})}></slot></span></span>`;var n=a(7896),l=a(61138),d=a(86856),c=a(57416),p=a(64187),u=a(22131),h=a(59669),g=a(63033),y=a(50882);let m=(0,h.A)` :host::after{transform:translateX(-100%) translateX(20px)}:host([animate]) .label{transform:translateX(-100%)}`,f=(0,h.A)` :host::after{transform:translateX(100%) translateX(-20px)}:host([animate]) .label{transform:translateX(100%)}`,C=(0,h.A)` :host{color:#000}:host::after{background:rgba(255,255,255,0.46)}`,v=(0,h.A)` :host{color:#fff}:host::after{background:rgba(0,0,0,0.54)}`,x=(0,h.A)` ${(0,p.V)("inline-flex")} :host{align-items:center;box-sizing:border-box;contain:content;overflow:hidden}.label-container{overflow:hidden}:host,:host::after{${""} border-radius:4px}:host::after{content:"";height:100%;position:absolute;width:100%;z-index:-1}.icon-container,.label{min-height:20px;min-width:20px;display:flex;align-items:center;justify-content:center;fill:currentcolor}:host([animate])::after,.label{transition:transform 250ms cubic-bezier(0.17,0.17,0,1)}.label{font-family:${n.O};font-size:${l.k};font-weight:600;line-height:${l.F};text-overflow:ellipsis;padding:0 4px}:host([expanded][animate])::after,:host([expanded][animate]) .label{transform:translateX(0%)}.label{transform:translateX(-100%)}::slotted([slot="icon"]){display:block;fill:currentcolor}`.withBehaviors(new d.t(m,f),new g.N(C,v),(0,u.mr)((0,h.A)` :host{forced-color-adjust:auto}::slotted([slot="icon"]){color:${y.A.ButtonText};fill:currentcolor}.icon-container,:host([expanded][animate]) .label,:host::after{background:${y.A.ButtonFace};color:${y.A.ButtonText};fill:currentcolor;border-radius:calc(${c.Pb} * 10px)}.label{background:transparent}`));var b=a(651);let _=r.L.compose({name:`${b.i.prefix}-content-indicator`,template:s,styles:x})},42320:function(e,t,a){a.d(t,{Ob:function(){return b}});var r=a(94020),i=a(89757),o=a(82774),s=a(69259);let n=(0,i.qy)`<template><slot ${(0,o.e)({property:"items",filter:e=>e instanceof HTMLElement&&null!==e.offsetParent})}></slot>${(0,s.z)(e=>e.layout===r.Y.list,(0,i.qy)` <span class="topic">${e=>e.topic}</span> `)} ${e=>e.dividerTemplate}</template>`;var l=a(7896),d=a(41123),c=a(47810),p=a(95239),u=a(89580),h=a(86856),g=a(59669),y=a(64187),m=a(22131);let f=(0,g.A)` :host([layout="double"]) .divider-1{left:0}:host([layout="triple"]) .divider-1{left:0}:host([layout="triple"]) .divider-2{left:0}:host([layout="mosaic"]) .divider-1{left:0}:host([layout="mosaic"]) .divider-2{left:1px}`,C=(0,g.A)` :host([layout="double"]) .divider-1{right:0}:host([layout="triple"]) .divider-1{right:0}:host([layout="triple"]) .divider-2{right:0}:host([layout="mosaic"]) .divider-1{right:0}:host([layout="mosaic"]) .divider-2{right:1px}`,v=(0,g.A)` ${(0,y.V)("grid")} :host{box-sizing:border-box;font-family:${l.O};font-size:${d.K};line-height:${d.Z};color:${c.l};height:100%;width:100%;position:relative}:host([layout="single"]){grid-template-columns:1fr}:host([layout="double"]){grid-template-columns:1fr 1fr}:host([layout="split"]){grid-template-rows:1fr 1fr}:host([layout="triple"]){grid-template-columns:1fr 1fr 1fr}:host([layout="mosaic"]){grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}:host([layout="mosaic"]) ::slotted(:first-child){grid-row:1 / span 2;grid-column:1}:host([layout="mosaic"]) ::slotted(msft-content-card:not(:first-child)){--mask-gradient:linear-gradient(rgba(0,0,0,0),${p.p})}:host([layout="list"]){grid-template-rows:auto 1fr 1fr 1fr;grid-template-columns:3fr 2fr}:host([layout="list"]) ::slotted(:first-child){grid-row:1 / span 4;grid-column:1}:host([layout="list"]) ::slotted(msft-content-card:not(:first-child)){background:${p.p};--heading-font-size:${d.K};--heading-line-height:${d.Z}}.topic{grid-row:1;grid-column:2;font-size:${u.Y};line-height:${u.v};background:${p.p};padding:6px 12px}.divider{background:rgba(255,255,255,0.4);position:absolute;left:20px;right:20px;top:20px;bottom:20px;z-index:1;pointer-events:none;opacity:0}:host([layout="double"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="split"]) .divider-1{grid-row:2;height:1px;top:0;opacity:1}:host([layout="triple"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="triple"]) .divider-2{grid-column:3;width:1px;opacity:1}:host([layout="mosaic"]) .divider-1{grid-column:2;grid-row:1 / span 2;width:1px;opacity:1}:host([layout="mosaic"]) .divider-2{grid-column:2;grid-row:2;height:1px;top:0;opacity:1}`.withBehaviors(new h.t(f,C),(0,m.mr)((0,g.A)` .divider{background:none}`));var x=a(651);let b=r.s.compose({name:`${x.i.prefix}-info-pane-slide`,template:n,styles:v})},94020:function(e,t,a){a.d(t,{Y:function(){return i},s:function(){return p}});var r,i,o=a(56911),s=a(89757),n=a(92011),l=a(60815),d=a(38493);(r=i||(i={})).single="single",r.double="double",r.split="split",r.triple="triple",r.mosaic="mosaic",r.list="list";let c=new Map;class p extends n.L{constructor(){super(...arguments),this.dividerTemplate=null,this.layout=i.single}itemsChanged(e,t){this.$fastController.isConnected&&(this.dividerTemplate=function(e){if(c.has(e))return c.get(e);if(e<1)return c.set(e,null),null;let t=Array(e).fill("").map((e,t)=>(0,s.qy)`<div class="divider divider-${t+1}" part="divider"></div>`).reduce((e,t)=>(0,s.qy)`${e}${t}`);return c.set(e,t),t}(this.items.length-1))}}(0,o.Cg)([l.sH],p.prototype,"items",void 0),(0,o.Cg)([l.sH],p.prototype,"dividerTemplate",void 0),(0,o.Cg)([d.CF],p.prototype,"layout",void 0),(0,o.Cg)([d.CF],p.prototype,"topic",void 0)},47131:function(e,t,a){a.d(t,{Bb:function(){return $}});var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{moneyCardContentDataChanged(){"Default"!==this.cardStyle&&void 0===this.moneyCardContentData.actionAppearance&&(this.moneyCardContentData.actionAppearance="outline")}getQuoteColor(e,t,a,r,i){return t?i:this.moneyCardContentData.swapGainLossColor?e?a:r:e?r:a}changeShowingValue(){this.showChangeValue=!this.showChangeValue}connectedCallback(){super.connectedCallback(),this.showChangeValue=!1}}(0,r.Cg)([(0,o.CF)({attribute:"layout"})],n.prototype,"layout",void 0),(0,r.Cg)([o.CF],n.prototype,"cardStyle",void 0),(0,r.Cg)([o.CF],n.prototype,"target",void 0),(0,r.Cg)([s.sH],n.prototype,"moneyCardContentData",void 0),(0,r.Cg)([s.sH],n.prototype,"quoteItems",void 0),(0,r.Cg)([s.sH],n.prototype,"showChangeValue",void 0),(0,r.Cg)([s.sH],n.prototype,"headerTelemetryTag",void 0),(0,r.Cg)([s.sH],n.prototype,"switchValueTelemetryTag",void 0),(0,r.Cg)([s.sH],n.prototype,"seeMoreTelemetryTag",void 0);var l=a(89757),d=a(69259),c=a(68835);let p=(0,l.qy)`<a class="quote-row" part="quote-row" href="${e=>e.quoteHref}" target=${(e,t)=>t.parent.target} aria-label="${e=>e.displayName} ${e=>e.symbol} ${e=>e.price} ${e=>e.changePcnt}" data-t="${e=>e.telemetryTag}"><div class="quote-view" part="quote-view"><div class="quote-title-container" part="quote-title-container"><span class="quote-title" part="quote-title"><p class="quote-title-content" part="quote-title-content" title="${e=>e.displayName} (${e=>e.symbol})">${e=>e.symbol}</p></span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str" title="${e=>e.displayName} (${e=>e.symbol})">${e=>e.displayName}</p></span></div><div class="quote-title-container" part="quote-title-container"><div class="price" part="price"><span class="price-str" part="price-str">${e=>e.price}</span></div></div><button class="change-values ${(e,t)=>t.parent.getQuoteColor(e.gain,e.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(e,t)=>t.parent.getQuoteColor(e.gain,e.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(e,t)=>t.parent.changeShowingValue()}" aria-label="${(e,t)=>t.parent.showChangeValue?`${e.changeValue} ${e.displayName} ${e.changePcnt}`:`${e.changePcnt} ${e.displayName} ${e.changeValue}`}" data-t="${(e,t)=>t.parent.switchValueTelemetryTag}">${(0,d.z)((e,t)=>t.parent.showChangeValue,(0,l.qy)`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${e=>e.changeValue}</span></span>`)} ${(0,d.z)((e,t)=>!t.parent.showChangeValue,(0,l.qy)`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${e=>e.changePcnt}&lrm;</span></span>`)}</button></div></a>`,u=(0,l.qy)`<msft-structured-data-card target=${e=>e.target} :headerTelemetryTag=${e=>e.headerTelemetryTag} :seeMoreTelemetryTag=${e=>e.seeMoreTelemetryTag} :data=${e=>e.moneyCardContentData}><slot name="more-actions" slot="more-actions"></slot><slot name="pin" slot="pin"></slot><slot name="title-icon" slot="title-icon"></slot><div class="quote-list" part="quote-list">${(0,c.ux)(e=>e.quoteItems,p)}</div><slot name="footer-start" slot="footer-start"></slot><slot name="footer-end" slot="footer-end"></slot></msft-structured-data-card>`;var h=a(47810),g=a(89580),y=a(41123),m=a(6032),f=a(61138),C=a(95403),v=a(14996),x=a(26920),b=a(59669),_=a(64187),w=a(22131),S=a(50882);let E=(0,b.A)` ${(0,_.V)("flex")} :host{height:100%;--quote-grid-columns:111px 81px 56px}:host(:focus){outline:none}msft-structured-data-card::part(title-link)::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}.price-str{color:${h.l};font-weight:600;text-align:end;width:100%;font-size:var(--price-content-font-size,${g.Y});line-height:var(--price-content-line-height,${g.v})}.quote-list{margin-top:var(--quote-list-margin-top,12px);display:grid;grid-template-rows:var(--quote-list-grid-rows,repeat(auto-fill,52px));row-gap:var(--quote-list-grid-gap,2px);z-index:1}.quote-title-content{color:${h.l};font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0;font-size:var(--quote-title-font-size,${y.K});line-height:var(--quote-title-line-height,${y.Z})}.sec-title-str{color:${m.c};margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:${f.k};line-height:${f.F}}.quote-row{cursor:pointer;text-decoration:none;padding:var(--quote-row-padding,8px 8px);margin:var(--quote-row-margin,0px 8px)}.quote-row:hover{background:${C.oO}}.change-values{height:24px;font-family:var(--body-font);border-radius:4px;border:0;padding:0;cursor:pointer;outline:none}.change-values:focus-visible{outline-color:${v.WN};outline-width:2px;outline-style:auto}.change-button-area{display:flex;flex-direction:column;justify-content:flex-end}.change-values-percentage{margin-top:4px;margin-bottom:4px;margin-inline-end:8px;display:block;font-size:${f.k};font-weight:600;line-height:${f.F};text-align:end}.price{align-items:center;display:flex}.quote-title-container{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:var(--quote-grid-columns)}.quote-green{color:#ffffff;background:#107c10}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}`.withBehaviors((0,w.mr)((0,b.A)` :host{forced-color-adjust:auto}.title-link:hover{text-decoration:underline}.change-values,.quote-row:hover{forced-color-adjust:none;background:${S.A.ButtonFace};box-shadow:0 0 0 calc((${x.vd} - ${x.XA}) * 1px) ${S.A.LinkText};color:${S.A.ButtonText}}::slotted(*[slot="option-button"]){fill:${S.A.ButtonText}}::slotted([slot="option-button"]:hover){background:${S.A.Highlight};fill:${S.A.HighlightText}}.change-values:focus-visible{outline-color:${S.A.Highlight}}`));var A=a(651);let $=n.compose({name:`${A.i.prefix}-show-quotes-money-card`,template:u,styles:E})},46439:function(e,t,a){a.d(t,{R:function(){return p}});var r=a(59669),i=a(64187),o=a(22131),s=a(50882),n=a(37998),l=a(95239),d=a(47810),c=a(57416);let p=(0,r.A)` ${(0,i.V)("block")} :host{--elevation:4;display:block;contain:content;height:var(--card-height,100%);width:var(--card-width,100%);box-sizing:border-box;background:${l.p};color:${d.l};border-radius:calc(${c.JU} * 1px);${n.ET}}:host(:hover){--elevation:8}:host(:focus-within){--elevation:8}:host{content-visibility:auto}`.withBehaviors((0,o.mr)((0,r.A)` :host{forced-color-adjust:none;background:${s.A.Canvas};box-shadow:0 0 0 1px ${s.A.CanvasText}}`))}}]);