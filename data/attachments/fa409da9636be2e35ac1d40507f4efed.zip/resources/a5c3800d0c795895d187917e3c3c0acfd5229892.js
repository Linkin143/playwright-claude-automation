"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_content-video-player_dist_sub-components_VideoJsCCToggleButton_js"],{10227(t,e,s){s.d(e,{VideoJsCCToggleButton(){return u}});var i,o=s(39610),n=s(56911),l=s(92011),r=s(60815),c=s(89757),d=s(59669),a=s(84540);let h=i=class extends l.L{constructor(){super(...arguments),this.isInitiallyTurnedOn=!0,this.touchTimeout=void 0,this.handleTouchEnd=()=>{this.touchTimeout&&(clearTimeout(this.touchTimeout),this.toggle(),this.removeEventListener("touchend",this.handleTouchEnd))}}connectedCallback(){super.connectedCallback(),void 0===i.globalIsTurnedOn&&(i.globalIsTurnedOn=this.isInitiallyTurnedOn),i.setStyle()}disconnectedCallback(){super.disconnectedCallback(),this.resetStyle()}handleTouchStart(){this.touchTimeout&&clearTimeout(this.touchTimeout),this.touchTimeout=window.setTimeout(()=>{this.touchTimeout=void 0,this.removeEventListener("touchend",this.handleTouchEnd)},300),this.addEventListener("touchend",this.handleTouchEnd)}toggle(){i.globalIsTurnedOn=!i.globalIsTurnedOn,i.setStyle(),this.$emit("toggle",{isTurnedOn:i.globalIsTurnedOn})}resetStyle(){document.documentElement.style.setProperty("--vjs-text-track-display-mode","initial")}static setStyle(){document.documentElement.style.setProperty("--vjs-text-track-display-mode",this.globalIsTurnedOn?"initial":"none")}};h.globalIsTurnedOn=void 0,(0,n.Cg)([r.sH],h.prototype,"localizedStrings",void 0),(0,n.Cg)([r.sH],h,"globalIsTurnedOn",void 0),h=i=(0,n.Cg)([(0,l.E)({name:"cc-toggle-button",template:c.qy`
        <button @click="${t=>t.toggle()}" @touchstart="${t=>t.handleTouchStart()}" aria-pressed='${()=>!!h.globalIsTurnedOn}' aria-label="${t=>t?.localizedStrings?.captions}">
            <img src="${t=>h.globalIsTurnedOn?a.M0:a.b1}" role="presentation" />
        </button>
    `,shadowOptions:null,styles:d.A`
        button {
            background: none;
            border: none;
            cursor: pointer;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        @media (prefers-color-scheme: light) {
            button {
                filter: invert(1);
            }
        }
    `})],h);class u extends(o.default.getComponent("Component")){constructor(t,e){super(t,e),this.ccToggleButton=new h,this.el().appendChild(this.ccToggleButton)}}}}]);