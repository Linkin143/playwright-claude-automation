(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["libs_icons-wc_icons_ThumbDown_svg-libs_icons-wc_icons_ThumbDownFilled_svg-libs_icons-wc_icons-201ed3"],{96016(e,t,a){"use strict";a.d(t,{},{A:'<svg width="20" height="20" viewBox="0 0 20 20"><path d="M12.35 15.85a.5.5 0 0 1-.7 0L6.16 10.4a.55.55 0 0 1 0-.78l5.49-5.46a.5.5 0 0 1 .7.7L7.2 10l5.16 5.15c.2.2.2.5 0 .7Z"/></svg>'})},2399(e,t,a){"use strict";a.d(t,{},{A:'<svg width="20" height="20" viewBox="0 0 20 20"><path d="M7.65 4.15c.2-.2.5-.2.7 0l5.49 5.46c.21.22.21.57 0 .78l-5.49 5.46a.5.5 0 0 1-.7-.7L12.8 10 7.65 4.85a.5.5 0 0 1 0-.7Z"/></svg>'})},32558(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 16.7c.34.98 1.63 1.43 2.43.6.16-.17.33-.36.44-.52.32-.48.45-1.12.5-1.73.05-.63.02-1.3-.05-1.91-.06-.62-.16-1.18-.24-1.59v-.05H12a3 3 0 0 0 2.96-3.54l-.69-3.76A4.5 4.5 0 0 0 8.67.67l-5.6 1.52c-.92.25-1.62 1-1.8 1.92L.9 5.88c-.27 1.39.79 2.56 1.92 3 .32.13.61.3.84.5 1.7 1.5 2.32 2.72 3.38 4.84.36.71.72 1.68 1 2.49Zm1.96-5.58v.01l.01.03a8.94 8.94 0 0 1 .13.58c.08.4.17.92.23 1.5s.09 1.18.04 1.73c-.04.55-.16.98-.34 1.25-.05.1-.17.22-.32.39-.2.2-.63.16-.76-.23-.29-.82-.67-1.83-1.05-2.6-1.07-2.14-1.76-3.5-3.62-5.15-.34-.3-.74-.52-1.13-.68-.89-.34-1.45-1.14-1.3-1.87l.35-1.77c.1-.56.53-1 1.07-1.15l5.6-1.53a3.5 3.5 0 0 1 4.37 2.75l.68 3.76A2 2 0 0 1 12 10.5h-1.5a.5.5 0 0 0-.48.62Z"/></svg>'})},56298(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48 17.3c-.8.83-2.09.38-2.43-.6-.28-.8-.64-1.77-1-2.48C6 12.1 5.37 10.9 3.67 9.37c-.23-.2-.52-.36-.84-.49C1.7 8.44.63 7.27.9 5.88l.36-1.77a2.5 2.5 0 0 1 1.8-1.92L8.66.66a4.5 4.5 0 0 1 5.6 3.54l.69 3.76A3 3 0 0 1 12 11.5h-.88l.01.05c.08.41.18.97.24 1.58.07.62.1 1.29.05 1.92a3.68 3.68 0 0 1-.5 1.73c-.11.16-.28.35-.44.52Z"/></svg>'})},94725(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 1.3C8.4.31 9.68-.14 10.48.7c.16.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H12a3 3 0 0 1 2.96 3.54l-.69 3.76a4.5 4.5 0 0 1-5.6 3.53l-5.6-1.52a2.5 2.5 0 0 1-1.8-1.92L.9 12.12c-.27-1.39.79-2.56 1.92-3 .32-.13.61-.3.84-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49Zm1.96 5.58v-.01l.01-.03a9.08 9.08 0 0 0 .13-.58c.08-.4.17-.92.23-1.5s.09-1.18.04-1.73a2.73 2.73 0 0 0-.34-1.25 3.26 3.26 0 0 0-.32-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.89.34-1.45 1.14-1.3 1.87l.35 1.77c.1.56.53 1 1.07 1.15l5.6 1.53c1.98.54 4-.73 4.37-2.75l.68-3.76A2 2 0 0 0 12 7.5h-1.5a.5.5 0 0 1-.48-.62Z"/></svg>'})},39677(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48.7c-.8-.83-2.09-.38-2.43.6-.28.8-.64 1.77-1 2.48C6 5.9 5.37 7.1 3.67 8.63c-.23.2-.52.36-.84.49-1.13.44-2.2 1.61-1.92 3l.36 1.77a2.5 2.5 0 0 0 1.8 1.92l5.6 1.52a4.5 4.5 0 0 0 5.6-3.53l.69-3.76A3 3 0 0 0 12 6.5h-.88l.01-.05c.08-.41.18-.97.24-1.59.07-.6.1-1.28.05-1.9a3.68 3.68 0 0 0-.5-1.74 4.16 4.16 0 0 0-.44-.52Z"/></svg>'})},25854(e,t,a){"use strict";a.d(t,{n:()=>T});var i,n,r,o,l,s,d,c,p=a(13292);(i=l||(l={}))[i.Success=1]="Success",i[i.Error=2]="Error",(n=s||(s={})).LinkedIn="LinkedIn",n.Taboola="Taboola",n.Outbrain="Outbrain",n.Oath="Oath",n.MediaNet="MediaNet",n.MGID="MGID",n.Bing1="Bing1",n.Bing2="Bing2",n.TripleLift="TripleLift",n.Yengo="Yengo",n.AdYouLike="AdYouLike",n.Baidu="Baidu",n.Popin="Popin",n.AppNexus="AppNexus",n.InMobi="InMobi",(r=d||(d={}))[r.LinkedIn=804]="LinkedIn",r[r.Taboola=42]="Taboola",r[r.Outbrain=164]="Outbrain",r[r.Oath=25]="Oath",r[r.MediaNet=142]="MediaNet",r[r.MGID=358]="MGID",r[r.Bing1=1126]="Bing1",r[r.Bing2=1126]="Bing2",r[r.TripleLift=28]="TripleLift",r[r.Yengo=0]="Yengo",r[r.AdYouLike=259]="AdYouLike",r[r.Baidu=1020]="Baidu",r[r.Popin=0]="Popin",r[r.AppNexus=32]="AppNexus",r[r.InMobi=333]="InMobi",(o=c||(c={})).CookieSyncUrl="cookieSyncUrl",o.PixelSync="pixelSync";var g=a(96500),u=a(87906),m=a(40450),h=a(24318),b=a(94108),f=a(29270),y=a(33744),v=a(73632),C=a(72627),x=a(92170),w=a(7446),k=a(99252),$=a(66012),S=a(37521);class T{constructor(e){this.config=e,this.isCookieSyncExecuted=!1,this.cookieSyncExpiryName="CookieSyncExpiry",this.expiryTimeInMillis=2592e5,this.cookieService=new x.O}async processCookieSync(){if(await (0,$._0)()||this.cookieService.getBrowserOptoutStatus())return;let e=this.cookieService.getMsaOptoutCookieData();if(e&&"1"===e)return;let t=this.config&&this.config.cookieSync;if(!t||!this.config.isCookieSyncEnabled||this.isCookieSyncExecuted)return;if((0,h.Lg)().supported){let e=new Date,t=(0,h.Lg)().getItem(this.cookieSyncExpiryName);if(t&&e.getTime()<+t+this.expiryTimeInMillis)return}let a=()=>{let e=this.getTCString();for(let a of Object.keys(t)){let i=(0,S.f)(b.Rb?.CurrentFlightSet?.has(p.Wm));this.partnerCookieHandler(a,t[a],i?"1":"0",e)}};if(window.__tcfapi?await window.__tcfapi("getTCData",2,(e,i)=>{if(i)if(e.gdprApplies){if("tcloaded"===e.eventStatus&&0!=Object.keys(e.vendor.consents).length)for(let a of Object.keys(t)){let{geo_country:i}=(0,f.MI)();("CN"===(i?.toUpperCase()??"")&&["songheng"].includes(a.toLowerCase())||e.vendor.consents[d[a]])&&this.partnerCookieHandler(a,t[a],e.gdprApplies?"1":"0",e.tcString)}}else a();else g.v.log("tcData fectch failed")}):a(),(0,h.Lg)().supported){let e=new Date().getTime();(0,h.Lg)().setItem(this.cookieSyncExpiryName,e.toString())}w.YT.sendClientLogEvent({message:`processed cookie sync. Locale: ${b.Rb.Locale}, AppType: ${y.T3.AppType}`,type:"information"}),this.isCookieSyncExecuted=!0}getTCString(){let e="eupubconsent-v2=",t=decodeURIComponent(document.cookie).split(";");for(let a=0;a<t.length;a++){let i=t[a].trim();if(0==i.indexOf(e))return i.substring(e.length).trim()}return""}async partnerCookieHandler(e,t,a,i){if(!t||!t.cookieSyncUrl)return void w.YT.sendAppErrorEvent((0,u.$5)(m.MpT,`${e} is missing cookie sync url`));try{this.disableSyncForPartner(e)||(!0===t.pixelSync?this.callPixelSync(e,t,a,i):this.downloadScript(t.cookieSyncUrl))}catch{w.YT.sendAppErrorEvent((0,u.$5)(m.A0k,`Cookie sync error while calling ${e}`))}}disableSyncForPartner(e){let t=e.toLocaleLowerCase(),a=b.Rb?.Locale?.toLowerCase()||"";return!["linkedin","bing1","bing2"].includes(t)&&("taboola"===t?b.Rb?.CurrentFlightSet?.has("prg-ad-no-tabl")||!["en-us","ja-jp","ko-kr"].includes(a):"popin"===t?!["ja-jp","ko-kr"].includes(a):"baidu"===t?!["zh-cn","zh-hk","ja-jp","ko-kr"].includes(a):"songheng"!==t||!["zh-cn"].includes(a))}async downloadScript(e){if(!e||!(0,v.S)()||this.scriptAlreadyExists(e))return;let t=(0,C.C7)(e);t.onload=()=>{w.YT.sendClientLogEvent({message:`Successfully downloaded cookie sync script: ${e}`,type:"information"})},t.onerror=t=>{w.YT.sendAppErrorEvent((0,u.$5)(m.B8p,"Failed to download cookie sync JS",`source url: ${e}, error: ${t}`))},document.head.appendChild(t)}async callPixelSync(e,t,a,i){if(e){let e=this.formatPixelSyncUrl(t.cookieSyncUrl,a,i);this.fireImagePixel(e)}}formatPixelSyncUrl(e,t,a){location.href.toLowerCase().indexOf("native-ad.html")>-1&&(document.getElementsByTagName("head")[0].setAttribute("data-client-settings",'{"pagetype": "gallery", "browser": {"browserType":"chrome", "version":"62", "ismobile":"true"}, "locale":{"language":"en", "market":"us"}, "aid": "activity1"}'),b.Rb.initializeHeadData());let i=0;b.Rb.ClientSettings&&b.Rb.ClientSettings.browser&&b.Rb.ClientSettings.browser.ismobile&&(i=1);let n=e.replace("<rid>",b.Rb.ClientSettings&&b.Rb.ClientSettings.aid?b.Rb.ClientSettings.aid:"").replace("<lang>",b.Rb.Locale?b.Rb.Locale:"").replace("<dgk>",b.Rb.ClientSettings&&b.Rb.ClientSettings.browser&&b.Rb.ClientSettings.browser.browserType?b.Rb.ClientSettings.browser.browserType:"").replace("<imd>",i.toString()).replace("<pn>",b.Rb.ClientSettings&&b.Rb.ClientSettings.pagetype?b.Rb.ClientSettings.pagetype:"").replace("<rf>",document.referrer).replace("<tp>",location.href).replace("<gdpr>",t).replace("<gdpr_consent>",a),r=(0,k.ab)();return r?n.replace("<userid>",r):n.replace("<userid>","")}scriptAlreadyExists(e){let t=document.getElementsByTagName("script");for(let a=t.length;a--;)if(t[a].src===e)return!0;return!1}fireImagePixel(e){new Image(1,1).src=e}}},37521(e,t,a){"use strict";var i=a(29270),n=a(3677),r=a(47211),o=a(73632);function l(e=!1){if(e)return(0,o.S)()&&null!=document.getElementById(n.z);let t=!1,{geo_country:a,geo_subdivision:s}=(0,i.MI)(),d=a?.toUpperCase()??"",c=s?.toUpperCase()??"";return d&&r.XD.includes(d)&&("CA"!==d||"QUEBEC"===c)&&(t=!0),t}a.d(t,{f:()=>l})},66728(e,t,a){"use strict";var i=a(40450);(0,i.KR6)(53e3,i.XkX),(0,i.KR6)(53001,i.XkX),(0,i.KR6)(53002),(0,i.KR6)(53003),(0,i.KR6)(53004),(0,i.KR6)(53005,i.XkX),(0,i.KR6)(53006,i.XkX),(0,i.KR6)(53007,i.XkX),(0,i.KR6)(53008),(0,i.KR6)(53009),(0,i.KR6)(53010,i.XkX),(0,i.KR6)(53011,i.XkX),(0,i.KR6)(53012),(0,i.KR6)(53013,i.XkX),(0,i.KR6)(53014,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(53015,i.XkX),(0,i.KR6)(53016,i.XkX),(0,i.KR6)(53031,i.XkX),(0,i.KR6)(53032,i.XkX),(0,i.KR6)(53050),(0,i.KR6)(53051),(0,i.KR6)(53055),(0,i.KR6)(53062),(0,i.KR6)(53063),(0,i.KR6)(53064),(0,i.KR6)(53065),(0,i.KR6)(53099),(0,i.KR6)(53151,i.XkX),(0,i.KR6)(53156,i.XkX),(0,i.KR6)(53161,i.XkX),(0,i.KR6)(54001,i.XkX),(0,i.KR6)(54002),(0,i.KR6)(54003),(0,i.KR6)(54004),(0,i.KR6)(54005),(0,i.KR6)(54006,i.XkX),(0,i.KR6)(54007),(0,i.KR6)(54008),(0,i.KR6)(54009),(0,i.KR6)(54010),(0,i.KR6)(54011),(0,i.KR6)(54012),(0,i.KR6)(54013),(0,i.KR6)(54014),(0,i.KR6)(54015),(0,i.KR6)(54016),(0,i.KR6)(54017),(0,i.KR6)(54101,i.XkX),(0,i.KR6)(54102,i.XkX),(0,i.KR6)(54103),(0,i.KR6)(54104),(0,i.KR6)(54105),(0,i.KR6)(54106),(0,i.KR6)(56014),(0,i.KR6)(56015),(0,i.KR6)(56016),(0,i.KR6)(56017),(0,i.KR6)(56018),(0,i.KR6)(56019),(0,i.KR6)(56020),(0,i.KR6)(56021),(0,i.KR6)(56022),(0,i.KR6)(56023),(0,i.KR6)(56024),(0,i.KR6)(56025),(0,i.KR6)(56026),(0,i.KR6)(56027),(0,i.KR6)(56028),(0,i.KR6)(56029),(0,i.KR6)(56030),(0,i.KR6)(56031),(0,i.KR6)(56032),(0,i.KR6)(56033),(0,i.KR6)(56034),(0,i.KR6)(56035),(0,i.KR6)(56036),(0,i.KR6)(56037),(0,i.KR6)(60301,i.XkX),(0,i.KR6)(60302),(0,i.KR6)(60303),(0,i.KR6)(60304),(0,i.KR6)(60305),(0,i.KR6)(60306);let n=(0,i.KR6)(70100),r=(0,i.KR6)(70101);(0,i.KR6)(70102,i.imi,(0,i.N5g)(!0));let o=(0,i.KR6)(70103);(0,i.KR6)(70104),(0,i.KR6)(70105);let l=(0,i.KR6)(224500,i.XkX,(0,i.N5g)(!0));(0,i.KR6)(224501);let s=(0,i.KR6)(224502);a.d(t,{},{Jl:n,NZ:o,Om:r,ZO:s,eM:l})},33335(e,t,a){"use strict";var i=a(40450);(0,i.KR6)(8110),(0,i.KR6)(8111),(0,i.KR6)(8112),(0,i.KR6)(8113),(0,i.KR6)(8114),(0,i.KR6)(8115),(0,i.KR6)(8116),(0,i.KR6)(8117),(0,i.KR6)(8118),(0,i.KR6)(8119),(0,i.KR6)(8120),(0,i.KR6)(8121),(0,i.KR6)(8122),(0,i.KR6)(8123),(0,i.KR6)(8124),(0,i.KR6)(8125);let n=(0,i.KR6)(8126),r=(0,i.KR6)(38300,i.imi,(0,i.N5g)(!0)),o=(0,i.KR6)(38301,i.imi,(0,i.N5g)(!0)),l=(0,i.KR6)(38302),s=(0,i.KR6)(38303),d=(0,i.KR6)(38304),c=(0,i.KR6)(38305),p=(0,i.KR6)(38306),g=(0,i.KR6)(38307);(0,i.KR6)(38310,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(38314,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(38315,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(38316),(0,i.KR6)(38317);let u=(0,i.KR6)(38318),m=(0,i.KR6)(38319,i.imi,(0,i.N5g)(!0)),h=(0,i.KR6)(38320),b=(0,i.KR6)(38321,i.imi,(0,i.N5g)(!0)),f=(0,i.KR6)(38322,i.imi,(0,i.N5g)(!0)),y=(0,i.KR6)(38323),v=(0,i.KR6)(38324),C=(0,i.KR6)(38325);(0,i.KR6)(38326,i.imi,(0,i.N5g)(!0));let x=(0,i.KR6)(38327,i.imi),w=(0,i.KR6)(38328),k=(0,i.KR6)(38329);(0,i.KR6)(38330);let $=(0,i.KR6)(38331,i.imi,(0,i.N5g)(!0));(0,i.KR6)(38332),(0,i.KR6)(38333);let S=(0,i.KR6)(38334,i.yfd,(0,i.N5g)(!0));(0,i.KR6)(38335,i.yfd,(0,i.N5g)(!0)),(0,i.KR6)(38336,i.yfd,(0,i.N5g)(!0)),(0,i.KR6)(38337,i.yfd,(0,i.N5g)(!0)),(0,i.KR6)(38340,i.yfd,(0,i.N5g)(!1)),(0,i.KR6)(38341,i.yfd,(0,i.N5g)(!1));let T=(0,i.KR6)(38342);(0,i.KR6)(38343);let _=(0,i.KR6)(38344),I=(0,i.KR6)(38345),A=(0,i.KR6)(38346),D=(0,i.KR6)(38347),z=(0,i.KR6)(38348);(0,i.KR6)(38349),(0,i.KR6)(38350,i.imi,(0,i.N5g)(!0)),(0,i.KR6)(38355,i.imi,(0,i.N5g)(!0));let F=(0,i.KR6)(38360);(0,i.KR6)(38361);let R=(0,i.KR6)(38362),L=(0,i.KR6)(38363),M=(0,i.KR6)(38364),E=(0,i.KR6)(38365,i.XkX),B=(0,i.KR6)(38366),P=(0,i.KR6)(38367);(0,i.KR6)(38368);let O=(0,i.KR6)(38369),N=(0,i.KR6)(38370);(0,i.KR6)(38371),(0,i.KR6)(38372);let H=(0,i.KR6)(38373);(0,i.KR6)(38374);let q=(0,i.KR6)(38375);(0,i.KR6)(38376);let W=(0,i.KR6)(38377),K=(0,i.KR6)(38378);(0,i.KR6)(38379);let U=(0,i.KR6)(38381),V=(0,i.KR6)(38382);a.d(t,{},{Ai:s,Ax:$,D8:H,Fw:T,Gu:y,HW:k,J2:R,KL:E,Kb:O,M5:D,MX:g,MY:n,Nf:C,ON:u,P8:S,PY:x,Qj:h,Qk:l,R_:c,TE:B,Xq:W,Y0:f,YJ:K,Y_:P,bV:_,dS:N,hq:L,jR:U,lP:q,lb:d,mg:A,mx:b,nj:v,pV:m,r4:r,s6:w,s8:I,sI:o,tD:z,vp:V,vy:p,x1:F,zV:M})},2274(e,t,a){"use strict";let i;var n=a(96500),r=a(10316);let o="DEFAULT",l={},s={},d={};function c(e,t=o){let a=l[t];a&&a.has(e)&&(a&&a.delete(e)&&0===a.size&&s[t]&&(i=setTimeout(()=>0===a.size&&s[t](null),200)),r.M.singleMark(e),n.v.log(`[vpreadyHelper] resolveVpMark ${e} scope ${t} remainingMarkers ${a.size}`))}function p(e,t=o){i&&clearTimeout(i),l[t]||(l[t]=new Set),l[t].add(e),n.v.log(`[vpreadyHelper] addVpMarker ${e} scope ${t} remainingMarkers ${l[t].size}`)}function g(e=o){return l[e]}function u(e=o){return d[e]=d[e]||new Promise(t=>{s[e]=t}),d[e]}a.d(t,{CI:()=>c,bP:()=>g,cX:()=>p,gR:()=>u})},73559(e,t,a){"use strict";var i=a(61473),n=a(7446),r=a(62514),o=a(35150),l=a(40450),s=a(33744),d=a(98794),c=a(89757),p=a(94172);let g={[r.C.bingDailyQuizCard]:"bingDailyQuizCard",[r.C.casualGamesCard]:"casualGamesCard",[r.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[r.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[r.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[r.C.communityCard]:"communityCard",[r.C.dailyBriefCard]:"dailyBriefCard",[r.C.dailyGreetingCard]:"dailyGreetingCard",[r.C.dailyMomentsCard]:"dailyMomentsCard",[r.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[r.C.dailyWonderQuoteCard]:"dailyWonderCopilotCard",[r.C.donationNpoCard]:"donationNpoCard",[r.C.electionCard]:"electionCard",[r.C.entertainmentPremierCard]:"entertainmentPremierCard",[r.C.esportsCard]:"esportsCard",[r.C.healthCard]:"bingHealthCard",[r.C.horoscopeAnswerCard]:"horoscopeCard",[r.C.hotListCard]:"hotListCard",[r.C.mangaCard]:"mangaCard",[r.C.mangaCarousel]:"mangaCarousel",[r.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[r.C.onThisDayCard]:"onThisDayCard",[r.C.prismCarouselCard]:"prismCarouselCard",[r.C.qnaCard]:"qnaCard",[r.C.realEstateCard]:"realEstateCard",[r.C.recipesCard]:"recipesCard",[r.C.richCalendarCard]:"richCalendarCard",[r.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[r.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[r.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[r.C.shoppingCarouselCard]:"shoppingCarousel",[r.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[r.C.shoppingRiverCard]:"shoppingRiverCard",[r.C.shoppingSdCard]:"shoppingSdCard",[r.C.topCommentsCard]:"topCommentsCard",[r.C.trendingNowCard]:"trendingNowWC",[r.C.trendingSearchCard]:"trendingSearchCard",[r.C.weatherCard]:"weatherCard",[r.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[r.C.winAppCard]:"winAppCard"},u={[r.C.bingDailyQuizCard]:"bingDailyQuizCard",[r.C.boostAdCard]:"boostAdCard",[r.C.casualGamesCard]:"casualGamesCard",[r.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[r.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[r.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[r.C.communityCard]:"communityCard",[r.C.contentGroupCard]:"contentGroupCard",[r.C.creatorPromotionCarousel]:"watchCreatorPromotionCarousel",[r.C.creatorSpotlightCard]:"creatorSpotlightCard",[r.C.dailyBriefCard]:"dailyBriefCard",[r.C.dailyGreetingCard]:"dailyGreetingCard",[r.C.dailyMomentsCard]:"dailyMomentsCard",[r.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[r.C.dailyWonderQuoteCard]:"dailyWonderQuoteCard",[r.C.donationNpoCard]:"donationNpoCard",[r.C.electionCard]:"electionCard",[r.C.entertainmentPremierCard]:"entertainmentPremierCard",[r.C.esportsCard]:"esportsCard",[r.C.healthCard]:"bingHealthCard",[r.C.healthRiverCard]:"healthRiverCard",[r.C.healthTipCard]:"healthTipCard",[r.C.horoscopeAnswerCard]:"horoscopeCard",[r.C.hotListCard]:"hotListCard",[r.C.mangaCard]:"mangaCard",[r.C.mangaCarousel]:"mangaCarousel",[r.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[r.C.onThisDayCard]:"onThisDayCard",[r.C.prismCarouselCard]:"prismCarouselCard",[r.C.qnaCard]:"qnaCard",[r.C.quizCard]:"quizCard",[r.C.realEstateCard]:"realEstateCard",[r.C.recipesCard]:"recipesCard",[r.C.richCalendarCard]:"richCalendarCard",[r.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[r.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[r.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[r.C.shoppingCarouselCard]:"shopping-carousel",[r.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[r.C.shoppingRiverCard]:"shoppingRiverCard",[r.C.shoppingSdCard]:"shoppingSdCard",[r.C.shoppingTopSectionCard]:"shoppingTopSectionCard",[r.C.topCommentsCard]:"topCommentsCard",[r.C.trendingNowCard]:"trendingNowCard",[r.C.trendingSearchCard]:"trendingSearchCard",[r.C.weatherCard]:"weather",[r.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[r.C.winAppCard]:"winAppCard"},m=(e,t)=>{if(!t)return e;let a="";if("ext"in t.contract){let e=t.contract.ext;a=`${e.row}_${e.col}`}return`${e}_${a}`},h=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{wpoMetadata:e.wpoMetadata,mapperArgs:e.mapperArgs,parentTelemetry:e.telemetryObject,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback,cardType:e.cardType},attributes:{style:`grid-area:${e.gridArea};width:${e.mapperArgs?.displaySettings?.cardWidth}px;contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject})}
`;(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize},attributes:{style:`grid-area:${e.gridArea};`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject})}
`;let b=(0,c.qy)`
    ${e=>{let t;return e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{attributes:{style:`grid-area:${e.gridArea}${(t=e.configInfo?.configRef?.experienceType)===i.yXx||t===i.Ohn?";width:100%":""}`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize},telemetryObject:e.telemetryObject})}}
`;(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:"edgeChromium"===s.T3.AppType})}
`;let f=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,cardMetadata:e.mapperArgs?e.mapperArgs.cardMetadata.data:null,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:"edgeChromium"===s.T3.AppType})}
`,y=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${m(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:!1})}
`;a.d(t,{},{BQ(e,t){let{configOptions:a,cardMetadata:i,hasLoadedCallback:r}=e;t||(t=o.G[i.type]),t||n.YT.sendAppErrorEvent({...l.ODw,message:"No card template type found",pb:{...l.ODw.pb,cardType:i.type}});let s=u[t],c={id:s,childTemplateType:t,mapperArgs:e,configInfo:a,hasLoadedCallback:r,cardType:i?.cardType};return(0,d.bw)({id:s,experienceType:(a&&a)?.configRef?.experienceType,mapperArgs:e},c,null,!0)},R0:u,eW:y,mO:f,ns:b,qq:g,wT:h,zZ:m})},83488(e,t,a){"use strict";var i=a(87906),n=a(40450),r=a(44978),o=a(69828),l=a(62514),s=a(98794),d=a(72287),c=a(82368);function p(e){let{cardMetadata:t,parentTelemetryObject:a,configOptions:l,layoutTemplateName:p,getReplacementCardsCallback:g,refreshFeedCallback:u,goToPersonalizeCallback:m,visualReadinessCallback:h,isArticleFreInInfoPane:b,cardActionClickHandler:f}=e,y=l&&l.childExperienceReferencesWC?l.childExperienceReferencesWC.articleFreCard:l,v=[];v=t.subItems&&t.subItems.length?t.subItems:t.subCards,t.subCards=v,t.subItems=void 0;let C=(0,d.H8)(t,(r.J.dismiss<<1)-1),x=(C&r.J.dismiss)!=0?(0,c.Eb)(e,C,t.id,a):{id:t.id,childTemplateType:"article-fre-card",articleFreConfigInfo:y,parentTelemetryObject:a,subCards:v,getReplacementCardsCallback:g,refreshFeedCallback:u,goToPersonalizeCallback:m,cardActionClickHandler:f,visualReadinessCallback:h,isArticleFreInInfoPane:b};return(0,s.bw)({id:t.id,experienceType:y?.configRef?.experienceType,mapperArgs:e},x,(e,t)=>{let a=t.cardSize;return a!==o.u._1x_2y&&a!==o.u._2x_2y&&(0,i.vV)(n.Qhr,`Article Fre Card mapped as ${a} on ${e} in ${p}`),{}},!0)}function g(e,t){if(t===l.C.articleFreCard||t===l.C.recommendedInterestsCard)return!0;if(t===l.C.infopaneCard){for(let t of e.subItems&&e.subItems.length?e.subItems:e.subCards)if("ArticleFre"===t.type&&"FreFeed"===t.id)return!0}return!1}a.d(t,{i:()=>g,z:()=>p})},10371(e,t,a){"use strict";var i=a(2375),n=a(89757);let r=(0,n.qy)`
    <fluent-card
        style="${e=>e.isArticleFreInInfoPane?"":"grid-area: "+e.gridArea}"
        class="${e=>e.cardSize}"
    >
        <article-fre
            config-instance-src=${e=>e.articleFreConfigInfo&&(0,i.v)(e.articleFreConfigInfo)}
            config-shared-ns=${e=>e.articleFreConfigInfo&&e.articleFreConfigInfo.configRef&&e.articleFreConfigInfo.configRef.sharedNs}
            instance-id=${e=>e.articleFreConfigInfo&&e.articleFreConfigInfo.instanceId}
            size=${e=>e.cardSize}
            :parentTelemetry=${e=>e.parentTelemetryObject}
            :subCards=${e=>e.subCards}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :refreshFeedCallback=${e=>e.refreshFeedCallback}
            :goToPersonalizeCallback=${e=>e.goToPersonalizeCallback}
            :visualReadinessCallback=${e=>e.visualReadinessCallback}
            :cardActionClickHandler=${e=>e.cardActionClickHandler}
        >
        </article-fre>
    </fluent-card>
`;a.d(t,{},{Q:r})},59409(e,t,a){"use strict";var i=a(73559);let n={getFeedDataForCard:e=>(e.cardMetadata.renderFromHomePage&&(e.cardSlot.layouts={C4:"_1x_2y",C3:"_1x_2y",C2:"_1x_2y"}),e.cardMetadata.cardType=e?.activeBoard?`${e.cardMetadata.type}_${e?.activeBoard}`:e.cardMetadata.type,(0,i.BQ)(e)),viewTemplate:i.wT},r=i.wT;a.d(t,{},{D:n,H:r})},42537(e,t,a){"use strict";var i,n,r=a(40201),o=a(11803),l=a(69828),s=a(35177),d=a(62679),c=a(44776),p=a(26330),g=a(47517),u=a(60124),m=a(89757),h=a(69259),b=a(44978),f=a(86294),y=a(77833),v=a(9960);f.j,(i=n||(n={})).Long="long",i.Short="short";let C=(0,m.qy)`
    <msft-article
        id="contentcard_${e=>e.id}"
        href=${e=>e.destinationUrl}
        target=${e=>e.openLinksInNewTab||e.openArticleInNewTab?"_blank":e.defaultAnchorTarget||"_self"}
        title=${e=>e.disableCardTitleTooltip?"":e.title}
        class="${e=>w(e)}"
        direction="${e=>e.dir}"
        :handleContentCardClickOverride=${e=>e.handleContentCardClickOverride}
        image-position=${e=>e.imagePosition?e.imagePosition:"end"}
        data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
        :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
        @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
        @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
        data-content-id=${e=>e.id}
        >
        ${(0,h.z)(e=>e.contentIndicator,e=>(0,r.Z)(e.contentIndicator))}
        ${(0,h.z)(e=>e.imageData,(0,m.qy)`
            <div slot="image" style="height: ${e=>e.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;">
            ${(0,h.z)(e=>e.isBlurred,(0,m.qy)`
                    <img
                        alt="${e=>e.imageData.altText}"
                        src="${e=>e.imageData.blurredSource}"
                        height="${e=>e.imageData.imageHeight}"
                        width="${e=>e.imageData.imageWidth}"
                        @load="${e=>e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}"
                        style="position: absolute; z-index: -1; filter: blur(50px);"
                    />
                `)}
                <img
                    alt="${e=>e.imageData.altText}"
                    src="${e=>e.imageData.source}"
                    height="${e=>e.imageData.imageHeight}"
                    width="${e=>e.imageData.imageWidth}"
                    @load="${e=>{e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(e.isBlurred?1:3,o.j.image)}}"
                />
            </div>
        `)}
        ${e=>{!e.imageData&&e.visualReadinessCallback&&e.visualReadinessCallback()}}
        ${(0,h.z)(e=>e.feedFontSize,(0,m.qy)`
            ${(0,h.z)(e=>(e.cardSize===l.u._1x_2y||e.cardSize===l.u._1x_1y)&&e.imageData,(0,m.qy)`
                <span style="font-size: ${e=>e.feedFontSize}px; ${e=>e.headingLineHeight?`line-height: ${e.headingLineHeight}px`:""}">
                    ${e=>e.title}
                </span>`)}
            ${(0,h.z)(e=>e.cardSize===l.u._2x_2y,(0,m.qy)`
                <span style="font-size: ${e=>e.twoColumnFeedFontSize||e.largeFeedFontSize||e.feedFontSize}px; ${e=>e.twoColumnHeadingLineHeight?`line-height: ${e.twoColumnHeadingLineHeight}px`:""}">
                    ${e=>e.title}
                </span>`)}
            ${(0,h.z)(e=>(e.cardSize===l.u._1x_2y||e.cardSize===l.u._1x_1y)&&!e.imageData,(0,m.qy)`<span style="font-size: ${e=>e.noImageFeedFontSize||e.feedFontSize}px;">${e=>e.title}</span>`)}
        `)}
        ${(0,h.z)(e=>!e.feedFontSize,(0,m.qy)`
            ${(0,h.z)(e=>!e.useLargeFontSize,(0,m.qy)`${e=>e.title}`)}
            ${(0,h.z)(e=>e.useLargeFontSize,(0,m.qy)`<span class="title${e=>e.cardSize}">${e=>e.title}</span>`)}
        `)}
        ${(0,h.z)(e=>k(e),(0,m.qy)`
            <p slot="abstract">${e=>e.abstract}</p>
        `)}
        ${(0,h.z)(e=>e.badge&&e.cardSize!==l.u._1x_1y,e=>(0,s.w)(e.badge))}
        ${(0,h.z)(e=>e.providerData&&!e.isPublisherPage&&(!e.enableInfopaneLike2cCard||e.cardSize!==l.u._2x_2y),d.vJ)}
        ${(0,h.z)(e=>e.isPublisherPage&&e.userSubscriptionData&&e.metadata?.subscriptionProductType=="Premium",(0,m.qy)`
            <msn-subscription-badge
                slot="attribution"
                :userSubscriptionData="${e=>e.userSubscriptionData}"
                :cardSize="${e=>e.cardSize}"
            >
            </msn-subscription-badge>
        `)}
        <div slot="start-action" class="infopane-like-start-actions">
            ${(0,h.z)(e=>e.providerData&&e.enableInfopaneLike2cCard&&e.cardSize===l.u._2x_2y,d.vJ)}
            ${(0,h.z)(e=>(!e.enableInfopaneLike2cCard||e.cardSize!==l.u._2x_2y)&&(!e.isAnaheimDesign||e.enableRichSocialReaction),(0,m.qy)`
                ${(0,h.z)(e=>e.enableRichSocialReaction,e=>(0,c.nj)({}))}
                ${(0,h.z)(e=>e.cardActionStatus&b.J.enabled&&!e.enableRichSocialReaction,(0,m.qy)`
                    ${c.LW}
                    ${(0,h.z)(e=>!(e.cardActionStatus&b.J.showMore),c.tB)}
                `)}
            `)}
        </div>
        <div slot="end-action" class="infopane-like-end-actions">
            ${(0,h.z)(e=>e.enableRichSocialReaction&&e.enableInfopaneLike2cCard&&e.cardSize===l.u._2x_2y,(0,c.nj)({}))}
            ${(0,h.z)(e=>e.cardActionStatus&b.J.enabled,(0,m.qy)`
                ${(0,h.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,m.qy)`
                    ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&b.J.showMore,c.LW)}
                    ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&b.J.showFewer,c.tB)}
                `)}
                ${(0,h.z)(e=>e.enableWCCardAction,p.L)}
            `)}
        </div>
        ${(0,h.z)(e=>!e.disableHideOnHover&&e.cardActionStatus&b.J.enabled&&!e.isWebContent,g.C)}
    </msft-article>
`,x=(0,m.qy)`
<style>
    .card-button {
        border-radius: 100%;
    }

    @media (forced-colors:active) {
        .card-button {
            background: none;
        }

        msn-social-bar::part(button-bg),
        msn-social-bar::part(reactions-count-button),
        msn-social-bar::part(comments-count-button) {
            color: buttontext;
            background-color: buttonface;
        }

        msn-social-bar::part(button-bg):hover,
        msn-social-bar::part(button-bg):focus-visible,
        msn-social-bar::part(reactions-count-button):hover,
        msn-social-bar::part(reactions-count-button):focus-visible,
        msn-social-bar::part(comments-count-button):hover,
        msn-social-bar::part(comments-count-button):focus-visible {
            color: buttonface;
            background-color: highlight;
        }
    }

    @media (forced-colors: active) {
        @media (prefers-color-scheme: dark) {
            msft-article#contentcard_${e=>e.id} msft-content-indicator svg[width="40"] path {
                fill: rgb(0, 0, 0);
            }
        }
    }

    @media (prefers-color-scheme: dark) {
        msft-article#contentcard_${e=>e.id} {
            --article-background-color: ${e=>e.articleCardBackgroundColor?.find(e=>e.isDarkMode)?.hexColor};
        }
    }

    @media (prefers-color-scheme: light) {
        msft-article#contentcard_${e=>e.id} {
            --article-background-color: ${e=>e.articleCardBackgroundColor?.find(e=>!e.isDarkMode)?.hexColor};
        }
    }

    msft-article-card[size$="x_2y"] msft-article::part(heading):after {
        top: calc(100% - ${e=>e.fixedCardHeight?304:292+(e.layoutGap||12)}px) !important;
    }

    msft-article.no-image::part(heading) {
        font-size: var(--msft-article-heading-font-size, 20px);
        line-height: var(--msft-article-heading-line-height, 28px);
    }

    msft-article-card msft-content-indicator {
        pointer-events: none;
    }

    msft-article-card[size="_1x_1y"] msft-article[direction="rtl"]:not(.no-image) msft-content-indicator{
        right: 204px;
        left: auto;
    }

    msft-article-card[size="_1x_1y"] msft-article:not(.no-image) msft-content-indicator{
        top: 18px;
        left: 204px;
    }

    ${(0,h.z)(e=>e.contentType===y.pL.Video,(0,m.qy)`
        msft-article-card msft-article msft-content-indicator {
            color: transparent;
        }
        msft-article-card msft-article msft-content-indicator::after{
            background: transparent;
        }

        msft-article-card[size="_1x_1y"] msft-article msft-content-indicator{
            left: 233px !important;
            top: 44px !important;
        }

        msft-article-card[size="_1x_2y"] msft-article msft-content-indicator{
            left: 130px;
            top: 88px;
        }

        msft-article-card[size="_2x_2y"] msft-article msft-content-indicator{
            left: 286px;
            top: 88px;
        }

        msft-article-card[size$="x_2y"] msft-article.no-image msft-content-indicator::part(icon-container) {
            min-width: 40px;
        }

        ${(0,h.z)(e=>"rtl"==e.dir,(0,m.qy)`
            msft-article-card[size="_1x_1y"] msft-article msft-content-indicator{
                right: 233px !important;
                top: 44px !important;
            }

            msft-article-card[size="_1x_2y"] msft-article msft-content-indicator{
                right: 130px;
                top: 88px;
            }

            msft-article-card[size="_2x_2y"] msft-article msft-content-indicator{
                right: 286px;
                top: 88px;
            }
        `)}
    `)}

    msft-article-card[size="_1x_2y"] msft-article.no-image msft-attribution {
        margin-bottom: 18px;
    }

    msft-article.long-gradient::part(gradient) {
        top: -55px;
    }

    /* TODO: These hard-coded styles will be cleaned up later as tracked in this task:
     * Task 3620803 - [Anaheim] Migrate article card to an independent wc or wce
     * https://msasg.visualstudio.com/ContentServices/_workitems/edit/3620803
     */
    ${(0,h.z)(e=>e.isAnaheimDesign&&!e.enableVerticalGradientCard&&!e.isInfopane&&e.isImage43,(0,m.qy)`
        msft-article-card[size="_2x_2y"].contentCard msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient( ${e=>e.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 60px, var(--gradient-color) 96px );
            width: 344px;
        }
    `)}

    ${(0,h.z)(e=>e.isAnaheimDesign&&!e.enableVerticalGradientCard&&e.isInfopane&&e.isImage43,(0,m.qy)`
        msft-article-card[size="_2x_2y"].infopane msft-article:not(.no-image)::part(gradient) {
            /* Merged two linear-gradient into one:
             * 1. linear-gradient(270deg, rgba(122, 84, 80, 0) 0%, rgba(122, 84, 80, 0.8) 100%); on the element with width 60px
             * 2. linear-gradient(270deg, rgba(122, 84, 80, 0.8) 0%, #7A5450 46.88%); on one element with width 77px
             */
            background: linear-gradient( ${e=>e.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 60px, var(--gradient-color) 96px );
            width: 344px;
        }
    `)}

    ${(0,h.z)(e=>e.isAnaheimDesign&&e.enableVerticalGradientCard||e.enableLinearFeed2cVerticalGradientCard,(0,m.qy)`
        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-article::part(heading) {
            line-height: var(--heading-line-height, 28px);
        }

        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(heading) {
            margin-bottom: 40px;
        }

        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient( 180deg, transparent 0%, var(--gradient-mid-color) 62.5%, var(--gradient-color) 100% );
            width: 100%;
        }

        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(text) {
            height: auto;
            width: 100%;
        }

        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-article:not(.no-image)::part(attribution) {
            display: flex;
            align-self: end;
        }

        msft-article-card[size="_2x_2y"].${e=>e.isInfopane?"infopane":"contentCard"} msft-attribution {
            margin-bottom: 8px;
        }
    `)}

    msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
        bottom: ${e=>e.fixedCardHeight?77:65+(e.layoutGap||12)}px;
    }

    ${(0,h.z)(e=>e.alignFooters,(0,m.qy)`
        msft-article-card[size$="x_2y"] msft-article::part(heading):after {
            top: calc(100% - ${e=>e.fixedCardHeight?304:292+(e.layoutGap||12)}px - 8px) !important;
        }

        msft-article::part(text) {
            margin-bottom: -8px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
            top: -29px;
            bottom: calc(${e=>e.fixedCardHeight?78:66+(e.layoutGap||12)}px + 8px);
        }

        msft-article.no-image::part(actions) {
            bottom: calc(var(--msft-article-padding) * 1px - 8px);
        }
    `)}

    msft-article-card[size="_1x_2y"] msft-article[class*="zoom-ratio"]:not(.no-image)::part(gradient):after {
        content: "";
        height: 10px;
        width: 100%;
        bottom: -5px;
        position: absolute;
        background: var(--gradient-mid-color);
    }

    ${(0,h.z)(e=>e.layoutGap,(0,m.qy)`
        msft-article-card[size="_1x_2y"] msft-article.no-image::part(gradient),
        msft-article-card[size="_2x_2y"] msft-article::part(gradient) {
            bottom: 0px;
        }

        msft-article-card[size="_1x_2y"] {
            --card-height: ${e=>292+e.layoutGap}px;
            --card-width: 300px;
        }

        msft-article-card[size="_2x_2y"] {
            --card-height: ${e=>292+e.layoutGap}px;
            --card-width: ${e=>600+e.layoutGap}px;
        }
    `)}

    msft-article span.title_1x_2y,
    msft-article span.title_2x_2y {
        font-size: 20px;
    }

    ${(0,h.z)(e=>e.enableTitleClickableOnly,(0,m.qy)`
        msft-article-card:hover msft-article::part(heading) {
            position: relative;
        }
    `)}

    ${(0,h.z)(e=>e.useTitleFontSize,(0,m.qy)`
        msft-article-card {
            --msft-article-heading-font-size: ${e=>e.useTitleFontSize}px;
            --msft-article-heading-line-height: 26px;
        }

        msft-article-card msft-article::part(attribution) {
            height: 28px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(heading) {
            margin-bottom: 11px;
        }

        msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 46%, var(--gradient-color) 100%);
            top: 5px;
        }

        ${(0,h.z)(e=>!e.isAnaheimDesign&&!e.enableLinearFeed2cVerticalGradientCard,(0,m.qy)`
            msft-article-card[size="_2x_2y"].contentCard msft-article:not(.no-image)::part(heading),
            msft-article.no-image::part(heading) {
                margin-bottom: 8px;
            }
        `)}
    `)}

    ${(0,h.z)(e=>!e.isAnaheimDesign&&e.isImage43&&!e.enableLinearFeed2cVerticalGradientCard,(0,m.qy)`
        msft-article-card[size="_2x_2y"] msft-article:not(.no-image)::part(gradient) {
            background: linear-gradient(${e=>e.gradientDeg}deg, transparent 0%, var(--gradient-mid-color) 55px, var(--gradient-color) 120px);
            width: 347px;
        }
    `)}

    ${u.Y.getArticleCardHoverGradientStyle()}

    ${(0,h.z)(e=>!e.isAnaheimDesign&&!e.optedOutOfReactions,(0,m.qy)`
        msft-article-card[size="_1x_2y"].contentCard msft-article::part(text) {
            padding-bottom: 10px;
        }
        msft-article-card.contentCard msft-article::part(actions) {
            bottom: 10px;
        }
    `)}

    ${(0,h.z)(e=>!e.isAnaheimDesign&&!e.isHubDesign&&!e.optedOutOfReactions,(0,m.qy)`
        msft-article-card.contentCard msft-article div[slot="end-action"] {
            display: flex;
            height: 20px;
            margin: 6px 0;
        }
    `)}

    msft-article-card[size="_1x_1y"].contentCard msft-article:not(.no-image)::part(actions) {
        bottom: -2px;
    }

    ${(0,h.z)(e=>e.enableInfopaneLike2cCard,(0,m.qy)`
    msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-start-actions msft-attribution {
            margin-bottom: 0;
        }
        msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-start-actions,
        msft-article-card[size="_2x_2y"].contentCard msft-article div.infopane-like-end-actions {
            display: grid;
            gap: 0px;
            align-items: center;
            grid-auto-flow: column;
        }
    `)}

    msft-article[id="contentcard_${e=>e.id}"] div.infopane-like-end-actions {
        display: flex;
    }

    /* 
     * Here about 'from the web' attribution style
     */
    ${(0,h.z)(e=>e.enableInfopaneLike2cCard&&e.cardSize===l.u._2x_2y,(0,m.qy)`
        msft-article[id="contentcard_${e=>e.id}"] .infopane-like-start-actions {
            flex:1;
        }
        msft-article[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-article[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
    `)}

    msft-article[id="contentcard_${e=>e.id}"] msft-attribution, msft-article[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
        width: calc(100%);
        ${e=>e.isProviderIconClickable?"display: flex":""};
    }
    msft-article[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
        width: calc(100%);
        min-height: var(--type-ramp-minus-1-line-height);
        position: relative;
        overflow: hidden;
        white-space: nowrap;
    }
    msft-article[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
        position:absolute;
        transition: all 0.5s ease-out;
    }

    ${(0,h.z)(e=>e.isDynamicFeed,(0,m.qy)`
        msft-article-card[size="_1x_1y"].contentCard msft-article::part(heading) {
            --msft-article-heading-font-size: 16px;
            --msft-article-heading-line-height: 22px;
            height: 66px;
            -webkit-line-clamp: 3;
            margin-top: -6px;
        }
        msft-article-card[size="_1x_1y"].contentCard msft-article:not(.no-image)::part(actions) {
            bottom: -12px;
        }
        msft-article-card[size="_1x_1y"].contentCard div[slot='image'] {
            border-radius: 6px;
        }
        msft-article-card[size="_1x_1y"],
        msft-article-card[size="_1x_2y"],
        msft-article-card[size="_2x_2y"] {
            border-radius: calc(var(--layer-corner-radius) * 2px);
        }
    `)}
</style>

<msft-article-card
    style="grid-area:${e=>e.gridArea};"
    size="${e=>e.cardSize}"
    card-fill-color="${e=>e.articleCardBackgroundColor?.find(e=>e.isDarkMode===(0,v.ud)())?.hexColor}"
    class="${e=>e.isInfopane?"infopane":"contentCard"}"
    data-badge-type="${e=>e.badge&&e.badge.type}"
>
    ${C}
</msft-article-card>
`,w=e=>{let t="";return e.imageData||(t+="no-image "),e.gradientType===n.Long&&(t+="long-gradient"),t},k=e=>e.abstract;a.d(t,{},{B:x,f:C})},19e3(e,t,a){"use strict";var i=a(37914),n=a(98669);let r={getFeedDataForCard:e=>(0,n.PB)(e),viewTemplate:i.K};a.d(t,{},{m:r})},37914(e,t,a){"use strict";var i=a(69828),n=a(40201),r=a(11803),o=a(62679),l=a(99381),s=a(44776),d=a(26330),c=a(21386),p=a(89757),g=a(69259),u=a(44978),m=a(77833);let h=(e,t)=>`${t}${(e.cardSize===i.u._1x_2y||e.cardSize===i.u._1x_3y)&&!e.imageData?e.cardSize+"_no_image":e.cardSize}`,b=(0,p.qy)`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        .msn-hp-external-link-abstract {
            font-size: 12px;
            z-index: 1;
            position: absolute;
            top: 25px;
            left: 8px; 
            user-select: none;
        }

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
            ${e=>e.isProviderIconClickable?"display: inline-flex":""}
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
        ${(0,g.z)(e=>e.contentType===m.pL.Video,(0,p.qy)`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
    </style>
    <msft-content-card
        exportparts="heading, abstract"
        id="contentcard_${e=>e.id}"
        class="${e=>e.isWebContent&&"web-content"}"
        href=${e=>e.destinationUrl}
        target=${e=>e.openLinksInNewTab?"_blank":"_self"}
        title=${e=>e.disableCardTitleTooltip?"":e.title}
        aria-label=${e=>e.ariaLabel}
        ?image-priority=${e=>e.imagePriority}
        style="--heading-max-lines: 3; --footer-start-padding: 8px;"
        :handleContentCardClickOverride=${e=>e.handleContentCardClickOverride}
        data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
        :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
        @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
        @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
    >
        ${(0,g.z)(e=>e.contentIndicator&&!(e.cardSize===i.u._1x_1y&&!e.imageData),e=>(0,n.Z)(e.contentIndicator))}
        ${(0,g.z)(e=>!e.isAnaheimDesign,(0,p.qy)`${e=>e.title}`)}
        ${(0,g.z)(e=>e.isAnaheimDesign&&!e.useSmallFontSize,(0,p.qy)`<span class="${e=>h(e,"title")}">${e=>e.title}</span>`)}
        ${(0,g.z)(e=>e.isAnaheimDesign&&e.useSmallFontSize,(0,p.qy)`${e=>e.title}`)}
        ${(0,g.z)(e=>e.abstract,(0,p.qy)`
            <p slot="abstract" style="${e=>!e.isWebContent&&"color: var(--neutral-foreground-rest);"}" class="${e=>h(e,"abstract")} ${e=>e.isMsnHpExternalLinkCard?"msn-hp-external-link-abstract":""}">
                ${e=>e.abstract}
            </p>
        `)}
        <!-- Only use placeholder -->
        <!-- If image data exists && 1x_2y && image priority -->
        ${(0,g.z)(e=>!!(e.imageData&&e.cardSize===i.u._1x_2y&&e.imagePriority),(0,p.qy)`
            <div slot="media" style="height: ${e=>e.imageData.imageHeight}px;width: ${e=>e.imageData.imageWidth}px;">
                <img
                    alt="${e=>e.imageData.altText}"
                    src="${e=>e.imageData.source}"
                    height="${e=>e.imageData.imageHeight}"
                    width="${e=>e.imageData.imageWidth}"
                    @load="${e=>{e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(3,r.j.image)}}"
                />
            </div>
        `)}
        ${(0,g.z)(e=>!!(e.imageData&&(e.cardSize!==i.u._1x_2y||!e.imagePriority)),(0,p.qy)`
            <img
                slot="media"
                alt="${e=>e.imageData.altText}"
                src="${e=>e.imageData.source}"
                height="${e=>e.imageData.imageHeight}"
                width="${e=>e.imageData.imageWidth}"
                @load="${e=>{e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(3,r.j.image)}}"
            />
        `)}
        ${e=>{!e.imageData&&e.visualReadinessCallback&&e.visualReadinessCallback()}}
        ${(0,g.z)(e=>e.providerData,(0,p.qy)`
            <msft-attribution slot="${e=>e.isProviderInFooter?"start-actions":"attribution"}" style="${e=>e.isProviderInFooter?"gap:0; z-index: 0":""}">
                ${(0,o.mt)()}
                <div class="attribution_container_${e=>e.id}" id="attribution_container">
                    <div class="attribution_Content_${e=>e.id}" style="${e=>"rtl"===e.dir?"right":"left"}:0px;">
                        ${(0,g.z)(e=>e.providerData&&e.providerData.name&&!e.isProviderIconClickable,(0,p.qy)`<span style="unicode-bidi: embed;">${e=>e.providerData.name}</span>`)}
                        ${(0,g.z)(e=>e.providerData&&e.providerData.name&&e.publishedDateTime,(0,p.qy)` · `)}
                        ${(0,g.z)(e=>e.publishedDateTime,(0,p.qy)`<span style="unicode-bidi: embed;">${e=>e.publishedDateTime}</span>`)}
                        ${(0,g.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,p.qy)` · `)}
                        ${(0,g.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,p.qy)`${e=>e.crawledContentLabel}`)}
                    </div>
                </div>
            </msft-attribution>
        `)}
        <!-- Workaround for bug in MsftContentCard: footer without end-actions will not be displayed. -->
        ${(0,g.z)(e=>e.providerData&&e.isProviderInFooter,(0,p.qy)`
            <div slot="end-actions"></div>
        `)}
        ${(0,g.z)(e=>e.cardActionStatus&u.J.enabled&&!e.disableHideOnHover,l.K)}
        ${(0,g.z)(e=>!e.isAnaheimDesign||e.enableRichSocialReaction,(0,p.qy)`
            <div slot="start-actions" style="gap:0">
                ${(0,g.z)(e=>e.enableRichSocialReaction,e=>(0,s.nj)({hideComments:e.hideComments}))}
                ${(0,g.z)(e=>e.cardActionStatus&u.J.enabled&&!e.enableRichSocialReaction,(0,p.qy)`
                    ${s.LW}
                    ${s.tB}
                `)}
            </div>
        `)}
        ${(0,g.z)(e=>!e.isAnaheimDesign||e.enableRichSocialReaction,(0,p.qy)`
            <div slot="end-actions" style="gap:0">
                ${(0,g.z)(e=>e.cardActionStatus&u.J.enabled,(0,p.qy)`
                    ${(0,g.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,p.qy)`
                        ${(0,g.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&u.J.showMore,s.LW)}
                        ${(0,g.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&u.J.showFewer,s.tB)}
                    `)}
                    ${(0,g.z)(e=>e.enableWCCardAction,d.L)}
                `)}
            </div>
        `)}
        ${(0,g.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,c.p)}
    </msft-content-card>
 `,f=(0,p.qy)`
    <style>
        ${(0,g.z)(e=>e.articleCardBackgroundColor&&e.showColorfulHalfUContentCard,(0,p.qy)`
            .content-card-gradient-mask {
                padding: 0; 
                width: 100%; 
                height: 100%;
            }

            @media (prefers-color-scheme: dark) {
                .content-card-gradient-mask#contentcardmask_${e=>e.id} {
                    background: linear-gradient(160deg, #404040 0%, ${e=>e.articleCardBackgroundColor?.find(e=>e.isDarkMode)?.hexColor} 150%);
                }
            }

            @media (prefers-color-scheme: light) {
                .content-card-gradient-mask#contentcardmask_${e=>e.id} {
                    background: linear-gradient(160deg, #e5e5e5 0%, ${e=>e.articleCardBackgroundColor?.find(e=>!e.isDarkMode)?.hexColor} 150%);
                }
            }
        `)}

        msft-content-card .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card(:not(.web-content))::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card span.title_1x_2y_no_image {
            font-size: 24px;
            line-height: 32px;
        }
        msft-content-card span.title_1x_3y_no_image {
            font-size: 16px;
            line-height: 22px;
        }
        msft-content-card p.abstract_1x_2y_no_image {
            font-size: 16px;
            line-height: 22px;
            margin-top: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        msft-content-card p.abstract_1x_3y_no_image {
            font-size: 14px;
            line-height: 20px;
            margin-top: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 5;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        fluent-card._1x_3y msft-content-card::part(abstract) {
            padding-left: var(--abstract-start-padding, 16px);
        }
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        ${(0,g.z)(e=>e.articleCardBackgroundColor&&e.showColorfulHalfUContentCard,(0,p.qy)`
            <div class="content-card-gradient-mask"
                id="contentcardmask_${e=>e.id}"
            >
                ${b}
            </div>
        `)}
        ${(0,g.z)(e=>!e.articleCardBackgroundColor||!e.showColorfulHalfUContentCard,(0,p.qy)`
            ${b}
        `)}
    </fluent-card>
`;a.d(t,{},{K:f})},85854(e,t,a){"use strict";var i=a(38118);a.d(t,{},{d(e){let{adSponsored:t,infoPaneNewsStoryLabel:a}=i.D.getLocStrings();return e.map(e=>e.isNativeAd?t||e.adLabelText||e.nativeAds?.[0]?.adLabelText||e.title||e.nativeAds?.[0]?.title:a||e.title)}})},58034(e,t,a){"use strict";var i,n,r,o;(r=i||(i={})).OneColumn="1_column",r.TwoColumn="2_column",(o=n||(n={})).LightDefault="lightDefault",o.LightNarrow="lightNarrow",o.LightLarge="lightLarge",o.LightWide="lightWide",o.LightStyle2="light2",a.d(t,{j:()=>i,o:()=>n})},76971(e,t,a){"use strict";var i=a(84289),n=a(87906),r=a(40450),o=a(83488),l=a(78518),s=a(98794),d=a(69828),c=a(46659),p=a(95402),g=a(35667),u=a(1792),m=a(25658),h=a(7446),b=a(98378),f=a(82368),y=a(52545),v=a(2568),C=a(22621),x=a(56233),w=a(50901),k=a(1480),$=a(58034),S=a(85854),T=a(57152),_=a(83916),I=a(73632),A=a(72627),D=a(19110),z=a(72287),F=a(98669),R=a(94108),L=a(33744),M=a(72746),E=a(64859),B=a(44978),P=a(43922),O=a(77833),N=a(52323),H=a(20999),q=a(50180),W=a(54694),K=a(10173),U=a(12673),V=a(44916),j=a(81859),G=a(12882),X=a(94623),J=a(18284),Z=a(60815),Y=a(98670),Q=a(51907),ee=a(86010);let et=!1,ea={[d.u._1x_2y]:c.L._300x304,[d.u._1x_3y]:c.L._300x326,[d.u._2x_2y]:c.L._612x304,[d.u._2x_3y]:c.L._612x462},ei={[d.u._1x_2y]:c.L._300x180},en={[d.u._1x_2y]:c.L._300x225,[d.u._1x_3y]:c.L._300x225,[d.u._2x_2y]:c.L._468x304,[d.u._2x_3y]:c.L._468x304},er={[d.u._1x_2y]:c.L._300x304,[d.u._1x_3y]:c.L._300x326,[d.u._2x_2y]:c.L._628x372,[d.u._2x_3y]:c.L._628x372},eo={[d.u._1x_2y]:p.Sv.infoPane,[d.u._1x_3y]:p.Sv.infoPane1x3y,[d.u._2x_2y]:p.Sv.infoPane,[d.u._2x_3y]:p.Sv.infoPane},el={MorningDigest:!0,RegionalTrending:!0,TopicNews:!0};function es(e){(0,i.tD)("InfopaneDataMapping.Start",performance.now());let{activeIndicator:t,autoRotate:n,autoRotateIntervalMs:p,disableAutoRotate:A,firstAutoRotateIntervalMs:D,cardActionBitMask:L,cardActionClickHandler:M,cardMetadata:W,cardSlot:U,enableInfopaneSwipe:V,enableRichSocialReaction:j,focusinHandler:J,focusoutHandler:Q,getReplacementCardsCallback:ee,reactionCallback:ea,shareActionHandler:ei,initCardAction:en,localizedStrings:er,mouseenterHandler:es,mouseleaveHandler:ep,openLinksInNewTab:eg,parentTelemetryObject:eu,refreshFeedCallback:em,setAutoRotate:eh,stockImageData:eb,visualReadinessCallback:ef,configOptions:ey,isAnaheimDesign:ev,isAdFeedbackV1Enabled:eC,isNarrowTitleFooterGap:ex,isProviderInFooter:ew,allowBlurScroll:ek,enableRotateAfterClick:e$,rotateAfterClickIntervalMs:eS,enableRotateOnlyOnce:eT,rotateBackAfterClickPrevButton:e_,rotateStopAfterClickPrevButton:eI,enableInfopaneRefactoring:eA,adTimerInMS:eD,infoPaneProminentFlipper:ez,infopaneThresholdSecondForNewFlag:eF,infopaneThresholdForCommentFlag:eR,enableTabbedInfopane:eL,columnLayout:eM,isIASEnabled:eE,appendIdxForId:eB}=e,{grid_area:eP}=U,eO=eR??1,eN=eF??7200,eH=ey&&(ey.childExperienceReferencesWC&&ey.childExperienceReferencesWC.socialBarWC||ey.childExperienceReferences&&ey.childExperienceReferences.socialBarWC),eq=[];if(W.subItems&&W.subItems.length?eq=W.subItems:(eq=W.subCards,W.subItems=eq),!eq.length)return;eq=function(e){let t=[],a=[];for(let i=0;i<e.length;i++){let n=e[i];if(n.type==O.pL.TabbedInfopaneCardTab)a.push(n);else if(n.type==O.pL.TopicFeed)a.push(n);else{if(a.length>0){let e={type:O.pL.TabbedInfopaneCard,subCards:a};t.push(e),a=[]}t.push(n)}}return t}(eq);let eW=(0,E.c)(eu),eK="",eU=!1,eV=W.wpoMetadata?.contentType==="PersonalizedInfopane";if(eV&&(0,E.b)(eW),W.feed){let{sageFeedGroupName:e,feedName:t}=W.feed;t&&el[e]&&(eK=t,eU=!0)}if(W.wpoMetadata){let{contentType:e}=W.wpoMetadata;if(""===eK){let t=e===O.pL.WorkHeadlines;if(ey.enableImmersiveInfopane){let e=er.topStoriesHeadingText;er.topStoriesHeadingText=e.slice(0,1)+e.slice(1).toLowerCase()}eK=function(e,t,a){let{topStoriesHeadingText:i,industryHeadlinesText:n,localNewsHealinesText:r}=a||{};return(0,X.YW)({isLocalNews:e,isWorkHeadlines:t}).with({isLocalNews:!0},()=>r).with({isWorkHeadlines:!0},()=>n).otherwise(()=>i)}([O.pL.LocalNews,O.pL.LocalNewsFeed].includes(e),t,er)}(e===O.pL.TopStories||e===O.pL.TopStoriesV2)&&(eq=eq.slice(0,6))}let ej=er?.cardActionsTooltips,eG={id:"infopane",childTemplateType:"infopane-card",telemetryContext:eW,slideContentData:[],isNarrowTitleFooterGap:ex,infoPaneFlipperStyle:ey.infoPaneFlipperStyle,enableDenseSlide:ey.enableDenseSlide,enableRotateOnlyOnce:eT,enableAdaptDarkMode:ey.enableAdaptDarkMode,infoPaneNextFlipperTitle:er?er.infoPaneNextFlipperTitle:"",infoPanePreviousFlipperTitle:er?er.infoPanePreviousFlipperTitle:"",useTitleFontSize:ey&&ey.useTitleFontSize,enableImmersiveInfopane:ey&&ey.enableImmersiveInfopane,autoRowHeights:ev&&ey.enableFlexCard,infopaneViewOptAdCount:ey.infopaneViewOptAdCount,enableInfopaneSwipe:V,cardActionsTooltips:ej,disableImmersiveInfopaneTitle:eV,enableVariableSpeed:ey.enableVariableInfopaneSpeed,parentContentId:ey.parentContentId},eX=ey&&ey.adBeaconServiceConfig,eJ={};return(0,s.bw)({id:"infopane",experienceType:(ey&&ey.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e},eG,(E,W)=>{var U;let V,X=W.cardSize,el=[];eq.forEach((t,i)=>{let n;if(!t)return;let p=t.recoId||t.metadata&&t.metadata.recoId,$=t.ri||t.metadata&&t.metadata.ri;V=(0,s.uX)({id:"infopane",columnArrangement:E,experienceType:(ey&&ey.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e,recoId:p,ri:$,subCardIndex:i}).telemetryExt;let S="ShoppingInfopane1"===t.type||"ShoppingInfopane2"===t.type||"ShoppingInfopane3"===t.type||"ShoppingInfopane4"===t.type,A="nativead"===t.type||"cmsad"===t.type||"directbuyad"===t.type||S,D="ArticleFre"===t.type&&"FreFeed"===t.id,N=t.type===O.pL.EventInfopaneShoppingAI,W=(0,z.H8)(t,L),U=(W&B.J.hide)!=0||ey.enableHideStoryFeedback&&((W&B.J.showFewer)!=0||(W&B.J.hidden)!=0),J=t.visualReadinessCallback;if(A)if(S&&(V||(V={}),V={...V,cardName:"ShoppingInfopane",ShoppingCardType:"ShoppingNTPInfopane",clickUrl:t.placement?.items?.[0]?.destinationUrl}),eD&&(eJ[i]=eD),(W&B.J.hide)==0){let i=(ey&&ey.enableNativeAdWCInfopane||t&&t.placement&&t.placement.enableNativeAdWC)&&ey?.childExperienceReferencesWC?.nativeAdWC;if(n=function(e,t,i,n,o,s,d,p,g,b,f,$,S,T,_,A,D,F,L,M,E,B,P=!1,O=!1,N,W,K,U,V,j,G,X,J,Q,ee,ea,ei,en,er,el,es,ed,ec,ep,eg,eu,em,eh){(0,u.Yu)(e,T);let eb=e.placement;if(!eb||!eb.items)return;let{crids:ef}=eb;(0,I.S)()&&!em&&y.x.addDedupeIds(ef,eb.region);let ey=b?.cardActionsTooltips,ev=new H.Yg,eC=[];return eb.items.forEach((y,I)=>{let{destinationUrl:H,adChoiceIconUrl:Y,clickBeacons:ed,imageWidth:em,imageHeight:ef,feedbackUrl:ev,description:ex,assets:ew,adScenarioType:ek,cashback:e$,verificationParameters:eS,noAdLabel:eT,assetRanks:e_,eventtrackers:eI}=y||{},{imageUrl:eA,title:eD,providerName:ez}=y||{},eF=(0,u.EJ)(H,{enableSafeAds:P});if(E&&B){let e=eb.region,t=eb.regionIndex,a={w:Number(y.originalImageWidth),h:Number(y.originalImageHeight)},i=(0,v.li)(eA,B,a,eF,e,t);if(i){let e=i.logInfo;h.YT.sendClientLogEvent({message:i.message,pb:{...r.Gq_.pb,logInfo:e},type:"warning"})}}let eR=(0,m.u)(e,i,"infopane",I,$),eL="river-half-textonly"!==(eb.region&&eb.region.toLowerCase())?(0,C.cG)(eb,I):null;!et&&eL&&(Promise.all([a.e("node_modules_video_js_dist_video_es_js"),a.e("web-components_content-video-player_dist_index_js"),a.e("web-components_native-ad-video_dist_index_js")]).then(a.bind(a,30376)),et=!0);let eM=em||c.L._300x156.width.toString(),eE=ef||c.L._300x156.height.toString(),eB=eD,eP=null,eO=null,eN=null,eH=null,eq=!1,eW=V&&!j&&ew&&ek&&l.JP.includes(ek),eK=j&&ew&&0!==Object.keys(ew).length&&X?.includes(ek);eW||eK?(eM=ew.img?.w.toString()??eM,eE=ew.img?.h.toString()??eE,eA=ew.img?.url??eA,eB=ew.img?.ext?.alt??eB,eD=ew.title??eD,ez=ew.providerName??ez,eP=ew.logo?.url,eW?eO=(0,u.Po)(ew,eb.region):eK&&((0,x.FM)(ew),eN=(0,x.Ng)(ew,e_),h.YT.addOrUpdateTmplProperty("hasVAv2","1"),h.YT.addOrUpdateTmplString("hasVAv2"))):er&&e$&&(eD=(0,q.GP)(b?.nativeAdCashbackText,e$)??eD,ez="Microsoft"),!ea&&J&&ew&&(eH=ew.callToAction??eH)&&!en&&(eq=!0),!ei&&ee&&ew&&(eP=ew.logo?.url)&&!en&&(eq=!0),J&&ew&&ew.callToAction&&(h.YT.addOrUpdateTmplProperty("hasCallToAction","1"),h.YT.addOrUpdateTmplString("hasCallToAction")),ee&&ew&&ew.logo?.url&&(h.YT.addOrUpdateTmplProperty("hasLogo","1"),h.YT.addOrUpdateTmplString("hasLogo"));let eU=e.id&&e.id.indexOf("amplifyad")>=0;if(eD&&eF){let a;if(eC.push({...eb,cardActionsTooltips:ey,id:e.id,index:I,gridArea:t,childTemplateType:"native-ad-card",isNativeAd:!0,imagePriority:!0,cardSize:n,adTelemetryContext:eR,telemetryContext:eR,adChoiceIconUrl:Y,clickBeacons:ed,destinationUrl:eF,imageData:{altText:eB,source:eA,imageWidth:eM,imageHeight:eE,visualReadinessCallback:f},providerData:{logoImage:eP,name:ez},title:eD,description:ex,enableNativeAdDescription:N,maxDescriptionLines:W,enableProviderAlignmentV2:U,cardLayout:eo[n],isAnaheimDesign:!!o,toggleCardActionMenu:(e,t)=>(0,z.JE)(e,t,p,s),feedbackUrl:ev,isAdFeedbackV1Enabled:d,useSmallFontSize:!!g,assets:ew,localizedStrings:b,videoProps:eL,hoverState:(a={isHovered:!1},(0,Z.sH)(a,"isHovered"),a),nativeAdWC:S,adBeaconServiceConfig:T,noBackPlateOnRest:!!_,feedFontSize:A,adSlugGA:D,isGreyAdsLabelEnabled:F,adLabelFontSize:M,disableCardTitleTooltip:L,enableTitleForTruncate:ep,showAdLabel:!eU,providerName:eU?b.nativeAdPromotedByText:ez,attribution:eU?ex:void 0,enableSafeAds:P,useLightShadow:O,lightShadowVal:K,enableVA:V,enableVAPhase2:j,enableVAPhase2WithShimmer:G,supportedAdScenarioTypes:X,enableCTA:J,enableCTAVariant:Q,enableLogo:ee,callToAction:eH,logoImageUrl:eP,hasCTALogoAssets:eq,enableBlendInAdSlugStyle:ec,assetColumns:eO,assetOrder:eN,enableBuyDirectAd:eg,hideAdLabelAndAdChoice:(0,z.tO)(eb?.providerId,eT),openAdInSameTab:eu,enableAdSponsoredText:eh}),el&&e.id&&eS){let t=es?`native_ad_${e.id}_${I}`:`native_ad_${e.id}`,a=eI?.find(e=>e.ext?.vendorKey==="IAS-omid");a?(0,w.n$)(a,t,r.nxh):(0,w.nL)(eS,t,r.nxh)}let i=!R.Rb?.CurrentFlightSet?.has("prg-ad-dv-on-rf"),l=eI&&e.id,c=!!eb?.isXandrPlacement;if(!eI||i&&e?.id||(0,k.xs)(eI,e?.id,i,c),i&&l){let t=es?`${e.id}_${I}`:`${e.id}`,a=(0,k.Q3)(eI);c&&a.has("doubleverify.com-omid")?(0,k.Mb)(a.get("doubleverify.com-omid"),t,r.nxh,c):a.has("DV")&&(0,k.Mb)(a.get("DV"),t,r.nxh)}}}),ev.saveUserActionBeacon(e.id,eb.beaconsJson),eC.forEach(e=>(0,Y.B)(e)),{id:e.id,gridArea:t,childTemplateType:"native-ad-card",isNativeAd:!0,imagePriority:!0,cardSize:n,nativeAds:eC,enableSafeAds:P}}(t,eP,eW&&eW.infopane,X,ev,en,eC,M,ey.useSmallFontSize,ey?.localizedStrings,J,V,i,eX,ey.noBackPlateOnRest,ey.twoColumnFeedFontSize||ey.feedFontSize,ey.adSlugGA,ey.isGreyAdsLabelEnabled,ey.disableCardTitleTooltip,ey.adLabelFontSize,ey.enableNativeAdImageVisualQualityChecker,ey.adTemplateConfig?.imageSizeConfig?.infopane,ey.enableSafeAds,ey.useLightShadow,ey.enableNativeAdDescription,ey.maxDescriptionLines,ey.lightShadowVal,ey.enableProviderAlignmentV2,ey.adTemplateConfig?.enableVA,ey.adTemplateConfig?.enableVAPhase2,ey.adTemplateConfig?.enableVAPhase2WithShimmer,ey.adTemplateConfig?.supportedAdScenarioTypes,ey.enableCTA,ey.enableCTAVariant,ey.enableLogo,ey.disableCTADisplay,ey.disableLogoDisplay,ey.ctaLogoSimplification,ey.enableCashback,eE,eB,ey&&ey.ipFlipperCustomSize,ey.enableBlendInAdSlugStyle,ey.enableTitleForTruncate,ey.enableBuyDirectAd,ey.openAdInSameTab,ey.adTemplateConfig?.enableBlockingQueue,ey.enableAdSponsoredText),e.configOptions.preloadInfopaneImages)for(let e of n?.nativeAds??[])(0,z.NN)(e.imageData?.source)}else{let a={...e,cardMetadata:t};n=(0,f.Eb)(a,W,t.id,eW&&eW.infopane,eC,(0,u.ZA)(a))}else if(t.type===O.pL.Dense){let a=t?.subItems??t?.subCards;if(a.forEach(e=>{if(!e)return;let t=e.recoId||e.metadata&&e.metadata.recoId;t&&(V.recoId=t)}),a?.length===4)n=function(e,t,a,i){let n,{cardActionBitMask:r,cardActionClickHandler:o,cardMetadata:l,configOptions:s,enableRichSocialReaction:p,getReplacementCardsCallback:u,reactionCallback:m,shareActionHandler:h,goToPersonalizeSettingsCallback:f,initCardAction:y,isAnaheimDesign:v,isNarrowTitleFooterGap:C,localizedStrings:x,openLinksInNewTab:w,parentTelemetryObject:k,refreshFeedCallback:$,stockImageData:S,visualReadinessCallback:T}=e,_=l?.subItems??l?.subCards,I=k.addOrUpdateChild({name:"TopStoriesDenseSlide",type:b.MJ.Headline}),A=I.addOrUpdateChild({name:"MoreSetting",type:b.MJ.ActionButton}),D={moreSetting:{title:s.localizedStrings?.moreSettingOptStr||"More settings",telemetryTag:A.getMetadataTag(),onClick:f}},R=_;if(t===d.u._2x_2y){let e=_[0]??(0,z.cZ)(_[0]);R=_?.slice(1);let t=l.visualReadinessCallback;n={...ed({cardMetadata:e,cardSize:d.u._1x_2y,cardActionStatus:(0,z.H8)(e,r),cardActionClickHandler:o,initCardAction:y,visualReadinessCallback(){T&&T(),t&&t()},localizedStrings:x,stockImageData:S,isAnaheimDesign:v,isNarrowTitleFooterGap:C,configOptions:s,openLinksInNewTab:w,socialBarWCConfigInfo:a,enableRichSocialReaction:p,useSmallFontSize:s.useSmallFontSize,refreshFeedCallback:$,getReplacementCardsCallback:u,reactionCallback:m,shareActionHandler:h,parentTelemetryObject:I,ext:i}),cardActionClickHandler:void 0,cardFillColor:"#333",cardSize:"_1x_2y",mediaType:P.z.image}}let L={heroNews:n,newsList:R?.map(e=>{let t=e.type===O.pL.WebContent,a=(0,F.po)(e,c.L._60x60,T,v,void 0,void 0,void 0,void 0,void 0,void 0,void 0,s.enableWebpFormat);e.cardContent||(e=(0,z.cZ)(e));let{destinationUrl:n,locale:r,id:o,provider:l,publishedDateTime:d,title:p}=e.cardContent;return{id:o,destinationUrl:n,title:p,ariaLabel:(0,z.yL)(p,l,s.localizedStrings),openLinksInNewTab:w,providerData:(0,z.p_)(l,t),publishedDateTime:!v&&s.enableArticleTimestamps&&(0,F.fL)(s.enableNewTimestampFormatForJAJP,new Date(d),r,s.localizedStrings),imageData:a,isNativeAd:!1,telemetryContext:(0,g.dj)(I,e.cardContent,e.metadata,i,t),isNarrowNewsItem:s.isNarrowNewsItem}})};return{id:"denseCard-infopane-1",childTemplateType:"dense-card",gridArea:"",telemetryObject:I,denseData:L,settingMenuConfig:D,localizedStrings:s.localizedStrings}}({...e,cardMetadata:t,parentTelemetryObject:eW&&eW.infopane},X,eH,V);else if((0,G.uC)(ey.childExperienceReferencesWC?.denseCard||ey.childExperienceReferences?.denseCard),n=ec(ey,t,eg,ew,()=>{ef&&ef(),J&&J()},ev,eu,X,ey.isGreyAdsLabelEnabled,i,V,eN,eO,eL),e.configOptions.preloadInfopaneImages)for(let e of((0,z.NN)(n.denseData.heroNews?.imageData?.source),(0,z.NN)(n.denseData.heroNews?.providerData?.logoImage),n.denseData.newsList||[]))(0,z.NN)(e.providerData?.logoImage)}else{var Q,es;let a,r,l,s;t.type===O.pL.TopStories?((a={...e}).cardMetadata=a.cardMetadata.subItems[0],(r=(0,K.W)(a).defaultLayout[0]).isAnaheimInfopane=!0,n=r):D?((0,G.uC)(ey.childExperienceReferencesWC&&ey.childExperienceReferencesWC.articleFreCard),Q=e,es=E,(l={...Q,isArticleFreInInfoPane:!0}).cardMetadata=l.cardMetadata.subItems[0],l.configOptions={...l.configOptions,enableHideStoryFeedback:!0,enableInstantHide:!0,enableDismissCallback:!0,useHideConfirmationNewStoryText:!0},n={...(s=(0,o.z)(l)).defaultLayout[0],...s[es][0]}):U?n=(0,f.Eb)(e,W,t.id,eW&&eW.infopane):t.type===O.pL.TabbedInfopaneCard?n=function(e,t,a,i,n,r,o,l){let{configOptions:s,openLinksInNewTab:d,isProviderInFooter:c,visualReadinessCallback:p,isAnaheimDesign:g,parentTelemetryObject:u,localizedStrings:m}=e,h=t?.subItems??t?.subCards,b=(0,_.G)(u),f=h.map((e,t)=>(0,T.Ww)(s,e,d,c,()=>{a&&a(),p&&p()},g,u,b,i,s.isGreyAdsLabelEnabled,t,r,m,o,l));return{id:`denseCard-infopane-${n+1}`,gridArea:"",childTemplateType:"tabbed-infopane-card",enableAdaptDarkMode:s.enableAdaptDarkMode,telemetryContext:b,slideContentData:f}}(e,t,ef,X,i,V,eN,eO):(n=ed({cardMetadata:t,cardSize:X,openLinksInNewTab:eg,visualReadinessCallback(){ef&&ef(),J&&J()},cardActionStatus:W,cardActionClickHandler:M,initCardAction:en,localizedStrings:er,parentTelemetryObject:eW&&eW.infopane,stockImageData:eb,enableRichSocialReaction:j,configOptions:ey,isAnaheimDesign:ev,useSmallFontSize:ey.useSmallFontSize,isNarrowTitleFooterGap:ex,refreshFeedCallback:em,socialBarWCConfigInfo:eH,getReplacementCardsCallback:ee,reactionCallback:ea,shareActionHandler:ei,ext:V,cardTitleText:eK,enableDefaultNewsIcon:eU,disableImmersiveInfopaneTitle:eV,isShoppingArticleCard:N}),e.configOptions.preloadInfopaneImages&&((0,z.NN)(n.imageData?.source),(0,z.NN)(n.providerData?.logoImage)))}n&&(t.type!==O.pL.TopStories&&(n.cardLayout=eo[X]),el.push(n))});let eF={...eW};if(ey&&ey.addExtToNewsContainer&&V&&eF.infopane){let{row:e,col:t,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:l}=V;eF.infopane=new N.$({...eF.infopane.contract,ext:{row:e,col:t,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:l}})}let eR={activeIndicator:t,autoRotate:n,autoRotateIntervalMs:p,disableAutoRotate:A,allowBlurScroll:ek,firstAutoRotateIntervalMs:D,focusinHandler:J,layout:X===d.u._2x_2y?$.j.TwoColumn:$.j.OneColumn,mouseenterHandler:es,mouseleaveHandler:ep,setAutoRotate:eh,slideContentData:el,infoPaneTabLabels:(0,S.d)(el),isNarrowTitleFooterGap:ex,enableRotateAfterClick:e$,rotateAfterClickIntervalMs:eS,enableRotateOnlyOnce:eT,rotateBackAfterClickPrevButton:e_,rotateStopAfterClickPrevButton:eI,enableInfopaneRefactoring:eA,adTimerMap:eJ,infoPaneProminentFlipper:ez,telemetryContext:eF};return Q&&(U=Q,eR.focusoutHandler=e=>{e.relatedTarget&&"fluent-menu-item"===e.relatedTarget.localName||U()}),(0,i.tD)("InfopaneDataMapping.End",performance.now()),eR},!0)}function ed({cardMetadata:e,cardSize:t,openLinksInNewTab:a,visualReadinessCallback:i,cardActionStatus:o,cardActionClickHandler:l,initCardAction:s,localizedStrings:p,parentTelemetryObject:m,stockImageData:b,enableRichSocialReaction:f,configOptions:y,isAnaheimDesign:v,isHubDesign:C,useSmallFontSize:x,isNarrowTitleFooterGap:w,refreshFeedCallback:k,socialBarWCConfigInfo:$,getReplacementCardsCallback:S,reactionCallback:T,shareActionHandler:_,ext:I,cardTitleText:A,enableDefaultNewsIcon:E,disableImmersiveInfopaneTitle:B,isShoppingArticleCard:P}){let H,q,K,{cardContent:j,metadata:G,type:X}=(0,z.cZ)(e),J=X===O.pL.WebContent,Z=(0,g.dj)(m,j,G||e,I,J),Y="link"===j.type&&(!j.provider||!j.provider.id);y&&y.addExtToNewsContainer&&Z&&(Z.contentCard=new N.$({...Z.contentCard.contract,ext:I}));let et=(0,F.PS)(e,p,y.enablePanocard,y.panocardType),eo=(0,z.Ie)(e);if(!(eo&&eo.url)&&b){let t;t=y?.useImgGenerator?[{url:(0,W.XP)(b.id,{width:0,height:0,enableDpiScaling:!1,enableWebpFormat:y.enableWebpFormat}),width:b.width,height:b.height}]:[b],e.cardContent.images=t}let el=y&&y.useArticleCardTemplate,es=y&&y.useMsnHomepageCardTemplate;el&&(q=(0,F.uK)(eo?.colorSamples,j.colorSamples,eo?.url));let ec=null;(Y||t===d.u._2x_3y||el&&t!==d.u._1x_2y)&&(ec=j.abstract);let{locale:eu,publishedDateTime:em,badges:eh,isWorkNewsContent:eb}=j,{enableResponsiveComponent:ef}=y||{},ey=G?.reasons,{badge:ev,reasonBadge:eC}=(0,D.bA)(p,eh,y&&y.enabledBadgeTypes,ey,y&&y.enabledReasonBadgeTypes,null),ex=(0,z.nN)(p,y,eC),ew=(0,F.Ew)(p),ek=G&&G.reactionSummary||e&&e.reactionSummary;e.metadata={...e.metadata,reactionSummary:ek};let e$=!ek;K=el?en[t]:es?e.id.includes("InfoBuyDirectCard")?null:er[t]:y.enableImmersiveInfopane?ei[t]:y.enableFeed3Cards&&t===d.u._2x_2y?c.L._612x328:ea[t],el&&t===d.u._2x_2y&&y.isImage43&&(K=c.L._406x304);let eS=""!==R.Rb.MarketDir?R.Rb.MarketDir:"ltr",eT=G?.reasons&&(y.childExperienceReferencesWC?.publisherFollowButton||y.childExperienceReferences?.publisherFollowButton),e_="",eI=null;if(y?.enableArticleTimestamps){let{disable1MonPlusTimestamp:e,disableNDaysPlusTimestamp:t}=M.ew.getConfig()||{},a=(0,V.YS)(em),i=(0,V.Tp)(em,t);e&&a||i||(e_=(0,M._L)(em,eu,void 0,y?.enableNewTimestampFormatForJAJP,y?.enableSimpleArticleTimestamp),eI=y?.enableSimpleArticleTimestamp&&(0,M._L)(em,eu,void 0,y.enableNewTimestampFormatForJAJP,!1,!0))}let eA=(0,u.EJ)(j.destinationUrl,y);P&&((H=new URL(eA)).searchParams.set("entryPoint","msn"),H.searchParams.set("FORM","INFOBG"),H.searchParams.set("msnrid",h.YT.getRequestId()),H.searchParams.set("adunitId","378983"),H.searchParams.set("propertyId","316966"),eA=H.toString());let eD=X===O.pL.WebContent&&(e.metadata.videoMetadata||!!e.metadata?.externalVideoFiles);eD&&(eA=(0,U.C)(encodeURIComponent(e.id),eA)),j?.isPanoCard&&et?.type==1&&(et.articleDestinationUrl=eA,eA=et.destinationUrl);let ez=(0,F.po)(e,K||{width:0,height:0},i,v,!1,!1,!1,!1,!1,!1,y.enableLowPowerDeviceImage,y.enableWebpFormat),eF={ariaLabel:(0,z.yL)(j.title,j.provider,p,X),cardActionStatus:(!J||y?.enableWCCardAction||y?.enableWCSaveButton)&&o,cardActionClickHandler:l,cardActionsTooltips:ex,cardTitleText:A,id:e.id,gridArea:"",isWebContent:J,colorSamples:e.colorSamples,contentType:X,contentTypeLabel:(0,z.Ww)(p,X)?.toLocaleUpperCase(),customTransitionSpeed:j.customTransitionSpeed,spotlightBreakingNewsTagString:p?.topStoriesBreakingNewsTagString,contentIndicator:(0,F.WH)(X,v&&y?.miniMediaIndicatorsIcons,e.id),abstract:ec,isWorkNewsContent:eb,isMsnHpExternalLinkCard:Y,childTemplateType:"content-card",crawledContentLabel:y?.localizedStrings?.crawledContentLabel,dir:eS,setDisplacementHandler:ep,removeDisplacementHandler:eg,title:j.title,titlePrefix:e.titlePrefix||"",badge:ev,reasonBadge:eC,openLinksInNewTab:a||Y,isProviderIconClickable:y&&y.isProviderIconClickable,useArrowIcons:y&&y.useArrowIcons,openArticleInNewTab:y&&y.openArticleInNewTab,destinationUrl:eA,imageData:ez,locale:j.locale,providerData:(0,z.p_)(j.provider,J),enableRichSocialReaction:(!J||y?.enableWebContentSocialReactions||y?.enableWCCardAction||y?.enableWCSaveButton)&&f,disableOptedOutButton:y?.disableOptedOutButton,enableHoverCardAction:y?.enableHoverCardAction,optedOutOfReactions:e$,telemetryContext:Z,toggleCardActionMenu:(e,t,a)=>(0,F.Sp)(e,t,l,s,null,!0,k,y?.openPersonalizeWithoutRouter,e$,a),cardSize:t,useArticleCardTemplate:el,articleCardBackgroundColor:q,isAnaheimDesign:!!v,isHubDesign:!!C,isDynamicFeed:y.isDynamicFeed,useSmallFontSize:!!x,isNarrowTitleFooterGap:w,socialBarWCConfigInfo:$,metadata:G||e,enableSaveButton:y&&!1!==y.enableSaveButton||J&&y?.enableWCSaveButton,publishedDateTime:e_,ariaDateTime:eI,gradientDeg:y&&y.isImage43?(0,F.rs)():void 0,isInfopane:!0,noBackPlateOnRest:!!v||y&&y.noBackPlateOnRest,enableFilledIconOnHover:y&&y.enableFilledIconOnHover,enableNeutralFilledShowMoreIcon:y&&y.enableNeutralFilledShowMoreIcon,topQuestionsHeading:p&&p.topQuestionsHeading,topQuestionsNote:p&&p.topQuestionsNote,highlightsHeading:p&&p.highlightsBadgeLabel,highlightsNote:p&&p.highlightsNote,followTexts:ew,useTitleFontSize:y&&y.useTitleFontSize,enableWCSaveButton:!J||y?.enableWCSaveButton,enableWCCardAction:!J||y?.enableWCCardAction,actionsArrayOverride:J&&y?.availableActions||void 0,disableCardTitleTooltip:y&&y.disableCardTitleTooltip,enableTitleForTruncate:y&&y.enableTitleForTruncate,disableImmersiveInfopaneTitle:B,publisherFollowButtonConfigInfo:eT?{...eT,instanceId:`${eT.instanceId}-${e.id}`}:void 0,enableHover:y&&y.enableHover,addExtToNewsContainer:y&&y.addExtToNewsContainer,getReplacementCardsCallback:S,reactionCallback:T,shareActionHandler:_,isSpotlightUX:e&&e.isFeatured,enableDefaultNewsIcon:E,useLightShadow:y&&y.useLightShadow,enableCardHideStoryIcon:y&&y.enableCardHideStoryIcon,lightShadowVal:y&&y.lightShadowVal,enableAttrOversizing:y&&y.enableAttrOversizing,useFollowPublisherButtonWC:y&&y.useFollowPublisherButtonWC,enableProviderAttrNav:!eD&&y&&y.enableProviderAttrNav,panoCaption:et,isPanoCard:j.isPanoCard,clickPanocardFooterHandler:(e,t)=>(0,z.s2)(e,t),clickPanocardArticleHandler:(e,t)=>(0,z.$z)(e,t),isShoppingArticleCard:P,externalVideoFiles:e.cardContent.videoFiles,socialBarInRight:y&&y.socialBarInRight&&!y.providerOnTopInfopane,providerAboveHeader:y&&y.providerOnTopInfopane};if(ef){let e,t=!1;eF.mediaData={altText:ez.altText,loadCallback:i,errorCallback(e,a){t||(t=!0,(0,n.vV)(r.qog,"Error fetching source","Source: "+e+", Article ID: "+a),i())},src:ez.source};let a=eF.providerData;eF.attributionData={altText:a&&a.name,name:a&&a.name,publishedDateTime:e_,src:a&&a.logoImage,useFollowingButton:!0,errorImageCallback(){},providerChannelURL:a&&(0,Q.As)(a)};let o="";switch(eC?.type.toLowerCase()){case"trending":o=`${L.T3.StaticsUrl}latest/icons-wc/icons/TrendingLight.svg`;break;case"local":o=`${L.T3.StaticsUrl}latest/icons-wc/icons/LocationPin.svg`;break;case"followtopic":case"followpublisher":o=`${L.T3.StaticsUrl}latest/icons-wc/icons/CircleCompleted.svg`}eC?.type&&(e={iconSrc:o,onClickBadge:(e,t)=>(0,F.Sp)(e,t,l,s,null,!0,k,y?.openPersonalizeWithoutRouter,e$,ee.hs.WhyAmISee),telemetryTag_badge:Z?.whyAmISee?.getMetadataTag(),text:eC?.localizedLabel||""}),eF.badgeProps=e,eF.visualReadinessCallback=i}return eF}function ec(e,t,a,i,n,r,o,l,s,d,p,f,y,v){if(e?.enableInfopaneDenseCardInteraction||e?.infopaneDenseCardNoHeroNews){let a=e.childExperienceReferencesWC?.denseCard||e.childExperienceReferences?.denseCard,i=t?.subItems??t?.subCards;if(i=i.filter((t,a)=>!e.enableInfopaneDenseCardInteraction||t.type===O.pL.NativeAd||t.type===O.pL.CmsAd||!(a>6)),a){let e=i[0]?.cardContent??(0,z.cZ)(i[0]).cardContent;a={...a,instanceId:`denseCard-${e.id}`}}let r=o.addOrUpdateChild({name:"DenseSlide",type:b.MJ.Headline}),h=(0,A.mZ)(),f=(0,j.h_)(),y={newsList:i?.map(t=>{let a=t.type===O.pL.NativeAd||t.type===O.pL.CmsAd;if(!a){let i=t.type===O.pL.WebContent;t.cardContent||(t=(0,z.cZ)(t));let{id:o,destinationUrl:l,title:s,provider:d}=t.cardContent,m=(0,F.D9)(t,c.L._240x129,h,n,f);return{id:o,destinationUrl:(0,u.EJ)((0,z.Dv)(l),e),title:s,ariaLabel:(0,z.yL)(s,d,e.localizedStrings),providerData:(0,z.p_)(d,i),isNativeAd:a,telemetryContext:(0,g.dj)(r,t.cardContent,t.metadata,p,i),isNarrowNewsItem:e.isNarrowNewsItem,imageData:m}}let i=t.placement?.items[0]||{};i=function(e){if(!e||!e.imageUrl)return e;let t=/https:\/\/images\.archive-digger\.com\/taboola\/image\/fetch\/f_jpg.+(http%3A%2F%2Fcdn.taboola.com%2F.+\.jpe?g)/,a=/^http:\/\/cdn.taboola.com\/.+\.jpe?g$/,i=e.imageUrl.trim();return e.imageUrl=(0,J.A)(e=>{if(0!==e.indexOf("https://images.archive-digger.com/taboola/"))return e;let i=e.match(t);if(!i||i.length<1)return e;let n=decodeURIComponent(i[1]);return a.test(n)?n:e})(i),e}(i);let{beaconsJson:o,privacyUrl:l,adLabelText:d,geminiViewabilityDataJson:b}=t.placement||{};return{...i,beaconsJson:o,privacyUrl:l,adLabelText:d,geminiViewabilityDataJson:b,isNativeAd:a,adTelemetryContext:(0,m.u)(t,r,"infopane",0),isNarrowNewsItem:e.isNarrowNewsItem,isGreyAdsLabelEnabled:s}}),configOptions:e,cardSize:l,visualReadinessCallback:n};return{id:`denseCard-infopane-${d+1}`,childTemplateType:"dense-card",gridArea:"",telemetryObject:r,denseConfigInfo:a,denseData:y}}{let C=e.childExperienceReferencesWC?.denseCard||e.childExperienceReferences?.denseCard,x=t?.subItems??t?.subCards,w=x[0]?.cardContent??(0,z.cZ)(x[0]).cardContent,k=x[0]?.commentSummary?.totalCount??(0,z.cZ)(x[0]).commentSummary?.totalCount??0,$=x[0]?.type===O.pL.WebContent,{id:S,destinationUrl:_,title:I,provider:A,type:D}=w,R=(0,z.Ie)(x[0]),L=o.addOrUpdateChild({name:"DenseSlide",type:b.MJ.Headline}),M=(0,g.dj)(L,w,x[0].metadata,p,D===O.pL.WebContent),E=!0!==e.disableDenseArticleTemplate&&R?.width<R?.height,B=c.L._240x129;E?B=c.L._240x253:e.useLargeHeroImageForDense&&(B=c.L._300x200);let P=(0,F.po)(x[0],B,n,r,void 0,void 0,void 0,void 0,void 0,void 0,void 0,e.enableWebpFormat),N=x?.slice(1);e?.enableDenseLayout1&&(N=[...x?.slice(0,x?.length-2),x[x?.length-1]]),N.length>8&&v&&(N=N.slice(0,7).concat(N[N.length-1])),C&&(C={...C,instanceId:`denseCard-${S}`});let H=$?em(w):_,q={id:S,destinationUrl:(0,u.EJ)((0,z.Dv)(H),e),openLinksInNewTab:a,title:I,ariaLabel:(0,z.yL)(I,A,e.localizedStrings),imagePriority:!1,providerData:(0,z.p_)(A,$),isProviderInFooter:i,imageData:P,useArticleCardTemplate:E,telemetryContext:M,commentCount:Math.min(k,99),commentFlag:k>=y,newFlag:(0,T.IT)(w.publishedDateTime,f)},W={heroNews:e.enableVideoOnDenseIp&&(D===O.pL.Video||"VideoPreview"===D)?(h.YT.addOrUpdateTmplString("densecard-hero-video"),{...q,videoMetadata:w.videoMetadata??{},externalVideoFiles:w.videoFiles??w.externalVideoFiles}):q,newsList:N?.map(a=>{let i=a.type===O.pL.NativeAd||a.type===O.pL.CmsAd;if(!i){let t=a.type===O.pL.WebContent;a.cardContent||(a=(0,z.cZ)(a));let n=a.metadata?.commentSummary?.totalCount??0,r=t?em(a.cardContent):a.cardContent.destinationUrl;return{destinationUrl:(0,u.EJ)((0,z.Dv)(r),e),title:a.cardContent.title,ariaLabel:(0,z.yL)(I,a.cardContent.provider,e.localizedStrings),providerData:(0,z.p_)(a.cardContent.provider,t),isNativeAd:i,telemetryContext:(0,g.dj)(L,a.cardContent,a.metadata,p,t),isNarrowNewsItem:e.isNarrowNewsItem,commentCount:Math.min(n,99),commentFlag:n>=y,newFlag:(0,T.IT)(a.cardContent.publishedDateTime,f)}}let n=a.placement?.items[0]||{},{beaconsJson:r,privacyUrl:o,adLabelText:l,geminiViewabilityDataJson:c}=a.placement||{};return{...n,beaconsJson:r,privacyUrl:o,adLabelText:l,geminiViewabilityDataJson:c,isNativeAd:i,adTelemetryContext:(0,m.u)(a,L,"infopane",0),isNarrowNewsItem:e.isNarrowNewsItem,isGreyAdsLabelEnabled:s,enableInfopaneDVBeacon:e?.enableInfopaneDVBeacon,isXandrPlacement:!!t?.placement?.isXandrPlacement,id:`denseCard-infopane-${d+1}`}}),configOptions:e,cardSize:l};return{id:`denseCard-infopane-${d+1}`,childTemplateType:"dense-card",gridArea:"",telemetryObject:L,denseConfigInfo:C,denseData:W}}}function ep(e,t){if(eu(e.event.target,"MSFT-ATTRIBUTION")){for(let a of eu(e.event.target,"MSFT-ATTRIBUTION").children)if("attribution_container"===a.id){let e=a?.clientWidth,i=a?.children[0].clientWidth,n=a?.children[0],r=e-i<0?e-i:0;"ltr"===t?n.style.left=r+"px":n.style.right=r+"px"}}}function eg(e,t){if(eu(e.event.target,"MSFT-ATTRIBUTION")){for(let a of eu(e.event.target,"MSFT-ATTRIBUTION").children)if("attribution_container"===a.id){let e=a.children[0];"ltr"===t?e.style.left="0px":e.style.right="0px"}}}function eu(e,t){if(!e.children||0===e.children.length)return null;let a=null,i=function(e,t){if(e.children&&0!==e.children.length)for(let n of e.children)n.nodeName===t&&(a=n),i(n,t)};return i(e,t),a}let em=e=>{let{destinationUrl:t,id:a}=e||{};return t?.includes("youtube.com")?(0,U.C)(encodeURIComponent(a),t):t};a.d(t,{ad:()=>es,gC:()=>ec})},64859(e,t,a){"use strict";var i=a(98378);a.d(t,{},{b(e){e&&e.infopane&&(e.personalTelemetry=e.infopane.addOrUpdateChild({name:"PersonalizedInfopane",type:i.MJ.Headline}),e.singleTelemetry=e.infopane.addOrUpdateChild({name:"single",type:i.MJ.Headline}))},c(e){if(!e)return;let t=e.addOrUpdateChild({name:"InfopaneHeader",type:i.MJ.Headline}),a=e.addOrUpdateChild({name:"Infopane",type:i.MJ.Headline}),n=a.addOrUpdateChild({name:"previousSlideArrow",behavior:i.MS.More,content:{headline:"previousSlideArrow"},type:i.MJ.ActionButton}),r=a.addOrUpdateChild({name:"nextSlideArrow",behavior:i.MS.More,content:{headline:"nextSlideArrow"},type:i.MJ.ActionButton}),o=a.addOrUpdateChild({name:"playTransition",behavior:i.MS.More,content:{headline:"playTransition"},type:i.MJ.ActionButton}),l=a.addOrUpdateChild({name:"pauseTransition",behavior:i.MS.More,content:{headline:"pauseTransition"},type:i.MJ.ActionButton}),s=a.addOrUpdateChild({name:"seeMore",behavior:i.MS.More,content:{headline:"seeMore"},type:i.MJ.ActionButton}),d=a.addOrUpdateChild({name:"articledestination",behavior:i.MS.Navigate,content:{headline:"articledestination"},type:i.MJ.ActionButton}),c=a.addOrUpdateChild({name:"infopanetab",behavior:i.MS.More,content:{headline:"infopanetab"},type:i.MJ.ActionButton});return{componentRoot:e,infopaneHeader:t,infopane:a,nextSlideArrow:r,previousSlideArrow:n,playTransitionButton:o,pauseTransitionButton:l,articledestination:d,seeMoreButton:s,tabTelemetry:c}}})},41483(e,t,a){"use strict";a.d(t,{RT:()=>tf,dU:()=>tC});var i,n,r,o,l,s,d=a(89757),c=a(69259),p=a(68835),g=a(87906),u=a(40450),m=a(40201),h=a(67453),b=a(62679),f=a(44776),y=a(26330),v=a(47517),C=a(35177),x=a(99381),w=a(21386),k=a(69828),$=a(94664),S=a(91277),T=a(77387),_=a(94164),I=a(82521),A=a(54084),D=a(58623),z=a(89228),F=a(98728),R=a(71733),L=a(31157);let M=`
msft-content-card.native-ad-infopane-horizontal::part(body) {
    display: block;
    background: var(--fill-color);
}
msft-content-card.native-ad-infopane-horizontal::part(footer) {
    position: absolute;
    bottom: 0px;
    width: calc(100% - 32px);
}
msft-content-card.native-ad-infopane-horizontal.hasInlineDecoration msft-attribution[slot="start-actions"]{
    margin-top: 0;
}
msft-content-card.native-ad-infopane-horizontal.hasInlineDecoration msft-attribution[slot="end-actions"]{
    margin-top: 0;
}
msft-content-card.native-ad-infopane-horizontal::part(heading-container) {
    width: 258px;
    margin-top: 24px;
    margin-left: 16px;
}
msft-content-card.native-ad-infopane-horizontal .info-pane-slide-title {
    font-size: 20px;
    line-height: 30px;
}
msft-content-card.native-ad-infopane-horizontal msft-attribution.info-pane-card-deco {
    width: 258px;
    margin-left: 32px;
    margin-top: 68px;
}
msft-content-card.native-ad-infopane-horizontal msft-attribution .shop-now {
    background: red;
    margin-top:20px;
    height: 32px;
    line-height: 32px;
    width: 102px;
    border-radius: 20px;
    text-align: center;
    background: rgba(255, 255, 255, 0.14);
    color: rgba(255, 255, 255, 0.8);
}

msft-content-card.native-ad-infopane-horizontal msn-inline-group::part(inline-item) {
    line-height: 25px;
}
`,E=`
msft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-1-by-1::part(media-wrapper) {
    background: var(--fill-color);
    border: 10px solid #fff;
    position: absolute;
    width: 180px;
    height: 180px;
    right: 46px;
    top: 40px;
}
msft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-1-by-1::part(media-wrapper) {
    left: 46px;
    right: unset;
}`,B=`
msft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-3-by-4::part(media-wrapper) {
    background: var(--fill-color);
    border: 10px solid #fff;
    position: absolute;
    width: 150px;
    height: 200px;
    right: 68px;
    top: 30px;
}
msft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-3-by-4::part(media-wrapper) {
    left: 68px;
    right: unset;
}`,P=`
msft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-4-by-3::part(media-wrapper) {
    background: var(--fill-color);
    border: 10px solid #fff;
    position: absolute;
    width: 208px;
    height: 156px;
    right: 38px;
    top: 50px;
}
msft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-4-by-3::part(media-wrapper) {
    left: 38px;
    right: unset;
}`,O=`
msft-content-card.native-ad-infopane-horizontal.native-ad-infopane-horizontal-9-by-16::part(media-wrapper) {
    background: var(--fill-color);
    border: 10px solid #fff;
    position: absolute;
    width: 123px;
    height: 220px;
    right: 38px;
    top: 20px;
}
msft-content-card.rtl.native-ad-infopane-horizontal.native-ad-infopane-horizontal-9-by-16::part(media-wrapper) {
    left: 38px;
    right: unset;
}`,N=`
msft-content-card.native-ad-infopane-pattern-overlay .info-pane-slide-title {
    font-size: 16px;
}
msft-content-card.native-ad-infopane-pattern-overlay::part(media) {
    height: 100%;
    border-radius: 0px;
    overflow: hidden;
}
msft-content-card:hover.native-ad-infopane-pattern-overlay::part(media) {
    filter: unset;
}
msft-content-card:hover.native-ad-infopane-pattern-overlay img {
    filter: brightness(0.9);
}
`,H=`
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(heading-container) {
    width: 248px;
}
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1 msft-attribution.info-pane-card-deco {
    width: 248px;
}
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(media-wrapper) {
    background: #fff;
    position: absolute;
    width: 304px;
    height: 100%;
    right: 8px;
    top: 0px;
}
msft-content-card.rtl.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-1-by-1::part(media-wrapper) {
    left: 8px;
    right: unset;
}
`,q=`
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(heading-container) {
    width: 144px;
}
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3 msft-attribution.info-pane-card-deco {
    width: 144px;
}
msft-content-card.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(media-wrapper) {
    background: #fff;
    position: absolute;
    width: 384px;
    height: 100%;
    right: 8px;
    top: 0px;
}
msft-content-card.rtl.native-ad-infopane-pattern-overlay.native-ad-infopane-pattern-overlay-4-by-3::part(media-wrapper) {
    left: 8px;
    right: unset;
}
`,W=e=>!!e.template&&("msn-info-pane-pattern-overlay-1-by-1"===e.template.templateType||"msn-info-pane-pattern-overlay-4-by-3"===e.template.templateType||"msn-info-pane-horizontal-1-by-1"===e.template.templateType||"msn-info-pane-horizontal-3-by-4"===e.template.templateType||"msn-info-pane-horizontal-4-by-3"===e.template.templateType||"msn-info-pane-horizontal-9-by-16"===e.template.templateType)||!1;var K=a(44978),U=a(9960),V=a(94172),j=a(56911),G=a(92011),X=a(55230),J=a(5096),Z=a(38493),Y=a(60815),Q=a(73632),ee=a(72691);(i=o||(o={}))._1_column="1_column",i._2_column="2_column",(n=l||(l={})).LightDefault="lightDefault",n.LightNarrow="lightNarrow",n.LightLarge="lightLarge",n.LightWide="lightWide",n.LightStyle2="light2",(r=s||(s={})).vertical="vertical",r.horizontal="horizontal";class et extends G.L{constructor(){super(),this.slideKeyPressHandler=(e,t)=>{this.adjust(t),this.autoScrollHandler()},this.onPrevButtonClicked=()=>{this.adjust(-1),this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"),this.autoScrollHandler()},this.onNextButtonClicked=()=>{this.adjust(1),this.rotateDirection="forward",this.autoScrollHandler()},this.layout=o._2_column,this.freWelcomeAnimationRunning=!1,this.orientation=s.horizontal,this.activeindicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.touchStart=!1,this.touchStartX=0,this.touchStartTabpanelLayoutX=0,this.touchDeltaX=0,this.touchStartTime=0,this.handleSwipeMove=e=>{if(this.touchDeltaX=e-this.touchStartX,0==this.activeTabIndex&&this.touchDeltaX>=0||this.activeTabIndex==this.tabIds.length-1&&this.touchDeltaX<=0){this.touchStart=!1;return}this.touchStart=!0,this.tabpanelLayout.style.transform=`translateX(${this.touchStartTabpanelLayoutX+this.touchDeltaX}px)`},this.handleSwipeEnd=e=>{if(!this.touchStart)return;let t=this.clientWidth,a=(this.touchStartX-e)/t,i=(new Date().getTime()-this.touchStartTime)/1e3;Math.abs(a)>.5||Math.abs(a)>.1&&i<.15?this.adjust(a>0?1:-1,!1):this.moveToTabpanelByIndex(this.activeTabIndex,!0),this.touchStart=!1,this.touchStartX=0,this.touchDeltaX=0,this.touchStartTime=0},this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=e=>"true"===e.getAttribute("aria-disabled"),this.isFocusableElement=e=>!this.isDisabledElement(e),this.setTabs=()=>{let e=this.isHorizontal()?"gridColumn":"gridRow";this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.tabs.forEach((t,a)=>{if("tab"===t.slot&&this.isFocusableElement(t)){this.activeindicator&&(this.showActiveIndicator=!0);let e=this.tabIds[a],i=this.tabpanelIds[a];t.setAttribute("id","string"!=typeof e?`tab-${a+1}`:e),t.setAttribute("aria-selected",this.activeTabIndex===a?"true":"false"),t.setAttribute("aria-controls","string"!=typeof i?`panel-${a+1}`:i),t.addEventListener("click",this.handleTabClick),t.addEventListener("keydown",this.handleTabKeyDown),t.setAttribute("tabindex",this.activeTabIndex===a?"0":"-1"),this.activeTabIndex===a&&(this.activetab=t)}else this.showActiveIndicator=!1;t.style[e]=`${a+1}`,this.isHorizontal()?t.classList.remove("vertical"):t.classList.add("vertical")}),this.tabsShowOrNot&&this.activeTabIndex>=0&&(this.tabsShowOrNot[this.activeTabIndex]=!0)},this.setTabPanels=()=>{this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds();let e=this.clientWidth;if(this.tabpanels.forEach((t,a)=>{let i=this.tabIds[a],n=this.tabpanelIds[a];t.setAttribute("id","string"!=typeof n?`panel-${a+1}`:n),t.setAttribute("aria-labelledby","string"!=typeof i?`tab-${a+1}`:i),this.enableInfopaneSwipe?0==a&&0==e?t.style.width="100%":t.style.width=`${e}px`:this.activeTabIndex!==a?t.setAttribute("hidden",""):t.removeAttribute("hidden")}),this.enableInfopaneSwipe){let e=1==Math.abs(this.prevActiveTabIndex-this.activeTabIndex);this.moveToTabpanelByIndex(this.activeTabIndex,e)}},this.handleTabClick=e=>{let t=e.currentTarget;1===t.nodeType&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(t),this.setComponent())},this.handleTabKeyDown=e=>{let t=e.key;if(this.isHorizontal())switch(t){case X.kT:e.preventDefault(),this.adjustBackward(e),this.enableInfopaneRefactoring&&(this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"));break;case X.bb:e.preventDefault(),this.adjustForward(e),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}else switch(t){case X.I5:e.preventDefault(),this.adjustBackward(e),this.enableInfopaneRefactoring&&(this.rotateBackAfterClickPrevButton&&(this.rotateDirection="backward"),this.rotateStopAfterClickPrevButton&&(this.rotateDirection="stay"));break;case X.HX:e.preventDefault(),this.adjustForward(e),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}switch(t){case"Home":e.preventDefault(),this.adjust(-this.activeTabIndex),this.enableInfopaneRefactoring&&(this.rotateDirection="forward");break;case"End":e.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1),this.enableInfopaneRefactoring&&(this.rotateDirection="forward")}},this.adjustForward=e=>{let t=this.tabs,a=0;for((a=this.activetab?t.indexOf(this.activetab)+1:1)===t.length&&(a=0);a<t.length&&t.length>1;)if(this.isFocusableElement(t[a])){this.moveToTabByIndex(t,a);break}else if(this.activetab&&a===t.indexOf(this.activetab))break;else a+1>=t.length?a=0:a+=1},this.adjustBackward=e=>{let t=this.tabs,a=0;for(a=(a=this.activetab?t.indexOf(this.activetab)-1:0)<0?t.length-1:a;a>=0&&t.length>1;)if(this.isFocusableElement(t[a])){this.moveToTabByIndex(t,a);break}else a-1<0?a=t.length-1:a-=1},this.moveToTabByIndex=(e,t)=>{let a=e[t];this.activetab=a,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=t,a.focus(),this.setComponent()},this.canAutoRotate=()=>this.enableInfopaneRefactoring?(this.enableRotateOnlyOnce&&!this.stopRotateDueShownAll&&0===this.activeTabIndex&&this.tabsShowOrNot&&this.tabsShowOrNot.every(e=>e)&&(this.stopRotateDueShownAll=!0),(!this.enableRotateAfterClick||!this.isFocusedOverAPeriodOfTime)&&!this.stopRotateDueShownAll&&(!!this.allowBlurScroll||!!this.isWindowFocused)&&(!this.isFocused||!!this.enableRotateAfterClick)&&!this.isMouseOver&&"visible"===document.visibilityState&&!!this.isInViewport&&!0):!this.isFocused&&!this.isMouseOver&&(this.allowBlurScroll||!this.allowBlurScroll&&this.isWindowFocused)&&"visible"===document.visibilityState&&this.isInViewport,this.updateAutoRotateState=()=>{let e=this.canAutoRotate();e&&!this.timer?this.autoScrollHandler():!e&&this.timer&&this.clearAutoScrollHandler()},this.focusInHandler=(()=>(this.enableInfopaneRefactoring?(this.updateIsFocusedOverAPeriodOfTime(),this.isFocused=!0,this.updateAutoRotateState()):this.isFocused=!0,!0)).bind(this),this.focusOutHandler=(()=>(this.enableInfopaneRefactoring?(this.clearIsFocusedOverAPeriodOfTime(),this.isFocused=!1,this.updateAutoRotateState()):(this.isFocused=!1,this.autoScrollHandler()),!0)).bind(this),this.windowFocusHandler=(()=>{this.enableInfopaneRefactoring?(this.isWindowFocused=!0,this.updateAutoRotateState()):(this.isWindowFocused=!0,this.autoScrollHandler())}).bind(this),this.windowBlurHandler=(()=>{this.enableInfopaneRefactoring?(this.isWindowFocused=!1,this.updateAutoRotateState()):this.isWindowFocused=!1}).bind(this),this.mouseInHandler=(()=>(this.enableInfopaneRefactoring?(this.isMouseOver=!0,this.updateAutoRotateState()):(this.isMouseOver=!0,this.autoScrollHandler()),!0)).bind(this),this.mouseOutHandler=(()=>(this.enableInfopaneRefactoring?(this.isMouseOver=!1,this.updateAutoRotateState()):(this.isMouseOver=!1,this.autoScrollHandler()),!0)).bind(this),this.windowVisiabilityChange=(()=>{this.updateAutoRotateState()}).bind(this),this.touchStartHandler=(e=>{this.tabpanelLayout.classList.remove("tappanel-scroll-anim"),this.handleSwipeStart(e.touches[0].clientX)}).bind(this),this.touchMoveHandler=(e=>{e.preventDefault(),this.handleSwipeMove(e.touches[0].clientX)}).bind(this),this.touchEndHandler=(e=>{this.handleSwipeEnd(e.changedTouches[0].clientX)}).bind(this)}handleChange(){this.direction=ee.o.getValueFor(this)}connectedCallback(){super.connectedCallback(),this.direction=ee.o.getValueFor(this),(0,Q.S)()&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.isFocused=!1,this.isWindowFocused=!0,this.isMouseOver=!1,this.rotateDirection="forward",ee.o.subscribe(this),this.activeindicator||(this.activeindicator=!1),this.addEventListeners(),this.autoScrollHandler(),this.setIntersectionObserver())}disconnectedCallback(){super.disconnectedCallback(),this.enableInfopaneRefactoring?this.clearAutoScrollHandler():window.clearTimeout(this.timer),ee.o.unsubscribe(this),this.removeEventListeners(),this.unsetIntersectionObserver(),this.tabs.forEach(e=>{e.removeEventListener("click",this.handleTabClick),e.removeEventListener("keydown",this.handleTabKeyDown)})}updateIsFocusedOverAPeriodOfTime(){this.isFocusedOverAPeriodOfTime=!0,this.focusTimer&&(window.clearTimeout(this.focusTimer),this.focusTimer=null),this.focusTimer=window.setTimeout(()=>{this.isFocusedOverAPeriodOfTime=!1,this.updateAutoRotateState(),this.focusTimer=null},(this.rotateAfterClickIntervalMs||1e4)-(this.autoScrollIntervalMs||6e3))}clearIsFocusedOverAPeriodOfTime(){this.focusTimer&&(window.clearTimeout(this.focusTimer),this.focusTimer=null),this.isFocusedOverAPeriodOfTime=!1}clearAutoScrollHandler(){this.timer&&window.clearTimeout(this.timer),this.timer=null}autoScrollHandler(e=0){if(this.enableInfopaneRefactoring){if(this.disableAutoScroll||this.freWelcomeAnimationRunning)return void this.clearAutoScrollHandler();let t=0;t=e||(0===this.activeTabIndex&&void 0!==this.firstAutoScrollIntervalMs?this.firstAutoScrollIntervalMs:this.adTimerMap&&this.adTimerMap[this.activeTabIndex]?(this.autoScrollIntervalMs||6e3)+this.adTimerMap[this.activeTabIndex]:this.autoScrollIntervalMs||6e3),this.clearAutoScrollHandler(),this.timer=window.setTimeout(()=>{if(this.timer=null,this.canAutoRotate()){switch(this.rotateDirection){case"forward":this.adjust(1,!0);break;case"backward":this.adjust(-1,!0)}performance.mark("InfoPaneAR"),this.autoScrollHandler()}},t)}else{if(this.disableAutoScroll||this.freWelcomeAnimationRunning)return void window.clearTimeout(this.timer);let e=0;e=0===this.activeTabIndex&&void 0!==this.firstAutoScrollIntervalMs?this.firstAutoScrollIntervalMs:this.adTimerMap&&this.adTimerMap[this.activeTabIndex]?(this.autoScrollIntervalMs||6e3)+this.adTimerMap[this.activeTabIndex]:this.autoScrollIntervalMs||6e3,this.timer&&window.clearTimeout(this.timer),this.timer=window.setTimeout(()=>{this.canAutoRotate()&&(this.adjust(1,!0),performance.mark("InfoPaneAR")),this.autoScrollHandler()},e)}}activeidChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(e,t){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition()),t&&(this.tabsShowOrNot=t.map(()=>!1),this.stopRotateDueShownAll=!1)}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition(),this.activeid=this.tabIds[this.activeTabIndex])}getTabpanelLayoutX(){let e=parseInt(this.tabpanelLayout.style.transform.replace("translateX(","").replace("px",""));return isNaN(e)?0:e}handleSwipeStart(e){this.touchStartTime=new Date().getTime(),this.touchStartX=e,this.touchStartTabpanelLayoutX=this.getTabpanelLayoutX(),this.touchDeltaX=0}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}moveToTabpanelByIndex(e,t){let a=this.clientWidth;t?this.tabpanelLayout.classList.add("tappanel-scroll-anim"):this.tabpanelLayout.classList.remove("tappanel-scroll-anim"),this.tabpanelLayout.style.transform=`translateX(${-a*e}px)`}getTabIds(){return this.tabs.map(e=>e.getAttribute("id"))}getTabPanelIds(){return this.tabpanels.map(e=>e.getAttribute("id"))}setComponent(e){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.change(),this.setTabs(),this.handleActiveIndicatorPosition(),this.setTabPanels(),e||this.focusTab(),this.change())}isHorizontal(){return this.orientation===s.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;let e=this.isHorizontal()?"gridColumn":"gridRow",t=this.isHorizontal()?"translateX":"translateY",a=this.isHorizontal()?"offsetLeft":"offsetTop",i=this.activeIndicatorRef[a];this.activeIndicatorRef.style[e]=`${this.activeTabIndex+1}`;let n=this.activeIndicatorRef[a]-i;0!=n&&(this.activeIndicatorRef.style[e]=`${this.prevActiveTabIndex+1}`),this.activeIndicatorRef.style.transform=`${t}(${n}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[e]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${t}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")},{once:!0})}adjust(e,t){this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=(0,J.Vf)(0,this.tabs.length-1,this.activeTabIndex+e),this.setComponent(t)}focusTab(){this.tabs[this.activeTabIndex].focus()}addEventListeners(){this.allowBlurScroll||(this.enableInfopaneRefactoring&&document.addEventListener("visibilitychange",this.windowVisiabilityChange,!0),window.addEventListener("focus",this.windowFocusHandler,!0),window.addEventListener("blur",this.windowBlurHandler,!0))}removeEventListeners(){this.allowBlurScroll||(this.enableInfopaneRefactoring&&document.removeEventListener("visibilitychange",this.windowVisiabilityChange,!0),window.removeEventListener("focus",this.windowFocusHandler,!0),window.removeEventListener("blur",this.windowBlurHandler,!0))}setIntersectionObserver(){if(this.intersectionObserver)return;let e=e=>{this.isInViewport=e[0].intersectionRatio>0,this.enableInfopaneRefactoring&&this.updateAutoRotateState()};this.intersectionObserver=new IntersectionObserver(e,{threshold:[0]}),this.intersectionObserver.observe(this)}unsetIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}}(0,j.Cg)([Z.CF],et.prototype,"layout",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"auto-scroll",mode:"boolean"})],et.prototype,"autoScroll",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"disable-auto-scroll",mode:"boolean"})],et.prototype,"disableAutoScroll",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"enable-rotate-after-click",mode:"boolean"})],et.prototype,"enableRotateAfterClick",void 0),(0,j.Cg)([Z.CF],et.prototype,"rotateAfterClickIntervalMs",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"auto-scroll-interval-ms"})],et.prototype,"autoScrollIntervalMs",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"first-auto-scroll-interval-ms"})],et.prototype,"firstAutoScrollIntervalMs",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"allow-blur-scroll",mode:"boolean"})],et.prototype,"allowBlurScroll",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"use-windows-styles",mode:"boolean"})],et.prototype,"useWindowsStyles",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"enable-rotate-only-once",mode:"boolean"})],et.prototype,"enableRotateOnlyOnce",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"enable-infopane-refactoring",mode:"boolean"})],et.prototype,"enableInfopaneRefactoring",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"enable-infopane-swipe",mode:"boolean"})],et.prototype,"enableInfopaneSwipe",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"infopane-prominent-flipper",mode:"boolean"})],et.prototype,"infoPaneProminentFlipper",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"rotate-prev-after-click-prev-button",mode:"boolean"})],et.prototype,"rotateBackAfterClickPrevButton",void 0),(0,j.Cg)([(0,Z.CF)({attribute:"rotate-stop-after-click-prev-button",mode:"boolean"})],et.prototype,"rotateStopAfterClickPrevButton",void 0),(0,j.Cg)([Y.sH],et.prototype,"infoPaneFlipperStyle",void 0),(0,j.Cg)([Y.sH],et.prototype,"previousFlipperTitle",void 0),(0,j.Cg)([Y.sH],et.prototype,"nextFlipperTitle",void 0),(0,j.Cg)([Y.sH],et.prototype,"nextFlipperTelemetryTag",void 0),(0,j.Cg)([Y.sH],et.prototype,"previousFlipperTelemetryTag",void 0),(0,j.Cg)([Y.sH],et.prototype,"direction",void 0),(0,j.Cg)([Y.sH],et.prototype,"tabpanelLayout",void 0),(0,j.Cg)([Z.CF],et.prototype,"orientation",void 0),(0,j.Cg)([Z.CF],et.prototype,"activeid",void 0),(0,j.Cg)([Y.sH],et.prototype,"tabs",void 0),(0,j.Cg)([Y.sH],et.prototype,"tabpanels",void 0),(0,j.Cg)([(0,Z.CF)({mode:"boolean"})],et.prototype,"activeindicator",void 0),(0,j.Cg)([Y.sH],et.prototype,"activeIndicatorRef",void 0),(0,j.Cg)([Y.sH],et.prototype,"showActiveIndicator",void 0);var ea=a(43799),ei=a(93809),en=a(82774),er=a(60402),eo=a(96016),el=a(2399),es=a(26106),ed=a.n(es),ec=a(30961),ep=a.n(ec);let eg=(0,d.qy)`<span aria-hidden="true" part="next" class="next"><slot name="next"><svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z" /></svg></slot></span>`,eu=(0,d.qy)`<span aria-hidden="true" part="previous" class="previous"><slot name="previous"><svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z" /></svg></slot></span>`,em=(0,d.qy)`<span part="next" class="filled-next"><slot name="filled-next">${d.qy.partial(ep())}</slot></span>`,eh=(0,d.qy)`<span part="previous" class="filled-previous"><slot name="filled-previous">${d.qy.partial(ed())}</slot></span>`,eb=e=>e.infoPaneProminentFlipper||[l.LightStyle2,l.LightDefault,l.LightLarge,l.LightNarrow,l.LightWide].includes(e.infoPaneFlipperStyle),ef=e=>`${e.useWindowsStyles?"windows":""} ${e.infoPaneFlipperStyle===l.LightNarrow?"flipper-light-narrow":""} ${e.infoPaneFlipperStyle===l.LightLarge?"flipper-light-large":""} ${e.infoPaneFlipperStyle===l.LightWide?"flipper-light-wide":""} ${e.infoPaneFlipperStyle===l.LightDefault?"flipper-light":""} ${e.infoPaneFlipperStyle===l.LightStyle2?"flipper-light2":""}`,ey=(0,d.qy)`<template @mouseenter=${(0,ei.F)(e=>e.mouseInHandler(),{capture:!0})} @focusin=${(0,ei.F)(e=>e.focusInHandler(),{capture:!0})} @focusout=${(0,ei.F)(e=>e.focusOutHandler(),{capture:!0})} @mouseleave=${(0,ei.F)(e=>e.mouseOutHandler(),{capture:!0})}><slot name="previous-flipper"><button title="${e=>e.previousFlipperTitle}" part="previous-flipper" class="previous-flipper ${e=>e.infoPaneProminentFlipper?"opacity-one-previous-flipper":""} ${e=>ef(e)}" tabIndex="0" @keypress="${(e,t)=>e.enableInfopaneRefactoring?e.onPrevButtonClicked():e.slideKeyPressHandler(t.event,-1)}" @click="${(e,t)=>e.enableInfopaneRefactoring?e.onPrevButtonClicked():e.slideKeyPressHandler(t.event,-1)}" data-t="${e=>e.previousFlipperTelemetryTag}">${(0,c.z)(e=>e.direction===L.O.rtl,(0,d.qy)` ${(0,c.z)(e=>e.useWindowsStyles,(0,d.qy)`${d.qy.partial(el.A)}`)} ${(0,c.z)(e=>!e.useWindowsStyles,e=>eb(e)?em:eg)} `)} ${(0,c.z)(e=>e.direction===L.O.ltr,(0,d.qy)` ${(0,c.z)(e=>e.useWindowsStyles,(0,d.qy)`${d.qy.partial(eo.A)}`)} ${(0,c.z)(e=>!e.useWindowsStyles,e=>eb(e)?eh:eu)} `)}</button></slot>${ea.p}<div class="tablist ${e=>e.useWindowsStyles?"windows":""}" part="tablist" role="tablist"><slot class="tab" name="tab" part="tab" ${(0,en.e)("tabs")}></slot>${(0,c.z)(e=>e.activeindicator,(0,d.qy)`<div ${(0,er.K)("activeIndicatorRef")} class="activeIndicator" part="activeIndicator"></div>`)}</div><slot name="next-flipper"><button title="${e=>e.nextFlipperTitle}" part="next-flipper" class="next-flipper ${e=>e.infoPaneProminentFlipper?"opacity-one-next-flipper":""} ${e=>ef(e)}" tabIndex="0" @keypress="${(e,t)=>e.enableInfopaneRefactoring?e.onNextButtonClicked():e.slideKeyPressHandler(t.event,1)}" @click="${(e,t)=>e.enableInfopaneRefactoring?e.onNextButtonClicked():e.slideKeyPressHandler(t.event,1)}" data-t="${e=>e.nextFlipperTelemetryTag}">${(0,c.z)(e=>e.direction===L.O.rtl,(0,d.qy)` ${(0,c.z)(e=>e.useWindowsStyles,(0,d.qy)`${eo.A}`)} ${(0,c.z)(e=>!e.useWindowsStyles,e=>eb(e)?eh:eu)} `)} ${(0,c.z)(e=>e.direction===L.O.ltr,(0,d.qy)` ${(0,c.z)(e=>e.useWindowsStyles,(0,d.qy)`${el.A}`)} ${(0,c.z)(e=>!e.useWindowsStyles,e=>eb(e)?em:eg)} `)}</button></slot>${ea.S}<div class=${e=>e.enableInfopaneSwipe?"tabpanelscroll":"tabpanel"} ${(0,er.K)("tabpanelLayout")} @touchstart=${(0,ei.F)((e,t)=>(e.enableInfopaneRefactoring&&e.touchStartHandler(t.event),!0),{capture:!0})} @touchmove=${(0,ei.F)((e,t)=>(e.enableInfopaneRefactoring&&e.touchMoveHandler(t.event),!0),{capture:!0})} @touchend=${(0,ei.F)((e,t)=>(e.enableInfopaneRefactoring&&e.touchEndHandler(t.event),!0),{capture:!0})} @on-welcome-animation=${(e,t)=>{e.freWelcomeAnimationRunning=!0,e.autoScrollHandler()}} @after-welcome-animation=${(e,t)=>{e.freWelcomeAnimationRunning=!1,e.autoScrollHandler()}}><slot name="tabpanel" part="tabpanel" ${(0,en.e)("tabpanels")}></slot></div></template>`;var ev=a(7896),eC=a(41123),ex=a(47810),ew=a(57416),ek=a(37998),e$=a(95403),eS=a(64835),eT=a(86856),e_=a(64187),eI=a(22131),eA=a(50882),eD=a(59669),ez=a(73477),eF=a(49991);let eR="M12.2676 15.793C11.9677 16.0787 11.493 16.0672 11.2073 15.7672L6.20597 10.5168C5.93004 10.2271 5.93004 9.77187 6.20597 9.4822L11.2073 4.23173C11.493 3.93181 11.9677 3.92028 12.2676 4.20597C12.5676 4.49166 12.5791 4.96639 12.2934 5.26631L7.78483 9.99949L12.2934 14.7327C12.5791 15.0326 12.5676 15.5073 12.2676 15.793Z",eL="M7.73271 4.20694C8.03263 3.92125 8.50737 3.93279 8.79306 4.23271L13.7944 9.48318C14.0703 9.77285 14.0703 10.2281 13.7944 10.5178L8.79306 15.7682C8.50737 16.0681 8.03263 16.0797 7.73271 15.794C7.43279 15.5083 7.42125 15.0336 7.70694 14.7336L12.2155 10.0005L7.70694 5.26729C7.42125 4.96737 7.43279 4.49264 7.73271 4.20694Z",eM=(0,eD.A)` .previous-flipper.windows:hover > svg > path,.previous-flipper.windows:focus-visible > svg > path{d:path("${eR}")}.next-flipper.windows:hover > svg > path,.next-flipper.windows:focus-visible > svg > path{d:path("${eL}")}`,eE=(0,eD.A)` .previous-flipper.windows:hover > svg > path,.previous-flipper.windows:focus-visible > svg > path{d:path("${eL}")}.next-flipper.windows:hover > svg > path,.next-flipper.windows:focus-visible > svg > path{d:path("${eR}")}`,eB=(0,eD.A)` ${(0,e_.V)("grid")} :host{--elevation:4;box-sizing:border-box;font-family:${ev.O};font-size:${eC.K};line-height:${eC.Z};color:${ex.l};background:${eF.dR};border-radius:calc(${ew.JU} * 1px);${ek.ET};overflow:hidden;height:100%;grid-template-columns:auto 1fr auto;grid-template-rows:auto 1fr;width:100%}:host(:hover) ::slotted([slot="previous-flipper"]),:host(:hover) .previous-flipper,:host(:hover) ::slotted([slot="next-flipper"]),:host(:hover) .next-flipper{opacity:1;transition:opacity 0.2s ease-in-out}:host(.light:hover) .previous-flipper:before,:host(.light:hover) .next-flipper:before{opacity:1;background:${ex.l}}.tappanel-scroll-anim{transition:transform .3s}.tablist{display:grid;grid-template-rows:auto auto;grid-template-columns:auto;position:absolute;bottom:6px;left:50%;transform:translate(-50%);width:max-content;align-self:center;justify-self:center;grid-row:1;grid-column:1 / span 3;z-index:3;cursor:pointer}.tablist.windows{display:none}.previous-flipper.windows,.next-flipper.windows{margin:0 8px;width:32px;height:32px;border-radius:16px;display:flex;align-items:center;justify-content:center;border:0px;--elevation:8;${ek.ET};background:${ex.l};fill:${e$.Wl}}.previous-flipper.windows:hover,.next-flipper.windows:hover,.previous-flipper.windows:focus-visible,.next-flipper.windows:focus-visible{--elevation:16}::slotted([slot="previous-flipper"]),.previous-flipper:not(.windows),::slotted([slot="next-flipper"]),.next-flipper:not(.windows){width:30px;height:56px;display:flex;justify-content:center;align-items:center;margin:0;position:relative;fill:${ex.l};color:${ex.l};background:transparent;border:none;padding:0}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-narrow:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-narrow:not(.windows){width:24px;height:72px;fill:currentColor;color:${e$.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-wide:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-wide:not(.windows){width:32px;height:72px;fill:currentColor;color:${e$.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-large:not(.windows),::slotted([slot="next-flipper"]),.next-flipper.flipper-light-large:not(.windows){width:32px;height:64px;fill:currentColor;color:${e$.wO}}::slotted([slot="previous-flipper"]),.previous-flipper.flipper-light-narrow:not(.windows),.previous-flipper.flipper-light-large:not(.windows),.previous-flipper.flipper-light-wide:not(.windows){inset-inline-start:4px}::slotted([slot="previous-flipper"]),.next-flipper.flipper-light-narrow:not(.windows),.next-flipper.flipper-light-large:not(.windows),.next-flipper.flipper-light-wide:not(.windows){inset-inline-end:4px}::slotted([slot="previous-flipper"]),.previous-flipper{grid-column:1;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}::slotted([slot="next-flipper"]),.next-flipper{grid-column:3;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}.previous-flipper.flipper-light2{margin-inline-start:2px}.next-flipper.flipper-light2{margin-inline-end:2px}.previous-flipper.flipper-light2,.next-flipper.flipper-light2{width:24px;height:48px;opacity:1}.previous-flipper.flipper-light2,.next-flipper.flipper-light2,.previous-flipper.flipper-light,.next-flipper.flipper-light,.previous-flipper.flipper-light-narrow,.next-flipper.flipper-light-narrow,.previous-flipper.flipper-light-large,.next-flipper.flipper-light-large,.previous-flipper.flipper-light-wide,.next-flipper.flipper-light-wide{fill:currentColor;color:${e$.wO}}::slotted([slot="previous-flipper"])::before,.previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper:not(.windows)::before{content:"";opacity:0.3;background:${e$.Wl};position:absolute;top:0;right:0;left:0;bottom:0;transition:all 0.1s ease-in-out}.previous-flipper.flipper-light:focus-visible::before,.next-flipper.flipper-light:focus-visible::before,.previous-flipper.flipper-light::before,.next-flipper.flipper-light::before{background:${ex.l};box-shadow:rgba(0,0,0,0.1) 0px 2px 4px;opacity:0.5}.previous-flipper.flipper-light2:focus-visible::before,.next-flipper.flipper-light2:focus-visible::before,.previous-flipper.flipper-light-narrow:focus-visible::before,.next-flipper.flipper-light-narrow:focus-visible::before,.previous-flipper.flipper-light-large:focus-visible::before,.next-flipper.flipper-light-large:focus-visible::before,.previous-flipper.flipper-light-wide:focus-visible::before,.next-flipper.flipper-light-wide:focus-visible::before,.previous-flipper.flipper-light2::before,.next-flipper.flipper-light2::before,.previous-flipper.flipper-light-narrow::before,.next-flipper.flipper-light-narrow::before,.previous-flipper.flipper-light-large::before,.next-flipper.flipper-light-large::before,.previous-flipper.flipper-light-wide::before,.next-flipper.flipper-light-wide::before{border-radius:2px;background:${ex.l};box-shadow:rgba(0,0,0,0.1) 0px 2px 4px;opacity:0.5;transition:opacity 0.3s linear 0s}.previous-flipper.flipper-light-narrow::after,.next-flipper.flipper-light-narrow::after,.previous-flipper.flipper-light-wide::after,.next-flipper.flipper-light-wide::after{content:"";position:absolute;top:-4px;right:-4px;left:-4px;bottom:-4px}::slotted([slot="previous-flipper"])::before,.previous-flipper.opacity-one-previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper.opacity-one-next-flipper:not(.windows)::before{opacity:1}.next,.previous{position:relative;${""} width:16px;height:16px}.filled-next,.filled-previous{position:relative;width:24px;height:24px}::slotted([slot="previous-flipper"]:hover),.previous-flipper:hover,::slotted([slot="next-flipper"]:hover),.next-flipper:hover{cursor:pointer}::slotted([slot="previous-flipper"]:${ez.N}),.previous-flipper:${ez.N},::slotted([slot="next-flipper"]:${ez.N}),.next-flipper:${ez.N}{opacity:1}::slotted([slot="previous-flipper"]:${ez.N})::before,.previous-flipper:${ez.N}::before,::slotted([slot="next-flipper"]:${ez.N})::before,.next-flipper:${ez.N}::before{background:${e$.oO};opacity:1}::slotted([slot="previous-flipper"]:hover)::before,.previous-flipper:hover::before,::slotted([slot="next-flipper"]:hover)::before,.next-flipper:hover::before{background:${e$.oO};opacity:1}:host([layout="1-column"]){--heading-font-size:${eC.K};--heading-line-height:${eC.Z}}.activeIndicator{grid-row:2;grid-column:1;width:20px;height:3px;border-radius:calc(${ew.Pb} * 1px);justify-self:center;background:${eS.IR}}.activeIndicatorTransition{transition:transform 0.2s ease-in-out}.tabpanel{grid-row:1/3;grid-column-start:1;grid-column-end:4;position:relative}.tabpanelscroll{position:absolute;height:100%;display:flex}`.withBehaviors(new eT.t(eM,eE),(0,eI.G2)((0,eD.A)` ::slotted([slot="previous-flipper"]),.previous-flipper:not(.windows),::slotted([slot="next-flipper"]),.next-flipper:not(.windows){fill:${e$.Wl};color:${e$.Wl}}::slotted([slot="previous-flipper"])::before,.previous-flipper:not(.windows)::before,::slotted([slot="next-flipper"])::before,.next-flipper:not(.windows)::before{background:${ex.l}}::slotted([slot="previous-flipper"]:hover)::before,.previous-flipper:hover::before,::slotted([slot="next-flipper"]:hover)::before,.next-flipper:hover::before{background:${ex.l}}.previous-flipper.windows,.next-flipper.windows{fill:${ex.l};background:${eF.dR}}`),(0,eI.mr)((0,eD.A)` .activeIndicator{forced-color-adjust:none;background:${eA.A.Highlight}}.previous-flipper.windows,.next-flipper.windows{background:${eA.A.ButtonFace}}.previous-flipper.windows:hover,.next-flipper.windows:hover,.previous-flipper.windows:focus-visible,.next-flipper.windows:focus-visible{background:${eA.A.Highlight};fill:${eA.A.HighlightText}}`));var eP=a(34897),eO=a(13660),eN=a(651);let eH=class extends et{};eH=(0,j.Cg)([(0,G.E)({name:"msn-info-pane",template:ey,styles:eB})],eH),eP.L.define(eN.i.registry),eO.K.define(eN.i.registry);var eq=a(37903),eW=a(66864);class eK extends eW.t{constructor(){super(...arguments),this.effectId="",this.isEnabled=!1,this.intersectionRootMargin="0px 0px 0px 0px",this.animationType="",this.showMultiTimes=!1,this.isAnimationValid=!1,this.updateAnimStatus=(e,t)=>{this.isAnimationValid!==e&&(this.isAnimationValid=e,e&&t&&setTimeout(()=>{t()},this.animationConfig.duration))}}connectedCallback(){if(super.connectedCallback(),this.animationType){this.effectGroup=eq.t.getEffectGroup();let e={root:this.intersectionRoot,rootMargin:this.intersectionRootMargin};this.effectGroup.register(this.effectId,this.animContainer,this.updateAnimStatus,e,this.showMultiTimes,this.animationConfig.delayTimeMs)}}disconnectedCallback(){super.disconnectedCallback(),this.animationType&&this.effectGroup.unregister(this.effectId)}}(0,j.Cg)([Z.CF],eK.prototype,"effectId",void 0),(0,j.Cg)([(0,Z.CF)({mode:"boolean"})],eK.prototype,"isEnabled",void 0),(0,j.Cg)([Z.CF],eK.prototype,"intersectionRoot",void 0),(0,j.Cg)([Z.CF],eK.prototype,"intersectionRootMargin",void 0),(0,j.Cg)([Z.CF],eK.prototype,"animationType",void 0),(0,j.Cg)([Z.CF],eK.prototype,"animationConfig",void 0),(0,j.Cg)([(0,Z.CF)({mode:"boolean"})],eK.prototype,"showMultiTimes",void 0),(0,j.Cg)([Y.sH],eK.prototype,"isAnimationValid",void 0);let eU={"scale-up":"animation1","scale-down":"animation1","scale-up-down":"animation2","opacity-up":"opacity-up-animation","move-up":"move-up-animation","move-up2":"move-up-animation2"},eV=(0,d.qy)`<style>.anim-container { overflow: hidden; width: 100%; height: 100%; } .anim-container div { transform: scale(${e=>e.animationConfig?.scaleFrom||1}); } .anim-wrapper { animation: ${e=>eU[e.animationType]} ${e=>e.animationConfig?.durationString} forwards; } .anim-wrapper-initial { opacity: ${e=>e.animationConfig?.initialOpacity?e.animationConfig?.initialOpacity:1}; } @keyframes animation1 { 0% { transform: scale(${e=>e.animationConfig?.scaleFrom}); } 100% { transform: scale(${e=>e.animationConfig?.scaleTo}); } } @keyframes animation2 { 0% { transform: scale(${e=>e.animationConfig?.scaleFrom}); } 50% { transform: scale(${e=>e.animationConfig?.scaleTo}); } 100% { transform: scale(${e=>e.animationConfig?.scaleFrom}); } } @keyframes opacity-up-animation { 0% { opacity: 0; } 66% { opacity: 0; } 100% { opacity: 1; } } @keyframes move-up-animation { 0% { transform: translate(0px, 100%); opacity: 0; } 33% { transform: translate(0px, 0px); opacity: 1; } 66% { transform: translate(0px, 0px); opacity: 1; } 100% { transform: translate(0px, -100%); opacity: 0; } } @keyframes move-up-animation2 { 0% { transform: translate(0px, 100%); opacity: 0; } 66% { transform: translate(0px, 100%); opacity: 0; } 100% { transform: translate(0px, 0px); opacity: 1; } }</style><div class="anim-container">${(0,c.z)(e=>e.animationType&&e.animationConfig,(0,d.qy)`<div class=${e=>e.isAnimationValid?"anim-wrapper":"anim-wrapper-initial"} ${(0,er.K)("animContainer")}><span part="anim-content"><slot name="anim-content"></slot></span></div>`)} ${(0,c.z)(e=>!e.animationType,(0,d.qy)`<slot name="anim-content"></slot>`)}</div>`;var ej=a(16559);let eG=(0,eD.A)``.withBehaviors(new ej.e("layoutStyle")),eX=class extends eK{};eX=(0,j.Cg)([(0,G.E)({name:"msn-animation-decorator",template:eV,styles:eG})],eX);var eJ=a(30383),eZ=a(30337),eY=a(66459),eQ=a(82988),e0=a(2188),e1=a(77833),e2=a(10371),e6=a(42537),e3=a(60941),e4=a(14097),e5=a(58034);eY.j,eJ._t;let e8=(0,d.qy)`
    <msn-info-pane-tab id="tab_${e=>e.id}" aria-label="${e=>e.title}"></msn-info-pane-tab>
`,e7=(0,d.qy)`
<msn-info-pane-panel id="tab_panel_${e=>e.id}">
    <msft-info-pane-slide>
        ${e6.B}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,e9=(0,d.qy)`
    <style>
        .card-button {
            border-radius: 100%;
        }

        /* 
         * Here about 'from the web' attribution style
         */
        msft-article[id="contentcard_${e=>e.id}"]::part(start-actions) {
            flex:1;
            padding-inline-end: 6px;
        }
        msft-article[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-article[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
        msft-article[id="contentcard_${e=>e.id}"] msft-attribution, msft-article[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
            ${e=>e.isProviderIconClickable?"display: inline-flex":""}
        }
        msft-article[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-article[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }   
    </style>
    <msn-info-pane-panel id="tab_panel_${e=>e.id}">
        <msft-info-pane-slide>
            <msft-article-card
                size="${e=>e.cardSize}"
                card-fill-color="${e=>e.articleCardBackgroundColor?.find(e=>e.isDarkMode===(0,U.ud)())?.hexColor}"
                class="infopane"
            >
                <msft-article
                    id="contentcard_${e=>e.id}"
                    href=${e=>e.destinationUrl}
                    target=${e=>e.openLinksInNewTab||e.openArticleInNewTab?"_blank":"_self"}
                    title=${e=>e.disableCardTitleTooltip?"":e.title}
                    aria-label=${e=>e.ariaLabel}
                    data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
                    :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
                    :handleContentCardClickOverride=${e=>e.handleContentCardClickOverride}
                    @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
                    @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
                >
                    ${(0,c.z)(e=>e.contentIndicator,e=>(0,m.Z)(e.contentIndicator))}
                    ${(0,c.z)(e=>e.imageData,(0,d.qy)`
                        <img
                            slot="image"
                            alt="${e=>e.imageData.altText}"
                            src="${e=>e.imageData.source}"
                            @load="${e=>e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}"
                        />
                    `)}
                    ${h.y}
                    ${(0,c.z)(e=>e.abstract&&!e.isMsnHpExternalLinkCard,(0,d.qy)`
                        <p slot="abstract" style="display: -webkit-box; -webkit-line-clamp: ${e=>e.contentIndicator?"3":"4"}; -webkit-box-orient: vertical; overflow: hidden;">
                            ${e=>e.abstract}
                        </p>
                    `)}
                    ${(0,b.fn)("start-action")}
                    ${(0,c.z)(e=>!e.isAnaheimDesign,(0,d.qy)`
                        <div slot="start-action" style="gap:0">
                            ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled&&!e.enableRichSocialReaction,(0,d.qy)`
                                ${f.LW}
                                ${f.tB}
                            `)}
                            ${(0,c.z)(e=>e.enableRichSocialReaction,()=>(0,f.nj)({}))}
                        </div>
                    `)}
                    <div slot="end-action" style="gap:0">
                        ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled,(0,d.qy)`
                            ${(0,c.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,d.qy)`
                                ${(0,c.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&K.J.showMore,f.LW)}
                                ${(0,c.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&K.J.showFewer,f.tB)}
                            `)}
                            ${(0,c.z)(e=>e.enableWCCardAction,y.L)}
                        `)}
                    </div>
                    ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled,v.C)}
                </msft-article>
            </msft-article-card>
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,te=(0,d.qy)`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-info-pane-slide {
            width: 100%;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        
        ${(0,c.z)(e=>e.contentType===e1.pL.Video,(0,d.qy)`
            msft-content-card[id="contentcard_${e=>e.id}"] msft-content-indicator {
                color: transparent;
                left: 286px;
                top: 100px;
            }
            msft-content-card[id="contentcard_${e=>e.id}"] msft-content-indicator::after{
                background: transparent;
            }
        `)}

        /* 
         * Here and elsewhere about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"]::part(start-actions) {
            flex:1;
            padding-inline-end: 6px;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <msn-info-pane-panel id="tab_panel_${e=>e.id}">
        <msft-info-pane-slide>
            <msft-content-card
                id="contentcard_${e=>e.id}"
                class="${e=>tC(e)}"
                href=${e=>e.destinationUrl}
                target=${e=>e.openLinksInNewTab||e.openArticleInNewTab?"_blank":"_self"}
                :handleContentCardClickOverride=${e=>e.handleContentCardClickOverride}
                title=${e=>e.disableCardTitleTooltip?"":e.id.includes("BuyDirectCard")?e.abstract:e.title}
                aria-label=${e=>e.ariaLabel}
                layout=${e=>e.cardLayout}
                data-t="${e=>e.telemetryContext&&e.telemetryContext.contentCard&&e.telemetryContext.contentCard.getMetadataTag()}"
                :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
                @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
            >
            ${h.y}
            ${(0,c.z)(e=>e.contentIndicator,e=>(0,m.Z)(e.contentIndicator))}
            ${(0,c.z)(e=>e.imageData,(0,d.qy)`
                <img
                    slot="background-image"
                    alt="${e=>e.imageData.altText}"
                    src="${e=>e.imageData.source}"
                    @load="${e=>e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}"
                    @error="${e=>{var t;return t=e.imageData.source,void(0,g.vV)(u.zfe,"Error fetching source","Source: "+t)}}"
                />
            `)}
            ${(0,c.z)(e=>e.abstract&&!e.isMsnHpExternalLinkCard,(0,d.qy)`
                <p slot="abstract" style="display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden;">
                    ${e=>e.abstract}
                </p>
            `)}
            ${(0,c.z)(e=>e.badge,e=>(0,C.w)(e.badge))}
            ${(0,c.z)(e=>!e.isMsnHpExternalLinkCard,e=>(0,b.fn)(e.providerAboveHeader?"attribution":"start-actions"))}
            ${(0,c.z)(e=>e.isMsnHpExternalLinkCard,(0,d.qy)`
                <msft-attribution slot="attribution" style="--design-unit: 1.5; position: absolute; bottom: 10px;">
                    <span style="unicode-bidi:embed">${e=>e.abstract}</span>
                </msft-attribution>
            `)}
            ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled,x.K)}
            ${(0,c.z)(e=>!e.isAnaheimDesign,(0,d.qy)`
                <div slot="start-actions" style="gap:0">
                    ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled&&!e.enableRichSocialReaction,(0,d.qy)`
                        ${f.LW}
                        ${f.tB}
                    `)}
                </div>
            `)}
            <div slot="${e=>e.providerAboveHeader?"start-actions":"end-actions"}" style="gap:0">
                ${(0,c.z)(e=>e.enableRichSocialReaction,()=>(0,f.nj)({}))}
                ${(0,c.z)(e=>e.cardActionStatus&K.J.enabled,(0,d.qy)`
                    ${(0,c.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,d.qy)`
                        ${(0,c.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&K.J.showMore,f.LW)}
                        ${(0,c.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&K.J.showFewer,f.tB)}
                    `)}
                    ${(0,c.z)(e=>e.enableWCCardAction,y.L)}
                `)}
            </div>
            ${(0,c.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,w.p)}
            </msft-content-card>
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,tt=(0,d.qy)`
        <div class="info-pane-slide-title" part="info-pane-slide-title" style="display: flex; align-items: end;">
            <h3 class="info-pane-slide-title" style="pointer-events: none; flex: 1;" part="info-pane-slide-title">
                ${e=>e.title}
            </h3>
            <div class="cta-button" style="margin-inline-start: 4px; z-index: 2; height: 34px;">
                <msn-native-ad-call-to-action 
                    text=${e=>e.localizedStrings.nativeAdLearnMoreText||"learn more"}
                    default-background-color="#C6C0BA"
                    background-color="${e=>e.layoutColor}"
                    color="#000000"
                    is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
                    cta-mode="default"
                    destination-url=${e=>e.destinationUrl}
                    tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
                    ${(0,e0.Ib)(!0,!1)}
                >
                </msn-native-ad-call-to-action>
            </div>
        </div>
    `,ta=e=>e?ti(e):h.y,ti=e=>(0,d.qy)`
    <div class="info-pane-slide-title" part="info-pane-slide-title" style="display: flex; align-items: end;">
        <h3 class="info-pane-slide-title" style="pointer-events: none; flex: 1;" part="info-pane-slide-title">
            ${e=>e.title}
        </h3>
        <msn-native-ad-call-to-action
            text=${()=>e}
            title=${()=>e}
            aria-label=${()=>e}
            :layoutConfig=${()=>({marginBottom:"6px",zIndex:2,marginInlineStart:"10px"})}
            background-color="${e=>e.layoutColor}"
            destination-url=${e=>e.destinationUrl}
            tel-metadata=${e=>e.adTelemetryContext?.destination?.getMetadataTag()}
            ${(0,e0.Ib)(!0,!1)}
        >
        </msn-native-ad-call-to-action>
    </div>   
`,tn=(0,d.qy)`
    <style>
        msft-info-pane-slide {
            width: 100%;
        }
        msft-content-card.native-ad-infopane-content-card::part(body) {
            grid-template-rows: 1fr 40px;
        }
        msft-content-card.native-ad-infopane-content-card::part(footer) {
            position: absolute;
            bottom: 0px;
            width: calc(100% - 32px);
        }
        msft-content-card.native-ad-infopane-content-card msft-attribution.info-pane-card-deco {
            top: -55px;
        }
        msft-content-card.native-ad-infopane-content-card.hasInlineDecoration msft-attribution[slot="start-actions"] {
            margin-top: 0px;
        }
        msft-content-card.native-ad-infopane-content-card msft-attribution[slot="start-actions"] .provider-name{
            vertical-align: middle;
        }
        msft-content-card.native-ad-infopane-content-card.hasInlineDecoration div[slot="end-actions"] {
            margin-top: 0px;
        }
        msft-content-card.hasInlineDecoration msft-attribution[slot="call-to-action"] {
            bottom: 50px;
            z-index: unset;
        }
        msft-content-card.native-ad-infopane-content-card .info-pane-card-deco msn-inline-group::part(group-container) {
            height: fit-content;
            transition: height  0.5s;
        }
        msft-info-pane-slide msft-ad-label {
            margin-right: 0;
        }
        msft-content-card a.ad-choice-icon {
            display: inline-flex;
            justify-content: center;
            min-width: calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px);
        }

        msft-content-card a.ad-choice-hidden {
            max-width: 0px;
            min-width: 0px;
            visibility: hidden;
            width: 0;
            padding: 0;
            margin: 0;
            border: 0;
        }

        msft-content-card.native-ad h3.info-pane-slide-title, msft-content-card.${(0,S.nP)("native-ad")} h3.info-pane-slide-title {
            -webkit-line-clamp: 2;
        }

        ${e=>(e=>{if(!e||!e.template)return"";let t=[];switch(W(e)&&t.push(M),e.template.templateType){case"msn-info-pane-horizontal-1-by-1":t.push(E);break;case"msn-info-pane-horizontal-3-by-4":t.push(B);break;case"msn-info-pane-horizontal-4-by-3":t.push(P);break;case"msn-info-pane-horizontal-9-by-16":t.push(O);break;case"msn-info-pane-pattern-overlay-1-by-1":t.push(N),t.push(H);break;case"msn-info-pane-pattern-overlay-4-by-3":t.push(N),t.push(q)}return t.join(" ")})(e)}
    </style>
    
    <msft-content-card
        id="${e=>(0,S.s4)(e.enableSafeAds,`native_ad_${e.id}_${e.index}`)}"
        class="${e=>tC(e)} ${e=>(e=>{let t=[(0,S.s4)(e.enableSafeAds,"native-ad")];if(e.template&&e.template.progressiveDisplay&&t.push("native-ad-infopane-content-card"),document.dir===L.O.rtl&&t.push("rtl"),e.template&&e.template.templateType)switch(e.template.templateType){case"msn-info-pane-horizontal-1-by-1":t.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-1-by-1");break;case"msn-info-pane-horizontal-3-by-4":t.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-3-by-4");break;case"msn-info-pane-horizontal-4-by-3":t.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-4-by-3");break;case"msn-info-pane-horizontal-9-by-16":t.push("native-ad-infopane-horizontal native-ad-infopane-horizontal-9-by-16");break;case"msn-info-pane-pattern-overlay-1-by-1":t.push("native-ad-infopane-horizontal native-ad-infopane-pattern-overlay native-ad-infopane-pattern-overlay-1-by-1");break;case"msn-info-pane-pattern-overlay-4-by-3":t.push("native-ad-infopane-horizontal native-ad-infopane-pattern-overlay native-ad-infopane-pattern-overlay-4-by-3")}return t.join(" ")})(e)}"
        href=${e=>e.destinationUrl}
        target="_blank"
        title=${e=>e.disableCardTitleTooltip?"":e.title}
        layout=${e=>e.cardLayout}
        data-t="${e=>e.id&&e.adTelemetryContext&&e.adTelemetryContext.nativeAdCard&&e.adTelemetryContext.nativeAdCard.getMetadataTag()}"
        :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
        ${(0,e0.Ib)()}
        @mouseenter=${e=>tx(e,!0)}
        @mouseleave=${e=>tx(e,!1)}
    >
        ${(e,t)=>t$(e.template,e.localizedStrings,t.parent?.nativeAds)}
        ${(0,c.z)(e=>e.hasAnyInlineDecoration,(0,d.qy)`
            ${e=>(0,eZ.zN)(e,!0)}               
        `)}
        ${(0,c.z)(e=>e.videoProps,(0,d.qy)`
            <native-ad-video-controls
                region="infopane"
                :destinationUrl=${e=>e.destinationUrl}
                :localizedStrings=${e=>e.localizedStrings}
            ></native-ad-video-controls>
            <div slot="${e=>W(e)?"media":"background-image"}" style="height: 100%; width: 100%">
                <native-ad-video-player
                    :videoProps=${e=>e.videoProps}
                    :backgroundImg=${e=>e.imageData}
                    region="infopane"
                ></native-ad-video-player>
            </div>
        `)}
        ${(0,c.z)(e=>e.imageData&&!e.videoProps,(0,d.qy)`         
            <div slot="${e=>W(e)?"media":"background-image"}" style="height: 100%; width: 100%">
                <img
                    style="height: 100%; width: 100%; object-fit: cover;"
                    slot="anim-content"
                    id="${e=>e.id}-img"
                    alt="${e=>e.imageData.altText}"
                    src="${e=>e.imageData.source}"
                    @load="${(e,t)=>(0,T.mQ)(e,t,"InfopaneCardTemplate")}"
                    @error="${(e,t)=>{(0,T.mQ)(e,t,"InfopaneCardTemplate"),(0,_.T)({id:`native_ad_${e.id}_${e.index}`,rLink:e.destinationUrl,imgLink:e.imageData.source})}}"
                />
            </div>
        `)}
        ${(0,c.z)(e=>e.providerData,(0,d.qy)`
            <msft-attribution slot="start-actions" id="start-actions" style="color: var(--neutral-foreground-rest);--design-unit: 0;">
                ${R.pK}
                ${e=>(0,R.Bq)(e.destinationUrl)}
                ${(0,c.z)(e=>e.assets&&e.assets.localInventory,(0,d.qy)`
                    &bull;<span id="in-store">${e=>e.localizedStrings.nativeAdInStoreText}</span>
                `)}
            </msft-attribution>
        `)}
        <div 
            slot="end-actions" 
            style="max-height: 32px;
            gap: 0; 
            position: relative"
        >
            ${(0,eQ.UN)()}
            ${(0,c.z)(e=>e.adChoiceIconUrl,(0,d.qy)`
            <a href="${e=>e.adChoiceIconUrl}" target="_blank"
                    class="${e=>to(e)} ad-choice-icon"
                    id="${e=>e.id}-ad-choice"
                    data-t="${e=>e.adTelemetryContext?.adChoice?.getMetadataTag()}"
                >
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter:invert(71%) sepia(0%) saturate(0%) hue-rotate(332deg) brightness(95%) contrast(97%);">
                        <path d="M4.52344 5.69531C4.70573 5.69531 4.86198 5.63542 4.99219 5.51562C5.1224 5.39062 5.1875 5.24219 5.1875 5.07031C5.1875 4.89844 5.1224 4.7526 4.99219 4.63281C4.86198 4.50781 4.70573 4.44531 4.52344 4.44531C4.33594 4.44531 4.17708 4.50781 4.04688 4.63281C3.91667 4.7526 3.85156 4.89844 3.85156 5.07031C3.85156 5.24219 3.91667 5.39062 4.04688 5.51562C4.17708 5.63542 4.33594 5.69531 4.52344 5.69531ZM1.44531 0.921875V0.929688C1.33594 0.861979 1.21875 0.828125 1.09375 0.828125C0.90625 0.828125 0.747396 0.890625 0.617188 1.01562C0.486979 1.13542 0.421875 1.28125 0.421875 1.45312V11.375C0.421875 11.5469 0.486979 11.6953 0.617188 11.8203C0.747396 11.9401 0.90625 12 1.09375 12C1.19271 12 1.28906 11.9792 1.38281 11.9375H1.39062L1.40625 11.9219L3.20312 11.0625C3.48958 10.9635 3.63281 10.7708 3.63281 10.4844C3.63281 10.3073 3.56771 10.1589 3.4375 10.0391C3.30729 9.91406 3.15104 9.85156 2.96875 9.85156C2.85417 9.85156 2.74479 9.8776 2.64062 9.92969C2.63542 9.9401 2.61979 9.95052 2.59375 9.96094C2.51042 10.0026 2.42188 10.0234 2.32812 10.0234C2.17188 10.0234 2.03906 9.97396 1.92969 9.875C1.82031 9.77083 1.76302 9.64844 1.75781 9.50781V3.375C1.76302 3.22917 1.82031 3.10677 1.92969 3.00781C2.03906 2.90365 2.17188 2.85156 2.32812 2.85156C2.41667 2.85156 2.5 2.8724 2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L8.53906 5.92188L8.64844 5.97656C8.8099 6.08594 8.89062 6.23177 8.89062 6.41406C8.89062 6.60677 8.80469 6.75521 8.63281 6.85938L8.5625 6.89844L5.1875 8.60938V6.67969C5.1875 6.5026 5.1224 6.35417 4.99219 6.23438C4.86198 6.11458 4.70573 6.05469 4.52344 6.05469C4.33594 6.05469 4.17708 6.11458 4.04688 6.23438C3.91667 6.35417 3.85156 6.5026 3.85156 6.67969V9.65625C3.85156 9.83333 3.91667 9.98177 4.04688 10.1016C4.17708 10.2214 4.33594 10.2812 4.52344 10.2812C4.65885 10.2812 4.78385 10.2448 4.89844 10.1719L11.125 7.00781C11.4271 6.90885 11.5781 6.71094 11.5781 6.41406C11.5781 6.14844 11.4453 5.95833 11.1797 5.84375L1.44531 0.921875ZM2.59375 9.96094C2.61979 9.95052 2.63542 9.9401 2.64062 9.92969L2.59375 9.96094ZM2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L2.57812 2.91406Z" fill="#00aecd"/>
                    </svg>
                </a>
            `)}
            ${(0,c.z)(e=>e.isAdFeedbackV1Enabled&&!!e.feedbackUrl,(0,d.qy)`
                <div class="see-more-telemetry-wrapper"
                    data-t="${e=>e.adTelemetryContext?.seeMore?.getMetadataTag()}"
                >
                    ${y.L}
                </div>
            `)}
        </div>
    </msft-content-card>
`,tr=(0,d.qy)`
    <msn-native-ad-wc
        id="${e=>(0,S.s4)(e.enableSafeAds,`native_ad_${e.id}_${e.index}`)}"
        style="z-index:0; position:relative"
        data-t="${e=>e.id&&e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
        ${(0,e0.Ib)(!1,!0)}
        :configRef=${e=>e.nativeAdWC?.configRef}
        :localizedStrings=${e=>e.localizedStrings}
        :adData=${e=>e}
        :isInfopane=${()=>!0}
    ></msn-native-ad-wc>
`,to=e=>e.hideAdLabelAndAdChoice?"ad-choice-hidden":"",tl=(0,d.qy)`
    <style>
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.nativeAdVideo-infopane::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 50px;
            height: auto;
        }
        msft-content-card.nativeAdVideo-infopane::part(mask) {
            visibility: hidden;
        }
        msft-content-card.nativeAdVideo-infopane::part(heading)::after {
            top: unset;
            bottom: 50px;
            right: 60px;
            width: 545px;
            height: 247px;
        }
        msft-content-card.nativeAdVideo-infopane::part(heading-container) {            
            width: 530px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        msft-attribution.info-pane-card-deco {
            z-index: unset;
            top: -65px;
            margin-bottom: -10px;
        }
        msft-attribution[slot="start-actions"] #in-store {
            margin-left: 3px;
        }
    </style>
    <msn-info-pane-panel id="tab_panel_${e=>(0,S.s4)(e.enableSafeAds,e.id)}">
        <style>
            msft-info-pane-slide {
                gap: 2px;
                background: linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(255,255,255,1) 50%, rgba(0,0,0,1) 100%);
            }
            .no-gap {
                gap: 0px;
            }
        </style>
        <msft-info-pane-slide
            layout="${e=>["single","double","triple"][Math.min(2,e.nativeAds.length-1)]}" 
            class="${e=>(0,S.s4)(e.enableSafeAds,`title-ad-${["single","double","triple"][Math.min(2,e.nativeAds.length-1)]}`)}"
        >
            ${(0,p.ux)(e=>e.nativeAds.slice(0,3),(0,d.qy)`${e=>e.nativeAdWC?tr:tn}`)}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,ts=(0,d.qy)`
 <msn-info-pane-panel id="tab_panel_${e=>e.id}">
     <style>
         msft-info-pane-slide msn-hide-story-card.hide-story-card {
             padding-top: 20px;
         }
         msft-info-pane-slide msn-hide-story-card.hide-story-card fluent-button {
             width: 48%;
             margin: 0 0 8px 0;
             display: flex;
         }
         msn-hide-story-card.hide-story-card::part(content-region) {
             display: inline-flex;
             align-items: center;
             padding: 16px 16px 0px;
             cursor: default;
         }
         msn-hide-story-card.hide-story-card::part(action-region) {
             display: flex;
             position: absolute;
             padding: 0px 16px 16px;
             justify-content: space-around;
             bottom: 0px;
             width: 100%;
             box-sizing: border-box;
             align-items: center;
             margin: 0;
         }
     </style>
     <msft-info-pane-slide>
         ${I.u}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,td=(0,d.qy)`
<msn-info-pane-panel id="tab_panel_${e=>e.id}">
    <msft-info-pane-slide>
        ${A.F}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,tc=(0,d.qy)`
<msn-info-pane-panel id="tab_panel_${e=>e.id}">
    <msft-info-pane-slide>
        ${D.X}
    </msft-info-pane-slide>
</msn-info-pane-panel>
`,tp=(0,d.qy)`
    <msn-info-pane-panel id="tab_panel_${e=>e.id}">
        <style>
            @media (prefers-color-scheme: light) {
                msft-info-pane-slide msn-hide-story-card.report-ad {
                    --neutral-foreground-rest: #2B2B2B;
                    --neutral-fill-input-rest: #FFFFFF;
                    --neutral-fill-rest: #EDEDED;
                    --neutral-fill-hover: #E5E5E5;
                    padding-top: 0px;
                    background: #FFFFFF;
                }
            }

            @media (prefers-color-scheme: dark) {
                msft-info-pane-slide msn-hide-story-card.report-ad {
                    --neutral-foreground-rest: #FFFFFF;
                    --neutral-fill-input-rest: #2B2B2B;
                    --neutral-fill-rest: #3D3D3D;
                    --neutral-fill-hover: #454545;
                    padding-top: 0px;
                    background: #2B2B2B;
                }
            }
            msft-info-pane-slide msn-hide-story-card.report-ad::part(content-region) {
                flex-direction: row;
                margin: 0;
                text-align: left;
                padding: 16px 16px 0px 24px;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad::part(action-region) {
                display: block;
                position: static;
                margin: 26px 0px 0px 0px;
                padding: 0px 16px 16px 24px;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button {
                width: 45%;
                display: inline-block;
                margin: 34px 5px 8px;
                text-align: center;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-radio {
                padding: 8px 0px 8px 0px;
                margin: 0;
                display: flex;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button::part(content) {
                text-overflow: ellipsis;
                overflow: hidden;
            }
            msft-info-pane-slide msn-hide-story-card.report-ad fluent-button::part(control) {
                width: 100%;
            }
        </style>
        <msft-info-pane-slide>
            ${z.j}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,tg=(0,d.qy)`
    <msn-info-pane-panel id="tab_panel_${e=>e.id}">
        <style>
            @media (prefers-color-scheme: light) {
                msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation {
                    padding-top: 20px;
                    --neutral-foreground-rest: #2B2B2B;
                    --neutral-fill-input-rest: #FFFFFF;
                    --neutral-fill-rest: #EDEDED;
                    --neutral-fill-hover: #E5E5E5;
                    background: #FFFFFF;
                }
            }

            @media (prefers-color-scheme: dark) {
                msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation {
                    padding-top: 20px;
                    --neutral-foreground-rest: #FFFFFF;
                    --neutral-fill-input-rest: #2B2B2B;
                    --neutral-fill-rest: #3D3D3D;
                    --neutral-fill-hover: #454545;
                    background: #2B2B2B;
                }
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button {
                width: 150px;
                text-align: center;
                display: block;
                margin: 54px auto 8px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button:hover {
                background: var(--button-hover-color);
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation::part(content-region) {
                margin: 0 auto;
                text-align: center;
                padding: 110px 16px 0px 16px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation::part(action-region) {
                display: block;
                position: static;
                margin: 0;
                padding: 0px 16px 16px;
            }
            msft-info-pane-slide msn-hide-story-card.ad-feedback-confirmation fluent-button::part(control) {
                width: 100%;
            }
        </style>
        <msft-info-pane-slide>
            ${F.L}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,tu=(0,d.qy)`
    <msn-info-pane-panel id="tab_panel_${e=>(0,S.s4)(e.enableSafeAds,e.id)}">
        <msft-info-pane-slide>
            ${e=>(0,V.yN)(e.denseConfigInfo,{properties:{denseData:e.denseData,telemetryObject:e.telemetryObject},memoize:!1})}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,tm=(0,d.qy)`
    <msn-info-pane-panel id="tab_panel_${e=>e.id}">
        <msft-info-pane-slide>
            ${e3.M}
        </msft-info-pane-slide>
    </msn-info-pane-panel>
`,th=(0,d.qy)`
 <msn-info-pane-panel id="tab_panel_${e=>(0,S.s4)(e.enableSafeAds,e.id)}">
     <msft-info-pane-slide class="no-gap">
         ${e4.z}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,tb=(0,d.qy)`
 <msn-info-pane-panel id="tab_panel_${e=>e.id}">
     <msft-info-pane-slide class="no-gap">
         ${e2.Q}
     </msft-info-pane-slide>
 </msn-info-pane-panel>
`,tf=(0,d.qy)`
<style>
    :host fluent-card {
        content-visibility: auto;
    }
</style>
<fluent-card style="grid-area:${e=>e.gridArea}; ${e=>e.autoRowHeights?"height: 304px;":""}"  class="${e=>e.cardSize}">
    <fluent-design-system-provider 
        fill-color="#333"
        style="height: 100%;"
    >
        <style>
            msft-content-card fluent-button::part(control) {
                padding: 0;
            }
            msn-info-pane.dense-slide msft-info-pane-slide {
                background: #fff;
            }
            msn-info-pane.dense-slide msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] ~ msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane.dense-slide[activeid^="tab_denseCard-"] msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane.dense-slide msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] {
                background: #2B2B2B;
            }
            msn-info-pane msn-info-pane-tab#tab_topStories[aria-selected="true"] ~ msn-info-pane-tab {
                background: #767676;
            }
            msn-info-pane msn-info-pane-tab#tab_topStories[aria-selected="true"] {
                background: #2B2B2B;
            }
            msn-info-pane[activeid^="tab_FreFeed"] msn-info-pane-tab {
                display: none;
            }
            @media (prefers-color-scheme: dark) {
                msn-info-pane.dense-slide.adapt-dark-mode msft-info-pane-slide {
                    background: #2b2b2b;
                }
                msn-info-pane.dense-slide.adapt-dark-mode msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] {
                    background: #fff;
                }
                msn-info-pane.dense-slide.adapt-dark-mode msn-info-pane-tab[id^="tab_denseCard-"][aria-selected="true"] ~ msn-info-pane-tab {
                    background: #fff;
                }
            }
        </style>
        ${h.j}
        <msn-info-pane id="infopane" layout="${e=>e.layout}" ?activeindicator="${e=>void 0===e.activeIndicator||e.activeIndicator}"
            data-t="${e=>e.telemetryContext?.infopane?.getMetadataTag()}"
            :nextFlipperTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.infopane&&e.telemetryContext.nextSlideArrow.getMetadataTag()}
            :previousFlipperTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.infopane&&e.telemetryContext.previousSlideArrow.getMetadataTag()}
            :previousFlipperTitle=${e=>e.infoPanePreviousFlipperTitle}
            :nextFlipperTitle=${e=>e.infoPaneNextFlipperTitle}
            style="${e=>ty(e)}"
            ?auto-scroll="${e=>e.autoRotate}"
            :autoScrollIntervalMs=${e=>e.autoRotateIntervalMs}
            ?disable-auto-scroll="${e=>e.disableAutoRotate}"
            ?enable-rotate-after-click=${e=>e.enableRotateAfterClick}
            :rotateAfterClickIntervalMs=${e=>e.rotateAfterClickIntervalMs}
            ?allow-blur-scroll="${e=>e.allowBlurScroll}"
            class="${e=>tk(e)}"
            :firstAutoScrollIntervalMs=${e=>e.firstAutoRotateIntervalMs}
            ?enable-rotate-only-once=${e=>e.enableRotateOnlyOnce}
            ?rotate-prev-after-click-prev-button=${e=>e.rotateBackAfterClickPrevButton}
            ?rotate-stop-after-click-prev-button=${e=>e.rotateStopAfterClickPrevButton}
            ?enable-infopane-refactoring=${e=>e.enableInfopaneRefactoring}
            ?enable-infopane-swipe=${e=>e.enableInfopaneSwipe}
            :adTimerMap=${e=>e.adTimerMap}
            ?infopane-prominent-flipper=${e=>e.infoPaneProminentFlipper}
            ?infopane-narrow-flipper=${e=>e.infoPaneNarrowFlipper}
            ?infopane-light-flipper=${e=>e.infoPaneLightFlipper}
            :infoPaneFlipperStyle=${e=>e.infoPaneFlipperStyle}
            @mouseenter=${(e,t)=>t.event&&tw.onMouseEnter(t.event.target,e.slideContentData&&e.slideContentData[0]&&e.slideContentData[0].enableHover)}
            @mouseleave=${(e,t)=>t.event&&tw.onMouseLeave(t.event.target,e.slideContentData&&e.slideContentData[0]&&e.slideContentData[0].enableHover)}
        >
            ${(0,p.ux)(e=>e.slideContentData,e8)}
            ${(0,p.ux)(e=>e.slideContentData,(0,d.qy)`${e=>tv(e)}`,{positioning:!0})}
        </msn-info-pane>
    </fluent-design-system-provider>
</fluent-card>
`,ty=e=>e.cardSize===k.u._2x_2y||e.cardSize===k.u._2x_3y?" --heading-font-size: 20px; --heading-line-height: 28px;":"",tv=e=>{let t=(e.cardActionStatus&K.J.hide)!=0||!!e.enableHideStoryFeedback&&((e.cardActionStatus&K.J.showFewer)!=0||(e.cardActionStatus&K.J.hidden)!=0);if("top-stories-card"===e.childTemplateType)return th;if("article-fre-card"===e.childTemplateType)return tb;if("dense-card"===e.childTemplateType)return tu;if(e.isNativeAd)return tl;if(e.showAdFeedback)return e.cardActionStatus&K.J.hidden?tc:e.cardActionStatus&K.J.adFeedbackSubmitted?tg:tp;if("tabbed-infopane-card"===e.childTemplateType)return tm;if(t)if(!e.enableHideStoryFeedback||e.cardSize===k.u._2x_3y)return ts;else return e.cardActionStatus&K.J.hidden?tc:td;else if(e.useArticleCardTemplate&&e.cardSize!==k.u._2x_3y)return e.isAnaheimDesign?e7:e9;else return te},tC=e=>{let t=[];return e.isNarrowTitleFooterGap&&t.push("narrowTitleGap"),e.hasAnyInlineDecoration&&t.push("hasInlineDecoration"),e.videoProps&&t.push("nativeAdVideo-infopane"),t.join(" ")},tx=(e,t)=>{e.template&&e.template.progressiveDisplay&&e.hoverState&&e.hoverState.isHovered!==t&&(e.hoverState.isHovered=t)},tw=new $.w,tk=e=>{let t="";return e.enableDenseSlide&&(t+="dense-slide"),e.enableAdaptDarkMode&&(t+=" adapt-dark-mode"),[e5.o.LightStyle2,e5.o.LightDefault,e5.o.LightNarrow,e5.o.LightLarge,e5.o.LightWide].includes(e.infoPaneFlipperStyle)&&(t+=" light"),t},t$=(e,t,a)=>{let{enableNativeAdCTALearnMoreInfopane:i,enableNativeAdCTAOpenInfopane:n,templateType:r}=e||{};return["msn-call-to-action-v3","msn-call-to-action-v3-pa"].includes(r)?tt:i&&a?.length===1?ta(t?.nativeAdLearnMoreText):n&&a?.length===1?ta(t?.nativeAdOpenText):h.y}},52600(e,t,a){"use strict";a.d(t,{j:()=>c});var i,n,r=a(65455),o=a(98794);(i=n||(n={})).full="full",i.half="half",i.tall="tall";var l=a(87906),s=a(40450),d=a(69828);let c={getFeedDataForCard:e=>(function(e){let t,{configOptions:a,parentTelemetryObject:i,cardMetadata:r,openLinksInNewTab:c,refreshSDCardSection:p,goToPersonalizeSettingsCallback:g,flattenedRightRail:u,sdCardActionClickHandler:m,supportedSdCardActionMenuItems:h,dismissSDCardMenuCallback:b,refreshFeedCallback:f,visualReadinessCallback:y,hasLoadedCallback:v,activeBoard:C,isWidgetRegion:x,onSDCardClick:w,turnOffWidgetsRegionCallback:k,manageWidgetsRegionCallback:$}=e;if(!r?.data)return null;let S=a&&a;try{t=JSON.parse(r.data)}catch(e){return(0,l.vV)(s.V8E,"exception while parsing feed money card data from data mapper"),null}let T=`moneyInfoCard_${r.type}`,_=`${r.type}${C?`_${C}`:""}${r.metadata?.isSpotlightUX?"_spotlight":""}`,I={cardFeedDataJson:t,childTemplateType:"money-info-card",cardLayout:n.full,goToPersonalizeSettingsCallback:g,id:T,moneyCardConfigInfo:S,noGradient:u,openLinksInNewTab:c,parentTelemetryObject:i,refreshSDCardSection:p,refreshFeedCallback:f,visualReadinessCallback:y,sdCardActionClickHandler:m,supportedSdCardActionMenuItems:h,dismissSDCardMenuCallback:b,cardType:_,experienceName:`${_}${r.id?`_${r.id}`:""}`,isSpotlightUX:r.metadata&&r.metadata.isSpotlightUX,previewType:r.metadata&&r.metadata.previewType,feedData:r.data,cardId:r.cardId,hasLoadedCallback:v,isWidgetRegion:x,onSDCardClick:w,turnOffWidgetsRegionCallback:k,manageWidgetsRegionCallback:$};return I.isWidgetRegion&&(I.cardSize="_1x_1y"),(0,o.bw)({id:T,experienceType:S?.configRef?.experienceType,mapperArgs:e},I,(e,t)=>{let a=t.cardSize,i=n.full;return a===d.u._1x_1y?i=n.half:a===d.u._1x_3y&&(i=n.tall),{cardLayout:i,sdCardActionClickHandler:m,supportedSdCardActionMenuItems:h}},!0)})(e),viewTemplate:r.P}},65455(e,t,a){"use strict";var i=a(69828),n=a(91748),r=a(89757),o=a(94172),l=a(33744);let s=(0,r.qy)`
<fluent-card
        style="grid-area:${e=>e.gridArea};contain:unset;content-visibility:visible"
        class="${e=>e.cardLayout}">
    <fluent-design-system-provider style="padding: 0; height: 100%; margin: 0;">
        ${e=>e.moneyCardConfigInfo&&(0,o.yN)(e.moneyCardConfigInfo,{properties:{cardLayout:e.cardLayout,openLinksInNewTab:e.openLinksInNewTab,noGradient:e.noGradient,supportedSdCardActionMenuItems:e.supportedSdCardActionMenuItems,wpoMetadata:e.wpoMetadata,parentTelemetry:e.parentTelemetryObject,refreshSDCardSection:e.refreshSDCardSection,visualReadinessCallback:e.visualReadinessCallback,sdCardActionClickHandler:e.sdCardActionClickHandler,dismissActionMenu:e.dismissSDCardMenuCallback,cardSize:e.cardSize,cardType:e.cardType,cardFeedDataJson:e.cardFeedDataJson},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible`},events:{goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback},memoize:"windowsShellV2"!==l.T3.AppType})}
    </fluent-design-system-provider>
</fluent-card>`,d=(0,r.qy)`${e=>e.moneyCardConfigInfo&&(0,o.yN)(e.moneyCardConfigInfo,{properties:{cardSize:e.cardSize===n.Go._1u?i.u._1x_2y:e.cardSize,shellV2PreviewType:"windowsShellV2"===l.T3.AppType?e.previewType:"",feedData:e.feedData,cardType:e.cardType,experienceName:e.experienceName,wpoMetadata:e.wpoMetadata,isSpotlight:e.isSpotlightUX,cardId:e.cardId,parentTelemetryObject:e.parentTelemetryObject,refreshSDCardSection:e.refreshSDCardSection,refreshFeedCallback:e.refreshFeedCallback,visualReadinessCallback:e.visualReadinessCallback,dismissActionMenu:e.dismissSDCardMenuCallback,sdCardActionClickHandler:e.sdCardActionClickHandler,supportedSdCardActionMenuItems:e.supportedSdCardActionMenuItems,hasLoadedCallback:e.hasLoadedCallback,isWidgetRegion:e.isWidgetRegion,onSDCardClick:e.onSDCardClick,turnOffWidgetsRegionCallback:e.turnOffWidgetsRegionCallback,manageWidgetsRegionCallback:e.manageWidgetsRegionCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible`,initialPreviewType:e.previewType},events:{goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback},memoize:"windowsShellV2"!==l.T3.AppType})}`,c=(0,r.qy)`
    ${e=>e.moneyCardConfigInfo.configRef?.experienceType==="MoneyInfo"?d:s}
`;a.d(t,{},{P:c})},33485(e,t,a){"use strict";var i=a(71733),n=a(1792);let r={getFeedDataForCard:e=>(0,n.M8)(e),viewTemplate:i.DO};a.d(t,{},{$:r})},18176(e,t,a){"use strict";a.d(t,{M:()=>r});var i=a(90466),n=a(98794);let r={getFeedDataForCard:e=>(function(e){let{cardMetadata:t}=e,{id:a}=t;return(0,n.bw)({id:a,experienceType:null,mapperArgs:e},{id:a,childTemplateType:"placeholder-card"})})(e),viewTemplate:i.u}},90466(e,t,a){"use strict";var i=a(89757);let n=(0,i.qy)`
    <fluent-card 
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        <div class="placeholder-card" style="height: 100%;" />
    </fluent-card>
`;a.d(t,{},{u:n})},34900(e,t,a){"use strict";a.d(t,{N:()=>r});var i=a(26144),n=a(98794);let r={getFeedDataForCard:e=>(function(e){let{configOptions:t,parentTelemetryObject:a,cardMetadata:i,pollsCardConfigInfo:r,goToPersonalizeSettingsCallback:o,refreshSDCardSection:l}=e,s=r||t&&t,d={id:"pollsCard",childTemplateType:"polls-card",parentTelemetryObject:a,pollsCardConfigInfo:s,fetchedData:i.data,goToPersonalizeSettingsCallback:o,refreshSDCardSection:l};return(0,n.bw)({id:"pollsCard",experienceType:s?.configRef?.experienceType,mapperArgs:e},d)})(e),viewTemplate:i.d}},26144(e,t,a){"use strict";var i=a(89757),n=a(94172);let r=(0,i.qy)`
    <fluent-card
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        ${e=>(0,n.yN)(e.pollsCardConfigInfo,{properties:{fetchedData:e.fetchedData,telemetryExt:e.telemetryExt,goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback,refreshSDCardSection:e.refreshSDCardSection},telemetryObject:e.telemetryObject})}
    </fluent-card>
`;(0,i.qy)`
    <cs-card
        style="grid-area:${e=>e.gridArea}; border-radius: 8px;"
        class="${e=>e.cardSize}"
        size="${e=>e.cardSize}"
    >
    ${e=>(0,n.yN)(e.pollsCardConfigInfo,{properties:{fetchedData:e.fetchedData,telemetryExt:e.telemetryExt,goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback,refreshSDCardSection:e.refreshSDCardSection,cardSize:e.cardSize},telemetryObject:e.telemetryObject})}
    </cs-card>
`,a.d(t,{},{d:r})},23897(e,t,a){"use strict";var i=a(89757),n=a(60402),r=a(69259),o=a(33744),l=a(2375),s=a(44978),d=a(2188),c=a(4670);let p={_1x_2y:"1u",_2x_2y:"_2x_2y",_1x_1y:"0.5u"},g=(0,i.qy)`
    <span slot="action-row-start">
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,l.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :url=${e=>e.feedbackUrl}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>o.T3.CurrentMarket||e.locale}
            :theme=${"ads"}
            :rootTelemetryObject=${e=>e.adTelemetryContext?.nativeAdCard}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>()=>e.openAdReportDialog(e)}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
    </span>
`,u=(0,i.qy)`
<cs-responsive-card
    ad=true
    ${(0,d.Ib)(!1,!0)}
    ?ad-va="${e=>e.adVA}"
    ?ad-va2="${e=>e.adVA2}"
    ?ruby-va="${e=>e.enableRubyVerticalAds&&e.adVA2}"
    ?ad-pa="${e=>e.template?.adPA}"
    ?enable-ad-social-bar="${e=>e.enableAdSocialBar}"
    :adAttributes=${e=>e.adAttributes}
    :abstract=${e=>e.abstract}
    ad-dts-style-key="${e=>e.adDTSStyleKey}"
    :adDTSTemplateConfig=${e=>e.adDTSTemplateConfig}
    :adDTSComponentDataMap=${e=>e.adDTSComponentDataMap}
    ?use-ad-dts-layout-renderer=${e=>e.useAdDTSLayoutRenderer}
    :attributionData=${e=>e.attributionData}
    :adSelectionCriteria=${e=>e.adSelectionCriteria}
    :badgeProps="${e=>e.badgeProps}"
    :callToAction="${e=>e.callToAction}"
    :data="${e=>e}"
    data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
    :heading="${e=>e.title}"
    ?hide-card-actions="${e=>e.hideCardActions||!e.feedbackUrl}"
    :href="${e=>e.destinationUrl}"
    :href_adButton="${e=>(0,c.lW)(e)}"
    :href_adChoiceButton="${e=>e.adChoiceIconUrl}"
    id="${e=>e.id}"
    ?dense-zoned="${e=>!!e.denseZoned||void 0}"
    ?zoned-layout="${e=>!!e.zonedLayout||void 0}"
    ?immersive="${e=>("_2x_2y"==e.cardSize||"_1x_2y"==e.cardSize&&!!e.immersiveCard)&&!e.isIntraNativeAd&&!e.__sidebarAd||void 0}"
    :intraArticle=${e=>e.isIntraNativeAd&&!e.disableRespIntraAdStyles}
    :isIntraFeedAd=${e=>e.isIntraNativeAd}
    :isIntraClassicAd="${e=>e.isIntraClassicAd}"
    ?sidebar-ad="${e=>!!e.__sidebarAd||void 0}"
    :mediaData=${e=>e.mediaData}
    media-type="${e=>e.imageData?.source?"image":""}"
    @mouseenter="${(e,t)=>e.mouseEnterCallback(t.event.currentTarget)}"
    @mouseleave="${(e,t)=>e.mouseLeaveCallback(t.event.currentTarget)}"
    :onClickLink="${e=>e.onClickLink}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide^s.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :popoverData="${e=>e.popoverData}"
    size="${e=>"_2x_2y"!=e.cardSize||!e.immersiveCard||e.isInfopane||e.__sidebarAd?p[e.cardSize]||e.cardSize:"2c"}"
    style="grid-area:${e=>e.gridArea};"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>e.adTelemetryContext?.nativeAdCard}"
    :telemetryTag_adButton="${e=>(0,c.j1)(e.adTelemetryContext)}"
    :telemetryTag_adChoiceButton="${e=>e.adTelemetryContext?.adChoice?.getMetadataTag()}"
    :telemetryTag_anchor="${e=>e.adTelemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_moreActions="${e=>e.adTelemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_adDisclaimerButton="${e=>e.adTelemetryContext?.adDisclaimer?.getMetadataTag()}"
    :telemetryTag_callToAction="${e=>e.adTelemetryContext?.callToAction?.getMetadataTag()}"
    :telemetryTag_undoHide="${e=>e.adTelemetryContext?.cancelButton?.getMetadataTag()}"
    title="${e=>e.title}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize&&!e.__sidebarAd||void 0}"
    ?ruby="${e=>e.ruby}"
    ?homepage-rubify-default-height="${e=>e.homepageRubifyDefaultHeight}"
    ?loading="${e=>e.loading}"
    ${(0,n.K)("cardElement")}
>
    ${(0,r.z)(e=>e.enableAdSocialBar&&e.feedbackUrl,g)}
</cs-responsive-card>`;a.d(t,{},{W:u})},88466(e,t,a){"use strict";var i=a(32460),n=a(51907);let r={getFeedDataForCard:e=>(0,n.y5)(e),viewTemplate:i.t};a.d(t,{},{v:r})},51907(e,t,a){"use strict";a.d(t,{y5:()=>E,As:()=>P,uh:()=>B});var i=a(44978),n=a(98794),r=a(69828),o=a(10071),l=a(35667),s=a(46659),d=a(11803),c=a(86010),p=a(56216),g=a(80119),u=a(82368),m=a(77833),h=a(87906),b=a(40450),f=a(98378),y=a(7446),v=a(94108),C=a(33744),x=a(60763),w=a(45519),k=a(19110),$=a(72287),S=a(72746),T=a(52323),_=a(72106),I=a(54694),A=a(72627),D=a(44916),z=a(12673),F=a(50180),R=a(59010);let L=["ocid","pc","cvid","ei","copilot_traceid"];function M(e,t,a){try{let i=new URL(e);return i.searchParams.set(t,a),i.toString()}catch(t){return e}}function E(e){let{cardMetadata:t,configOptions:a,immersiveCard:i,visualReadinessCallback:l,ruby:s,overrideTelemetryExtArgs:d}=e,c=t.type,{childExperienceReferencesWC:p={},childExperienceReferences:g={}}=a,u=B(e,{socialBarWCConfigInfo:p.socialBarWC||g.socialBarWC,videoCardConfigInfo:p.videoCardWC},l),{id:h,metadata:b,telemetryContext:y}=u,v=b?!b.reactionSummary:u&&!u.reactionSummary;o.R.setContentIdCandidateIfNeeded(h,c,v);let C=a&&a,x=t&&t.ri||b&&b.ri,w=t&&t.recoId||b&&b.recoId;return e.configOptions.preloadImages&&(0,$.NN)(u.attributionData?.src),(0,n.bw)({id:h,experienceType:C?.configRef?.experienceType,mapperArgs:e,recoId:w,ri:x},u,(n,o)=>{var d;let c,p=o.cardSize;(u.usePortraitImage||u.useSquareImage)&&u.usePortraitImage;let g=O(u,p,l,i,{segment_1_1:!!e.cardMetadata.feedMetadata?.segment},a),h=r.u._1u;switch(p){case"_1x_1y":h=r.u._05u;break;case"_1x_2y":h=r.u._1u;break;case"_2x_2y":h=s?"2c":r.u._2c;break;default:h=p||r.u._1u}"shorts"===t.size&&(h="shorts"),a.useInfopaneSlideTemplate&&(h=r.u._1u);let b=g?(c=(d=u).contentType)===m.pL.WebContent&&d.metadata?.videoMetadata||c===m.pL.Video?"video":"image":void 0;e.configOptions.preloadImages&&(0,$.NN)(g?.src);let v=o.telemetryExt;a.logThumbnailUrl&&(v.tmb=g?.src),p!==r.u._05u&&(v.height=a.isWaterfallFeed&&a.enableDynamicWaterfall?void 0:304);let C={...y};return C&&C.contentCard&&(C.destination&&(C.destination=C.contentCard.addOrUpdateChild({...C.destination.contract,type:f.MJ.Headline,ext:v,action:f.EG.Click})),C.contentCard=new T.$({...C.contentCard.contract,ext:v})),{visualReadinessCallback:l,mediaData:g,mediaType:b,telemetryContext:C,responsiveCardSize:h,zonedCarouselCard:!!t.zonedCarouselCard,zonedMegaCard:!!t.zonedMegaCard,hideComments:!!(a.hideCommentsInHalfUCards&&h===r.u._05u)}},!0,d)}function B(e,t,a,n=!1,r){var o;let s,d,{cardActionBitMask:p,cardActionClickHandler:g,cardMetadata:_,cardSlot:I,configOptions:E={},enableRichSocialReaction:H,shareActionHandler:q,initCardAction:W,isNarrowTitleFooterGap:K,isPublisherPage:U,cardActionMenuClickCallback:V,getReplacementCardsCallback:j,goToPersonalizeSettingsCallback:G,heightReadyCallback:X,hideCardCallback:J,reactionCallback:Z,refreshFeedCallback:Y,visualReadinessCallback:Q,localizedStrings:ee,mouseenterHandler:et,mouseleaveHandler:ea,openLinksInNewTab:ei,parentTelemetryObject:en,getSpotlightMenuItems:er,supportedSdCardActionMenuItems:eo,sdCardActionClickHandler:el,isSpotlightZone:es,userSubscriptionData:ed,displaySettings:ec,preventDefaultClick:ep,actionMenuLocalizedStrings:eg,feedbackHandler:eu,shareHandler:em,immersiveCard:eh,feedName:eb,notificationMetadata:ef,openLinksInCurrentTab:ey,renderContentIndicator:ev,ruby:eC,underlineTitle:ex,waterfallCardSlot:ew}=e,{availableActions:ek,enableEverGreenWebContent:e$=!1,enableNewTimestampFormatForJAJP:eS,enableHideStoryFeedback:eT,openPersonalizeWithoutRouter:e_,telemetryConstants:eI={},enabledBadgeTypes:eA,enabledReasonBadgeTypes:eD,disableCardTitleTooltip:ez,enableTitleForTruncate:eF,disablePublishTime:eR,useStatSocialTemplate:eL,enableRubyBottomSocialBar:eM,enableHoverFollowButton:eE}=E,{socialBarWCConfigInfo:eB,videoCardConfigInfo:eP}=t,eO=(0,$.cZ)(_),eN=eO.metadata?.reasons&&E.childExperienceReferencesWC.publisherFollowButton,{cardContent:eH,dynamicCardSize:eq,metadata:eW,isFirstSectionCard:eK,type:eU}=eO,{grid_area:eV}=I,{abstract:ej,id:eG,destinationUrl:eX,locale:eJ,title:eZ,publishedDateTime:eY,provider:eQ,defaultAnchorTarget:e0,videoFiles:e1,isWorkNewsContent:e2,badges:e6}=eH,e3=eU===m.pL.WebContent,e4=(0,$.H8)(eO,p),e5="following"===eb?void 0:eO?.metadata?.reasons,{badge:e8,reasonBadge:e7}=(0,k.bA)(ee,e6,eA,e5,eD),e9=(0,$.nN)(ee,E,e7);eX||(0,h.vV)(b.Okb,"Missing destinationUrl for content card","Article ID: "+eG);let te=_.recoReasonTag??eW.recoReasonTag;_&&_.recoId&&eW&&(eW.recoId=_.recoId);let tt=(0,l.dj)(en,eH,eW,void 0,e3,{...l.ZZ,...eI});tt&&tt.hide&&tt.hide.contract&&(tt.showFewer=new T.$({...tt.hide.contract,name:"showFewer",action:f.EG.Click,behavior:f.MS.Dislike,type:f.MJ.ActionButton,content:{...tt?.hide.contract?.content}}),tt.hide.contract.ext={recoReasonTag:te});let ta=(e4&i.J.hide)!=0||eT&&((e4&i.J.showFewer)!=0||(e4&i.J.hidden)!=0),ti=eW?.videoMetadata||_?.videoMetadata,tn=e3&&!!ti,tr=eU===m.pL.Video,to=_?.size==="shorts",tl=eW?!eW.reactionSummary:eO&&!eO.reactionSummary,ts=null,{disable1MonPlusTimestamp:td,disableNDaysPlusTimestamp:tc}=S.ew.getConfig()||{},tp=(0,D.YS)(eY),tg=(0,D.Tp)(eY,tc);td&&tp||tg||(ts=(0,S._L)(eY,eJ,void 0,eS,!0)),ts=e3&&e$&&(0,$.xk)(eY)?null:ts,(0,$.Be)(eY,E);let tu=""!==v.Rb.MarketDir?v.Rb.MarketDir:"ltr";te&&te.tag&&y.YT.addOrUpdateTmplProperty("recoReasonTag","1");let tm=_?.containerType===m.pL.TrendingNowCarousel||_?.containerType===m.pL.NewsTrendingNow,th=(0,$.p_)(eQ,e3,void 0,tn),tb={altText:th&&th.name,name:th&&th.name,publishedDateTime:eR||tm?null:ts,viewCount:tm?(o=_,(0,w.ZV)(o?.metadata?.consumptionSummary?.totalViews)):null,src:th&&th.logoImage,useFollowingButton:!0,providerChannelURL:th&&P(th)},tf="";switch(e7?.type.toLowerCase()){case"trending":tf=`${C.T3.StaticsUrl}latest/icons-wc/icons/TrendingLight.svg`;break;case"local":tf=`${C.T3.StaticsUrl}latest/icons-wc/icons/LocationPin.svg`;break;case"followtopic":case"followpublisher":tf=`${C.T3.StaticsUrl}latest/icons-wc/icons/CircleCompleted.svg`}e8?s={isNonInteractive:!0,iconSrc:"",onClickBadge(){},telemetryTag_badge:"",text:e8?.localizedLabel||""}:e7?.type&&(s={iconSrc:tf,onClickBadge:(e,t)=>N(e,t,g,W,null,!eT,Y,e_,tl,c.hs.WhyAmISee),telemetryTag_badge:tt?.whyAmISee?.getMetadataTag(),text:e7?.localizedLabel||""});let ty=!!eO.feedMetadata?.segment;n&&(d=O(eO,a,r,eh,{segment_1_1:ty},E));let tv=eX;tn&&(tv=(0,z.C)(encodeURIComponent(eG),tv)),(0,x.vM)()&&(tv=function(e,t){let a=new R.m((0,A.iA)()),i="?";if(e.indexOf("?")>-1){let t=new R.m(e).getAllSearchParams();for(let e in t)a.delete(e);i=Object.keys(t).length>0?"&":"?"}return(t&&L.forEach(e=>{a.delete(e)}),0===Object.keys(a.getAllSearchParams()).length)?e:e+i+a.toString()}(tv,!0)),to&&(tv=M(tv,"category","shorts")),(0,$.FU)(eW)&&(tv=M(tv,"cgfrom","cg_ruby_ntp_carousel_item"));let tC=ta?(0,u.Eb)(e,e4,eG,en):{id:eG,dir:tu,isWorkNewsContent:e2,gridArea:eV,telemetryContext:tt,defaultAnchorTarget:e0,abstract:ej,cardContent:eH,cardActionStatus:e4,cardActionClickHandler:g,cardActionsTooltips:e9,externalVideoFiles:tr?e1:void 0,videoMetadata:tr?ti:void 0,title:eZ,titlePrefix:eO.isFeatured&&ee.topStoriesBreakingNewsTagString,contentType:eU,sdCardActionClickHandler:el,imagePriority:!1,isWebContent:e3,isFirstSectionCard:eK,metadata:eW||eO,openLinksInNewTab:ei,enableRichSocialReaction:H,optedOutOfReactions:tl,userSubscriptionData:ed,isPublisherPage:U,locale:eJ,immersiveCard:to||eh,isNarrowTitleFooterGap:K,mouseenterHandler:et,mouseleaveHandler:ea,actionsArrayOverride:e3&&ek||void 0,displaySettings:ec,actionMenuLocalizedStrings:eg,cardActionMenuClickCallback:V,getReplacementCardsCallback:j,goToPersonalizeSettingsCallback:G,heightReadyCallback:X,hideCardCallback:J,preventDefaultClick:ep,reactionCallback:Z,refreshFeedCallback:Y,visualReadinessCallback:r??Q,shareActionHandler:q,feedbackHandler:eu,shareHandler:em,destinationUrl:tv,wpoMetadata:eW?.wpoMetadata||eO?.wpoMetadata,wpoRank:eW?.wpoRank||eO?.wpoRank,cardId:eW?.cardId||eO?.cardId,type:eW?.type||eO?.type,subType:eW?.subType||eO?.subType,childTemplateType:"responsive-card",attributionData:tb,providerData:(0,$.p_)(eQ,e3),toggleCardActionMenu:(e,t,a,i,n)=>N(e,t,g,W,null,!eT,Y,e_,tl,a,void 0,i,n,eM,eE),mediaData:d,socialBarWCConfigInfo:eB,videoCardConfigInfo:eP,badgeProps:s,publisherFollowButtonConfigInfo:eN&&{...eN,instanceId:`${eN.instanceId}-${eG}`},enableCardHideStoryIcon:E&&E.enableCardHideStoryIcon,badge:e8,reasonBadge:e7,slides:_?.slides||eW?.slides,disableCardTitleTooltip:ez,enableTitleForTruncate:eF,openLinksInCurrentTab:ey,renderContentIndicator:ev,useStatSocialTemplate:eL,order:ew?.order??0};if(ef?.spotlightPreviewTypes?.length&&eW?.isSpotlightUX){let{additionalLabelText:e,followedEntity:t,followedType:a,spotlightCardTitle:i}=ef;if(tC.childTemplateType="article-breaking-news-card",tC.cardTitle=i,tC.additionalLabelText=e,tC.followedType=a,tC.followedEntity=t,tC.getSpotlightMenuItems=er,tC.supportedSdCardActionMenuItems=eo,tC.isSpotlightZone=es,tC.recoId=_&&_.recoId||eW&&eW.recoId,ee){let{bingVideoNoPreviewStr:e,bingVideoPreviewStr:a,disableNotification:i,followingText:n,followConfirmationText:r}=ee;tC.followButtonTitle=n,tC.followingButtonHoverTip=r&&(0,F.GP)(r,t),tC.disableNotificationText=i,tC.videoNoPreviewLabel=e,tC.videoPreviewLabel=a}}if(tC.ruby=eC,tC.underlineTitle=ex,tC.segment=!!eO.feedMetadata?.segment,eC&&eM){let{reactionSummary:e,commentSummary:t,commentStatus:a}=eW;tC.rubySocialBarData=(0,$.Qw)(e,t,a)}return eC&&(0,$.FU)(eW)&&(tC.hideLikeButton=!0),tC}function P(e){let t=e?.name??"page",a=e?.profileId??"";return(0,_.Hg)(a,t,"source")}function O(e,t,a,i,n,o){if(!t)return;let l=!1,c=p.n._268x140;(t===r.u._05u||t===r.u._1x_1y)&&(c=o.enableHomePageStyle?i?p.n._306x256:p.n._104x84:p.n._90x90),t===r.u._075u&&(c=p.n._268x94),t===r.u._2x_2y&&(c=o?.enableHomePageStyle?p.n._628x372:p.n._612x304),t===r.u._1x_2y&&(c=i?p.n._300x304:s.L._300x156),o.kumoStyle&&(c=(0,g.F)(t,i)||{width:260,height:136},n.segment_1_1&&(c={width:260,height:260}));let u=()=>a(3,d.j.image);return function(e,t,a,i,n){let r=(0,$.Ie)(e);if(!r)return null;let o=(0,I.oQ)(r?.url,{width:t.width,height:t.height,focalRegion:r.focalRegion,enableDpiScaling:!0,devicePixelRatio:(0,A.mZ)(),enableWebpFormat:n});return{altText:e.cardContent?.title,loadCallback:a,errorCallback:i,src:o}}(e,c,u,(e,t)=>{l||(l=!0,(0,h.vV)(b.qog,"Error fetching source","Source: "+e+", Article ID: "+t),u())},o.enableWebpFormat)}function N(e,t,a,n,r=!1,o=!1,l,s,d,p,g,u,m,h,b){let f=t,y=e;t.detail&&t.detail.event&&t.detail.data&&(f=t.detail.event,y=this.getListCardMetadata(t.detail.data),r=!0),(y.isLauncher||y.isThirdParty)&&y.useMobile&&(f.preventDefault(),f.stopPropagation());let{cardSize:v,id:C,title:x,destinationUrl:w,mediaData:k,providerData:S,cardActionStatus:T,telemetryContext:{seeMore:_},actionsArrayOverride:I,metadata:A,isLauncher:D,isThirdParty:z,shareHandler:F,feedbackHandler:R,panoCaption:L,isShoppingArticleCard:M,locale:E,ruby:B}=y,P=g?.overrideReasonsDisplay?[{type:c.QK.trending,rank:0},{type:c.QK.u2u,rank:1}]:A.reasons,O={cardSize:v,enabled:!0,buttonElement:f.currentTarget,fromRightClick:m,article:{id:C,headlineTitle:x,href:w,locale:E,image:{alt:k&&k.altText,src:k&&k.src},provider:{id:S.id,profileId:S.profileId,name:S.name,image:{alt:S.name,src:S.logoImage}},abstract:A.abstract,reasons:P,source:A.source},parentTelemetryObject:_,onStatusChange:a,cardStatus:T,updateFeedOnHide:r,disableHoverSquare:!0,showToast:o,refreshFeedCallback:l,openPersonalizeWithoutRouter:s,actionsArrayOverride:I,isReactionsOptedOut:d,isLauncher:D,isThirdParty:z,shareHandler:F,feedbackHandler:R,debugId:A.debugId,dialogToOpen:p,interactCard:u,useCommunityReactionsForShowMoreLess:B,showAiDisclaimerAttribution:A?.displayAttributes?.showTitleDisclaimer};if(L||M)O.actionsArrayOverride=[i.X.ManageInterests,i.X.Divider,i.X.Report];else if(B&&(0,$.FU)(A))O.actionsArrayOverride=[i.X.WhyAmISee,i.X.Report];else if(B&&(b||h)){let e=[i.X.ShowFewer];b?e.push(i.X.ManageInterests):e.push(i.X.FollowPublisher),e.push(i.X.Mute,i.X.Save,i.X.Divider,i.X.WhyAmISee,i.X.Report),O.actionsArrayOverride=e}m?window.dispatchEvent(new CustomEvent("contentCardRightClick",{detail:{actionState:O,event:f,initCardAction:n}})):n(O)}},32460(e,t,a){"use strict";var i=a(69828),n=a(44776),r=a(89757),o=a(69259),l=a(60402),s=a(44978),d=a(33744),c=a(2375),p=a(94172);let g=(0,r.qy)`
    ${e=>(0,p.yN)(e.publisherFollowButtonConfigInfo,{attributes:{slot:"following-button"},properties:{contentId:e.id,publisherName:e.providerData.name,publisherProfileId:e.providerData.profileId,profileId:e.providerData.id,getReplacementCardsCallback:e.getReplacementCardsCallback,enableFollowToast:!0,cardActionStatus:e.cardActionStatus,usingResponsiveCard:!0}})}
`,u=(0,r.qy)`
    <span slot="action-row-start">
    ${(0,o.z)(e=>e.useStatSocialTemplate,(0,r.qy)`
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,c.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :hideComments=${e=>e.hideComments||!1}
            :canShowOneLineComments=${e=>!e.isInfopane&&e.cardSize===i.u._2x_2y}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>d.T3.CurrentMarket||e.locale}
            :theme=${e=>e.socialBarTheme||"default"}
            :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>e.cardActionClickHandler&&((...t)=>e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide,...t))}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
        `,(0,r.qy)`${e=>(0,n.nj)({theme:e.socialBarTheme,hideComments:e.hideComments})}`)}
    </span>
`,m=(0,r.qy)`
<cs-responsive-card
    :abstract=${e=>e.abstract}
    :attributionData=${e=>e.attributionData}
    :badgeProps="${e=>e.badgeProps}"
    :overlayBadgeProps="${e=>e.overlayBadgeProps}"
    :contentIndicator="${e=>e.renderContentIndicator}"
    :data="${e=>e}"
    :heightReadyCallback="${e=>e.heightReadyCallback}"
    :heading="${e=>e.title}"
    :href="${e=>e.destinationUrl}"
    id="${e=>e.id}"
    ?immersive="${e=>"_2x_2y"==e.cardSize||("_1x_2y"==e.cardSize||"_1x_1y"==e.cardSize||"shorts"===e.responsiveCardSize)&&!!e.immersiveCard||void 0}"
    :mediaData=${e=>e.mediaData}    
    media-type="${e=>e.mediaType}"
    :preventDefaultClick="${e=>e.preventDefaultClick}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide^s.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :onClickLink=${(e,t)=>e.onClickLink}
    :onClickCompanionButton=${(e,t)=>e.onClickCompanionButton}
    size="${e=>e.responsiveCardSize}"
    style="${e=>{let t;return e.ruby?void 0:(t=`grid-area:${e.gridArea};`,e.predictedHeight?`${t} --placeholder-intrinsic-height: ${e.predictedHeight-32}px;`:t)}}"
    :rubySocialBarData="${e=>e.rubySocialBarData}"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>e.telemetryContext?.contentCard}"
    :telemetryTag_anchor="${e=>e.telemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_hideCard="${e=>e.telemetryContext?.showFewer?.getMetadataTag()}"
    :telemetryTag_undoHide="${e=>e.telemetryContext?.undoShowFewer?.getMetadataTag()}"
    :telemetryTag_moreActions="${e=>e.telemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_showMore="${e=>e.telemetryContext?.upvote?.getMetadataTag()}"
    :telemetryTag_undoShowMore="${e=>e.telemetryContext?.undoUpvote?.getMetadataTag()}"
    :telemetryTag_companion="${e=>e.telemetryContext?.companion?.getMetadataTag()}"
    :telemetryObject_commentButton="${e=>e.telemetryContext?.commentsButton}"
    title="${e=>e.title}"
    ?underline-title="${e=>e.underlineTitle}"
    :headingPrefix="${e=>e.titlePrefix}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize||void 0}"
    ?ruby="${e=>e.ruby}"
    ?zoned-carousel="${e=>e.zonedCarouselCard}"
    ?zoned-mega="${e=>e.zonedMegaCard}"
    ?homepage-rubify-default-height="${e=>e.homepageRubifyDefaultHeight}"
    ?segment="${e=>e.segment}"
    ?companion="${e=>e.companion}"
    :companionButtonText="${e=>e.companionButtonText}"
    ${(0,l.K)("cardElement")}
>
    ${(0,o.z)(e=>e.publisherFollowButtonConfigInfo,g)}
    ${(0,o.z)(e=>e.enableRichSocialReaction,u)}
</cs-responsive-card>
`;a.d(t,{},{t:m})},41291(e,t,a){"use strict";a.d(t,{V:()=>S});var i=a(69828),n=a(95402),r=a(77833),o=a(98794),l=a(90948),s=a(51907),d=a(58034),c=a(64859),p=a(52323),g=a(98378),u=a(7446),m=a(25658),h=a(50866),b=a(84289),f=a(91748),y=a(76971),v=a(72287),C=a(33744),x=a(94108),w=a(12867),k=a(85854);let $={[i.u._1x_2y]:n.Sv.infoPane,[i.u._1x_3y]:n.Sv.infoPane1x3y,[i.u._2x_2y]:n.Sv.infoPane,[i.u._2x_3y]:n.Sv.infoPane},S={getFeedDataForCard:e=>(function(e){(0,b.tD)("InfopaneDataMapping.Start",performance.now());let t=[],{cardActionBitMask:a,cardActionClickHandler:n,cardMetadata:S,cardSlot:T,configOptions:_,enableRichSocialReaction:I,enableRotateOnlyOnce:A,preventDefaultClick:D,handleAdFeedbackSubmit:z,hideStoryEntryPointMap:F,isAdFeedbackV1Enabled:R,initCardAction:L,getReplacementCardsCallback:M,localizedStrings:E,notificationMetadata:B,openLinksInNewTab:P,openLinksInCurrentTab:O,parentTelemetryObject:N,reactionCallback:H,visualReadinessCallback:q,underlineTitle:W}=e,{grid_area:K}=T;if(S.subItems&&S.subItems.length?t=S.subItems:(t=S.subCards,S.subItems=t),!t.length)return;let U=(0,c.c)(N),V=_&&_,j=_&&(_.childExperienceReferencesWC&&_.childExperienceReferencesWC.socialBarWC||_.childExperienceReferences&&_.childExperienceReferences.socialBarWC),G=_&&_.childExperienceReferencesWC&&_.childExperienceReferencesWC.publisherFollowButton;if(S.wpoMetadata){let{contentType:e}=S.wpoMetadata;(e===r.pL.TopStories||e===r.pL.TopStoriesV2)&&(t=t.slice(0,6))}let X=!1;_?.enablePauseInfopaneOnSpot&&S.wpoMetadata&&S.wpoMetadata.contentType===r.pL.TopStories&&S.metadata&&!0===S.metadata.isSpotlightUX&&S.metadata.previewType&&S.metadata.previewType.startsWith("News_BreakingNews")&&(X=!0);let J=E?.cardActionsTooltips,Z=!!(_?.enableChevronFlipper||_?.enableRubifyDashboard),Y={id:"infopane",childTemplateType:_.useResponsiveInfopane?"responsive-infopane":"infopane-card",config:_,slideContentData:[],enableRotateOnlyOnce:A,enableAdaptDarkMode:_&&_.enableAdaptDarkMode,infoPaneNextFlipperTitle:E?E.infoPaneNextFlipperTitle:"",infoPanePreviousFlipperTitle:E?E.infoPanePreviousFlipperTitle:"",useTitleFontSize:_&&_.useTitleFontSize,enableImmersiveInfopane:_&&_.enableImmersiveInfopane,infopaneViewOptAdCount:_&&_.infopaneViewOptAdCount,cardActionsTooltips:J,enablePauseInfopaneOnSpot:X,telemetryContext:U,parentContentId:_.parentContentId,underlineTitle:W,flipperCaretIcon:Z?`${(0,C.rA)()?.StaticsUrl}latest/fluent-icons/chevron_left_24_regular.svg`:void 0,enableChevronFlipper:Z};return(0,o.bw)({id:"infopane",experienceType:(_&&_.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e},Y,(c,C)=>{let S,J=[],Z=C.cardSize;t.forEach((t,i)=>{let d,h,b=t.recoId||t.metadata&&t.metadata.recoId,C=t.ri||t.metadata&&t.metadata.ri;S=(0,o.uX)({id:"infopane",columnArrangement:c,experienceType:V?.configRef?.experienceType,mapperArgs:e,recoId:b,ri:C,subCardIndex:i}).telemetryExt,t.segmentMetadata?.signature&&(S.signature=t.segmentMetadata.signature);let w=t.visualReadinessCallback,k=()=>{q&&q(),w&&w()},A=x.Rb?.CurrentFlightSet?.has("prg-ad-iasv2ra"),K=x.Rb?.CurrentFlightSet?.has("prg-ad-iasv3ratt-rf")===!1;if("nativead"===t.type||"cmsad"===t.type||"directbuyad"===t.type)(h=(0,l.tc)({cardActionBitMask:a,cardMetadata:t,cardSlot:T,configOptions:_,cardActionClickHandler:n,handleAdFeedbackSubmit:z,immersiveCard:!0,initCardAction:L,isAdFeedbackV1Enabled:R,localizedStrings:E,enableIASResponsiveAdCardFix:A,enableResponsiveAdAndTrustedTypes:K})).adTelemetryContext=(0,m.u)(t,U&&U.infopane,"infopane",0,S),h.telemetryContext=h.adTelemetryContext,e.configOptions.preloadInfopaneImages&&((0,v.NN)(h.imageData?.source),(0,v.NN)(h.providerData?.logoImage));else if(t.type===r.pL.Dense){if((t?.subItems??t?.subCards).forEach(e=>{if(!e)return;let t=e.recoId||e.metadata&&e.metadata.recoId;t&&(S.recoId=t)}),h=(0,y.gC)(_,t,P,!0,k,!0,N,Z,_.isGreyAdsLabelEnabled,i,S),e.configOptions.preloadInfopaneImages)for(let e of((0,v.NN)(h.denseData.heroNews?.imageData?.source),(0,v.NN)(h.denseData.heroNews?.providerData?.logoImage),h.denseData.newsList||[]))(0,v.NN)(e.providerData?.logoImage)}else h=(0,s.uh)({cardActionBitMask:a,cardActionClickHandler:n,cardMetadata:t,cardSlot:T,configOptions:_,enableRichSocialReaction:I,getReplacementCardsCallback:M,hideStoryEntryPointMap:F,immersiveCard:!0,initCardAction:L,preventDefaultClick:D,localizedStrings:E,notificationMetadata:B,openLinksInNewTab:P,openLinksInCurrentTab:O,parentTelemetryObject:U&&U.infopane,reactionCallback:H,underlineTitle:W},{socialBarWCConfigInfo:j,publisherFollowButtonConfigInfo:G},Z,!0,k),e.configOptions.preloadInfopaneImages&&((0,v.NN)(h.mediaData?.src),(0,v.NN)(h.providerData?.logoImage));if(_&&_.addExtToNewsContainer&&h.telemetryContext&&(h.telemetryContext.destination&&h.telemetryContext.contentCard&&(h.telemetryContext.destination=h.telemetryContext.contentCard.addOrUpdateChild({...h.telemetryContext.destination.contract,type:g.MJ.Headline,ext:S})),h.telemetryContext.contentCard=new p.$({...h.telemetryContext.contentCard?.contract,ext:S})),t.type===r.pL.EventSDCardSportsMIT3&&(h.enableCardHideStoryIcon=!1,"WorldCup"===t.subType||t.metadata?.subType==="WorldCup")){let e=E?.worldCupCoverage||"";e&&(h.overlayBadgeProps={text:e})}let X=t.type===r.pL.EventInfopaneShoppingAI;X&&(h.destinationUrl=((d=new URL(h.destinationUrl)).searchParams.set("entryPoint","msn"),d.searchParams.set("FORM","INFOBG"),d.searchParams.set("msnrid",u.YT.getRequestId()),d.searchParams.set("adunitId","378983"),d.searchParams.set("propertyId","316966"),d.toString())),h={...h,...h.attributionData,cardSize:Z,responsiveCardSize:"_1x_2y"==Z?f.Go._1u:f.Go._2c,enableProviderAlignmentV2:_&&_.enableProviderAlignmentV2,enableAttrOversizing:_&&_.enableAttrOversizing,imageData:{imageWidth:h.mediaData?.width?.toString(),imageHeight:h.mediaData?.height?.toString(),source:h.mediaData?.src,visualReadinessCallback:h.mediaData?.loadCallback},isInfopane:!0,isShoppingArticleCard:X,mediaType:t.type===r.pL.Video?"video":"image",addExtToNewsContainer:_&&_.addExtToNewsContainer,useLightShadow:_&&_.useLightShadow,enableAdSponsoredText:_&&_.enableAdSponsoredText},t.type!==r.pL.TopStories&&(h.cardLayout=$[Z]),J.push(h)});let Y={...U};if(_&&_.addExtToNewsContainer&&S&&Y.infopane){let{row:e,col:t,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:l}=S;Y.infopane=new p.$({...Y.infopane.contract,ext:{row:e,col:t,width:a,height:i,template:n,slot:r,traceIdIndex:o,co:l}})}let Q=_.autoRotateIntervalMs??e.autoRotateIntervalMs,ee=_.autoRotateIntervalMs?void 0:e.autoRotateIntervalMs/1e3,et=_.enableOneCInfopaneNav&&Z===h.qJ._1x_2y,ea=(0,w.a)().get("vpFreeze"),ei=(0,k.d)(J),en={autoRotateIntervalMs:e.autoRotateIntervalMs,firstAutoRotateIntervalMs:e.firstAutoRotateIntervalMs,layout:Z===i.u._2x_2y?d.j.TwoColumn:d.j.OneColumn,gridArea:K,slideContentData:J,enableFlippersOnRest:_.enableInfopaneFlippersOnRest,enableTransparentFlippersOnRest:_.enableTransIfpFlippersOnRest,enableNoMarginFlippers:_.enableNoMarginFlippers,enableSlideShow:!_.disableSlideShow&&!ea,enablePlayPauseButton:!_.disableInfopanePlayPauseButton,disableNavAnimation:_.disableNavAnimation,shiftIpNavToRight:_.shiftIpNavToRight,rotationDuration:Q?Q/1e3:3,enableSingleRotation:A,disableInfopaneComplexAds:_.disableInfopaneComplexAds,enableIpTransform:_.enableIpTransform,enableInfopaneDenseCardInteraction:_.enableInfopaneDenseCardInteraction,restartRotationTimer:_.useResponsiveInfopane&&_.infopaneRestartRotationBuffer>0&&ee?ee+_.infopaneRestartRotationBuffer:_.restartRotationTimer,wpoRotationDuration:_.useResponsiveInfopane?ee:void 0,flipperSize:_.ipFlipperCustomSize??"large",flipperColorInverted:_.invertIpFlipperColor,enablePauseInfopaneOnSpot:X,seeMoreOverride:_.seeMoreOverride,enableLazyInfopane:!!_.enableLazyInfopane,lazyInfopanePreloadCount:_.lazyInfopanePreloadCount,navPosition:_.enableBottomNav&&!et?"bottom":"top",tabCount:_.enableMaxInfopaneSlider&&!et?99:5,telemetryContext:Y,parentContentId:_.parentContentId,infoPaneTabLabels:ei};return(0,b.tD)("InfopaneDataMapping.End",performance.now()),en},!0)})(e),viewTemplate:a(37899).P}},37899(e,t,a){"use strict";var i=a(89757),n=a(69259),r=a(68835),o=a(66591),l=a(32460),s=a(81244),d=a(7446),c=a(98378),p=a(44978),g=a(23897),u=a(33744),m=a(58623),h=a(98728),b=a(89228),f=a(54084),y=a(94172);let v=(0,i.qy)`
    <card-flipper class="previousFlipper" 
        slot="previous-flipper"
        caretIcon="${e=>e.flipperCaretIcon||`${(0,u.rA)()?.StaticsUrl}latest/fluent-icons/caret_left_24_filled.svg`}"
        direction="previous"
        invert-color=${e=>e.flipperColorInverted}
        aria-hidden="${e=>!e.enableFlippersOnRest||!e.enableTransparentFlippersOnRest}"
        size=${e=>e.flipperSize}
        data-t="${e=>e.telemetryContext?.previousSlideArrow?.getMetadataTag()}"
        title=${e=>e.infoPanePreviousFlipperTitle}
        ?is-chevron="${e=>e.enableChevronFlipper}"
    >
    </card-flipper>
`,C=(0,i.qy)`
    <card-flipper class="nextFlipper" 
        slot="next-flipper"
        caretIcon="${e=>e.flipperCaretIcon||`${(0,u.rA)()?.StaticsUrl}latest/fluent-icons/caret_left_24_filled.svg`}"
        direction="next"
        invert-color=${e=>e.flipperColorInverted}
        aria-hidden="${e=>!e.enableFlippersOnRest||!e.enableTransparentFlippersOnRest}"
        size=${e=>e.flipperSize}
        data-t="${e=>e.telemetryContext?.nextSlideArrow?.getMetadataTag()}"
        title=${e=>e.infoPaneNextFlipperTitle}
        ?is-chevron="${e=>e.enableChevronFlipper}"
    >
    </card-flipper>
`,x=(0,i.qy)`
        ${v}
        ${C}
        `,w=new WeakMap,k=(0,i.qy)`
                <cs-responsive-infopane
                    class="${e=>A(e)}"
                    :config="${e=>e.config}"
                    duration="${e=>e.rotationDuration}"
                    media-controls="${e=>e.enablePlayPauseButton}"
                    navigation-position="${e=>e.navPosition}"
                    :enableSingleRotation="${e=>e.enableSingleRotation}"
                    :hasSlideShow="${e=>e.enableSlideShow}"
                    :parentContentId="${e=>e.parentContentId}"
                    size="${e=>e.cardSize}"
                    tab-count=${e=>e.tabCount}
                    transition-strategy=${e=>e.enableIpTransform?"transform":"position"}
                    :restartRotationTimer="${e=>e.restartRotationTimer}"
                    :wpoRotationDuration="${e=>e.wpoRotationDuration}"
                    style="grid-area:${e=>e.gridArea}"
                    data-t="${e=>e.telemetryContext?.infopane?.getMetadataTag()}"
                    play-telemetry="${e=>e.telemetryContext?.playTransitionButton?.getMetadataTag()}"
                    pause-telemetry="${e=>e.telemetryContext?.pauseTransitionButton?.getMetadataTag()}"
                    tab-telemetry="${e=>e.telemetryContext?.tabTelemetry?.getMetadataTag()}"
                    :tabLabels=${e=>e.infoPaneTabLabels}
                    @mouseenter=${(e,t)=>{t.event&&$(t.event.currentTarget)}}
                    @mouseleave=${(e,t)=>{t.event&&S(t.event.currentTarget)}}
                    preload-panels=${e=>e.lazyInfopanePreloadCount}
                    :enableVariableSpeed=${e=>e.enableVariableSpeed}
                    :variableTransitionMap=${e=>e.enableVariableSpeed&&e.slideContentData.map(e=>({id:e.id,slideDuration:e.customTransitionSpeed}))}
                    :lazyPanels=${e=>e.enableLazyInfopane?e.slideContentData.map(e=>({id:e.id,data:e})):void 0}
    :lazyPanelTemplate=${(e,t)=>(w.has(t.parent)||w.set(t.parent,(0,i.qy)`${e=>I(e)}`),w.get(t.parent))}
                    >
                    ${(0,n.z)(e=>!e.disableInfopaneFlippers,x)}
                    ${(0,r.ux)(e=>e.enableLazyInfopane?[]:e.slideContentData,(0,i.qy)`${(e,t)=>I(e)}`)}
                </cs-responsive-infopane>
    `,$=e=>{(0,s.kM)("SuperInfopaneCard",()=>d.YT.sendActionEvent(e,c.EG.Hover,c.MS.Open))},S=e=>{(0,s.pS)("SuperInfopaneCard",()=>d.YT.sendActionEvent(e,c.EG.MouseLeave,c.MS.Open))},T=i.qy.partial("style='height: 100%; width: 100%;'"),_=(0,i.qy)`
    <div class="dense-card-container">
        ${e=>(0,y.yN)(e.denseConfigInfo,{properties:{denseData:e.denseData,telemetryObject:e.telemetryObject},memoize:!1})}
    </div>
`,I=e=>{let t=(e.cardActionStatus&p.J.hide)!=0||!!e.enableHideStoryFeedback&&((e.cardActionStatus&p.J.showFewer)!=0||(e.cardActionStatus&p.J.hidden)!=0);if(e.isNativeAd)return g.W;if(t)return e.cardActionStatus&p.J.hidden?(0,i.qy)`<div class="infopane-hide-story" ${T}>
            ${m.X}
        <div>`:e.cardActionStatus&p.J.adFeedbackSubmitted?(0,i.qy)`<div class="infopane-hide-story" ${T}>
            ${h.L}
        <div>`:(0,i.qy)`<div class="infopane-hide-story" ${T}>
        ${e.currentCardData?.type==="nativead"?b.j:f.F}
    </div>`;return"dense-card"===e.childTemplateType?_:l.t},A=e=>(0,o.x)("infopane mid-button infopaneCardWrapper",["no-nav-anim",e.disableNavAnimation],["immersive-infopane",e.enableImmersiveInfopane],["show-flippers",e.enableFlippersOnRest],["tsp-flippers",e.enableTransparentFlippersOnRest],["no-margin-flippers",e.enableNoMarginFlippers],["has-dense-card",e.slideContentData?.some(e=>"dense-card"===e.childTemplateType)]);a.d(t,{},{P:k})},85842(e,t,a){"use strict";var i=a(30316),n=a(28747);let r={getFeedDataForCard:e=>(0,n.v)(e),viewTemplate:i.U};a.d(t,{},{a:r})},28747(e,t,a){"use strict";var i=a(98794),n=a(18576),r=a(18336),o=a(69828),l=a(7446),s=a(3006),d=a(5871);function c(e){let{cardMetadata:t,openLinksInNewTab:a,configOptions:i,refreshSDCardSection:r,refreshFeedCallback:o,goToPersonalizeSettingsCallback:l,flattenedRightRail:s,supportedSdCardActionMenuItems:c,sdCardActionClickHandler:p,visualReadinessCallback:g,dismissSDCardMenuCallback:u,parentTelemetryObject:m,hasLoadedCallback:h,activeBoard:b,isWidget:f,isWidgetRegion:y,turnOffWidgetsRegionCallback:v,manageWidgetsRegionCallback:C,onSDCardClick:x}=e;if(!t.data)return;let w=i.childExperienceReferencesWC?.sportsCard,k=n.F.mapSubCardToSportsMatchData(t),$=t?.data,S=t.cardId,T=t.wpoId;(f||i?.enableSportsCompPreload&&t?.isFirstSectionCard)&&(0,d.Q)(t?.data||"");let _=`${t.type}${b?`_${b}`:""}${t.metadata?.isSpotlightUX?"_spotlight":""}`,I=`${_}${t.id?`_${t.id}`:""}`;return{id:I,childTemplateType:"sports-card",sportsMatchupData:k,openLinksInNewTab:a,cardId:S,cardStyle:i&&i.cardStyle,sportsCardConfigInfo:w,refreshFeed:r||o,goToPersonalizeCallback:l,visualReadinessCallback:g,hasLoadedCallback:h,noGradient:s,supportedSdCardActionMenuItems:c,sdCardActionClickHandler:p,dismissSDCardMenuCallback:u,feedData:$,cardType:_,experienceName:I,isSpotlightUX:t.metadata&&t.metadata.isSpotlightUX,previewType:t.metadata&&t.metadata.previewType,parentTelemetryObject:m,isWidgetRegion:y,turnOffWidgetsRegionCallback:v,manageWidgetsRegionCallback:C,onSDCardClick:x,wpoId:T,zonedLayout:t?.zonedLayout??!1}}function p(e){let{supportedSdCardActionMenuItems:t,sdCardActionClickHandler:a,waterfallCardSlot:n}=e,d=c(e);return d?(d.isWidgetRegion&&(d.cardSize="_1x_1y"),n?.order&&l.YT.addOrUpdateTmplProperty("sportsCardRow",`${n?.order}`),(0,i.bw)({id:d.id,experienceType:d.sportsCardConfigInfo?.configRef?.experienceType,mapperArgs:e},d,(e,i)=>({cardLayout:i.cardSize===o.u._1x_1y?r.mj.Small:r.mj.Medium,supportedSdCardActionMenuItems:t,sdCardActionClickHandler:a}),!0)):(0,s.wc)()}a.d(t,{v:()=>p,x:()=>c})},30316(e,t,a){"use strict";var i=a(69828),n=a(91748),r=a(89757),o=a(94172),l=a(33744);let s=(0,r.qy)`${e=>e.sportsCardConfigInfo&&(0,o.yN)(e.sportsCardConfigInfo,{properties:{wpoMetadata:e.wpoMetadata,cardType:e.cardType,experienceName:e.experienceName,cardId:e.cardId,shellV2PreviewType:"windowsShellV2"===l.T3.AppType?e.previewType:"",cardSize:e.cardSize===n.Go._1u?i.u._1x_2y:e.cardSize,goToPersonalizeCallback:e.goToPersonalizeCallback,refreshFeed:e.refreshFeed,visualReadinessCallback:e.visualReadinessCallback,parentTelemetryObject:e.parentTelemetryObject,supportedSdCardActionMenuItems:e.supportedSdCardActionMenuItems,sdCardActionClickHandler:e.sdCardActionClickHandler,dismissActionMenu:e.dismissSDCardMenuCallback,isSpotlight:e.isSpotlightUX,isWidgetRegion:e.isWidgetRegion,turnOffWidgetsRegionCallback:e.turnOffWidgetsRegionCallback,manageWidgetsRegionCallback:e.manageWidgetsRegionCallback,telemetryExt:e.telemetryExt,feedDataParsed:e.sportsMatchupData,hasLoadedCallback:e.hasLoadedCallback,onSDCardClick:e.onSDCardClick,wpoId:e.wpoId},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible`,initialPreviewType:e.previewType},memoize:"windowsShellV2"!==l.T3.AppType})}`,d=(0,r.qy)`${e=>e.sportsCardConfigInfo&&(0,o.yN)(e.sportsCardConfigInfo,{properties:{cardLayout:e.cardLayout,wpoMetadata:e.wpoMetadata,sportsData:e.sportsMatchupData,openLinksInNewTab:e.openLinksInNewTab,telemetryExt:e.telemetryExt,noGradient:e.noGradient,refreshFeed:e.refreshFeed,goToPersonalizeCallback:e.goToPersonalizeCallback,supportedSdCardActionMenuItems:e.supportedSdCardActionMenuItems,sdCardActionClickHandler:e.sdCardActionClickHandler,visualReadinessCallback:e.visualReadinessCallback,dismissActionMenu:e.dismissSDCardMenuCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible`},memoize:"windowsShellV2"!==l.T3.AppType})}`,c=(0,r.qy)`
    ${e=>e.sportsCardConfigInfo.configRef?.experienceType==="SportsInfo"?s:d}
`;a.d(t,{},{U:c})},57152(e,t,a){"use strict";a.d(t,{u:()=>f,IT:()=>b,Ww:()=>y});var i,n,r=a(98794),o=a(98378),l=a(69828),s=a(35667),d=a(46659);(i=n||(n={})).OneColumn="1_column",i.TwoColumn="2_column";var c=a(83916),p=a(1792),g=a(25658),u=a(72287),m=a(98669),h=a(77833);function b(e,t){let a=new Date().getTime(),i=new Date(e).getTime();return!isNaN(i)&&a-i<1e3*t}function f(e){let{cardMetadata:t,cardSlot:a,openLinksInNewTab:i,parentTelemetryObject:o,visualReadinessCallback:s,isAnaheimDesign:d,isProviderInFooter:p,localizedStrings:g,configOptions:u,infopaneThresholdSecondForNewFlag:m,infopaneThresholdForCommentFlag:h}=e,b="tabbedInfopaneCard",f=h??1,v=m??7200,C=[];if(t.subItems&&t.subItems.length?C=t.subItems:(C=t.subCards,t.subItems=C),!C.length)return;let x=(0,c.G)(o),w={id:b,childTemplateType:"tabbed-infopane-card",enableAdaptDarkMode:u.enableAdaptDarkMode,telemetryContext:x,slideContentData:[]};return(0,r.bw)({id:b,experienceType:(u&&u.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e},w,(t,a)=>{let c=a.cardSize,m=[];return C.forEach((a,n)=>{if(!a)return;let l=a.recoId||a.metadata&&a.metadata.recoId,h=a.ri||a.metadata&&a.metadata.ri,C=(0,r.uX)({id:b,columnArrangement:t,experienceType:(u&&u.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e,recoId:l,ri:h,subCardIndex:n}).telemetryExt,w=a.visualReadinessCallback,k=y(u,a,i,p,()=>{s&&s(),w&&w()},d,o,x,c,!1,n,C,g,v,f);k&&m.push(k)}),{layout:c===l.u._2x_2y?n.TwoColumn:n.OneColumn,slideContentData:m}})}function y(e,t,a,i,n,r,l,c,f,y,v,C,x,w,k){let $,S=e.childExperienceReferencesWC?.denseCard||e.childExperienceReferences?.denseCard,T=t?.subItems??t?.subCards,_=T[0]?.cardContent??(0,u.cZ)(T[0]).cardContent,I=T[0]?.commentSummary?.totalCount??(0,u.cZ)(T[0]).commentSummary?.totalCount??0;S={...S,instanceId:`denseCard-${_.id}`};let A=T[0]?.type===h.pL.WebContent,{id:D,destinationUrl:z,title:F,provider:R,type:L}=_,M=(0,u.Ie)(T[0]),E=l.addOrUpdateChild({name:"DenseSlide",type:o.MJ.Headline}),B=(0,s.dj)(E,_,T[0].metadata,C,L===h.pL.WebContent),P=!0!==e.disableDenseArticleTemplate&&M?.width<M?.height,O=d.L._240x129;P?O=d.L._240x253:e.useLargeHeroImageForDense&&(O=d.L._300x200);let N=(0,m.po)(T[0],O,n,r,!1),H=T?.slice(1);H.length>8&&(H=H.slice(0,7).concat(H[H.length-1]));let q={heroNews:{id:D,destinationUrl:(0,p.EJ)((0,u.Dv)(z)),openLinksInNewTab:a,title:F,ariaLabel:(0,u.yL)(F,R,null),imagePriority:!1,providerData:(0,u.p_)(R,A,null),isProviderInFooter:i,imageData:N,useArticleCardTemplate:P,telemetryContext:B,commentCount:Math.min(I,99),commentFlag:I>=k,newFlag:b(_.publishedDateTime,w)},newsList:H?.map(t=>{let a=t.type===h.pL.NativeAd||t.type===h.pL.CmsAd;if(!a){let i=t.type===h.pL.WebContent;t.cardContent||(t=(0,u.cZ)(t));let n=t.metadata.commentSummary?.totalCount??0;return{destinationUrl:(0,p.EJ)((0,u.Dv)(t.cardContent.destinationUrl)),title:t.cardContent.title,ariaLabel:(0,u.yL)(F,t.cardContent.provider,null),providerData:(0,u.p_)(t.cardContent.provider,i,null),isNativeAd:a,telemetryContext:(0,s.dj)(E,t.cardContent,t.metadata,C,i),isNarrowNewsItem:e.isNarrowNewsItem,commentCount:n<=99?n:99,commentFlag:n>=k,newFlag:b(t.cardContent.publishedDateTime,w)}}let i=t.placement?.items[0]??{},{beaconsJson:n,privacyUrl:r,adLabelText:o,geminiViewabilityDataJson:l}=t.placement??{};return{...i,beaconsJson:n,privacyUrl:r,adLabelText:o,geminiViewabilityDataJson:l,isNativeAd:a,adTelemetryContext:(0,g.u)(t,E,"infopane",0),isNarrowNewsItem:e.isNarrowNewsItem,isGreyAdsLabelEnabled:y}}),configOptions:e,cardSize:f,isTabbedInfopane:!0};$=t.feed?.feedName?t.feed.feedName:x?.tabNameAll?x.tabNameAll:"総合";let W=function(e,t){switch(e){case"CanonicalName-entertainment":return t.tabEntertainment;case"CanonicalName-sports":return t.tabSports;case"CanonicalName-news-national":return t.tabNewsNational;case"CanonicalName-news-world":return t.tabNewsWorld;case"CanonicalName-finance-business":return t.tabFinanceBusiness;case"CanonicalName-lifestyle":return t.tabLifestyle;case"CanonicalName-businessnews":return t.tabBusinessNews;case"CanonicalName-scienceandtechnology":return t.tabScienceAndTechnology;default:return t.tabAll}}(t.id,c);return{id:v.toString(),denseConfigInfo:S,childTemplateType:"tabbed-infopane-card",gridArea:"",telemetryObject:E,denseData:q,tabLabel:$,tabTelemetry:W}}},83916(e,t,a){"use strict";var i=a(98378);a.d(t,{},{G(e){if(!e)return;let t=e.addOrUpdateChild({name:"TabbedInfopane",type:i.MJ.Headline}),a=t.addOrUpdateChild({name:"taball",behavior:i.MS.Show,content:{headline:"taball"},type:i.MJ.ActionButton}),n=t.addOrUpdateChild({name:"tabentertainment",behavior:i.MS.Show,content:{headline:"tabentertainment"},type:i.MJ.ActionButton}),r=t.addOrUpdateChild({name:"tabsports",behavior:i.MS.Show,content:{headline:"tabsports"},type:i.MJ.ActionButton}),o=t.addOrUpdateChild({name:"tabnewsnational",behavior:i.MS.Show,content:{headline:"tabnewsnational"},type:i.MJ.ActionButton}),l=t.addOrUpdateChild({name:"tabnewsworld",behavior:i.MS.Show,content:{headline:"tabnewsworld"},type:i.MJ.ActionButton}),s=t.addOrUpdateChild({name:"tabfinancebusiness",behavior:i.MS.Show,content:{headline:"tabfinancebusiness"},type:i.MJ.ActionButton}),d=t.addOrUpdateChild({name:"tablifestyle",behavior:i.MS.Show,content:{headline:"tablifestyle"},type:i.MJ.ActionButton}),c=t.addOrUpdateChild({name:"tabbusinessnews",behavior:i.MS.Show,content:{headline:"tabbusinessnews"},type:i.MJ.ActionButton}),p=t.addOrUpdateChild({name:"tabscienceandtechnology",behavior:i.MS.Show,content:{headline:"tabscienceandtechnology"},type:i.MJ.ActionButton});return{componentRoot:e,tabbedInfopane:t,tabAll:a,tabEntertainment:n,tabSports:r,tabNewsNational:o,tabNewsWorld:l,tabFinanceBusiness:s,tabLifestyle:d,tabBusinessNews:c,tabScienceAndTechnology:p}}})},60941(e,t,a){"use strict";var i=a(89757),n=a(68835),r=a(94172);let o=(0,i.qy)`
<fluent-tab id="tab_panel_${e=>e.id}" data-t=${e=>e.tabTelemetry?.getMetadataTag()} aria-label=${e=>e.tabLabel}>${e=>e.tabLabel}</fluent-tab>
<fluent-tab-panel data-t=${e=>e.tabTelemetry?.getMetadataTag()}>
${e=>(0,r.yN)(e.denseConfigInfo,{properties:{denseData:e.denseData,telemetryObject:e.telemetryObject},memoize:!1})}
</fluent-tab-panel>
`,l=(0,i.qy)`
<style>
    .tabbed-infopane {
        background: #fff;
        height: 304px;
    }
    .tabbed-infopane fluent-tabs {
        background: #E5E5E5;
    }
    .tabbed-infopane fluent-tab-panel {
        padding: 0px;
    }
    .tabbed-infopane fluent-tab {
        color: #222222;
        font-size: 14px;
        font-family: "Segoe UI", Arial, Sans-Serif;
        font-weight: 400;
        align-items: center;
        line-height: 20px;
        background: #E5E5E5;
        text-align: center;
        padding: 8.2px;
        border-radius: 0px 0px 0px 0px;
    }
    /* Change selected tab's design */
    .tabbed-infopane fluent-tab[aria-selected="true"] {
        background-color: #fff;
        color: rgba(0, 0, 0, 0.83);
        font-weight: 700;
        border-radius: 6px 6px 0px 0px;
        box-shadow: 0px -2.02314px 4.0462px rgba(0, 0, 0, 0.05);
    }
    /* Show underline when hovering unselected tabs */
    .tabbed-infopane fluent-tab[aria-selected="false"]:hover {
        text-decoration: underline;
    }
    /* Change dense-card's design for tabbed-infopane */
    .tabbed-infopane dense-card::part(dense-card-part) {
        margin-top: 0px;
        background: #fff;
    }
    /* Disable fluent-tabs' active-indicator */
    .tabbed-infopane fluent-tabs::part(active-indicator) {
        display: none;
    }

    @media (prefers-color-scheme: dark) {
        .tabbed-infopane.adapt-dark-mode {
            background: #424242;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tabs {
            background: #757575;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tab {
            color: #FFFFFF;
            background: #757575;
        }
        .tabbed-infopane.adapt-dark-mode fluent-tab[aria-selected="true"] {
            background-color: #424242;
            color: #FFFFFF;
        }
        .tabbed-infopane.adapt-dark-mode dense-card::part(dense-card-part) {
            background: #424242;
        }
    }
</style>
<div class="${e=>d(e)}"
     data-t="${e=>e.telemetryContext?.tabbedInfopane?.getMetadataTag()}">
    <fluent-tabs orientation="horizontal">
        ${(0,n.ux)(e=>e.slideContentData,o,{positioning:!0})}
    </fluent-tabs>
</div>
`,s=(0,i.qy)`
<style>
    :host fluent-card {
        content-visibility: auto;
    }
</style>
<fluent-card style="grid-area:${e=>e.gridArea}; ${e=>e.autoRowHeights?"height: 304px;":""}"  class="${e=>e.cardSize}">
    <fluent-design-system-provider 
        fill-color="#333"
        style="height: 100%;"
    >
    ${l}
    </fluent-design-system-provider>
</fluent-card>
`,d=e=>{let t="tabbed-infopane";return e.enableAdaptDarkMode&&(t+=" adapt-dark-mode"),t};a.d(t,{},{L9:s,M:l})},10173(e,t,a){"use strict";a.d(t,{W:()=>$});var i,n,r,o,l,s,d,c,p=a(44978),g=a(69828),u=a(35667),m=a(98794),h=a(98378),b=a(58319),f=a(25066),y=a(33744),v=a(98669),C=a(77833),x=a(29307),w=a(54694),k=a(72287);function $(e){var t,a,i,n,r,o,$,S,T,_,I,A,D,z,F,R;let L,{cardMetadata:M,parentTelemetryObject:E,localizedStrings:B,openLinksInNewTab:P,cardActionClickHandler:O,cardActionBitMask:N,initCardAction:H,enableRichSocialReaction:q,visualReadinessCallback:W,configOptions:K,refreshFeedCallback:U,isAnaheimDesign:V,additionalHeaders:j}=e,{topStoriesHeadingText:G,workHeadlinesHeadingText:X,workHeadlinesTooltipText:J}=B,Z=((e,t)=>{let a,i;if(!e)return;t===C.pL.TopicFeedTrendingNow||t===C.pL.TopicFeed?(a=e.addOrUpdateChild({name:s.TrendingNowCard,type:h.MJ.ContentGroup}),i=s):(a=e.addOrUpdateChild({name:l.TopStoriesCard,type:h.MJ.ContentGroup}),i=l);let n=a.addOrUpdateChild({name:i.CardVersion,type:h.MJ.ContentGroup}),r=n.addOrUpdateChild({name:i.SubCard}),o=a.addOrUpdateChild({name:i.Header,action:h.EG.Click,behavior:h.MS.Navigate,type:h.MJ.ContentGroup,content:{id:i.Header,type:h.b5.Feed,vertical:i.Vertical,headline:i.HeaderLinkHL}}),d=a.addOrUpdateChild({name:i.FlipperPrevious,action:h.EG.Click,behavior:h.MS.Show,content:{id:i.FlipperPrevious},type:h.MJ.ContentGroup}),c=a.addOrUpdateChild({name:i.FlipperNext,action:h.EG.Click,behavior:h.MS.Show,content:{id:i.FlipperNext},type:h.MJ.ContentGroup}),{zone:p}=e.contract||{};return p&&(a.contract.zone=p,o.contract.zone=p),{componentRoot:e,topStoriesCard:a,cardVersion:n,subCard:r,headingClick:o,flipperNextClick:c,flipperPreviousClick:d}})(E,M.type),Y=K&&K.topStoryCardConfig;if(Y&&Y.topStoriesLandingPageLink){let e=(0,b.bI)(Y.topStoriesLandingPageLink);L=(0,f.wY)(e)}let Q=K&&(K.childExperienceReferencesWC&&K.childExperienceReferencesWC.socialBarWC||K.childExperienceReferences&&K.childExperienceReferences.socialBarWC),ee=M.type===C.pL.WorkHeadlines,et=ee?[p.X.Report]:null,ea=(t=M.subCards,a=B,i=N,n=O,r=H,o=Z&&Z.topStoriesCard,$=!ee&&q,S=P,T=K,_=U,I=et,A=Q,D=j,t?t.map(e=>{let t,l,s,{locale:d,provider:c,publishedDateTime:p,title:g,url:m,destinationUrl:h,id:b,abstract:f,type:x}=e;if(o){let a=(0,u.dj)(o,e,null,null,x===C.pL.WebContent);a&&(t={contentCard:a.contentCard,contentCardTelemetryObject:a.contentCard&&a.contentCard,button:a.seeMore&&a.seeMore.getMetadataTag(),destination:a.destination,buttonTelemetryObject:a.seeMore,seeMore:a.seeMore})}let z=(0,k.H8)(e,i),{cardActionsTooltips:F,crawledContentLabel:R}=a,L=x===C.pL.WebContent;if(T&&(T.useThumbnailTopStories||T.useRightRailTopStories||T.useTopStoriesRibbonCarousel)){let t;t=T?.useImgGenerator?T.stockImageData&&{url:(0,w.XP)(T.stockImageData.id,{width:0,height:0,enableDpiScaling:!1}),width:T.stockImageData.width,height:T.stockImageData.height}:T.stockImageData;let a=e.images&&e.images[0]||t,i=a&&a.colorSamples,n=e&&e.colorSamples;l=function(e,t){let a;if(!e)return;let{attribution:i,title:n=t,url:r}=e;if(!r)return null;let o=[];return n&&o.push(n),i&&o.push(i),o.length&&(a=o.join(" - ")),{source:r,altText:a}}(a,e.title),s=(0,v.uK)(i,n,!0)}let M=(0,k.Dv)(m||h);return("winWidgets"===y.T3.AppType||"windowsNewsPlus"===y.T3.AppType)&&(M=(0,u._l)(M)),{id:b,abstract:f,articleCardBackgroundColor:s,gridArea:null,childTemplateType:null,cardActionStatus:!L&&z,cardActionClickHandler:n,cardActionsTooltips:F,crawledContentLabel:R,isWebContent:L,destinationUrl:M,enableRichSocialReaction:!L&&$,isProviderIconClickable:T&&T.isProviderIconClickable,locale:d,imageData:l,title:g,providerData:(0,k.p_)(c,L),publishedDateTime:T&&T.enableArticleTimestamps&&`${(0,v.fL)(T.enableNewTimestampFormatForJAJP,new Date(p),d,a)}`,toggleCardActionMenu:(e,t)=>(0,v.Sp)(e,t,n,r,!0,!0,_,T?.openPersonalizeWithoutRouter),telemetryContext:t,openLinksInNewTab:S,openArticleInNewTab:T&&T.openArticleInNewTab,ariaLabel:(0,k.yL)(g,c,a),actionsArrayOverride:I,socialBarWCConfigInfo:A,metadata:e,enableFilledIconOnHover:T&&T.enableFilledIconOnHover,additionalHeaders:D,disableCardTitleTooltip:T&&T.disableCardTitleTooltip,disableTitleOnArticleCardOnly:T&&T.disableTitleOnArticleCardOnly}}):[]),ei={id:"topStories",childTemplateType:"top-stories-card",listCardData:ea,openLinksInNewTab:P,topStoriesHeadingText:K&&!0===K.disableTopStoriesCardHeading?"":ee?X:G,tooltip:ee?J:null,telemetryContext:Z,cardLayout:(z=K,F=ea.length,z&&z.useRightRailTopStories?d.RightRail:z&&z.useTopStoriesRibbonCarousel?d.RibbonCarousel:z&&z.useThumbnailTopStories?F>3?d.Thumbnail:d.CompactThumbnail:z&&z.useStackedTopStories?d.Stacked:F>3?d.Normal:d.Compact),cardBackground:(R=K)&&R.useSectionHeaderTopStories?c.InheritSection:R&&R.useGradientTopStories?c.Gradient:c.Normal,headingLink:L,isAnaheimDesign:V,disableTopStoriesInlineAction:K?.disableTopStoriesInlineAction,isDynamicFeed:K&&K.isDynamicFeed,useGradientBackground:Y&&Y.useGradientBackground,disableCardTitleTooltip:K&&K.disableCardTitleTooltip,disableTitleOnArticleCardOnly:K&&K.disableTitleOnArticleCardOnly,enableFeeds2TopStoriesCarousel:K&&K.enableFeeds2TopStoriesCarousel,isSpotlightUX:M.subCards&&M.subCards[0]&&M.subCards[0].isFeatured,spotlightBreakingNewsTagString:B?.topStoriesBreakingNewsTagString},en=(0,m.bw)({id:"topStories",experienceType:(K&&K.childExperienceReferencesWC)?.configRef?.experienceType,mapperArgs:e},ei,(e,t)=>{let a=(0,x.A)(ea);a.forEach((e,a)=>{if(e.telemetryContext&&e.telemetryContext.contentCard&&e.telemetryContext.destination){let i={...t.telemetryExt};e.metadata.recoId&&(i.recoId=e.metadata.recoId),e.metadata.ri&&(i.ri=e.metadata.ri),i.sco=a+1,i.cid=`${i.co}.${i.sco}`,e.telemetryContext.destination=e.telemetryContext.contentCard.addOrUpdateChild({...e.telemetryContext.destination.contract,type:h.MJ.Headline,ext:i})}});let i={listCardData:a},n=t.cardSize;return n===g.u._1x_2y&&(i.cardLayout=K&&K.useThumbnailTopStories?d.CompactThumbnail:d.Compact),K&&K.useRightRailTopStories&&(i.cardLayout=n===g.u._1x_3y?d.TallRightRail:d.RightRail),i});return W&&W(),en}(i=l||(l={})).Header="header",i.Vertical="homepage",i.HeaderLinkHL="TopStories",i.TopStoriesCard="TopStoriesCard",i.CardVersion="single",i.FlipperNext="FlipperNext",i.FlipperPrevious="FlipperPrevious",i.SubCard="topstories",(n=s||(s={})).Header="trendingnow_header",n.Vertical="homepage",n.HeaderLinkHL="TrendingNow",n.TrendingNowCard="TrendingNow",n.CardVersion="single",n.FlipperNext="FlipperNext",n.FlipperPrevious="FlipperPrevious",n.SubCard="trendingnow",(r=d||(d={})).Compact="compact",r.CompactThumbnail="compactthumb",r.TallRightRail="tallrightrail",r.RightRail="rightrail",r.Normal="normal",r.Stacked="stacked",r.Thumbnail="thumb",r.RibbonCarousel="ribbonCarousel",(o=c||(c={})).Normal="normal",o.Gradient="gradient",o.InheritSection="inheritSection"},14097(e,t,a){"use strict";a.d(t,{z:()=>ea});var i,n,r,o,l=a(56911),s=a(47810),d=a(95403),c=a(6032),p=a(83252),g=a(86856),u=a(22131),m=a(59669),h=a(73477),b=a(16215),f=a(63033);let y=(0,m.A)`
:host{--background-gradient-angle:44.24deg;--inline-actions-gradient-angle:270deg;--inline-actions-dynamic-gradient-angle:90deg;--feeds-2-light-background-gradient-angle:93.96deg;--feeds-2-dark-background-gradient-angle:138.52deg}:host msft-article .inline-actions{right:0}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{right:88px}:host([layout="thumb"][card-size="_2x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_2x_2y"]) msft-article .inline-actions{right:72px}:host([layout="thumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="thumb"][card-size="_1x_3y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_3y"]) msft-article .inline-actions{right:65px}:host .icon-tooltip{left:15px}`,v=(0,m.A)`
:host{--background-gradient-angle:-44.24deg;--inline-actions-gradient-angle:-270deg;--feeds-2-light-background-gradient-angle:-93.96deg;--feeds-2-dark-background-gradient-angle:-138.52deg}:host msft-article .inline-actions{left:0}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{left:88px}:host([layout="thumb"][card-size="_2x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_2x_2y"]) msft-article .inline-actions{left:72px}:host([layout="thumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_2y"]) msft-article .inline-actions,:host([layout="thumb"][card-size="_1x_3y"]) msft-article .inline-actions,:host([layout="compactthumb"][card-size="_1x_3y"]) msft-article .inline-actions{left:65px}:host msft-article .inline-actions .actions-button{margin:4px 0 4px 8px}:host .icon-tooltip{right:15px}`,C=(0,m.A)`
:host([layout="ribbonCarousel"]){border-radius:0}:host([layout="ribbonCarousel"][background="gradient"]){background:linear-gradient(var(--ribbon-carousel-gradient-background))}:host([layout="ribbonCarousel"][background="inheritSection"]) fluent-horizontal-scroll{display:block;margin:0 16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) fluent-horizontal-scroll{margin-inline:16px}:host([layout="ribbonCarousel"][card-size="_1x_1y"]) .inner-content{width:300px}:host([layout="ribbonCarousel"][card-size="_2x_1y"]) .inner-content{width:612px}:host([layout="ribbonCarousel"][card-size="_3x_1y"]) .inner-content{width:924px}:host([layout="ribbonCarousel"][card-size="_4x_1y"]) .inner-content{width:1236px}:host([layout="ribbonCarousel"]) .inner-content{overflow:visible}:host([layout="ribbonCarousel"][background="inheritSection"]) .inner-content{width:100%}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .inner-content{padding-bottom:16px}:host([layout="ribbonCarousel"]) .heading-container{padding-top:10px;padding-bottom:2px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading-container{padding-bottom:0;padding-top:0}:host([layout="ribbonCarousel"][card-size="_1x_2y"]) .heading-container{padding-top:12px}:host([layout="ribbonCarousel"]) .heading{font-size:var(--type-ramp-plus-1-font-size);font-weight:600;line-height:var(--type-ramp-plus-1-line-height)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-heigh,16px);display:inline-flex;padding:16px 16px;font-weight:400}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading-container{align-items:baseline}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading svg{margin-inline-end:8px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .heading::after{content:"";position:absolute;top:0px;right:0px;left:0px;height:160px;width:612px;z-index:1}:host([layout="ribbonCarousel"]) fluent-horizontal-scroll{max-width:-webkit-fill-available;max-width:-moz-available;--scroll-item-spacing:0}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) fluent-horizontal-scroll{z-index:2}:host([layout="ribbonCarousel"]) msft-article{height:102px;min-width:300px;white-space:initial}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article{height:96px;width:272px;min-width:272px;background:var(--article-backplate);border-radius:8px;margin-inline-end:8px}:host([layout="ribbonCarousel"]) msft-article,:host([layout="ribbonCarousel"][background="inheritSection"]) msft-article{margin-inline-end:12px}:host([layout="ribbonCarousel"]) msft-article:last-child,:host([layout="ribbonCarousel"][background="inheritSection"]) msft-article:last-child{margin-inline-end:0}:host([layout="ribbonCarousel"]) msft-article .image{height:60px;margin-top:4px;width:60px}:host([layout="ribbonCarousel"]) msft-article .image{height:80px;margin-top:0px;width:68px}:host([layout="ribbonCarousel"]) msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,3)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(heading){--msft-article-heading-font-size:14px;--msft-article-heading-line-height:20px;margin-top:20px;width:180px}:host([layout="ribbonCarousel"]) msft-article::part(article){height:88px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(article){height:80px;padding:8px}:host([layout="ribbonCarousel"]) msft-article::part(attribution){position:absolute;bottom:4px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(attribution),:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article::part(actions){top:8px}:host([layout="ribbonCarousel"]) msft-article .inline-actions{bottom:0}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article .inline-actions{top:-8px;inset-inline-end:72px}:host([layout="ribbonCarousel"][background="gradient"]) msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(var(--inline-actions-ribbon-carousel-gradient-background))}:host([layout="ribbonCarousel"][background="gradient"]) social-bar-wc::part(reaction-menu-container){background:var(--background-ribbonCarousel-social-bar)}:host([layout="ribbonCarousel"][background="gradient"][feeds-2-carousel="true"]) social-bar-wc::part(reaction-menu-container){top:0px;animation:none}:host .card-content{display:flex;overflow-x:hidden}:host .card-content msft-article.carousel{display:block}:host([layout="ribbonCarousel"][background="inheritSection"]) ::part(viewport){overflow-y:hidden}:host([layout="ribbonCarousel"]) .next,:host([layout="ribbonCarousel"]) .previous{width:32px;height:32px;border-color:transparent;border-radius:999px;box-shadow:0px 3.2px 7.2px rgb(0 0 0 / 13%),0px 0px 3.8px rgb(0 0 0 / 11%);background:var(--neutral-fill-stealth-rest)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{height:38px;width:16px;fill:var(--neutral-foreground-hint);backdrop-filter:blur(60px);border-radius:3px;box-shadow:none}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{opacity:1}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next:hover,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous:hover{fill:var(--neutral-foreground-rest)}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next{margin-inline-start:16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous{margin-inline-end:16px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .next::before,:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) .previous::before{border-radius:3px;background:var(--feeds-2-flipper-background)}:host([layout="ribbonCarousel"][background="inheritSection"]) .previous{margin-inline-start:10px}:host([layout="ribbonCarousel"][background="inheritSection"]) .next{margin-inline-end:10px}:host([layout="ribbonCarousel"][background="gradient"]):not([feeds-2-carousel="true"]) .previous{margin-inline-start:36px}:host([layout="ribbonCarousel"][background="gradient"]):not([feeds-2-carousel="true"]) .next{margin-inline-end:36px}:host([layout="ribbonCarousel"]) .next::before,:host([layout="ribbonCarousel"]) .previous::before{border-color:transparent}`,x=(0,m.A)`
:host([layout*="rightrail"]) .heading{font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height);color:var(--neutral-foreground-hint)}:host([layout="rightrail"]) msft-article .image{height:62px;width:62px}:host([layout="tallrightrail"]) msft-article .image{height:76px;width:76px}:host([layout="tallrightrail"]) msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,3)}:host([layout*="rightrail"]) .heading-container{text-transform:uppercase}:host([layout*="rightrail"]) .heading{padding-left:16px;padding-right:16px}:host([layout="tallrightrail"]) msft-article{height:92px}:host([layout*="rightrail"]) msft-article::part(article){padding:8px 16px}:host([layout*="rightrail"]) social-bar-wc::part(button-bg):hover,:host([layout*="rightrail"]) social-bar-wc::part(button-bg):hover{background-color:initial}:host([layout="tallrightrail"]) msft-article.social-reaction-enabled .inline-actions{min-width:76px}:host([layout="rightrail"]) msft-article.social-reaction-enabled .inline-actions{min-width:62px}`,w=(0,m.A)`
:host([background="gradient"]){--neutral-fill-stealth-hover:var(--gradient-hover);background:linear-gradient(var(--gradient-background));background-color:var(--background-color-dark-mode)}:host([background="gradient"][layout="ribbonCarousel"][feeds-2-carousel="true"]){background:linear-gradient(var(--feeds-2-gradient-background))}:host([layout="normal"][background="gradient"][card-size="_3x_2y"]) msft-article{--neutral-fill-stealth-hover:transparent;--inline-actions-gradient-background:transparent;--inline-actions-alt-gradient-background:transparent}:host([layout="normal"][background="gradient"]) msft-article::part(actions){background:transparent}:host([layout="thumb"][background="gradient"]) msft-article:hover .inline-actions,:host([layout="thumb"][background="gradient"]) msft-article:focus-within .inline-actions,:host([layout="thumb"][background="gradient"]) msft-article:hover .inline-actions social-bar-wc::part(social-bar),:host([layout="thumb"][background="gradient"]) msft-article:focus-within .inline-actions social-bar-wc::part(social-bar){background:none}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-1))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-2))}:host([background="gradient"][card-size="_1x_3y"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions,:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-3))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-4))}:host([background="gradient"][card-size="_1x_3y"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions,:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-5))}:host([background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-6))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-1))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-2))}:host([layout="compact"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-compact-gradient-background-3))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-1))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-3))}:host([layout="compactthumb"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-thumb-gradient-background-5))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-1))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-2))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-3))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-4))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-5))}:host([layout="stacked"][background="gradient"]) msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:linear-gradient(var(--inline-actions-stacked-gradient-background-6))}:host([layout="ribbonCarousel"][background="gradient"][feeds-2-carousel="true"]) msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(var(--inline-actions-feeds-2-gradient-background))}:host([background="gradient"]):host msft-article .inline-actions .actions-button:${h.N}{background:transparent}:host([background="gradient"]) msft-article .inline-actions .divider{border-left:1px solid rgba(0,0,0,0.09);margin-top:2px}:host([background="gradient"]) msft-article:hover,:host([background="gradient"]) msft-article:focus-within,:host([background="gradient"]) social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article .inline-actions .actions-button:hover{background:var(--gradient-hover)}:host([background="gradient"]) social-bar-wc::part(reaction-menu-container){background:var(--background-social-bar)}:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(comments-count-button):hover,:host([background="gradient"]) msft-article.filled-icon-hover .inline-actions .actions-button:hover{background:transparent}`,k=(0,m.A)`
:host{--msft-article-heading-line-height:22px;display:flex;height:100%;border-radius:calc(var(--layer-corner-radius) * 1px)}:host .inner-content{display:flex;flex-wrap:wrap;justify-content:space-between;margin:0 auto;overflow:var(--overflow,hidden)}:host msft-article .image{border-radius:4px;margin-inline-start:6px;overflow:hidden}:host msft-article .image{height:72px;width:72px}:host([card-size="_2x_2y"]) msft-article .image{height:59px;width:59px}:host([card-size="_1x_2y"]) msft-article .image,:host([card-size="_1x_3y"]) msft-article .image{height:52px;width:52px}:host([layout="normal"]),:host([layout="thumb"]),:host([layout*="rightrail"]){padding-left:3px;padding-right:3px}:host([layout="normal"][class="infopane-anaheim-design"]),:host([layout="thumb"][class="infopane-anaheim-design"]),:host([layout*="rightrail"][class="infopane-anaheim-design"]){padding-left:2px;padding-right:2px}:host([card-size="_3x_2y"]){padding-left:9px;padding-right:9px}:host([card-size="_3x_2y"]) msft-article{width:444px}:host([layout="compact"]),:host([layout="compactthumb"]),:host([layout*="rightrail"]){--msft-article-heading-font-size:14px;--msft-article-heading-line-height:20px}:host([layout="compact"]) msft-article{height:80px}:host([layout="ribbonCarousel"]) msft-article,:host([layout*="rightrail"]) msft-article{padding-bottom:0px}:host([layout="normal"]) msft-article,:host([layout="thumb"]) msft-article{padding-bottom:0px;margin-bottom:6px}:host msft-article::part(heading){-webkit-line-clamp:var(--heading-max-lines,2)}:host msft-article::part(heading)::after{height:100%;width:100%}:host msft-article.crawled-content::part(heading){-webkit-line-clamp:var(--heading-max-lines,1)}:host .heading-container{width:100%;position:relative;display:flex;align-items:center}:host .heading-container.anaheim-infopane{padding-top:12px;padding-bottom:6px}:host .anaheim-infopane-bottom-padding{height:8px;width:100%}:host([card-size="_3x_2y"]) .heading-container{padding-left:3px;padding-right:3px}:host .heading{font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);font-weight:600;color:${s.l};margin:0;padding:16px 12px 10px;width:100%}:host([layout="normal"]) .heading,:host([layout="thumb"]) .heading{padding-left:9px;padding-right:9px}:host .heading-link{text-decoration:none}:host .heading-icon-container{cursor:pointer;display:inline-block;fill:${s.l};padding:0 8px;height:18px}:host .heading-icon-container:hover .icon-tooltip,:host .heading-icon-container:focus .icon-tooltip{visibility:visible;opacity:1}:host .icon-tooltip{background-color:${d.wO};border-radius:4px;color:${s.l};font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);opacity:0;padding:8px;position:absolute;text-transform:initial;top:40px;transition:opacity 0.3s;visibility:hidden;width:200px;z-index:1}:host([layout="compact"]) .heading{text-transform:uppercase;color:${c.c};font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}:host([layout="compact"]) .heading-icon-container{fill:${c.c}}:host msft-article{border-radius:0;height:80px;padding-bottom:6px;width:300px;z-index:0}:host([layout="stacked"]) msft-article::part(text){display:inline-flex}:host([layout="stacked"]) msft-article::part(abstract){margin-inline-start:0px;width:90px}:host([layout="stacked"][card-size="_2x_2y"]) msft-article.stacked-fromweb::part(heading){max-width:470px}:host([layout="stacked"][card-size="_3x_2y"]) msft-article.stacked-fromweb::part(heading){max-width:770px}:host([layout="stacked"]) msft-article{height:36px;margin:0 9px;padding:0;width:100%}:host([layout="stacked"]) msft-article:nth-of-type(6){margin-bottom:6px;padding:0}:host([layout="stacked"]) msft-article::part(heading){display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:300px;margin-inline-start:4.5px}:host([layout="stacked"][card-size="_2x_2y"]) msft-article::part(heading){width:542px}:host([layout="stacked"][card-size="_3x_2y"]) msft-article::part(heading){width:832px}:host msft-article::part(article){border-radius:0;grid-gap:0;grid-template-columns:1fr auto;padding:8px 12px;overflow:visible}:host([layout="normal"]) msft-article::part(article),:host([layout="thumb"]) msft-article::part(article){height:64px}:host([layout="thumb"][card-size="_3x_2y"]) msft-article::part(article){padding:4px 12px}:host([layout="normal"]) msft-article::part(text),:host([layout="thumb"]) msft-article::part(text){max-height:calc(var(--msft-article-heading-line-height,24px) * 2);overflow:hidden}:host([layout="normal"]) msft-article::part(attribution),:host([layout="stacked"]) msft-article::part(attribution),:host([layout="compactthumb"]) msft-article::part(attribution),:host([layout="thumb"]) msft-article::part(attribution){display:inline-block;margin-inline-end:4px;vertical-align:top;width:16px}:host([layout="normal"]) msft-article::part(heading),:host([layout="compactthumb"]) msft-article::part(heading),:host([layout="thumb"]) msft-article::part(heading),:host([layout*="rightrail"]) msft-article::part(heading){width:calc(100% - 31px);display:-webkit-inline-box;margin-inline-start:3.5px}:host([layout*="rightrail"]) msft-article::part(heading){width:calc(100% - 26px)}:host msft-article::part(abstract){margin-inline-start:24px;-webkit-line-clamp:var(--abstract-max-lines,1);margin-top:-2px;color:var(--msft-card-font-color)}:host([layout="compact"][card-size="_1x_2y"]) msft-article::part(abstract){margin-inline-start:0}:host msft-article.crawled-content::part(abstract){color:${c.c};font-size:12px;line-height:16px;margin-top:4px}:host([layout="thumb"]) msft-article.crawled-content::part(abstract),:host([layout*="rightrail"]) msft-article.crawled-content::part(abstract){margin-top:0}:host([layout="normal"]) msft-article::part(actions),:host([layout="thumb"]) msft-article::part(actions),:host([layout="ribbonCarousel"]) msft-article::part(actions){position:absolute;bottom:0;padding-bottom:4px;padding-top:1px;width:calc(100% - 20px);background:var(--fill-color)}:host([layout="normal"]) msft-article:hover::part(actions),:host([layout="normal"]) msft-article:focus-within::part(actions),:host([layout="thumb"]) msft-article::part(actions),:host([layout="thumb"]) msft-article:hover::part(actions),:host([layout="thumb"]) msft-article:focus-within::part(actions),:host([layout="ribbonCarousel"]) msft-article::part(actions),:host([layout="ribbonCarousel"]) msft-article:hover::part(actions),:host([layout="ribbonCarousel"]) msft-article:focus-within::part(actions){background:transparent}:host([layout="thumb"][card-size="_3x_2y"]) msft-article::part(actions){bottom:10px}:host msft-article msft-attribution{display:grid;grid-template-columns:16px auto auto;grid-gap:8px;margin-bottom:4px;position:relative}:host([layout="normal"]) msft-article msft-attribution,:host([layout="thumb"]) msft-article msft-attribution{height:20px;padding-top:4px}:host([layout="thumb"]) msft-article msft-attribution{grid-template-columns:16px auto 65px}:host([layout="ribbonCarousel"][feeds-2-carousel="true"]) msft-article msft-attribution{max-width:180px}:host msft-article .inline-actions{align-items:center;background:${d.oO};display:grid;gap:4px;grid-template-columns:auto auto auto;height:28px;justify-content:end;margin:4px 0;opacity:0;padding:0;padding-inline-start:40px;position:absolute;width:auto;z-index:10}:host([layout="thumb"]) msft-article .inline-actions,:host([layout="compactthumb"]) msft-article .inline-actions{height:23px;margin:0}:host([layout="compact"]) msft-article .inline-actions,:host([layout="stacked"]) msft-article .inline-actions,:host([layout*="rightrail"]) msft-article .inline-actions{top:0}:host([layout="normal"]) msft-article .inline-actions{bottom:0;margin-bottom:5px;height:24px}:host([layout="compact"]) msft-article .inline-actions,:host([layout*="rightrail"]) msft-article .inline-actions{margin-inline-end:4px}:host([layout="stacked"]) msft-article .inline-actions{background:var(--neutral-fill-stealth-hover);margin-inline-end:12px}:host msft-article:hover,:host msft-article:focus-within{background:${d.oO};border-radius:4px}:host msft-article:hover .inline-actions,:host msft-article:focus-within .inline-actions{opacity:1}:host msft-article .inline-actions .actions-button{background:transparent;border:none;border-radius:4px;color:currentColor;cursor:pointer;fill:currentColor;height:24px;justify-content:center;min-width:24px;padding:0;width:24px}:host msft-article .inline-actions .actions-button svg{width:16px;height:16px}:host msft-article .inline-actions .actions-button:hover,:host msft-article .inline-actions .actions-button:${h.N}{background:${p.Xt}}:host msft-article .inline-actions .divider{height:11px;margin:-3px 0 0;border-left:1px solid ${p.Xt}}:host([layout="compact"]) msft-article .inline-actions .divider{margin-top:-2px}:host social-bar-wc::part(social-bar){align-self:start;opacity:1;background:none;height:24px}:host([layout="normal"]) social-bar-wc::part(react-button-container),:host([layout="normal"]) social-bar-wc::part(active-button-container){height:24px;padding:0;border-radius:16px}:host([layout="normal"]) social-bar-wc::part(button-bg){padding-top:4px;height:24px}:host msft-article.filled-icon-hover .inline-actions .actions-button:hover > svg > path:nth-child(1){transition:all 0.5s;d:path("${b.i_}")}:host msft-article.filled-icon-hover .inline-actions .actions-button svg{width:20px;height:20px}.attribution-provider-clickable{z-index:4;display:flex;margin:0 -23px}.attribution-icon-clickable{color:unset;text-decoration:none}.attribution-provider-name{unicode-bidi:embed}.attribution-provider-name:hover{text-decoration:underline}.attribution-provider-name .attribution-provider-logo-available:hover{text-decoration:underline}.attribution-provider-logo-available{margin-inline-start:10px}.attribution-published-time{margin:0 3px}.attribution-provider-not-clickable{margin:0 5px}.ts-breaking-news-tag{background-color:var(--accent-fill-rest);border-radius:3px;color:white;padding:0 5px}.breaking-news-red-tag{background-color:#C50F1F !important}.spotlight-flash-bg{animation:spotlight-ts-bg-animation 2000ms cubic-bezier(0,0,1,1) 667ms}@keyframes .spotlight-ts-bg-animation{0%{border:2px solid #8FA2FF;background-color:#8FA2FF26;transition-timing-function:cubic-bezier(0,0,1,1)}100%{transition-timing-function:cubic-bezier(0,0,1,1)}}${C} ${x}
`.withBehaviors(new g.t(y,v),(0,u.mr)((0,m.A)` :host msft-article .inline-actions{background:currentColor !important;padding-inline-start:12px !important}.attribution-provider-logo{forced-color-adjust:none;background:#FFFFFF}`),(0,u.C7)((0,m.A)` :host(.infopane-anaheim-design){--neutral-foreground-rest:#2B2B2B;--fill-color:#FFFFFF;--neutral-fill-hover:#E5E5E5;--neutral-fill-stealth-hover:#F2F2F2;background:#FFFFFF}`)),$=(0,m.A)` :host msft-article.social-reaction-enabled .inline-actions{background:linear-gradient(270deg,rgb(var(--neutral-fill-stealth-hover-rgb)) 0.01%,rgb(var(--neutral-fill-stealth-hover-rgb)) 76.82%,rgba(var(--neutral-fill-stealth-hover-rgb),0.8) 88.69%,rgba(var(--neutral-fill-stealth-hover-rgb),0) 100%)}`.withBehaviors((0,u.C7)((0,m.A)` :host{--neutral-fill-stealth-hover-rgb:242,242,242}`),(0,u.G2)((0,m.A)` :host{background:#3b3b3b;--fill-color:#3b3b3b;--neutral-foreground-hint:#a7a7a7;--neutral-foreground-rest:#ffffff;--neutral-fill-stealth-hover:#474747}:host msft-article:hover,:host msft-article:focus-within{background:#474747}:host{--neutral-fill-stealth-hover-rgb:71,71,71}.spotlight-flash-bg{animation:spotlight-bg-animation 2000ms cubic-bezier(0,0,1,1) 667ms}@keyframes spotlight-bg-animation{0%{border:2px solid #8FA2FF;background-color:#8FA2FF4D;transition-timing-function:cubic-bezier(0,0,1,1)}100%{transition-timing-function:cubic-bezier(0,0,1,1)}}`)),S=(0,m.A)`
${w}
`.withBehaviors((0,u.mr)((0,m.A)` :host{forced-color-adjust:auto}@media (forced-colors:active){:host([background="gradient"]) social-bar-wc::part(button-bg):hover,:host([background="gradient"]) social-bar-wc::part(button-bg):focus-within,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="gradient"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):focus-within{color:buttonface;background-color:highlight}}`),new f.N((0,m.A)` :host{--article-backplate:rgba(255,255,255,0.7);--background-color-dark-mode:unset;--background-social-bar:#FFFFFF;--background-ribbonCarousel-social-bar:#FFFFFF;--gradient-background:var(--background-gradient-angle),#C2CEE8 0%,rgba(241,246,255,0.6) 100%;--ribbon-carousel-gradient-background:var(--background-gradient-angle),rgba(194,206,232,0.4) 0%,rgba(241,246,255,0.24) 100%;--feeds-2-gradient-background:var(--feeds-2-light-background-gradient-angle),rgba(59,199,225,0.16) 0%,rgba(53,138,220,0.2) 98.88%;--feeds-2-flipper-background:#f1f6fb;--gradient-hover:rgba(0,0,0,0.05);--stacked-gradient-hover:242,242,242;--inline-actions-gradient-background:var(--inline-actions-gradient-angle),#D9D8F2 77.54%,rgba(208,214,242,0.8) 90.62%,rgba(208,214,242,0) 100%;--inline-actions-alt-gradient-background:var(--inline-actions-gradient-angle),#E6E2EF 0.01%,#E3DEEE 76.82%,rgba(227,222,238,0.8) 88.69%,rgba(227,222,238,0) 100%;--inline-actions-thumb-gradient-background-1:var(--inline-actions-gradient-angle),#d3dae8 0.01%,#ccd4e5 76.82%,rgba(202,211,228,0.8) 88.69%,rgba(201,210,228,0) 100%;--inline-actions-thumb-gradient-background-2:var(--inline-actions-gradient-angle),#e4e8ef 0.01%,#dde2ec 76.82%,rgba(219,225,235,0.8) 88.69%,rgba(218,224,235,0) 100%;--inline-actions-thumb-gradient-background-3:var(--inline-actions-gradient-angle),#ced6e6 0.01%,#c7d0e3 76.82%,rgba(198,207,226,0.8) 88.69%,rgba(196,206,225,0) 100%;--inline-actions-thumb-gradient-background-4:var(--inline-actions-gradient-angle),#dfe4ed 0.01%,#d8deea 76.82%,rgba(214,220,233,0.8) 88.69%,rgba(214,219,233,0) 100%;--inline-actions-thumb-gradient-background-5:var(--inline-actions-gradient-angle),#cad3e4 0.01%,#c3cce1 76.82%,rgba(194,203,224,0.8) 88.69%,rgba(193,202,224,0) 100%;--inline-actions-thumb-gradient-background-6:var(--inline-actions-gradient-angle),#d9dfea 0.01%,#d3d9e8 76.82%,rgba(210,216,232,0.8) 88.69%,rgba(208,215,230,0) 100%;--inline-actions-compact-gradient-background-1:var(--inline-actions-gradient-angle),#e6e9f0 0.01%,#dadfeb 76.82%,rgba(215,222,233,0.8) 88.69%,rgba(214,220,233,0) 100%;--inline-actions-compact-gradient-background-2:var(--inline-actions-gradient-angle),#dee3ed 0.01%,#d3dae8 76.82%,rgba(209,216,231,0.8) 88.69%,rgba(208,215,231,0) 100%;--inline-actions-compact-gradient-background-3:var(--inline-actions-gradient-angle),#d7ddea 0.01%,#cbd3e4 76.82%,rgba(202,210,228,0.8) 88.69%,rgba(199,208,227,0) 100%;--inline-actions-stacked-gradient-background-1:var(--inline-actions-gradient-angle),#e6e9f0 0.01%,#e3e7ee 76.82%,rgba(224,229,237,0.8) 88.69%,rgba(220,225,235,0) 100%;--inline-actions-stacked-gradient-background-2:var(--inline-actions-gradient-angle),#e5e9f0 0.01%,#e2e6ee 76.82%,rgba(222,227,236,0.8) 88.69%,rgba(219,224,235,0) 100%;--inline-actions-stacked-gradient-background-3:var(--inline-actions-gradient-angle),#e2e6ee 0.01%,#dfe4ed 76.82%,rgba(220,225,235,0.8) 88.69%,rgba(215,222,233,0) 100%;--inline-actions-stacked-gradient-background-4:var(--inline-actions-gradient-angle),#dfe4ed 0.01%,#dce1eb 76.82%,rgba(216,222,233,0.8) 88.69%,rgba(214,220,233,0) 100%;--inline-actions-stacked-gradient-background-5:var(--inline-actions-gradient-angle),#dee3ed 0.01%,#dae0eb 76.82%,rgba(215,221,233,0.8) 88.69%,rgba(213,219,233,0) 100%;--inline-actions-stacked-gradient-background-6:var(--inline-actions-gradient-angle),#dbe0eb 0.01%,#d7dde9 76.82%,rgba(213,219,233,0.8) 88.69%,rgba(209,216,231,0) 100%;--inline-actions-ribbon-carousel-gradient-background:var(--inline-actions-gradient-angle),#E5E8ED 0.01%,#E4E7ED 76.82%,rgba(227,231,237,0.8) 88.69%,rgba(227,230,237,0) 100%;--inline-actions-feeds-2-gradient-background:var(--inline-actions-gradient-angle),#f5fbfd 0.01%,#f5fcfe 76.82%,rgba(245,252,254,0.8) 88.69%,rgba(245,252,254,0) 100%}:host msft-article msft-attribution{--neutral-foreground-hint:#5f5f5f}`,(0,m.A)` :host{--article-backplate:rgba(255,255,255,0.0512);--background-color-dark-mode:#424242;--background-social-bar:#2B3C59;--background-ribbonCarousel-social-bar:#2B3C59;--gradient-background:var(--background-gradient-angle),#2B3C59 0%,rgba(43,60,89,0.6) 100%;--ribbon-carousel-gradient-background:var(--background-gradient-angle),#2B3C59 0%,rgba(43,60,89,0.6) 100%;--feeds-2-gradient-background:var(--feeds-2-dark-background-gradient-angle),#0F384D 0.44%,#0F2E4D 85.15%;--feeds-2-flipper-background:#173549;--gradient-hover:rgba(255,255,255,0.07);--stacked-gradient-hover:72,72,72;--inline-actions-gradient-background:var(--inline-actions-gradient-angle),#716583 0.01%,#665879 76.82%,rgba(100,86,119,0.8) 88.69%,rgba(98,84,118,0) 100%;--inline-actions-alt-gradient-background:var(--inline-actions-gradient-angle),#716583 0.01%,#665879 76.82%,rgba(100,86,119,0.8) 88.69%,rgba(98,84,118,0) 100%;--inline-actions-thumb-gradient-background-1:var(--inline-actions-gradient-angle),#3e4b60 0.01%,#3d4b62 76.82%,rgba(61,75,99,0.8) 88.69%,rgba(61,75,99,0) 100%;--inline-actions-thumb-gradient-background-2:var(--inline-actions-gradient-angle),#404c5d 0.01%,#404c5f 76.82%,rgba(63,75,95,0.8) 88.69%,rgba(64,76,96,0) 100%;--inline-actions-thumb-gradient-background-3:var(--inline-actions-gradient-angle),#3e4b62 0.01%,#3c4b63 76.82%,rgba(60,74,99,0.8) 88.69%,rgba(60,75,100,0) 100%;--inline-actions-thumb-gradient-background-4:var(--inline-actions-gradient-angle),#404c5f 0.01%,#3f4b60 76.82%,rgba(63,76,96,0.8) 88.69%,rgba(63,75,97,0) 100%;--inline-actions-thumb-gradient-background-5:var(--inline-actions-gradient-angle),#3d4c63 0.01%,#3b4a64 76.82%,rgba(60,75,101,0.8) 88.69%,rgba(59,75,101,0) 100%;--inline-actions-thumb-gradient-background-6:var(--inline-actions-gradient-angle),#404c5f 0.01%,#3e4b61 76.82%,rgba(62,75,97,0.8) 88.69%,rgba(62,76,98,0) 100%;--inline-actions-compact-gradient-background-1:var(--inline-actions-gradient-angle),#414c5c 0.01%,#404b5e 76.82%,rgba(64,76,95,0.8) 88.69%,rgba(63,75,95,0) 100%;--inline-actions-compact-gradient-background-2:var(--inline-actions-gradient-angle),#404c5e 0.01%,#3f4b60 76.82%,rgba(63,75,96,0.8) 88.69%,rgba(62,75,96,0) 100%;--inline-actions-compact-gradient-background-3:var(--inline-actions-gradient-angle),#404c60 0.01%,#3d4a61 76.82%,rgba(61,74,97,0.8) 88.69%,rgba(60,74,97,0) 100%;--inline-actions-stacked-gradient-background-1:var(--inline-actions-gradient-angle),#424c5c 0.01%,#414c5d 76.82%,rgba(64,76,93,0.8) 88.69%,rgba(64,75,94,0) 100%;--inline-actions-stacked-gradient-background-2:var(--inline-actions-gradient-angle),#424d5d 0.01%,#414d5e 76.82%,rgba(64,76,94,0.8) 88.69%,rgba(64,76,94,0) 100%;--inline-actions-stacked-gradient-background-3:var(--inline-actions-gradient-angle),#404b5c 0.01%,#404b5d 76.82%,rgba(64,76,94,0.8) 88.69%,rgba(63,75,94,0) 100%;--inline-actions-stacked-gradient-background-4:var(--inline-actions-gradient-angle),#404b5d 0.01%,#404b5e 76.82%,rgba(64,76,95,0.8) 88.69%,rgba(64,76,96,0) 100%;--inline-actions-stacked-gradient-background-5:var(--inline-actions-gradient-angle),#404c5e 0.01%,#404c5f 76.82%,rgba(64,75,95,0.8) 88.69%,rgba(63,75,96,0) 100%;--inline-actions-stacked-gradient-background-6:var(--inline-actions-gradient-angle),#404c5e 0.01%,#3f4b5f 76.82%,rgba(63,75,95,0.8) 88.69%,rgba(62,74,95,0) 100%;--inline-actions-ribbon-carousel-gradient-background:var(--inline-actions-gradient-angle),#3E4C61 0.01%,#3E4C62 76.82%,rgba(62,76,98,0.8) 88.69%,rgba(62,76,98,0) 100%;--inline-actions-feeds-2-gradient-background:var(--inline-actions-gradient-angle),#1b3d55 0.01%,#1b3f56 76.82%,rgba(27,64,86,0.8) 88.69%,rgba(27,64,86,0) 100%}:host msft-article msft-attribution{--neutral-foreground-hint:#b9b9b9}`)),T=(0,m.A)` :host([background="inheritSection"]){background:inherit}:host([background="inheritSection"]) msft-article .inline-actions,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:hover,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:focus-visible{background-color:rgba(255,255,255,0.8)}:host([background="inheritSection"]) msft-article,:host([background="inheritSection"]) msft-article:hover,:host([background="inheritSection"]) msft-article:focus-within{background-color:rgba(255,255,255,0.9);border-radius:4px}:host([background="inheritSection"]) msft-article.filled-icon-hover social-bar-wc::part(button-bg):hover,:host([background="inheritSection"]) msft-article.filled-icon-hover social-bar-wc::part(comments-count-button):hover{background:transparent}`.withBehaviors((0,u.C7)((0,m.A)` :host{--neutral-fill-stealth-hover-rgb:242,242,242}`),(0,u.G2)((0,m.A)` :host([background="inheritSection"]) msft-article .inline-actions,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:hover,:host([background="inheritSection"]) msft-article .inline-actions .actions-button:focus-visible{background-color:rgba(0,0,0,0.3)}:host([background="inheritSection"]) msft-article,:host([background="inheritSection"]) msft-article:hover,:host([background="inheritSection"]) msft-article:focus-within{background-color:rgba(0,0,0,0.4)}`)),_=(0,m.A)` :host .inner-content.dynamic-gradient-morning,:host([background="gradient"]) .inner-content.dynamic-gradient-morning social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-morning)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-morning-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-morning-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-morning-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-morning-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-morning-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-morning-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-morning msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-morning-6)}:host .inner-content.dynamic-gradient-day,:host([background="gradient"]) .inner-content.dynamic-gradient-day social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-day)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-day-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-day-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-day-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-day-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-day-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-day-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-day msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-day-6)}:host .inner-content.dynamic-gradient-sunset,:host([background="gradient"]) .inner-content.dynamic-gradient-sunset social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-sunset)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-sunset-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-sunset-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-sunset-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-sunset-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-sunset-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-sunset-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-sunset msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-sunset-6)}:host .inner-content.dynamic-gradient-night,:host([background="gradient"]) .inner-content.dynamic-gradient-night social-bar-wc::part(reaction-menu-container){background:var(--background-color-dynamic-gradient-night)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-1)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-2)}:host([layout="compactthumb"][background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-compact-background-gradient-night-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(1) .inline-actions{background:var(--inline-actions-background-gradient-night-1)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(2) .inline-actions{background:var(--inline-actions-background-gradient-night-2)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(3) .inline-actions{background:var(--inline-actions-background-gradient-night-3)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(4) .inline-actions{background:var(--inline-actions-background-gradient-night-4)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(5) .inline-actions{background:var(--inline-actions-background-gradient-night-5)}:host([background="gradient"]) .inner-content.dynamic-gradient-night msft-article.social-reaction-enabled:nth-of-type(6) .inline-actions{background:var(--inline-actions-background-gradient-night-6)}`.withBehaviors(new f.N((0,m.A)` :host{--background-color-dynamic-gradient-morning:linear-gradient(140.53deg,#FFFEDC 9.32%,#FFF4D7 58.45%);--background-color-dynamic-gradient-day:linear-gradient(140.53deg,#F5F7E1 9.32%,#CDF0FF 58.45%);--background-color-dynamic-gradient-sunset:linear-gradient(140.56deg,#F0E1F7 5.42%,#FFE9E1 51.68%);--background-color-dynamic-gradient-night:linear-gradient(140.53deg,#F0E1F7 9.32%,#CDDFFF 58.45%);--inline-actions-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(237,233,203,0) 0.01%,#F2EECF 7.81%,#F2ECCE 66.67%,#F2ECCE 100%);--inline-actions-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(242,233,205,0) 0.01%,#F2E9CD 7.81%,#F2E8CC 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,235,206,0) 0.01%,#F2EBCE 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,238,207,0) 0%,rgba(242,233,205,0) 0.01%,#F2E9CD 7.81%,#F2E8CC 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,232,204,0) 0.01%,#F2E8CC 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-background-gradient-morning-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,232,204,0) 0.01%,#F2E8CC 7.81%,#F2E9CD 66.67%,#F2E8CC 100%);--inline-actions-compact-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,233,203,0) 0.01%,#EDE9CB 7.81%,#EDE6CA 66.67%,#EDE4C9 100%);--inline-actions-compact-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,229,201,0) 0%,#EDE5C9 7.81%,#EDE4C8 66.67%,#EDE3C8 100%);--inline-actions-compact-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,227,200,0) 0%,#EDE3C8 7.81%,#EDE3C8 66.67%,#EDE3C8 100%);--inline-actions-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(219,233,224,0) 0%,#DBE9E0 7.81%,#D4E8E6 66.67%,#D3E7E7 100%);--inline-actions-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(204,230,237,0) 0%,#CCE6ED 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,231,234,0) 0%,#CFE7EA 7.81%,#C7E5EF 66.67%,#C5E5F2 100%);--inline-actions-background-gradient-day-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,229,242,0) 0%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-background-gradient-day-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,231,234,0) 0%,rgba(196,229,242,0) 0.01%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C5E5F2 100%);--inline-actions-background-gradient-day-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,229,242,0) 0%,#C4E5F2 7.81%,#C4E5F2 66.67%,#C4E5F2 100%);--inline-actions-compact-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,#D3E3DE 7.81%,#CCE2E5 66.67%,#C1E0EC 100%);--inline-actions-compact-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(198,225,233,0) 0%,#C6E1E9 7.81%,#C1E0EC 66.67%,#C0E0ED 100%);--inline-actions-compact-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(192,224,237,0) 0%,#C0E0ED 7.81%,#C0E0ED 66.67%,#C0E0ED 100%);--inline-actions-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,218,223,0) 0%,#EDDADF 7.81%,#EEDBDC 66.67%,#EFDBDB 100%);--inline-actions-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(239,220,218,0) 0%,#EFDCDA 7.81%,#F1DDD8 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-background-gradient-sunset-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(242,222,214,0) 0%,#F2DED6 7.81%,#F2DED6 66.67%,#F2DED6 100%);--inline-actions-compact-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(233,214,218,0) 0%,#E9D6DA 7.81%,#EAD8D6 66.67%,#EDDAD1 100%);--inline-actions-compact-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(236,216,213,0) 0%,#ECD8D5 7.81%,#EDDAD1 66.67%,#EDDAD1 100%);--inline-actions-compact-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(237,218,209,0) 0%,#EDDAD1 7.81%,#EDDAD1 66.67%,#EDDAD1 100%);--inline-actions-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(218,214,238,0) 0%,#DAD6EE 7.81%,#D1D5EF 66.67%,#CFD5F0 100%);--inline-actions-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(199,213,242,0) 0%,#C7D5F2 7.81%,#C6D5F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,213,240,0) 0%,#CFD5F0 7.81%,#C7D5F2 66.67%,#C5D5F2 100%);--inline-actions-background-gradient-night-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,212,242,0) 0%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(207,213,240,0) 0%,rgba(196,212,242,0) 0.01%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-background-gradient-night-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(196,212,242,0) 0%,#C4D4F2 7.81%,#C4D4F2 66.67%,#C4D4F2 100%);--inline-actions-compact-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(208,209,233,0) 0%,#D0D1E9 7.81%,#CAD0EB 66.67%,#C1D0ED 100%);--inline-actions-compact-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(200,208,236,0) 0%,#C8D0EC 7.81%,#C0CFED 66.67%,#C0CFED 100%);--inline-actions-compact-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(192,207,237,0) 0%,#C0CFED 7.81%,#C0CFED 66.67%,#C0CFED 100%)}`,(0,m.A)` :host{--background-color-dynamic-gradient-morning:linear-gradient(140.02deg,#464706 -2.33%,#3F2807 84.75%);--background-color-dynamic-gradient-day:linear-gradient(138.52deg,#464706 0.44%,#203A49 83.53%);--background-color-dynamic-gradient-sunset:linear-gradient(139.03deg,#371F42 5.05%,#4A2517 63.37%);--background-color-dynamic-gradient-night:linear-gradient(138.52deg,#512C2C -1.32%,#252C4E 85.77%);--inline-actions-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(81,74,24,0) 0%,#514A18 7.81%,#504718 66.67%,#504618 100%);--inline-actions-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(79,66,24,0) 0%,#4F4218 7.81%,#4F4118 66.67%,#4E3F18 100%);--inline-actions-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(79,69,24,0) 0%,#4F4518 7.81%,#4F4318 66.67%,#4F4118 100%);--inline-actions-background-gradient-morning-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(78,62,24,0) 0%,#4E3E18 7.81%,#4D3B18 66.67%,#4D3A19 100%);--inline-actions-background-gradient-morning-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(78,63,24,0) 0%,#4E3F18 7.81%,#4E3E18 66.67%,#4D3D18 100%);--inline-actions-background-gradient-morning-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(76,56,25,0) 0%,#4C3819 7.81%,#4C3819 66.67%,#4C3819 100%);--inline-actions-compact-background-gradient-morning-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(81,74,24,0) 0.01%,#514A18 7.81%,#504618 66.67%,#4F4118 100%);--inline-actions-compact-background-gradient-morning-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(79,69,24,0) 0.01%,#4F4518 7.81%,#4E4018 66.67%,#4E3E18 100%);--inline-actions-compact-background-gradient-morning-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(78,63,24,0) 0.01%,#4E3F18 7.81%,#4D3D18 66.67%,#4D3919 100%);--inline-actions-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(73,81,43,0) 0.01%,#49512B 7.81%,#455031 66.67%,#424F36 100%);--inline-actions-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(62,77,63,0) 0.01%,#3E4D3F 7.81%,#3A4C45 66.67%,#394C47 100%);--inline-actions-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(63,77,60,0) 0.01%,#424E37 7.81%,#3E4D3D 66.67%,#3D4C41 100%);--inline-actions-background-gradient-day-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(55,76,74,0) 0.01%,#374C4A 7.81%,#354B4D 66.67%,#324A52 100%);--inline-actions-background-gradient-day-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(58,76,70,0) 0.01%,#3A4C46 7.81%,#384C48 66.67%,#354B4D 100%);--inline-actions-background-gradient-day-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(49,73,86,0) 0.01%,#314956 7.81%,#314957 66.67%,#314957 100%);--inline-actions-compact-background-gradient-day-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(70,80,48,0) 0.01%,#465030 7.81%,#414E38 66.67%,#3D4C40 100%);--inline-actions-compact-background-gradient-day-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(63,78,59,0) 0.01%,#3F4E3B 7.81%,#3C4C42 66.67%,#364B4C 100%);--inline-actions-compact-background-gradient-day-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(58,76,70,0) 0.01%,#3A4C46 7.81%,#344A50 66.67%,#314955 100%);--inline-actions-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(77,49,62,0) 0.01%,#4D313E 7.81%,#4F3239 66.67%,#503237 100%);--inline-actions-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(83,51,49,0) 0.01%,#533331 7.81%,#55332E 66.67%,#583428 100%);--inline-actions-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(82,51,51,0) 0.01%,#523234 7.81%,#523234 66.67%,#55332E 100%);--inline-actions-background-gradient-sunset-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(88,52,39,0) 0.01%,#583427 7.81%,#583427 66.67%,#583428 100%);--inline-actions-background-gradient-sunset-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(85,51,45,0) 0.01%,#55332D 7.81%,#583427 66.67%,#583427 100%);--inline-actions-background-gradient-sunset-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(88,52,39,0) 0.01%,#583427 7.81%,#583427 66.67%,#583427 100%);--inline-actions-compact-background-gradient-sunset-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(77,49,62,0) 0.01%,#4D313E 7.81%,#513235 66.67%,#55342D 100%);--inline-actions-compact-background-gradient-sunset-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(82,51,51,0) 0.01%,#523333 7.81%,#56342B 66.67%,#583428 100%);--inline-actions-compact-background-gradient-sunset-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(87,52,42,0) 0.01%,#57342A 7.81%,#583428 66.67%,#583428 100%);--inline-actions-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(80,59,69,0) 0.01%,#503B45 7.81%,#4C3B49 66.67%,#4A3B4B 100%);--inline-actions-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(70,59,77,0) 0.01%,#463B4D 7.81%,#403B51 66.67%,#403B51 100%);--inline-actions-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(73,59,75,0) 0.01%,#493B4B 7.81%,#453B4D 66.67%,#433B4F 100%);--inline-actions-background-gradient-night-4:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(63,59,83,0) 0.01%,#3F3B53 7.81%,#3C3B55 66.67%,#383B58 100%);--inline-actions-background-gradient-night-5:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(67,59,79,0) 0.01%,#433B4F 7.81%,#3E3B54 66.67%,#3D3B54 100%);--inline-actions-background-gradient-night-6:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(54,59,89,0) 0.01%,#363B59 7.81%,#353B5A 66.67%,#353B5A 100%);--inline-actions-compact-background-gradient-night-1:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(77,59,72,0) 0.01%,#4D3B48 7.81%,#483B4C 66.67%,#433B4F 100%);--inline-actions-compact-background-gradient-night-2:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(73,59,76,0) 0.01%,#493B4C 7.81%,#433B4F 66.67%,#3F3B52 100%);--inline-actions-compact-background-gradient-night-3:linear-gradient(var(--inline-actions-dynamic-gradient-angle),rgba(211,227,222,0) 0%,rgba(67,59,79,0) 0.01%,#433B4F 7.81%,#3B3B57 66.67%,#363B59 100%)}`));var I=a(69828),A=a(92011),D=a(38493),z=a(60815);class F extends A.L{constructor(){super(...arguments),this.cardActionMenuHandler=(e,t)=>{e.toggleCardActionMenu&&e.toggleCardActionMenu(e,t)},this.supportedCardSizeTopStoriesCarousel=["_1x_1y","_2x_1y","_3x_1y","_4x_1y"]}layoutChanged(e,t){this.isImageLayout=!1,this.isAttributionLayout=!1,t!==r.RibbonCarousel||this.supportedCardSizeTopStoriesCarousel.find(e=>e===this.cardSize)||(this.cardSize===I.u._1x_2y?this.layout=r.Compact:this.layout=r.Normal),(t===r.Thumbnail||t===r.CompactThumbnail||t===r.RibbonCarousel||t===r.TallRightRail||t===r.RightRail)&&(this.isImageLayout=!0),(t===r.Normal||t===r.Thumbnail||t===r.CompactThumbnail||t===r.RibbonCarousel)&&(this.isAttributionLayout=!0)}backgroundChanged(e,t){e!==t&&(e&&this.$fastController.removeStyles(this.getBackgroundStyles(e)),this.$fastController.addStyles(this.getBackgroundStyles(t)))}getBackgroundStyles(e){switch(e){case o.InheritSection:return T;case o.Gradient:return S;default:return $}}getDynamicGradientColor(){if(!this.useGradientBackground)return"";this.$fastController.addStyles(_);let e=new Date().getHours();return e>=6&&e<12?"dynamic-gradient-morning":e>=12&&e<17?"dynamic-gradient-day":e>=17&&e<22?"dynamic-gradient-sunset":"dynamic-gradient-night"}connectedCallback(){super.connectedCallback()}disconnectedCallback(){super.disconnectedCallback()}scrollToPrevious(){if(this.enableFeeds2Carousel){let e=this.getCurrentScrollIndex();this.horizontalScroll.scrollToPosition(this.scrollStops[e-2>0?e-2:0],this.horizontalScroll.scrollContainer.scrollLeft)}else this.horizontalScroll.scrollToPrevious()}scrollToNext(){if(this.enableFeeds2Carousel){let{scrollItems:e,scrollContainer:{scrollLeft:t}}=this.horizontalScroll,a=this.getCurrentScrollIndex(),i=a+2<e.length-1?a+2:e.length-1;this.horizontalScroll.scrollToPosition(this.scrollStops[i],t)}else this.horizontalScroll.scrollToNext()}getCurrentScrollIndex(){let{scrollContainer:e}=this.horizontalScroll,t=e.scrollLeft;return this.scrollStops||this.saveScrollStops(),this.scrollStops.findIndex(e=>Math.abs(e)>=Math.abs(t))}saveScrollStops(){let{scrollItems:e}=this.horizontalScroll;this.scrollStops=e.map((e,t)=>280*t),this.scrollStops.push((e.length-1)*280+272)}}(0,l.Cg)([(0,D.CF)({attribute:"is-anaheim-design",mode:"boolean"})],F.prototype,"isAnaheimDesign",void 0),(0,l.Cg)([(0,D.CF)({attribute:"is-anaheim-infopane",mode:"boolean"})],F.prototype,"isAnaheimInfopane",void 0),(0,l.Cg)([(0,D.CF)({attribute:"disable-inline-action",mode:"boolean"})],F.prototype,"disableTopStoriesInlineAction",void 0),(0,l.Cg)([(0,D.CF)({attribute:"card-heading"})],F.prototype,"cardHeading",void 0),(0,l.Cg)([(0,D.CF)({attribute:"card-heading-link"})],F.prototype,"cardHeadingLink",void 0),(0,l.Cg)([(0,D.CF)({attribute:"card-tooltip"})],F.prototype,"tooltip",void 0),(0,l.Cg)([(0,D.CF)({attribute:"feeds-2-carousel",mode:"boolean"})],F.prototype,"enableFeeds2Carousel",void 0),(0,l.Cg)([(0,D.CF)({attribute:"prong2-dynamic-feed",mode:"boolean"})],F.prototype,"isDynamicFeed",void 0),(0,l.Cg)([(0,D.CF)({attribute:"prong2-dynamic-gradient-background",mode:"boolean"})],F.prototype,"useGradientBackground",void 0),(0,l.Cg)([D.CF],F.prototype,"target",void 0),(0,l.Cg)([z.sH],F.prototype,"cardData",void 0),(0,l.Cg)([z.sH],F.prototype,"headingTelemetryTag",void 0),(0,l.Cg)([z.sH],F.prototype,"flipperNextTelemetryTag",void 0),(0,l.Cg)([z.sH],F.prototype,"fliperPreviousTelemetryTag",void 0),(0,l.Cg)([z.sH],F.prototype,"cardVersionTelemetryTag",void 0),(0,l.Cg)([z.sH],F.prototype,"subCardTelemetryTag",void 0),(0,l.Cg)([z.sH],F.prototype,"isSpotlightUX",void 0),(0,l.Cg)([z.sH],F.prototype,"spotlightBreakingNewsTagString",void 0),(0,l.Cg)([(0,D.CF)({attribute:"card-size"})],F.prototype,"cardSize",void 0),(0,l.Cg)([D.CF],F.prototype,"layout",void 0),(0,l.Cg)([D.CF],F.prototype,"background",void 0),(i=r||(r={})).Compact="compact",i.CompactThumbnail="compactthumb",i.TallRightRail="tallrightrail",i.RightRail="rightrail",i.Normal="normal",i.Stacked="stacked",i.Thumbnail="thumb",i.RibbonCarousel="ribbonCarousel",(n=o||(o={})).Normal="normal",n.Gradient="gradient",n.InheritSection="inheritSection";var R=a(44776),L=a(89757),M=a(69259),E=a(60402),B=a(68835),P=a(44978),O=a(58759),N=a.n(O),H=a(30576),q=a.n(H),W=a(33307),K=a(33744),U=a(54694),V=a(9960);let j={[r.Compact]:3,[r.CompactThumbnail]:3,[r.RightRail]:3,[r.TallRightRail]:4,[r.Normal]:6,[r.Stacked]:6,[r.Thumbnail]:6},G={[I.u._1x_2y]:[52,52],[I.u._1x_3y]:[76,76],[I.u._2x_2y]:[59,59],[I.u._3x_2y]:[72,72]},X=(0,L.qy)`
${(0,M.z)(e=>e.enableRichSocialReaction,(0,L.qy)`<span class="divider"></span>`)}<fluent-button class="actions-button" aria-expanded="false" aria-label="${e=>e.cardActionsTooltips&&e.cardActionsTooltips.seeMore}" role="button" title="${e=>e.cardActionsTooltips&&e.cardActionsTooltips.seeMore}" @click=${(e,t)=>t.parent.cardActionMenuHandler&&t.parent.cardActionMenuHandler(e,t.event)} @keypress=${(e,t)=>t.parent.cardActionMenuHandler&&t.parent.cardActionMenuHandler(e,t.event)} data-t="${e=>e.telemetryContext?.seeMore?.getMetadataTag()}">${e=>(0,L.qy)`${L.qy.partial(W.A)}`}</fluent-button>`,J=(0,L.qy)`<div id="inline-actions" class="inline-actions">${(0,M.z)(e=>e.enableRichSocialReaction,(0,R.nj)({theme:"topStories"}))} ${(0,M.z)(e=>e.cardActionStatus&P.J.enabled,X)}</div>`,Z=(0,L.qy)`<msft-article role="listitem" href=${e=>e.destinationUrl} title=${e=>e.disableCardTitleTooltip&&!e.disableTitleOnArticleCardOnly?"":e.title} target=${e=>e.openLinksInNewTab||e.openArticleInNewTab?"_blank":e.defaultAnchorTarget||"_self"} data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}" :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()} :handleContentCardClickOverride=${e=>e.handleContentCardClickOverride} class=${(e,t)=>`${e.isWebContent?"crawled-content":""} ${e.enableRichSocialReaction?"social-reaction-enabled":""} ${e.isWebContent?"stacked-fromweb":""} ${e.enableFilledIconOnHover?"filled-icon-hover":""}`}>${(e,t)=>{var a;return(a=t.parent.layout)===r.Normal||a===r.Stacked||a===r.CompactThumbnail||a===r.Thumbnail||a===r.RibbonCarousel?(0,L.qy)`<span slot="attribution">${(0,M.z)(e=>e.providerData&&e.providerData.logoImage,(0,L.qy)`<img slot="image" class="attribution-provider-logo" src="${e=>e.providerData.logoImage}" alt="${e=>e.providerData.name}" />`)}</span>`:(0,L.qy)`<msft-attribution slot="attribution" class="${e=>e.isProviderIconClickable?"attribution-provider-clickable":""}">${(0,M.z)(e=>e.providerData&&e.providerData.logoImage,(0,L.qy)` ${(0,M.z)(e=>e.isProviderIconClickable&&e.providerData.profileId,(0,L.qy)`<a class="attribution-icon-clickable" tabindex="-1" title="${e=>e.providerData.name}" href=${e=>Y(e.providerData.profileId)} target="_blank" data-t="${e=>e.telemetryContext?.clickableProviderIcon?.getMetadataTag()}"><div style="display: inline-flex;align-items: center"><img slot="image" tabindex="0" class="attribution-provider-logo" src="${e=>e.providerData.logoImage}" alt="${e=>e.providerData.name}" /><span class="attribution-provider-name attribution-provider-logo-available" tabindex="0">${e=>e.providerData.name}</span><span class="attribution-published-time">·</span><span>${e=>e.publishedDateTime}</span></div></a>`)} ${(0,M.z)(e=>!e.isProviderIconClickable||!e.providerData.profileId,(0,L.qy)`<img slot="image" class="attribution-provider-logo" src="${e=>e.providerData.logoImage}" alt="${e=>e.providerData.name}" /></a>`)} `)} ${(0,M.z)(e=>e.isProviderIconClickable&&e.providerData&&!e.providerData.logoImage,(0,L.qy)` ${(0,M.z)(e=>e.providerData.name&&e.providerData.profileId,(0,L.qy)`<a class="attribution-icon-clickable" tabindex="-1" title="${e=>e.providerData.name}" href=${e=>Y(e.providerData.profileId)} target="_blank" data-t="${e=>e.telemetryContext?.clickableProviderIcon?.getMetadataTag()}"><div style="display: inline-flex;align-items: center"><span class="attribution-provider-name" tabindex="0">${e=>e.providerData.name}</span>${(0,M.z)(e=>e.publishedDateTime,(0,L.qy)`<span class="attribution-published-time">·</span><span>${e=>e.publishedDateTime}</span>`)}</div></a>`)} `)} ${(0,M.z)(e=>!e.isProviderIconClickable||!e.providerData.profileId,(0,L.qy)`<span class="attribution-provider-not-clickable">${(0,M.z)(e=>e.providerData&&e.providerData.name,(0,L.qy)`<span style="unicode-bidi:embed">${e=>e.providerData.name}</span>`)} ${(0,M.z)(e=>e.providerData&&e.providerData.name&&e.publishedDateTime,(0,L.qy)` · `)} ${(0,M.z)(e=>e.publishedDateTime,(0,L.qy)`${e=>e.publishedDateTime}`)}</span>`)}</msft-attribution>`}}<div slot="start-action" style="gap:0">${(0,M.z)((e,t)=>!t.parent.disableTopStoriesInlineAction,J)}</div>${(0,M.z)((e,t)=>t.parent.isDynamicFeed&&t.parent.isSpotlightUX&&0===t.index,(0,L.qy)`<fluent-badge class="ts-breaking-news-tag" appearance="accent">${(e,t)=>t.parent.spotlightBreakingNewsTagString}</fluent-badge>`)} ${e=>e.title} ${(0,M.z)((e,t)=>e.isWebContent,(0,L.qy)`<span slot="abstract">${e=>e.crawledContentLabel}</span>`)} ${(0,M.z)((e,t)=>!(e.isWebContent&&t.parent.cardSize!==I.u._3x_2y)&&(t.parent.layout===r.Thumbnail||t.parent.layout===r.Normal)&&e.abstract,(0,L.qy)`<p slot="abstract">${e=>e.abstract}</p>`)} ${(0,M.z)((e,t)=>e.imageData&&t.parent.isImageLayout,(0,L.qy)` ${(e,t)=>(function(e,t,a,i){let{articleCardBackgroundColor:n,imageData:o}=e,l=G[t]||[72,72];a===r.RightRail&&(l=[62,62]),a===r.RibbonCarousel&&(l=i?[68,80]:[60,60]);let s=n&&n.find(e=>e.isDarkMode===(0,V.ud)())?.hexColor,d=(0,U.oQ)(o.source,{width:l[0],height:l[1],enableDpiScaling:!1,quality:90});return(0,L.qy)`<div slot="image" class="image"><img style="background: ${s}" height=${l[1]}, width=${l[0]}, alt="${o.altText}" src="${d}" /></div>`})(e,t.parent.cardSize,t.parent.layout,t.parent.enableFeeds2Carousel)} `)} ${(0,M.z)((e,t)=>t.parent.isAttributionLayout,(0,L.qy)`<msft-attribution slot="start-action"><span>${(0,M.z)(e=>e.providerData&&e.providerData.name,(0,L.qy)`<span style="unicode-bidi:embed">${e=>e.providerData.name}</span>`)} ${(0,M.z)((e,t)=>e.providerData&&e.providerData.name&&e.isWebContent&&t.parent.cardSize===I.u._3x_2y,(0,L.qy)` · `)} ${(0,M.z)((e,t)=>e.isWebContent&&t.parent.cardSize===I.u._3x_2y,(0,L.qy)`${e=>e.crawledContentLabel}`)} ${(0,M.z)((e,t)=>(e.providerData&&e.providerData.name||e.isWebContent&&t.parent.cardSize===I.u._3x_2y)&&e.publishedDateTime,(0,L.qy)` · `)} ${(0,M.z)(e=>e.publishedDateTime,(0,L.qy)`${e=>e.publishedDateTime}`)}</span></msft-attribution>`)}</msft-article>`;function Y(e){return`https://www.msn.com/${K.T3.CurrentMarket}/community/channel/${e}`}let Q=(0,L.qy)`<fluent-horizontal-scroll aria-hidden="false" class="horizontal-scroll" speed="1500" easing="ease-in-out" ${(0,E.K)("horizontalScroll")}><fluent-flipper slot="previous-flipper" direction="previous" part="flipper-previous" class="previous" @click="${e=>e.scrollToPrevious()}" data-t="${e=>e.fliperPreviousTelemetryTag}">${(0,M.z)(e=>"rtl"===document.dir&&!e.enableFeeds2Carousel,(0,L.qy)`<svg slot="previous" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"></path></svg>`)} ${(0,M.z)(e=>e.enableFeeds2Carousel,(0,L.qy)`<div slot="previous">${e=>"rtl"===document.dir?(0,L.qy)`${L.qy.partial(q())}`:(0,L.qy)`${L.qy.partial(N())}`}</div>`)}</fluent-flipper><fluent-flipper slot="next-flipper" direction="next" part="flipper-next" class="next" @click="${e=>e.scrollToNext()}" data-t="${e=>e.flipperNextTelemetryTag}">${(0,M.z)(e=>"rtl"===document.dir&&!e.enableFeeds2Carousel,(0,L.qy)`<svg slot="next" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="red"><path d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"></path></svg>`)} ${(0,M.z)(e=>e.enableFeeds2Carousel,(0,L.qy)`<div slot="next">${e=>"rtl"===document.dir?(0,L.qy)`${L.qy.partial(N())}`:(0,L.qy)`${L.qy.partial(q())}`}</div>`)}</fluent-flipper>${(0,B.ux)(e=>e.cardData,Z)}</fluent-horizontal-scroll>`,ee=(0,L.qy)`<div data-t="${e=>e.cardVersionTelemetryTag}" style="display: flex; width: 100%;" class="${e=>e.isDynamicFeed&&e.isSpotlightUX?"spotlight-flash-bg":""}" animation-name="${e=>e.isDynamicFeed?"spotlight-ts-bg-animation, none":""}"><div :classList="inner-content ${e=>e.getDynamicGradientColor()}" data-t="${e=>e.subCardTelemetryTag}">${(0,M.z)(e=>e.cardHeading,(0,L.qy)`<div :classList="heading-container ${e=>e.isAnaheimInfopane?"anaheim-infopane":""}">${e=>e.cardHeadingLink?(0,L.qy)`<a class="heading heading-link" href=${e=>e.cardHeadingLink} target=${e=>e.target} data-t="${e=>e.headingTelemetryTag}">${(0,M.z)(e=>e.enableFeeds2Carousel,(0,L.qy)`${L.qy.partial('<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2.5" y="4.33" width="12.67" height="8.67" rx="2" fill="url(#paint0_linear_1770_321358)"/><rect x="2.5" y="4.33" width="12.67" height="8.67" rx="2" fill="url(#paint1_linear_1770_321358)" fill-opacity=".5"/><path d="M.5 4.33c0-1.1.9-2 2-2h8.73a2 2 0 0 1 2 2v7.49c0 1.12.6 1.18.6 1.18H2.5a2 2 0 0 1-2-2V4.33Z" fill="url(#paint2_linear_1770_321358)"/><rect x="7.83" y="6.33" width="4" height="1.33" rx=".67" fill="#EDFCFF"/><rect x="7.83" y="9" width="4" height="2" rx="1" fill="#EDFCFF"/><rect x="1.83" y="6.33" width="4.67" height="4.67" rx="1" fill="#EDFCFF"/><rect x="1.83" y="3.67" width="10" height="1.33" rx=".67" fill="#EDFCFF"/><defs><linearGradient id="paint0_linear_1770_321358" x1="6.5" y1="4.62" x2="13.94" y2="14.21" gradientUnits="userSpaceOnUse"><stop stop-color="#007BBC"/><stop offset="1" stop-color="#155AA8"/></linearGradient><linearGradient id="paint1_linear_1770_321358" x1="13.39" y1="10.09" x2="15.21" y2="9.98" gradientUnits="userSpaceOnUse"><stop/><stop offset=".27" stop-opacity="0"/></linearGradient><linearGradient id="paint2_linear_1770_321358" x1="13.17" y1="13" x2="-.64" y2="3.74" gradientUnits="userSpaceOnUse"><stop stop-color="#358ADC"/><stop offset="1" stop-color="#20B2C6"/></linearGradient></defs></svg>')}`)} ${e=>e.cardHeading}</a>`:(0,L.qy)`<h3 class="heading">${e=>e.cardHeading}</h3>`} ${(0,M.z)(e=>e.tooltip,(0,L.qy)`<div class="heading-icon-container" role="tooltip" tabindex="0" aria-describedby="#tooltip">${L.qy.partial('<svg viewBox="0 0 12 12" width="14" height="13" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 0H8.5C8.77614 0 9 0.223858 9 0.5V3H10C11.1046 3 12 3.89543 12 5V10C12 11.1046 11.1046 12 10 12H2C0.89543 12 0 11.1046 0 10V5C0 3.89543 0.895431 3 2 3H3V0.5C3 0.223858 3.22386 0 3.5 0ZM8 3V1H4V3H8ZM2 4C1.44772 4 1 4.44772 1 5V10C1 10.5523 1.44772 11 2 11H10C10.5523 11 11 10.5523 11 10V5C11 4.44772 10.5523 4 10 4H2Z"/></svg>')}<span id="tooltip" class="icon-tooltip">${e=>e.tooltip}</span></div>`)}</div><slot name="ngbutton"></slot><slot name="ngmenu"></slot>`)} ${(0,M.z)(e=>e.layout===r.RibbonCarousel,Q)} ${(0,M.z)(e=>e.layout!==r.RibbonCarousel,(0,L.qy)`<div role="list" style="display: contents;">${(0,B.ux)(e=>j[e.layout]?e.cardData.slice(0,j[e.layout]):e.cardData,Z,{positioning:!0})}</div>${(0,M.z)(e=>e.isAnaheimInfopane,(0,L.qy)`<div class="anaheim-infopane-bottom-padding"></div>`)} `)}</div></div>`,et=class extends F{};et=(0,l.Cg)([(0,A.E)({name:"msn-top-stories",template:ee,styles:k})],et);let ea=(0,L.qy)`
<fluent-card style="grid-area:${e=>e.gridArea}; ${e=>e.isDynamicFeed?"border-radius: 8px":""}">
    <msn-top-stories
        class=${e=>e.isAnaheimDesign?"infopane-anaheim-design":""}
        card-size=${e=>e.cardSize}
        card-heading=${e=>e.topStoriesHeadingText}
        card-tooltip=${e=>e.tooltip}
        card-heading-link=${e=>e.headingLink}
        is-anaheim-design=${e=>e.isAnaheimDesign}
        is-anaheim-infopane=${e=>e.isAnaheimInfopane}
        disable-inline-action=${e=>e.disableTopStoriesInlineAction}
        feeds-2-carousel=${e=>e.enableFeeds2TopStoriesCarousel}
        prong2-dynamic-feed=${e=>e.isDynamicFeed}
        prong2-dynamic-gradient-background=${e=>e.useGradientBackground}
        layout=${e=>e.cardLayout}
        background=${e=>e.cardBackground}
        target=${e=>e.openLinksInNewTab?"_blank":"_self"}
        :cardData=${e=>e.listCardData}
        :headingTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.headingClick&&e.telemetryContext.headingClick.getMetadataTag()}
        :flipperNextTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.flipperNextClick&&e.telemetryContext.flipperNextClick.getMetadataTag()}
        :fliperPreviousTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.flipperPreviousClick&&e.telemetryContext.flipperPreviousClick.getMetadataTag()}
        :cardVersionTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.cardVersion&&e.telemetryContext.cardVersion.getMetadataTag()}
        :subCardTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.subCard&&e.telemetryContext.subCard.getMetadataTag()}
        :isSpotlightUX=${e=>e.isSpotlightUX}
        :spotlightBreakingNewsTagString=${e=>e.spotlightBreakingNewsTagString}
        data-t="${e=>e.telemetryContext?.topStoriesCard?.getMetadataTag()}"
    >
    </msn-top-stories>
</fluent-card>
`},96245(e,t,a){"use strict";a.d(t,{t:()=>s});var i=a(56525),n=a(87906),r=a(40450),o=a(98794),l=a(3006);let s={getFeedDataForCard:e=>(function(e){try{let{cardMetadata:t,configOptions:a,parentTelemetryObject:i,hasLoadedCallback:l}=e,s=a&&a;try{return(0,o.bw)({id:"travelDestination",experienceType:s?.configRef?.experienceType,mapperArgs:e},{id:"travelDestination",childTemplateType:"travel-destination-card",configInfo:s,mapperArgs:e,parentTelemetryObject:i,hasLoadedCallback:l},null,!0)}catch(t){(0,n.vV)(r.OV,`Error in populating layouts and position telemetry = ${JSON.stringify(e)}`)}}catch(t){(0,n.vV)(r.OV,`Error in feed layout mapperargs = ${JSON.stringify(e)}`)}return(0,l.wc)()})(e),viewTemplate:i.T}},56525(e,t,a){"use strict";var i=a(89757),n=a(94172);let r=(0,i.qy)`
${e=>(0,n.yN)(e.configInfo,{includeTelemetryTag:!1,properties:{parentTelemetry:e.parentTelemetryObject,wpoMetadata:e.wpoMetadata,cardSize:e.cardSize,mapperArgs:e.mapperArgs,refreshSDCardSection:e.mapperArgs?.refreshSDCardSection,goToPersonalizeSettingsCallback:e.mapperArgs?.goToPersonalizeSettingsCallback,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain: unset;content-visibility: visible;`,class:`${e.cardSize} travel-destination-card-container`}})}
`;a.d(t,{},{T:r})},95583(e,t,a){"use strict";a.d(t,{O:()=>r});var i=a(13162),n=a(98794);let r={getFeedDataForCard:e=>(function(e){let{cardMetadata:t,parentTelemetryObject:a,configOptions:i}=e,r=i&&(i.childExperienceReferencesWC&&(i.childExperienceReferencesWC.videoCard||i.childExperienceReferencesWC.videoCardWC)||i.childExperienceReferences&&(i.childExperienceReferences.videoCard||i.childExperienceReferences.videoCardWC)),o=i&&(i.childExperienceReferencesWC&&i.childExperienceReferencesWC.socialBarWC||i.childExperienceReferences&&i.childExperienceReferences.socialBarWC),l={childTemplateType:"video-card",contentId:t?.cardContent?.id,id:t?.cardContent?.id??"videoCard",parentTelemetryObject:a,videoCardConfigInfo:r,socialBarWCConfigInfo:o,videoCardProps:{posterUrl:Array.isArray(t?.cardContent?.images)?t.cardContent.images[0]?.url:void 0}};return(0,n.bw)({id:"video-card",experienceType:r?.configRef?.experienceType,mapperArgs:e},l)})(e),viewTemplate:i.Q}},13162(e,t,a){"use strict";a.d(t,{Q:()=>E});var i=a(56911),n=a(92011),r=a(59669);let o=(0,r.A)` msft-article-card.mobile,msft-article-card.mobile *{-webkit-tap-highlight-color:transparent;outline:none;-ms-touch-action:manipulation;touch-action:manipulation}.card-button{border-radius:100%}msft-article.vertical-gradient::part(text){margin-bottom:0px;height:148px;padding:12px calc(var(--msft-article-padding) * 1px) 16px}@media (forced-colors:active){.card-button{background:none}msn-social-bar::part(button-bg),msn-social-bar::part(reactions-count-button),msn-social-bar::part(comments-count-button){color:buttontext;background-color:buttonface}msn-social-bar::part(button-bg):hover,msn-social-bar::part(button-bg):focus-visible,msn-social-bar::part(reactions-count-button):hover,msn-social-bar::part(reactions-count-button):focus-visible,msn-social-bar::part(comments-count-button):hover,msn-social-bar::part(comments-count-button):focus-visible{color:buttonface;background-color:highlight}}msft-article span.title_1x_2y,msft-article span.title_2x_2y{font-size:20px}msft-article.no-image::part(heading){font-size:var(--msft-article-heading-font-size,20px);line-height:var(--msft-article-heading-line-height,28px)}msft-article-card[size="_1x_2y"] msft-article.no-image msft-attribution{margin-bottom:18px}msft-article.long-gradient::part(gradient){top:-55px}msft-article-card[size="_1x_2y"] .video-card-embed{position:relative}msft-article-card[size="_2x_2y"] .video-card-embed{position:relative}msft-article-card[size="_1x_2y"] msft-article.videocard .video-card-embed .hover-mask{display:none;width:100%;height:79px;background:var(--fill-color);position:absolute;bottom:0px;z-index:10}msft-article-card[size="_1x_2y"] msft-article.videocard.videocard-hover .video-card-embed .hover-mask{display:block}msft-article-card msft-article.hide-non-image::part(text),msft-article-card msft-article.hide-non-image::part(hide-story-wrapper){display:none}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient::part(heading){line-height:var(--heading-line-height,28px)}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(heading){margin-bottom:40px}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(gradient){background:linear-gradient( 180deg,transparent 0%,var(--gradient-mid-color) 62.5%,var(--gradient-color) 100% );width:100%}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(text){height:auto;width:100%}msft-article-card[size="_2x_2y"].contentCard msft-article.vertical-gradient:not(.no-image)::part(attribution){display:flex;align-self:end}msft-article-card[size="_2x_2y"].contentCard msft-attribution{margin-bottom:8px}msft-article div.infopane-like-end-actions{display:flex}.video-play-button-container{border-radius:50%;display:block;height:40px;left:50%;opacity:1;padding:0;position:absolute;top:50%;transform:translate(-50%,-50%);transition:all 0.4s ease 0s;width:40px}.video-play-button{align-items:center;display:flex;height:100%;justify-content:center;width:100%}.video-experience-placeholder{background:0px 0px rgba(0,0,0,0.6);display:block;left:0;position:relative;top:0;z-index:1}msft-article-card[size="_2x_2y"].no-gradient .video-experience-placeholder{height:304px}.video-experience-placeholder.hidden{z-index:0;opacity:0}.video-experience-container{position:absolute;right:0px;top:0px;z-index:0}msft-article-card.mobile msft-article::part(image){width:100%;opacity:1}msft-article-card.mobile msft-article::part(text){margin-bottom:-6px;padding-top:0}msft-article-card.mobile .infopane-like-end-actions{border-radius:50%;border:none;background-color:transparent;fill:var(--neutral-foreground-rest);margin-top:0px;margin-inline:4px -5px}msft-article-card.mobile .infopane-like-start-actions{height:32px;margin-inline-start:-8px}msft-article-card.mobile msft-article::part(heading){fill:currentcolor;display:-webkit-box;outline:0px;overflow:hidden;text-decoration:none;-webkit-line-clamp:3;-webkit-box-orient:vertical;font-weight:600;height:72px;margin-bottom:10px}msft-article-card.mobile msft-article .heading-title-content{font-size:18px !important;line-height:24px !important}msft-article-card.mobile msft-article .video-experience-placeholder{height:170px;overflow:hidden}msft-article-card.mobile msft-article msft-attribution{margin-bottom:8px}`;var l=a(11803),s=a(62679),d=a(69828),c=a(35177),p=a(44776),g=a(26330),u=a(47517),m=a(89757),h=a(69259),b=a(68835),f=a(9960),y=a(44978),v=a(94172);let C=(e,t)=>{if(globalThis.videoCards||(globalThis.videoCards={}),globalThis.videoCards[e.id])return globalThis.videoCards[e.id];{let a=`${e.cardSize} vertical_gradient`,i=(0,v.yN)(e.videoCardConfigInfo,{memoize:!1,properties:{id:e.id,context:{cardData:e,customStyleClass:a,eventsCallback:t.parent.eventsCallback,previewEndCallback:t.parent.previewEndCallback}}});return globalThis.videoCards[e.id]=i,i}},x=(0,m.qy)`<div><span class="video-play-button-container"><svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" slot="icon"><g filter="url(#filter0_b_1234_35012)"><circle cx="20" cy="19.9991" r="19" fill="url(#paint0_linear_1234_35012)" /><circle cx="20" cy="19.9991" r="19.5" stroke="url(#paint1_linear_1234_35012)" /></g><path d="M27.2221 18.6837C28.2586 19.2535 28.2586 20.7429 27.2221 21.3127L17.2226 26.8096C16.2229 27.3591 15 26.6359 15 25.4951L15 14.5013C15 13.3605 16.2229 12.6373 17.2226 13.1868L27.2221 18.6837Z" fill="white" /><defs><filter id="filter0_b_1234_35012" x="-10" y="-10.0009" width="60" height="60" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix" /><feGaussianBlur in="BackgroundImage" stdDeviation="5" /><feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_1234_35012" /><feBlend mode="normal" in="SourceGraphic" in2="effect1_backgroundBlur_1234_35012" result="shape" /></filter><linearGradient id="paint0_linear_1234_35012" x1="1" y1="0.999146" x2="39" y2="38.9991" gradientUnits="userSpaceOnUse"><stop stop-opacity="0.5" /><stop offset="1" stop-opacity="0.7" /></linearGradient><linearGradient id="paint1_linear_1234_35012" x1="20" y1="0.999146" x2="20" y2="38.9991" gradientUnits="userSpaceOnUse"><stop stop-color="white" stop-opacity="0.4" /><stop offset="1" stop-color="white" stop-opacity="0.2" /></linearGradient></defs></svg></span><img alt="${e=>e.imageData&&e.imageData.altText}" src="${e=>e.imageData&&e.imageData.source}" height="${e=>e.imageData&&w(e)}" width="${e=>e.imageData&&e.imageData.imageWidth}" @load="${(e,t)=>{e.imageData&&e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(3,l.j.image),t.parent.setPlaceholderRendered()}}" @error="${(e,t)=>{e.imageData&&e.imageData.source&&t.parent.error(e.imageData.source)}}" /></div>`,w=e=>{if(e.useMobile){let{imageHeight:t}=e.displaySettings;return document.body.style.setProperty("--displaySettingsImageHeight",`${t}px`),t}return e.imageData.imageHeight},k=(0,m.qy)`<div slot="image" class="video-card-embed" style="height: ${e=>e.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;"><div class="hover-mask"></div><div class="video-experience-placeholder ${(e,t)=>t.parent.playerPlaying?"hidden":""}" style="${e=>`height: ${w(e)}px`}">${x}</div><div class="video-experience-container">${(0,h.z)((e,t)=>t.parent.placeholderRendered,C)}</div></div>`,$=(0,m.qy)`<fluent-card class="${e=>e.cardSize}">${(e,t)=>C(e,t)}</fluent-card>`,S=(0,m.qy)`<style>msft-article-card[size$="x_2y"] msft-article::part(heading):after { top: calc(100% - ${e=>e.fixedCardHeight?304:292+(e.layoutGap||12)}px - 8px) !important;
} msft-article::part(text) { margin-bottom: -8px;
} msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) { top: -29px; bottom: ${e=>e.fixedCardHeight?78:66+(e.layoutGap||12)}px;
} msft-article.no-image::part(actions) { bottom: calc(var(--msft-article-padding) * 1px - 8px);
}</style><msft-article-card size="${e=>e.cardSize}" card-fill-color="${e=>e.disableColorSampling?(0,f.ud)()?"#333":"#FFF":e.enableFeedSuperCardsSingleColor?(0,f.ud)()||(0,f.r0)(e)?"#292929":"#FFFFFF":e.articleCardBackgroundColor?.find(t=>t.isDarkMode===((0,f.ud)()||(0,f.r0)(e)))?.hexColor}" class="contentCard no-gradient ${e=>e.useMobile?"mobile":""}" data-badge-type="${e=>e.badge&&e.badge.type}" style="${e=>e.useMobile?`--card-height:${e.displaySettings.cardHeight}px;--card-width:${e.displaySettings.cardWidth}px`:""}"><msft-article id="contentcard_${e=>e.id}" href=${e=>e.destinationUrl} target="_blank" title=${e=>e.disableCardTitleTooltip?"":e.title} style="--heading-max-lines: 2;" class="vertical-gradient ${(e,t)=>t.parent.useVideoTemplate?"videocard":""} ${(e,t)=>t.parent.isHoverVideo?"videocard-hover":""} ${(e,t)=>t.parent.useVideoTemplate&&!t.parent.isHoverVideo?"hide-non-image":""}" data-t="${e=>e.telemetryContext&&e.telemetryContext.contentCard&&e.telemetryContext.contentCard.getMetadataTag()}" :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()} @mouseover="${(e,t)=>t.parent.mouseenterHandler&&t.parent.mouseenterHandler(t.event)}" @mouseleave="${(e,t)=>t.parent.mouseleaveHandler&&t.parent.mouseleaveHandler(t.event)}" @click="${(e,t)=>t.parent.clickHandler(e,t)}">${(0,h.z)(e=>e.providerData,(0,m.qy)`<msft-attribution slot="${e=>e.isProviderInFooter?"start-actions":"attribution"}" style="${e=>e.isProviderInFooter?"gap:0":""}">${(0,s.mt)()}<div class="attribution_container_${e=>e.id}" id="attribution_container"><div class="attribution_Content_${e=>e.id}" style="${e=>"rtl"===e.dir?"right":"left"}:0px;">${(0,h.z)(e=>e.providerData&&e.providerData.name&&!e.isProviderIconClickable,(0,m.qy)`<span style="unicode-bidi: embed;">${e=>e.providerData.name}</span>`)} ${(0,h.z)(e=>e.providerData&&e.providerData.name&&e.publishedDateTime,(0,m.qy)` · `)} ${(0,h.z)(e=>e.publishedDateTime,(0,m.qy)`<span style="unicode-bidi: embed;">${e=>e.publishedDateTime}</span>`)} ${(0,h.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,m.qy)` · `)} ${(0,h.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,m.qy)`${e=>e.crawledContentLabel}`)}</div></div></msft-attribution>`)} ${(0,h.z)((e,t)=>!t.parent.isPreviewable(e.metadata),(0,m.qy)`<div slot="image" class="video-card-embed" style="height: ${e=>e.imageData&&e.imageData.imageHeight}px; position: relative; z-index: 0; overflow: hidden;">${x}</div>`)} ${(0,h.z)((e,t)=>t.parent.isPreviewable(e.metadata),k)} ${(0,h.z)(e=>e.feedFontSize,(0,m.qy)` ${(0,h.z)(e=>(e.cardSize===d.u._1x_2y||e.cardSize===d.u._1x_1y)&&e.imageData,(0,m.qy)`<span class="heading-title-content" style="font-size: ${e=>e.feedFontSize}px; ${e=>e.headingLineHeight?`line-height: ${e.headingLineHeight}px`:""}">${e=>e.title}</span>`)} ${(0,h.z)(e=>e.cardSize===d.u._2x_2y,(0,m.qy)`<span style="font-size: ${e=>e.twoColumnFeedFontSize||e.largeFeedFontSize||e.feedFontSize}px; ${e=>e.twoColumnHeadingLineHeight?`line-height: ${e.twoColumnHeadingLineHeight}px`:""}">${e=>e.title}</span>`)} ${(0,h.z)(e=>(e.cardSize===d.u._1x_2y||e.cardSize===d.u._1x_1y)&&!e.imageData,(0,m.qy)`<span style="font-size: ${e=>e.noImageFeedFontSize||e.feedFontSize}px;">${e=>e.title}</span>`)} `)} ${(0,h.z)(e=>!e.feedFontSize,(0,m.qy)` ${(0,h.z)(e=>!e.useLargeFontSize,(0,m.qy)`${e=>e.title}`)} ${(0,h.z)(e=>e.useLargeFontSize,(0,m.qy)`<span class="title${e=>e.cardSize}">${e=>e.title}</span>`)} `)} ${(0,h.z)(e=>e.badge&&e.cardSize!==d.u._1x_1y,e=>(0,c.w)(e.badge,!0,!1))}<div slot="start-action" class="infopane-like-start-actions">${(0,h.z)(e=>e.providerData&&e.enableInfopaneLike2cCard&&e.cardSize===d.u._2x_2y,s.QQ)} ${(0,h.z)(e=>(!e.enableInfopaneLike2cCard||e.cardSize!==d.u._2x_2y)&&(!e.isAnaheimDesign||e.enableRichSocialReaction),(0,m.qy)` ${(0,h.z)(e=>e.enableRichSocialReaction&&!e.isLauncher,e=>(0,p.nj)({theme:e.useMobile&&!e.isMsnMobile&&"superappDefaultNewFeed",hideComments:e.useMobile&&!e.isMsnMobile}))} ${(0,h.z)(e=>e.cardActionStatus&y.J.enabled&&!e.enableRichSocialReaction,(0,m.qy)` ${p.LW} ${(0,h.z)(e=>!(e.cardActionStatus&y.J.showMore),p.tB)} `)} `)}</div><div slot="end-action" class="infopane-like-end-actions">${(0,h.z)(e=>e.enableRichSocialReaction&&e.enableInfopaneLike2cCard&&e.cardSize===d.u._2x_2y,(0,p.nj)({}))} ${(0,h.z)(e=>e.cardActionStatus&y.J.enabled,(0,m.qy)` ${(0,h.z)(e=>e.enableRichSocialReaction,(0,m.qy)` ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&y.J.showMore,p.LW)} ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&y.J.showFewer,p.tB)} `)} ${(0,h.z)(e=>!1!==e.enableWCCardAction&&!e.isMsnMobile,g.L)} `)}</div>${(0,h.z)(e=>!e.disableHideOnHover&&e.cardActionStatus&y.J.enabled,u.C)}</msft-article></msft-article-card>`,T=(0,m.qy)`${(e,t)=>t.parent.selectTemplate()}`,_=(0,m.qy)` ${(0,b.ux)(e=>[e.cardData],T)}
`;var I=a(38493),A=a(60815),D=a(77833),z=a(81859),F=a(87906),R=a(40450);class L extends n.L{constructor(){super(...arguments),this.placeholderRendered=!1,this.shouldRenderVideo=!0,this.playerPlaying=!1,this.playingCallbackRegistered=!1,this.mouseenterHandler=e=>{this.showCardInfoWhenHover&&this.useVideoTemplate&&(this.isHoverVideo=!0)},this.mouseleaveHandler=e=>{this.showCardInfoWhenHover&&(this.isHoverVideo=!1)},this.previewEndCallback=e=>{this.useVideoTemplate=!e},this.setPlaceholderRendered=()=>{this.shouldRenderVideo&&(this.placeholderRendered=!0)},this.eventsCallback=(e,t)=>{this.playerPlaying||this.playingCallbackRegistered||"play"!==t||(this.playingCallbackRegistered=!0,e.one("playing",()=>{this.playerPlaying=!0}))}}connectedCallback(){super.connectedCallback(),(0,z.h_)()&&(this.shouldRenderVideo=!1)}selectTemplate(){return void 0===this.previewVideo?$:S}isPreviewable(e){return!!this.previewVideo&&e&&e.videoFiles&&0!==e.videoFiles.length}clickHandler(e,t){return!e.useMobile||!!e.isMsnMobile||(e.mobileCardClickCallback(t.event,D.pL.Video,e,"video card"),!1)}error(e){(0,F.vV)(R.FPh,"Error fetching source","Source: "+e)}}(0,i.Cg)([(0,I.CF)({attribute:"preview-video",mode:"boolean"})],L.prototype,"previewVideo",void 0),(0,i.Cg)([A.sH],L.prototype,"cardData",void 0),(0,i.Cg)([A.sH],L.prototype,"isHoverVideo",void 0),(0,i.Cg)([A.sH],L.prototype,"useVideoTemplate",void 0),(0,i.Cg)([A.sH],L.prototype,"placeholderRendered",void 0),(0,i.Cg)([A.sH],L.prototype,"playerPlaying",void 0),(0,i.Cg)([A.sH],L.prototype,"showCardInfoWhenHover",void 0);let M=class extends L{};M=(0,i.Cg)([(0,n.E)({name:"msn-video-card",template:_,styles:o})],M);let E=(0,m.qy)`
    <msn-video-card
        class="${e=>e.cardSize}"
        style="grid-area:${e=>e.gridArea}"
        :cardData=${e=>e}
        :showCardInfoWhenHover=${e=>e.showCardInfoWhenHover}
        preview-video=${e=>e.useVideoPreviewTemplate}
    >
    </msn-video-card>
`},27970(e,t,a){"use strict";var i=a(94972),n=a(65949);let r={getFeedDataForCard:e=>(0,n._C)(e),viewTemplate:i.p,getPreviewForCard:e=>(0,n.E_)(e)};a.d(t,{},{j:r})},65949(e,t,a){"use strict";a.d(t,{_C:()=>l,E_:()=>o,QC:()=>s});var i=a(98794),n=a(69828),r=a(33744);function o(e){if(!e)return null;if(!function(e){if(!e.body||!e.body[0]||!e.body[0].columns||e.body[0].columns.length<3)return!1;let t=e.body[0].columns[2].items&&e.body[0].columns[2].items[0];return!!t&&!!t.text}(e))return e;{let t=e.body[0].columns[2].items[0].text,a={$schema:"http://adaptivecards.io/schemas/adaptive-card.json",version:e.version,type:"AdaptiveCard",body:[{type:"ColumnSet",columns:[{type:"Column",items:[{type:"TextBlock",id:"WidgetsOverlayText",text:t.slice(0,t.length-1),size:"small",horizontalAlignment:"center"}]}]}]};return e.widgetsOverlay=a,e.timeToLiveInSeconds=1800,e.contentType="Weather",e}}function l(e){let t,{cardMetadata:a,configOptions:r,supportedSdCardActionMenuItems:o}=e;return a?.data&&(t=function(e){let{configOptions:t,parentTelemetryObject:a,cardMetadata:i,openLinksInNewTab:n,hideCardCallback:r,goToPersonalizeSettingsCallback:o,sdCardActionClickHandler:l,dismissSDCardMenuCallback:s,refreshSDCardSection:d,supportedSdCardActionMenuItems:c,refreshFeedCallback:p,visualReadinessCallback:g,hasLoadedCallback:u,isDynamicFeed:m,activeBoard:h,isWidgetRegion:b,onSDCardClick:f,enableRubyHomepage:y}=e;return{id:"weather",childTemplateType:"weather-card",parentTelemetryObject:a,weatherCardConfigInfo:t&&t,cardMetadata:i.data,openLinksInNewTab:n,hideWeatherCardCallback:r,goToPersonalizeSettingsCallback:o,dismissSDCardMenuCallback:s,refreshSDCardSection:d,sdCardActionClickHandler:l,supportedSdCardActionMenuItems:c,refreshFeed:p,visualReadinessCallback:g,hasLoadedCallback:u,isDynamicFeed:m,isSpotlightUX:i.metadata&&i.metadata.isSpotlightUX,activeBoard:h,previewType:i.metadata&&i.metadata.previewType,isProngReclaim:i.metadata&&i.metadata.isProngReclaim,isWidgetRegion:b,isRubyCard:!!y,isRubyHomepage:!!y,onSDCardClick:f}}(e)),(0,i.bw)({id:"weather",experienceType:(r&&r)?.configRef?.experienceType,mapperArgs:e},t,(e,t)=>({cardLayout:t.cardSize===n.u._1x_1y?"half":"full",supportedSdCardActionMenuItems:o}),!0)}function s(){return"edgeChromium"===r.T3.AppType}},94972(e,t,a){"use strict";var i=a(73632),n=a(89757),r=a(65949),o=a(94172);let l=(0,n.qy)`
    ${(e,t)=>{var a;let n="{}"===(a=e).cardMetadata?a.cardLayout:"_1x_1y"===a.cardSize?"half":"_1x_2y"===a.cardSize?"full":"_1x_3y"===a.cardSize?"large":a.cardLayout,l={cardSize:n,openLinksInNewTab:e.openLinksInNewTab,cardMetadata:e.cardMetadata,wpoMetadata:e.wpoMetadata,parentTelemetry:e.parentTelemetryObject,sdCardActionClickHandler:e.sdCardActionClickHandler,hideWeatherCardCallback:e.hideWeatherCardCallback,goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback,dismissActionMenu:e.dismissSDCardMenuCallback,refreshSDCardSection:e.refreshSDCardSection,supportedSdCardActionMenuItems:e.supportedSdCardActionMenuItems,refreshFeed:e.refreshFeed,visualReadinessCallback:e.visualReadinessCallback,hasLoadedCallback:e.hasLoadedCallback,isDynamicFeed:e.isDynamicFeed,isSpotlightUX:e.isSpotlightUX,cardLayout:e.activeBoard,previewType:e.previewType,isProngReclaim:e.isProngReclaim,isWidgetRegion:e.isWidgetRegion,isRubyCard:e.isRubyCard,isRubyHomepage:e.isRubyHomepage,onSDCardClick:e.onSDCardClick},s={cardSize:n,style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible`};return e.weatherCardConfigInfo?(0,o.yN)(e.weatherCardConfigInfo,{properties:l,attributes:s,memoize:(0,r.QC)()&&!(0,i.S)()}):void 0}}
`,s=(0,n.qy)`
    ${l}
`;a.d(t,{},{p:s})},5871(e,t,a){"use strict";var i=a(2018),n=a(87906),r=a(33335),o=a(7446);function l(e){return`${e}Bundle`}let s=Object.freeze({TeamVsTeamWithBracket:"SportsMarchmadness",Articles:"SportsArticle",EventBrief:"SportsEventBrief",Spotlight:"SportsSpotlight",SpotlightRace:"SportsSpotlightRace",SpotlightTennis:"SportsSpotlightTennis",SpotlightGolf:"SportsSpotlightGolf",StandingsRankings:"SportsStandingsRankings",MotorSportsSingleRace:"SportsLeaderboard",MotorSportsRaceList:"SportsLeaderboard",GolfSchedule:"SportsLeaderboard",GolfLeaderBoard:"SportsLeaderboard",FRE:"SportsFre",Cricket:"SportsCricket",Tennis:"SportsTennis",TeamVsTeam:"SportsMatchList"}),d={[l("SportsMatchList")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,14472)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,82724)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,83322)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,4708))]).then(e=>({SportsMatchListTransformer:e[0].SportsMatchListTransformer,SportsMatchTransformer:e[1].SportsMatchTransformer})),[l("SportsCricket")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("sports-cricket")]).then(a.bind(a,22726)),Promise.all([a.e("common-feed-libs"),a.e("sports-cricket")]).then(a.bind(a,30502))]).then(e=>e?.[0]),[l("SportsTennis")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("sports-tennis")]).then(a.bind(a,87760)),Promise.all([a.e("common-feed-libs"),a.e("sports-tennis")]).then(a.bind(a,39438))]).then(e=>e?.[0])},c={...d,[l("SportsSpotlight")]:()=>Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-spotlight")]).then(a.bind(a,59682)).then(e=>({SportsSpotlightTransformer:e.SportsSpotlightTransformer,SportsMatchTransformer:e.SportsMatchTransformer,SportsGameStatsTransformer:e.SportsGameStatsTransformer,SportsPickWinnerTransformer:e.SportsPickWinnerTransformer}))};a.d(t,{},{Q(e,t,a){try{let n;if(t)n="Spotlight";else{let t=JSON.parse(e).Model.Tabs[0].tabType;t&&(n=["SeasonStatistics","Video","Countdown","Spotlight"].includes(t)?"Spotlight":["EventBrief","TeamVsTeamWithBracket","SpotlightTennis","SpotlightRace","SpotlightGolf","StandingsRankings"].includes(t)||["MotorSportsSingleRace","MotorSportsRaceList","GolfSchedule","GolfLeaderBoard","FRE","Cricket","Tennis"].includes(t)?t:"TeamVsTeam")}let r=s[n];if(!r)return;let p=i.vv.get("MoneyAndSportsModuleLoadPromiseMap",()=>({})),g=p[r];if(g)return g;let u=a?c:d,m=l(r);if(u[m])return g=u[m](),o.YT.addOrUpdateTmplProperty("sportsPreloaded",`${r}`),p[r]=g,g}catch(e){(0,n.c_)(e,r.MY,"Error in prefetching sports card component","")}}})},45519(e,t,a){"use strict";a.d(t,{},{ZV(e){if(null==e)return"";let t=Number(e);if(isNaN(t)||!isFinite(t))return"";if(t<1e3)return t.toString();let a=["K","M","B","T"],i=-1,n=t;for(;n>=1e3&&i<a.length-1;)n/=1e3,i++;return((n=Math.round(10*n)/10)%1==0?n.toFixed(0):n.toFixed(1))+a[i]},g_(e){if(null==e)return"";let t=Number(e);if(isNaN(t)||!isFinite(t))return"";if(t<1e4)return t.toString();let a=t/1e4;return((a=Math.round(10*a)/10)%1==0?a.toFixed(0):a.toFixed(1))+"w"}})},13186(e,t,a){"use strict";a.d(t,{},{P:"#0078D4"})},34897(e,t,a){"use strict";a.d(t,{L:()=>p});var i=a(10103);class n extends i.y{}var r=a(5675),o=a(7896),l=a(61138),s=a(59669),d=a(64187);let c=(0,s.A)` ${(0,d.V)("flex")} :host{box-sizing:border-box;font-family:${o.O};font-size:${l.k};line-height:${l.F};height:100%}`,p=n.compose({name:"msn-info-pane-panel",template:(0,r.S)(),styles:c})},13660(e,t,a){"use strict";a.d(t,{K:()=>b});var i=a(99751);class n extends i.s{focus(e){this.hasAttribute("data-suppress-focus")||super.focus(e)}}var r=a(60347),o=a(59669),l=a(50882),s=a(64187),d=a(73477),c=a(22131),p=a(7896),g=a(47810),u=a(26920),m=a(14996);let h=(0,o.A)` ${(0,s.V)("inline-flex")} :host{box-sizing:border-box;font-family:${p.O};min-height:6px;min-width:6px;background-color:${g.l};border-radius:20px;opacity:0.4;grid-row:1;z-index:1;margin:0px 2px}:host([aria-selected="true"]){z-index:2;opacity:1;min-width:30px}:host(:hover),:host(:active){background:${g.l};opacity:1}:host(:${d.N}){outline:none;box-shadow:0 0 0 calc((${u.vd} - ${u.XA}) * 1px) rgba(0,0,0,1),0 0 0 calc((${u.vd} + ${u.XA}) * 1px) ${m.WN}}:host(:focus){outline:none}`.withBehaviors((0,c.mr)((0,o.A)` :host{forced-color-adjust:none;border-color:transparent;color:${l.A.ButtonText};fill:${l.A.ButtonText}}:host(:hover),:host([aria-selected="true"]:hover){background:${l.A.Highlight};color:${l.A.HighlightText};fill:${l.A.HighlightText}}:host([aria-selected="true"]){background:${l.A.HighlightText};color:${l.A.Highlight};fill:${l.A.Highlight}}:host(:${d.N}){border-color:${l.A.ButtonText};box-shadow:0 0 0 calc((${u.vd} - ${u.XA}) * 1px) rgba(0,0,0,1),0 0 0 calc((${u.vd} + ${u.XA}) * 1px) ${l.A.ButtonText}}`)),b=n.compose({name:"msn-info-pane-tab",template:(0,r.M)(),styles:h})},86294(e,t,a){"use strict";a.d(t,{j:()=>y});var i=a(56911),n=a(4174),r=a(37180),o=a(45046),l=a(92011),s=a(38493);class d extends l.L{}(0,i.Cg)([s.CF],d.prototype,"userSubscriptionData",void 0),(0,i.Cg)([s.CF],d.prototype,"cardSize",void 0);var c=a(59669),p=a(9960),g=a(69809);let u=(0,c.A)`
.badge{border-radius:4px;font-size:8px}.badge svg{margin-inline-end:6px}.true{background:linear-gradient(90deg,#5051D1 0%,#797AF5 100%);padding:2px 6px 3px 8px;color:#FFFFFF}.false{background:${(0,p.ud)()?"linear-gradient(90deg, rgba(255, 255, 255, 0.88) 0%, rgba(255, 255, 255, 0.78) 100%)":"linear-gradient(90deg, rgba(0, 0, 0, 0.64) 0%, rgba(0, 0, 0, 0.46) 100%)"};display:flex;padding:2px 6px 3px 8px;color:${g.m_}}._1x_2y{display:inline-flex;margin-bottom:6px}._2x_2y{position:absolute;top:16px}`;var m=a(89757),h=a(69259);let b=(0,m.qy)`<svg width="8" height="10" xmlns="http://www.w3.org/2000/svg"><path d="M3.874.816 4 .813c1.097 0 1.994.856 2.059 1.936l.003.126v.375h.563c.621 0 1.125.504 1.125 1.125v4.5C7.75 9.496 7.246 10 6.625 10h-5.25A1.125 1.125 0 0 1 .25 8.875v-4.5c0-.621.504-1.125 1.125-1.125h.563v-.375c0-1.097.856-1.994 1.936-2.059L4 .813l-.126.003ZM4 5.875a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm.096-3.933L4 1.938a.938.938 0 0 0-.933.841l-.005.096v.375h1.876v-.375a.938.938 0 0 0-.842-.933L4 1.938l.096.004Z" fill="currentColor"/></svg>`,f=(0,m.qy)`<div class="badge ${e=>e.userSubscriptionData.isSubscribed?"true":"false"} ${e=>"_1x_2y"==e.cardSize?"_1x_2y":"_2x_2y"}">${(0,h.z)(e=>!e.userSubscriptionData.isSubscribed,(0,m.qy)` ${b}<b>${e=>e.userSubscriptionData?.subscribeToViewText?.toLocaleUpperCase()}</b>`)} ${(0,h.z)(e=>e.userSubscriptionData.isSubscribed,(0,m.qy)`<b>${e=>e.userSubscriptionData?.subscribedText?.toLocaleUpperCase()}</b>`)}</div>`,y=class extends d{};y=(0,i.Cg)([(0,l.E)({name:"msn-subscription-badge",template:f,styles:u})],y),n.m.define(r.c.registry),o.m.define(r.c.registry)},74826(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 2h5c.28 0 .5.22.5.5V5h1a2 2 0 012 2v5a2 2 0 01-2 2H4a2 2 0 01-2-2V7c0-1.1.9-2 2-2h1V2.5c0-.28.22-.5.5-.5zM10 5V3H6v2h4zM4 6a1 1 0 00-1 1v5a1 1 0 001 1h8a1 1 0 001-1V7a1 1 0 00-1-1H4z"></path></svg>'},58759(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M9.43 11.84a1 1 0 001.57-.82V4.98a1 1 0 00-1.57-.82L5.64 6.78c-.85.59-.85 1.85 0 2.44l3.79 2.62z"></path></svg>'},26106(e){e.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M15 17.9a1.25 1.25 0 01-2.07.94l-6.31-5.52c-.8-.7-.8-1.94 0-2.64l6.3-5.52c.82-.7 2.08-.13 2.08.94v11.8z"></path></svg>'},30576(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M7.57 11.84A1 1 0 016 11.02V4.98a1 1 0 011.57-.82l3.79 2.62c.85.59.85 1.85 0 2.44l-3.79 2.62z"></path></svg>'},30961(e){e.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 17.9a1.25 1.25 0 002.07.94l6.31-5.52c.8-.7.8-1.94 0-2.64l-6.3-5.52C10.25 4.46 9 5.03 9 6.1v11.8z"></path></svg>'},86203(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11.14 2.53a1.5 1.5 0 00-2.28 0l-6.62 7.8A1 1 0 003 11.98h3V17a1 1 0 001 1h6a1 1 0 001-1v-5.02h3a1 1 0 00.76-1.65l-6.62-7.8z"></path></svg>'},48493(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.86 2.53c.6-.7 1.68-.7 2.28 0l6.62 7.8a1 1 0 01-.76 1.65h-3V17a1 1 0 01-1 1H7a1 1 0 01-1-1v-5.02H3a1 1 0 01-.76-1.65l6.62-7.8zm1.52.65a.5.5 0 00-.76 0L3 10.98h3.5c.28 0 .5.23.5.5V17h6v-5.52c0-.27.22-.5.5-.5H17l-6.62-7.8z"></path></svg>'},10103(e,t,a){"use strict";var i=a(92011);class n extends i.L{}a.d(t,{y:()=>n})},5675(e,t,a){"use strict";var i=a(89757);function n(){return(0,i.qy)`
        <template slot="tabpanel" role="tabpanel">
            <slot></slot>
        </template>
    `}a.d(t,{S:()=>n})},99751(e,t,a){"use strict";var i=a(56911),n=a(92011),r=a(38493),o=a(35106),l=a(88458);class s extends n.L{}(0,i.Cg)([(0,r.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"disabled",void 0),(0,l.X)(s,o.qw),a.d(t,{s:()=>s})},60347(e,t,a){"use strict";var i=a(89757),n=a(35106);function r(e={}){return(0,i.qy)`
        <template slot="tab" role="tab" aria-disabled="${e=>e.disabled}">
            ${(0,n.LT)(e)}
            <slot></slot>
            ${(0,n.aO)(e)}
        </template>
    `}a.d(t,{M:()=>r})},49991(e,t,a){"use strict";a.d(t,{Ed:()=>m,h3:()=>u,Gs:()=>h,aK:()=>b,dR:()=>y});var i=a(97747),n=a(5291),r=a(83252),o=a(31023),l=a(6032),s=a(356),d=a(47691),c=a(95239),p=a(88397);let{create:g}=i.G,u=g("gradient-white-fill").withDefault(e=>(0,p.u)(.8,1,n.q.create(1,1,1),e(r.F7))),m=g("gradient-background-fill").withDefault(e=>(0,p.u)(0,1,null,e(r.F7))),h=g("neutral-fill-bubble-on-rest").withDefault(e=>{var t,a;let i;return t=e(o.r),a=e(r.F7),i=t.closestIndexOf(a),t.get(i-5)}),b=g("neutral-foreground-hint-on-bubble-on-rest").withDefault(e=>e(l.g).evaluate(e,e(h))),f=g({name:"neutral-layer-card-recipe",cssCustomPropertyName:null}).withDefault({evaluate(e){var t,a,i;return t=e(o.r),a=e(s.l),i=e(d.E),t.get(t.closestIndexOf(n.q.create(a,a,a))-i)}}),y=g("neutral-layer-card").withDefault(e=>e(f).evaluate(e)),v=g("neutral-fill-bubble-rest-delta",6),C=g("neutral-fill-bubble-hover-delta",9);g("neutral-fill-bubble-rest",e=>{let t=e(o.r),a=t.closestIndexOf(e(c.p));return t.get(a+(a>=10?-1:1)*e(v))}),g("neutral-fill-bubble-hover",e=>{let t=e(o.r),a=t.closestIndexOf(e(c.p));return t.get(a+(a>=10?-1:1)*e(C))})},88397(e,t,a){"use strict";var i=a(33045),n=a(87122);function r(e=0,t=1,a,o){let l=o.toColorString(),{r:s,g:d,b:c}=(0,i.Hs)(l),p=new n.M(s,d,c,e).toStringWebRGBA(),g=new n.M(s,d,c,t).toStringWebRGBA(),u=`linear-gradient(160deg, ${p}, ${g})`;return a?[u,a?.toColorString()].join():u}a.d(t,{u:()=>r})}}]);