"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-match-list"],{14472(t,e,s){s.r(e),s.d(e,{SportsMatchListTransformer(){return o}});var a=s(23305),i=s(89757),r=s(79811);class o extends a.Bc{async transform(t){const e=await this.getCurrentViewModel(t);return{viewTemplate:i.qy`
                <sports-match-list
                    :viewModel="${e}"
                ></sports-match-list>`}}async getCurrentViewModel(t){const e=await this.getMatches(t,t.reason);return{matches:e,isIncomplete:t.isCopilotTheme&&e.length<t.numberOfMatches,cardSize:t.cardSize,paginationStyle:"",reason:t.reason,showParticipantAddIcon:!1,tabIndex:0,telemetryTag:"",isCopilotTheme:t.isCopilotTheme}}async getMatches(t,e){if(!t.sportsMatchOverallData)return[];const s=t.followedSports||new Map,i=(0,r.Yo)(t.sportsMatchOverallData),o=t.sportsMatchOverallData.slice(0,t.numberOfMatches).map(async o=>{const n=o.sportsMatchData,c=(0,r.gK)(n.participantOne,s),l=(0,r.gK)(n.participantTwo,s),p={matchData:o,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,participantOneFollowed:c,participantTwoFollowed:l,topDetailText:t.matchTopDetailText,isContainLiveMatch:i,reason:e,enableLiveScores:this.transformerProvider.config.enableLiveScores,cardSize:t.cardSize,showMatchUXV2:t.showMatchUXV2,isCopilotTheme:t.isCopilotTheme,isMitUX:t.isMitUX};return this.transformerProvider.generateView(p,a.hi.SportsMatch)});return(await Promise.all(o)).filter(r.z2)}}},35908(t,e,s){s.r(e),s.d(e,{SportsMatchListTransformer(){return a.SportsMatchListTransformer},SportsMatchTransformer(){return i.SportsMatchTransformer}});var a=s(14472),i=s(82724);Promise.resolve().then(s.bind(s,83322)),Promise.resolve().then(s.bind(s,4708))},71372(t,e,s){s.d(e,{a(){return o}});var a=s(56911),i=s(92011),r=s(95144);let o=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([r.x],o)},83322(t,e,s){s.r(e),s.d(e,{SportsMatchList(){return g}});var a=s(56911),i=s(71372);class r extends i.a{}var o=s(92011),n=s(59669),c=s(61138),l=s(63033);const p=n.A`
`,h=n.A` .sports-match-list{row-gap:12px;display:grid}.reason.sports-match-list{row-gap:8px}.reason-text{font-size:${c.k};line-height:${c.F};font-weight:600;padding-bottom:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;position:relative}.sports-match-list._15u{row-gap:0;height:272px}.sports-match-list._15u.incomplete{height:252px;padding-top:20px}.sports-match-list._15u.copilot-theme{row-gap:10px;align-items:center}`.withBehaviors(new l.N(null,p));var m=s(89757),d=s(69259),w=s(68835);const u=m.qy`
    <div class="sports-match-list ${t=>t.viewModel.paginationStyle} ${t=>t.viewModel.reason.length>0?"reason":""}
        ${t=>"1.5u"===t.viewModel.cardSize?"_15u":""} ${t=>t.viewModel.isIncomplete?"incomplete":""} ${t=>t.viewModel.isCopilotTheme?"copilot-theme":""}"
    >
        ${(0,d.z)(t=>!t.viewModel.isCopilotTheme&&t.viewModel.reason,m.qy`<div class="reason-text">
            ${t=>t.viewModel.reason}
        </div>`)}
        ${(0,w.ux)(t=>t.viewModel.matches,m.qy`<sports-match
            :viewModel="${t=>t.viewModel}"
        ></sports-match>
        `,{positioning:!0})}
    </div>
`,v=m.qy`
    ${(0,d.z)(t=>null!=t.viewModel,u)}
`;let g=class extends r{};g=(0,a.Cg)([(0,o.E)({name:"sports-match-list",template:v,styles:h,shadowOptions:{delegatesFocus:!0}})],g)}}]);