(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["stripe-wc"],{36478(e,t,a){"use strict";a.d(t,{},{A:'<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M7.73 4.2a.75.75 0 0 1 1.06.03l5 5.25c.28.3.28.75 0 1.04l-5 5.25a.75.75 0 1 1-1.08-1.04L12.2 10l-4.5-4.73a.75.75 0 0 1 .02-1.06Z" fill="currentcolor"/></svg>'})},32558(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 16.7c.34.98 1.63 1.43 2.43.6.16-.17.33-.36.44-.52.32-.48.45-1.12.5-1.73.05-.63.02-1.3-.05-1.91-.06-.62-.16-1.18-.24-1.59v-.05H12a3 3 0 0 0 2.96-3.54l-.69-3.76A4.5 4.5 0 0 0 8.67.67l-5.6 1.52c-.92.25-1.62 1-1.8 1.92L.9 5.88c-.27 1.39.79 2.56 1.92 3 .32.13.61.3.84.5 1.7 1.5 2.32 2.72 3.38 4.84.36.71.72 1.68 1 2.49Zm1.96-5.58v.01l.01.03a8.94 8.94 0 0 1 .13.58c.08.4.17.92.23 1.5s.09 1.18.04 1.73c-.04.55-.16.98-.34 1.25-.05.1-.17.22-.32.39-.2.2-.63.16-.76-.23-.29-.82-.67-1.83-1.05-2.6-1.07-2.14-1.76-3.5-3.62-5.15-.34-.3-.74-.52-1.13-.68-.89-.34-1.45-1.14-1.3-1.87l.35-1.77c.1-.56.53-1 1.07-1.15l5.6-1.53a3.5 3.5 0 0 1 4.37 2.75l.68 3.76A2 2 0 0 1 12 10.5h-1.5a.5.5 0 0 0-.48.62Z"/></svg>'})},56298(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48 17.3c-.8.83-2.09.38-2.43-.6-.28-.8-.64-1.77-1-2.48C6 12.1 5.37 10.9 3.67 9.37c-.23-.2-.52-.36-.84-.49C1.7 8.44.63 7.27.9 5.88l.36-1.77a2.5 2.5 0 0 1 1.8-1.92L8.66.66a4.5 4.5 0 0 1 5.6 3.54l.69 3.76A3 3 0 0 1 12 11.5h-.88l.01.05c.08.41.18.97.24 1.58.07.62.1 1.29.05 1.92a3.68 3.68 0 0 1-.5 1.73c-.11.16-.28.35-.44.52Z"/></svg>'})},94725(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 1.3C8.4.31 9.68-.14 10.48.7c.16.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H12a3 3 0 0 1 2.96 3.54l-.69 3.76a4.5 4.5 0 0 1-5.6 3.53l-5.6-1.52a2.5 2.5 0 0 1-1.8-1.92L.9 12.12c-.27-1.39.79-2.56 1.92-3 .32-.13.61-.3.84-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49Zm1.96 5.58v-.01l.01-.03a9.08 9.08 0 0 0 .13-.58c.08-.4.17-.92.23-1.5s.09-1.18.04-1.73a2.73 2.73 0 0 0-.34-1.25 3.26 3.26 0 0 0-.32-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.89.34-1.45 1.14-1.3 1.87l.35 1.77c.1.56.53 1 1.07 1.15l5.6 1.53c1.98.54 4-.73 4.37-2.75l.68-3.76A2 2 0 0 0 12 7.5h-1.5a.5.5 0 0 1-.48-.62Z"/></svg>'})},39677(e,t,a){"use strict";a.d(t,{},{A:'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48.7c-.8-.83-2.09-.38-2.43.6-.28.8-.64 1.77-1 2.48C6 5.9 5.37 7.1 3.67 8.63c-.23.2-.52.36-.84.49-1.13.44-2.2 1.61-1.92 3l.36 1.77a2.5 2.5 0 0 0 1.8 1.92l5.6 1.52a4.5 4.5 0 0 0 5.6-3.53l.69-3.76A3 3 0 0 0 12 6.5h-.88l.01-.05c.08-.41.18-.97.24-1.59.07-.6.1-1.28.05-1.9a3.68 3.68 0 0 0-.5-1.74 4.16 4.16 0 0 0-.44-.52Z"/></svg>'})},12688(e,t,a){"use strict";var r=a(89757),i=a(14475),o=a(33744);a.d(t,{},{$:e=>(0,r.qy)`<a class="ad-choice" data-t=${e.telemetryTag||""} href=${e.href||""} target="${i.z._blank}" title=${e.text||""}><img alt=${e.text||""} aria-hidden="true" src="${(0,o.rA)().StaticsUrl}/latest/responsive-card/adChoiceIcon.svg"></img></a>`})},61666(e,t,a){"use strict";var r=a(89757),i=a(69259),o=a(14475),s=a(4670),n=a(2188);let l=(e,t)=>{t.event.preventDefault(),window.dispatchEvent(new CustomEvent("dsaClick",{detail:{adSelectionCriteria:e.adSelectionCriteria,anchorElement:t.event.target,strings:e.config.localizedStrings},bubbles:!0,composed:!0}))},d=(e,t)=>("Enter"===t.event.key&&l(e,t),!0);a.d(t,{},{Q:e=>(0,r.qy)` ${(0,i.z)(!!e.enableDSADialog,(0,r.qy)`<a class="${e.className||"ad-label"} dsa" data-native-label data-t=${e.telemetryTag||""} title=${e.dsaDialogTooltip||""} ?no-border=${!!e.noBorder} @click=${l} @keydown=${d} tabindex="0">${e.text||"Ad"}</a>`)} ${(0,i.z)(!e.enableDSADialog,(0,r.qy)`<a class="${e.className||"ad-label"}" data-native-label data-t=${e.telemetryTag||""} href=${e.href||""} target="${o.z._blank}" title=${!(0,s.jj)()?"":e.text||""} ?no-border=${!!e.noBorder} ${!(0,s.jj)()&&(0,n.Ib)(!0,!1)}>${e.text||"Ad"}</a>`)} `})},92291(e,t,a){"use strict";a.r(t),a.d(t,{StripeWC:()=>rr,StripeWCFlippersStyles:()=>aG,StripeWCRiverStyles:()=>aJ,StripeWCStyles:()=>aH,StripeWCTemplate:()=>r_,ToolingInfo:()=>rw,templateDarkStyles:()=>aV,templateStyles:()=>aK,topStripeStyles:()=>aj});var r,i,o,s,n,l,d=a(4174),c=a(37180),p=a(75003),u=a(69329),h=a(65614),g=a(42320),m=a(651),y=a(12165),C=a(58757),f=a(55461),v=a(97964),b=a(56911),x=a(38493),_=a(60815),w=a(55230),S=a(56863),$=a(92011);class A extends $.L{}class I extends(0,S.rf)(A){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class k extends I{onTitleClicked(){this.$emit("action-title-clicked")}handleTextInput(){this.inputControl&&(this.value=this.inputControl.value,this.$emit("action-text-input",this.inputControl.value))}addToWatchlist(e){this.inputControl&&(this.inputControl.value="",this.value=""),this.$emit("action-add-to-watchlist",e)}handleOnKeyDownSearchBox(e){if(!this.moneyCardContentData.showSuggestions)return!0;switch(e.key){case w.I5:e.preventDefault(),this.activeSuggestion=this.searchSuggestions.length-1,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;case w.HX:e.preventDefault(),this.activeSuggestion=0,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement()}return!0}focusSelectedElement(){this.selectedSuggestion.querySelectorAll("li").forEach(e=>{e.id===this.activeId&&e.focus()})}handleOnKeyDownAutoSuggestBox(e){switch(e.key){case w.HX:e.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case w.I5:e.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+this.searchSuggestions.length-1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case" ":case"Enter":e.preventDefault(),this.searchSuggestions.length>0&&(this.inputControl.value="",this.activeSuggestion=-1,this.selectedSuggestion.querySelectorAll("li").forEach(e=>{e.id===this.activeId&&e.click()}));break;case"Escape":e.preventDefault(),this.activeSuggestion=-1,this.inputControl.value="",this.$emit("action-text-input",this.inputControl.value);break;default:return}}getSuggestionClass(e,t,a){return e===this.activeId?a:t}}(0,b.Cg)([(0,x.CF)({attribute:"layout"})],k.prototype,"layout",void 0),(0,b.Cg)([_.sH],k.prototype,"moneyCardContentData",void 0),(0,b.Cg)([_.sH],k.prototype,"searchSuggestions",void 0),(0,b.Cg)([_.sH],k.prototype,"goBackTelemetryTag",void 0),(0,b.Cg)([_.sH],k.prototype,"addToWatchlistTelemetryTag",void 0),(0,b.Cg)([_.sH],k.prototype,"activeSuggestion",void 0),(0,b.Cg)([_.sH],k.prototype,"activeId",void 0);var P=a(89757),T=a(60402),D=a(69259),R=a(68835);let M=(0,P.qy)`<li id="${e=>e.quoteId}" tabindex="0" active=${(e,t)=>e.quoteId===t.parent.activeId||null} class="${(e,t)=>t.parent.getSuggestionClass(e.quoteId,"suggestion-entry","suggestion-entry-selected")}" part="${(e,t)=>t.parent.getSuggestionClass(e.quoteId,"suggestion-entry","suggestion-entry-selected")}" aria-label="${e=>e.longName} ${e=>e.exchangeName}" @click="${(e,t)=>t.parent.addToWatchlist(e.quoteId)}" data-t="${(e,t)=>t.parent.addToWatchlistTelemetryTag}"><div class="suggestion-item" part="suggestion-item"><div class="suggestion-company" part="suggestion-company"><span class="suggestion-symbol" part="suggestion-symbol">${e=>e.equitySymbol}</span><span class="suggestion-name" part="suggestion-name">${e=>e.longName}</span></div><div class="suggestion-market" part="suggestion-market"><span class="suggestion-market-str">${e=>e.exchangeName}</span></div><div class="suggestion-add-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17 9.53v.94h-6.53V17h-.94v-6.53H3v-.94h6.53V3h.94v6.53H17z" /></svg></div></div></li>`,B=(0,P.qy)`<div class="search-area" part="search-area"><div class="search-icon" part="search-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 3a5.5 5.5 0 014.23 9.02l4.12 4.13a.5.5 0 01-.63.76l-.07-.06-4.13-4.12A5.5 5.5 0 118.5 3zm0 1a4.5 4.5 0 100 9 4.5 4.5 0 000-9z" /></svg></div><input class="search-input" part="search-input" type="search" autofocus="autofocus" @input=${e=>e.handleTextInput()} @keydown="${(e,t)=>e.handleOnKeyDownSearchBox(t.event)}" aria-label="${e=>e.moneyCardContentData?.searchPlaceholder}" placeholder="${e=>e.moneyCardContentData?.searchPlaceholder}" :value="${e=>e.value}" ${(0,T.K)("inputControl")} />${(0,D.z)(e=>e.moneyCardContentData?.showSuggestions===!0,(0,P.qy)`<ul class="suggestions-list" part="suggestions-list" tabindex="-1" @keydown="${(e,t)=>e.handleOnKeyDownAutoSuggestBox(t.event)}" ${(0,T.K)("selectedSuggestion")}>${(0,R.ux)((e,t)=>e.searchSuggestions,M)}</ul>`)} ${(0,D.z)(e=>e.moneyCardContentData?.noSuggestion===!0,(0,P.qy)`<div class="suggestions-list" part="suggestions-list"><div class="no-suggestion-str">${e=>e.moneyCardContentData?.noSuggestionHint}</div></div>`)}</div>`,L=(0,P.qy)`<div class="title" part="title"><button class="title-button" part="title-button" @click="${e=>e.onTitleClicked()}" aria-label="${e=>e.moneyCardContentData?.goBackLabel}" data-t="${e=>e.goBackTelemetryTag}"><span class="title-content">&lrm;${e=>e.moneyCardContentData?.titleContent}</span></button></div>${B}
`;var O=a(59669),F=a(64187),E=a(22131),z=a(73477),N=a(61138),U=a(6032),q=a(48196),W=a(33113),H=a(47810),j=a(41123),K=a(95403),V=a(37998),G=a(7896),J=a(83252),Q=a(86856),X=a(50882);let Y=(0,O.A)` .suggestion-add-icon{padding-left:10px}`,Z=(0,O.A)` .suggestion-add-icon{padding-right:10px}`,ee=(0,O.A)` ${(0,F.V)("grid")} :host{box-sizing:border-box;position:relative;width:100%;outline:none;padding:12px 16px;height:100%;grid-template-rows:auto 1fr}:host([layout="full"]) .title{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:1fr auto;height:24px;margin-bottom:11px}:host([layout="half"]) .title{align-items:center;display:grid;grid-template-columns:1fr auto;grid-column-gap:8px;margin-bottom:8px;height:16px}.title-button{border:none;display:flex;font-size:${N.k};line-height:${N.F};font-weight:500;color:${U.c};background-color:transparent;outline:none;cursor:pointer;padding:0px}.title-button:focus{text-decoration:underline}.title-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-inline-end:12px}.search-area{display:grid;grid-template-columns:auto 1fr;height:calc(${q.D} * 1px);position:relative;border:1px solid ${W.I2}}.search-icon{width:20px;padding:6px 10px}svg path{fill:${H.l}}.search-input{color:${H.l};background:transparent;font-size:${j.K};line-height:${j.Z};height:calc(${q.D} * 1px);border:none;outline:none}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.suggestion-add-icon{padding-left:10px}.suggestions-list{margin:0px;display:block;position:absolute;box-sizing:border-box;top:40px;width:100%;padding:4px;background:${K.Wl};--elevation:10;${V.ET};z-index:9999;border:1px solid transparent}.no-suggestion-str{margin:3px 9px;font-size:${j.K};line-height:${j.Z}}.suggestion-entry-selected{font-family:${G.O};outline:none;list-style:none;border:none;width:258px;height:47px;padding:0px;background:${J.Xt};text-decoration:none;cursor:pointer}.suggestion-entry{border:none;outline:none;list-style:none;width:258px;height:47px;padding:0px;background:${K.Wl};text-decoration:none;cursor:pointer}.suggestion-entry:hover .suggestion-item{background:${J.Xt}}.suggestion-entry,.search-input,.title-button{font-family:${G.O}}.suggestion-item{display:grid;grid-template-columns:140px 66px 32px;grid-column-gap:2px;height:40px;padding:5px 8px 2px 8px}.suggestion-company{display:grid;text-align:start;grid-template-rows:20px 20px}.suggestion-add-icon{padding-top:9px}.suggestion-symbol{display:block;font-weight:800;font-size:${j.K};line-height:${j.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}.suggestion-name{display:block;font-weight:600;font-size:${N.k};line-height:${N.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}.suggestion-market{display:flex;position:relative;padding-top:8px}.suggestion-market-str{position:absolute;right:0px;font-weight:600;text-align:end;font-size:${N.k};line-height:${N.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${H.l}}`.withBehaviors(new Q.t(Y,Z),(0,E.mr)((0,O.A)` :host{forced-color-adjust:auto}svg path{fill:${X.A.ButtonText}}.suggestion-entry:hover .suggestion-item,.suggestion-entry:${z.N} .suggestion-item{forced-color-adjust:none;background:${X.A.Highlight}}.suggestion-entry:hover .suggestion-item *,.suggestion-entry:hover .suggestion-item svg path,.suggestion-entry:${z.N} .suggestion-item *,.suggestion-entry:${z.N} .suggestion-item svg path{color:${X.A.HighlightText};fill:currentcolor}`)),et=k.compose({name:`${m.i.prefix}-add-watchlist-money-card`,template:L,styles:ee});var ea=a(47131),er=a(61851),ei=a(34897),eo=a(16333),es=a(85981),en=a(19511),el=a(61473),ed=a(2684),ec=a(47211);(r=s||(s={})).AutosEntityList="AutosEntityList",r.AutosCarousel="AutosCarousel",(i=n||(n={})).AnaheimNtpFeeds="anaheim-ntp-feeds",i.MSNArticle="articles-startshop-feeds",i.MSNHomePage="hponeservicefeed";var ep=a(87906),eu=a(40450),eh=a(33744),eg=a(43672),em=a(12776),ey=a(23057),eC=a(83826);let ef='{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';async function ev(e,t=n.AnaheimNtpFeeds,a,r){let i=function(e){switch(e){case n.AnaheimNtpFeeds:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";case n.MSNArticle:return"TUvfxJjXdl3YnnSTtb4nTd6OHIbDUzhvcgJt26A7Bi";case n.MSNHomePage:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";default:return""}}(t),o=new URL(`https://assets.msn.com/service/news/feed/segments/autosMarketplace?apikey=${i}&ocid=${t}`),s=await (0,ey.XK)()===2?em.WR.getOneServiceParamsWithAuth((0,eh.rA)().UserId,t):em.WR.getOneServiceParamsWithoutAuth((0,eh.rA)().UserId,t),l=new Set(["apikey","ocid"]);r&&s.push({key:"contentId",value:r}),s&&s.forEach(e=>{e.value&&!l.has(e.key)&&o.searchParams.set(e.key,e.value)});let d=await (0,eC.w)(()=>fetch(o.href),"GetAutosEntityList"),c=3;if(!d.ok&&!e)return"{}";if(!d.ok&&e)switch(eh.T3.CurrentMarket){case eg.DX.ENUS:return ef;case eg.DX.ENCA:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';case eg.DX.ENGB:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';default:return ef}for(;c>0&&d?.status!==200;){try{d=await (0,eC.w)(()=>fetch(o.href),"GetAutosEntityList")}catch(e){(0,ep.c_)(Error("Response Fetch Error"),eu.uqN,"send request to segments api failed")}c--}if(!d.ok)throw Error(d.statusText);let p=await d.json(),u=p&&p[0]&&p[0].data;if(a&&p.length>0){let e=p.filter(e=>e.type==a);u=e&&e[0]&&e[0].data}return u}var eb=a(32247),ex=a(13507),e_=a(2274),ew=a(10316),eS=a(84289),e$=a(44646),eA=a(45596),eI=a(52226),ek=a(37125),eP=a(5977);(o=l||(l={})).casualGamesCard="casual-games-card",o.casualGamesStripeCarouselCard="casual-games-stripe-carousel-card",o.contentCard="content-card",o.contentCardPreview1x="content-card-preview-1x",o.denseCard="dense-card",o.displayAdCard="display-ad-card",o.infopaneCard="infopane-card",o.infopaneSlideCard="infopane-slide-card",o.moneyInfoCardWC="money-info-card",o.healthArticlesCardWC="health-articles-card",o.nativeAdCard="native-ad-card",o.placeholderCard="placeholder-card",o.pollsCard="polls-card",o.shoppingCarouselCard="shopping-carousel-card",o.shoppingVideoCarousel="shopping-video-carousel-card",o.superappUpsellCard="superapp-upsell-card",o.trendingNowCard="trending-now-card",o.weatherCard="weather-card",o.webContentCard="web-content-card",o.videoCard="video-card",o.sportsCard="sports-card",o.travelDestinationCard="travel-destination";var eT=a(77833);let eD={[eT.pL.Article]:l.contentCard,[eT.pL.CasualGamesStripeCarousel]:l.casualGamesStripeCarouselCard,[eT.pL.EsportsCasualGames]:l.casualGamesCard,[eT.pL.Slideshow]:l.contentCard,[eT.pL.ExternalLink]:l.contentCard,[eT.pL.Video]:l.contentCard,[eT.pL.WebContent]:l.contentCard,[eT.pL.Infopane]:l.infopaneCard,[eT.pL.ShoppingCarousel]:l.shoppingCarouselCard,[eT.pL.Dense]:l.denseCard,[eT.pL.TrendingInTenMinutes]:l.trendingNowCard,[eT.pL.NativeAd]:l.nativeAdCard};var eR=a(69828);let eM=(0,O.A)`

:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),eB={cardCount:4,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eM},eL=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
  
`.withBehaviors(),eO={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eL},eF=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot6"
        "slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eE={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eF},ez=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot7"
        "slot1 slot2 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eN={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ez},eU=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot6"
        "slot1 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eq={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eU},eW=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot7"
        "slot1 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eH={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eW},ej=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot8"
        "slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eK={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:ej},eV=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot10"
        "slot3 slot6 slot9 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eG={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:eV},eJ=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot9"
        "slot1 slot4 slot7 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),eQ={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot9",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot10",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:eJ},eX=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),eY={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}},{grid_area:"slot3",layouts:{C4:eR.u._2x_3y,C3:eR.u._2x_3y,C2:eR.u._2x_3y}}],styles:eX},eZ=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),e0={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}},{grid_area:"slot3",layouts:{C4:eR.u._3x_3y,C3:eR.u._3x_3y,C2:eR.u._3x_3y}}],styles:eZ},e1=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),e2={cardCount:2,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y,C1:eR.u._1x_3y}}],styles:e1},e3=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot5";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e4={cardCount:5,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._2x_3y,C3:eR.u._2x_3y,C2:eR.u._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:e3},e6=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot6"
        "slot1 slot1 slot2 slot4 slot6"
        "slot1 slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e5={cardCount:6,cardSlots:[{grid_area:"slot1",layouts:{C5:eR.u._2x_3y,C4:eR.u._2x_3y,C3:eR.u._2x_3y,C2:eR.u._2x_3y}},{grid_area:"slot2",layouts:{C5:eR.u._1x_3y,C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}},{grid_area:"slot3",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot4",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot5",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot6",layouts:{C5:eR.u._1x_3y,C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}}],styles:e6},e8=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot4 slot7";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),e7={cardCount:7,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._2x_3y,C3:eR.u._2x_3y,C2:eR.u._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:e8},e9=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot8"
        "slot1 slot1 slot3 slot6 slot8"
        "slot1 slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),te={cardCount:8,cardSlots:[{grid_area:"slot1",layouts:{C5:eR.u._2x_3y,C4:eR.u._2x_3y,C3:eR.u._2x_3y,C2:eR.u._2x_3y}},{grid_area:"slot2",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot3",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot4",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot5",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot6",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot7",layouts:{C5:eR.u._1x_1y,C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y}},{grid_area:"slot8",layouts:{C5:eR.u._1x_3y,C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y}}],styles:e9};var tt=a(47300);let ta=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas: 
        "slot1 slot1 slot1 slot2"
        "slot1 slot1 slot1 slot2";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0 16px;
}

${(0,tt.H5)(tt.j1.c3)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2";
    };
}

${(0,tt.H5)(tt.j1.c2)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),tr={cardCount:2,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._3x_2y,C3:eR.u._2x_2y,C2:eR.u._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_2y,C3:eR.u._1x_2y,C2:eR.u._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[1,2]}}],styles:ta},ti=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
${(0,tt.H5)(tt.j1.c3)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot1"
            "slot1 slot1 slot1"
            "slot1 slot1 slot1";
    };
}

${(0,tt.H5)(tt.j1.c2)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),to={cardCount:1,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._4x_2y,C3:eR.u._3x_2y,C2:eR.u._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:ti},ts=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
`.withBehaviors(),tn={cardCount:1,cardSlots:[{grid_area:"slot1",layouts:{C5:eR.u._5x_2y,C4:eR.u._4x_2y,C3:eR.u._3x_2y,C2:eR.u._2x_2y}}],styles:ts},tl=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),td={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tl},tc=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot7"
        "slot3 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),tp={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:tc},tu=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot8"
        "slot2 slot4 slot6 slot8"
        "slot3 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),th={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tu},tg=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot8"
        "slot2 slot5 slot7 slot8"
        "slot3 slot6 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),tm={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_3y,C3:eR.u._1x_3y,C2:eR.u._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:tg},ty=(0,O.A)`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot11"
        "slot3 slot6 slot9 slot12";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot10"],
:host fluent-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot11"],
:host fluent-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot10"],
:host cs-responsive-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot11"],
:host cs-responsive-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),tC={cardCount:12,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot11",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot12",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ty},tf=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot7"
        "slot2 slot3 slot12 slot7"
        "slot4 slot5 slot13 slot7";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C4"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot3"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot5"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot3"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot5"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}
    
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot7"
        "slot2 slot3 slot7"
        "slot4 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot7"
        "slot4 slot7"
        "slot8 slot7";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),tv={cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._2x_2y,C3:eR.u._2x_2y,C2:eR.u._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_4y,C3:eR.u._1x_4y,C2:eR.u._1x_4y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C2:[6,1]}},{grid_area:"slot9",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:9}},{grid_area:"slot10",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:10}},{grid_area:"slot11",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:tf},tb=(0,O.A)`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot8"
        "slot2 slot3 slot12 slot9"
        "slot4 slot5 slot13 slot10";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot8"
        "slot2 slot3 slot9"
        "slot4 slot5 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot3"
        "slot4 slot5"
        "slot8 slot9";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),tx={"msn-home-page-river-section-1111":eB,"msn-home-page-river-section-1113":eO,"msn-home-page-river-section-1131":eE,"msn-home-page-river-section-1133":eN,"msn-home-page-river-section-1311":eq,"msn-home-page-river-section-1313":eH,"msn-home-page-river-section-1331":eK,"msn-home-page-river-section-1333":eQ,"msn-home-page-river-section-3331":eG,"msn-home-page-river-section-1W13":e4,"msn-home-page-river-section-1W131":e5,"msn-home-page-river-section-1WWW":to,"msn-home-page-river-section-1WWWW":tn,"msn-home-page-river-section-1WW1":tr,"msn-home-page-river-section-1W33":e7,"msn-home-page-river-section-1W331":te,"msn-home-page-river-section-3111":td,"msn-home-page-river-section-3113":tp,"msn-home-page-river-section-3131":th,"msn-home-page-river-section-3333":tC,"msn-home-page-river-section-3311":tm,"msn-home-page-river-section-111W":eY,"msn-home-page-river-section-111WW":e0,"msn-home-page-river-section-11WW":e2,"msn-home-page-top-stripe-view-no-segment":{cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:306,gutterPx:16,cardSlots:[{grid_area:"slot1",layouts:{C4:eR.u._2x_2y,C3:eR.u._2x_2y,C2:eR.u._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[4,2]}},{grid_area:"slot4",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C4:[2,4],C3:[2,3],C2:[6,1]}},{grid_area:"slot9",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:9},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[6,2]}},{grid_area:"slot10",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:10},telemetryRowCol:{C4:[4,4],C3:[4,3]}},{grid_area:"slot11",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:eR.u._1x_1y,C3:eR.u._1x_1y,C2:eR.u._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:tb},"msn-home-page-top-stripe-view-big-forth-col-no-segment":tv};var t_=a(72287),tw=a(37914),tS=a(7961),t$=a(60640),tA=a(19e3),tI=a(10862),tk=a(9039),tP=a(50365),tT=a(18420),tD=a(65455),tR=a(52600),tM=a(71733),tB=a(33485),tL=a(90466),tO=a(18176),tF=a(26144),tE=a(34900),tz=a(18755),tN=a(59409),tU=a(245),tq=a(71084),tW=a(30316),tH=a(85842),tj=a(56525),tK=a(96245),tV=a(8097),tG=a(32361),tJ=a(13162),tQ=a(95583),tX=a(94972),tY=a(27970),tZ=a(37899),t0=a(41291),t1=a(32460),t2=a(88466),t3=a(94172);let t4=(0,P.qy)`
<fluent-card
    id="health-articles-card"
    style="grid-area:${e=>e.gridArea};border-radius:6px"
    class="${e=>e.cardSize}"
>
    ${e=>e.healthArticlesConfigInfo&&(0,t3.yN)(e.healthArticlesConfigInfo,{includeTelemetryTag:!1,properties:{parentTelemetryObject:e.parentTelemetryObject,telObjectBase:e.parentTelemetryObject,healthArticleData:e.healthArticleData,refreshSDCardSection:e.refreshSDCardSection,sdCardActionClickHandler:e.sdCardActionClickHandler,refreshFeed:e.refreshFeed,cardSize:e.cardSize},events:{goToPersonalizeSettingsCallback:e.goToPersonalizeSettingsCallback}})}

</fluent-card>
`;var t6=a(66728),t5=a(98794),t8=a(7074);function t7(e){try{if(!e)throw Error(`Invalid color string = ${e}`);let t=e?.substr(1),a=parseInt(t?.substr(0,2),16),r=parseInt(t?.substr(2,2),16),i=parseInt(t?.substr(4,2),16);if(!(0,t8.A)(a)||!(0,t8.A)(r)||!(0,t8.A)(i))throw Error(`Could not extract color from = ${e}`);return`${a}, ${r}, ${i}`}catch(e){return"58, 52, 45"}}function t9(e){let t,a=e.length;for(;0!=a;)t=Math.floor(Math.random()*a),a--,[e[a],e[t]]=[e[t],e[a]];return e}let ae={"casual-games-card":tN.H,"casual-games-stripe-carousel-card":tz.K,"content-card":tw.K,"content-card-preview-1x":tS.T,"infopane-card":tZ.P,"infopane-slide-card":t$.g,"dense-card":tI.e,"display-ad-card":tP.s,"money-info-card":tD.P,"health-articles-card":t4,"native-ad-card":tM.DO,"placeholder-card":tL.u,"polls-card":tF.d,"shopping-carousel-card":tU.j,"sports-card":tW.U,"weather-card":tX.p,"web-content-card":tS.T,"video-card":tJ.Q,"trending-now-card":tV.A,"travel-destination-card":tj.T,"responsive-card":t1.t},at={[l.casualGamesCard]:tN.D,[l.casualGamesStripeCarouselCard]:tz.O,[l.contentCard]:t2.v,[l.contentCardPreview1x]:t2.v,[l.denseCard]:tk.o,[l.infopaneCard]:t0.V,[l.infopaneSlideCard]:t2.v,[l.displayAdCard]:tT.E,[l.moneyInfoCardWC]:tR.j,[l.healthArticlesCardWC]:{getFeedDataForCard:e=>(function(e){try{let{configOptions:t,parentTelemetryObject:a,cardMetadata:r,refreshSDCardSection:i,sdCardActionClickHandler:o,refreshFeedCallback:s,goToPersonalizeSettingsCallback:n}=e,l=t&&t,d=r&&r.data&&function(e){let t=null;if(!e)return t;let a=JSON.parse(e);if(!a)return t;let r=[],i=[];if(a.items)for(let e=0;e<a.items.length;e++)a.items[e].imageUrl&&r.push(a.items[e]);if(a.randomItems)for(let e=0;e<a.randomItems.length;e++)i.push(a.randomItems[e]);r=t9(r),i=t9(i),(r.length>0||i.length>0)&&(t=[]);for(let e=0;e<r.length&&e<2;e++)t.push(function(e){let t=e.title,a=e.url,r=e.imageUrl,i=e.additionalAttributes.find(e=>"ProviderLogo"==e.key).value,o=e.additionalAttributes.find(e=>"ProviderName"==e.key).value,s=t7(e.additionalAttributes.find(e=>"DarkModeColor"==e.key).value);return{title:t,clickUrl:a,mainImageUrl:r,brandLogoUrl:i,brandName:o,gradientColor:s,category:"recommendation"}}(r[e]));for(let e=0;e<i.length&&t.length<4;e++)t.push(function(e){let t=e.title,a=e.url,r=e.imageUrl,i=e.additionalAttributes.find(e=>"ProviderLogo"==e.key).value,o=e.additionalAttributes.find(e=>"ProviderName"==e.key).value,s=t7(e.additionalAttributes.find(e=>"DarkModeColor"==e.key).value);return{title:t,clickUrl:a,mainImageUrl:r,brandLogoUrl:i,brandName:o,gradientColor:s,category:"suggestion"}}(i[e]));return t}(r.data);return(0,t5.bw)({id:"healthArticlesCard",experienceType:l?.configRef?.experienceType,mapperArgs:e},{id:"healthArticlesCard",childTemplateType:"health-articles-card",parentTelemetryObject:a,telObjectBase:a,healthArticlesConfigInfo:l,healthArticleData:d,sdCardActionClickHandler:o,refreshFeed:i||s,goToPersonalizeSettingsCallback:n,refreshSDCardSection:i})}catch(t){(0,ep.vV)(t6.NZ,`Error in feed layout: ${t}, mapperargs = ${JSON.stringify(e)}`)}return null})(e),viewTemplate:t4},[l.nativeAdCard]:tB.$,[l.placeholderCard]:tO.M,[l.pollsCard]:tE.N,[l.shoppingCarouselCard]:tq.f,[l.sportsCard]:tH.a,[l.trendingNowCard]:tG.Q,[l.weatherCard]:tY.j,[l.webContentCard]:tA.m,[l.videoCard]:tQ.O,[l.travelDestinationCard]:tK.t};var aa=a(29871),ar=a(94108),ai=a(58319),ao=a(96897),as=a(83756),an=a(66546),al=a(69846),ad=a(7446),ac=a(98378),ap=a(87283);let au=(e,t)=>{let a=document.createElement("style");a.innerHTML=t,e?.prepend?.(a)},ah=(e=[])=>e.reduce((e,t)=>eD[t?.type]?e+1:e,0),ag=e=>tx[e.riverSectionTemplate]?.cardSlots?.length||0;var am=a(87440),ay=a(63456),aC=a(29307),af=a(12867);let av="local",ab="promotions",ax="fromOurPartners",a_="bannerAd",aw="quizCardWC",aS={"ar-ae":"BBlFCyr","ar-eg":"BBlmAAj","ar-sa":"BBlFPtc","bn-in":"BBU7Qw4","da-dk":"BBlrVvd","de-at":"BBlROe9","de-ch":"BBZ1dPy","de-de":"BB19Lup4","el-gr":"BBlpx0F","en-ae":"BBlFzXn","en-au":"BB12Wlad","en-ca":"BB15zxqh","en-gb":"BB131KqR","en-ie":"BBlSybW","en-in":"BBlJDWj","en-my":"BBnmzKF","en-nz":"BBloYCJ","en-ph":"BBpkImc","en-sg":"BBnkfV1","en-xl":"BBJLSPs","en-za":"BBlq660","es-ar":"BBnlJDa","es-cl":"BBlrlMA","es-co":"BBloOIy","es-es":"BB12XBRm","es-mx":"BBu6hpo","es-pe":"BBlqzW8","es-us":"BBlsKCT","es-ve":"BBloH3J","es-xl":"BBlsFUm","fi-fi":"BBltzSJ","fr-be":"BBltAia","fr-ca":"BBHSUQ1","fr-ch":"BBm7onJ","fr-fr":"BB1fEVKT","he-il":"BBlrTD9","hi-in":"BBH8j5q","id-id":"BBqRsFe","it-it":"BB1334rQ","ja-jp":"CChcKo","ko-kr":"AAfBokA","mr-in":"AAEnx4n","nb-no":"BBlG6uP","nl-be":"BBltzP7","nl-nl":"BBlpya4","pl-pl":"BBls505","pt-br":"BBlrUUd","pt-pt":"AAg0WfA","sv-se":"BBlu2g8","te-in":"AAEns3L","th-th":"BBot3Jh","tr-tr":"BBlppGp","vi-vn":"BBov02b","zh-cn":"AAFsW17","zh-hk":"BBlBHZI"};function a$(e,t,a,r,i,o,s){if(!s)return;let n=e.indexOf(s);if(-1===n)return;let l=new Date,d=l.getDay(),c="#"+Math.trunc(l.getHours()).toString()+"#";if(r&&(d>=1&&d<=5&&r.includes(c)||(i=-1)),a&&d>=1&&d<=5&&a.includes(c)&&(i=1),null!=i&&!(i<0)&&!(i>=e.length)&&!(i>=t.length))if("1"===o)for(let a=i;a<n;a++){let{cardProviderConfig:r}=t[a]||{},{initialRequest:i}=r||{},{feedId:o,_:s}=i||{};if(o===a_||o===ab||o===ax);else{let r=e[a];e[a]=e[n],e[n]=r;let i=t[a];t[a]=t[n],t[n]=i}}else if("2"===o){let a=e[i];e[i]=e[n],e[n]=a;let r=t[i];t[i]=t[n],t[n]=r}else{let a=e.splice(n,1)[0];e.splice(i,0,a);let r=t.splice(n,1)[0];t.splice(i,0,r)}}function aA(e,t){return e.personalizedStripeConfig?.[t]}let aI=["973aa0a3-3a64-3640-ac8f-64c7abbb88d9"];function ak(e){if(e)try{return JSON.parse(e)}catch{return}}function aP(e){let t=ak(e);return t?.Model?.Tabs?.[0]?.primaryEntityId}function aT(e){let t=aP(e);return!!t&&aI.includes(t)}var aD=a(25854),aR=a(59010),aM=a(36597),aB=a(49371);let aL=(0,aM.wg)("debugalert");class aO{static getServiceUrl(e,t,a){let r=new URL((0,aB.e3)()?this.baseUrlForBot:this.baseUrl),i=new aR.m;return i.set(eh.T3.OneServiceContentMarketQspKey,t),i.set("ocid","health-verthp-feeds"),i.set("apikey","FywQv6H345wNCU4yKWraF2esI9qiMQFx90v53mMHrm"),i.set("$top","20"),eh.T3?.UserId&&i.set("user",eh.T3.UserId),eh.T3.ShouldUseFdheadQsp&&i.set("fdhead","prg-wpo-healthcs"),i.set("noCache","true"),i.set("$select",e),!1===a&&i.set("ranid",`${Math.random().toString().replace("0.","")}`),r.search=i.toString(),r.href}static async getDataFromOneService(e,t,a){try{if(!t)throw Error("Null or empty market");if("1"===aL)throw Error("this is a test alert");let r={method:"GET",headers:{accept:"application/json"}};t&&5===t.length&&t.substr(0,2);let i=this.getServiceUrl(e,t,a),o=await (0,eC.w)(async()=>{let e=await fetch(i,r);if(e){if(!e.ok)throw Error(`Status:${e.status} Url = ${i}`)}else throw Error(`Null response. Url = ${i}`);return e.json()},"getContentFromOneService");if(!o||!o.length||!o[0]||!o[0].data)throw Error(`Null, empty or invalid response Json. Url = ${i}`);return JSON.parse(o[0].data)}catch(t){let e;throw"object"==typeof t?e=t.message:"string"==typeof t&&(e=t),Error(`Error in one service call. ${e}`)}}}aO.baseUrl="https://api.msn.com/news/feed/segments/health",aO.baseUrlForBot="https://assets.msn.com/service/news/feed/segments/health";var aF=a(94818),aE=a(72627),az=a(47616);let aN=(0,a(73632).S)()?window.fetch.bind(window):(e,t)=>(0,az.hv)(e,800,t);class aU{async getUserPreferences(){let e,t=eh.T3.CurrentMarket||"en-us",a=eh.T3.UserId,r=`/api/v1/getpref/${a}?market=${t}`;try{if(!(e=await aN(this.getFalconServiceUrl("userpreferencefetcher","bing-shopping",r),this.getFalconRequestInit("GET")))||!e.ok)return[];let t=await e.json();if(!(t&&t.orderedVerticals))return[];return(t&&t.orderedVerticals&&{orderedVerticals:t.orderedVerticals.map(e=>({...e,name:e.name}))}).orderedVerticals.map(e=>e.name)}catch(e){return(0,ep.c_)(e,eu.QyC,"Error fetching user preference data",`usermuid: ${a}`),[]}}getFalconServiceUrl(e,t,a){return((0,aE.ou)().startsWith("localhost.msn.com")?`https://${e}.${t}.microsoft-testing-falcon.io`:`https://services.bingapis.com/${t}.${e}`)+a}getFalconRequestInit(e){return{method:e}}}let aq=(0,O.A)`
.stripe-slider-container{left:-52px}`,aW=(0,O.A)`
.title-arrow{-moz-transform:scale(-1,1);-webkit-transform:scale(-1,1);-o-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.stripe-slider-container{right:-52px}.scrollDownButtonContainerRight{right:inherit;left:25px}`,aH=(0,O.A)`
:host{--border-color:#e6e6e6;--heading-font-size:14px;--heading-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--heading-line-height:20px;--heading-start-padding:8px;--abstract-start-padding:8px;--dense-card-hero-width:300px;--dense-card-news-list-width:263px;--dense-list-item-height:39px;--dense-list-item-title-opacity:1;--dense-list-item-title-line-height:19px;--dense-card-new-layout1-margin-top:2px;--dense-card-new-layout1-width:280px;--dense-card-new-layout1-margin:0 11px;--dense-new-layout1-list-item-height:36px;--dense-new-layout1-list-item-max-width:261px;--dense-new-layout1-list-item-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--dense-new-layout1-list-item-font-size:15px;--fill-color:#fff;--heading-max-lines:2}.stripe-feed{height:100%;padding:0px 0px 60px;box-sizing:border-box}.river-section{margin-bottom:8px;display:flex;flex-flow:column;position:relative}.progress-ring-wrapper{display:flex;justify-content:center}.river-section-header-group{align-items:baseline;border-top:2px solid var(--border-color,#e6e6e6);display:flex;width:100%}.river-section-footer-group{align-items:baseline;display:flex;justify-content:space-between;width:100%}.stripe-title{padding-top:5px}.stripe-title h2{font-size:20px;font-weight:600;margin-top:unset;margin-bottom:20px;white-space:nowrap;display:inline-flex;align-items:center}msft-ad-label{min-width:32px;height:13px;margin-right:8px}.stripe-title h2 a{border-bottom:none;color:${H.l};position:relative;text-decoration:none}.stripe-title h2 a:hover{text-decoration:underline}.stripe-title h2 a span{position:absolute;top:.29rem}.stripe-title svg path{stroke:currentColor;stroke-width:1px}.sub-nav{display:grid;grid-template-columns:minmax(0,1fr);margin-inline-start:33px;writing-mode:horizontal-tb}.see-more{min-width:max-content;margin-top:5px;position:absolute;right:0;bottom:-4px}.see-more a{color:#0070c9;font-size:12px;font-weight:600;letter-spacing:0.64px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;text-decoration:none}.in-stripe-banner-ad{width:auto;height:auto;display:flex;justify-content:center;overflow:hidden}.pagination-sentinel{position:absolute;bottom:0;left:0;right:0;z-index:-1;height:200px}.stripe-slider-container{box-sizing:border-box;width:calc(100% + 106px);padding:0px 50px 0px}.stripe-slider-container.more-space{padding-bottom:16px}.stripe-slider-container-rail{padding-right:49px !important;padding-left:49px !important}.stripe-river-section{margin-right:3px}cs-feed-layout:part(heading){font-family:var(--heading-font-family)}msft-ad-label{--ad-label-fill-green:#1E6525;--ad-label-color-white:#FFF}msft-ad-label::part(control){box-sizing:border-box;display:inline-block;border-radius:2px;border-color:transparent;vertical-align:bottom}#liveshopping{display:none}#secondaryStripe{margin-top:-12px}`.withBehaviors(new Q.t(aq,aW),(0,E.G2)((0,O.A)` :host{--fill-color:#2b2b2b}`)),aj=`
:host{--heading-start-padding:16px;--heading-max-lines:2;--heading-line-height:28px}`,aK=' fluent-card,fluent-card msn-info-pane{position:relative}fluent-card .placeholder-card{animation:placeholder-animation 1s linear infinite;background-image:linear-gradient(90deg,#fafafa 0%,white 50%,#fafafa 100%);background-size:100px 100%;background-color:#fafafa;background-repeat:no-repeat;background-position:-50%}fluent-card msn-info-pane::part(previous-flipper),fluent-card msn-info-pane::part(next-flipper){opacity:1}@keyframes placeholder-animation{to{background-position:150%}}:host([data-section="finance"]) fluent-card[class="full"]:nth-of-type(1){background:none}:host([data-section="weather"]) fluent-card money-info-card::part(money-card),:host([data-section="tools"]) fluent-card money-info-card::part(money-card),:host([data-section="finance"]) fluent-card money-info-card::part(money-card){height:100%;width:100%;border-radius:4px;display:flex;justify-content:center}:host(cs-feed-layout[data-section="liveshopping"]){width:1271px;margin-right:0px !important;margin-left:0px !important}:host([data-section="partners"]) fluent-card msft-content-card img[slot="media"],:host([data-section="promotions"]) fluent-card msft-content-card img[slot="media"]{width:306px;height:200px;object-fit:cover}#displayAdCard{--elevation:4;display:flex;justify-content:center;height:var(--card-height,100%);width:var(--card-width,100%);padding-top:3px;box-sizing:border-box;background:var(--fill-color);border-radius:calc(var(--layer-corner-radius) * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))))}.info-pane-slide-title{-webkit-line-clamp:2 !important}',aV=" @media (prefers-color-scheme:dark){fluent-card .placeholder-card{background:#2b2b2b !important}}",aG=' .next-arrow,.previous-arrow{height:45px;width:45px}.next::part(next),.previous::part(previous){height:45px;width:45px}.next-arrow:before,.previous-arrow:before{content:"";opacity:0;position:absolute;inset:0px;transition:all 0.1s ease-in-out 0s}',aJ=`
.msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.msft-horizontal-card-slider::part(arrow-container){padding:5px 10px}.msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}`;var aQ=a(44704);let aX={topStripe:{name:"today.Hero",action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Section},secondaryStripe:{name:"today.Hero.standaloneEP",action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Section},headlineItemViewModel:{name:"HeadlineItemViewModel",action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Headline},todayHeadlines:{name:"todayHeadlines",action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Headline},todayStripeHeadlines:{name:"todayStripeHeadlines",action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Headline},title:{name:"title",action:ac.EG.Click,behavior:ac.MS.Navigate,type:ac.MJ.NavBar},seeMore:{name:"seeMore",action:ac.EG.Click,behavior:ac.MS.Navigate}};class aY{getSectionTelemetryTag(e,t){return e in aX?this.getTelemetryTag(aX[e]):this.getTelemetryTag({name:t||`stripe.${e}`,action:ac.EG.View,behavior:ac.MS.Show,type:ac.MJ.Section})}getTelemetryTag(e){return(0,aQ.N)(e.name,e.behavior,e.action,e.type).getMetadataTag()}}var aZ=a(65794),a0=a(12673),a1=a(12882),a2=a(4934),a3=a(31216);let a4=(e,t)=>{let a=t.findIndex(e=>(0,a3.RD)((0,a3.qK)(e)));if(-1!==a){let e=[...t],r=e[a];return e.splice(a,1),e.unshift(r),{backfillMetadata:e,backfillTemplateId:void 0,backfillCardTypeSlot:void 0}}return{backfillMetadata:t,backfillTemplateId:e?.templateId,backfillCardTypeSlot:[]}},a6=new Map([["video",a4],["video_stripe",a4]]),a5=(e,t,a)=>{let r={backfillMetadata:void 0,backfillTemplateId:void 0,backfillCardTypeSlot:void 0};try{let i=a6.get(e);if(!i||!a)return r;return i(a,t)}catch{return r}};var a8=a(38118);let a7=(0,af.a)().get("vptest"),a9=(0,eb.ZF)(),re="AdServiceCall.StripeWC",rt="inserted-card";function ra(e){return`stripewc.${e}`}class rr extends aZ.U{constructor(){super(...arguments),this.isFetchingStripes=!1,this.riverSectionLayoutData=[],this.ttvrFired=!1,this.isFeedExhausted=!1,this.enableRail=!1,this.visualReadinessCallbackSet=!1,this.appliedStyles=[],this.defaultLoadCount=2,this.infopaneSubItems=[],this.loadedWebComponents=[],this.nativeAdPlacementsMap={},this.pollsData={poll:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null},quiz:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null}},this.autosData={fallbackToContentCard:!1,data:null,enableStaticResponse:!1},this.riverSectionIndex=0,this.riverSectionResponses={},this.retryCountRecord={},this.nativeAdIsLoaded={},this.nativeAdIndiceRegionFilters=[],this.ttvrLogInfo={topStripeStartAt:[],topStripeFetchedAt:[],topStripeRetryAt:[],topStripeRenderedAt:void 0,topStripeAdsReadyAt:void 0,aboveThefoldReadyAt:void 0,ttvrFiredAt:void 0,ttvrBoundedImage:[]},this.hasSectionInterest={},this.dynamicRankingInterests=[],this.dynamicInterestsFetched=!1,this.shoppingCarouselData={data:[],fallbackToContentCard:!1},this.replacementInfopaneCards={},this.shouldOverrideInfopaneCards=!1,this.customInsertedCards={},this.overrideHasSlideShow=!1,this.dependencies=new Set,this.onBreakpointCallback=e=>{this.columnArrangement=e.toUpperCase(),window.setTimeout(()=>{this.updateShowDot(),this.updateStripes()})},this.initCardAction=e=>{this.cardActionRef||(this.cardActionRef=this.shadowRoot.querySelector?.("card-action")),this.cardActionRef?.updateCardActionProps({...e})},this.getVisualReadinessCallback=(e,t,a)=>{let r=t===l.infopaneCard?l.infopaneCard:e?.cardContent?.id,i=this.riverSectionIds[0];return this.getSectionAdPlacementIndices(i).includes(a)||this.dependencies.add(r),()=>{this.dependencies.has(r)&&this.dependencies.delete(r),0===this.dependencies.size&&this.setVisuallyReadyMarkers()}},this.getSectionAdPlacementIndices=e=>{let t=[...this.config?.adPlacements?.[e]?.placements||[],...this.config?.cmsAdPlacements?.[e]?.placements||[]],a=[];return t.forEach(e=>{e.region!==eT.pL.Infopane&&e.indices?.length&&a.push(...e.indices)}),a},this.setVisuallyReadyMarkers=()=>{this.ttvrFired||(this.ttvrFired=!0,(0,ex.D)(()=>{this.markVisuallyReady(),this.ttvrLogInfo.ttvrFiredAt=performance.now(),this.config.enableBulkFetch?this.updateStripes():this.updateStripes(this.riverSectionIds[this.riverSectionLayoutData.findIndex(e=>void 0!==e)]),this.initTopStripeNativeAds().then(()=>{let e=(0,as.Kl)();e&&an.m?.updateVisuallyReadyTiming?.getActionSender(e)?.send((0,as.ez)(el.p_1,void 0,void 0,void 0,window.performance.now()))})}))},this.setPaginationObserver=()=>{"IntersectionObserver"in window&&this.paginationSentinelRef&&(this.sentinelObserver=new IntersectionObserver(this.onSentinelChange),window.requestAnimationFrame(()=>{this.sentinelObserver.observe(this.paginationSentinelRef)}))},this.onSentinelChange=e=>{!e||e.length<1||!this.ttvrFired||e[0].isIntersecting&&this.onUserPaginate()},this.onUserPaginate=()=>{this.riverSectionIndex<this.riverSections.length?this.fetchStripes(this.config.lazyLoadCount):this.isFeedExhausted=!0},this.isPaginationVisible=()=>{if(!this.paginationSentinelRef)return!1;let{y:e,height:t}=this.paginationSentinelRef.getBoundingClientRect();return e-t<Math.max(document.documentElement.clientHeight,window.innerHeight)},this.processLayoutStyles=()=>{let{stripeStyles:e={}}=this.config;Object.keys(e).forEach(t=>{if(!this.appliedStyles.includes(t)){var a,r,i;let o,s,n,l;a=e[t],r=t,i=this,s=r.split(" "),n=i,((e,t)=>{let a=e?.shadowRoot||e;if(!a||a.querySelector("style.stripe-style"))return;let r=document.createElement("style");r.className="stripe-style",Object.keys(t).forEach(e=>{r.innerHTML+=`${e} { ${t[e]} }
`}),a.prepend(r)})(o=(l=()=>{let e=s.shift();return(n=n?.shadowRoot?.querySelector?.(e)||n?.querySelector?.(e),s.length&&n)?l():n})(),a),o&&this.appliedStyles.push(t)}})},this.onDisplayAdHeightChange=e=>{let{htmlId:t,height:a}=e?.detail||{};if(t?.startsWith("rectangle1")&&a&&!this.enableRail){let{longDisplayAdLayoutTemplate:e}=this.config,t=this.riverSectionIds[0];if(!e)return;this.riverSectionLayoutData[0].templateId=600===a?e:this.riverSections[0].riverSectionTemplate,this.updateStripes(t)}}}isFeedExhaustedChanged(e,t){if(!t)return;this.sentinelObserver?.disconnect();let a=this.config?.cardProviderConfig?.initialRequest?.count||30;this.onFeedEndCb?.({cardCount:a})}async enableRailChanged(e){if("boolean"!=typeof e||!this.config)return;await new Promise(e=>window.setTimeout(e));let{longDisplayAdLayoutTemplate:t}=this.config;this.enableRail&&t&&this.riverSectionLayoutData[0]?.templateId===t&&(this.riverSectionLayoutData[0].templateId=this.riverSections[0].riverSectionTemplate,this.updateStripes(this.riverSectionIds[0]))}async experienceConnected(){this.stripeWCTelemetry||(this.stripeWCTelemetry=new aY),await a8.D.initConfig(),(0,eo.registerCSResponsiveCard)(),(0,es.C)(),en.T.define(h.G.registry),this.initRiverSectionAndId(),a7&&(this.riverSectionIds.forEach(e=>(0,e_.cX)(ra(e))),(0,e_.gR)().then(()=>{Object.assign(a9,{vpready:performance.now()}),performance.mark("vpready")})),this.initFeedLayoutData(),this.topStripeCardProvider=new al.f(this.config.cardProviderConfig),this.config.paginationSentinelHeight&&(this.sentinelHeight=`height: ${this.config.paginationSentinelHeight}px;`);let{nativeAdIndiceRegionFilters:e=[]}=this.config;if(this.nativeAdIndiceRegionFilters=e.map(e=>e.toLowerCase()),this.fetchStripes(this.config.initialLoadCount),this.config.buyDirectInfopaneCard?.primaryServiceClientSettings&&this.config.buyDirectInfopaneCard?.shoppingCarouselAPISettings)try{this.shoppingPrimaryServiceClient=this.shoppingPrimaryServiceClient||new aF.J(window.fetch.bind(window),this.config.buyDirectInfopaneCard.primaryServiceClientSettings,this.config.buyDirectInfopaneCard.shoppingCarouselAPISettings,null,location.href)}catch(e){ad.YT.sendAppErrorEvent({...eu.PxO,message:"Failed to initialize buy direct infopane service client",pb:{...eu.PxO.pb,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}}async initFinanceUserService(){try{let e={experienceType:el.ahW,instanceSrc:"default"};if(this.moneyInfoCardWCConfig=(await aa.L.getConfig(e)).properties,!this.financeUserService){let{FinanceServices:e,getFinanceDataConnector:t}=await Promise.all([a.e("node_modules_crypto-js_index_js"),a.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),a.e("libs_finance-service-library_dist_index_js")]).then(a.bind(a,43818));t().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=e.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)}}catch(e){(0,ep.vV)(eu.yIP,`Failed to initialize finance services: ${e.message}`)}}async initBuyDirectUserService(){try{let e={experienceType:el.Yeu,instanceSrc:"index_Buydirect"};this.buyDirectConfig=(await aa.L.getConfig(e)).properties,this.buyDirectServiceClient||(this.buyDirectServiceClient=new aF.J(window.fetch.bind(window),this.buyDirectConfig.primaryServiceClientSettings,this.buyDirectConfig.shoppingCarouselAPISettings,null,location.href))}catch(e){(0,ep.vV)(eu.$oH,`Failed to initialize buy direct services: ${e.message}`)}}async initUserPreferenceFetcherService(){try{this.userPreferenceFetcherService||(this.userPreferenceFetcherService=new aU)}catch(e){(0,ep.vV)(eu.QyC,`Failed to initialize user reference service: ${e.message}`)}}initRiverSectionAndId(){if(this.config.stripePlacementOverwrite){let e=new Set(this.config.stripePlacementOverwrite);Object.entries(this.config.childExperienceReferencesWC).forEach(([t,{hide:a}])=>{a||e.has(t)||ad.YT.sendAppErrorEvent({...eu.nlb,message:"stripe key from childExperienceReferencesWC does not exist in stripePlacementOverwrite",pb:{...eu.nlb.pb,customMessage:`stripe key: ${t}`}})});let t=[];for(let e of this.config.stripePlacementOverwrite){let a=this.config.childExperienceReferencesWC[e];a?a.hide||t.push(e):ad.YT.sendAppErrorEvent({...eu.nlb,message:"stripe key from stripePlacementOverwrite does not exist in childExperienceReferencesWC",pb:{...eu.nlb.pb,customMessage:`stripe key: ${e}`}})}this.riverSectionIds=t}else{let e=[];Object.keys(this.config.childExperienceReferencesWC).forEach(t=>{this.config.childExperienceReferencesWC[t].hide||e.push(t)}),this.riverSectionIds=e}let e=this.config.riverSectionCardProviderConfig;this.riverSections=this.riverSectionIds.map(t=>{let a=this.config.childExperienceReferencesWC[t];return{...a,riverCardProvider:new al.f((0,am.A)({},e,a.cardProviderConfig))}})}getExperienceType(){return el.p_1}shadowDomPopulated(){this.columnArrangement=(0,e$.TU)().currentColumnArrangement.toUpperCase(),(0,e$.TU)().subscribe(this.onBreakpointCallback),this.updateShowDot(),window.addEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange),this.config&&this.config.adCookieSyncConfig&&this.config.adCookieSyncConfig.isCookieSyncEnabled&&(this.cookieSyncService=new aD.n(this.config.adCookieSyncConfig||{}),this.cookieSyncService.processCookieSync()),this.setPaginationObserver()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange)}updateShowDot(){let e=this.getDisplayedColumnLayout();this.isShowDot=["C2","C3"].includes(e)||"C4"===e&&this.config.isC5Enabled}async refreshFeed(){this.riverSections.forEach(({riverCardProvider:e})=>e.clearCache()),this.nativeAdPlacementsMap={},this.riverSectionIndex=0,this.initFeedLayoutData(),this.fetchStripes(this.config.initialLoadCount)}initFeedLayoutData(){this.riverSectionLayoutData=Array(this.riverSectionIds.length).fill(void 0)}async fetchStripes(e=this.defaultLoadCount){if(this.isFetchingStripes)return;let t=0;this.isFetchingStripes=!0;let a=()=>{this.isFetchingStripes=!1,(this.isPaginationVisible()||this.config.enableBulkFetch)&&this.riverSectionIndex<this.riverSections.length&&this.fetchStripes(this.config.lazyLoadCount),this.riverSectionIndex>=this.riverSections.length&&(ew.M.singleMark("StripeWC-FullPageLoaded"),this.isFeedExhausted=!0)},r=aA(this.config,"finance"),i=aA(this.config,"sports"),o=aA(this.config,"buydirect"),s=aA(this.config,"dynamicStripe"),n=[];if((r?.moveStripePosition||r?.personalizeInsertCard)&&n.push(this.fetchFinanceInterests()),i?.moveStripePosition&&n.push(this.fetchSportsInterests()),s?.enabled&&n.push(this.fetchDynamicInterests()),await Promise.all(n),s?.runBeforeFinanceRanking&&this.updateDynamicSectionRanking(s),s?.skipFinanceRanking&&0!=this.dynamicRankingInterests.length||this.updateFinanceSectionRanking(r),this.updateSportsSectionRanking(i),s?.runBeforeFinanceRanking||this.updateDynamicSectionRanking(s),o?.moveStripePosition&&(await this.initBuyDirectUserService(),this.buyDirectServiceClient&&(void 0==this.hasSectionInterest.buydirect&&await this.updateUserBuyDirectInterest(),this.hasSectionInterest.buydirect>0&&(a$(this.riverSectionIds,this.riverSections,void 0,void 0,o.newStripePositionIndex,"1","buydirect"),ad.YT.addOrUpdateTmplString("BuyDirectStripeMovedToTop")))),this.riverSectionIndex>0&&this.config.enableBulkFetch){let t=[],r=this.riverSectionIndex;for(let a=r;a<Math.min(this.riverSections.length,r+e);a++){let e=this.riverSectionIds[a],r=this.riverSections[a],{feedId:i,count:o}=r.cardProviderConfig.initialRequest;i===a_||i===ab||i===ax?t.push(new Promise(e=>e(void 0))):i===av?t.push(this.fetchLocalNewsRiverContent(o)):t.push(this.fetchRiverContent(e,r))}Promise.all(t).then(async t=>{for(let a=r;a<Math.min(this.riverSections.length,r+e);a++){let e=this.riverSectionIds[a];this.riverSectionResponses[e]=t[a-r],await this.fetchStripe(this.riverSectionIndex++)}this.isFetchingStripes=!1}).catch(async e=>{console.error(e)}).finally(()=>{a()})}else{let r=async()=>{if(this.riverSectionIndex<this.riverSections.length&&t<e){try{await this.fetchStripe(this.riverSectionIndex++),this.riverSectionLayoutData[this.riverSectionIndex-1]&&t++}catch(e){console.error(e)}!this.ttvrFired&&this.riverSectionLayoutData[this.riverSectionIndex-1]&&((0,as.Qc)().then(async()=>{this.ttvrLogInfo.aboveThefoldReadyAt=performance.now(),this.ttvrFired||(this.setVisuallyReadyMarkers(),ad.YT.sendAppErrorEvent({...eu.HR1,message:"TTVR is blocked due to the first image is not available.",pb:{...eu.HR1.pb,customMessage:JSON.stringify(this.ttvrLogInfo)}}))}),await (0,eS.dT)()),await r()}};await r(),a()}}async fetchFinanceInterests(){await this.initFinanceUserService(),this.financeUserService&&(void 0==this.hasSectionInterest.finance||void 0==this.hasSectionInterest.casualGames)&&await this.updateUserFinanceInterest()}async fetchSportsInterests(){await this.updateUserSportsInterest()}async fetchDynamicInterests(){await this.initUserPreferenceFetcherService(),this.userPreferenceFetcherService&&!this.dynamicInterestsFetched&&this.updateDynamicRankingInterests()}updateFinanceSectionRanking(e){e?.moveStripePosition&&this.hasSectionInterest.finance>e.financeInterestScore&&a$(this.riverSectionIds,this.riverSections,e.moveStripeToTopHours,e.moveStripeToIndexHours,e.newStripePositionIndex,e.adsLocStrategy,"finance")}updateSportsSectionRanking(e){e?.moveStripePosition&&this.hasSectionInterest.sports>0&&a$(this.riverSectionIds,this.riverSections,e.moveStripeToTopHours,e.moveStripeToIndexHours,e.newStripePositionIndex,e.adsLocStrategy,"sports")}updateDynamicSectionRanking(e){if(this.dynamicRankingInterests.length>0){let t=e.newStripePositionIndex;for(let a=0;a<this.dynamicRankingInterests.length;a++){let r=this.dynamicRankingInterests[a];a$(this.riverSectionIds,this.riverSections,void 0,void 0,t,e.adsLocStrategy,r),-1!=this.riverSectionIds.indexOf(r)&&(t=this.riverSectionIds.indexOf(r)+1)}}}async getWeatherData(e){let t={};t.requestInfo={isStaleRefresh:e};let{PageBase:r}=await a.e("libs_experiences-page-base-wc_dist_index_js").then(a.bind(a,40817));this.weatherDataConnector=await r.getInstance().rootReducer.getDataConnector(ed.ni),this.weatherDataConnector&&(this.activeLocation=await this.weatherDataConnector.fetchActiveStateforWeather(null,null,t))}async fetchAutosData(e){try{let t=await ev(this.autosData.enableStaticResponse,n.MSNHomePage);t.includes("Listing")?(this.autosData.data=t,this.updateStripes(e)):this.autosData.fallbackToContentCard=!0}catch(e){this.autosData.fallbackToContentCard=!0,(0,ep.c_)(e,eu.uqN,"send request to segments api failed")}}async fetchStripe(e){let t,a=this.riverSections[e],r=this.riverSectionIds[e],{feedId:i,count:o}=a.cardProviderConfig.initialRequest,s=this.getOverrideFeedId(r,i),n=s===i?a:this.getRiverSectionLayoutWithOverrideFeedId(a,s),d=!1,c=[];if(0===e&&this.ttvrLogInfo.topStripeStartAt.push(performance.now()),this.hasMoneyInfoCardWC(r)&&!this.loadedWebComponents.includes[l.moneyInfoCardWC]?this.fetchMoneyInfoCardData(r):this.hashealthArticleInfoCardWC(r)&&!this.loadedWebComponents.includes[l.healthArticlesCardWC]?this.fetchHealthInfoCardData(r):this.hasTravelDestinationCardWC(r)&&!this.loadedWebComponents.includes[l.travelDestinationCard]?this.fetchTravelDestinationCardData(r):this.hasSportsInfoCardWC(r)&&!this.loadedWebComponents.includes(l.sportsCard)&&this.fetchSportsInfoCardData(r),s===a_)c=Array(o).fill({type:eT.pL.Article});else if(s===ab||s===ax)c=this.createStripeAdCardDefaultMetadata(o),this.config.cmsAdPlacements?.[r]&&this.loadNativeAd(r,!0),this.loadNativeAd(r),d=!0;else if(s===av){await this.getWeatherData(),t=this.riverSectionResponses[r]||await this.fetchLocalNewsRiverContent(o);let e=ar.Rb.Locale;if(ar.Rb.ClientSettings.locale.market===this.activeLocation.isoCode.toLowerCase()){let{locality:r,displayName:i}=this.activeLocation;(0,ay.A)(t,"value[0].subCards[0].feed.feedName",r),a.riverSectionTitle=i,"es-ar"!=e&&(a.seeMoreUrl+="local"),c=t.subCards||[]}}else t=this.riverSectionResponses[r]||await this.fetchRiverContent(r,n),s!==i&&this.isFeedResponseUnderfilled(t,a)&&(t=await this.getFallbackFeedResponse(t,r,a)),t?.cardMetadata?.length?(em.WR.removeOcidFromRiverCardProviderResponse(t),c=t.cardMetadata,this.loadNativeAd(r),0===e&&this.ttvrLogInfo.topStripeFetchedAt.push(performance.now())):this.retryFetchingStripe(e),d=!0;this.addRiverSection(e,a,c,d)}async retryFetchingStripe(e){let t=this.config.retryTimeOutMs&&this.config.retryTimeOutMs>=0?this.config.retryTimeOutMs:1e3,a=this.config.maxRetryTimes&&this.config.maxRetryTimes>=0?this.config.maxRetryTimes:0,r=this.riverSectionIds[e];this.retryCountRecord[r]||(this.retryCountRecord[r]=0),this.retryCountRecord[r]>=a||(this.retryCountRecord[r]++,ad.YT.sendAppErrorEvent({...eu.sOF,message:`Start retrying to fetch [${r}] in ${t}ms.`,pb:{...eu.sOF.pb,customMessage:`Retry count: ${this.retryCountRecord[r]}`}}),window.setTimeout(async()=>{0===e&&this.ttvrLogInfo.topStripeRetryAt.push(performance.now()),await this.fetchStripe(e),0===e&&await this.initTopStripeNativeAds()},t))}addRiverSection(e,t,a=[],r=!0){let i=a.filter(e=>{if(eD[e.type])return e;ad.YT.sendAppErrorEvent({...eu.vES,message:"Unsupported content card type in OneService metadata.",pb:{...eu.vES.pb,customMessage:`Card type [${e.type}] needs to be added to MSNHomepageOneServiceMetadataTypeToCardTypeMap`}})});if(!i?.length)return;let o=this.riverSectionIds[e],s=t.riverSectionTemplate,n=i,d=[],{adPlacements:c={},cmsAdPlacements:p={},insertCardInSlot:u={}}=this.config,h=this.config.slotToCardType||{},g=(0,aC.A)(h[o])||[],{backfillMetadata:m,backfillCardTypeSlot:y,backfillTemplateId:C}=a5(o,n,this.config.childExperienceReferencesWC?.[o]?.backfillConfigs);n=m||n,g=y||g;let f=tx[s=C||s]||{},v=aA(this.config,o);v?.personalizeInsertCard&&this.hasSectionInterest[o]>0&&(u[o]=u[o].filter(e=>e?.cardType!==v.cardToDisable));let b=[...c[o]?.placements||[],...p[o]?.placements||[]],x=[...g||[],...u[o]||[]];b.forEach(e=>{e&&e.region!==eT.pL.Infopane&&e?.indices.forEach(e=>{let t=e-1;d.includes(t)||d.push(t)})});let _=[];x.forEach(e=>{if(e&&e?.cardType!==l.contentCard&&e?.cardType!==l.videoCard&&e?.cardType!==l.pollsCard){if(e?.cardType===l.denseCard)return void e.positions?.forEach(t=>{let a=parseInt(t.slot.replace("slot",""))-1;_.push({index:a,count:e.args?.denseListSize||0})});e.positions?.forEach(e=>{let t=parseInt(e.slot.replace("slot",""))-1;_.forEach(e=>{e.index<t&&(t+=e.count-1)}),d.includes(t)||d.push(t)})}}),(d=d.sort((e,t)=>e>t?1:e<t?-1:0)).forEach(e=>{let t=n.pop();n.splice(e,0,t)}),this.riverSectionLayoutData[e]={cardMetadataList:n,feedData:this.mapFeedData(o,n,f,this.config.openLinksInNewTab,this.telemetryObject,g,e),hasPlaceHolderAds:r,insertBannerAd:t?.insertBannerAd,pivotsNav:t?.pivotsNav,riverSectionTitle:t?.riverSectionTitle,riverSectionTitleUrl:(0,ai.bI)(t?.riverSectionTitleUrl?t.riverSectionTitleUrl:t?.seeMoreUrl),riverSectionTitleColor:t?.riverSectionTitleColor,seeMoreUrl:(0,ai.bI)(t?.seeMoreUrl),seeMoreText:t?.seeMoreText,adLabel:t?.adLabel,sectionId:o,telemetryName:t?.telemetryName,templateId:s,adSlugGA:this.config.adSlugGA,isMsnHPAdSlug:this.config.isMsnHPAdSlug,enableSafeAds:!!this.config?.enableSafeAds,disableSlider:this.config.disableStripeSlider,leftArrow:this.config.localizedStrings.previousArrow,rightArrow:this.config.localizedStrings.nextArrow,disableStripeTheme:this.config.disableStripeTheme,isC5Enabled:this.config.isC5Enabled,isDVEnabled:this.config?.isDVEnabled},0===e&&((0,eS.yi)(`${this.getExperienceType()}TopStripeRendered`),this.ttvrLogInfo.topStripeRenderedAt=performance.now()),"shopping"===o&&this.config.overrideBingUrlsAugmentations&&(this.riverSectionLayoutData[e].riverSectionTitleUrl=eA.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[e].riverSectionTitleUrl,"msn"),this.riverSectionLayoutData[e].seeMoreUrl=eA.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[e].seeMoreUrl,"msn")),this.riverSectionLayoutData=[...this.riverSectionLayoutData]}async addFlipperStyles(){let e,t=await (e=this.shadowRoot,new Promise(t=>{let a=new MutationObserver((0,ap.A)(()=>{t(e?.querySelectorAll?.("msft-horizontal-card-slider")),a.disconnect()}));a.observe(e,{childList:!0,subtree:!0})}));if(t?.length&&t[0].shadowRoot)for(let e=0;e<t.length-1;e++)au(t[e].shadowRoot,aG)}async fetchRiverContent(e,t){let a,r=this.riverSectionIds[0],i="";e===r&&(i=` TTVR log: ${JSON.stringify(this.ttvrLogInfo)}`);try{if(e===r){if(ao.WD&&t.enableWebWorker&&!this.config.disableWWForTopStripe){let e=this.config?.cardProviderConfig?.initialRequest?.timeoutMs||1e3;a=await t.riverCardProvider.fetchFromWebWorker("myfeed",e)}else window.enableEarlyRiverRequest&&window.topStripeResponse&&(window.enableEarlyRiverRequest=!1,a=window.topStripeResponse);a?.cardMetadata?.length||(a=await this.topStripeCardProvider.fetch())}else a=await t.riverCardProvider.fetch({})}catch(t){ad.YT.sendAppErrorEvent({...eu.sOF,message:`Content fetch failed for Stripe WC river section when loading ${e}`,pb:{...eu.sOF.pb,customMessage:`Failed with exception : ${JSON.stringify(t)} ${i}`}})}if(a?.cardMetadata?.length){if(e!==r&&a.cardMetadata[0]?.type===eT.pL.Infopane)a.cardMetadata=a.cardMetadata.filter(e=>e.type!==eT.pL.Infopane);else if(e===r&&a.cardMetadata[0]?.type===eT.pL.Infopane){let e=this.config.cardProviderConfig?.initialRequest?.infopaneItemCount;e&&a.cardMetadata[0].subItems.length>e&&(a.cardMetadata[0].subItems=a.cardMetadata[0].subItems.slice(0,e))}"esports"===e&&a?.cardMetadata?.length<8&&ad.YT.sendAppErrorEvent({...eu.nZM,message:`Content fetch content is less than 8 for Stripe WC river section when loading ${e}`,pb:{...eu.nZM.pb,customMessage:`Returned response: ${JSON.stringify(a)} ${i}`}})}else ad.YT.sendAppErrorEvent({...eu.uIm,message:`Content fetch failed for invalid empty Stripe WC river section when loading ${e}`,pb:{...eu.uIm.pb,customMessage:`Returned response: ${JSON.stringify(a)} ${i}`}});return a}async fetchLocalNewsRiverContent(e){let t,r,{PageBase:i}=await a.e("libs_experiences-page-base-wc_dist_index_js").then(a.bind(a,40817));this.weatherDataConnector=await i.getInstance().rootReducer.getDataConnector(ed.ni);let{latitude:o,longitude:s}=this.weatherDataConnector.getCurrentState().currentLocation||this.activeLocation,n=`${o}|${s}`,{apikey:l}=this.config,{ocid:d}=this.config.riverSectionCardProviderConfig.initialRequest,c=eh.T3.CurrentMarket;r=`${eh.T3.AssetsUrl}/service/MSN/Feed/me?$top=${e}&cm=${c}&location=${n}&ocid=${d}&apikey=${l}&cipenabled=false&DisableTypeSerialization=true&query=localnews&queryType=myfeed&wrapodata=false&responseSchema=cardview`,this.has1SFlight("1s-viewurldomain")&&(r=`${r}&fdhead=1s-viewurldomain`);try{t=await fetch(r)}catch(e){ad.YT.sendAppErrorEvent({...eu.sOF,message:"Content fetch failed for Local News River section.",pb:{...eu.sOF.pb,url:r,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}return t?.json()}async fetchShoppingCarouselData(e){try{this.shoppingCarouselData.data?.length?this.updateStripes(e):this.shoppingCarouselData.fallbackToContentCard=!0}catch(e){this.shoppingCarouselData.fallbackToContentCard=!0}}async fetchShoppingCarouselBDData(e){let t=await e.getShoppingEntitiesDataUsing1S(!0,1e3);return t||null}async getBuyDirectCard(){let e=await this.fetchShoppingCarouselBDData(this.shoppingPrimaryServiceClient);if(!e||!e.shoppingEntities||!e.shoppingEntities.length)return ad.YT.sendAppErrorEvent({...eu.ca0,message:"No buy direct infopane card data from 1S.",pb:{...eu.ca0.pb,customMessage:"No buy direct infopane card data from 1S."}}),null;let t=e.shoppingEntities[0];if(!t.globalOfferId||!t.title||!t.imageInfo.sourceImageUrl)return ad.YT.sendAppErrorEvent({...eu.ca0,message:"Invalid buy direct infopane card data data from 1S.",pb:{...eu.ca0.pb,customMessage:"Invalid buy direct infopane card data from 1S."}}),null;let a=this.config.buyDirectInfopaneCard.formcode,r=this.config.buyDirectInfopaneCard.trafsrc,i=this.config.bwmCampaignCode??"",o=this.config.bdBlurredBackground?"InfoBuyDirectCard":"BuyDirectCard";o+=this.config.buyDirectEventDecoration?this.config.buyDirectEventDecoration:"",o+=this.config.disableBuyDirectCashback?"_NoCashback":"";let s=eI.u.buildAbsoluteUrl({market:eh.T3.CurrentMarket,pid:t.globalOfferId,title:t.title,trafsrc:r,ocid:r,formCode:a,isBing:this.config.bdDirectToBing,isBWM:this.config.isBWM,campaignCode:i}),n=t.cashbackInfo?.cashbackPercentage&&t.cashbackInfo?.cashbackPercentage>0?`${t.cashbackInfo.cashbackPercentage}%`:void 0;this.config?.enableForumCashback&&!n&&ad.YT.sendAppErrorEvent({...eu.LOQ,message:"Buy Direct stripe offer failed to fetch dynamic cashback",pb:{...eu.LOQ.pb,customMessage:"Empty cashback info"}});let l=(0,ek.Yd)((0,ek.Lm)()),d=n||l,c=d?`Buy with Microsoft - ${d} Cash back and free shipping on all orders`:"Buy with Microsoft - Earn Cash back";return{type:"link",cardContent:{abstract:c=this.config.disableBuyDirectCashback?"Buy with Microsoft - Free shipping on all orders":c,destinationUrl:`${s}`,id:`${t.id}`,kicker:`${t.title}`,title:`${t.priceInfo?.price?t.priceInfo.price+" ":""}${t.title}`,type:"link",category:{product:"news"},images:[{id:`${t.globalOfferId}`,url:`${t.imageInfo.sourceImageUrl}`}]},id:o}}getInfopaneCardOverride(e,t,a,r,i,o){return{type:"link",cardContent:{destinationUrl:r,title:i,type:"link",category:{product:"news"},images:[{url:(0,eP.Je)(o,a,t)}]},id:e}}mapFeedData(e,t,a,r,i,o,s){if(!t||!t.length||!a)return null;let n={defaultLayout:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]},{rowHeightPx:d,colWidthPx:c,gutterPx:p,cardSlots:u=[]}=a,h=s>2?s-2:s-1,g="topStripe"===e?{C5:0,C4:0,C3:0,C2:0}:{C5:4+3*h,C4:4+3*h,C3:4+3*h,C2:6+3*h},m=this.columnArrangement.toLowerCase(),{slotToCardType:y={},insertCardInSlot:C={}}=this.config,f={...this.config.infopaneConfig||{}},v={};return C[e]&&C[e].forEach(({cardType:a,positions:r,args:i})=>{let o=r.find(e=>!e.column||e.column===m);if(o){let r=u.findIndex(e=>e.grid_area===o.slot);if(v[o.slot]=a,r>-1){let o={type:rt,cardContent:{insertedCardType:a,insertedCardArgs:i},id:`${a}-slot-${r+1}`};if(t[r]?.id===o.id)return;if(a===l.pollsCard){let a=i.pollsCardConfigInfo.instanceId===aw,s=a?this.pollsData.quiz:this.pollsData.poll;!s.fallbackToContentCard&&(s.fetchingTriggered?s.data&&(t[r]&&t.push(t[r]),t[r]=o):this.fetchQuizData(e,a))}else if(a===l.denseCard){let{denseListSize:e,denseDataConfigOptions:a}=i,s=t.splice(r,e);a?.enableDenseLayout1&&s.unshift(s[0]),o.subItems=s,t.splice(r,0,o)}else if(a===l.shoppingCarouselCard){let a=["index_LiveShopping_Shopping","index_LiveShopping_Lifestyle"];a.includes(i.configOptions.configRef.instanceSrc)&&!this.shoppingCarouselData?.fallbackToContentCard&&(this.shoppingCarouselData.data?.length?(t[r]&&t.push(t[r]),t[r]=o):this.fetchShoppingCarouselData(e)),(this.shoppingCarouselData.data?.length||!a.includes(i.configOptions.configRef.instanceSrc))&&(t[r]&&t.push(t[r]),t[r]=o)}else a===l.sportsCard?this.shouldInsertSportsInfoCard()?(t[r]&&(t.push(t[r]),this.customInsertedCards[a]={metadataIndex:r,cardData:t[r],backupIndex:t.length-1}),t[r]=o):this.sportsSegmentResponsePromise||this.fetchSportsInfoCardData(e):(t[r]&&(t.push(t[r]),this.customInsertedCards[a]={metadataIndex:r,cardData:t[r],backupIndex:t.length-1}),t[r]=o)}}else if(this.customInsertedCards[a]){let{metadataIndex:e,cardData:r,backupIndex:i}=this.customInsertedCards[a];t.splice(i,1),t[e]=r,this.customInsertedCards[a]=void 0}}),u.forEach((a,s)=>{let u=t[s];if(!u)return;let h=u.cardContent?.insertedCardType||eD[u.type],C=o||y[e],b=C?C.find(({positions:e})=>e.some(e=>(!e.column||e.column&&e.column===m)&&e.slot===a?.grid_area)):null;if(b&&(h=b.cardType),!h)return;let x=parseFloat(a?.grid_area?.replace("slot","")),_=null,w=()=>this.config.enableNewTTVR?this.getVisualReadinessCallback(u,h,x):this.setVisuallyReadyMarkers;if(!this.ttvrFired){if(e===this.riverSectionIds[0]){if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&h===l.infopaneCard)this.visualReadinessCallbackSet=!0,_=w(),u.subItems=u.subItems.map(e=>({...e,visualReadinessCallback:_})),this.ttvrLogInfo.ttvrBoundedImage.push(`today hero infopane: ${u.subItems[0]?.cardContent?.images[0]?.url}`);else if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&h===l.contentCard){this.visualReadinessCallbackSet=!0;let e=(0,t_.Ie)(u);e&&(this.ttvrLogInfo.ttvrBoundedImage.push(`today hero content: ${e.url}`),_=w())}}else if(h===l.contentCard){let e=(0,t_.Ie)(u);e&&(this.ttvrLogInfo.ttvrBoundedImage.push(`river content: ${e.url}`),_=this.setVisuallyReadyMarkers)}}let S={...this.config,...this.config.childExperienceReferencesWC[e],isMsnHpExternalLinkCard:"link"===u.type},$=this.nativeAdPlacementsMap[e];(h===l.nativeAdCard||h===l.infopaneCard)&&$?.length&&(S.isGreyAdsLabelEnabled=$[0]?.isGreyAdsLabelEnabled),u.type===eT.pL.Infopane&&(S.useMsnHomepageCardTemplate=!0,this.ttvrFired||(f.disableAutoRotate=!0));let A=u?.cardContent?.insertedCardArgs?.pollsCardConfigInfo?.instanceId===aw?this.pollsData.quiz:this.pollsData.poll;(!this.ttvrFired&&u.type===rt||this.getSectionAdPlacementIndices(e).includes(x)&&!this.nativeAdIsLoaded[e]||v[a?.grid_area]===l.pollsCard&&A.isFetching)&&(h=l.placeholderCard);let I=(u?.cardContent?.type||u?.type)===eT.pL.WebContent,k={cardMetadata:u,cardSlot:a,parentTelemetryObject:i,openLinksInNewTab:r||S.isMsnHpExternalLinkCard,openLinksInCurrentTab:!r&&!S.isMsnHpExternalLinkCard,isAnaheimDesign:!0,refreshFeedCallback:()=>this.refreshFeed(),visualReadinessCallback:_,localizedStrings:this.config.localizedStrings||{},isProviderInFooter:!0,hideComments:I,enableRichSocialReaction:!!this.config.childExperienceReferences?.socialBarWC,initCardAction:this.initCardAction,configOptions:{...S,disableOptedOutButton:!0,enableWCCardAction:!0,enableHoverCardAction:!!this.config.childExperienceReferences?.cardAction,useSmallFontSize:h!==l.infopaneCard,isImage32:!0,useHomepageTelemetry:!0,enableWebContentSocialReactions:!0,socialBarInRight:!0,providerOnTop:!0,providerOnTopInfopane:!0,hideCommentsInHalfUCards:!0,disableSlideShow:!this.overrideHasSlideShow&&this.config.disableSlideShow},isIASEnabled:this.config.isIASEnabled,appendIdxForId:this.config.appendIdxForId,rowHeightPx:d,colWidthPx:c,gutterPx:p,rowCount:g};if(u.cardContent?.insertedCardArgs&&(k=(0,am.A)({},k,u.cardContent.insertedCardArgs)),b&&(k=(0,am.A)({},k,b.args)),k.configOptions.useInfopaneSlideTemplate&&(k.immersiveCard=!0),h===l.infopaneCard){if(!this.infopaneSubItems?.length&&u?.subItems?.length&&(this.infopaneSubItems=u.subItems.slice()),this.ttvrFired||(this.config.enableDenseSlide&&this.config.denseListSize?u.subItems=u.subItems.slice(0,this.config.denseListSize+1):u.subItems=u.subItems.slice(0,1)),k=(0,am.A)({},k,f),this.config.enableDenseSlide&&this.config.denseListSize){let e=this.config.denseCardCount||1,t=this.config.denseListSize+1,a=k.cardMetadata.subItems,r=[];for(let i=0;i<e;i++){let e=i*t,o=(i+1)*t,s={size:0,subItems:a.slice(e,o).map(e=>({...e,visualReadinessCallback:void 0})),type:"densetab",visualReadinessCallback:a&&a[0].visualReadinessCallback};s.subItems.length>0&&r.push(s)}a.splice(e*t).forEach(e=>{r.push(e)}),k.cardMetadata.subItems=r}else if(k.cardMetadata?.subItems?.length){let e=k.cardMetadata.subItems;k.cardMetadata.subItems=e.map(e=>e?.subItems&&e?.subItems.length>0?e.subItems[0]:e)}}if((h===l.contentCard||h===l.infopaneCard)&&this.ttvrFired&&this.config.childExperienceReferences?.socialBarWC&&(0,a1.uC)(this.config.childExperienceReferences.socialBarWC),"video"===e&&h===l.contentCard&&u.type===eT.pL.WebContent){let e=k.cardMetadata&&k.cardMetadata.cardContent;if(e){let{destinationUrl:t,title:a,id:r}=e;k.cardMetadata.cardContent.destinationUrl=(0,a0.C)(r,t,a)}}if(this.ttvrFired&&h===l.trendingNowCard&&!this.loadedWebComponents.includes(l.trendingNowCard))try{(0,a1.uC)(k.configOptions),this.loadedWebComponents.push(l.trendingNowCard)}catch(e){ad.YT.sendAppErrorEvent({...eu.oUl,message:"Failed to load Trending Now WC",pb:{...eu.oUl.pb,errorMessage:JSON.stringify(e)}})}if(this.ttvrFired&&h===l.pollsCard){let e=u.cardContent.insertedCardArgs.pollsCardConfigInfo.instanceId===aw;k.cardMetadata.data=e?this.pollsData.quiz.data:this.pollsData.poll.data}if(this.ttvrFired&&h===l.moneyInfoCardWC&&(this.moneyInfoCardWCData?k.cardMetadata.data=this.moneyInfoCardWCData:k.cardMetadata.data="{}",this.loadedWebComponents.includes(l.moneyInfoCardWC)||((0,a1.uC)(k.configOptions),this.loadedWebComponents.push(l.moneyInfoCardWC))),this.ttvrFired&&h===l.sportsCard){let t=this.sportsSegmentData?.data,a=this.sportsSegmentData?.type;k.cardMetadata.data=t||"{}",a?k.cardMetadata.type=a:t||this.fetchSportsInfoCardData(e);let r=u.cardContent?.insertedCardArgs?.cardSize;if(r){let e={...k.cardSlot?.layouts||{}};Object.keys(e).forEach(t=>{e[t]=r}),k={...k,cardSlot:{...k.cardSlot,layouts:e}}}this.loadedWebComponents.includes(l.sportsCard)||((0,a1.uC)(k.configOptions),this.loadedWebComponents.push(l.sportsCard))}if(this.ttvrFired&&h===l.healthArticlesCardWC&&(k.cardMetadata.data=this.healthInfoCardWCData||"{}",this.loadedWebComponents.includes(l.healthArticlesCardWC)||((0,a1.uC)(k.configOptions),this.loadedWebComponents.push(l.healthArticlesCardWC))),this.ttvrFired&&h===l.travelDestinationCard){let e;k.cardMetadata={...k.cardMetadata,...this.travelDestinationCardWCData};let t=this.travelDestinationCardWCData?.dataType;e=["HotelList","HotelListingResult"].includes(t)?el.S6:e,e=["FlightPriceTrends","FlightPriceTrendsList"].includes(t)?el.aJb:e,e=["ThemeCardList","ThemeInspiration"].includes(t)?el.znl:e,(e=["DestinationList","Destination"].includes(t)?el.Qs5:e)&&k.configOptions.configRef?.experienceType&&(k.configOptions.configRef.experienceType=e),this.loadedWebComponents.includes(l.travelDestinationCard)||((0,a1.uC)(k.configOptions),this.loadedWebComponents.push(l.travelDestinationCard))}let P=at[h].getFeedDataForCard(k);h===l.denseCard&&u.cardContent.insertedCardArgs?.denseDataConfigOptions&&(P.defaultLayout[0].denseData.configOptions=u.cardContent.insertedCardArgs?.denseDataConfigOptions),Object.keys(P).forEach(e=>{n[e]&&(n[e]=n[e].concat(P[e]))})}),n}async fetchQuizData(e,t){let r;r=this.config.disableQuizCard?t?null:this.config.pollsCardWCConfig:t?this.config.quizCardWCConfig:this.config.pollsCardWCConfig;let i=t?"quiz":"poll";if(this.pollsData[i].fetchingTriggered=!0,this.pollsData[i].isFetching=!0,r)try{let{contentId:o,timezoneDiffToUTC:s}=r,{PollsCardWCActionServiceClient:n}=await a.e("polls-service").then(a.bind(a,50612)),l=new n(window.fetch.bind(window)),d=await l.getPollsData(o,t,s);d?.length>0?this.pollsData[i].data=d:this.pollsData[i].fallbackToContentCard=!0,ew.M.singleMark("StripeWC-PollsCardLoadEnd"),this.pollsData[i].isFetching=!1,this.updateStripes(e)}catch(t){this.pollsData[i].fallbackToContentCard=!0;let e={...eu.V9L,message:"Failed fetching Poll/Quiz data for stripe wc",pb:{...eu.V9L.pb,customMessage:t.message}};ad.YT.sendAppErrorEvent(e)}else this.pollsData[i].fallbackToContentCard=!0}async initTopStripeNativeAds(){let e=this.riverSectionIds[0];try{if(!this.ttvrFired||!this.riverSectionLayoutData[0])return;await this.initNativeAdService();let t=[this.fetchNativeAdsContent(e),this.fetchNativeAdsContent(e,!0)];Promise.all(t).then(t=>{let[a=[],r=[]]=t;this.updateAdPlacementData(e,[...a,...r]),ew.M.singleMark("StripeWC-topStripeReady"),this.startInfopaneAutoRotation(),this.ttvrLogInfo.topStripeAdsReadyAt=performance.now()})}catch(t){ad.YT.sendAppErrorEvent({...eu.sHf,message:"Error when fetching top stripe nativeAds data",pb:{...eu.sHf.pb,errorMessage:JSON.stringify(t)}}),this.updateStripes(e),this.startInfopaneAutoRotation();return}}hasTravelDestinationCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.travelDestinationCard&&(a=!0)}),a}hashealthArticleInfoCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.healthArticlesCardWC&&(a=!0)}),a}hasMoneyInfoCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.moneyInfoCardWC&&(a=!0)}),a}hasSportsInfoCardWC(e){let t=this.config.insertCardInSlot?.[e]||[],a=!1;return t.forEach(e=>{e?.cardType===l.sportsCard&&(a=!0)}),a}async updateUserFinanceInterest(){let e=await this.financeUserService.getFinanceInterest();e&&(this.hasSectionInterest.finance=0,e.explicit?.length>0&&(this.hasSectionInterest.finance+=1e3),e.implicit?.length>0&&(this.hasSectionInterest.finance+=1))}async updateDynamicRankingInterests(){this.dynamicRankingInterests=await this.userPreferenceFetcherService.getUserPreferences(),this.dynamicInterestsFetched=!0}async updateUserBuyDirectInterest(){await this.buyDirectServiceClient.hasBuyDirectInterest()&&(this.hasSectionInterest.buydirect=1)}async updateUserSportsInterest(){let e=this.sportsSegmentData?.data||await this.getSportsSegmentResponse();this.hasSectionInterest.sports=+!!function(e,t=.4){let a=ak(e),r=a?.Model?.Tabs?.[0],i=Number(r?.RankingData?.Relevance),o=r?.isLive,s=!0===o||"True"===String(o),n=!Number.isNaN(i)&&i>=t;return aT(e)&&(s||n)}(e)}shouldInsertSportsInfoCard(){let e=this.sportsSegmentData?.data;return!!e&&!!this.sportsSegmentData?.type&&aT(e)}isFeedResponseUnderfilled(e,t){let a=ag(t);return ah(e?.cardMetadata)<a}async getFallbackFeedResponse(e,t,a){let r=e?.cardMetadata||[],i=ah(r),o=await this.fetchRiverContent(t,a);return i?{...e,cardMetadata:((e=[],t=[],a)=>{let r=[...e],i=new Set,o=0,s=e=>{let t=e?.id||e?.cardContent?.id;return!(t&&i.has(t))&&(t&&i.add(t),eD[e?.type]&&(o+=1),!0)};if(e.forEach(s),o>=a)return r;for(let e of t){if(o>=a)break;s(e)&&r.push(e)}return r})(r,o?.cardMetadata,ag(a))}:o}getOverrideFeedId(e,t){if("sports"===e){let a=aA(this.config,e);return function(e,t){let a=aP(e);if(a)return t?.find(({entityId:e})=>e===a)?.feedId||void 0}(this.sportsSegmentData?.data,a?.promotedFeedIds)||t}return t}getRiverSectionLayoutWithOverrideFeedId(e,t){let a=(0,am.A)({},this.config.riverSectionCardProviderConfig,e.cardProviderConfig,{initialRequest:{feedId:t}});return{...e,cardProviderConfig:a,riverCardProvider:new al.f(a)}}async fetchTravelDestinationCardData(e){await a2.Iw.GetSDCardData().then(t=>{t&&Array.isArray(t)&&t.length>0&&(this.travelDestinationCardWCData=t[0],this.travelDestinationCardWCData&&this.travelDestinationCardWCData.length>0&&this.updateStripes(e))})}async fetchSportsInfoCardData(e){await this.getSportsSegmentResponse()?this.updateStripes(e):this.logSportsInsertedCardFallback(e)}logSportsInsertedCardFallback(e){ad.YT.sendAppErrorEvent({...eu.sOF,message:"Sports inserted-card fallback to original content card",pb:{...eu.sOF.pb,customMessage:`sectionId=${e||"unknown-section"}`}})}async getSportsSegmentResponse(){let e=this.sportsSegmentData?.data;return e||(this.sportsSegmentResponsePromise||(this.sportsSegmentResponsePromise=a.e("libs_sports-service-connector_dist_segments_index_js").then(a.bind(a,12080)).then(({fetchSportsSegments:e})=>e({market:eh.T3.CurrentMarket,user:eh.T3.UserId})).then(e=>{let t=e?.[0];return t?.data&&t?.type?(this.sportsSegmentData={data:t.data,type:t.type},t.data):""}).catch(()=>(this.sportsSegmentResponsePromise=void 0,""))),this.sportsSegmentResponsePromise)}async fetchHealthInfoCardData(e){let t=eh.T3.CurrentMarket,a=`recommendations|articleData|1|${t}`;await aO.getDataFromOneService(a,t,!0).then(t=>{t&&(this.healthInfoCardWCData=JSON.stringify(t),this.healthInfoCardWCData&&this.healthInfoCardWCData.length>0&&this.updateStripes(e))})}async fetchMoneyInfoCardData(e){let t={experienceType:el.ahW,instanceSrc:"default"};this.moneyInfoCardWCConfig=(await aa.L.getConfig(t)).properties;try{if(!this.financeUserService||!this.financeAutoSuggestService||!this.financeService){let{FinanceServices:e,getFinanceDataConnector:t}=await Promise.all([a.e("node_modules_crypto-js_index_js"),a.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),a.e("libs_finance-service-library_dist_index_js")]).then(a.bind(a,43818));this.financeUserService||(t().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=e.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)),this.financeAutoSuggestService=e.getAutoSuggestService(),this.financeService=e.getCachedFinanceService()}let t={userSignedIn:!1,dataFrom:"watchlist",dataTimestamp:null,data:null,fullWatchlistQuoteIds:null};if(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)t.userSignedIn=!0;else{let{getUserSignInState:e}=await a.e("libs_auth_dist_index_js").then(a.bind(a,9788));t.userSignedIn=await e()===2}let r=[];(t.userSignedIn||this.moneyInfoCardWCConfig.enableUnsignedWatchlist)&&(t.fullWatchlistQuoteIds=r=await this.financeUserService.getWatchlist(!1)),r&&0!==r.length||this.moneyInfoCardWCConfig.enableUnsignedWatchlist?t.dataFrom="watchlist":t.dataFrom="market";let i="watchlist"===t.dataFrom?r:this.moneyInfoCardWCConfig.apiConfig.marketQuoteIds;this.financeService.cleanCache();let o=await this.financeService.getRecommendation()||this.moneyInfoCardWCConfig.apiConfig.recommendedQuoteIds,s=[i,o],n=[].concat(...s),l=await this.financeService.getQuoteSummary(n),d={};l.forEach(e=>{e?.id&&(d[e.id]=e)});let[c,p]=s.map(e=>e.map(e=>d[e]).filter(e=>e));t.data={recommend:{quoteItems:p,quoteIds:p.map(e=>e.id)},[t.dataFrom]:{quoteItems:c,quoteIds:c.map(e=>e.id)}},t.data.watchlist||(t.data.watchlist={quoteItems:[],quoteIds:[]}),t.dataTimestamp=new Date().getTime();let u=[...this.moneyInfoCardWCConfig.defaultTabs];"watchlist"!==t.dataFrom&&u.splice(u.indexOf("watchlist"),1);let h={userSignedIn:t.userSignedIn,dataFrom:t.dataFrom,fullWatchlistQuoteIds:"watchlist"===t.dataFrom?i:[],recommendQuoteItems:p,tabListDetails:t.data,notifications:null,tabs:u};this.moneyInfoCardWCData=JSON.stringify(h),this.updateStripes(e)}catch(e){ad.YT.sendAppErrorEvent({...eu.B0w,message:"MoneyInfoCard content fetch failed",pb:{...eu.B0w.pb,customMessage:`Failed with exception : ${JSON.stringify(e)}`}})}}getDisplayedColumnLayout(){let e=this.columnArrangement;if(!this.enableRail||!e)return e;let t=parseInt(e.replace("C",""),10);return Number.isNaN(t)?e:`C${t-1}`}updateStripes(e){this.updateRiverSections(e),this.config.stripeStyles&&this.processLayoutStyles(),a7&&e&&(0,e_.CI)(ra(e))}updateRiverSections(e){this.riverSectionLayoutData=this.riverSectionLayoutData.map((t,a)=>{if(!t)return;let{templateId:r,sectionId:i}=t,o=tx[r];if(void 0!==e&&e!==i)return t;let s=(0,aC.A)(this.config.slotToCardType?.[i]||[])||[],n=t.cardMetadataList,{backfillCardTypeSlot:d,backfillMetadata:c,backfillTemplateId:p}=a5(i,n,this.config.childExperienceReferencesWC?.[i]?.backfillConfigs);if(n=c||n,s=d||s,o=p?tx[p]:o,!t.hasPlaceHolderAds&&e!==i)return{...t,feedData:this.mapFeedData(i,t.cardMetadataList,o,this.config.openLinksInNewTab,this.telemetryObject,s,a)};{let r=this.nativeAdPlacementsMap[i];if(r&&t?.cardMetadataList?.length===r.length){let e=!1;if(r.forEach(t=>e=e||this.hasAdsContent(t)),!e)return void(0,ep.vV)(eu.Koy,"No ads content for entire stripe",`sectionId: ${i}, adsConfig: ${this.config.adPlacements?.[i]}, cmsConfig: adsConfig: ${this.config.adPlacements?.[i]}`)}let d=r?.filter(e=>e.region===eT.pL.Infopane),c=r?.filter(e=>e.region!==eT.pL.Infopane),p=n.map((a,r)=>{if(a.type===eT.pL.Infopane){if(!this.ttvrFired||!this.nativeAdIsLoaded[e])return a;if(a.subItems=this.infopaneSubItems.slice(),d?.length){let e=d.sort((e,t)=>e.regionIndex>t.regionIndex?1:e.regionIndex<t.regionIndex?-1:0),t=[];e.forEach(e=>{let r=e.regionIndex-1;!t.includes(r)&&a.subItems[r]&&this.hasAdsContent(e)&&(t.push(r),a.subItems.splice(r,0,this.createNativeAdCardMetadata(e)))})}if(this.shouldOverrideInfopaneCards&&this.ttvrFired&&"topStripe"==e)for(let e=0;e<a?.subItems?.length;e++){let t=a.subItems[e];if(t?.id&&this.replacementInfopaneCards[t.id]){let r=this.replacementInfopaneCards[t.id];a.subItems[e]=r.card,r.tmplStringPrefix&&ad.YT.addOrUpdateTmplString(`${r.tmplStringPrefix}-${t.cardContent.id}`)}}return a}{let e,i=0;for(let e=0;e<r;e++)t.cardMetadataList[e].type===rt&&t.cardMetadataList[e].subItems?.length?i+=t.cardMetadataList[e].subItems.length-1:i++;return(a.cardContent?.insertedCardType===l.denseCard?c?.forEach(e=>{if(this.hasAdsContent(e)&&e.regionIndex>i){let t=e.regionIndex-i,r=a.subItems?.[t];r&&r.type!==eT.pL.NativeAd&&(a.subItems[t]=this.createNativeAdCardMetadata(e))}}):e=c?.find(e=>e.regionIndex===i+1),e&&this.hasAdsContent(e))?this.createNativeAdCardMetadata(e):a}});return{...t,feedData:this.mapFeedData(i,p,o,this.config.openLinksInNewTab,this.telemetryObject,s,a),hasPlaceHolderAds:!1,cardMetadataList:(0,aC.A)(p)}}})}updateAdPlacementData(e,t){let a=this.nativeAdPlacementsMap[e];a?.length&&t?.length&&a.forEach((e,r)=>{let i=t.filter(t=>t.region===e.region&&t.regionIndex===e.regionIndex)[0];i?.items?.length&&(a[r]=i)}),this.updateStripes(e)}async fetchNativeAdsContent(e,t){let a=this.getAdRequestForRiver(e,t),r=ar.Rb.Locale,i=aS[r]||ec.F3[r];if(!a)return;r&&(a.locale=r);let o=[];try{await this.initNativeAdService(),a.placements?.length&&(a=(0,aC.A)(a)).placements.forEach(e=>{this.nativeAdIndiceRegionFilters.length&&!this.nativeAdIndiceRegionFilters.includes(e.region.toLowerCase())&&(e.indices=e.indices.map((e,t)=>t+1))}),ew.M.startMark(re);let{placements:r,adLabelText:s,isGreyAdsLabelEnabled:n}=t?await this.nativeAdService.fetchCmsAds(a,i,[]):await this.nativeAdService.fetchNativeAds(a);r?.length&&r.forEach(a=>{e===this.riverSectionIds[0]||this.nativeAdIndiceRegionFilters.includes(a.region.toLowerCase())||(t?this.config.cmsAdPlacements?.[e]:this.config.adPlacements?.[e]).placements.forEach(e=>{e.region===a.region&&(a.regionIndex=e.indices[a.regionIndex-1])}),a.adLabelText=s,a.isGreyAdsLabelEnabled=n,this.config.isMsnHPAdSlug&&(a.isGreyAdsLabelEnabled=!1),o.push(a)})}catch(t){this.nativeAdIsLoaded[e]=!0,(0,ep.c_)(t,eu.sHf,"Call to Ad Service failed")}finally{ew.M.endMark(re),this.nativeAdIsLoaded[e]=!0}return o}async initNativeAdService(){if(!this.nativeAdService){let{NativeAdService:e}=await a.e("libs_ad-service_dist_index_js").then(a.bind(a,73487));this.nativeAdService=new e(void 0,this.config&&this.config.adServiceConfig)}}loadNativeAd(e,t){this.ttvrFired&&this.fetchNativeAdsContent(e,t).then(t=>{this.updateAdPlacementData(e,t)})}createStripeAdCardDefaultMetadata(e){let t=[];for(let a=1;a<=e;a++)t.push({type:eT.pL.NativeAd,regionIndex:a,placement:{items:[]}});return t}createNativeAdCardMetadata(e){if(e?.items?.length)return{type:eT.pL.NativeAd,id:`${eT.pL.NativeAd}-${e.regionIndex}`,placement:e}}hasAdsContent(e){return Object.keys(e?.items[0]||{}).length>0}getAdRequestForRiver(e,t){let a,r=t?this.config.cmsAdPlacements?.[e]:this.config.adPlacements?.[e];if(r){if(r?.placements){let t=[];if(r.placements.forEach(e=>{if(e.region.indexOf(eT.pL.Infopane)>=0)t.push({...e,img:this.config.adTemplateConfig?.imageSizeConfig?.infopane});else{let a=e.indices;if(a.length){let r={...e,indices:a};t.push(r)}}}),t.length){let i=this.getDefaultAdPlaceholderPlacements(t);this.nativeAdPlacementsMap[e]?this.nativeAdPlacementsMap[e].push(...i):this.nativeAdPlacementsMap[e]=i,a={placements:t,pageType:r.pageType}}}return a}}getDefaultAdPlaceholderPlacements(e){let t=[];return e&&e.forEach(e=>{let a=e.indices.map(t=>({...e,regionIndex:t,items:[{}]}));t=t.concat(a)}),t}getNavigationButonTelemetryTag(e){return(0,aQ.N)(e,ac.MS.Paginate,ac.EG.Click,ac.MJ.ActionButton).getMetadataTag()}startInfopaneAutoRotation(){let e=this.config.infopaneConfig||{};if(e.autoRotate&&!e.disableAutoRotate){let e=this.riverSectionIds[0],t=this.shadowRoot.querySelector?.(`#${e} cs-feed-layout`)?.shadowRoot,a=t?.querySelector("cs-responsive-infopane");a&&window.setTimeout(()=>{a.hasSlideShow=!0,this.overrideHasSlideShow=!0},1e3)}}has1SFlight(e){let t=eh.T3.CurrentRequestTargetScope&&eh.T3.CurrentRequestTargetScope.pageExperiments;return!!t&&t.includes("1s-viewurldomain")}handleContentOverlap(e,t){let a=e.target.getBoundingClientRect();a.top<160&&window.scrollBy(0,a.top-160)}overrideInfopaneSlideCardToElectionCard(e){e.cardMetadata={id:"electionCard",cardContent:{abstract:"US Elections: Latest news, results and more",destinationUrl:"https://www.msn.com/en-us/channel/topic/US%20Elections/tp-Y_cc072da4-ecb2-413a-9ffe-5ec5ad54ca41",id:"electionCard",images:[{id:"USElectionCard",caption:"US Elections: Latest news, results and more",url:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sKqsZ.img"}],type:"ArticlePreview",title:"US Elections: Latest news, results and more"},metadata:{},type:"article"}}}(0,b.Cg)([_.sH],rr.prototype,"columnArrangement",void 0),(0,b.Cg)([_.sH],rr.prototype,"isShowDot",void 0),(0,b.Cg)([_.sH],rr.prototype,"isFetchingStripes",void 0),(0,b.Cg)([_.sH],rr.prototype,"requestContext",void 0),(0,b.Cg)([_.sH],rr.prototype,"riverSectionLayoutData",void 0),(0,b.Cg)([_.sH],rr.prototype,"ttvrFired",void 0),(0,b.Cg)([_.sH],rr.prototype,"cardActionRef",void 0),(0,b.Cg)([_.sH],rr.prototype,"isFeedExhausted",void 0),(0,b.Cg)([_.sH],rr.prototype,"onFeedEndCb",void 0),(0,b.Cg)([_.sH],rr.prototype,"enableRail",void 0);var ri=a(66591),ro=a(36478),rs=a(72691),rn=a(31157),rl=a(36042);let rd=(0,O.A)` .container{left:3px}`,rc=(0,O.A)` .container{right:3px}`,rp=(0,O.A)`
.arrow-container-rail{display:none}${(0,tt.H5)(tt.j1.c3)}{.arrow-container.arrow-container-rail{width:697px}}${(0,tt.H5)(tt.j1.c4)}{.arrow-container.arrow-container-rail{width:1019px}}${(0,tt.H5)(tt.j1.c5)}{.arrow-container.arrow-container-rail{width:1341px}}`,ru=(0,O.A)`
:host{--viewport-width:auto;--viewport-height:auto;--element-gap:16px;height:var(--viewport-height);width:var(--viewport-width);position:relative;display:flex}.arrow-container{position:absolute;display:flex;justify-content:space-between;align-items:flex-end;align-self:end;pointer-events:none;z-index:0;right:20px;bottom:4px}${(0,tt.H5)(tt.j1.c2)}{.arrow-container{width:697px}}${(0,tt.H5)(tt.j1.c3)}{.arrow-container{width:1019px}}${(0,tt.H5)(tt.j1.c4)}{.arrow-container{width:1341px}}.viewport{height:303px;overflow-x:hidden;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.viewport-weather{height:303px;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.disable-overflow-hidden{overflow:visible;height:var(--viewport-height)}.page-indicator{font-size:var(--page-number-font-size,12px);color:var(--page-number-color);line-height:16px;pointer-events:all}.page-indicator span{background:#c2c2c2;border-radius:50%;height:6px;width:6px;display:inline-block;margin:0 4px;cursor:pointer}.page-indicator span.active{background:#333;cursor:default}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content;height:100%;left:3px;position:relative}.slider-arrow{pointer-events:all;z-index:2;outline:none;background:var(--flipper-background,transparent);width:var(--flipper-width,20px);height:var(--flipper-height,20px);display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;border:none;margin-bottom:162px;width:28px}.slider-arrow.hide{pointer-events:none;visibility:hidden}.slider-arrow svg{width:var(--flipper-icon-width);color:var(--flipper-icon-color,buttonText);fill:#9b9b9b}${rp}
`.withBehaviors(new Q.t(rd,rc)),rh=(0,P.qy)`<svg width="24" height="24" viewBox="0 0 5 8" style="transform: scale(-1, 1);" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,rg=(0,P.qy)`<svg width="24" height="24" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,rm=(0,P.qy)` ${(0,R.ux)(e=>e.pageIndicatorData,(0,P.qy)`<span class="${e=>e.active?"active":""}" id=${e=>e.pageIndex} @click=${(e,t)=>t.parent.handlePageIndicatorClick(t.event)} data-t="${(e,t)=>t.parent.pageIndicatorTelemetryTag}"></span>`)}
`,ry=(0,P.qy)`<div ${(0,T.K)("viewport")} class="${e=>"weather"==e.sectionId?"viewport-weather":"viewport"}" part="viewport" direction="${e=>e.direction?e.direction:"ltr"}"><div class="container" part="container" ${(0,T.K)("container")}><slot ${(0,T.K)("viewportSlot")} @slotchange=${e=>e.setCurrentSlotWidth()}></slot></div></div><div class="${e=>(0,ri.x)("arrow-container",["arrow-container-rail",e.isRailEnabled])}" part="arrow-container"><slot ${(0,T.K)("previousArrow")} name="previous-arrow"><button class="slider-arrow previous-arrow" @mousedown="${(e,t)=>t.event&&e.mouseDownHandler(t.event)}" @click="${e=>e.slideKeyPressHandler(-1)}" aria-label="${e=>e.leftArrow}" data-t="${e=>e.previousArrowTelemetryTag}" hidden tabindex="-1">${(0,D.z)(e=>e.renderSlider&&"ltr"===e.direction,rh)} ${(0,D.z)(e=>e.renderSlider&&"rtl"===e.direction,rg)}</button></slot><div class="page-indicator">${(0,D.z)(e=>e.renderSlider,rm)}</div><slot ${(0,T.K)("nextArrow")} name="next-arrow"><button class="slider-arrow next-arrow" @mousedown="${(e,t)=>t.event&&e.mouseDownHandler(t.event)}" @click="${e=>e.slideKeyPressHandler(1)}" aria-label="${e=>e.rightArrow}" data-t="${e=>e.nextArrowTelemetryTag}" hidden tabindex="-1">${(0,D.z)(e=>e.renderSlider&&"ltr"===e.direction,rg)} ${(0,D.z)(e=>e.renderSlider&&"rtl"===e.direction,rh)}</button></slot></div>`,rC=class extends $.L{columnArrangementChanged(e,t){e&&this.container&&this.handleBreakpointChange()}constructor(){super(),this.direction=rn.O.ltr,this.nextArrowTelemetryTag="",this.previousArrowTelemetryTag="",this.pageIndicatorTelemetryTag="",this.columnArrangement="C4",this.currentPageIndex=1,this.totalNumPages=1,this.pageIndicatorData=[],this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.handleBreakpointChange=()=>{this.setSliderStates(),this.refreshSliderControls(this.viewport.scrollLeft)},this.handleBreakpointChange=(0,rl.A)(this.handleBreakpointChange,200)}connectedCallback(){super.connectedCallback(),this.direction=rs.o.getValueFor(this),this.setSliderStates(),this.refreshSliderControls(0)}setCurrentSlotWidth(){let e=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=e?Number(e.replace(/px/,"")):0,this.viewportSlot.assignedElements().length>0&&("C4"===this.columnArrangement&&this.isC5Enabled?this.currentSlotElementWidth=1273:"C3"===this.columnArrangement?this.currentSlotElementWidth=951:"C2"===this.columnArrangement?this.currentSlotElementWidth=629:this.currentSlotElementWidth=0)}slideKeyPressHandler(e){if(this.disableSliderInColumnArrangement())return;let t=this.viewport.clientWidth,a=this.container.clientWidth;if(t<=0||a<=0)return;let r="rtl"!==this.direction,i=this.viewport.scrollLeft;if(r||(e*=-1),!r&&e>0&&0===i||r&&e<0&&0===i)return;let o=e*this.getScrollDistance();if(i+o>a)return;this.currentPageIndex=Math.floor(Math.abs(i+o)/t)+1,this.currentPageIndex<=0&&(this.currentPageIndex=1),this.onSlideIndexChange?.(this.currentPageIndex-1);let s=i+o;window.requestAnimationFrame(()=>{this.viewport.scrollTo(s,0),this.refreshSliderControls(s)})}mouseDownHandler(e){e.preventDefault(),e.stopPropagation()}setArrowVisibility(e){let t=e*("ltr"===this.direction?1:-1);t<=0?this.setArrowsHiddenVisibility(!0,!1):this.viewport.clientWidth+t>this.container.clientWidth?this.setArrowsHiddenVisibility(!1,!0):this.setArrowsHiddenVisibility(!1,!1)}hideNextArrow(e){e?this.nextArrow.children[0].classList.add("hide"):this.nextArrow.children[0].classList.remove("hide")}hidePreviousArrow(e){e?this.previousArrow.children[0].classList.add("hide"):this.previousArrow.children[0].classList.remove("hide")}setArrowsHiddenVisibility(e,t){this.hidePreviousArrow(e),this.hideNextArrow(t)}getScrollDistance(){return this.currentSlotElementWidth+this.currentContentGapSize}refreshSliderControls(e){this.setPageIndicator(),this.setArrowVisibility(e)}setSliderStates(){this.calculateTotalNumPages(),this.setCurrentSlotWidth(),this.setSliderVisibility()}calculateTotalNumPages(){return"C4"===this.columnArrangement&&this.isC5Enabled||["C2","C3"].includes(this.columnArrangement)?this.totalNumPages=2:this.totalNumPages=0}setSliderVisibility(){this.renderSlider=!(this.disableSlider||"C5"===this.columnArrangement||"C4"===this.columnArrangement&&!this.isC5Enabled||["topStripe","buydirect","shopping"].includes(this.sectionId)),"topStripe"!==this.sectionId&&this.disableSliderInColumnArrangement?this.viewport.classList.remove("disable-overflow-hidden"):this.viewport.classList.add("disable-overflow-hidden")}disableSliderInColumnArrangement(){let e=["C2","C3"];return this.isC5Enabled&&e.push("C4"),this.disableSlider||!e.includes(this.columnArrangement)}setPageIndicator(){this.pageIndicatorData=[];for(let e=1;e<=this.totalNumPages;e++){let t={active:this.currentPageIndex===e,pageIndex:e};this.pageIndicatorData.push(t)}}handlePageIndicatorClick(e){if(this.disableSliderInColumnArrangement())return;let t="ltr"===this.direction?1:-1,a=Number(e?.target.id),r=(a-1)*this.getScrollDistance();this.currentPageIndex=a,window.requestAnimationFrame(()=>{this.viewport.scrollTo(r*t,0),this.refreshSliderControls(r)})}};(0,b.Cg)([_.sH],rC.prototype,"direction",void 0),(0,b.Cg)([_.sH],rC.prototype,"nextArrowTelemetryTag",void 0),(0,b.Cg)([_.sH],rC.prototype,"previousArrowTelemetryTag",void 0),(0,b.Cg)([_.sH],rC.prototype,"pageIndicatorTelemetryTag",void 0),(0,b.Cg)([_.sH],rC.prototype,"columnArrangement",void 0),(0,b.Cg)([_.sH],rC.prototype,"currentPageIndex",void 0),(0,b.Cg)([_.sH],rC.prototype,"totalNumPages",void 0),(0,b.Cg)([_.sH],rC.prototype,"sectionId",void 0),(0,b.Cg)([_.sH],rC.prototype,"disableSlider",void 0),(0,b.Cg)([_.sH],rC.prototype,"isC5Enabled",void 0),(0,b.Cg)([_.sH],rC.prototype,"leftArrow",void 0),(0,b.Cg)([_.sH],rC.prototype,"rightArrow",void 0),(0,b.Cg)([_.sH],rC.prototype,"renderSlider",void 0),(0,b.Cg)([_.sH],rC.prototype,"pageIndicatorData",void 0),(0,b.Cg)([_.sH],rC.prototype,"isRailEnabled",void 0),rC=(0,b.Cg)([(0,$.E)({name:"stripe-slider",template:ry,styles:ru,shadowOptions:{delegatesFocus:!0}})],rC);let rf=(0,P.qy)` ${(e,t)=>(0,t3.yN)(e.pivotsNav,{properties:{parentTelemetry:t.parent.telemetryObject}})}
`,rv=(0,P.qy)`<div class="river-section-header-group" style="${e=>e.riverSectionTitleColor&&!e.disableStripeTheme?`border-color: ${e.riverSectionTitleColor};`:""} ${e=>e.seeMoreText?"border-width: 1px;":""}"><div class="stripe-title"><h2>${(0,D.z)(e=>e.adLabel,(0,P.qy)`<msn-native-ad-ad-label type="${e=>e.adSlugGA?"defaultLabel":"greenLabel"}" ad-label-text=${e=>e.adLabel} ad-label-text-opacity="${e=>e.adSlugGA?"0.81":"0.7"}" should-adjust-gap is-msn-hp-ad-slug=${e=>e.isMsnHPAdSlug} enable-safe-ads=${e=>e.enableSafeAds}></msn-native-ad-ad-label>`)}<a href="${e=>e.riverSectionTitleUrl}" target="${(e,t)=>t.parent.config.openLinksInNewTab?"_blank":"_self"}" style="${e=>e.riverSectionTitleColor&&!e.disableStripeTheme?`color: ${e.riverSectionTitleColor}`:""};${e=>e.riverSectionTitleUrl?"":"text-decoration: none;"}" data-t="${(e,t)=>t.parent.stripeWCTelemetry.getTelemetryTag(aX.title)}" title="${e=>e.seeMoreText}" aria-label="${e=>e.seeMoreText}">${e=>e.riverSectionTitle} ${(0,D.z)(e=>e.riverSectionTitleUrl||e.adLabel,(0,P.qy)`<span class="title-arrow">${P.qy.partial(ro.A)}</span>`)}</a></h2></div><div class="sub-nav">${(0,D.z)(e=>e.pivotsNav,rf)}</div></div>`,rb=(0,P.qy)`<div class="feed-section">${(0,R.ux)(e=>e.riverSectionLayoutData.filter(e=>null!=e),(0,P.qy)` ${(0,D.z)(e=>e.insertBannerAd,(0,P.qy)`<div class="in-stripe-banner-ad" id="${(e,t)=>e.sectionId}"><display-ads config-instance-src="default" instance-id="banner2"></display-ads></div>`)} ${(0,D.z)(e=>!e.insertBannerAd,(0,P.qy)`<div class="river-section" data-t="${(e,t)=>t.parent.stripeWCTelemetry.getSectionTelemetryTag(e.sectionId,e.telemetryName)}" id="${(e,t)=>e.sectionId}" @focusin="${(e,t)=>t.parent.handleContentOverlap(t.event,e.sectionId)}">${(0,D.z)(e=>e.riverSectionTitle,rv)}<stripe-slider class="${(e,t)=>(0,ri.x)("stripe-slider-container",["stripe-slider-container-rail",t.parent.enableRail],["more-space","topStripe"===e.sectionId||t.parent.isShowDot])}" part="stripe-slider-container" :isRailEnabled=${(e,t)=>t.parent.enableRail} :previousArrowTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("leftarrow")} :nextArrowTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("rightarrow")} :pageIndicatorTelemetryTag=${(e,t)=>t.parent.getNavigationButonTelemetryTag("pageIndicator")} :leftArrow=${e=>e.leftArrow||{}} :rightArrow=${e=>e.rightArrow||{}} :columnArrangement=${(e,t)=>t.parent.getDisplayedColumnLayout()} :disableSlider=${e=>e.disableSlider} :isC5Enabled=${e=>e.isC5Enabled} :sectionId=${e=>e.sectionId}><cs-feed-layout class="stripe-river-section" data-section=${e=>e.sectionId} layout=${(e,t)=>t.parent.getDisplayedColumnLayout()} :data=${e=>e.feedData} :childTemplateMap=${e=>ae} :layoutStyles=${e=>{var t;let a,r;return a=tx[t=e.templateId].styles,r=aV+aK,t.indexOf("top-stripe-view")>=0?(0,O.A)`${a}${r}${aj}`:(0,O.A)`${a}${r}`}} data-t="${(e,t)=>"topStripe"===e.sectionId?t.parent.stripeWCTelemetry.getTelemetryTag(aX.todayHeadlines):null}"></cs-feed-layout></stripe-slider></div>`)} `)}<div ${(0,T.K)("paginationSentinelRef")} style=${e=>e.sentinelHeight} class="pagination-sentinel"></div></div>`,rx=(0,P.qy)` ${e=>e.config.childExperienceReferences?.cardAction&&(0,t3.yN)(e.config.childExperienceReferences.cardAction)}
`,r_=(0,P.qy)`<fluent-design-system-provider id="sf-design-system" style="background: transparent" fill=""><div class="stripe-feed" style="${e=>e.config.noPaddingEnd&&e.isFeedExhausted?"padding-bottom: 4px":null}">${(0,D.z)(e=>e.riverSectionLayoutData,rb)} ${(0,D.z)(e=>e.isFetchingStripes&&e.ttvrFired,(0,P.qy)`<div class="progress-ring-wrapper"><fluent-progress-ring></fluent-progress-ring></div>`)}</div>${(0,D.z)(e=>e.ttvrFired,rx)}</fluent-design-system-provider>`;d.m.define(c.c.registry),p.m.define(c.c.registry),u.m.define(c.c.registry),er.m.define(h.G.registry),g.Ob.define(m.i.registry),y.Id.define(m.i.registry),C.Af.define(m.i.registry),f.yr.define(m.i.registry),v.rX.define(m.i.registry),et.define(m.i.registry),ea.Bb.define(m.i.registry),ei.L.define(m.u.registry);let rw={experienceConfigSchema:void 0}},33335(e,t,a){"use strict";var r=a(40450);(0,r.KR6)(8110),(0,r.KR6)(8111),(0,r.KR6)(8112),(0,r.KR6)(8113),(0,r.KR6)(8114),(0,r.KR6)(8115),(0,r.KR6)(8116),(0,r.KR6)(8117),(0,r.KR6)(8118),(0,r.KR6)(8119),(0,r.KR6)(8120),(0,r.KR6)(8121),(0,r.KR6)(8122),(0,r.KR6)(8123),(0,r.KR6)(8124),(0,r.KR6)(8125);let i=(0,r.KR6)(8126),o=(0,r.KR6)(38300,r.imi,(0,r.N5g)(!0)),s=(0,r.KR6)(38301,r.imi,(0,r.N5g)(!0)),n=(0,r.KR6)(38302),l=(0,r.KR6)(38303),d=(0,r.KR6)(38304),c=(0,r.KR6)(38305),p=(0,r.KR6)(38306),u=(0,r.KR6)(38307);(0,r.KR6)(38310,r.imi,(0,r.N5g)(!0)),(0,r.KR6)(38314,r.imi,(0,r.N5g)(!0)),(0,r.KR6)(38315,r.imi,(0,r.N5g)(!0)),(0,r.KR6)(38316),(0,r.KR6)(38317);let h=(0,r.KR6)(38318),g=(0,r.KR6)(38319,r.imi,(0,r.N5g)(!0)),m=(0,r.KR6)(38320),y=(0,r.KR6)(38321,r.imi,(0,r.N5g)(!0)),C=(0,r.KR6)(38322,r.imi,(0,r.N5g)(!0)),f=(0,r.KR6)(38323),v=(0,r.KR6)(38324),b=(0,r.KR6)(38325);(0,r.KR6)(38326,r.imi,(0,r.N5g)(!0));let x=(0,r.KR6)(38327,r.imi),_=(0,r.KR6)(38328),w=(0,r.KR6)(38329);(0,r.KR6)(38330);let S=(0,r.KR6)(38331,r.imi,(0,r.N5g)(!0));(0,r.KR6)(38332),(0,r.KR6)(38333);let $=(0,r.KR6)(38334,r.yfd,(0,r.N5g)(!0));(0,r.KR6)(38335,r.yfd,(0,r.N5g)(!0)),(0,r.KR6)(38336,r.yfd,(0,r.N5g)(!0)),(0,r.KR6)(38337,r.yfd,(0,r.N5g)(!0)),(0,r.KR6)(38340,r.yfd,(0,r.N5g)(!1)),(0,r.KR6)(38341,r.yfd,(0,r.N5g)(!1));let A=(0,r.KR6)(38342);(0,r.KR6)(38343);let I=(0,r.KR6)(38344),k=(0,r.KR6)(38345),P=(0,r.KR6)(38346),T=(0,r.KR6)(38347),D=(0,r.KR6)(38348);(0,r.KR6)(38349),(0,r.KR6)(38350,r.imi,(0,r.N5g)(!0)),(0,r.KR6)(38355,r.imi,(0,r.N5g)(!0));let R=(0,r.KR6)(38360);(0,r.KR6)(38361);let M=(0,r.KR6)(38362),B=(0,r.KR6)(38363),L=(0,r.KR6)(38364),O=(0,r.KR6)(38365,r.XkX),F=(0,r.KR6)(38366),E=(0,r.KR6)(38367);(0,r.KR6)(38368);let z=(0,r.KR6)(38369),N=(0,r.KR6)(38370);(0,r.KR6)(38371),(0,r.KR6)(38372);let U=(0,r.KR6)(38373);(0,r.KR6)(38374);let q=(0,r.KR6)(38375);(0,r.KR6)(38376);let W=(0,r.KR6)(38377),H=(0,r.KR6)(38378);(0,r.KR6)(38379);let j=(0,r.KR6)(38381),K=(0,r.KR6)(38382);a.d(t,{},{Ai:l,Ax:S,D8:U,Fw:A,Gu:f,HW:w,J2:M,KL:O,Kb:z,M5:T,MX:u,MY:i,Nf:b,ON:h,P8:$,PY:x,Qj:m,Qk:n,R_:c,TE:F,Xq:W,Y0:C,YJ:H,Y_:E,bV:I,dS:N,hq:B,jR:j,lP:q,lb:d,mg:P,mx:y,nj:v,pV:g,r4:o,s6:_,s8:k,sI:s,tD:D,vp:K,vy:p,x1:R,zV:L})},73559(e,t,a){"use strict";var r=a(61473),i=a(7446),o=a(62514),s=a(35150),n=a(40450),l=a(33744),d=a(98794),c=a(89757),p=a(94172);let u={[o.C.bingDailyQuizCard]:"bingDailyQuizCard",[o.C.casualGamesCard]:"casualGamesCard",[o.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[o.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[o.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[o.C.communityCard]:"communityCard",[o.C.dailyBriefCard]:"dailyBriefCard",[o.C.dailyGreetingCard]:"dailyGreetingCard",[o.C.dailyMomentsCard]:"dailyMomentsCard",[o.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[o.C.dailyWonderQuoteCard]:"dailyWonderCopilotCard",[o.C.donationNpoCard]:"donationNpoCard",[o.C.electionCard]:"electionCard",[o.C.entertainmentPremierCard]:"entertainmentPremierCard",[o.C.esportsCard]:"esportsCard",[o.C.healthCard]:"bingHealthCard",[o.C.horoscopeAnswerCard]:"horoscopeCard",[o.C.hotListCard]:"hotListCard",[o.C.mangaCard]:"mangaCard",[o.C.mangaCarousel]:"mangaCarousel",[o.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[o.C.onThisDayCard]:"onThisDayCard",[o.C.prismCarouselCard]:"prismCarouselCard",[o.C.qnaCard]:"qnaCard",[o.C.realEstateCard]:"realEstateCard",[o.C.recipesCard]:"recipesCard",[o.C.richCalendarCard]:"richCalendarCard",[o.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[o.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[o.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[o.C.shoppingCarouselCard]:"shoppingCarousel",[o.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[o.C.shoppingRiverCard]:"shoppingRiverCard",[o.C.shoppingSdCard]:"shoppingSdCard",[o.C.topCommentsCard]:"topCommentsCard",[o.C.trendingNowCard]:"trendingNowWC",[o.C.trendingSearchCard]:"trendingSearchCard",[o.C.weatherCard]:"weatherCard",[o.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[o.C.winAppCard]:"winAppCard"},h={[o.C.bingDailyQuizCard]:"bingDailyQuizCard",[o.C.boostAdCard]:"boostAdCard",[o.C.casualGamesCard]:"casualGamesCard",[o.C.casualGamesCarouselCard]:"casualGamesCarouselCard",[o.C.casualGamesProng2CarouselCard]:"casualGamesProng2CarouselCard",[o.C.casualGamesStripeCarouselCard]:"casualGamesStripeCarouselCard",[o.C.communityCard]:"communityCard",[o.C.contentGroupCard]:"contentGroupCard",[o.C.creatorPromotionCarousel]:"watchCreatorPromotionCarousel",[o.C.creatorSpotlightCard]:"creatorSpotlightCard",[o.C.dailyBriefCard]:"dailyBriefCard",[o.C.dailyGreetingCard]:"dailyGreetingCard",[o.C.dailyMomentsCard]:"dailyMomentsCard",[o.C.dailyWonderCopilotCard]:"dailyWonderCopilotCard",[o.C.dailyWonderQuoteCard]:"dailyWonderQuoteCard",[o.C.donationNpoCard]:"donationNpoCard",[o.C.electionCard]:"electionCard",[o.C.entertainmentPremierCard]:"entertainmentPremierCard",[o.C.esportsCard]:"esportsCard",[o.C.healthCard]:"bingHealthCard",[o.C.healthRiverCard]:"healthRiverCard",[o.C.healthTipCard]:"healthTipCard",[o.C.horoscopeAnswerCard]:"horoscopeCard",[o.C.hotListCard]:"hotListCard",[o.C.mangaCard]:"mangaCard",[o.C.mangaCarousel]:"mangaCarousel",[o.C.mobileTrendingSearchCard]:"mobileTrendingSearchCard",[o.C.onThisDayCard]:"onThisDayCard",[o.C.prismCarouselCard]:"prismCarouselCard",[o.C.qnaCard]:"qnaCard",[o.C.quizCard]:"quizCard",[o.C.realEstateCard]:"realEstateCard",[o.C.recipesCard]:"recipesCard",[o.C.richCalendarCard]:"richCalendarCard",[o.C.sharedHeroNewsCard]:"sharedHeroNewsCard",[o.C.shoppingBannerSdCard]:"shoppingBannerSdCard",[o.C.shoppingBuyingGuidePremiumCard]:"shoppingBuyingGuidePremiumCard",[o.C.shoppingCarouselCard]:"shopping-carousel",[o.C.shoppingEventsDealCard]:"shoppingEventsDealCard",[o.C.shoppingRiverCard]:"shoppingRiverCard",[o.C.shoppingSdCard]:"shoppingSdCard",[o.C.shoppingTopSectionCard]:"shoppingTopSectionCard",[o.C.topCommentsCard]:"topCommentsCard",[o.C.trendingNowCard]:"trendingNowCard",[o.C.trendingSearchCard]:"trendingSearchCard",[o.C.weatherCard]:"weather",[o.C.widgetsNotificationsCard]:"widgetsNotificationsCard",[o.C.winAppCard]:"winAppCard"},g=(e,t)=>{if(!t)return e;let a="";if("ext"in t.contract){let e=t.contract.ext;a=`${e.row}_${e.col}`}return`${e}_${a}`},m=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{wpoMetadata:e.wpoMetadata,mapperArgs:e.mapperArgs,parentTelemetry:e.telemetryObject,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback,cardType:e.cardType},attributes:{style:`grid-area:${e.gridArea};width:${e.mapperArgs?.displaySettings?.cardWidth}px;contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject})}
`;(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize},attributes:{style:`grid-area:${e.gridArea};`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject})}
`;let y=(0,c.qy)`
    ${e=>{let t;return e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{attributes:{style:`grid-area:${e.gridArea}${(t=e.configInfo?.configRef?.experienceType)===r.yXx||t===r.Ohn?";width:100%":""}`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize},telemetryObject:e.telemetryObject})}}
`;(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:"edgeChromium"===l.T3.AppType})}
`;let C=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,cardMetadata:e.mapperArgs?e.mapperArgs.cardMetadata.data:null,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:"edgeChromium"===l.T3.AppType})}
`,f=(0,c.qy)`
    ${e=>e.configInfo&&(0,p.yN)({...e.configInfo,instanceId:`${g(e.configInfo.instanceId,e.telemetryObject)}`},{properties:{mapperArgs:e.mapperArgs,feedLayoutCardSize:e.cardSize,hasLoadedCallback:e.hasLoadedCallback},attributes:{style:`grid-area:${e.gridArea};contain:unset;content-visibility:visible;`,class:`${e.cardSize}`,tabindex:e.customTabIndex??!1},telemetryObject:e.telemetryObject,memoize:!1})}
`;a.d(t,{},{BQ(e,t){let{configOptions:a,cardMetadata:r,hasLoadedCallback:o}=e;t||(t=s.G[r.type]),t||i.YT.sendAppErrorEvent({...n.ODw,message:"No card template type found",pb:{...n.ODw.pb,cardType:r.type}});let l=h[t],c={id:l,childTemplateType:t,mapperArgs:e,configInfo:a,hasLoadedCallback:o,cardType:r?.cardType};return(0,d.bw)({id:l,experienceType:(a&&a)?.configRef?.experienceType,mapperArgs:e},c,null,!0)},R0:h,eW:f,mO:C,ns:y,qq:u,wT:m,zZ:g})},18755(e,t,a){"use strict";var r=a(89757),i=a(94172),o=a(73559);let s=(0,r.qy)`
    ${e=>e.configInfo&&(0,i.yN)(e.configInfo,{properties:{mapperArgs:e.mapperArgs,parentTelemetry:e.telemetryObject,feedLayoutCardSize:e.cardSize},attributes:{style:`grid-area:${e.gridArea}`,class:`${e.cardSize}`},telemetryObject:e.telemetryObject})}
`;a.d(t,{},{K:s,O:{getFeedDataForCard:e=>(0,o.BQ)(e),viewTemplate:s}})},7961(e,t,a){"use strict";var r=a(11803),i=a(44776),o=a(46659),s=a(21386),n=a(89757),l=a(69259),d=a(33744),c=a(2375);let p=(0,n.qy)`      
    <msft-attribution slot="attribution">
    ${(0,l.z)(e=>e.providerData.logoImage,(0,n.qy)`
        <img 
            slot="image" 
            src="${e=>e.providerData.logoImage}" 
            alt="${e=>e.providerData.name}" 
            @load=${e=>{e.imageData&&e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(1,r.j.provider)}} />
    `)}
    <div class="attribution_container_${e=>e.id}" id="attribution_container">
        <div class="attribution_Content_${e=>e.id}" style="${e=>"rtl"===e.dir?"right":"left"}:0px;">
            ${(0,l.z)(e=>e.providerData&&e.providerData.name,(0,n.qy)`<span style="unicode-bidi: embed;">${e=>e.providerData.name}</span>`)}
            ${(0,l.z)(e=>e.providerData&&e.providerData.name&&e.publishedDateTime,(0,n.qy)` · `)}
            ${(0,l.z)(e=>e.publishedDateTime,(0,n.qy)`<span style="unicode-bidi: embed;">${e=>e.publishedDateTime}</span>`)}
            ${(0,l.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,n.qy)` · `)}
            ${(0,l.z)(e=>e.isWebContent&&e.crawledContentLabel,(0,n.qy)`${e=>e.crawledContentLabel}`)}
        </div>
    </div>
    </msft-attribution>

`,u=(0,n.qy)`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card.msft-content-card-preview {
            height: 100px;
        }
        msft-content-card.msft-content-card-preview::part(body) {
            height: 100%;
        }
        msft-content-card.msft-content-card-preview .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card.msft-content-card-preview fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.msft-content-card-preview::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.msft-content-card-preview msft-attribution {
            position: relative;
            overflow: hidden;
            margin-top: 0;
            margin-bottom: 0;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl msft-attribution {
            margin-right: 5px;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            padding: 8px;
            display: flex;
            flex-flow: column-reverse;
            height: 100%;
            box-sizing: border-box;
            justify-content: space-between;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            height: 100%;
        }

        ${e=>"end"===e.imagePosition?`
            msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: right;
                margin-top: unset;
                margin: 8px 8px 8px 0px;
            }
            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: left;
                margin: 8px 0px 8px 8px;
            }
            `:`        
            msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: left;
                margin-top: unset;
                margin: 8px 0 8px 8px;
            }
            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {
                float: right;
                margin: 8px 8px 8px 0;
            }
            `}
        msft-content-card.msft-content-card-preview::part(media),
        msft-content-card.msft-content-card-preview::part(media) img {
            border-radius: unset;
        }
        msft-content-card.msft-content-card-preview::part(heading) {
            font-size: 14px;
            line-height: 20px;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper {
            display: flex;
            gap: 8px;
        }

        msft-content-card.msft-content-card-preview .attribution-wrapper .social-bar-wrapper {
            position: relative;
            z-index: 99999;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl .social-bar-wrapper::before {
            left: unset;
            right: 0px;
            transform: translateX(100%);
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper {
            height: 100%;
            position: absolute;
            top: 0;
            right: 0;
            width: calc(100% - 120px);
            padding: 8px 0;
            box-sizing: border-box;
            display: flex;
            flex-flow: column;
            justify-content: space-between;
            z-index: 2;
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper.image-end {
            right: unset;
            left: 0;
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-attribution-wrapper.no-image {
            width: 100%; 
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-container {
            padding-right: 8px;
            height: 60px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }
        msft-content-card.msft-content-card-preview .image-end .title-container {
            padding-right: 0;
        }
            
        msft-content-card.msft-content-card-preview .provider-top .title-container {
            height:40px;
            -webkit-line-clamp: 2;
            padding-top: 4px;
        }  

        msft-content-card.msft-content-card-preview .title-container:hover {
            text-decoration: underline;
        }
        msft-content-card.msft-content-card-preview .title-container:focus {
            outline: none;
            text-decoration: underline;
        }
        /* 
         *  Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position: absolute;
            transition: all 0.5s ease-out;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }

    /**
    *  To support high contrast mode for accessibility
    **/
    @media (forced-colors: active) {
        msft-content-card.msft-content-card-preview .title-container {
            color: linktext;
        }
    }
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize} msft-content-card-preview-wrapper"
    >
        <msft-content-card
            exportparts="heading"
            id="contentcard_${e=>e.id}"
            href=${e=>e.destinationUrl}
            target=${e=>e.openLinksInNewTab?"_blank":"_self"}
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            style="--heading-max-lines: 2;"
            class="msft-content-card-preview"
            data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
            @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
            @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
        >
            ${(0,l.z)(e=>e.imageData,(0,n.qy)`
                <img
                    slot="media"
                    src="${e=>e.imageData.source}"
                    alt="${e=>e.imageData.altText}"
                    height="${o.L._104x84.height}"
                    width="${o.L._104x84.width}"
                    @load="${e=>{e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(3,r.j.image)}}"
                />
            `)}
            ${e=>{!e.imageData&&e.visualReadinessCallback&&e.visualReadinessCallback()}}
            <div class="title-attribution-wrapper ${e=>e.imageData?.source?"":"no-image"} ${e=>"end"===e.imagePosition?"image-end":""} ${e=>e.providerAboveHeader?"provider-top":""}">
                ${(0,l.z)(e=>e.providerData&&e.providerAboveHeader,p)}
                <div class="title-wrapper">
                    <div class="title-container" tabindex="0" role="link" @keypress="${(e,t)=>"Enter"==t.event.key&&t.event.target.click()}">${(0,n.qy)`${e=>e.title}`}</div>
                    ${(0,l.z)(e=>e.abstract,(0,n.qy)`
                        <p slot="abstract" style="color: var(--neutral-foreground-rest);">${e=>e.abstract}</p>
                    `)}
                </div>
                <div class="attribution-wrapper ${e=>"rtl"===e.dir?"attribution-rtl":""}">
                    ${(0,l.z)(e=>e.providerData&&!e.providerAboveHeader,p)}
                    ${(0,l.z)(e=>e.enableRichSocialReaction,e=>(0,n.qy)`
 <div class="social-bar-wrapper" style="display: flex; gap: 4px; margin-right: 5px;">
     ${(0,l.z)(e=>e.optedOutOfReactions,(0,n.qy)`
         ${i.LW}
         ${i.tB}
     `)}
     <social-bar-wc
         config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,c.v)(e.socialBarWCConfigInfo)}
         instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
         config-shared-ns=${e=>e.socialBarWCConfigInfo?.configRef?.sharedNs}
         :contentId=${e=>e.id}
         :destinationUrl=${e=>e.destinationUrl}
         :locale=${e=>d.T3.CurrentMarket||e.locale}
         :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
         :hideComments=${()=>!0}
         :isRightPos=${e=>e.socialBarInRight}
         :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        theme="superappListCard"
    ></social-bar-wc>
 </div>
 `)}
                </div>
            </div>
            ${(0,l.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,s.p)}
        </msft-content-card>
    </fluent-card>
`;a.d(t,{},{T:u})},60640(e,t,a){"use strict";var r=a(36880),i=a(51122),o=a(40201),s=a(62679),n=a(99381),l=a(44776),d=a(26330),c=a(21386),p=a(69828),u=a(89757),h=a(69259),g=a(44978),m=a(77833),y=a(41483);r.m,i.m;let C=(0,u.qy)`
    <style>
        :host fluent-card {
            content-visibility: auto;
        }
        ${(0,h.z)(e=>e.contentType===m.pL.Video,(0,u.qy)`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            fluent-card._1x_1y msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card span.infopane-title {
            font-size: var(--infopane-title-font-size, 28px);
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        ${e=>v(e)}

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${e=>e.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution, msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${e=>e.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_container_${e=>e.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${e=>e.id}"] .attribution_Content_${e=>e.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea};"
        class="${e=>e.cardSize}"
    >
        <fluent-design-system-provider
            fill-color="#333333"
            style="display: flex; padding: 0; height: 100%;"
        >
            <msft-content-card
                id="contentcard_${e=>e.id}"
                class="${e=>(0,y.dU)(e)}"
                href=${e=>e.destinationUrl}
                target=${e=>e.openLinksInNewTab?"_blank":"_self"}
                title=${e=>e.disableCardTitleTooltip?"":e.title}
                layout="infoPane"
                style="${e=>f(e)}"
                data-t="${e=>e.telemetryContext?.contentCard?.getMetadataTag()}"
                :anchorTelemetryTag=${e=>e.telemetryContext&&e.telemetryContext.destination&&e.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(e,t)=>e.setDisplacementHandler&&e.setDisplacementHandler(t,e.dir)}"
                @mouseleave="${(e,t)=>e.removeDisplacementHandler&&e.removeDisplacementHandler(t,e.dir)}"
            >
            ${(0,h.z)(e=>e.contentIndicator,e=>(0,o.Z)(e.contentIndicator))}
            ${(0,h.z)(e=>!e.isAnaheimDesign,(0,u.qy)`${e=>e.title}`)}
            ${(0,h.z)(e=>e.isAnaheimDesign,(0,u.qy)`<span class="infopane-title">${e=>e.title}</span>`)}
                <img
                    slot="background-image"
                    alt="${e=>e.imageData&&e.imageData.altText}"
                    src="${e=>e.imageData&&e.imageData.source}"
                    @load="${e=>e.imageData&&e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}"
                />
                ${e=>(0,s.fn)(e.isProviderInFooter?"start-actions":"attribution")}
                ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled,n.K)}
                ${(0,h.z)(e=>!e.isAnaheimDesign,(0,u.qy)`
                    <div slot="start-actions" style="gap:0">
                        ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled&&!e.enableRichSocialReaction,(0,u.qy)`
                            ${l.LW}
                            ${l.tB}
                        `)}
                    </div>
                `)}
                <div slot="${e=>e.isProviderInFooter?"end-actions":"start-actions"}" style="gap:0">
                    <style>
                        .card-button:not(:hover) {
                            background: transparent;
                        }
                        msft-content-card fluent-button::part(control) {
                            padding: 0;
                        }
                    </style>
                    ${(0,h.z)(e=>e.enableRichSocialReaction,(0,l.nj)({}))}
                    ${(0,h.z)(e=>e.cardActionStatus&g.J.enabled,(0,u.qy)`
                        ${(0,h.z)(e=>e.enableRichSocialReaction&&e.enableWCSaveButton,(0,u.qy)`
                            ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&g.J.showMore,l.LW)}
                            ${(0,h.z)(e=>!e.optedOutOfReactions&&e.cardActionStatus&g.J.showFewer,l.tB)}
                        `)}
                        ${(0,h.z)(e=>e.enableWCCardAction,d.L)}
                    `)}
                </div>
                ${(0,h.z)(e=>e.enableHoverCardAction&&!e.optedOutOfReactions,c.p)}
            </msft-content-card>
        </fluent-design-system-provider>
    </fluent-card>
`,f=e=>{let t="width: 100%;";return(e.cardSize===p.u._2x_2y||e.cardSize===p.u._2x_3y)&&(t+=" --heading-font-size: 20px; --heading-line-height: 28px;"),(e.cardSize===p.u._1x_1y||e.cardSize===p.u._1x_2y)&&e.useInfopaneSlideTemplate&&(t+=" --infopane-title-font-size: 20px;"),t},v=e=>{let t="";return(e.cardSize===p.u._1x_1y||e.cardSize===p.u._1x_2y)&&e.useInfopaneSlideTemplate&&(t+=`
            msft-content-card[layout="infoPane"]::part(footer) {
                padding: 0 16px 4px;
                margin-bottom: 0;
                height: 40px;
            }
        `),t};a.d(t,{},{g:C})},9039(e,t,a){"use strict";a.d(t,{o:()=>u});var r=a(10862),i=a(46659),o=a(35667),s=a(98669),n=a(77833),l=a(98794),d=a(3006),c=a(72287),p=a(25658);let u={getFeedDataForCard:e=>(function(e){let{cardSlot:t,configOptions:a,parentTelemetryObject:r,cardMetadata:u,openLinksInNewTab:h,visualReadinessCallback:g,isAnaheimDesign:m,isProviderInFooter:y,enableArticleTimestamps:C,localizedStrings:f,enableNewTimestampFormatForJAJP:v}=e;if(!u||!u.subItems||0===u.subItems.length)return(0,d.wc)();let b=u?.subItems[0]?.type===n.pL.WebContent,x=a&&a,_=u.subItems[0].cardContent,{id:w,destinationUrl:S,title:$,provider:A,type:I}=_;x&&(x.instanceId=`denseCard-${w}`);let k={id:w,destinationUrl:S,openLinksInNewTab:h,title:$,ariaLabel:(0,c.yL)($,A,a?.localizedStrings),imagePriority:!1,providerData:(0,c.p_)(A,b),isProviderInFooter:y,imageData:(0,s.po)(u.subItems[0],i.L._240x129,g,m),publishedDateTime:C&&`${(0,s.fL)(v,new Date(_.publishedDateTime),_.locale,f)}`},P=u.subItems.slice(1),T={heroNews:k,newsList:P?.map(e=>{let t=e.type===n.pL.NativeAd||e.type===n.pL.CmsAd,l=e?.cardContent;if(!t){let d=e.type===n.pL.WebContent;return{abstract:e.cardContent.abstract,imageData:(0,s.po)(e,i.L._240x129,g,m),destinationUrl:e.cardContent.destinationUrl,title:e.cardContent.title,ariaLabel:(0,c.yL)(e.cardContent.title,e.cardContent.provider,a?.localizedStrings),providerData:(0,c.p_)(e.cardContent.provider,d),isNativeAd:t,telemetryContext:(0,o.dj)(r,e.cardContent,e.metadata,null,d),isNarrowNewsItem:a?.isNarrowNewsItem,publishedDateTime:C&&`${(0,s.fL)(v,new Date(l.publishedDateTime),l.locale,f)}`}}let d=e.placement?.items[0]||{},{beaconsJson:u,privacyUrl:h,adLabelText:y,isGreyAdsLabelEnabled:b,geminiViewabilityDataJson:x}=e.placement||{};return{...d,beaconsJson:u,privacyUrl:h,adLabelText:y,geminiViewabilityDataJson:x,isNativeAd:t,adTelemetryContext:(0,p.u)(e,r,"river",0),isNarrowNewsItem:a?.isNarrowNewsItem,isGreyAdsLabelEnabled:b}})},D={id:x?.instanceId,childTemplateType:"dense-card",telemetryObject:r,denseConfigInfo:x,denseData:T,visualReadinessCallback:g};return(0,l.bw)({id:"denseCard",experienceType:x?.configRef?.experienceType,mapperArgs:e},D,(e,t)=>{let a=t.telemetryExt;return T.newsList.forEach((e,t)=>{if(!e.isNativeAd&&e.telemetryContext?.destination&&!e.telemetryContext.destination?.contract?.ext){let r=P[t],{traceIdIndex:i}=r||{},{recoId:o,ri:s}=r?.metadata||{},n={...a,recoId:o,ri:s,traceIdIndex:i};e.telemetryContext.destination=e.telemetryContext.contentCard.addOrUpdateChild({...e.telemetryContext.destination.contract,ext:n})}}),{denseData:T}})})(e),viewTemplate:r.e}},10862(e,t,a){"use strict";var r=a(89757),i=a(94172);let o=(0,r.qy)`
<fluent-card
    style="grid-area:${e=>e.gridArea};contain:unset"
    class="${e=>e.cardSize}"
>
    ${e=>(0,i.yN)(e.denseConfigInfo,{properties:{denseData:e.denseData,telemetryObject:e.telemetryObject},memoize:!1,includeTelemetryTag:!1})}
</fluent-card>
`;a.d(t,{},{e:o})},18420(e,t,a){"use strict";a.d(t,{E:()=>n});var r=a(50365),i=a(98794),o=a(94108),s=a(68866);let n={getFeedDataForCard:e=>(function(e){var t;let{configOptions:a={},cardMetadata:r}=e,n=(t=a,!(0,o.Th)().CurrentFlightSet?.has("prg-hp-fvrf")&&t.isWaterfallFeed&&(0,o.Th)().ClientSettings?.pagetype==="hp"),l=r.instanceId||(n?"rectangle1":void 0),d=(0,s.$q)(window.location.href),c="hp2";(0,s._f)(d)?c="hp2lock":(0,s.AO)(d)&&(c="winweb");let p={id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",type:r.type,enableSafeAds:!!a.enableSafeAds,childTemplateType:"display-ad-card",configInstanceSrc:r.configInstanceSrc||(n?"waterfall":"default"),instanceId:l,pageTypeOverride:n?c:void 0,shimmerIdOverride:n?"rectangle1":void 0,batchCallAdCountOverride:a.displayAdBatchCountOverride,enableExtraAdSlug:"rectangle1"===l&&!!n||void 0};return(0,i.bw)({id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",experienceType:a?.configRef?.experienceType,mapperArgs:e},p)})(e),viewTemplate:r.s}},50365(e,t,a){"use strict";var r=a(89757);let i=(0,r.qy)`
<div 
    id="${e=>e.id}"
    style="grid-area:${e=>e.gridArea};
    ${e=>"DisplayAdBanner"===e.type?"display: flex; justify-content: center; overflow: hidden;":""}
    ${e=>"DisplayAdBanner"===e.type&&"_1x_2y"===e.cardSize?"max-width: 300px;":""}
    ${e=>"DisplayAdBanner"===e.type&&"_2x_2y"===e.cardSize?"max-width: 612px;":""}"
    class="${e=>e.cardSize}"
> 
    <display-ads 
        config-instance-src="${e=>e.configInstanceSrc}" 
        instance-id="${e=>e.instanceId}" 
        :enableExtraAdSlug="${e=>e.enableExtraAdSlug}"
        :shimmerIdOverride="${e=>e.shimmerIdOverride}"
        :batchCallAdCountOverride="${e=>e.batchCallAdCountOverride}"
        :pageTypeOverride="${e=>e.pageTypeOverride}"
    >
    
    </display-ads>
</div>
`;a.d(t,{},{s:i})},23897(e,t,a){"use strict";var r=a(89757),i=a(60402),o=a(69259),s=a(33744),n=a(2375),l=a(44978),d=a(2188),c=a(4670);let p={_1x_2y:"1u",_2x_2y:"_2x_2y",_1x_1y:"0.5u"},u=(0,r.qy)`
    <span slot="action-row-start">
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,n.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :url=${e=>e.feedbackUrl}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>s.T3.CurrentMarket||e.locale}
            :theme=${"ads"}
            :rootTelemetryObject=${e=>e.adTelemetryContext?.nativeAdCard}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>()=>e.openAdReportDialog(e)}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
    </span>
`,h=(0,r.qy)`
<cs-responsive-card
    ad=true
    ${(0,d.Ib)(!1,!0)}
    ?ad-va="${e=>e.adVA}"
    ?ad-va2="${e=>e.adVA2}"
    ?ruby-va="${e=>e.enableRubyVerticalAds&&e.adVA2}"
    ?ad-pa="${e=>e.template?.adPA}"
    ?enable-ad-social-bar="${e=>e.enableAdSocialBar}"
    :adAttributes=${e=>e.adAttributes}
    :abstract=${e=>e.abstract}
    ad-dts-style-key="${e=>e.adDTSStyleKey}"
    :adDTSTemplateConfig=${e=>e.adDTSTemplateConfig}
    :adDTSComponentDataMap=${e=>e.adDTSComponentDataMap}
    ?use-ad-dts-layout-renderer=${e=>e.useAdDTSLayoutRenderer}
    :attributionData=${e=>e.attributionData}
    :adSelectionCriteria=${e=>e.adSelectionCriteria}
    :badgeProps="${e=>e.badgeProps}"
    :callToAction="${e=>e.callToAction}"
    :data="${e=>e}"
    data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
    :heading="${e=>e.title}"
    ?hide-card-actions="${e=>e.hideCardActions||!e.feedbackUrl}"
    :href="${e=>e.destinationUrl}"
    :href_adButton="${e=>(0,c.lW)(e)}"
    :href_adChoiceButton="${e=>e.adChoiceIconUrl}"
    id="${e=>e.id}"
    ?dense-zoned="${e=>!!e.denseZoned||void 0}"
    ?zoned-layout="${e=>!!e.zonedLayout||void 0}"
    ?immersive="${e=>("_2x_2y"==e.cardSize||"_1x_2y"==e.cardSize&&!!e.immersiveCard)&&!e.isIntraNativeAd&&!e.__sidebarAd||void 0}"
    :intraArticle=${e=>e.isIntraNativeAd&&!e.disableRespIntraAdStyles}
    :isIntraFeedAd=${e=>e.isIntraNativeAd}
    :isIntraClassicAd="${e=>e.isIntraClassicAd}"
    ?sidebar-ad="${e=>!!e.__sidebarAd||void 0}"
    :mediaData=${e=>e.mediaData}
    media-type="${e=>e.imageData?.source?"image":""}"
    @mouseenter="${(e,t)=>e.mouseEnterCallback(t.event.currentTarget)}"
    @mouseleave="${(e,t)=>e.mouseLeaveCallback(t.event.currentTarget)}"
    :onClickLink="${e=>e.onClickLink}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^l.J.hide^l.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :popoverData="${e=>e.popoverData}"
    size="${e=>"_2x_2y"!=e.cardSize||!e.immersiveCard||e.isInfopane||e.__sidebarAd?p[e.cardSize]||e.cardSize:"2c"}"
    style="grid-area:${e=>e.gridArea};"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>e.adTelemetryContext?.nativeAdCard}"
    :telemetryTag_adButton="${e=>(0,c.j1)(e.adTelemetryContext)}"
    :telemetryTag_adChoiceButton="${e=>e.adTelemetryContext?.adChoice?.getMetadataTag()}"
    :telemetryTag_anchor="${e=>e.adTelemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_moreActions="${e=>e.adTelemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_adDisclaimerButton="${e=>e.adTelemetryContext?.adDisclaimer?.getMetadataTag()}"
    :telemetryTag_callToAction="${e=>e.adTelemetryContext?.callToAction?.getMetadataTag()}"
    :telemetryTag_undoHide="${e=>e.adTelemetryContext?.cancelButton?.getMetadataTag()}"
    title="${e=>e.title}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize&&!e.__sidebarAd||void 0}"
    ?ruby="${e=>e.ruby}"
    ?homepage-rubify-default-height="${e=>e.homepageRubifyDefaultHeight}"
    ?loading="${e=>e.loading}"
    ${(0,i.K)("cardElement")}
>
    ${(0,o.z)(e=>e.enableAdSocialBar&&e.feedbackUrl,u)}
</cs-responsive-card>`;a.d(t,{},{W:h})},88466(e,t,a){"use strict";var r=a(32460),i=a(80299);let o={getFeedDataForCard:e=>(0,i.y5)(e),viewTemplate:r.t};a.d(t,{},{v:o})},80299(e,t,a){"use strict";var r=a(44978),i=a(98794),o=a(85007),s=a(69828),n=a(10071),l=a(35667),d=a(46659),c=a(11803),p=a(86010),u=a(56216),h=a(80119),g=a(82368),m=a(77833),y=a(87906),C=a(40450),f=a(98378),v=a(7446),b=a(94108),x=a(33744),_=a(60763),w=a(45519),S=a(19110),$=a(72287),A=a(72746),I=a(52323),k=a(72106),P=a(54694),T=a(72627),D=a(44916),R=a(12673),M=a(50180),B=a(88904);function L(e){let{cardMetadata:t,configOptions:a,immersiveCard:r,visualReadinessCallback:o,ruby:l,overrideTelemetryExtArgs:d}=e,c=t.type,{childExperienceReferencesWC:p={},childExperienceReferences:u={}}=a,h=O(e,{socialBarWCConfigInfo:p.socialBarWC||u.socialBarWC,videoCardConfigInfo:p.videoCardWC},o),{id:g,metadata:y,telemetryContext:C}=h,v=y?!y.reactionSummary:h&&!h.reactionSummary;n.R.setContentIdCandidateIfNeeded(g,c,v);let b=a&&a,x=t&&t.ri||y&&y.ri,_=t&&t.recoId||y&&y.recoId;return e.configOptions.preloadImages&&(0,$.NN)(h.attributionData?.src),(0,i.bw)({id:g,experienceType:b?.configRef?.experienceType,mapperArgs:e,recoId:_,ri:x},h,(i,n)=>{var d;let c,p=n.cardSize;(h.usePortraitImage||h.useSquareImage)&&h.usePortraitImage;let u=E(h,p,o,r,{segment_1_1:!!e.cardMetadata.feedMetadata?.segment},a),g=s.u._1u;switch(p){case"_1x_1y":g=s.u._05u;break;case"_1x_2y":g=s.u._1u;break;case"_2x_2y":g=l?"2c":s.u._2c;break;default:g=p||s.u._1u}"shorts"===t.size&&(g="shorts"),a.useInfopaneSlideTemplate&&(g=s.u._1u);let y=u?(c=(d=h).contentType)===m.pL.WebContent&&d.metadata?.videoMetadata||c===m.pL.Video?"video":"image":void 0;e.configOptions.preloadImages&&(0,$.NN)(u?.src);let v=n.telemetryExt;a.logThumbnailUrl&&(v.tmb=u?.src),p!==s.u._05u&&(v.height=a.isWaterfallFeed&&a.enableDynamicWaterfall?void 0:304);let b={...C};return b&&b.contentCard&&(b.destination&&(b.destination=b.contentCard.addOrUpdateChild({...b.destination.contract,type:f.MJ.Headline,ext:v,action:f.EG.Click})),b.contentCard=new I.$({...b.contentCard.contract,ext:v})),{visualReadinessCallback:o,mediaData:u,mediaType:y,telemetryContext:b,responsiveCardSize:g,zonedCarouselCard:!!t.zonedCarouselCard,zonedMegaCard:!!t.zonedMegaCard,hideComments:!!(a.hideCommentsInHalfUCards&&g===s.u._05u)}},!0,d)}function O(e,t,a,i=!1,s){var n;let d,c,{cardActionBitMask:u,cardActionClickHandler:h,cardMetadata:k,cardSlot:P,configOptions:T={},enableRichSocialReaction:L,shareActionHandler:N,initCardAction:U,isNarrowTitleFooterGap:q,isPublisherPage:W,cardActionMenuClickCallback:H,getReplacementCardsCallback:j,goToPersonalizeSettingsCallback:K,heightReadyCallback:V,hideCardCallback:G,reactionCallback:J,refreshFeedCallback:Q,visualReadinessCallback:X,localizedStrings:Y,mouseenterHandler:Z,mouseleaveHandler:ee,openLinksInNewTab:et,parentTelemetryObject:ea,getSpotlightMenuItems:er,supportedSdCardActionMenuItems:ei,sdCardActionClickHandler:eo,isSpotlightZone:es,userSubscriptionData:en,displaySettings:el,preventDefaultClick:ed,actionMenuLocalizedStrings:ec,feedbackHandler:ep,shareHandler:eu,immersiveCard:eh,feedName:eg,notificationMetadata:em,openLinksInCurrentTab:ey,renderContentIndicator:eC,ruby:ef,underlineTitle:ev,waterfallCardSlot:eb}=e,{availableActions:ex,enableEverGreenWebContent:e_=!1,enableNewTimestampFormatForJAJP:ew,enableHideStoryFeedback:eS,openPersonalizeWithoutRouter:e$,telemetryConstants:eA={},enabledBadgeTypes:eI,enabledReasonBadgeTypes:ek,disableCardTitleTooltip:eP,enableTitleForTruncate:eT,disablePublishTime:eD,useStatSocialTemplate:eR,enableRubyBottomSocialBar:eM,enableHoverFollowButton:eB}=T,{socialBarWCConfigInfo:eL,videoCardConfigInfo:eO}=t,eF=(0,$.cZ)(k),eE=eF.metadata?.reasons&&T.childExperienceReferencesWC.publisherFollowButton,{cardContent:ez,dynamicCardSize:eN,metadata:eU,isFirstSectionCard:eq,type:eW}=eF,{grid_area:eH}=P,{abstract:ej,id:eK,destinationUrl:eV,locale:eG,title:eJ,publishedDateTime:eQ,provider:eX,defaultAnchorTarget:eY,videoFiles:eZ,isWorkNewsContent:e0,badges:e1}=ez,e2=eW===m.pL.WebContent,e3=(0,$.H8)(eF,u),e4="following"===eg?void 0:eF?.metadata?.reasons,{badge:e6,reasonBadge:e5}=(0,S.bA)(Y,e1,eI,e4,ek),e8=(0,$.nN)(Y,T,e5);eV||(0,y.vV)(C.Okb,"Missing destinationUrl for content card","Article ID: "+eK);let e7=k.recoReasonTag??eU.recoReasonTag;k&&k.recoId&&eU&&(eU.recoId=k.recoId);let e9=eW===m.pL.CasualGamesCarouselSubItem||eW===m.pL.CasualGamesGroupSubItem?(0,o.Y2)(ez,eF):{cardContent:ez,cardMetadata:eU,telemetryName:void 0},te=e9.telemetryName?{contentCardName:e9.telemetryName}:{},tt=(0,l.dj)(ea,e9.cardContent,e9.cardMetadata,void 0,e2,{...l.ZZ,...eA,...te});tt&&tt.hide&&tt.hide.contract&&(tt.showFewer=new I.$({...tt.hide.contract,name:"showFewer",action:f.EG.Click,behavior:f.MS.Dislike,type:f.MJ.ActionButton,content:{...tt?.hide.contract?.content}}),tt.hide.contract.ext={recoReasonTag:e7});let ta=(e3&r.J.hide)!=0||eS&&((e3&r.J.showFewer)!=0||(e3&r.J.hidden)!=0),tr=eU?.videoMetadata||k?.videoMetadata,ti=e2&&!!tr,to=eW===m.pL.Video,ts=k?.size==="shorts",tn=eU?!eU.reactionSummary:eF&&!eF.reactionSummary,tl=null,{disable1MonPlusTimestamp:td,disableNDaysPlusTimestamp:tc}=A.ew.getConfig()||{},tp=(0,D.YS)(eQ),tu=(0,D.Tp)(eQ,tc);td&&tp||tu||(tl=(0,A._L)(eQ,eG,void 0,ew,!0)),tl=e2&&e_&&(0,$.xk)(eQ)?null:tl,(0,$.Be)(eQ,T);let th=""!==b.Rb.MarketDir?b.Rb.MarketDir:"ltr";e7&&e7.tag&&v.YT.addOrUpdateTmplProperty("recoReasonTag","1");let tg=k?.containerType===m.pL.TrendingNowCarousel||k?.containerType===m.pL.NewsTrendingNow,tm=(0,$.p_)(eX,e2,void 0,ti),ty={altText:tm&&tm.name,name:tm&&tm.name,publishedDateTime:eD||tg?null:tl,viewCount:tg?(n=k,(0,w.ZV)(n?.metadata?.consumptionSummary?.totalViews)):null,src:tm&&tm.logoImage,useFollowingButton:!0,providerChannelURL:tm&&F(tm)},tC="";switch(e5?.type.toLowerCase()){case"trending":tC=`${x.T3.StaticsUrl}latest/icons-wc/icons/TrendingLight.svg`;break;case"local":tC=`${x.T3.StaticsUrl}latest/icons-wc/icons/LocationPin.svg`;break;case"followtopic":case"followpublisher":tC=`${x.T3.StaticsUrl}latest/icons-wc/icons/CircleCompleted.svg`}e6?d={isNonInteractive:!0,iconSrc:"",onClickBadge(){},telemetryTag_badge:"",text:e6?.localizedLabel||""}:e5?.type&&(d={iconSrc:tC,onClickBadge:(e,t)=>z(e,t,h,U,null,!eS,Q,e$,tn,p.hs.WhyAmISee),telemetryTag_badge:tt?.whyAmISee?.getMetadataTag(),text:e5?.localizedLabel||""});let tf=!!eF.feedMetadata?.segment;i&&(c=E(eF,a,s,eh,{segment_1_1:tf},T));let tv=eV;ti&&(tv=(0,R.C)(encodeURIComponent(eK),tv)),(0,_.vM)()&&(tv=(0,B.T)(tv,!0)),ts&&(tv=(0,B.C)(tv,"category","shorts")),(0,$.FU)(eU)&&(tv=(0,B.C)(tv,"cgfrom","cg_ruby_ntp_carousel_item"));let tb=ta?(0,g.Eb)(e,e3,eK,ea):{id:eK,dir:th,isWorkNewsContent:e0,gridArea:eH,telemetryContext:tt,defaultAnchorTarget:eY,abstract:ej,cardContent:ez,cardActionStatus:e3,cardActionClickHandler:h,cardActionsTooltips:e8,externalVideoFiles:to?eZ:void 0,videoMetadata:to?tr:void 0,title:eJ,titlePrefix:eF.isFeatured&&Y.topStoriesBreakingNewsTagString,contentType:eW,sdCardActionClickHandler:eo,imagePriority:!1,isWebContent:e2,isFirstSectionCard:eq,metadata:eU||eF,openLinksInNewTab:et,enableRichSocialReaction:L,optedOutOfReactions:tn,userSubscriptionData:en,isPublisherPage:W,locale:eG,immersiveCard:ts||eh,isNarrowTitleFooterGap:q,mouseenterHandler:Z,mouseleaveHandler:ee,actionsArrayOverride:e2&&ex||void 0,displaySettings:el,actionMenuLocalizedStrings:ec,cardActionMenuClickCallback:H,getReplacementCardsCallback:j,goToPersonalizeSettingsCallback:K,heightReadyCallback:V,hideCardCallback:G,preventDefaultClick:ed,reactionCallback:J,refreshFeedCallback:Q,visualReadinessCallback:s??X,shareActionHandler:N,feedbackHandler:ep,shareHandler:eu,destinationUrl:tv,wpoMetadata:eU?.wpoMetadata||eF?.wpoMetadata,wpoRank:eU?.wpoRank||eF?.wpoRank,cardId:eU?.cardId||eF?.cardId,type:eU?.type||eF?.type,subType:eU?.subType||eF?.subType,childTemplateType:"responsive-card",attributionData:ty,providerData:(0,$.p_)(eX,e2),toggleCardActionMenu:(e,t,a,r,i)=>z(e,t,h,U,null,!eS,Q,e$,tn,a,void 0,r,i,eM,eB),mediaData:c,socialBarWCConfigInfo:eL,videoCardConfigInfo:eO,badgeProps:d,publisherFollowButtonConfigInfo:eE&&{...eE,instanceId:`${eE.instanceId}-${eK}`},enableCardHideStoryIcon:T&&T.enableCardHideStoryIcon,badge:e6,reasonBadge:e5,slides:k?.slides||eU?.slides,disableCardTitleTooltip:eP,enableTitleForTruncate:eT,openLinksInCurrentTab:ey,renderContentIndicator:eC,useStatSocialTemplate:eR,order:eb?.order??0};if(em?.spotlightPreviewTypes?.length&&eU?.isSpotlightUX){let{additionalLabelText:e,followedEntity:t,followedType:a,spotlightCardTitle:r}=em;if(tb.childTemplateType="article-breaking-news-card",tb.cardTitle=r,tb.additionalLabelText=e,tb.followedType=a,tb.followedEntity=t,tb.getSpotlightMenuItems=er,tb.supportedSdCardActionMenuItems=ei,tb.isSpotlightZone=es,tb.recoId=k&&k.recoId||eU&&eU.recoId,Y){let{bingVideoNoPreviewStr:e,bingVideoPreviewStr:a,disableNotification:r,followingText:i,followConfirmationText:o}=Y;tb.followButtonTitle=i,tb.followingButtonHoverTip=o&&(0,M.GP)(o,t),tb.disableNotificationText=r,tb.videoNoPreviewLabel=e,tb.videoPreviewLabel=a}}if(tb.ruby=ef,tb.underlineTitle=ev,tb.segment=!!eF.feedMetadata?.segment,ef&&eM){let{reactionSummary:e,commentSummary:t,commentStatus:a}=eU;tb.rubySocialBarData=(0,$.Qw)(e,t,a)}return ef&&(0,$.FU)(eU)&&(tb.hideLikeButton=!0),tb}function F(e){let t=e?.name??"page",a=e?.profileId??"";return(0,k.Hg)(a,t,"source")}function E(e,t,a,r,i,o){if(!t)return;let n=!1,l=u.n._268x140;(t===s.u._05u||t===s.u._1x_1y)&&(l=o.enableHomePageStyle?r?u.n._306x256:u.n._104x84:u.n._90x90),t===s.u._075u&&(l=u.n._268x94),t===s.u._2x_2y&&(l=o?.enableHomePageStyle?u.n._628x372:u.n._612x304),t===s.u._1x_2y&&(l=r?u.n._300x304:d.L._300x156),o.kumoStyle&&(l=(0,h.F)(t,r)||{width:260,height:136},i.segment_1_1&&(l={width:260,height:260}));let p=()=>a(3,c.j.image);return function(e,t,a,r,i){let o=(0,$.Ie)(e);if(!o)return null;let s=(0,P.oQ)(o?.url,{width:t.width,height:t.height,focalRegion:o.focalRegion,enableDpiScaling:!0,devicePixelRatio:(0,T.mZ)(),enableWebpFormat:i});return{altText:e.cardContent?.title,loadCallback:a,errorCallback:r,src:s}}(e,l,p,(e,t)=>{n||(n=!0,(0,y.vV)(C.qog,"Error fetching source","Source: "+e+", Article ID: "+t),p())},o.enableWebpFormat)}function z(e,t,a,i,o=!1,s=!1,n,l,d,c,u,h,g,m,y){let C=t,f=e;t.detail&&t.detail.event&&t.detail.data&&(C=t.detail.event,f=this.getListCardMetadata(t.detail.data),o=!0),(f.isLauncher||f.isThirdParty)&&f.useMobile&&(C.preventDefault(),C.stopPropagation());let{cardSize:v,id:b,title:x,destinationUrl:_,mediaData:w,providerData:S,cardActionStatus:A,telemetryContext:{seeMore:I},actionsArrayOverride:k,metadata:P,isLauncher:T,isThirdParty:D,shareHandler:R,feedbackHandler:M,panoCaption:B,isShoppingArticleCard:L,locale:O,ruby:F}=f,E=u?.overrideReasonsDisplay?[{type:p.QK.trending,rank:0},{type:p.QK.u2u,rank:1}]:P.reasons,N={cardSize:v,enabled:!0,buttonElement:C.currentTarget,fromRightClick:g,article:{id:b,headlineTitle:x,href:_,locale:O,image:{alt:w&&w.altText,src:w&&w.src},provider:{id:S.id,profileId:S.profileId,name:S.name,image:{alt:S.name,src:S.logoImage}},abstract:P.abstract,reasons:E,source:P.source},parentTelemetryObject:I,onStatusChange:a,cardStatus:A,updateFeedOnHide:o,disableHoverSquare:!0,showToast:s,refreshFeedCallback:n,openPersonalizeWithoutRouter:l,actionsArrayOverride:k,isReactionsOptedOut:d,isLauncher:T,isThirdParty:D,shareHandler:R,feedbackHandler:M,debugId:P.debugId,dialogToOpen:c,interactCard:h,useCommunityReactionsForShowMoreLess:F,showAiDisclaimerAttribution:P?.displayAttributes?.showTitleDisclaimer};if(B||L)N.actionsArrayOverride=[r.X.ManageInterests,r.X.Divider,r.X.Report];else if(F&&(0,$.FU)(P))N.actionsArrayOverride=[r.X.WhyAmISee,r.X.Report];else if(F&&(y||m)){let e=[r.X.ShowFewer];y?e.push(r.X.ManageInterests):e.push(r.X.FollowPublisher),e.push(r.X.Mute,r.X.Save,r.X.Divider,r.X.WhyAmISee,r.X.Report),N.actionsArrayOverride=e}g?window.dispatchEvent(new CustomEvent("contentCardRightClick",{detail:{actionState:N,event:C,initCardAction:i}})):i(N)}a.d(t,{As:()=>F,uh:()=>O,y5:()=>L})},32460(e,t,a){"use strict";var r=a(69828),i=a(44776),o=a(89757),s=a(69259),n=a(60402),l=a(44978),d=a(33744),c=a(2375),p=a(94172);let u=(0,o.qy)`
    ${e=>(0,p.yN)(e.publisherFollowButtonConfigInfo,{attributes:{slot:"following-button"},properties:{contentId:e.id,publisherName:e.providerData.name,publisherProfileId:e.providerData.profileId,profileId:e.providerData.id,getReplacementCardsCallback:e.getReplacementCardsCallback,enableFollowToast:!0,cardActionStatus:e.cardActionStatus,usingResponsiveCard:!0}})}
`,h=(0,o.qy)`
    <span slot="action-row-start">
    ${(0,s.z)(e=>e.useStatSocialTemplate,(0,o.qy)`
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,c.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :hideComments=${e=>e.hideComments||!1}
            :canShowOneLineComments=${e=>!e.isInfopane&&e.cardSize===r.u._2x_2y}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>d.T3.CurrentMarket||e.locale}
            :theme=${e=>e.socialBarTheme||"default"}
            :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>e.cardActionClickHandler&&((...t)=>e.cardActionClickHandler(e.id,e.cardActionStatus^l.J.hide,...t))}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
        `,(0,o.qy)`${e=>(0,i.nj)({theme:e.socialBarTheme,hideComments:e.hideComments})}`)}
    </span>
`,g=(0,o.qy)`
<cs-responsive-card
    :abstract=${e=>e.abstract}
    :attributionData=${e=>e.attributionData}
    :badgeProps="${e=>e.badgeProps}"
    :overlayBadgeProps="${e=>e.overlayBadgeProps}"
    :contentIndicator="${e=>e.renderContentIndicator}"
    :data="${e=>e}"
    :heightReadyCallback="${e=>e.heightReadyCallback}"
    :heading="${e=>e.title}"
    :href="${e=>e.destinationUrl}"
    id="${e=>e.id}"
    ?immersive="${e=>"_2x_2y"==e.cardSize||("_1x_2y"==e.cardSize||"_1x_1y"==e.cardSize||"shorts"===e.responsiveCardSize)&&!!e.immersiveCard||void 0}"
    :mediaData=${e=>e.mediaData}    
    media-type="${e=>e.mediaType}"
    :preventDefaultClick="${e=>e.preventDefaultClick}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^l.J.hide^l.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :onClickLink=${(e,t)=>e.onClickLink}
    :onClickCompanionButton=${(e,t)=>e.onClickCompanionButton}
    size="${e=>e.responsiveCardSize}"
    style="${e=>{let t;return e.ruby?void 0:(t=`grid-area:${e.gridArea};`,e.predictedHeight?`${t} --placeholder-intrinsic-height: ${e.predictedHeight-32}px;`:t)}}"
    :rubySocialBarData="${e=>e.rubySocialBarData}"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>e.telemetryContext?.contentCard}"
    :telemetryTag_anchor="${e=>e.telemetryContext?.destination?.getMetadataTag()}"
    :telemetryTag_hideCard="${e=>e.telemetryContext?.showFewer?.getMetadataTag()}"
    :telemetryTag_undoHide="${e=>e.telemetryContext?.undoShowFewer?.getMetadataTag()}"
    :telemetryTag_moreActions="${e=>e.telemetryContext?.seeMore?.getMetadataTag()}"
    :telemetryTag_showMore="${e=>e.telemetryContext?.upvote?.getMetadataTag()}"
    :telemetryTag_undoShowMore="${e=>e.telemetryContext?.undoUpvote?.getMetadataTag()}"
    :telemetryTag_companion="${e=>e.telemetryContext?.companion?.getMetadataTag()}"
    :telemetryObject_commentButton="${e=>e.telemetryContext?.commentsButton}"
    title="${e=>e.title}"
    ?underline-title="${e=>e.underlineTitle}"
    :headingPrefix="${e=>e.titlePrefix}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize||void 0}"
    ?ruby="${e=>e.ruby}"
    ?zoned-carousel="${e=>e.zonedCarouselCard}"
    ?zoned-mega="${e=>e.zonedMegaCard}"
    ?homepage-rubify-default-height="${e=>e.homepageRubifyDefaultHeight}"
    ?segment="${e=>e.segment}"
    ?companion="${e=>e.companion}"
    :companionButtonText="${e=>e.companionButtonText}"
    ${(0,n.K)("cardElement")}
>
    ${(0,s.z)(e=>e.publisherFollowButtonConfigInfo,u)}
    ${(0,s.z)(e=>e.enableRichSocialReaction,h)}
</cs-responsive-card>
`;a.d(t,{},{t:g})},71084(e,t,a){"use strict";a.d(t,{f:()=>n});var r=a(245),i=a(87906),o=a(40450),s=a(98794);let n={getFeedDataForCard:e=>(function(e){try{let{configOptions:t,cardMetadata:a,parentTelemetryObject:r,openLinksInNewTab:i,sdCardActionClickHandler:o,useInlineSvgIcons:n,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d}=e,c="shopping-carousel",p={id:c,childTemplateType:"shopping-carousel-card",openLinksInNewTab:i,sdCardActionClickHandler:o,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d,parentTelemetryObject:r,shoppingCardMetadata:a,shoppingCarouselCardConfigInfo:t&&t,useInlineSvgIcons:n};return(0,s.bw)({id:c,experienceType:p.shoppingCarouselCardConfigInfo?.configRef?.experienceType,mapperArgs:e},p)}catch(e){(0,i.c_)(e,o.Odo,"Error in Shopping Carousel Mapper")}})(e),viewTemplate:r.j}},245(e,t,a){"use strict";var r=a(89757),i=a(94172);let o=(0,r.qy)`
    ${e=>(0,i.yN)(e.shoppingCarouselCardConfigInfo,{attributes:{style:`grid-area:${e.gridArea}`,class:`${e.cardSize}`,tabindex:e.customTabIndex??0},properties:{parentTelemetry:e.parentTelemetryObject,openLinksInNewTab:e.openLinksInNewTab,sdCardActionClickHandler:e.sdCardActionClickHandler,goToPersonalizeCallback:e.goToPersonalizeSettingsCallback,refreshFeedCallback:e.refreshFeedCallback,shoppingCardMetadata:e.shoppingCardMetadata,useInlineSvgIcons:e.useInlineSvgIcons,cardSize:e.cardSize}})}
`;a.d(t,{},{j:o})},28747(e,t,a){"use strict";var r=a(98794),i=a(18576),o=a(18336),s=a(69828),n=a(7446),l=a(3006),d=a(5871);function c(e){let{cardMetadata:t,openLinksInNewTab:a,configOptions:r,refreshSDCardSection:o,refreshFeedCallback:n,goToPersonalizeSettingsCallback:l,flattenedRightRail:c,supportedSdCardActionMenuItems:p,sdCardActionClickHandler:u,visualReadinessCallback:h,dismissSDCardMenuCallback:g,parentTelemetryObject:m,hasLoadedCallback:y,activeBoard:C,isWidget:f,isWidgetRegion:v,turnOffWidgetsRegionCallback:b,manageWidgetsRegionCallback:x,onSDCardClick:_}=e;if(!t.data)return;let w=r.childExperienceReferencesWC?.sportsCard,S=i.F.mapSubCardToSportsMatchData(t),$=t?.data,A=t.cardId,I=t.wpoId;(f||r?.enableSportsCompPreload&&t?.isFirstSectionCard)&&(0,d.Q)(t?.data||"");let k=t.size===s.u.navCard||t.cardSize===s.u.navCard?"_navCard":"",P=`${t.type}${C?`_${C}`:""}${t.metadata?.isSpotlightUX?"_spotlight":""}${k}`,T=`${P}${t.id?`_${t.id}`:""}`;return{id:T,childTemplateType:"sports-card",sportsMatchupData:S,openLinksInNewTab:a,cardId:A,cardStyle:r&&r.cardStyle,sportsCardConfigInfo:w,refreshFeed:o||n,goToPersonalizeCallback:l,visualReadinessCallback:h,hasLoadedCallback:y,noGradient:c,supportedSdCardActionMenuItems:p,sdCardActionClickHandler:u,dismissSDCardMenuCallback:g,feedData:$,cardType:P,experienceName:T,isSpotlightUX:t.metadata&&t.metadata.isSpotlightUX,previewType:t.metadata&&t.metadata.previewType,parentTelemetryObject:m,isWidgetRegion:v,turnOffWidgetsRegionCallback:b,manageWidgetsRegionCallback:x,onSDCardClick:_,wpoId:I,zonedLayout:t?.zonedLayout??!1}}function p(e){let{supportedSdCardActionMenuItems:t,sdCardActionClickHandler:a,waterfallCardSlot:i}=e,d=c(e);return d?(d.isWidgetRegion&&(d.cardSize="_1x_1y"),i?.order&&n.YT.addOrUpdateTmplProperty("sportsCardRow",`${i?.order}`),(0,r.bw)({id:d.id,experienceType:d.sportsCardConfigInfo?.configRef?.experienceType,mapperArgs:e},d,(e,r)=>({cardLayout:r.cardSize===s.u._1x_1y?o.mj.Small:o.mj.Medium,supportedSdCardActionMenuItems:t,sdCardActionClickHandler:a}),!0)):(0,l.wc)()}a.d(t,{v:()=>p,x:()=>c})},32361(e,t,a){"use strict";a.d(t,{Q:()=>s});var r=a(8097),i=a(98794),o=a(73559);let s={getFeedDataForCard:e=>(function(e){let{cardMetadata:t,configOptions:a,parentTelemetryObject:r,visualReadinessCallback:s}=e;if(a&&a.useSharedTelemetry)return(0,o.BQ)(e,"trending-now-card");let n=a&&a;return(0,i.bw)({id:"trendingNowCard",experienceType:n?.configRef?.experienceType,mapperArgs:e},{id:"trendingNowCard",childTemplateType:"trending-now-card",parentTelemetryObject:r,visualReadinessCallback:s,trendingNowCardConfigInfo:n,trendingNowCardMetadata:t},null,!0)})(e),viewTemplate:r.A}},8097(e,t,a){"use strict";var r=a(2375),i=a(89757);let o=(0,i.qy)`
<fluent-card
    style="grid-area:${e=>e.gridArea};"
    class="${e=>e.cardSize}"
>
    <trending-now-card
        config-instance-src=${e=>e.trendingNowCardConfigInfo&&(0,r.v)(e.trendingNowCardConfigInfo)}
        config-shared-ns=${e=>e.trendingNowCardConfigInfo&&e.trendingNowCardConfigInfo.configRef&&e.trendingNowCardConfigInfo.configRef.sharedNs}
        instance-id=${e=>e.trendingNowCardConfigInfo&&e.trendingNowCardConfigInfo.instanceId}
        :feedLayoutCardSize=${e=>e.cardSize}
        :parentTelemetry=${e=>e.parentTelemetryObject}
        :trendingNowCardMetadata=${e=>e.trendingNowCardMetadata}
        :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    >
    </trending-now-card>
</fluent-card>
`;a.d(t,{},{A:o})},88904(e,t,a){"use strict";var r=a(59010),i=a(72627);let o=["ocid","pc","cvid","ei","copilot_traceid"];function s(e,t){let a=new r.m((0,i.iA)()),s="?";if(e.indexOf("?")>-1){let t=new r.m(e).getAllSearchParams();for(let e in t)a.delete(e);s=Object.keys(t).length>0?"&":"?"}return(t&&o.forEach(e=>{a.delete(e)}),0===Object.keys(a.getAllSearchParams()).length)?e:e+s+a.toString()}function n(e,t,a){try{let r=new URL(e);return r.searchParams.set(t,a),r.toString()}catch(t){return e}}a.d(t,{C:()=>n,T:()=>s})},5871(e,t,a){"use strict";var r=a(2018),i=a(87906),o=a(33335),s=a(7446);function n(e){return`${e}Bundle`}let l=Object.freeze({TeamVsTeamWithBracket:"SportsMarchmadness",Articles:"SportsArticle",EventBrief:"SportsEventBrief",Spotlight:"SportsSpotlight",SpotlightRace:"SportsSpotlightRace",SpotlightTennis:"SportsSpotlightTennis",SpotlightGolf:"SportsSpotlightGolf",StandingsRankings:"SportsStandingsRankings",MotorSportsSingleRace:"SportsLeaderboard",MotorSportsRaceList:"SportsLeaderboard",GolfSchedule:"SportsLeaderboard",GolfLeaderBoard:"SportsLeaderboard",FRE:"SportsFre",Cricket:"SportsCricket",Tennis:"SportsTennis",TeamVsTeam:"SportsMatchList"}),d={[n("SportsMatchList")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,14472)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,82724)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,83322)),Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-match-list")]).then(a.bind(a,4708))]).then(e=>({SportsMatchListTransformer:e[0].SportsMatchListTransformer,SportsMatchTransformer:e[1].SportsMatchTransformer})),[n("SportsCricket")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("sports-cricket")]).then(a.bind(a,22726)),Promise.all([a.e("common-feed-libs"),a.e("sports-cricket")]).then(a.bind(a,30502))]).then(e=>e?.[0]),[n("SportsTennis")]:()=>Promise.all([Promise.all([a.e("common-feed-libs"),a.e("sports-tennis")]).then(a.bind(a,87760)),Promise.all([a.e("common-feed-libs"),a.e("sports-tennis")]).then(a.bind(a,39438))]).then(e=>e?.[0])},c={...d,[n("SportsSpotlight")]:()=>Promise.all([a.e("common-feed-libs"),a.e("libs_sports-data-transformers_src_SportsMatchTransformer_ts-web-components_sports-info-match_-e8b077"),a.e("sports-spotlight")]).then(a.bind(a,59682)).then(e=>({SportsSpotlightTransformer:e.SportsSpotlightTransformer,SportsMatchTransformer:e.SportsMatchTransformer,SportsGameStatsTransformer:e.SportsGameStatsTransformer,SportsPickWinnerTransformer:e.SportsPickWinnerTransformer}))};a.d(t,{},{Q(e,t,a){try{let i;if(t)i="Spotlight";else{let t=JSON.parse(e).Model.Tabs[0].tabType;t&&(i=["SeasonStatistics","Video","Countdown","Spotlight"].includes(t)?"Spotlight":["EventBrief","TeamVsTeamWithBracket","SpotlightTennis","SpotlightRace","SpotlightGolf","StandingsRankings"].includes(t)||["MotorSportsSingleRace","MotorSportsRaceList","GolfSchedule","GolfLeaderBoard","FRE","Cricket","Tennis"].includes(t)?t:"TeamVsTeam")}let o=l[i];if(!o)return;let p=r.vv.get("MoneyAndSportsModuleLoadPromiseMap",()=>({})),u=p[o];if(u)return u;let h=a?c:d,g=n(o);if(h[g])return u=h[g](),s.YT.addOrUpdateTmplProperty("sportsPreloaded",`${o}`),p[o]=u,u}catch(e){(0,i.c_)(e,o.MY,"Error in prefetching sports card component","")}}})},45519(e,t,a){"use strict";a.d(t,{},{ZV(e){if(null==e)return"";let t=Number(e);if(isNaN(t)||!isFinite(t))return"";if(t<1e3)return t.toString();let a=["K","M","B","T"],r=-1,i=t;for(;i>=1e3&&r<a.length-1;)i/=1e3,r++;return((i=Math.round(10*i)/10)%1==0?i.toFixed(0):i.toFixed(1))+a[r]},g_(e){if(null==e)return"";let t=Number(e);if(isNaN(t)||!isFinite(t))return"";if(t<1e4)return t.toString();let a=t/1e4;return((a=Math.round(10*a)/10)%1==0?a.toFixed(0):a.toFixed(1))+"w"}})},36597(e,t,a){"use strict";var r=a(95758);function i(e,t=""){let a=new URLSearchParams(window.location.search).get(e);return a&&""!==a?String(a):t}a(68866);let o=new r.bb().data;function s(e,t,a){if(e&&e.length>0){let i=(0,r.KP)(o.devicePixelRatio,"devicePixelRatio"),s=a*(i=i&&i>0?i:1),n=1;if(s<100?n=1.5:s<350&&(n=1.2),e.startsWith("https://www.bing.com/th?id=")||e.startsWith("https://bing.com/th?id=")||e.startsWith("https://th.bing.com/th?id=")){let r=new URLSearchParams(e.substring(e.indexOf("?")+1)).get("id");e=e.substring(0,e.indexOf("?"));let o=Math.floor(a*i*n);e=`${e}?id=${r}&${t}=${o}&p=0`}else if(e.startsWith("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/")){e.includes("?")&&(e=e.substring(0,e.indexOf("?")));let r=Math.floor(a*i*n);e=`${e}?${t}=${Math.floor(r)}`}}return e}function n(e,t,a,r){return(e&&""!==e||(e="ABT748875623C1C490A64E339BEF5741D0A4D98E2E4B21323BED0D12971212C1C24"),e.startsWith("https://www.bing.com/th?id=")||e.startsWith("https://bing.com/th?id=")||e.startsWith("https://th.bing.com/th?id="))?`${e}${t?"&w="+t:""}${a?"&h="+a:""}${r}`:`https://www.bing.com/th?id=${e}${t?"&w="+t:""}${a?"&h="+a:""}${r||""}`}a.d(t,{g8:()=>s,gq:()=>n,wg:()=>i})},94818(e,t,a){"use strict";a.d(t,{J:()=>v});var r,i,o,s,n=a(33744),l=a(42826),d=a(53128),c=a(96882);(r=o||(o={}))[r.ntp=0]="ntp",r[r.dhp=1]="dhp";var p=a(87906),u=a(40450),h=a(96500);(i=s||(s={})).MIT="MIT",i.Topic="Topic",i.Category="category";var g=a(7446),m=a(99252),y=a(12776),C=a(52306);let f="XGP6bGECtXattHPaMTSEtXAJpanIfDLqAumdUN8Bpi";class v{constructor(e,t,a,r,i){this.fetchImpl=e,this.ocid="Peregrine",this.serviceClientSettings=t,this.APISettings=a,this.formCodes=r,this.generateServiceClientSettings(i)}generateServiceClientSettings(e){let t=(0,n.rA)();(0,m.ab)();let a=l._3.getQueryParameterByName("userid",e),r=l._3.getQueryParameterByName("testhooks",e),{enableLocalization:i,addFlightParam:o,queryParamsToForward:s}=this.APISettings;if(this.ocid="Peregrine",this.serviceClientSettings.queryParams){if(this.queryParamsMap=new Map(Object.entries(this.serviceClientSettings.queryParams)),this.queryParamsMap.set("apikey",this.serviceClientSettings.queryParams.apiKey||t.OneServiceApiKey),this.queryParamsMap.set(t.OneServiceContentMarketQspKey,t.CurrentMarket),this.queryParamsMap.set("ocid",this.ocid),this.queryParamsMap.set("trackingid",t.ActivityId),this.queryParamsMap.set("testhooks",r),"1"===r&&a&&this.queryParamsMap.set("userid",a),i&&t.Latitude&&t.Longitude&&(this.queryParamsMap.set("lat",t.Latitude),this.queryParamsMap.set("long",t.Longitude)),t.ShouldUseFdheadQsp){let e=o&&t.CurrentRequestTargetScope&&t.CurrentRequestTargetScope.pageExperiments,a=e&&e.join(",");this.queryParamsMap.set("fltids",a)}if(s){let t=new Set(s),a=new URL(e);a&&a.search&&new URLSearchParams(a.search).forEach((e,a)=>{t.has(a)&&this.queryParamsMap.set(a,e)})}}this.serviceClientSettings.pathComponents?this.pathComponentsMap=new Map(Object.entries(this.serviceClientSettings.pathComponents)):this.pathComponentsMap=new Map,this.pathComponentsMap.set(t.OneServiceContentMarketQspKey,t.CurrentMarket),this.pathComponentsMap.set("version","v1")}async getShoppingEntitiesData(e=null){let t=null;return await this.getShoppingEntitiesDataJson(e).then(e=>{t=this.TryGetShoppingEntitiesData(e)}).catch(e=>{(0,p.c_)(e,u.xkP,"Failed to fetch Shopping entities response")}),t}async getShoppingEntitiesDataJson(e=null){let{pathComponents:t,queryParams:a,serviceBaseUrl:r,servicePath:i}=this.serviceClientSettings,o=[];if(a)for(let e of this.queryParamsMap.entries())o.push({key:e[0],value:e[1]});if(t)for(let e of this.pathComponentsMap.entries())i=i.replace(`{${e[0]}}`,e[1]);let s=new URL(i,r);if(s.search=l._3.keyValueArrayToQueryString(o),this.serviceClientSettings.additionalUrlAugmentations&&(s.search=s.search.concat(this.serviceClientSettings.additionalUrlAugmentations)),e&&e.data)try{let t=JSON.parse(e.data);return h.v.log("shoppingEntitiesData provided by parent in serviceContextMetadata"),t}catch(e){return(0,p.c_)(e,u.ECJ,"Error in getShoppingEntitiesDataJson, unable to parse serviceContextMetadata"),null}{let e=await this.fetchImpl(s.href,{method:"GET",headers:{accept:"application/json"}});return e.ok?e.json():(g.YT.sendAppErrorEvent({...u.xkP,message:"Shopping carousel response not ok.",pb:{...u.xkP.pb,customMessage:`Shopping carousel response not ok. Status: ${e.status}, StatusText: ${e.statusText}`}}),null)}}convertBlackJackDealsDataToShoppingEntitiesData(e){let t=e.shoppingEntities.map(e=>({...e,communityInfo:this.ensureSocialBarDataForBlackjackDealsCommunityInfo(e.communityInfo,e.title,e.id),viewsCount:e.productInsightsData.uxInsightDecoration.find(e=>e.startsWith("ViewCountInsight"))?.match(/--(.+)/)?.[1]})).filter(e=>0!==Object.keys(e).length);return t.length>0?{shoppingEntities:t}:null}ensureSocialBarDataForBlackjackDealsCommunityInfo(e,t,a){let{itemId:r,itemUrl:i}=e??{};if(r&&i)return e;let o=C.E.buildAbsoluteUrl(t,void 0,a),s={itemId:o,itemUrl:o};return e?{...e,...s}:s}TryGetShoppingEntitiesData(e){let t,{enablemsnsdcardcms:a}=this.APISettings;if(!e)return g.YT.sendAppErrorEvent({...u.Fjq,message:"Received empty ShoppingEntitiesData response.",pb:{...u.Fjq.pb,customMessage:JSON.stringify(e)}}),null;if(e.prongCards&&e.prongCards.length>0)return this.GetProngCardItems(e);if(e.productCards&&e.productCards.length>0)return e;if(e.shopping&&e.shopping.length>0)return JSON.parse(e.shopping[0].data);if(e.length>0&&e[0]?.type=="ShoppingCard")return JSON.parse(e[0].data);if(e.length>0&&e[0]?.type=="ShoppingCarousel"){let t=JSON.parse(e[0].data);if(t.topics&&t.topics.some(e=>"Blackjack"===e.title&&e.shoppingEntities?.length>0))return this.convertBlackJackDealsDataToShoppingEntitiesData(t.topics.find(e=>"Blackjack"===e.title))}let r=[];if(e[0]?.type=="ShoppingBuyDirectCard"?(t=e[0].type,(r=JSON.parse(e[0].data)).forEach(e=>{e&&e.imageInfo&&""==e.imageInfo.sourceImageUrl&&e.imageInfo.images&&(e.imageInfo.sourceImageUrl=e.imageInfo.images[0].url)})):e[0]?.type=="ShoppingFeedResponse"&&a?(t=e[0].type,(r=JSON.parse(e[0].data)?.categories).forEach(e=>{e&&e.backgroundImage&&void 0==e.imageInfo&&(e.imageInfo=e.backgroundImage,e.clickUrl=e.backgroundImage.clickUrl)})):r=e[0]?.type=="ShoppingFeedResponse"?JSON.parse(e[0].data)?.trendingProducts:e.shoppingEntities,!r||0==r.length)return g.YT.sendAppErrorEvent({...u.dMO,message:"Missing required fields in ShoppingEntitiesData response.",pb:{...u.dMO.pb,customMessage:JSON.stringify(e)}}),null;let{enbaleFirstCarouselItems:i,enbaleSecondCarouselItems:o,minCarouselItems:s,maxCarouselItems:n,randomizeCarouselItems:l}=this.APISettings;if(l&&(r=r.sort(()=>.5-Math.random())),r.length<s)return g.YT.sendAppErrorEvent({...u.c7V,message:"Insufficient shoppingEntities items in shoppingEntitiesData response.",pb:{...u.c7V.pb,customMessage:`MinimumRequired=${s}, shoppingEntitiesCount=${r.length}`}}),null;r.length>n&&(r=r.slice(0,n)),r.length>1&&i&&(r=r.slice(0,Math.ceil(r.length/2))),r.length>1&&o&&(r=r.slice(Math.ceil(r.length/2)));let d=this.GetFormCode("shoppingEntities");return r.forEach(e=>{e&&e.clickUrl&&(e.clickUrl=`${e.clickUrl}&FORM=${d}`)}),e.shoppingEntities=r,e.type=t,e}GetFormCode(e){let t=d.U0.isDhpPage()?o.dhp:o.ntp;return this.formCodes&&this.formCodes[e]&&this.formCodes[e][o[t]]}GetProngCardItems(e){if(!this.serviceClientSettings.usingPreviewTable&&!this.serviceClientSettings.usingProductionTable){let t=e.prongCards.filter(e=>e.type===s.Category).sort(()=>.5-Math.random()),a=e.prongCards.filter(e=>e.type!==s.Category).sort(()=>.5-Math.random());e.prongCards=t.concat(a).slice(0,10)}return e}getDealsSDCardRequestBody(){return JSON.stringify({categoryId:"All",getProductDeals:!0,skip:0,take:this.serviceClientSettings.queryParams.take||30,userMuid:(0,m.ab)()})}async getShoppingEntitiesDataUsing1S(e=!0,t,a=u.xkP){let r=null,i="shopping/blackjack/getblackjackdeals"===this.serviceClientSettings.servicePath?await this.fetchFrom1S(t,"POST",this.getDealsSDCardRequestBody()):await this.fetchFrom1S(t,"GET");return i?r=this.TryGetShoppingEntitiesData(i):e&&(0,p.c_)(Error("Failed to fetch Shopping entities response"),a,`Failed to fetch Shopping entities response, with filter ${this.serviceClientSettings?.queryParams?.filter}`),r}async fetchFrom1S(e,t="GET",a=null){let r=(0,n.rA)(),i={method:t,headers:await y.WR.getOneServiceHeaders(),body:a,timeoutMs:e},o=[];if((0,m.ab)()&&!this.APISettings.skipUserMUID&&(o.push({key:"user",value:"m-"+(0,m.ab)()}),i.headers||(i.headers={MUID:(0,m.ab)()}),i.headers.MUID=(0,m.ab)()),this.serviceClientSettings.queryParams){o.push({key:"apikey",value:this.serviceClientSettings.queryParams.apikey||f}),o.push({key:r.OneServiceContentMarketQspKey,value:r.CurrentMarket}),this.serviceClientSettings.queryParams.ocid&&o.push({key:"ocid",value:this.serviceClientSettings.queryParams.ocid}),this.serviceClientSettings.queryParams.top&&o.push({key:"$top",value:this.serviceClientSettings.queryParams.top}),this.serviceClientSettings.queryParams.contentType&&o.push({key:"contentType",value:this.serviceClientSettings.queryParams.contentType});let e="";r.ShouldUseFdheadQsp&&r.CurrentRequestTargetScope?.pageExperiments&&(e=r.CurrentRequestTargetScope.pageExperiments.join()),r.ShouldUseFdheadQsp&&this.serviceClientSettings.queryParams.fdhead&&(e=e+","+this.serviceClientSettings.queryParams.fdhead),e&&o.push({key:"fdhead",value:e}),this.serviceClientSettings.queryParams.select&&o.push({key:"$select",value:this.serviceClientSettings.queryParams.select}),this.serviceClientSettings.queryParams.filter&&o.push({key:"$filter",value:this.serviceClientSettings.queryParams.filter}),this.serviceClientSettings.queryParams.setactivityid&&o.push({key:"activityId",value:(0,c.G)()})}else o.push({key:"apikey",value:f});let s=new URL(this.serviceClientSettings.servicePath,this.serviceClientSettings.serviceBaseUrl);s.search=l._3.keyValueArrayToQueryString(o);try{let e=await this.fetchImpl(s.href,i);if(e.ok)return await e.json()}catch(e){(0,p.c_)(e,u.F6z,`MSN homepage shopping carousel fetch data failed, request url: ${s.href}`)}o.pop(),s.search=l._3.keyValueArrayToQueryString(o);try{let e=await this.fetchImpl(s.href,i);if(e.ok)return await e.json()}catch(e){return(0,p.c_)(e,u.F6z,`MSN homepage shopping carousel second call fetch data failed, request url: ${s.href}`),null}}async hasBuyDirectInterest(){let e=await this.getShoppingEntitiesDataUsing1S(!0);if(!e||!e.shoppingEntities||!e.shoppingEntities.length)return!1;let t=e.shoppingEntities[0];return!!(t.id&&t.id.startsWith("Reco-"))}}},50880(e,t,a){"use strict";a.d(t,{KA:()=>k,Y6:()=>D,nt:()=>P,rF:()=>T,HU:()=>v,eJ:()=>$,B:()=>A,os:()=>S,py:()=>b,VN:()=>I,z7:()=>w,yA:()=>x,Cb:()=>function e(t){return C(t,function(a,r,i){a[Array.isArray(t)?i:(0,f.A)(""+i)]=(0,m.A)(r)?e(r):r})}});var r,i,o=a(33744),s=a(43672),n=a(54837),l=a(12420),d=a(93653),c=a(56018),p=a(87827),u=a(78285),h=a(53867),g=a(9790),m=a(6809),y=a(26888);let C=function(e,t,a){var r=(0,u.A)(e),i=r||(0,h.A)(e)||(0,y.A)(e);if(t=(0,c.A)(t,4),null==a){var o=e&&e.constructor;a=i?r?new o:[]:(0,m.A)(e)&&(0,g.A)(o)?(0,l.A)((0,p.A)(e)):{}}return(i?n.A:d.A)(e,function(e,r,i){return t(a,e,r,i)}),a};var f=a(96883);function v(e){if(!e)return"";let t=e.split("-");return 2===t.length?t[1]:e}function b(e){return!isNaN(Number(v(e)))}function x(e){if(!e)return"";let t=e.split("-");return 2===t.length?t[1]:e}function _(e,t){if(e){var a;return(a=e,e=o.T3.CurrentMarket===s.DX.JAJP&&(a+"").indexOf(".00")>-1?(a+"").replace(".00",""):a+"",t&&-1==e.indexOf(t))?t+e:e}return""}function w(e,t,a=s.DX.ENUS){if(e){let r,i=(-1!==(e+="").indexOf(t)?e.replace(t,""):e).replace(/,/g,""),o=parseFloat(i);if(o+"00"!==(r=i.length,i.slice(0,r-3)+i.slice(r-2,r))&&o+""!==i);else if(a===s.DX.JAJP)return _(o.toLocaleString(a),t);else return _(o.toLocaleString(a,{minimumFractionDigits:2,maximumFractionDigits:2}),t)}return e}function S(e,t){return e&&t?String(e)+"+"+t:""}function $(e,t,a){if(!e||!t||!(e>=t))return"";{let r=(e-t)/1e3,i=String(parseInt(String(r/60/60%24)));i=10>Number(i)?"0"+i:i;let o=String(parseInt(String(r/60%60)));o=10>Number(o)?"0"+o:o;let s=String(parseInt(String(r%60)));return a+String(i+":"+o+":"+(s=10>Number(s)?"0"+s:s))}}function A(e){let t=[],a=[];return e&&e.length>0&&e.forEach(e=>{if(e&&e.id&&e?.imageInfo?.sourceImageUrl){let r=new URLSearchParams(new URL(e.imageInfo.sourceImageUrl).search);r.has("id")&&(t.push(v(e.id)),a.push(r.get("id")))}}),[t,a]}function I(e=new Date().getHours(),t=new Date().toLocaleDateString(),a=72e5){return new Date(t+(e>=10?" "+e:" 0"+e)+":00:00").getTime()+a}function k(e){return btoa(Array.from(new TextEncoder().encode(e)).map(e=>String.fromCharCode(e)).join(""))}function P(e,t,a){if(!e||!t||!a)return;let r=+e.replace(a,"").replace(",",""),i=+t.replace(a,"").replace(",","");if(!r||!i)return;let o=r-i;if(!(o<=0))return o}function T(e,t,a,r=!1){let i=P(e,t,a);if(!i)return;let o=100*i/e.replace(a,"").replace(",","");return(r?Math.ceil(o):Math.floor(o))+"%"}function D(e,t){if(e){let a=e;return t?.forEach(e=>{a=a.replace(RegExp(e+"$"),"")}),a=a.replace(/[^a-z0-9]/gi,"").toLowerCase()}return e}(r=i||(i={})).el="el",r.es="es",r.da="da",r.fi="fi",r.fr="fr",r.hu="hu",r.it="it",r.ja="ja",r.nl="nl",r.pl="pl",r.pt="pt"},37125(e,t,a){"use strict";var r=a(69326);function i(e=!1){let t,a,o;return(a=(t=new Date).getUTCDay(),o=t.getUTCHours(),!(1==a&&o>=18||5==a&&o<22||a>=2&&a<=4)||(0,r.kg)()||e)?30:20}function o(e){return e.toString()+"%"}a.d(t,{Lm:()=>i,Yd:()=>o})},5977(e,t,a){"use strict";var r=a(33744),i=a(45596),o=a(87906),s=a(40450);function n(e,t){(0,o.c_)(e,s.Wbw,`url: ${t}`)}function l(e,t,a,r,i){try{if(!e||!t&&!a||0===t||0===a)return"";let o=new URL(e),s=o.searchParams.get("bw"),n=s?parseInt(s):0;n&&(t=t?t-2*n:t,a=a?a-2*n:a),t&&o.searchParams.set("h",t.toString()),a&&o.searchParams.set("w",a.toString()),void 0===r||o.searchParams.get("c")||o.searchParams.set("c",r),null!=i&&""!==i?o.searchParams.set("rs",i):o.searchParams.set("rs","1");let l=o.toString();t&&o.searchParams.set("h",(2*t).toString()),a&&o.searchParams.set("w",(2*a).toString()),n&&o.searchParams.set("bw",(2*n).toString());let d=o.toString();return`${l} 1x, ${d} 2x`}catch(t){return n(t,e),`${e} 1x`}}function d(e){let t=e.imageInfo?.images;if(t&&t.length>1){let a=t.map(e=>({...e,sourceImageUrl:(0,i.zt)(e.url)}));e.imageInfo.sourceImageUrl||(e.imageInfo.sourceImageUrl=a[0].sourceImageUrl),e.images=a.filter(t=>t.sourceImageUrl!==e.imageInfo.sourceImageUrl)}}function c(e,t=0){let a=e.imageInfo?.sourceImageUrl;a&&(e.imageInfo.sourceImageUrl=p(u(a,t),"17"))}function p(e,t){try{let a=new URL(e);return a.searchParams.set("c",t.toString()),a.toString()}catch(t){return n(t,e),e}}function u(e,t=0,a="FFFFFF"){if(!t||!a)return e;try{let r=new URL(e);return r.searchParams.set("bw",t.toString()),r.searchParams.set("bc",a),r.toString()}catch(t){return n(t,e),e}}async function h(e,t="",a="",r=1,i=0){if(!t&&!a||!e.imageInfo?.sourceImageUrl)return;let o=await g(e),s="";o&&t&&(s=t),!o&&a&&(r=function(e){try{let t=new URL(e),a=t.searchParams.get("w"),r=t.searchParams.get("h"),i=a?parseInt(a):0,o=r?parseInt(r):0;if(!i||!o)return;return i/o}catch(t){n(t,e);return}}(e.imageInfo.sourceImageUrl)||r,e.imageInfo.ratio&&.2>Math.abs(e.imageInfo.ratio-r)&&(s=a)),e.imageInfo.hasWhiteBackground=o,s&&(e.imageInfo.sourceImageUrl=p(e.imageInfo.sourceImageUrl,s),i&&o&&(e.imageInfo.sourceImageUrl=u(e.imageInfo.sourceImageUrl,i)))}async function g(e){try{let t=e.imageInfo?.sourceImageUrl;if(!t)return!0;let a=await m(function(e,t=50){let a=new URL(e);return a.searchParams.set("w",t.toString()),a.searchParams.delete("h"),a.toString()}(t)),r=a.naturalWidth,i=a.naturalHeight;if(!r||!i)return!0;return e.imageInfo.ratio=r/i,function(e){try{e.crossOrigin="anonymous";let t=document.createElement("canvas"),a=e.naturalWidth,r=e.naturalHeight;t.width=a,t.height=r;let i=t.getContext("2d");i?.drawImage(e,0,0);let o=i?.getImageData(0,0,t.width,t.height),s=o?.data;if(!s)return!0;return function(e,t,a,r=5,i=20){let o=0;for(let s=0;s<a;s++)for(let n=0;n<t;n++)if(n<r||n>=t-r||s<r||s>=a-r){let a=(s*t+n)*4,r=e[a],l=e[a+1],d=e[a+2],c=255-i;r>c&&l>c&&d>c&&o++}return o/(2*r*(t+a-2*r))*100}(s,a,r)>=25}catch(t){return n(t,e.src),!0}}(a)}catch(e){return!0}}async function m(e){let t=new Image;return t.crossOrigin="anonymous",t.src=e,await t.decode(),t}(0,r.rA)().StaticsUrl,a.d(t,{AO:()=>d,Ep:()=>h,Je:()=>l,iD:()=>c})},52306(e,t,a){"use strict";var r=a(45596),i=a(50880);class o extends r.dN{static buildAbsoluteUrl(e,t,a,r,o=!0,s){a=(0,i.yA)(a);let n=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(n,"msnembedded",t,o),n.searchParams.append("filters",this.getFiltersQueryParam(a,s)),n.searchParams.append("q",e),n.searchParams.append("productpage","true"),r&&n.searchParams.set("overlay","true"),n.href}static getFiltersQueryParam(e,t){let a=new URLSearchParams(window?.location?.search||""),r=`pdprecocache:"true" scenario:"17" gType:"12" gId:"${e}" gGlobalOfferIds:"${e}"`;return t&&(r+=' brqenabled:"true"'),e?r:a.get("filters")||""}}o.bingBaseUrl="https://www.bing.com/shop/productpage",a.d(t,{E:()=>o})},52226(e,t,a){"use strict";var r=a(45596),i=a(7446);class o extends r.X9{static buildAbsoluteUrl({market:e,pid:t,title:a,clickSource:o,trafsrc:s,ocid:n,formCode:l,isBing:d,isBWM:c,campaignCode:p,addEntrypoint:u=!0}){if(d){let o=new URLSearchParams;if(a){let e=a.split(" ");a=e.length>2?e.slice(0,-2).join(" "):e.join(" "),o.set("q",a??"")}t&&(u&&o.set("entrypoint","buydirect"),o.set("productpage","true"),o.set("browse","true"),o.set("filters",`scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`)),e&&o.set("setmkt",e),s&&o.set("trafsrc",s),n&&o.set("ocid",n),l&&o.set("FORM",l),p&&o.set("CBC",p),o.set("msnrid",i.YT?i.YT.getRequestId():"Telemetry not initialized"),o.set("adunitId","378983"),o.set("propertyId","316966");let d=(0,r.wW)(o);return t?`https://www.bing.com/shop/productpage${d?"?"+d:""}`:`https://www.bing.com/shop/buywithmicrosoft${d?"?"+d:""}`}{let i=new URLSearchParams;t&&i.set("pid",t),o&&i.set(r.Ts.ClickSourceQueryParam,o),a&&i.set("title",a),n&&i.set("ocid",n),s&&i.set("trafsrc",s),l&&i.set("FORM",l);let d=(0,r.wW)(i);return t?`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/product${d?"?"+d:""}`:`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/superdeals${d?"?"+d:""}`}}static addSearchParams({url:e,pid:t,title:a,clickSource:i,trafsrc:o,ocid:s,formCode:n},l){if(!e)return e;let d=new URLSearchParams;a&&d.set("title",a),t&&d.set("pid",t),i&&d.set(r.Ts.ClickSourceQueryParam,i),s&&d.set("ocid",s),o&&d.set("trafsrc",o),n&&d.set("FORM",n);let[c,p]=e.split("?"),u=(0,r.$c)(new URLSearchParams(p),d),h=(0,r.wW)(u);if(l&&!t){let e=c.indexOf("/buydirect");if(-1!==e){let t=c.slice(e+10);return`https://www.bing.com/shop/buywithmicrosoft${t}${h?`?${h}`:""}`}}return c+(h?`?${h}`:"")}}a.d(t,{u:()=>o})},45596(e,t,a){"use strict";var r,i,o=a(72627),s=a(7446),n=a(33744),l=a(43672),d=a(69326),c=a(50880);function p(e){return new URLSearchParams((0,o.iA)()).get(e)}function u(e,t=!1,a=!1){let r=new URLSearchParams(location.search);t&&function(e){let t=["modal-offer-ids","modal-image-ids","pid","title","clksrc","modal-ec-ids"];for(let a=0;a<t.length;a++){let r=t[a];e.delete(r)}}(r),a&&r.delete("disableheader"),e&&e.forEach((e,t)=>{r.set(t,e)});let i=new URLSearchParams;return r.getAll("item").forEach(e=>i.append("item",e)),r.delete("item"),`${r}${i.getAll("item").length>0?"&"+decodeURIComponent(i.toString()):""}`}function h(e,t){let a=new URLSearchParams(e);return t&&t.forEach((e,t)=>{a.set(t,e)}),a}(r=i||(i={})).ClickSourceQueryParam="clksrc",r.ModalCarouselOfferIdsQueryParam="modal-offer-ids",r.ModalCarouselImageIdsQueryParam="modal-image-ids",r.ModalCarouselECIdsQueryParam="modal-ec-ids",r.gameFirstPositionQueryParam="game-first-position",r.itemQueryParam="item",r.AutoShowEdgeSidePane="auto_show_edge_shopping_pane",r.FeaturedComponentKey="featc",r.FeaturedComponentIndex="feati";class g{static getSchemeAndDomain(){return window.location.origin.indexOf("localhost")>-1?window.location.origin:`https://${n.T3.NavTargetHostName}`}}let m=Object.freeze({NtpSdCard:"SDPDP1",NtpEventCard:"NTPMIT",NtpEventCard2:"NTPMIF",NtpCarousel:"CARPDP",NtpToL2Overlay:"STPDPI",NtpToL2OverlayWithoutOfferIds:"STPDPF",NtpToL2OverlayWithBRQ:"STPDPK",NtpAugmentCard:"SHAUG1",NtpSdCardControl:"STPDPG",NtpCarouselControl:"STPDPH",NtpToL2OverlayControl:"STPDPJ",Bing:"SHOPHP",Start:"SSPD01",FullPage:"ANNTS2",BingSDCardclick:"bhshpc",MeStripe:"msmstb",TopNav:"mstntb",AtfTitle:"mscatft",AtfCard:"msatfc",ShoppingTopSpan:"TOPARC",ShoppingViewsCarousel:"arcarc",ShoppingViewsCarousel2:"SHCAR2",ShoppingViewsCarousel1:"SHCAR1",Prong2Pivot:"P2SHPV",Prong2:"P2SHOP",Prong2Fashion:"P2SHFS",Prong2BGPremium:"P2BGPM",Prong2BGPremiumProduct:"P2BGPD",Prong1:"PRSHOP",Prong1BGPremium:"P1BGPM",Prong1BGPremiumProduct:"P1BGPD",MITSHP:"MITSHP",BuyingGuide1:"BGPDP1",BuyingGuideRelatedSearch:"BGLIRS",BuyingGuideInfoPane:"INFOBG",BuyingGuideAds:"SSBG01"});class y{static getBingShoppingQueryParameters(e,t,a=!0){let r=new URLSearchParams;return r.set("entryPoint",e),t&&r.set("FORM",t),"msn"!==e||(0,d.kg)()||r.set("msnrid",s.YT.getRequestId()),a&&n.T3.CurrentMarket!==l.DX.FRFR&&(r.set("adunitId","378983"),r.set("propertyId","316966")),r}static updateBingShoppingQueryParameters(e,t,a,r=!0,i){return e.searchParams.delete("adunitid"),e.searchParams.delete("propertyid"),this.getBingShoppingQueryParameters(t,a,r).forEach((t,a)=>e.searchParams.set(a,t)),i&&e.searchParams.set("ocid",i),e.toString()}static updateUrlIfBingShopping(e,t){return e?.startsWith("https://www.bing.com/shop")?y.updateBingShoppingQueryParameters(new URL(e),t):e}}function C(e){return e?e.replace("?id=/th?","?"):""}function f(){return"1"===p("isembedded")||"1"===p("disableheader")}function v(e){return!e.find(e=>e&&!(0,c.py)(e))}function b(e,t){let a=new URL(e);return Object.keys(t).forEach(e=>{a.searchParams.set(e,t[e])}),a.toString()}function x(e,t,a,r=!0){let i=new URL(e);i.searchParams.delete("adunitid"),i.searchParams.delete("propertyid");let o=new URLSearchParams;return o.set("entryPoint",t),a&&o.set("FORM",a),"msn"!==t||(0,d.kg)()||o.set("msnrid",s.YT.getRequestId()),r&&n.T3.CurrentMarket!==l.DX.FRFR&&(o.set("adunitId","378983"),o.set("propertyId","316966")),o.forEach((e,t)=>i.searchParams.set(t,e)),i.toString()}a.d(t,{$c:()=>h,DH:()=>b,F7:()=>v,Ts:()=>i,X9:()=>g,dN:()=>y,h3:()=>f,wA:()=>p,wQ:()=>x,wW:()=>u,zt:()=>C},{eA:m})},31216(e,t,a){"use strict";var r=a(40450),i=a(87906);let o=(e,t,a)=>`${e??t??"N/A"}${a?" (playlist) ":""}`,s=(e,t)=>{(0,i.vV)(e,"Data returned by content view does not contain expected video data.",t,{...e.pb})};a.d(t,{},{H8:o,RD:(e,t,a)=>e?.title?(e?.thumbnail?.image||s(r.r5T,`Video ID [${o(e?.id,t,a)}] has an empty headline image but the content is valid.`),((e,t,a)=>{if(e?.videoMetadata?.externalVideoFiles?.length){let i=e.videoMetadata.externalVideoFiles;if(!i?.find(e=>!e.url&&!e.format))return!0;s(r.WWk,`Video ID [${o(e.id,t,a)}] has an invalid 1pp video file.`)}return!1})(e,t,a)):(s(r.Ta7,`Video ID [${o(e?.id,t,a)}] has an empty headline.`),!1),Wr:s,qK(e){let{cardContent:t,metadata:a}=e;return{id:e.id,title:t?.title,thumbnail:{image:t?.images?.[0]},videoMetadata:{playTime:a?.videoMetadata.playTime,externalVideoFiles:t?.videoFiles},sourceId:t?.sourceId||""}}})},13186(e,t,a){"use strict";a.d(t,{},{P:"#0078D4"})},49371(e,t,a){"use strict";var r=a(72627);function i(e=(0,r.$t)()){return/^python-requests|^CriteoBot|^ias-|GrapeshotCrawler/.test(e)}function o(e=(0,r.$t)()){if(!e)return!1;let t=(0,r.iA)(),a=t&&t.includes("reqsrc=vp");return -1!==e.indexOf("Yahoo")||-1!==e.indexOf("Yandex")||-1!==e.indexOf("Baiduspider")||-1!==e.indexOf("Bingbot")||-1!==e.indexOf("Googlebot")||-1!==e.indexOf("Google-InspectionTool")||-1!==e.indexOf("msnbot")||!a&&-1!==e.indexOf("HeadlessChrome")}a.d(t,{e3:()=>o,fR:()=>i})},85007(e,t,a){"use strict";function r(e){return e.flatMap(e=>[e,e?.metadata])}function i(e,t){return{cardContent:{...e,id:function(...e){let t=r(e);return t.find(e=>e?.recoItemId)?.recoItemId??t.find(e=>e?.recoId)?.recoId??t.find(e=>e?.id)?.id}(t,e)},cardMetadata:{...t,category:"casualgames"},telemetryName:!function(...e){return r(e).some(e=>"8"===String(e?.badgeType))}(t,e)?void 0:"RandomGameExploration"}}a.d(t,{Y2:()=>i})},86203(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11.14 2.53a1.5 1.5 0 00-2.28 0l-6.62 7.8A1 1 0 003 11.98h3V17a1 1 0 001 1h6a1 1 0 001-1v-5.02h3a1 1 0 00.76-1.65l-6.62-7.8z"></path></svg>'},48493(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.86 2.53c.6-.7 1.68-.7 2.28 0l6.62 7.8a1 1 0 01-.76 1.65h-3V17a1 1 0 01-1 1H7a1 1 0 01-1-1v-5.02H3a1 1 0 01-.76-1.65l6.62-7.8zm1.52.65a.5.5 0 00-.76 0L3 10.98h3.5c.28 0 .5.23.5.5V17h6v-5.52c0-.27.22-.5.5-.5H17l-6.62-7.8z"></path></svg>'},9723(e,t,a){"use strict";var r=a(59669),i=a(63033);let o=(0,r.A)`
.ad-choice{filter:var(--filter-color)}`,s=(0,r.A)`
:host{--filter-color:invert(99%) sepia(10%) saturate(0%) hue-rotate(244deg) brightness(120%) contrast(100%)}.ad-choice{align-items:center;display:flex;width:12px;z-index:${"1"}}@media (forced-colors:active){.ad-choice{filter:invert(1) !important}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice{filter:var(--filter-color) !important}}`.withBehaviors(new i.N(null,o));a.d(t,{},{B:s})},27742(e,t,a){"use strict";var r=a(59669),i=a(4126);let o=(0,r.A)`
:is(.ad-label,[data-native-label]){font-size:12px;border:unset;padding:unset}`,s=(0,r.A)`
:is(.ad-label,[data-native-label]){align-items:center;border-radius:4px;border:0.5px solid var(--color-neutral-stroke-1,var(--neutral-foreground-rest));color:inherit;display:flex;font-size:11px;padding:0 4px 1px 4px;text-decoration:none;z-index:${"1"}}a[no-border]{border:unset;padding:unset;display:inline-flex}.dsa:hover{text-decoration:underline}`.withBehaviors(new i.o("ruby",!0,o));a.d(t,{},{E:s})},75003(e,t,a){"use strict";var r=a(37180),i=a(72526),o=a(46439),s=a(38380);let n=i.L.compose({name:`${r.c.prefix}-card`,template:s.v,styles:o.R});a.d(t,{},{m:n})},72526(e,t,a){"use strict";var r=a(56911),i=a(96193),o=a(33045),s=a(47429),n=a(60815),l=a(38493),d=a(95239),c=a(31023),p=a(69809),u=a(5291),h=a(99758);class g extends i.z{cardFillColorChanged(e,t){if(t){let e=(0,o.Hs)(t);null!==e&&(this.neutralPaletteSource=t,d.p.setValueFor(this,u.q.create(e.r,e.g,e.b)))}}neutralPaletteSourceChanged(e,t){if(t){let e=(0,o.Hs)(t),a=u.q.create(e.r,e.g,e.b);c.r.setValueFor(this,h.p.create(a))}}handleChange(e,t){this.cardFillColor||d.p.setValueFor(this,e=>e(p.M3).evaluate(e,e(d.p)))}connectedCallback(){super.connectedCallback();let e=(0,s.Zo)(this);if(e){let t=n.cP.getNotifier(e);t.subscribe(this,"fillColor"),t.subscribe(this,"neutralPalette"),this.handleChange(e,"fillColor")}}}(0,r.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,r.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0),a.d(t,{L:()=>g})},38380(e,t,a){"use strict";let r=(0,a(25717).T)();a.d(t,{},{v:r})},69329(e,t,a){"use strict";a.d(t,{m:()=>v});var r=a(75261);class i extends r.t{}var o=a(37180),s=a(59669),n=a(64187),l=a(22131),d=a(50882),c=a(48196),p=a(83252),u=a(64835),h=a(6032);let g=(0,s.A)` ${(0,n.V)("flex")} :host{align-items:center;outline:none;height:calc(${c.D} * 1px);width:calc(${c.D} * 1px);margin:calc(${c.D} * 1px) 0}.progress{height:100%;width:100%}.background{stroke:${p.F7};fill:none;stroke-width:2px}.determinate{stroke:${u.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out}.indeterminate-indicator-1{stroke:${u.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out;animation:spin-infinite 2s linear infinite}:host([paused]) .indeterminate-indicator-1{animation-play-state:paused;stroke:${p.F7}}:host([paused]) .determinate{stroke:${h.c}}@keyframes spin-infinite{0%{stroke-dasharray:0.01px 43.97px;transform:rotate(0deg)}50%{stroke-dasharray:21.99px 21.99px;transform:rotate(450deg)}100%{stroke-dasharray:0.01px 43.97px;transform:rotate(1080deg)}}`.withBehaviors((0,l.mr)((0,s.A)` .indeterminate-indicator-1,.determinate{stroke:${d.A.FieldText}}.background{stroke:${d.A.Field}}:host([paused]) .indeterminate-indicator-1{stroke:${d.A.Field}}:host([paused]) .determinate{stroke:${d.A.GrayText}}`));var m=a(89757),y=a(69259),C=a(18893);let f=function(e={}){return(0,m.qy)`
        <template
            role="progressbar"
            aria-valuenow="${e=>e.value}"
            aria-valuemin="${e=>e.min}"
            aria-valuemax="${e=>e.max}"
        >
            ${(0,y.z)(e=>"number"==typeof e.value,(0,m.qy)`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${e=>`${44*e.percentComplete/100}px 44px`}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,(0,m.qy)`
                    <slot name="indeterminate">
                        ${(0,C.R)(e.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:(0,m.qy)`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),v=i.compose({name:`${o.c.prefix}-progress-ring`,template:f,styles:g})},25717(e,t,a){"use strict";var r=a(89757);function i(){return(0,r.qy)`
        <slot></slot>
    `}a.d(t,{T:()=>i})},75261(e,t,a){"use strict";var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){let e="number"==typeof this.min?this.min:0,t="number"==typeof this.max?this.max:100,a="number"==typeof this.value?this.value:0,r=t-e;this.percentComplete=0===r?0:Math.fround((a-e)/r*100)}}(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Object)],n.prototype,"value",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"min",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"max",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],n.prototype,"paused",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Number)],n.prototype,"percentComplete",void 0),a.d(t,{t:()=>n})},34054(e,t,a){"use strict";var r=a(15420);a.d(t,{},{A:function(e,t,a){var i=e.length;return a=void 0===a?i:a,!t&&a>=i?e:(0,r.A)(e,t,a)}})},82393(e,t,a){"use strict";a.d(t,{A:()=>B});var r,i=a(6574),o=(r={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},function(e){return null==r?void 0:r[e]}),s=a(57842),n=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,l=RegExp("[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]","g"),d=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,c=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,p="\\ud800-\\udfff",u="\\u2700-\\u27bf",h="a-z\\xdf-\\xf6\\xf8-\\xff",g="A-Z\\xc0-\\xd6\\xd8-\\xde",m="\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",y="['’]",C="["+m+"]",f="["+h+"]",v="[^"+p+m+"\\d+"+u+h+g+"]",b="(?:\\ud83c[\\udde6-\\uddff]){2}",x="[\\ud800-\\udbff][\\udc00-\\udfff]",_="["+g+"]",w="(?:"+f+"|"+v+")",S="(?:"+_+"|"+v+")",$="(?:"+y+"(?:d|ll|m|re|s|t|ve))?",A="(?:"+y+"(?:D|LL|M|RE|S|T|VE))?",I="(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?",k="[\\ufe0e\\ufe0f]?",P="(?:\\u200d(?:"+["[^"+p+"]",b,x].join("|")+")"+k+I+")*",T="(?:"+["["+u+"]",b,x].join("|")+")"+(k+I+P),D=RegExp([_+"?"+f+"+"+$+"(?="+[C,_,"$"].join("|")+")",S+"+"+A+"(?="+[C,_+w,"$"].join("|")+")",_+"?"+w+"+"+$,_+"+"+A,"\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])|\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])|\\d+",T].join("|"),"g");let R=function(e,t,a){if(e=(0,s.A)(e),void 0===(t=a?void 0:t)){var r;return(r=e,c.test(r))?e.match(D)||[]:e.match(d)||[]}return e.match(t)||[]};var M=RegExp("['’]","g");let B=function(e){return function(t){var a;return(0,i.A)(R((a=t,(a=(0,s.A)(a))&&a.replace(n,o).replace(l,"")).replace(M,"")),e,"")}}},16670(e,t,a){"use strict";var r=RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");a.d(t,{},{A:function(e){return r.test(e)}})},29952(e,t,a){"use strict";a.d(t,{A:()=>g});var r=a(16670),i="\\ud800-\\udfff",o="[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",s="\\ud83c[\\udffb-\\udfff]",n="[^"+i+"]",l="(?:\\ud83c[\\udde6-\\uddff]){2}",d="[\\ud800-\\udbff][\\udc00-\\udfff]",c="(?:"+o+"|"+s+")?",p="[\\ufe0e\\ufe0f]?",u="(?:\\u200d(?:"+[n,l,d].join("|")+")"+p+c+")*",h=RegExp(s+"(?="+s+")|"+("(?:"+[n+o+"?",o,l,d,"["+i+"]"].join("|"))+")"+(p+c+u),"g");let g=function(e){return(0,r.A)(e)?e.match(h)||[]:e.split("")}},96883(e,t,a){"use strict";a.d(t,{A:()=>o});var r=a(57842),i=a(33610);let o=(0,a(82393).A)(function(e,t,a){var o;return t=t.toLowerCase(),e+(a?(o=t,(0,i.A)((0,r.A)(o).toLowerCase())):t)})},33610(e,t,a){"use strict";a.d(t,{A:()=>n});var r=a(34054),i=a(16670),o=a(29952),s=a(57842);let n=function(e){e=(0,s.A)(e);var t=(0,i.A)(e)?(0,o.A)(e):void 0,a=t?t[0]:e.charAt(0),n=t?(0,r.A)(t,1).join(""):e.slice(1);return a.toUpperCase()+n}},12165(e,t,a){"use strict";a.d(t,{Id:()=>x});var r=a(56911),i=a(92011),o=a(38493);class s extends i.L{constructor(){super(...arguments),this.appearance="primary"}}(0,r.Cg)([o.CF],s.prototype,"appearance",void 0),(0,r.Cg)([(0,o.CF)({attribute:"fill"})],s.prototype,"fill",void 0),(0,r.Cg)([(0,o.CF)({attribute:"color"})],s.prototype,"color",void 0),(0,r.Cg)([o.CF],s.prototype,"download",void 0),(0,r.Cg)([o.CF],s.prototype,"href",void 0),(0,r.Cg)([o.CF],s.prototype,"hreflang",void 0),(0,r.Cg)([o.CF],s.prototype,"ping",void 0),(0,r.Cg)([o.CF],s.prototype,"referrerpolicy",void 0),(0,r.Cg)([o.CF],s.prototype,"rel",void 0),(0,r.Cg)([o.CF],s.prototype,"target",void 0),(0,r.Cg)([o.CF],s.prototype,"type",void 0);var n=a(89757);let l=(0,n.qy)`<a class="control" part="control" download="${e=>e.download}" href="${e=>e.href}" hreflang="${e=>e.hreflang}" ping="${e=>e.ping}" referrerpolicy="${e=>e.referrerpolicy}" rel="${e=>e.rel}" target="${e=>e.target}" type="${e=>e.type}" style="${e=>e.fill&&e.color?`background-color: var(--ad-label-fill-${e.fill}); color: var(--ad-label-color-${e.color})`:void 0}"><slot></slot></a>`;var d=a(59669),c=a(64187),p=a(73477),u=a(22131),h=a(7896),g=a(62047),m=a(57416),y=a(26920),C=a(47810),f=a(14996);let v=(0,d.A)` ${(0,c.V)("inline-block")} :host{box-sizing:border-box;font-family:${h.O};font-size:${g.t};font-weight:400;${""} z-index:4}.control{text-align:center;border-radius:calc(${m.Pb} * 1px);padding:0 6px;min-width:24px;text-decoration:none;height:16px;border:calc(${y.XA} * 1px) solid ${C.l};color:${C.l}}.control:${p.N}{outline:none;border:calc(${y.XA} * 1px) solid ${f.WN}}`.withBehaviors((0,u.mr)((0,d.A)` :host{forced-color-adjust:auto}`));var b=a(651);let x=s.compose({name:`${b.i.prefix}-ad-label`,template:l,styles:v,shadowOptions:{delegatesFocus:!0}})},36880(e,t,a){"use strict";var r=a(92011);class i extends r.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}a.d(t,{m:()=>i})},58757(e,t,a){"use strict";a.d(t,{Af:()=>C});var r=a(36880),i=a(89757),o=a(60402);let s=(0,i.qy)`<span part="image" ${(0,o.K)("imageContainer")}><slot name="image" ${(0,o.K)("image")} @slotchange=${e=>e.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var n=a(59669),l=a(64187),d=a(22131),c=a(7896),p=a(61138),u=a(6032),h=a(74838),g=a(50882);let m=(0,n.A)` ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};font-size:${p.k};font-weight:400;line-height:${p.F};align-items:center;color:${u.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${h.vR} * 2px)}`.withBehaviors((0,d.mr)((0,n.A)` :host,.content{color:${g.A.CanvasText};fill:currentcolor}`));var y=a(651);let C=r.m.compose({name:`${y.i.prefix}-attribution`,template:s,styles:m})},51122(e,t,a){"use strict";var r,i,o=a(56911),s=a(92011),n=a(38493),l=a(60815),d=a(93856);(r=i||(i={})).default="default",r.condensed="condensed",r.infoPane="infoPane",r.infoPane1x3y="infoPane1x3y",r.infoPaneSplitVertical="infoPaneSplitVertical",r.infoPaneSplitHorizontal="infoPaneSplitHorizontal";class c extends s.L{constructor(){super(...arguments),this.layout=i.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(e){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(e):(this.$emit("link-invoked",e),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(e=>e instanceof d.L)}setExpanded(e){this.filteredContentIndicator().forEach(t=>t.expanded=e)}}(0,o.Cg)([n.CF],c.prototype,"layout",void 0),(0,o.Cg)([(0,n.CF)({attribute:"heading-level",mode:"fromView",converter:n.R$})],c.prototype,"headinglevel",void 0),(0,o.Cg)([(0,n.CF)({mode:"fromView"})],c.prototype,"href",void 0),(0,o.Cg)([l.sH],c.prototype,"isGrid",void 0),(0,o.Cg)([l.sH],c.prototype,"anchorTelemetryTag",void 0),(0,o.Cg)([l.sH],c.prototype,"mediaNodes",void 0),(0,o.Cg)([l.sH],c.prototype,"hasAbstract",void 0),(0,o.Cg)([l.sH],c.prototype,"abstract",void 0),(0,o.Cg)([l.sH],c.prototype,"iconSlottedNodes",void 0),(0,o.Cg)([(0,n.CF)({attribute:"image-priority",mode:"boolean"})],c.prototype,"imagePriority",void 0),(0,o.Cg)([n.CF],c.prototype,"target",void 0),(0,o.Cg)([l.sH],c.prototype,"hoverActionsSlottedNodes",void 0),(0,o.Cg)([l.sH],c.prototype,"handleContentCardClickOverride",void 0),(0,o.Cg)([l.sH],c.prototype,"contentIndicatorNodes",void 0),a.d(t,{S:()=>i,m:()=>c})},55461(e,t,a){"use strict";a.d(t,{yr:()=>E});var r=a(51122),i=a(89757),o=a(60402),s=a(69259),n=a(416),l=a(10108),d=a(82774),c=a(33744);let p=(0,a(69326).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),u=(0,i.qy)`<div class="footer ${e=>e.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,o.K)("startActionsContainer")}><slot name="start-actions" ${(0,o.K)("startActions")} @slotchange=${e=>e.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,o.K)("endActionsContainer")}><slot name="end-actions" ${(0,o.K)("endActions")} @slotchange=${e=>e.handleEndActionsContentChange()}></slot></span></div>`,h=(0,i.qy)`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,m=(0,i.qy)`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${e=>(e.title&&e.title.match(g)?.[0])??"Earn cash back"}</span></div>`,y=(e,t)=>(0,i.qy)`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${t}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${e.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${e}</span></div>`,C=(0,i.qy)`<div style="display: flex;">${e=>e.id.includes("__")?(0,i.qy)` ${(0,s.z)(e=>e.id.includes("_Christmas"),y("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,s.z)(e=>e.id.includes("_BlackFriday"),y("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,s.z)(e=>e.id.includes("_CyberMonday"),y("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:(0,i.qy)` ${(0,s.z)(e=>e&&!e.id.includes("_NoCashback"),m)} ${(0,s.z)(e=>e,h)} `}</div>`,f=(0,i.qy)`<div style="background: no-repeat center url('${e=>e.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,v=(0,i.qy)`<div class="logo-container"><img src=${p} alt="Microsoft Logo" aria-hidden="true" /></div>`,b=(0,i.qy)`<template ${(0,n.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${e=>e.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,s.z)(e=>e.id.includes("contentcard_tripleCashback"),v)} ${(0,s.z)(e=>e.id.includes("contentcard_edgeReclaim"),v)} ${(0,s.z)(e=>e.id.includes("contentcard_InfoBuyDirectCard"),f)}<slot name="background-image" ${(0,o.K)("backgroundImage")}></slot></span>${(0,s.z)(e=>e.id.includes("BuyDirectCard"),C)}<div class="mask" part="mask"></div><div class="body ${e=>e.hasAbstract?"has-abstract":""} ${e=>e.isGrid?"grid":""}" part="body">${(0,s.z)(e=>e?.mediaNodes?.length>0,(0,i.qy)`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,o.K)("mediaContainer")}><slot name="media" ${(0,o.K)("media")} @slotchange=${e=>e.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,o.K)("iconContainer")} class="${e=>e.iconSlottedNodes&&e.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,o.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,s.z)(e=>e?.mediaNodes?.length===0,(0,i.qy)`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${e=>e.headinglevel} name="heading"><a class="heading" part="heading" href=${e=>e.href?e.href:void 0} target=${e=>e.target?e.target:void 0} @click=${(e,t)=>e.handleContentCardLinkClick(t.event)} data-t="${e=>e.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,s.z)(e=>e.layout!==r.S.default,u)}</div>${(0,s.z)(e=>e.layout===r.S.default,u)}<span part="hover-actions" class="${e=>e.hoverActionsSlottedNodes&&e.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var x=a(64187),_=a(73477),w=a(22131),S=a(59669),$=a(50882),A=a(7896),I=a(61138),k=a(6032),P=a(41123),T=a(47810),D=a(89580),R=a(95239),M=a(86856);let B=(0,S.A)` :host([layout="default"]) .media-wrapper{float:right}`,L=(0,S.A)` :host([layout="default"]) .media-wrapper{float:left}`,O=(0,S.A)` ${(0,x.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${A.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${I.k});line-height:var(--footer-line-height,${I.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${k.c};fill:${k.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${P.K});line-height:var(--abstract-line-height,${P.Z});font-weight:400;grid-column:span 2;box-sizing:content-box;color:${k.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${k.c};fill:${k.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${T.l};font-size:var(--heading-font-size,${D.Y});line-height:var(--heading-line-height,${D.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${_.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${R.p};box-shadow:0px -25px 15px ${R.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${T.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${T.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${R.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${R.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new M.t(B,L),(0,w.mr)((0,S.A)` .heading{color:${$.A.LinkText};background:${$.A.ButtonFace}}.abstract{color:${$.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${$.A.ButtonText};background:${$.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${$.A.ButtonFace};color:${$.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${$.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${$.A.ButtonFace}}`));var F=a(651);let E=r.m.compose({name:`${F.i.prefix}-content-card`,template:b,styles:O,shadowOptions:{delegatesFocus:!0}})},93856(e,t,a){"use strict";var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,r.Cg)([(0,o.CF)({mode:"boolean"})],n.prototype,"expanded",void 0),(0,r.Cg)([s.sH],n.prototype,"defaultItems",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean",attribute:"animate"})],n.prototype,"shouldanimate",void 0),a.d(t,{L:()=>n})},97964(e,t,a){"use strict";a.d(t,{rX:()=>_});var r=a(93856),i=a(89757),o=a(82774);let s=(0,i.qy)`<span class="icon-container" part="icon-container" aria-hidden="true"><slot name="icon"></slot></span><span class="label-container" part="label-container"><span class="label" part="label"><slot ${(0,o.e)({property:"defaultItems",filter:e=>e instanceof HTMLElement&&null!==e.offsetParent||e instanceof Text&&!!e.textContent?.trim().length})}></slot></span></span>`;var n=a(7896),l=a(61138),d=a(86856),c=a(57416),p=a(64187),u=a(22131),h=a(59669),g=a(63033),m=a(50882);let y=(0,h.A)` :host::after{transform:translateX(-100%) translateX(20px)}:host([animate]) .label{transform:translateX(-100%)}`,C=(0,h.A)` :host::after{transform:translateX(100%) translateX(-20px)}:host([animate]) .label{transform:translateX(100%)}`,f=(0,h.A)` :host{color:#000}:host::after{background:rgba(255,255,255,0.46)}`,v=(0,h.A)` :host{color:#fff}:host::after{background:rgba(0,0,0,0.54)}`,b=(0,h.A)` ${(0,p.V)("inline-flex")} :host{align-items:center;box-sizing:border-box;contain:content;overflow:hidden}.label-container{overflow:hidden}:host,:host::after{${""} border-radius:4px}:host::after{content:"";height:100%;position:absolute;width:100%;z-index:-1}.icon-container,.label{min-height:20px;min-width:20px;display:flex;align-items:center;justify-content:center;fill:currentcolor}:host([animate])::after,.label{transition:transform 250ms cubic-bezier(0.17,0.17,0,1)}.label{font-family:${n.O};font-size:${l.k};font-weight:600;line-height:${l.F};text-overflow:ellipsis;padding:0 4px}:host([expanded][animate])::after,:host([expanded][animate]) .label{transform:translateX(0%)}.label{transform:translateX(-100%)}::slotted([slot="icon"]){display:block;fill:currentcolor}`.withBehaviors(new d.t(y,C),new g.N(f,v),(0,u.mr)((0,h.A)` :host{forced-color-adjust:auto}::slotted([slot="icon"]){color:${m.A.ButtonText};fill:currentcolor}.icon-container,:host([expanded][animate]) .label,:host::after{background:${m.A.ButtonFace};color:${m.A.ButtonText};fill:currentcolor;border-radius:calc(${c.Pb} * 10px)}.label{background:transparent}`));var x=a(651);let _=r.L.compose({name:`${x.i.prefix}-content-indicator`,template:s,styles:b})},42320(e,t,a){"use strict";a.d(t,{Ob:()=>x});var r=a(94020),i=a(89757),o=a(82774),s=a(69259);let n=(0,i.qy)`<template><slot ${(0,o.e)({property:"items",filter:e=>e instanceof HTMLElement&&null!==e.offsetParent})}></slot>${(0,s.z)(e=>e.layout===r.Y.list,(0,i.qy)` <span class="topic">${e=>e.topic}</span> `)} ${e=>e.dividerTemplate}</template>`;var l=a(7896),d=a(41123),c=a(47810),p=a(95239),u=a(89580),h=a(86856),g=a(59669),m=a(64187),y=a(22131);let C=(0,g.A)` :host([layout="double"]) .divider-1{left:0}:host([layout="triple"]) .divider-1{left:0}:host([layout="triple"]) .divider-2{left:0}:host([layout="mosaic"]) .divider-1{left:0}:host([layout="mosaic"]) .divider-2{left:1px}`,f=(0,g.A)` :host([layout="double"]) .divider-1{right:0}:host([layout="triple"]) .divider-1{right:0}:host([layout="triple"]) .divider-2{right:0}:host([layout="mosaic"]) .divider-1{right:0}:host([layout="mosaic"]) .divider-2{right:1px}`,v=(0,g.A)` ${(0,m.V)("grid")} :host{box-sizing:border-box;font-family:${l.O};font-size:${d.K};line-height:${d.Z};color:${c.l};height:100%;width:100%;position:relative}:host([layout="single"]){grid-template-columns:1fr}:host([layout="double"]){grid-template-columns:1fr 1fr}:host([layout="split"]){grid-template-rows:1fr 1fr}:host([layout="triple"]){grid-template-columns:1fr 1fr 1fr}:host([layout="mosaic"]){grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}:host([layout="mosaic"]) ::slotted(:first-child){grid-row:1 / span 2;grid-column:1}:host([layout="mosaic"]) ::slotted(msft-content-card:not(:first-child)){--mask-gradient:linear-gradient(rgba(0,0,0,0),${p.p})}:host([layout="list"]){grid-template-rows:auto 1fr 1fr 1fr;grid-template-columns:3fr 2fr}:host([layout="list"]) ::slotted(:first-child){grid-row:1 / span 4;grid-column:1}:host([layout="list"]) ::slotted(msft-content-card:not(:first-child)){background:${p.p};--heading-font-size:${d.K};--heading-line-height:${d.Z}}.topic{grid-row:1;grid-column:2;font-size:${u.Y};line-height:${u.v};background:${p.p};padding:6px 12px}.divider{background:rgba(255,255,255,0.4);position:absolute;left:20px;right:20px;top:20px;bottom:20px;z-index:1;pointer-events:none;opacity:0}:host([layout="double"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="split"]) .divider-1{grid-row:2;height:1px;top:0;opacity:1}:host([layout="triple"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="triple"]) .divider-2{grid-column:3;width:1px;opacity:1}:host([layout="mosaic"]) .divider-1{grid-column:2;grid-row:1 / span 2;width:1px;opacity:1}:host([layout="mosaic"]) .divider-2{grid-column:2;grid-row:2;height:1px;top:0;opacity:1}`.withBehaviors(new h.t(C,f),(0,y.mr)((0,g.A)` .divider{background:none}`));var b=a(651);let x=r.s.compose({name:`${b.i.prefix}-info-pane-slide`,template:n,styles:v})},94020(e,t,a){"use strict";var r,i,o=a(56911),s=a(89757),n=a(92011),l=a(60815),d=a(38493);(r=i||(i={})).single="single",r.double="double",r.split="split",r.triple="triple",r.mosaic="mosaic",r.list="list";let c=new Map;class p extends n.L{constructor(){super(...arguments),this.dividerTemplate=null,this.layout=i.single}itemsChanged(e,t){this.$fastController.isConnected&&(this.dividerTemplate=function(e){if(c.has(e))return c.get(e);if(e<1)return c.set(e,null),null;let t=Array(e).fill("").map((e,t)=>(0,s.qy)`<div class="divider divider-${t+1}" part="divider"></div>`).reduce((e,t)=>(0,s.qy)`${e}${t}`);return c.set(e,t),t}(this.items.length-1))}}(0,o.Cg)([l.sH],p.prototype,"items",void 0),(0,o.Cg)([l.sH],p.prototype,"dividerTemplate",void 0),(0,o.Cg)([d.CF],p.prototype,"layout",void 0),(0,o.Cg)([d.CF],p.prototype,"topic",void 0),a.d(t,{Y:()=>i,s:()=>p})},47131(e,t,a){"use strict";a.d(t,{Bb:()=>I});var r=a(56911),i=a(92011),o=a(38493),s=a(60815);class n extends i.L{moneyCardContentDataChanged(){"Default"!==this.cardStyle&&void 0===this.moneyCardContentData.actionAppearance&&(this.moneyCardContentData.actionAppearance="outline")}getQuoteColor(e,t,a,r,i){return t?i:this.moneyCardContentData.swapGainLossColor?e?a:r:e?r:a}changeShowingValue(){this.showChangeValue=!this.showChangeValue}connectedCallback(){super.connectedCallback(),this.showChangeValue=!1}}(0,r.Cg)([(0,o.CF)({attribute:"layout"})],n.prototype,"layout",void 0),(0,r.Cg)([o.CF],n.prototype,"cardStyle",void 0),(0,r.Cg)([o.CF],n.prototype,"target",void 0),(0,r.Cg)([s.sH],n.prototype,"moneyCardContentData",void 0),(0,r.Cg)([s.sH],n.prototype,"quoteItems",void 0),(0,r.Cg)([s.sH],n.prototype,"showChangeValue",void 0),(0,r.Cg)([s.sH],n.prototype,"headerTelemetryTag",void 0),(0,r.Cg)([s.sH],n.prototype,"switchValueTelemetryTag",void 0),(0,r.Cg)([s.sH],n.prototype,"seeMoreTelemetryTag",void 0);var l=a(89757),d=a(69259),c=a(68835);let p=(0,l.qy)`<a class="quote-row" part="quote-row" href="${e=>e.quoteHref}" target=${(e,t)=>t.parent.target} aria-label="${e=>e.displayName} ${e=>e.symbol} ${e=>e.price} ${e=>e.changePcnt}" data-t="${e=>e.telemetryTag}"><div class="quote-view" part="quote-view"><div class="quote-title-container" part="quote-title-container"><span class="quote-title" part="quote-title"><p class="quote-title-content" part="quote-title-content" title="${e=>e.displayName} (${e=>e.symbol})">${e=>e.symbol}</p></span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str" title="${e=>e.displayName} (${e=>e.symbol})">${e=>e.displayName}</p></span></div><div class="quote-title-container" part="quote-title-container"><div class="price" part="price"><span class="price-str" part="price-str">${e=>e.price}</span></div></div><button class="change-values ${(e,t)=>t.parent.getQuoteColor(e.gain,e.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(e,t)=>t.parent.getQuoteColor(e.gain,e.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(e,t)=>t.parent.changeShowingValue()}" aria-label="${(e,t)=>t.parent.showChangeValue?`${e.changeValue} ${e.displayName} ${e.changePcnt}`:`${e.changePcnt} ${e.displayName} ${e.changeValue}`}" data-t="${(e,t)=>t.parent.switchValueTelemetryTag}">${(0,d.z)((e,t)=>t.parent.showChangeValue,(0,l.qy)`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${e=>e.changeValue}</span></span>`)} ${(0,d.z)((e,t)=>!t.parent.showChangeValue,(0,l.qy)`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${e=>e.changePcnt}&lrm;</span></span>`)}</button></div></a>`,u=(0,l.qy)`<msft-structured-data-card target=${e=>e.target} :headerTelemetryTag=${e=>e.headerTelemetryTag} :seeMoreTelemetryTag=${e=>e.seeMoreTelemetryTag} :data=${e=>e.moneyCardContentData}><slot name="more-actions" slot="more-actions"></slot><slot name="pin" slot="pin"></slot><slot name="title-icon" slot="title-icon"></slot><div class="quote-list" part="quote-list">${(0,c.ux)(e=>e.quoteItems,p)}</div><slot name="footer-start" slot="footer-start"></slot><slot name="footer-end" slot="footer-end"></slot></msft-structured-data-card>`;var h=a(47810),g=a(89580),m=a(41123),y=a(6032),C=a(61138),f=a(95403),v=a(14996),b=a(26920),x=a(59669),_=a(64187),w=a(22131),S=a(50882);let $=(0,x.A)` ${(0,_.V)("flex")} :host{height:100%;--quote-grid-columns:111px 81px 56px}:host(:focus){outline:none}msft-structured-data-card::part(title-link)::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}.price-str{color:${h.l};font-weight:600;text-align:end;width:100%;font-size:var(--price-content-font-size,${g.Y});line-height:var(--price-content-line-height,${g.v})}.quote-list{margin-top:var(--quote-list-margin-top,12px);display:grid;grid-template-rows:var(--quote-list-grid-rows,repeat(auto-fill,52px));row-gap:var(--quote-list-grid-gap,2px);z-index:1}.quote-title-content{color:${h.l};font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0;font-size:var(--quote-title-font-size,${m.K});line-height:var(--quote-title-line-height,${m.Z})}.sec-title-str{color:${y.c};margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:${C.k};line-height:${C.F}}.quote-row{cursor:pointer;text-decoration:none;padding:var(--quote-row-padding,8px 8px);margin:var(--quote-row-margin,0px 8px)}.quote-row:hover{background:${f.oO}}.change-values{height:24px;font-family:var(--body-font);border-radius:4px;border:0;padding:0;cursor:pointer;outline:none}.change-values:focus-visible{outline-color:${v.WN};outline-width:2px;outline-style:auto}.change-button-area{display:flex;flex-direction:column;justify-content:flex-end}.change-values-percentage{margin-top:4px;margin-bottom:4px;margin-inline-end:8px;display:block;font-size:${C.k};font-weight:600;line-height:${C.F};text-align:end}.price{align-items:center;display:flex}.quote-title-container{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:var(--quote-grid-columns)}.quote-green{color:#ffffff;background:#107c10}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}`.withBehaviors((0,w.mr)((0,x.A)` :host{forced-color-adjust:auto}.title-link:hover{text-decoration:underline}.change-values,.quote-row:hover{forced-color-adjust:none;background:${S.A.ButtonFace};box-shadow:0 0 0 calc((${b.vd} - ${b.XA}) * 1px) ${S.A.LinkText};color:${S.A.ButtonText}}::slotted(*[slot="option-button"]){fill:${S.A.ButtonText}}::slotted([slot="option-button"]:hover){background:${S.A.Highlight};fill:${S.A.HighlightText}}.change-values:focus-visible{outline-color:${S.A.Highlight}}`));var A=a(651);let I=n.compose({name:`${A.i.prefix}-show-quotes-money-card`,template:u,styles:$})},46439(e,t,a){"use strict";var r=a(59669),i=a(64187),o=a(22131),s=a(50882),n=a(37998),l=a(95239),d=a(47810),c=a(57416);let p=(0,r.A)` ${(0,i.V)("block")} :host{--elevation:4;display:block;contain:content;height:var(--card-height,100%);width:var(--card-width,100%);box-sizing:border-box;background:${l.p};color:${d.l};border-radius:calc(${c.JU} * 1px);${n.ET}}:host(:hover){--elevation:8}:host(:focus-within){--elevation:8}:host{content-visibility:auto}`.withBehaviors((0,o.mr)((0,r.A)` :host{forced-color-adjust:none;background:${s.A.Canvas};box-shadow:0 0 0 1px ${s.A.CanvasText}}`));a.d(t,{},{R:p})}}]);