"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_video-card-wc_dist_components_PlutoTvPlayerElement_js"],{60630(e,l,t){t.d(l,{PlutoTvPlayerElement(){return c}});var s=t(56911),o=t(59669),r=t(89757),a=t(92011);const n=o.A`
.plutoTV_root > iframe{
    border: none;
    height: 70vh;
    min-height: 720px;
    width: 100%;
}`,i=r.qy`
<div class="plutoTV_root" data-t="${e=>e.videoCardProps?.telemetryContext?.parentTelemetry?.getMetadataTag()}">
    <iframe class="plutotvplayer" scrolling="no" src="//msn.pluto.tv/" allowfullscreen="true" allow="autoplay; fullscreen"></iframe>
</div>`;let c=class extends a.L{};c=(0,s.Cg)([(0,a.E)({name:"pluto-tv-player",template:i,styles:n})],c)}}]);