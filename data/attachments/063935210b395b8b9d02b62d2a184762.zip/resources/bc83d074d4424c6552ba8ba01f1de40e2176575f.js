"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-cricket-v2"],{58142(e,t,r){r.d(t,{U(){return l}});var a=r(41432),i=r(11796),s=r(79811),o=r(32150),n=r(96950);class l extends i.Bc{constructor(){super(...arguments),this.getShowMatchCount=e=>e===a.uE._15u?3:1,this.getGameDate=e=>{const t=new Date,r=new Date(e);if(t.toDateString()===r.toDateString())return this.transformerProvider.strings.today;return r.toLocaleDateString(o.T3.CurrentMarket,{weekday:"short",day:"numeric",month:"long"})},this.getFirstScoreLine=e=>{if(e.yetToBat)return this.transformerProvider.strings?.yetToBat;if(e.notToBat)return this.transformerProvider.strings?.didNotBat;const t=e.inningsScore||[];return t.length>0?t[0]:""},this.getSecondScoreLine=(e,t,r)=>{const{inningsScore:a=[],overs:s,target:o,targetOver:n}=e;return t&&r===i.Xp.superover&&a.length>0?`${a[1]?a[1]:""} (SO)`:o&&n&&s&&a.length>0?`(${n}/${s}) T:${o}`:2===a.length?s?`${a[1]} (${s})`:a[1]:1===a.length&&s?`(${s})`:a.length>1?a[1]:""}}async transform(e){const t=await this.getViewModel(e);return{viewTemplate:n.qy`
                <sports-cricket-v2
                    :viewModel="${t}"
                ></sports-cricket-v2>`}}async getViewModel(e){const{cardSize:t}=e,r=this.getShowMatchCount(t),a=this.getMatchData(e,r),o={...e.telemetryConstants,name:i.BP.Game};return{cardSize:t,isRubySpotlight:e.isRubySpotlight,linkTarget:"_blank",matchData:a.matches,isDarkMode:(0,s.jJ)(),strings:{...this.transformerProvider.strings},telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,o),getFirstScoreLine:this.getFirstScoreLine,getSecondScoreLine:this.getSecondScoreLine}}getMatchData(e,t){const r=e.matchData?.map(e=>e?.sportsMatchData).slice(0,t)||[],a=e.followedSports||new Map,n=new Map,l=new Map,c=new Map;return r.forEach(e=>{if(e){const t=e.participantOne||{},r=e.participantTwo||{},n=(0,s.yn)(e.gameStartDateTime);e.gameStartTime=(e.gameStartDateTimeIsToBeAnnounced?null:(0,s.ry)(n,o.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA;const l="string"!=typeof e.gameState?(0,s.m5)(e.gameState.state):e.gameStateCatetory,p=e.gameState&&"string"!=typeof e.gameState?this.getDetailedGameStatus(e.gameState?.detailedGameState):e.detailedGameState;e.detailedGameState=p!==i.Xp.nonlive?p:l;let d="";d=p&&p!==i.Xp.nonlive?p:l===i.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:l,e.gameStateCatetory=l,e.gameState=d,t.imageUrl=this.getParticipantIconUrl(t.imageUrl||(0,s.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),r.imageUrl=this.getParticipantIconUrl(r.imageUrl||(0,s.iK)(r.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),t.gameCenterUrl&&(t.scheduleUrl=(0,s.Ot)(t.gameCenterUrl)),r.gameCenterUrl&&(r.scheduleUrl=(0,s.Ot)(r.gameCenterUrl)),e.gameCenterUrl&&!e.matchClickthroughUrl&&(e.matchClickthroughUrl=(0,s.Ot)(e.gameCenterUrl)),e.gameDate=this.getGameDate(n.toString()||""),e.gameStateCatetory=e.cricketGameCategory||e.gameStateCatetory,(0,s.gK)(t,a)&&c.set(t.satoriId,!0),(0,s.gK)(r,a)&&c.set(r.satoriId,!0)}}),{matches:r,scoreClassNameMap:n,matchSummaryMap:l,followedMap:c}}getParticipantIconUrl(e){return e?.replace(/w=([\d]*)?&h=([\d]*)?/,"w=72&h=72")}getDetailedGameStatus(e){switch(e){case"InProgressGame":case"InProgress":return i.Xp.inprogressGame;case"Drinks":return i.Xp.drinks;case"Dinner":return i.Xp.dinner;case"Tea":return i.Xp.tea;case"Lunch":return i.Xp.lunch;case"Fog":return i.Xp.fog;case"Innings":return i.Xp.innings;case"Stumps":return i.Xp.stumps;case"InningsBreak":return i.Xp.break;case"Toss":return i.Xp.toss;case"SuperOver":return i.Xp.superover;case"BadWeatherCondition":return i.Xp.BadWeatherCondition;case"PreGame":return i.Xp.preGame;case"Final":case"PostGame":return i.Xp.postGame;case"Delayed":return i.Xp.delayed;case"Abandoned":return i.Xp.abandoned;case"Postponed":return i.Xp.postponed;default:return i.Xp.nonlive}}}},83546(e,t,r){r.d(t,{h(){return i}});var a=r(53128);function i(){return(0,a.oh)()}},46467(e,t,r){r.r(t),r.d(t,{SportsCricketV2Transformer(){return d.U},SportsSpotlightCricketV2Transformer(){return p}});var a=r(41432),i=r(11796),s=r(87906),o=r(33335),n=r(32150),l=r(79811),c=r(96950);class p extends i.Bc{constructor(){super(...arguments),this.getCricketMetaData=e=>({cardSize:this.cardSize,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,leagueId:"",isRubySpotlight:!0,matchData:[{sportsMatchData:{...e.sportsSpotlightCricketData.match}}],followedSports:e.followedSports})}async transform(e){this.cardSize=e.cardSize,this.isInDarkMode=(0,l.jJ)();const t=await this.getCurrentViewModel(e);return{viewTemplate:c.qy`
                <sports-spotlight-cricket-v2
                    :viewModel="${t}"
                ></sports-spotlight-cricket-v2>
            `}}async getCurrentViewModel(e){try{if(!e.sportsSpotlightCricketData)return void(0,s.vV)(o.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,e);const{match:t,partnershipInfo:r,playerOfTheMatchInfo:c,recentMatches:p}=e.sportsSpotlightCricketData;((0,l.nD)(t)||(0,l.nD)(r)&&(0,l.nD)(c)&&(0,l.nD)(p))&&(0,s.vV)(o.Ax,"Spotlight Cricket data missing",`market=${n.T3.CurrentMarket}`,e);const d=this.getCricketMetaData(e),g=await this.transformerProvider.generateView(d,i.hi.SportsCricketV2);let h,m,u;return this.cardSize!==a.uE._05u&&(h=(0,l.nD)(r)?void 0:this.getPartnership(e),m=(0,l.nD)(c)?void 0:this.getPlayerOfMatch(e),u=(0,l.nD)(p)?void 0:this.getRecentMatches(e)),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,matchView:g?.viewTemplate,clickThroughUrl:(0,l.Ot)(t.gameCenterUrl),partnershipVM:h,playerOfTheMatchVM:m,recentMatchesVM:u,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsSpotlightCricketCard})}}catch(t){return void(0,s.vV)(o.Ax,"Error in transforming Spotlight Cricket data",`market=${n.T3.CurrentMarket}`,e)}}buildTestString(e,t,r){if(!e?.[t])return"";const a=e[t][0]?.[r],i=e[t][1]?.[r];return i?`${a} & ${i}`:a}getPOTMStatsTypeByRole(e){const{battingStatistics:t,bowlingStatistics:r,role:a}=e,{primaryRole:s}=a||{};return i.pA.batter===s||i.pA.wicketKeeper===s?i.pA.batter:i.pA.bowler===s?i.pA.bowler:t&&r?i.pA.allRounder:t?i.pA.batter:i.pA.bowler}getPOTMStatsByRole(e,t){const{battingStatistics:r,bowlingStatistics:a,statistics:s}=e,{runsText:o,cricketWicketsTaken:n,cricketStrikeRate:l,cricketEconomyRate:c}=this.transformerProvider.strings,p=this.getPOTMStatsTypeByRole(e);if(t===i.S_.test)switch(p){case i.pA.batter:return{left:{value:this.buildTestString(s,"batting","runsScored"),label:o}};case i.pA.bowler:return{left:{value:this.buildTestString(s,"bowling","bowlingSummary"),label:n}};default:return{left:{value:this.buildTestString(s,"batting","runsScored"),label:o},right:{value:this.buildTestString(s,"bowling","wicketsTaken"),label:n}}}switch(p){case i.pA.batter:return{left:{value:r?.runsScored??"",label:o},right:{value:r?.strikeRate??"",label:l}};case i.pA.bowler:return{left:{value:a?.wicketsTaken??"",label:n},right:{value:a?.economyRate??"",label:c}};default:return{left:{value:r?.runsScored??"",label:o},right:{value:a?.wicketsTaken??"",label:n}}}}getPlayerOfMatch(e){const{telemetryBuilder:t,strings:r}=this.transformerProvider,{playerOfTheMatchInfo:a,match:s}=e.sportsSpotlightCricketData,o=(0,l.iK)(a.teamImageId||s.fallbackImageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),c=a.imageId?(0,l.iK)(a.imageId||"",!1,this.transformerProvider.config.teamImageInfoBig):"",p=`${n.T3.StaticsUrl}latest/sports/background/cricket/copilot-player-backplate${this.isInDarkMode?"-dark":""}.svg`;return{stats:this.getPOTMStatsByRole(a,s.gameFormat),playerOfTheMatchInfo:a,imageUrl:c,teamImageUrl:o,backplateImgUrl:p,name:c||!a.shortName?a.name:a.shortName,strings:{playerOfTheMatchHeader:r.playerOfTheMatchHeader},telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsSpotlightCricketCard})}}getRecentMatches(e){const t=e.sportsSpotlightCricketData.recentMatches.map(e=>{const t={...e,teamImageUrl:e.teamImageId?(0,l.iK)(e.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo):null,matches:e.matches?.slice(0,5)},r=t.matches?.length;r&&(t.matches[r-1].isLatest=!0);const a=Boolean(r&&r<5);if(a){const e=a?5-r:0;t.matches.push(...Array(e).fill({teamName:"",teamImageId:"",summary:"-",gameStatus:"NoGame"}))}return t});return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,isRubySpotlight:!0,recentMatches:t,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsSpotlightCricketCard})}}getPartnership(e){const{telemetryBuilder:t,strings:r}=this.transformerProvider,{partnershipInfo:a,match:s}=e.sportsSpotlightCricketData,{batter1:o,batter2:n,runs:c,balls:p}=a;if(o&&n)return o.imageUrl=(0,l.iK)(o.imageId,!1,this.transformerProvider.config.teamImageInfoBig),n.imageUrl=(0,l.iK)(n.imageId,!1,this.transformerProvider.config.teamImageInfoBig),o.teamImageUrl=(0,l.iK)(o.teamImageId||s.fallbackImageId||"",!1,this.transformerProvider.config.suggestionImageInfo),{batter1:o,batter2:n,hasImages:Boolean(o.imageUrl&&n.imageUrl),teamScore:`${o.teamShortName} - ${c} (${p})`,strings:{currentPartnership:r.currentPartnership,runsText:r.runsText,cricketBalls:r.cricketBalls},telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsSpotlightCricketCard})}}}var d=r(58142);Promise.resolve().then(r.bind(r,96085)),Promise.resolve().then(r.bind(r,63800)),Promise.resolve().then(r.bind(r,82407)),Promise.resolve().then(r.bind(r,78314)),Promise.resolve().then(r.bind(r,7761))},82407(e,t,r){r.r(t),r.d(t,{PlayerOfMatchV2(){return $}});var a=r(56911),i=r(92011),s=r(74849),o=r(4126),n=r(63033);const l=s.A` @container (min-width:180px) and (max-width:240px){.wrap{.name{max-width:100px}&.has-img{.bg-cloud,.img-wrap{right:0}.stat-left{right:90px}.stat-right{right:5px;left:auto}}&.no-img{.stat-right{right:25px;left:auto}.stat-left{right:auto;left:25px}}}}@container (min-width:180px) and (max-width:233px){.wrap{.name{max-width:85px}}}@container (min-width:240px){.wrap{&.has-img{.stat-right{right:0;left:auto}}}}`,c=s.A` :host{--stats-bg-color:#101524;--stats-text-color:#828BAC}.wrap{color:#D7DEEF}`,p=s.A` :host{--stats-bg-color:#F8F4F2;--stats-text-color:#A85800;--bg-cloud-width:122px;--bg-cloud-height:102px}.wrap{display:flex;flex-direction:column;position:relative;height:128px;container-type:inline-size}.content{flex:1;display:flex;align-items:center}.title{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.name{font-size:17px;line-height:24px;font-weight:550;margin-bottom:4px;max-width:120px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis;overflow:hidden}.flag{width:20px;height:20px}.bg-cloud{position:absolute}.bg-cloud,.img-wrap{top:20px;right:32px}.bg-cloud,.bg-cloud svg{height:var(--bg-cloud-height);width:var(--bg-cloud-width)}.img-wrap{position:absolute;height:var(--bg-cloud-height);width:var(--bg-cloud-width);overflow:hidden;display:flex;align-items:flex-end;justify-content:center;clip-path:path("M49.3069 3.21045C79.8516 -4.40514 107.795 2.18406 111.72 17.9273C113.129 23.5793 111.25 29.6414 106.85 35.4442C105.006 37.8752 104.085 39.0907 104.31 39.9956C104.536 40.9006 105.92 41.541 108.689 42.822C115.3 45.8798 119.805 50.3506 121.215 56.0026C125.14 71.7459 103.56 90.6827 73.0154 98.2984C42.4707 105.914 14.5273 99.3248 10.602 83.5815C9.19295 77.9296 11.0716 71.8669 15.4716 66.0639C17.3149 63.6328 18.2366 62.4173 18.0109 61.5124C17.7853 60.6075 16.4009 59.967 13.632 58.6861C7.02234 55.6284 2.51684 51.158 1.10753 45.5062C-2.81779 29.7629 18.7621 10.8261 49.3069 3.21045Z")}.player-img{height:94px;width:auto}.stat-left,.stat-right{position:absolute;background:var(--stats-bg-color);color:var(--stats-text-color);padding:2px 6px;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:550;border-radius:20px;display:flex;align-items:center;white-space:nowrap;z-index:1}.stat-label{font-weight:400;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);margin-inline-start:4px}.stat-left{top:90px;right:124px}.stat-right{top:16px;left:196px}.title{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;max-width:150px}.no-img{.stat-left{top:90px;right:158px}.stat-right{top:30px;left:164px}.bg-cloud{top:22px;right:50%;transform:translateX(50%)}.player-info{position:absolute;top:40px;right:50%;transform:translateX(50%);z-index:1;text-align:center;height:68px;display:flex;flex-direction:column;align-items:center;justify-content:center}.name{max-width:80px;margin-bottom:0px}}`.withBehaviors(new n.N(null,c),new o.o("isAdaptiveThemeEnabled",!0,l));var d=r(96950),g=r(69259);const h=d.qy`
    <div class="player-info">
        <div class="name" title="${e=>e.viewModel.playerOfTheMatchInfo.name}">
            ${e=>e.viewModel.playerOfTheMatchInfo.name}
        </div>
        <img class="flag" src="${e=>e.viewModel.teamImageUrl}" alt="${e=>e.viewModel.playerOfTheMatchInfo.teamName}">
    </div>
`,m=d.qy`
    <div class="bg-cloud">
        <img src="${e=>e.viewModel.backplateImgUrl}">
    </div>
`,u=d.qy`
    ${m}
    <div class="img-wrap">
        <img src="${e=>e.viewModel.imageUrl}" alt="${e=>e.viewModel.playerOfTheMatchInfo.name}" class="player-img">
    </div>
`,x=d.qy`
    ${e=>e.viewModel.stats.left?d.qy`<div class="stat-left" title="${e=>e.viewModel.stats.left.label} ${e=>e.viewModel.stats.left.value}">
        ${e=>e.viewModel.stats.left.value}
        <span class="stat-label">${e=>e.viewModel.stats.left.label}</span>
    </div>`:null}

    ${e=>e.viewModel.stats.right?d.qy`<div class="stat-right" title="${e=>e.viewModel.stats.right.value} ${e=>e.viewModel.stats.right.label}">
        ${e=>e.viewModel.stats.right.value}
        <span class="stat-label">${e=>e.viewModel.stats.right.label}</span>
    </div>`:null}
`,v=d.qy`
    <div class="wrap ${e=>e.viewModel.imageUrl?"has-img":"no-img"}">
        <div class="title" title="${e=>e.viewModel.strings.playerOfTheMatchHeader}">
            ${e=>e.viewModel.strings.playerOfTheMatchHeader}
        </div>
        <div class="content">
            ${h}
            ${x}
            ${e=>e.viewModel.imageUrl?u:m}
        </div>
    </div>
`,f=d.qy`
    ${(0,g.z)(e=>null!=e.viewModel,v)}
`;var b=r(71372),w=r(83546);class y extends b.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,w.h)()}}let $=class extends y{};$=(0,a.Cg)([(0,i.E)({name:"player-of-match-card-v2",template:f,styles:p})],$)},71372(e,t,r){r.d(t,{a(){return o}});var a=r(56911),i=r(92011),s=r(95144);let o=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([s.x],o)},78314(e,t,r){r.r(t),r.d(t,{SportsCricketPartnershipV2(){return k}});var a=r(56911),i=r(92011),s=r(71372),o=r(83546);class n extends s.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,o.h)()}}var l=r(74849),c=r(4126),p=r(63033),d=r(29789);const g=l.A` @container (min-width:200px) and (max-width:280px){.wrap{.header{margin:0 0 16px}.pl-img{width:80px;height:80px}}`,h=l.A` :host{--stat-color:#828BAC;--batsmen-background-color:#9DA8D91A}`,m=l.A` :host{--stat-color:#6B3900;--batsmen-background-color:#FAF4EF}.wrap{display:flex;flex-direction:column;align-items:center;color:var(--smtc-foreground-ctrl-neutral-primary-rest);container-type:inline-size}.title{margin-right:auto}.header{margin:0px 20px 16px;align-items:center;display:flex;align-self:stretch;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);white-space:nowrap}.flag{width:20px;height:20px;margin-right:4px}.batsmen{width:100%;overflow:hidden;display:flex;justify-content:space-around;height:112px;border-radius:${d.OV} ${d.OV} ${d.z5} ${d.z5};background:var(--batsmen-background-color);padding:24px 20px 28px;box-sizing:border-box;position:relative}.pl-name{font-size:15px;line-height:20px;font-weight:550;text-overflow:ellipsis;overflow:hidden;max-width:100%}.stat{color:var(--stat-color);text-align:center;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-variant-ligatures:none}.separator{width:1px;height:100%;background:rgba(0,0,0,0.1)}.pl-img{width:100px;height:100px;position:absolute}.pl-img.left{left:-12px;bottom:0px}.pl-img.right{right:-12px;bottom:0px}.player{width:112px;display:flex;flex-direction:column;align-items:center;text-align:center}.no-lig{font-variant-ligatures:none}.has-images{.batsmen{justify-content:center}.pl-name{max-width:100%;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.player{width:68px}.separator{height:48px;margin:0px 12px}}.no-images{.pl-name{white-space:nowrap;margin-bottom:4px}.player{width:112px}.stat-wrap{display:flex;justify-content:center}.stat-value{font-weight:550}.stat-label{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.stat:first-child{margin-right:12px}}`.withBehaviors(new p.N(null,h),new c.o("isAdaptiveThemeEnabled",!0,g));var u=r(96950),x=r(69259);const v=(e,t)=>u.qy`
    <div class="player">
        <div class="pl-name" title="${e.name}">${e.name}</div>
        <div class="stat" title="${e.battingStatistics?.battingSummary||""}">${e.battingStatistics?.battingSummary||""}</div>
        <img class="pl-img ${t}" src="${e.imageUrl}" alt="${e.name}">
    </div>
`,f=u.qy`
    ${e=>v(e.viewModel.batter1,"left")}
    <div class="separator"></div>
    ${e=>v(e.viewModel.batter2,"right")}
`,b=e=>u.qy`
    <div class="player">
        <div class="pl-name" title="${e.name}">${e.shortName||e.name}</div>
        <div class="stat-wrap">
            <div class="stat" title="${e.battingStatistics?.runsScored||""} ${e=>e.viewModel.strings.runsText}">
                <div class="stat-value">${e.battingStatistics?.runsScored||""}</div>
                <div class="stat-label">${e=>e.viewModel.strings.runsText}</div>
            </div>

            <div class="stat" title="${e.battingStatistics?.ballsFaced||""} ${e=>e.viewModel.strings.cricketBalls}">
                <div class="stat-value">${e.battingStatistics?.ballsFaced||""}</div>
                <div class="stat-label">${e=>e.viewModel.strings.cricketBalls}</div>
            </div>
        </div>
    </div>
`,w=u.qy`
    ${e=>b(e.viewModel.batter1)}
    <div class="separator"></div>
    ${e=>b(e.viewModel.batter2)}
`,y=u.qy`
    <div class="wrap ${e=>e.viewModel.hasImages?"has-images":"no-images"}">
        <div class="header" title="${e=>e.viewModel.strings.currentPartnership} ${e=>e.viewModel.teamScore}">
            <div class="title">${e=>e.viewModel.strings.currentPartnership}</div>
            <img class="flag" src="${e=>e.viewModel.batter1.teamImageUrl}" alt="${e=>e.viewModel.batter1.teamShortName}" />
            <div class="no-lig">${e=>e.viewModel.teamScore}</div>
        </div>
        <div class="batsmen">
            ${e=>e.viewModel.hasImages?f:w}
        </div>
    </div>
`,$=u.qy`
    ${(0,x.z)(e=>e.viewModel,u.qy`${y}`)}
`;let k=class extends n{};k=(0,a.Cg)([(0,i.E)({name:"sports-info-cricket-partnership-v2",template:$,styles:m})],k)},7761(e,t,r){r.r(t),r.d(t,{SportsCricketRecentMatches(){return S}});var a=r(56911),i=r(92011),s=r(74849),o=r(22131),n=r(4126),l=r(48751),c=r(61138),p=r(62047);const d=s.A` .ruby{container-type:inline-size}@container (min-width:180px) and (max-width:233px){.ruby{.content{.team-info{min-width:55px;max-width:60px}.team-performance{gap:2px}}}}@container (min-width:234px) and (max-width:269px){.ruby{.content{.team-performance{gap:7px}}}}`,g=s.A` :host{--ruby-win-color:#6CC57B;--ruby-loss-color:#F98981;--ruby-tie-color:#8791B0;--ruby-win-bg-color:#09662033;--ruby-loss-bg-color:#9D192033;--ruby-tie-bg-color:#323F60A6}.recent-matches{color:${l.l}}.ruby .result-element .team-name{color:#D7DEEF}`,h=(0,o.G2)(g),m=s.A` :host{--ruby-win-color:#01712B;--ruby-loss-color:#AC1922;--ruby-tie-color:#635C57;--ruby-win-bg-color:#94DC7F33;--ruby-loss-bg-color:#FFB5AE33;--ruby-tie-bg-color:#F8F4F2}p{margin:0;font-family:"Segoe UI"}.team-info{margin-right:8px}.title{font-size:${c.k};line-height:${c.F};font-weight:600;margin:8px 0;text-align:center}.content{display:flex;flex-direction:column;background:var(--sports-item-background);padding:6px 12px;border-radius:8px}.team-performance{display:flex;flex-direction:row;gap:8px;&:first-child{padding-bottom:5px;margin-bottom:5px;border-bottom:1px solid rgba(0,0,0,0.05)}}.result-element{padding-top:4px;width:32px;display:flex;flex-direction:column;align-items:center;span{width:24px;text-align:center}.result{color:#fff;font-size:${c.k};line-height:${c.F};text-align:center;border-radius:6px;font-weight:600;height:24px;display:flex;justify-content:center;align-items:center;margin-bottom:6px}.winner{background-color:rgba(15,112,59,1)}.loss{background-color:rgba(209,52,56,1)}.tied{background-color:rgba(220,159,6,1)}}.team-name{font-size:${p.t};line-height:${p.e};font-weight:600;text-align:center}.team-image{height:32px}.underscore{width:12px;height:1px;position:absolute;bottom:6px;right:50%;transform:translateX(50%)}.ruby{.content{background:none;padding:0px 0px 18px}.title{display:none}.team-info{display:flex;align-items:center;width:70px;margin-right:0px}.team-image{width:20px;height:20px}.team-performance{gap:12px;&:first-child{margin-bottom:24px;border-bottom:0px}}.team-name{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:550;margin:0px 0px 0px 4px;max-width:44px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit}.result-element{position:relative;padding-top:0px;width:auto;.team-name{display:none}.winner{background-color:var(--ruby-win-bg-color);color:var(--ruby-win-color)}.loss{background-color:var(--ruby-loss-bg-color);color:var(--ruby-loss-color)}.tied{background-color:var(--ruby-tie-bg-color);color:var(--ruby-tie-color)}.underscore{&.winner{background-color:var(--ruby-win-color)}&.loss{background-color:var(--ruby-loss-color)}&.tied{background-color:var(--ruby-tie-color)}}}.result{margin-bottom:0px;border-radius:14px;height:28px;width:28px;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}}`.withBehaviors(h,new n.o("isAdaptiveThemeEnabled",!0,d));var u=r(96950),x=r(69259),v=r(39957);const f=u.qy`
    <div class="team-performance">
        <div class="team-info">
            <img class="team-image" src="${e=>e.teamImageUrl}" alt="${e=>e.teamName}" />
            <p class="team-name">${e=>e.teamName}</p>
        </div>
        ${(0,v.ux)(e=>e.matches,()=>u.qy`
    <div class="result-element">
        <span class="${(e,t)=>t.parentContext.parent.getResultClass(e.gameStatus)} result">
            ${e=>e.summary}
        </span>
        <span class="team-name">${e=>e.teamName}</span>
        ${(0,x.z)(e=>e.isLatest,u.qy`<div class="underscore ${(e,t)=>t.parentContext.parent.getResultClass(e.gameStatus)}"></div>`)}
    </div>
`)}
    </div>
`,b=u.qy`
    <div class="recent-matches ${e=>e.viewModel.isRubySpotlight?"ruby":""}" data-t="${e=>e.viewModel.telemetryTag}">
        <p class="title">${e=>e.viewModel.strings?.recentMatches}</p>
        <div class="content">
            ${(0,v.ux)(e=>e.viewModel.recentMatches,f)}
        </div>
    </div>
`,w=u.qy`
    ${(0,x.z)(e=>null!=e.viewModel,b)}
`;var y=r(11796),$=r(71372),k=r(83546);class z extends $.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,k.h)()}getResultClass(e){return e===y.qz.Won?"winner":e===y.qz.Lost?"loss":"tied"}}let S=class extends z{};S=(0,a.Cg)([(0,i.E)({name:"sports-cricket-recent-matches",template:w,styles:m,shadowOptions:{delegatesFocus:!0}})],S)},63800(e,t,r){r.r(t),r.d(t,{SportsCricketV2(){return O}});var a=r(56911),i=r(11796),s=r(71372);const o={preGame:{postponedStates:new Set([i.Xp.abandoned,i.Xp.postponed,i.Xp.delayed])},live:{liveTagStates:new Set([i.Xp.superover,i.Xp.inprogressGame,i.Xp.lunch,i.Xp.tea,i.Xp.dinner,i.Xp.drinks]),plainTextStates:new Set([i.Xp.stumps,i.Xp.abandoned,i.Xp.delayed])}};class n extends s.a{get gameStateCategoriesMap(){return o}getParticipant(e,t){return this.viewModel.isRTL?e?t.participantTwo:t.participantOne:e?t.participantOne:t.participantTwo}getLiveText(e){return e==i.Xp.inprogressGame?this.viewModel.strings?.sportsLive:e}getGameTime(e){return(e.tvChannel?`${e.gameStartTime}, ${e.tvChannel}`:e.gameStartTime)||""}isScoreMultiLine(e){return Boolean(e.inningsScore?.length&&e.inningsScore?.length>1||e.overs)}getRubyMiddleTemplate(e){return e===i.Xp.preGame?"pre":e===i.Xp.postGame?"post":"live"}getYetToBatClass(e){return e.yetToBat||e.notToBat?"r-to-bat":"score-line1"}showMatchNameInfo(e){return Boolean(this.viewModel.isRubySpotlight)&&Boolean(e.matchNameInfo)&&"0.5u"!==this.viewModel.cardSize}showVenueCityInfo(e){return Boolean(this.viewModel.isRubySpotlight)&&Boolean(e.venueCity)&&"0.5u"!==this.viewModel.cardSize}}var l=r(92011),c=r(86856),p=r(63033),d=r(74849),g=r(22131),h=r(70289);const m=d.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D;--ruby-text-color:#D7DEEF;--ruby-grey-text-color:rgba(130,139,172,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.r-winner-tag-icon{filter:invert(1) hue-rotate(45deg)}`,u=d.A`
`,x=d.A`
`,v=d.A` :host{--ruby-text-color:rgba(40,37,35,1);--ruby-grey-text-color:rgba(99,93,90,1);--ruby-live-text-bg:rgba(237,246,232,1);--ruby-live-text-color:rgba(0,127,48,1)}.match-data{text-align:center;align-items:center;display:grid;row-gap:0;position:relative;height:100%}.ruby-match-wrapper{text-decoration:none;padding:8px 0;color:var(--ruby-text-color);min-width:0px;${h.f}}.ruby-match-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;height:77px}.ruby-match-detail{flex:1;min-width:0px}.r-partcpnt-img img{width:40px}.r-partcpnt-name{font-size:15px;line-height:20px;font-weight:500}.r-pre-game .r-toss-state{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-base-line-height,16px);font-weight:500;color:rgba(0,127,48,1);text-transform:uppercase}.r-pre-game .r-post-poned-state{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:500;text-transform:uppercase}.r-game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-base-line-height,16px);font-weight:400}.r-game-time{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:500}.ruby-spotlight .r-game-time{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-3-line-height,32px)}.r-game-venue{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-plus-1-line-height,18px);color:var(--ruby-grey-text-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.r-middle-detail-score{display:flex;gap:12px;justify-content:center}.r-score .score-line1{display:flex;flex-direction:row-reverse;justify-content:start;align-items:center;gap:5px;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:600;color:var(--ruby-text-color)}.r-score.left .score-line1{flex-direction:row;justify-content:end}.r-score .participant-score{font-size:12px;line-height:16px;color:var(--ruby-grey-text-color)}.r-score{font-size:12px;flex:1;position:relative}.r-score.left{text-align:right}.r-score.right{text-align:left}.r-post-game .r-score .loser,.r-post-game .loser .score-line1{color:var(--ruby-grey-text-color)}.r-participant-score{display:flex;flex-direction:column;font-variant-ligatures:none}.r-winner-tag{margin-top:-2px}.r-score.left .r-winner-tag{transform:scaleX(1)}.r-score.right .r-winner-tag{transform:scaleX(-1)}.r-winner-tag > svg{fill:currentColor}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));width:max-content;display:flex;align-items:center;justify-content:center;text-align:center;margin:auto;border-radius:8px;padding:3px 9px 3px 4px;font-size:12px;font-weight:600;margin-top:-10px}.r-live-text{color:var(--ruby-live-text-color,rgba(0,127,48,1));line-height:14px;text-transform:uppercase}.r-detailed-live-game-state{font-size:12px;line-height:16px;font-weight:500;text-transform:uppercase;margin-top:-10px}.r-detailed-live-game-state.stumps{color:var(--ruby-live-text-color,rgba(0,127,48,1))}.r-detailed-live-game-state.abandoned{color:var(--ruby-text-color)}.r-detailed-live-game-state.delayed,.r-post-poned-state.delayed{color:rgba(192,65,63,1)}.live-ping{position:relative;width:20px;height:20px}.live-ping::before{content:"";position:absolute;top:50%;left:50%;width:12px;height:12px;background-color:#007F30;opacity:0.2;border-radius:9999px;transform:translate(-50%,-50%);}.r-game-info{font-size:12px;line-height:16px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;width:100%;max-width:270px;margin:0 auto 10px auto}.r-to-bat{color:var(--ruby-grey-text-color);line-height:28px;font-size:15px;padding-top:3px}@keyframes ping{0%{transform:translate(-50%,-50%) scale(1);opacity:0.6}75%{transform:translate(-50%,-50%) scale(1.50);opacity:0}100%{opacity:0}}`.withBehaviors(new c.t(u,x),new p.N(null,m),(0,g.mr)(d.A` :host{forced-color-adjust:auto}`));var f=r(96950),b=r(69259),w=r(39957),y=r(32150);const $=()=>`${(0,y.rA)().StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`,k=(e,t)=>f.qy`
    <div class="r-partcpnt">
        <div class="r-partcpnt-img">
            <img role="presentation" src="${e=>t.imageUrl}"/>
        </div>
        <div class="r-partcpnt-name">${(e,r)=>t.name||""}</div>
    </div>
`,z=f.qy`
    <div class="r-pre-game">
        ${e=>e.detailedGameState===i.Xp.toss?f.qy`<div class="r-toss-state">
            ${e=>e.detailedGameState}
        </div>
        `:f.qy`<div class="r-game-date">
            ${e=>e.gameDate}
        </div>`}
        ${(e,t)=>t.parent.gameStateCategoriesMap.preGame.postponedStates.has(e.detailedGameState)?f.qy`<div class="r-post-poned-state ${e=>e.detailedGameState.toLowerCase()}">
                    ${e=>e.detailedGameState}
                </div>`:f.qy`
                <div class="r-game-time">
                    ${(e,t)=>t.parent.getGameTime(e)}
                </div>
            `}
        ${(0,b.z)((e,t)=>t.parent.showVenueCityInfo(e),f.qy`
            <div class="r-game-venue">
                ${e=>e.venueCity}
            </div>
        `)}
    </div>
`,S=(e,t,r)=>f.qy`
    <div class="r-participant-score ${e.isWinner?"":"loser"}">
        <div class="${(t,r)=>r.parent.getYetToBatClass(e)}">
            <div class="r-winner-tag">
                ${(0,b.z)(t=>e?.isWinner,f.qy`<img src=${`${(0,y.rA)().StaticsUrl}/latest/icons-wc/icons/sports/WinnerTagIcon.svg`} alt="Winner Tag" class="r-winner-tag-icon">`)}
            </div>
            ${(t,r)=>r.parent.viewModel.getFirstScoreLine(e)}
        </div>
        ${(0,b.z)((t,r)=>r.parent.isScoreMultiLine(e),f.qy`
            <span>${(a,i)=>i.parent.viewModel.getSecondScoreLine(e,t,r)}</span>
        `)}
    </div>
`,M=(e=!1)=>f.qy`
<div class="r-middle-detail-score">
    <div class="r-score left">
    ${(t,r)=>{const a=r.parent.getParticipant(!0,t);return a?S(a,e,t.detailedGameState):""}}
    </div>
    <div class="r-score right">
    ${(t,r)=>{const a=r.parent.getParticipant(!1,t);return a?S(a,e,t.detailedGameState):""}}
    </div>
</div>
`,T=f.qy`
    <div class="r-post-game">
        <div class="r-game-date">
            ${e=>e.gameDate}
        </div>
        ${M(!0)}
    </div>
`,C=f.qy`
    <div class="r-live-game">
    ${(e,t)=>t.parent.gameStateCategoriesMap.live.liveTagStates.has(e.detailedGameState)?f.qy`<div class="r-live-tag">
                <span class="live-ping"><img src=${$} /></span> <span class="r-live-text">${(e,t)=>t.parent.getLiveText(e.detailedGameState)}</span>
            </div>`:t.parent.gameStateCategoriesMap.live.plainTextStates.has(e.detailedGameState)?f.qy`
                <div class="r-detailed-live-game-state ${e=>e.detailedGameState.toLowerCase()}">
                    ${e=>e.detailedGameState}
                </div>
            `:void 0}
    ${M()}
    </div>
`,D=f.qy`
 <div class="ruby-middle-detail">
     ${(e,t)=>{switch(t.parent.getRubyMiddleTemplate(e.gameStateCatetory)){case"pre":return z;case"post":return T;case"live":return C;default:return""}}}
 </div>
`,F=f.qy`
    <div class="ruby-match-detail">
        ${D}
    </div>
`,I=f.qy`
    <a class="ruby-match-wrapper"
        tabindex="0"
        href="${e=>e.matchClickthroughUrl?e.matchClickthroughUrl:void 0}"
        target="${(e,t)=>t.parent.viewModel.linkTarget}"
        data-t="${(e,t)=>t.parent.viewModel.telemetryTag}"
    >
        ${(0,b.z)((e,t)=>t.parent.showMatchNameInfo(e),f.qy`<div class="r-game-info">${e=>e.matchNameInfo}</div>`)}
        <div class="ruby-match-content">
            ${(e,t)=>k(0,t.parent.getParticipant(!0,e)||{})}
            ${F}
            ${(e,t)=>k(0,t.parent.getParticipant(!1,e)||{})}
        </div>
    </a>
`,B=f.qy`
    ${(0,b.z)(e=>e.viewModel.matchData.length>0,f.qy`
        <div class="match-data ${e=>e.viewModel.isRubySpotlight?"ruby-spotlight":""}">
            ${(0,w.ux)(e=>e.viewModel.matchData,I,{positioning:!0})}
        </div>`)}
`,P=f.qy`
    ${e=>e.viewModel?f.qy`${B}`:f.qy`<div></div>`}
`;let O=class extends n{};O=(0,a.Cg)([(0,l.E)({name:"sports-cricket-v2",template:P,styles:v,shadowOptions:{delegatesFocus:!0}})],O)},96085(e,t,r){r.r(t),r.d(t,{SportsSpotlightCricketV2(){return b}});var a=r(56911),i=r(92011),s=r(71372);class o extends s.a{}var n=r(74849),l=r(48751),c=r(70289);const p=n.A` :host{height:100%}.wrap{display:flex;flex-direction:column;text-decoration:none;height:100%;color:${l.l};${c.f}}sports-cricket-v2{flex:0;margin-bottom:auto}.partnership sports-cricket-v2{margin-left:20px;margin-right:20px}`;var d=r(96950),g=r(69259);const h=d.qy`
    ${d.qy`${e=>e.viewModel.matchView}`}
`,m=d.qy`
    <player-of-match-card-v2
        :viewModel="${e=>e.viewModel.playerOfTheMatchVM}"
    ></player-of-match-card-v2>
`,u=d.qy`
    <sports-cricket-recent-matches
        :viewModel="${e=>e.viewModel.recentMatchesVM}"
    ></sports-cricket-recent-matches>
`,x=d.qy`
    <sports-info-cricket-partnership-v2
        :viewModel="${e=>e.viewModel.partnershipVM}"
    ></sports-info-cricket-partnership-v2>
`,v=d.qy`
    <a
        href="${e=>e.viewModel.clickThroughUrl}"
        target="_blank"
        class="wrap ${e=>e.viewModel.partnershipVM?"partnership":""} "
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${h}
        ${e=>e.viewModel.playerOfTheMatchVM&&m}
        ${e=>e.viewModel.recentMatchesVM&&u}
        ${e=>e.viewModel.partnershipVM&&x}
    </a>
`,f=d.qy`
    ${(0,g.z)(e=>null!=e.viewModel,v)}
`;let b=class extends o{};b=(0,a.Cg)([(0,i.E)({name:"sports-spotlight-cricket-v2",template:f,styles:p,shadowOptions:{delegatesFocus:!0}})],b)},99657(e,t,r){r.d(t,{D(){return o},I(){return s}});var a=r(68136);const{create:i}=a.G,s=i("sloppy-click-z-index",1),o=i("click-z-index",1)},29789(e,t,r){r.d(t,{OV(){return a},z5(){return i}});const a="var(--mai-smtc-corner-card-nested-default-inside, var(--smtc-corner-image-in-card))",i="var(--mai-smtc-corner-card-nested-default-outside, var(--smtc-corner-image-in-card))"},38817(e,t,r){r.d(t,{R7(){return u},e(){return h},kc(){return m},nH(){return g}});var a=r(57416),i=r(55153),s=r(95239),o=r(26920),n=r(48751),l=r(64187),c=r(22131),p=r(74849),d=r(50882);const g=p.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,h=p.A` ${(0,l.V)("flex")} :host{background:${s.p};outline:calc(${o.XA} * 1px) solid ${i.cu};border-radius:calc((${a.JU} - ${o.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${n.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${o.XA} * 1px) ${i.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${o.XA} * 1px) ${i.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${o.XA} * 1px) ${i.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${i.QG} * 1px);height:calc(${i.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${i.QG} * 1px);height:calc((${i.l8} * 2px) + (${i.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${i.QG} * 2px) + (${i.Sn} * 1px));height:calc((${i.l8} * 2px) + (${i.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${i.QG} * 2px) + (${i.Sn} * 1px));height:calc(${i.l8} * 1px)}::slotted(*){color:inherit}`,m=(0,c.mr)(p.A` :host{background:${d.A.Canvas};color:${d.A.CanvasText}}`),u=p.A` ${h} ${g} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(m)},70289(e,t,r){r.d(t,{f(){return l}});var a=r(64187),i=r(74849),s=r(38817),o=r(99657),n=r(36452);const l=i.A.partial`position: relative; z-index: ${o.D};`;i.A` ${s.e} ${s.nH} ${(0,a.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${n.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${n.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${n.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(s.kc)}}]);