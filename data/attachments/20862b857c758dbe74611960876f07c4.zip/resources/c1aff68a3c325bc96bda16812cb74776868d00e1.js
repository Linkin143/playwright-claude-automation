"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-match-list"],{14472(e,t,s){s.r(t),s.d(t,{SportsMatchListTransformer:()=>r});var a=s(23305),o=s(89757),i=s(79811);class r extends a.Bc{async transform(e){let t=await this.getCurrentViewModel(e);return{viewTemplate:(0,o.qy)`
                <sports-match-list
                    :viewModel="${t}"
                ></sports-match-list>`}}async getCurrentViewModel(e){let t=await this.getMatches(e,e.reason);return{matches:t,isIncomplete:e.isCopilotTheme&&t.length<e.numberOfMatches,cardSize:e.cardSize,paginationStyle:"",reason:e.reason,showParticipantAddIcon:!1,tabIndex:0,telemetryTag:"",isCopilotTheme:e.isCopilotTheme}}async getMatches(e,t){if(!e.sportsMatchOverallData)return[];let s=e.followedSports||new Map,o=(0,i.Yo)(e.sportsMatchOverallData),r=e.sportsMatchOverallData.slice(0,e.numberOfMatches).map(async r=>{let l=r.sportsMatchData,n=(0,i.gK)(l.participantOne,s),p=(0,i.gK)(l.participantTwo,s),c={matchData:r,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:n,participantTwoFollowed:p,topDetailText:e.matchTopDetailText,isContainLiveMatch:o,reason:t,enableLiveScores:this.transformerProvider.config.enableLiveScores,cardSize:e.cardSize,showMatchUXV2:e.showMatchUXV2,isCopilotTheme:e.isCopilotTheme,isMitUX:e.isMitUX};return this.transformerProvider.generateView(c,a.hi.SportsMatch)});return(await Promise.all(r)).filter(i.z2)}}},35908(e,t,s){s.r(t),s.d(t,{SportsMatchListTransformer:()=>a.SportsMatchListTransformer,SportsMatchTransformer:()=>o.SportsMatchTransformer});var a=s(14472),o=s(82724);Promise.resolve().then(s.bind(s,83322)),Promise.resolve().then(s.bind(s,4708))},83322(e,t,s){s.r(t),s.d(t,{SportsMatchList:()=>g});var a=s(56911),o=s(71372);class i extends o.a{}var r=s(92011),l=s(59669),n=s(61138),p=s(63033);let c=(0,l.A)`
`,h=(0,l.A)` .sports-match-list{row-gap:12px;display:grid}.reason.sports-match-list{row-gap:8px}.reason-text{font-size:${n.k};line-height:${n.F};font-weight:600;padding-bottom:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;position:relative}.sports-match-list._15u{row-gap:0;height:272px}.sports-match-list._15u.incomplete{height:252px;padding-top:20px}.sports-match-list._15u.copilot-theme{row-gap:10px;align-items:center}`.withBehaviors(new p.N(null,c));var m=s(89757),d=s(69259),w=s(68835);let v=(0,m.qy)`
    <div class="sports-match-list ${e=>e.viewModel.paginationStyle} ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>"1.5u"===e.viewModel.cardSize?"_15u":""} ${e=>e.viewModel.isIncomplete?"incomplete":""} ${e=>e.viewModel.isCopilotTheme?"copilot-theme":""}"
    >
        ${(0,d.z)(e=>!e.viewModel.isCopilotTheme&&e.viewModel.reason,(0,m.qy)`<div class="reason-text">
            ${e=>e.viewModel.reason}
        </div>`)}
        ${(0,w.ux)(e=>e.viewModel.matches,(0,m.qy)`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>
        `,{positioning:!0})}
    </div>
`,M=(0,m.qy)`
    ${(0,d.z)(e=>void 0!=e.viewModel,v)}
`,g=class extends i{};g=(0,a.Cg)([(0,r.E)({name:"sports-match-list",template:M,styles:h,shadowOptions:{delegatesFocus:!0}})],g)}}]);