"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-results"],{42550(e,t,i){i.r(t),i.d(t,{SportsEventResultsTransformer(){return p},SportsMatchTransformer(){return c.SportsMatchTransformer}});var r=i(67072),a=i(23305),n=i(87906),s=i(33335),o=i(79811),l=i(33744),d=i(89757);class p extends a.Bc{async transform(e){const t=await this.getViewModel(e);return{viewTemplate:d.qy`
                <sports-event-results
                    :viewModel="${t}"
                ></sports-event-results>`}}async getViewModel(e){const{telemetryBuilder:t}=this.transformerProvider,i=e.cardSize,r=this.getFirstMatch(e),{sport:d,eventName:p,clickThroughUrl:c}=e.tabData.tabContent,h=await this.getMatchView(e),g=(0,o.jJ)()?r?.sport?.darkImageId:r?.sport?.imageId,x=(0,l.rA)().CurrentMarket,m=this.getHeaderImageFallback();return r||(0,n.vV)(s.Ax,"Sports Event Results error: empty match list",`market=${x}`,e),{tabType:e.tabData.tabType,headerImage:this.buildHeaderIconUrl(g),headerImageFallback:m,teamImageFallback:this.getTeamImageFallback(),sport:d||"",eventName:p,phase:r?.phaseName||"",tabClickUrl:(0,o.Ot)(c),cardSize:i,matchView:h,tableData:this.getTableData(e),winnerSvg:this.getWinnerSvgUrl(),participantOneData:this.getParticipantData(r?.participantOne||{}),participantTwoData:this.getParticipantData(r?.participantTwo||{}),isHeroCard:e.isHeroCard,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsEventResults})}}getFirstMatch(e){return e.matchData[0]?.sportsMatchData}buildTeamIconUrl(e){return e?this.buildIconUrl(e):this.getTeamImageFallback()}buildHeaderIconUrl(e){return e?(0,o._K)(this.buildIconUrl(e),100,100):this.getHeaderImageFallback()}buildIconUrl(e){return(0,o.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced)}getWinnerSvgUrl(){const e=(0,o.jJ)()?"Light":"Dark";return`${(0,l.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2${e}.svg`}getTeamImageFallback(){return`${(0,l.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}getHeaderImageFallback(){return`${(0,l.rA)().StaticsUrl}latest/sports/icons/Olympics2024.svg`}getParticipantData(e){return{imageUrl:this.buildTeamIconUrl(e.imageId),name:e.name,isWinner:(0,o.Hn)(e.isWinner),score:e.score||""}}async getMatchView(e){const t=this.getFirstMatch(e);if(!t||e.tabData.tabType!==a.v1.LeagueEventResultTeamVsTeam)return;const i=e.followedSports||new Map,r=i.get(t.participantOne?.satoriId||"")||i.get(t.participantOne?.yId||"")||!1,n=i.get(t.participantTwo?.satoriId||"")||i.get(t.participantTwo?.yId||"")||!1,s={matchData:{sportsMatchData:t},parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:r,participantTwoFollowed:n,reason:"",showMatchUXV2:!0,noBackgrounds:!0,useLargeTeamIcon:!0,enableLiveScores:this.transformerProvider.config.enableLiveScores};return await this.transformerProvider.generateView(s,a.hi.SportsMatch)}getRowHeight(e){return e.cardSize===r.uE._1x_2y?"28px":e.cardSize===r.uE._1x_3y?"29px":"22px"}getTableData(e){if(e.tabData.tabType!==a.v1.LeagueEventResultOneVsMany)return null;const t=this.getTableKey(e),i=this.getTableBody(e),r={keys:t,body:i},n=this.getRowHeight(e),s=`repeat(${i.length}, ${n})`;return{telemetryTag:"",cardSize:e.cardSize,isDarkModeTheme:(0,o.jJ)(),tableStyles:this.getTableStyles(e),gridStyles:"width: auto;",data:r,columnStyle:(this.hasRanking(e)?"minmax(auto, 20px)":"")+" minmax(0, 1fr) minmax(auto, 50px)",rowStyle:s}}getTableKey(e){return this.hasRanking(e)?["rank","player","score"]:["player","score"]}hasRanking(e){const t=this.getFirstMatch(e),i=t?.participants||[];return!!i.length&&i.some(e=>e.overallRank)}getTableBody(e){const t=this.getFirstMatch(e),i=t?.participants||[];if(!i.length)return(0,n.vV)(s.Ax,"Sports Event Results error: empty participant list",`market=${(0,l.rA)().CurrentMarket}`,e),[];const a=this.getRowCount(e),o=e.cardSize===r.uE._1x_1y,d="font-size: 12px; line-height: 16px; font-weight: 600;",p=o?"icon-20":"icon-24";return i.slice(0,a).map(e=>({rank:{value:e.overallRank,cellClass:"no-border",textStyles:d},player:{icon:this.buildTeamIconUrl(e.imageId),iconClass:p,cellClass:"no-border",value:e.name,textStyles:d+`margin-inline-start: ${o?"6px":"8px"};`},score:{class:"right",cellClass:"no-border",value:e.score||"",textStyles:d}}))}getRowCount(e){return e.cardSize===r.uE._1x_2y?6:e.cardSize===r.uE._1x_3y?11:2}getTableStyles(e){return`\n            margin-top: 0px;\n            padding: ${e.isHeroCard?"0px 8px":"2px 8px"};\n            background-color: rgba(0, 0, 0, 0);\n        `}}var c=i(82724);Promise.resolve().then(i.bind(i,75747)),Promise.resolve().then(i.bind(i,13038)),Promise.resolve().then(i.bind(i,4708))},71372(e,t,i){i.d(t,{a(){return s}});var r=i(56911),a=i(92011),n=i(95144);let s=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,r.Cg)([n.x],s)},75747(e,t,i){i.r(t),i.d(t,{SportsEventResults(){return I}});var r=i(56911),a=i(71372),n=i(60815);class s extends a.a{constructor(){super(...arguments),this.isSportsImageUnavailable=!1}isFullCardBg(){return"_1x_1y"!==this.viewModel.cardSize&&(!!this.viewModel.isHeroCard||"OneVsManyEventResult"!==this.viewModel.tabType)}onHeaderImageError(){this.isSportsImageUnavailable=!0}}(0,r.Cg)([n.sH],s.prototype,"isSportsImageUnavailable",void 0);var o=i(92011),l=i(47810),d=i(86856),p=i(70289),c=i(63033),h=i(59669);const g=h.A` :host{--divider-color:rgba(255,255,255,0.1);--wrap-bg-color:rgba(26,26,26,0.5);--phase-color:rgb(214,214,214);--divider-hero-color:rgb(102,102,102)}`,x=h.A` .match .win-wrap img{transform:rotate(180deg)}`,m=h.A` :host{--divider-color:rgba(0,0,0,0.05);--wrap-bg-color:rgba(255,255,255,0.5);--phase-color:rgb(112,112,112);--divider-hero-color:rgba(0,0,0,0.08)}.wrap{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:${l.l};${p.f}}.bg{background:var(--sports-item-background);border-radius:8px}.table{border-radius:8px;margin-top:4px}.table-title{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;width:100%}.sport-icon{width:60px;height:60px;margin-top:16px}.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bold{font-weight:600}.sport{font-weight:700;font-size:var(--type-ramp-plus-3-font-size,24px);line-height:var(--type-ramp-plus-3-line-height,32px);margin-top:4px;max-width:calc(100% - 16px)}.event{font-weight:600;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-2-font-size,20px);margin-top:2px;padding-bottom:2px;max-width:calc(100% - 16px)}.divider{margin:8px 0px 8px;width:calc(100% - 16px);height:1px;background-color:var(--divider-color)}.divider-header{width:calc(100% - 16px);height:1px;background-color:var(--divider-hero-color)}.match{width:100%}.match .team-icon{height:20px;width:20px;min-width:20px;margin-inline-end:6px}.match-line{display:flex;justify-content:flex-start;align-items:center;height:20px}.team-name{margin-inline-end:auto}.team-name,.score{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);margin-inline-start:4px}.simple-match-wrap{width:100%;padding:2px 8px;margin-top:4px;box-sizing:border-box}.match .win-wrap img{width:8px;height:8px}.win-wrap{width:14px;min-width:14px;display:flex;align-items:center;justify-content:flex-end}.sm-header{display:grid;grid-template-columns:min-content 1fr min-content;width:100%;column-gap:4px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden}.table .sm-header{width:252px;max-width:252px;margin:6px 8px 4px;display:flex;justify-content:space-between}.sm-sport{font-weight:600}.phase{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);color:var(--phase-color)}.one-v-one{padding:0px 12px 12px;width:100%;box-sizing:border-box}.one-v-one .header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;width:100%}.no-phase .match{height:46px;display:flex;flex-direction:column;justify-content:space-between;margin-top:8px}sports-match{pointer-events:none}._1x_2y.wrap{height:224px}._1x_3y.wrap.v-align-mid{height:334px;margin-top:20px}._1x_3y .one-v-one{padding-top:12px}._1x_1y .one-v-one .header{margin-bottom:4px}._1x_3y .sport-icon{width:108px;height:108px;margin-top:32px}._1x_3y .sport{margin-top:20px}._1x_3y .event{margin-top:6px}._1x_3y .divider{margin:28px 0px 12px}.hero._1x_2y.wrap{height:220px}.hero .table-title{padding:6px 8px;box-sizing:border-box}.hero .table{margin-top:0px}.hero .table .sm-header{margin-top:4px}.hero .divider{margin-bottom:4px;background-color:var(--divider-hero-color)}`.withBehaviors(new d.t(null,x),new c.N(null,g));var v=i(89757),u=i(69259);const b=v.qy`
    <img src="${e=>e.viewModel.winnerSvg}">
`,$=({score:e,isWinner:t})=>v.qy`
    <div class="score" title=${t=>e}>${t=>e}</div>
    <div class="win-wrap">
        ${e=>t?b:null}
    </div>
`,f=v.qy`
    <div class="match">
        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantOneData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantOneData.name}>${e=>e.viewModel.participantOneData.name}</div>
            ${e=>$(e.viewModel.participantOneData)}
        </div>

        <div class="match-line">
            <img
                class="team-icon"
                src=${e=>e.viewModel.participantTwoData.imageUrl||e.viewModel.teamImageFallback}
                onerror="this.style.visibility='hidden'"
            >
            <div class="team-name truncate" title=${e=>e.viewModel.participantTwoData.name}>${e=>e.viewModel.participantTwoData.name}</div>
            ${e=>$(e.viewModel.participantTwoData)}
        </div>
    </div>
`,y=v.qy`
    <img
        src="${e=>e.isSportsImageUnavailable?e.viewModel.headerImageFallback:e.viewModel.headerImage}"
        class="sport-icon"
        @error="${e=>e.onHeaderImageError()}"
    >
    <div class="sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
    <div class="event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
`,w=v.qy`
    <div class="table bg">
        ${(0,u.z)(e=>"_1x_1y"!==e.viewModel.cardSize,v.qy`
            <div class="sm-header bold">
                <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
                <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        <sports-table
            :viewModel="${e=>e.viewModel.tableData}"
        ></sports-table>
    </div>
`,z=v.qy`
    ${y}

    <div class="divider"></div>

    <div class="one-v-one ${e=>e.viewModel.phase?"":"no-phase"}">
        ${(0,u.z)(e=>e.viewModel.phase,v.qy`
            <div class="header">
                <div class="phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
            </div>
        `)}
        ${f}
    </div>
`,k=v.qy`
    <div class="table-title truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
`,_=v.qy`
    ${e=>"_1x_1y"===e.viewModel.cardSize?T:k}
    ${(0,u.z)(e=>e.viewModel.isHeroCard,v.qy`<div class="divider-header"></div>`)}
    ${w}
`,S=v.qy`
    ${y}

    <div class="divider"></div>

    ${(0,u.z)(e=>e.viewModel.matchView,v.qy`
        <sports-match
            :viewModel="${e=>e.viewModel.matchView?.viewModel}"
        ></sports-match>
    `)}
`,T=v.qy`
    <div class="sm-header">
        <div class="sm-sport truncate" title=${e=>e.viewModel.sport}>${e=>e.viewModel.sport}</div>
        <div class="sm-event truncate" title=${e=>e.viewModel.eventName}>${e=>e.viewModel.eventName}</div>
        <div class="sm-phase truncate" title=${e=>e.viewModel.phase}>${e=>e.viewModel.phase}</div>
    </div>
`,j=v.qy`
    ${T}

    <div class="simple-match-wrap bg">
        ${f}
    </div>
`,M=v.qy`
    <a
        class="wrap ${e=>e.viewModel.cardSize} ${e=>e.isFullCardBg()?"bg v-align-mid":""} ${e=>e.viewModel.isHeroCard?"hero":""}"
        data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.tabClickUrl}"
        target="blank"
    >
        ${e=>((e,t)=>{const i="_1x_1y"===t;switch(e){case"OneVsOneEventResult":return i?j:z;case"OneVsManyEventResult":return _;case"TeamVsTeamEventResult":return i?j:S;default:return null}})(e.viewModel.tabType,e.viewModel.cardSize)}
    </a>
`,F=v.qy`
    ${(0,u.z)(e=>e&&null!=e.viewModel,M)}
`;let I=class extends s{};I=(0,r.Cg)([(0,o.E)({name:"sports-event-results",template:F,styles:m,shadowOptions:{delegatesFocus:!0}})],I)},13038(e,t,i){i.r(t),i.d(t,{SportsTable(){return T}});var r=i(56911),a=i(92011),n=i(47810),s=i(62047),o=i(41123),l=i(61138),d=i(86856),p=i(59669),c=i(22131),h=i(70289),g=i(63033);const x=p.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,m=p.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,v=p.A` .table-container{text-decoration:none}.clickable{${h.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${n.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${n.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${s.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${s.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${s.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${o.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${s.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${o.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${l.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,m),new g.N(null,x),(0,c.mr)(p.A` :host{forced-color-adjust:auto}`));var u=i(89757),b=i(68835),$=i(69259);const f=u.qy`
    ${e=>void 0!==e.viewModel.data.title?u.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?u.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?u.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=u.qy`
    ${(0,b.ux)(e=>e.getHeaderValues(),u.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=u.qy`
    ${(0,b.ux)(e=>e.getAllBodyCells(),()=>u.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?u.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?u.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>u.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?u.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>u.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,z=u.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?f:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":f}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,k=u.qy`
    ${(0,$.z)(e=>null!=e.viewModel,z)}
`;var _=i(71372);class S extends _.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(i=>{t.forEach(t=>e.push(i[t]))}),e}}}let T=class extends S{};T=(0,r.Cg)([(0,a.E)({name:"sports-table",template:k,styles:v,shadowOptions:{delegatesFocus:!0}})],T)}}]);