"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-marchmadness"],{37969(e,t,a){a.r(t),a.d(t,{SportsMarchmadnessTransformer:()=>p,SportsMatchTransformer:()=>m.SportsMatchTransformer});var i=a(67072),r=a(23305),n=a(50180);let s="Quarterfinal",o="SemiFinal",l="Championship",h="Champion";var c=a(79811),d=a(89757);class p extends r.Bc{constructor(){super(...arguments),this.getMediumCardMatchCount=()=>{switch(this.uxType){case l:case h:return 1;case o:case s:return 2;default:return 3}},this.getBigCardMatchCount=()=>{switch(this.uxType){case l:case h:return 1;case o:return 2;case s:return 4;default:return 5}},this.getShowMatchCount=()=>{switch(this.cardSize){case i.uE._1x_2y:return this.getMediumCardMatchCount();case i.uE._1x_3y:return this.getBigCardMatchCount();default:return 1}}}async transform(e){let t=await this.getViewModel(e);return{viewTemplate:(0,d.qy)`
                <sports-marchmadness
                    :viewModel="${t}"
                ></sports-marchmadness>`}}async getViewModel(e){this.cardSize=e.cardSize;let t=e.matchData[0].sportsMatchData;"string"!=typeof t.gameState&&(t.gameStateCatetory=(0,c.m5)(t.gameState.state));let a=t.gameStateCatetory,i=a===r.Xp.postGame,{bracketPhase:d,league:p}=e.tabContent||{};this.uxType=((e,t)=>{let{league:a}=t||{};return a&&a.contentHeaderLine1&&a.shouldShowContentHeaderImage?a.headerImage?o:s:a&&a.contentHeaderLine1?e===r.Xp.postGame?h:l:"Match"})(a,e.tabContent);let m=(0,c.jJ)(),g=this.getHeaderImage(p.headerImage,i),u=await this.getMatchViews(e);return{bracketIconUrl:(0,n.GP)("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w={1}&h={2}&q=60&m=6&f=png&u=t",m?"AA1dH5oj":"AA1dH0n8","28","30"),bracketPhase:d,cardSize:this.cardSize,headerImage:g,isPostGame:i,matchClickthroughUrl:this.getMatchClickthroughUrl(t,p),headerLine1:p.contentHeaderLine1,headerLine2:p.contentHeaderLine2,matchViews:u,uxType:this.uxType,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.MarchMadnessCard})}}async getMatchViews(e){if(!e.matchData)return;let t=e.followedSports||new Map,a=this.getShowMatchCount(),i=e.matchData.slice(0,a),n=(0,c.Yo)(i),s=this.uxType===l||this.uxType===h,o=e.tabContent?.league?.clickThroughUrl,d=i.map(async a=>{let i=a.sportsMatchData;s&&o&&(i.gameCenterUrl=o);let l=(0,c.gK)(i.participantOne,t),h=(0,c.gK)(i.participantTwo,t),d={matchData:a,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:l,participantTwoFollowed:h,topDetailText:i.matchHeader,isContainLiveMatch:n,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores};return this.transformerProvider.generateView(d,r.hi.SportsMatch)});return(await Promise.all(d)).filter(c.z2)}getIconInfo(e){let t=this.cardSize===i.uE._1x_3y;return e?{width:t?108:70,height:t?108:70}:t?{height:108,width:153}:{height:80,width:114}}getHeaderImage(e,t){if(!e)return"";let a=this.getIconInfo(t);return(0,c.iK)(e,!1,a)}getMatchClickthroughUrl(e,t){return(this.uxType===l||this.uxType===h)&&t?.clickThroughUrl?(0,c.Ot)(t.clickThroughUrl):e.matchClickthroughUrl||""}}var m=a(82724);Promise.resolve().then(a.bind(a,16034)),Promise.resolve().then(a.bind(a,4708))},20517(e,t,a){var i=a(56911),r=a(92011),n=a(60815);class s extends r.L{}(0,i.Cg)([n.sH],s.prototype,"viewModel",void 0),a.d(t,{z:()=>s})},16034(e,t,a){a.r(t),a.d(t,{SportsMarchmadness:()=>b});var i=a(56911),r=a(20517);class n extends r.z{}var s=a(92011),o=a(47810),l=a(41123),h=a(61138),c=a(70289),d=a(63033),p=a(59669),m=a(22131);let g=(0,p.A)` .semifinal-name{color:#FFFFFF}`,u=(0,p.A)` .match-data{text-decoration:none;${c.f};display:flex;flex-direction:column;justify-content:space-around}._1x_3y .match-data{justify-content:normal}.match-list{display:flex;flex-direction:column;row-gap:12px}.content{display:grid;gap:12px;height:100%;position:relative}.tournament{display:flex;flex-direction:column;row-gap:40px;justify-content:center}._1x_2y .tournament{row-gap:20px}.header,.semifinal-top-icon,.champ-head{display:flex;align-items:center;justify-content:center;color:${o.l}}._1x_2y .semifinal-top-icon{display:none}.semifinal-top-icon img{height:82px}._1x_2y .header-image{display:none}._1x_3y .header-image{display:flex;justify-content:center}._1x_3y .header-image img{height:82px}.tournament-name{font-size:${l.K};line-height:${l.Z};font-weight:700}.tournament-icon{width:22px;height:18px}.tournament-phase{font-size:${h.k};line-height:${h.F}}.semifinal-icon,.quarterfinal-icon{height:24px}.semifinal-icon img,.quarterfinal-icon img{height:24px}.semifinal-name,.quarterfinal-name{font-size:16px;font-weight:900;line-height:24px;letter-spacing:0px;text-align:center;text-transform:uppercase;margin:0 2px}.icon-right{transform:scale(-1)}.final-header{height:36px}.champ-head{flex-direction:column;text-align:center;row-gap:6px}._1x_3y .champ-head{row-gap:16px;margin-bottom:28px;margin-top:24px}.desc{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);color:${o.l};overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:268px}.top-text{text-align:center;font-size:24px;text-transform:uppercase;font-weight:900;line-height:24px;max-width:268px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.top-text.one-line{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.champ-head.post-game{row-gap:0px}.post-game .desc{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);text-transform:uppercase;font-weight:600}`.withBehaviors(new d.N(null,g),(0,m.mr)((0,p.A)` :host{forced-color-adjust:auto}`));var v=a(89757),w=a(68835),x=a(69259);let f=(0,v.qy)`
    <div class="match-list">
        ${(0,w.ux)(e=>e.viewModel.matchViews,(0,v.qy)`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,y=(0,v.qy)`
    ${(0,x.z)(e=>e.viewModel.headerImage,(0,v.qy)`
        <div class="header-image">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />
        </div>`)}
`,M=(0,v.qy)`
    <div class="tournament">
        <div>
            ${y}
            <div class="header final-header">
                <div class="quarterfinal-icon">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
                <div class="quarterfinal-name">
                    ${e=>e.viewModel.headerLine1?.toLowerCase()}
                </div>
                <div class="quarterfinal-icon icon-right">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
            </div>
        </div>
        ${f}
    </div>
`,C=(0,v.qy)`
    <div class="desc" title="${e=>e.viewModel.headerLine2}">${e=>e.viewModel.headerLine2}</div>
`,$=(0,v.qy)`
    <a class="match-data"
        href="${e=>e.viewModel.matchClickthroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}"
        target="_blank"
    >
        <div class="champ-head${e=>e.viewModel.isPostGame?" post-game":""}">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />

            <div>
                <div class="top-text${e=>e.viewModel.headerLine2?" one-line":""}" title="${e=>e.viewModel.headerLine1}">${e=>e.viewModel.headerLine1}</div>
                ${(0,x.z)(e=>e.viewModel.headerLine2,C)}
            </div>
        </div>
        ${f}
    </a>
`,S=(0,v.qy)`
    <div class="content ${e=>e.viewModel.cardSize}">
        ${e=>((e,t)=>{if("_1x_1y"===t)return f;switch(e){case"Match":default:return f;case"SemiFinal":case"Quarterfinal":return M;case"Champion":case"Championship":return $}})(e.viewModel.uxType,e.viewModel.cardSize)}
    </div>
`,T=(0,v.qy)`
    ${(0,x.z)(e=>void 0!=e.viewModel,S)}
`,b=class extends n{};b=(0,i.Cg)([(0,s.E)({name:"sports-marchmadness",template:T,styles:u,shadowOptions:{delegatesFocus:!0}})],b)}}]);