"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_content-video-player_dist_sub-components_VideoJsCCToggleButton_js"],{10227:function(e,t,n){n.d(t,{VideoJsCCToggleButton:function(){return h}});var o,s=n(39610),i=n(56911),l=n(92011),u=n(60815),c=n(89757),d=n(59669),r=n(84540);let a=o=class extends l.L{constructor(){super(...arguments),this.isInitiallyTurnedOn=!0,this.touchTimeout=void 0,this.handleTouchEnd=()=>{this.touchTimeout&&(clearTimeout(this.touchTimeout),this.toggle(),this.removeEventListener("touchend",this.handleTouchEnd))}}connectedCallback(){super.connectedCallback(),void 0===o.globalIsTurnedOn&&(o.globalIsTurnedOn=this.isInitiallyTurnedOn),o.setStyle()}disconnectedCallback(){super.disconnectedCallback(),this.resetStyle()}handleTouchStart(){this.touchTimeout&&clearTimeout(this.touchTimeout),this.touchTimeout=window.setTimeout(()=>{this.touchTimeout=void 0,this.removeEventListener("touchend",this.handleTouchEnd)},300),this.addEventListener("touchend",this.handleTouchEnd)}toggle(){o.globalIsTurnedOn=!o.globalIsTurnedOn,o.setStyle(),this.$emit("toggle",{isTurnedOn:o.globalIsTurnedOn})}resetStyle(){document.documentElement.style.setProperty("--vjs-text-track-display-mode","initial")}static setStyle(){document.documentElement.style.setProperty("--vjs-text-track-display-mode",this.globalIsTurnedOn?"initial":"none")}};a.globalIsTurnedOn=void 0,(0,i.Cg)([u.sH],a.prototype,"localizedStrings",void 0),(0,i.Cg)([u.sH],a,"globalIsTurnedOn",void 0),a=o=(0,i.Cg)([(0,l.E)({name:"cc-toggle-button",template:(0,c.qy)`
        <button @click="${e=>e.toggle()}" @touchstart="${e=>e.handleTouchStart()}" aria-pressed='${()=>!!a.globalIsTurnedOn}' aria-label="${e=>e?.localizedStrings?.captions}">
            <img src="${e=>a.globalIsTurnedOn?r.M0:r.b1}" role="presentation" />
        </button>
    `,shadowOptions:null,styles:(0,d.A)`
        button {
            background: none;
            border: none;
            cursor: pointer;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        @media (prefers-color-scheme: light) {
            button {
                filter: invert(1);
            }
        }
    `})],a);class h extends s.default.getComponent("Component"){constructor(e,t){super(e,t),this.ccToggleButton=new a,this.el().appendChild(this.ccToggleButton)}}}}]);