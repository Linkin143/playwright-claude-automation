"use strict";(self.viewsWebpackChunks=self.viewsWebpackChunks||[]).push([["consumption-page"],{34625:function(e,t,i){i.d(t,{Aw:function(){return C},K1:function(){return T},M:function(){return g},M_:function(){return F},Mw:function(){return P},O3:function(){return u},VE:function(){return l},Vj:function(){return $},Vq:function(){return b},XM:function(){return S},_8:function(){return c},a1:function(){return p},aO:function(){return x},bX:function(){return d},iN:function(){return w},ik:function(){return k},nV:function(){return h},qY:function(){return B},q_:function(){return f},tM:function(){return y},th:function(){return A},ts:function(){return R},xp:function(){return v},zC:function(){return m}});var n=i(59669),o=i(22131),r=i(25975),a=i(32257),s=i(75117);let c=(0,n.A)`
    :host {
        --cstm-foreground-ctrl-neutral-primary-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(2%) saturate(1678%) hue-rotate(190deg) brightness(95%) contrast(96%);
        --cstm-foreground-ctrl-neutral-primary-pressed-filter: brightness(0) saturate(100%) invert(64%) sepia(10%) saturate(836%) hue-rotate(188deg) brightness(89%) contrast(89%);
        --cstm-foreground-ctrl-neutral-secondary-rest-filter: brightness(0) saturate(100%) invert(56%) sepia(80%) saturate(138%) hue-rotate(190deg) brightness(85%) contrast(82%);
        --cstm-foreground-ctrl-on-subtle-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(3%) saturate(1502%) hue-rotate(191deg) brightness(95%) contrast(97%);
        --cstm-foreground-ctrl-on-brand-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(3%) saturate(1158%) hue-rotate(190deg) brightness(97%) contrast(92%);
        --cstm-status-danger-tint-foreground-filter: brightness(0) saturate(100%) invert(63%) sepia(19%) saturate(1420%) hue-rotate(314deg) brightness(103%) contrast(95%);
        --cstm-subtle-button-border-color: rgba(255, 255, 255, 0.08);
        --cstm-status-informative-background: #E5EBFA;
        --cstm-status-informative-foreground: #000000;
        --cstm-foreground-ranked-badge: #798FD4;
        --cstm-status-warning-tint-foreground: #F3C357;
        --cstm-theme-color-accent-200: #1C2338;
    }
`,l=(0,n.A)`
    :host {
        --cstm-corner-media-outside-radius: calc(${r.y3Q} * ${r.MU6});
        --cstm-corner-media-inside-radius: calc(${r.xl2} * ${r.MU6});
        --cstm-corner-media-in-card: var(--cstm-corner-media-outside-radius) var(--cstm-corner-media-outside-radius) var(--cstm-corner-media-inside-radius) var(--cstm-corner-media-inside-radius);
    }
`,d=(0,n.A)`
    :host {
        --cstm-border-on-squircle-px: 1px;
        --cstm-foreground-ctrl-neutral-primary-rest-filter: brightness(0) saturate(100%) invert(10%) sepia(8%) saturate(616%) hue-rotate(341deg) brightness(94%) contrast(88%);
        --cstm-foreground-ctrl-neutral-primary-pressed-filter: brightness(0) saturate(100%) invert(30%) sepia(4%) saturate(768%) hue-rotate(329deg) brightness(97%) contrast(86%);
        --cstm-foreground-ctrl-neutral-secondary-rest-filter: brightness(0) saturate(100%) invert(39%) sepia(2%) saturate(1223%) hue-rotate(335deg) brightness(91%) contrast(90%);
        --cstm-foreground-ctrl-on-subtle-rest-filter: brightness(0) saturate(100%) invert(10%) sepia(3%) saturate(2871%) hue-rotate(343deg) brightness(94%) contrast(88%);
        --cstm-foreground-ctrl-on-brand-rest-filter: brightness(0) saturate(100%) invert(90%) sepia(7%) saturate(146%) hue-rotate(345deg) brightness(101%) contrast(89%);
        --cstm-status-danger-tint-foreground-filter: brightness(0) saturate(100%) invert(15%) sepia(93%) saturate(4284%) hue-rotate(349deg) brightness(69%) contrast(91%);
        --cstm-status-danger-background-light: #AC1922;
        --cstm-status-danger-foreground-light: #FFFFFF;
        --cstm-status-informative-background: #272320;
        --cstm-status-informative-foreground: #FFFFFF;
        --cstm-foreground-ranked-badge: #A25A02;
        --cstm-status-warning-tint-foreground: #A25A02;
        --cstm-theme-color-accent-200: #FEE6D4;
        --cstm-subtle-button-border-color: rgba(0, 0, 0, 0.08);
        --cstm-background-flyout-linear-gradient: linear-gradient(0deg, ${a.RKA} 0%, ${a.RKA} 100%),
            linear-gradient(0deg, ${a.Pgz} 0%, ${a.Pgz} 100%),
            linear-gradient(0deg, ${a.oXU} 0%, ${a.oXU} 100%), ${r.vJX};
    }
`.withBehaviors((0,o.G2)("bingHomepage"!==s.T3.AppType?c:(0,n.A)``)),p="var(--cstm-foreground-ctrl-neutral-primary-rest-filter)",g="var(--cstm-foreground-ctrl-neutral-primary-pressed-filter)",u="var(--cstm-foreground-ctrl-neutral-secondary-rest-filter)",h="var(--cstm-foreground-ctrl-on-subtle-rest-filter)",m="var(--cstm-background-flyout-linear-gradient)",b=`${r.ry_} ${r.kf9} ${r.Ws$} 0px ${r.Ci3},
    ${r.MSR} ${r.FeE} ${r.XES} 0px ${r.xEt}`,f="var(--cstm-border-on-squircle-px)",y="var(--cstm-corner-media-in-card)",v=`${r.yds} ${r.Tb$} ${r.ruk} ${r.FkA} ${r.fxR} inset, ${r.wvE} ${r.pTq} ${r.XLk} 0px ${r.VVH}`,w=`${r.Y4F} ${r.Rqs} ${r.rOe} 0px ${r.JMw}, 0px ${r.qcT} ${r.cjA} 0px ${r.I5k}`,x=`0px ${r.VVF} ${r.Ziq} 0px ${r.nWb}, 0px ${r.qcT} ${r.cjA} 0px ${r.I5k}`,C=`0px ${r.ZTc} ${r.$rc} 0px ${r.H2V}, 0px ${r.qcT} ${r.cjA} 0px ${r.I5k}`,R="var(--cstm-subtle-button-border-color)",A=`${r._SK} ${r.Tex} ${r.Dpq} 0px ${r.ze9}`,k="var(--cstm-status-danger-background-light)",$="var(--cstm-status-danger-foreground-light)",S="var(--cstm-status-informative-background)",T="var(--cstm-status-informative-foreground)",F="var(--cstm-foreground-ranked-badge)",P="var(--cstm-status-warning-tint-foreground)",B="var(--cstm-theme-color-accent-200)"},26779:function(e,t,i){i.d(t,{F6:function(){return o},Hx:function(){return l},NZ:function(){return d},XK:function(){return s},YP:function(){return r},Yn:function(){return c},er:function(){return n},uQ:function(){return a}});let n='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue",sans-serif',o='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue", "Microsoft YaHei",sans-serif',r='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans SC",sans-serif',a='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans JP",sans-serif',s='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans KR",sans-serif',c="Segoe UI, Segoe UI Midlevel, Segoe WP, Arial, sans-serif",l='"Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue",sans-serif',d='"Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue", "Microsoft YaHei",sans-serif'},46026:function(e,t,i){i.d(t,{H:function(){return l}});var n=i(59669);let o=(0,n.A)`
    :host {
        --smtc-text-global-body1-font-size: 20px;
        --smtc-text-global-body2-font-size: 15px;
        --smtc-text-global-body2-line-height: 20px;
    }
`,r=(0,n.A)`
    :host {
        --smtc-text-global-subtitle1-line-height: 28px;
    }
`,a=(0,n.A)`
    :host {
        --smtc-text-style-default-header-weight: 550;
    }
`,s=(0,n.A)`
    :host {
        --smtc-text-ramp-lg-item-body-font-size: 17px;
    }
`,c=(0,n.A)`
    :host {
        --smtc-text-global-title1-font-size: 28px;
        --smtc-text-global-title2-font-size: 24px;
        --smtc-text-global-title2-line-height: 31px;
    }
`,l=(0,n.A)`
    ${o}
    ${r}
    ${c}
    ${a}
    ${s}
`},99563:function(e,t,i){i.d(t,{y:function(){return r}});var n=i(75117),o=i(94108);class r{constructor(e,t,i){this.___styleOverride=e,this.___stylesOverrideInFlight=t,this.___flightName=i}connectedCallback(e){let{source:t}=e;"zh-cn"===n.T3.CurrentMarket?this.___flightName&&o.Rb.CurrentFlightSet.has(this.___flightName)?(t.$fastController.addStyles(this.___stylesOverrideInFlight),t.$fastController.removeStyles(this.___styleOverride)):(t.$fastController.addStyles(this.___styleOverride),t.$fastController.removeStyles(this.___stylesOverrideInFlight)):(t.$fastController.removeStyles(this.___styleOverride),t.$fastController.removeStyles(this.___stylesOverrideInFlight))}}},33544:function(e,t,i){i.d(t,{P:function(){return o}});var n=i(94108);class o{constructor(e,t){this.___flightName=e,this.___styleOverride=t}connectedCallback(e){let{source:t}=e;n.Rb.CurrentFlightSet.has(this.___flightName)?t.$fastController.addStyles(this.___styleOverride):t.$fastController.removeStyles(this.___styleOverride)}}},15189:function(e,t,i){i.d(t,{l:function(){return o},o:function(){return n}});let n=()=>{if(!window?.matchMedia||!window.matchMedia("(forced-colors: active)")?.matches)return null;let e=window.getComputedStyle(document.documentElement).backgroundColor.toLowerCase(),t=0,i=0,n=0;if(e.startsWith("#")){let o=e.replace("#","");3===o.length&&(o=o.split("").map(e=>e+e).join("")),t=parseInt(o.substring(0,2),16),i=parseInt(o.substring(2,4),16),n=parseInt(o.substring(4,6),16)}else{let o=e.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);o&&(t=parseInt(o[1]),i=parseInt(o[2]),n=parseInt(o[3]))}return t>220&&i>220&&n>220?"light":"dark"};class o{constructor(e,t){this.___darkStyleOverride=e,this.___lightStyleOverride=t,this._sourceList=[],this._mediaQuery=null,this._handleChange=()=>{let e=n();this._sourceList&&0!==this._sourceList.length&&this._sourceList.forEach(t=>{t&&t.bgtheme!==e&&(t.bgtheme=e,"light"===e?t.$fastController.addStyles(this.___lightStyleOverride):t.$fastController.removeStyles(this.___lightStyleOverride),"dark"===e?t.$fastController.addStyles(this.___darkStyleOverride):t.$fastController.removeStyles(this.___darkStyleOverride))})}}connectedCallback(e){let{source:t}=e;this._sourceList||(this._sourceList=[]),this._sourceList.includes(t)||this._sourceList.push(t),!this._mediaQuery&&window?.matchMedia&&(this._mediaQuery=window.matchMedia("(forced-colors: active)"),this._addMediaQueryListener()),this._handleChange()}disconnectedCallback(e){let t=e?.source;if(t&&this._sourceList){let e=this._sourceList.indexOf(t);e>=0&&this._sourceList.splice(e,1)}this._sourceList&&0===this._sourceList.length&&(this._removeMediaQueryListener(),this._mediaQuery=null)}_addMediaQueryListener(){"function"==typeof this._mediaQuery?.addEventListener?this._mediaQuery.addEventListener("change",this._handleChange):"function"==typeof this._mediaQuery?.addListener&&this._mediaQuery.addListener(this._handleChange)}_removeMediaQueryListener(){"function"==typeof this._mediaQuery?.removeEventListener?this._mediaQuery.removeEventListener("change",this._handleChange):"function"==typeof this._mediaQuery?.removeListener&&this._mediaQuery?.removeListener(this._handleChange)}}},61918:function(e,t,i){i.r(t),i.d(t,{closeIcon:function(){return eo},BANNER_AD_MARGIN_PADDING_BOTTOM_RUBY:function(){return ep},CONSUMPTION_PAGE_WIDTH_4_COL:function(){return eh},RUBY_STICKY_BANNER_ACTIVATION_WINDOW_MS:function(){return eR},CONTENT_PEEK_HEIGHT:function(){return ex},RUBY_BANNER_AD_MIN_HEIGHT:function(){return ea},CONSUMPTION_PAGE_WIDTH_2_COL:function(){return eb},LoadedPageTemplate:function(){return ik},ErrorTemplate:function(){return iP},BANNER_AD_MIN_HEIGHT:function(){return er},BANNER_AD_HEIGHT_SMALL:function(){return es},RUBY_RR_BOTTOM_AD_LOOKAHEAD:function(){return e$},trendingNewsRRIcon:function(){return et},arrowDownIcon:function(){return en},RUBY_RR_BOTTOM_AD_GAP:function(){return eT},viewsPageId:function(){return ev},getBottomOffsetBasedOnViewport:function(){return ew},CONSUMPTION_PAGE_WIDTH_5_COL:function(){return eu},staticInstanceIdSlots:function(){return eg},SUPPORT_PADDING_FOR_CLASSIC_GA_HOVER_EFFECT:function(){return ef},ConsumptionPage:function(){return th},ContentTypeToTelemetryContentTypeMap:function(){return ey},RUBY_RR_BOTTOM_AD_HYSTERESIS:function(){return eS},CONTENT_PEEK_RRAD_GAP:function(){return eC},RUBY_RR_BOTTOM_AD_STICK_OFFSET:function(){return ek},RUBY_STICKY_BANNER_CLASSES:function(){return eA},BANNER_AD_HEIGHT_LARGE:function(){return ec},trendingNowRefreshIcon:function(){return ei},BannerAdTemplate:function(){return ie},ConsumptionPageTemplate:function(){return iI},BANNER_AD_MARGIN_PADDING_BOTTOM:function(){return ed},CONSUMPTION_PAGE_WIDTH_3_COL:function(){return em},shouldRenderAboveRiverBlock:function(){return i$},ConsumptionPageStyles:function(){return iK},BANNER_AD_PADDING_TOP:function(){return el},BannerTemplate:function(){return it},ToolingInfo:function(){return iX}});var n=i(56911),o=i(61473),r=i(2684),a=i(30101),s=i(57531),c=i(36261);let l={article:"article_content",slideshow:"gallery_content",video:"video_content",webcontent:"video_content",manga:"manga_content",GemArticle:"gem_content",GemRail:"gem_content"};var d=i(61043),p=i(24895),g=i(74079),u=i(25523),h=i(95629),m=i(58581),b=i(13267),f=i(34120),y=i(44439),v=i(37630),w=i(26151),x=i(35363),C=i(76284),R=i(50980),A=i(69917),k=i(18091),$=i(64049),S=i(14881),T=i(22525),F=i(80044),P=i(90389),B=i(91384),I=i(78604),H=i(43803),D=i(77653),_=i(41293),E=i(8231),M=i(11076),O=i(84592),V=i(1661),z=i(46386),L=i(7446),N=i(90286),G=i(94108),W=i(87906),j=i(40450),q=i(47815);let U=async(e,t,i,n)=>{let o=await e.getConfig(t.configRef),{enableExtraAdSlug:r,pageTypeOverride:a,providerId:s,requestIdOverride:c,subverticalKeyOverride:l,useSimplifiedRRSizing:d,verticalKeyOverride:p}=i,g={htmlId:n,enableExtraAdSlug:r,instanceId:t.instanceId,pageTypeOverride:a,providerIdBase62:s,requestIdOverride:c,subverticalKeyOverride:l,useSimplifiedRRSizing:d,verticalKeyOverride:p},u=((e,t)=>{let{adPlacements:i,enableBannerstreamVideo:n,appNexusFlightKeywords:o,nativeAdConfigs:r,useLargeBannerContainer:a,useSimplifiedAppNexusLBSizing:s,useSmallBannerSize:c}=e,{enableExtraAdSlug:l,htmlId:d,instanceId:p,pageTypeOverride:g,providerIdBase62:u,providerIdBase32:h,requestIdOverride:m,subverticalKeyOverride:b,useSimplifiedRRSizing:f,verticalKeyOverride:y}=t,v=m||L.YT.getRequestId(),w=h||(e=>{let t;try{t=(0,N.$)(e,62,32)}catch(t){(0,W.vV)(j.LkX,"Error encoding CMS provider ID from base 62 to 32",`${t.message}. Could not encode provider id: ${e}`)}return t})(u)||"7HD66FC",x=g||G.Rb?.ClientSettings?.pagetype,C=y||G.Rb?.ClientSettings?.verticalKey||"",R=((e,t,i,n)=>{if(!e?.length)return;let o=`${i}_${n}`;for(let r of[`${t}_${o}`,o,i,n,"default"]){let t=e.find(e=>e.adName.toLowerCase()===r.toLowerCase());if(t)return t}})(i,b||G.Rb?.ClientSettings?.categoryKey||"",C,p),A=a&&R?.adName?.includes("banner")||!1,k=n||R?.enableBannerstreamVideo||!1,$=((e,t,i)=>{if(!t||!e)return null;let n=t.adName?t.adName.toLowerCase():"";return n.indexOf("rectangle1")>=0?e.rectangle1:n.indexOf("rectangle2")>=0?e.rectangle2:n.indexOf("rectangle4")>=0?e.rectangle4:n.indexOf("banner")>=0?e.banner:"weather"==i?e.rectangle1:null})(r,R,C),S=$?.properties?.props?.enableNativeAdXandr||!1,T=R?.adName?.indexOf("banner")>=0,F=T&&c?90:R?.appNexusAdsHeight,P=T&&c?728:R?.appNexusAdsWidth;return l&&(F=250,P=300),{enableNativeAdXandr:S,rid:v,providerIdBase32:w,pageType:x,placements:[{targetId:d,pageGroup:R?.pageGroup,width:P,height:F,useSimplifiedLBSize:s,remove300LBSize:A,useSimplifiedRRSize:f,flightKeywords:o,enableBannerstreamVideo:k,adName:R?.adName}]}})(o.properties,g);(0,q.xy)(u)};var K=i(71267),X=i(95822),Y=i(62690),Z=i(73686),J=i(47300),Q=i(98378),ee=i(75117);let et=`${(0,ee.rA)().StaticsUrl}latest/views/watch/icons/TrendingNewsRR.svg`,ei=`${(0,ee.rA)().StaticsUrl}latest/fluent-icons/arrow_sync_20_regular.svg`,en=`${(0,ee.rA)().StaticsUrl}latest/fluent-icons/arrow_circle_down_20_filled.svg`,eo=`${(0,ee.rA)().StaticsUrl}latest/views/icons/Close.svg`,er=112,ea=114,es=110,ec=270,el=4,ed=32,ep=40,eg=["bannerAd","topDisplayAd","bottomDisplayAd","publisherSubscribeFollowButton"],eu=(0,Z.Rs)(20,19),eh=(0,Z.Rs)(16,15),em=(0,Z.Rs)(12,11),eb=(0,Z.Rs)(8,7),ef=20,ey=new Map([[a.i.Article,Q.b5.Article],[a.i.Gallery,Q.b5.Gallery],[a.i.Video,Q.b5.Video],[a.i.Webcontent,Q.b5.WebContent]]),ev=e=>`ViewsPageId-${e}`,ew={[J.j1.c5]:332,[J.j1.c4]:642,[J.j1.c3]:642,[J.j1.c2]:0,[J.j1.c1]:0},ex=168,eC=40,eR=3e3,eA=["ruby-sticky-banner","ruby-sticky-banner-visible","ruby-sticky-banner-exit"],ek=80,e$=32,eS=64,eT=32;var eF=i(44646),eP=i(99215),eB=i(23183),eI=i(84289),eH=i(46376),eD=i(66591),e_=i(31157),eE=i(60815),eM=i(38493),eO=i(73632),eV=i(2018),ez=i(70399),eL=i(66546),eN=i(85652),eG=i(11720),eW=i(36909),ej=i(87960),eq=i(86987),eU=i(68537),eK=i(58319),eX=i(51856),eY=i(8098),eZ=i(34125),eJ=i(5917),eQ=i(43190),e0=i(83593),e1=i(47725),e2=i(44704),e5=i(61285);let e3=async e=>{switch(e){case a.i.Article:return await Promise.all([i.e("web-components_article-page-wc_dist_index_js"),i.e("cs-core-desktop_libs_dist_design-system_design-units_js")]).then(i.bind(i,35125));case a.i.Gallery:return await Promise.all([i.e("card-action-dist"),i.e("libs_ad-service_dist_BeaconService_js"),i.e("libs_ad-service_dist_VideoPropsMapper_js-libs_ad-service_dist_template-selection_config-descr-804c31"),i.e("libs_ad-service_dist_NativeAdService_js"),i.e("web-components_slideshow-base_dist_slideshow-components_immersive-slideshow_index_js"),i.e("web-components_slideshow-base_dist_index_js"),i.e("libs_views-base-class-utils_dist_ViewsBaseElementClass_js-libs_views-helpers_dist_slideshow_S-781d95")]).then(i.bind(i,92130));case a.e.Manga:return await Promise.all([i.e("common-feed-libs"),i.e("libs_super-component-theme_dist_SuperComponentTheme_helper_js-node_modules_cs-core_design-sys-aaae0a"),i.e("web-components_manga-page-wc_dist_index_js")]).then(i.bind(i,66004));default:return}},e6=(e,t=!1)=>t?a.e.Manga:e;var e4=i(15135),e8=i(46082),e9=i(91277);let e7=new Map([["article","ArticlePage"],["gallery","GalleryPage"],["video","VideoPage"]]);var te=i(55265);function tt(e,t){if(e)for(let[i,n]of Object.entries(e))!eg.includes(i)&&n&&(n.instanceId=n.instanceId||"",n.instanceId+="_"+t)}var ti=i(57566),tn=i(46120),to=i(88620),tr=i(66146),ta=i(49415),ts=i(7547),tc=i(51496),tl=i(90499);async function td(e,t,i){let n;switch(e.type){case a.i.Article:n=(0,tn.o)(e,t.featureFlags,i);break;case a.i.Gallery:n=(0,to.K)(e,t.featureFlags,i);break;case a.i.Video:case a.i.Webcontent:e.type!==a.i.Webcontent||t?.featureFlags?.enableRubyConsumptionView||(0,tl.P)(e.type),n=function(e,t){let{vertical:i,category:n}=(0,_.G)(e,!!t.useTeraForVerticalData);return{videoData:e,vertical:i,category:n,inStreamVideoAd:{verticalKeyOverride:i,pageTypeOverride:"video"},addRelatedPlayListOverride:!t.shouldShowPauseEndSlate}}(e,i);break;default:(0,tl.P)(e.type)}return{aboveRiverBlock:function(e,t,i){if(!i.disableAds)return{contentId:e.id,mappedPageType:i.mappedPageType,partnerId:s.kw.get(e.type)||"",pageNumber:i.infiniteReadingContext?.scrollDepth||1,enableNativeAdXandr:(0,c.G)(t||{},c.T.enableNativeAdXandr)}}(e,t.featureFlags,i),actionTray:(0,tr.c)(e,t.featureFlags),bannerAd:(0,A.D)(t.featureFlags,i,e.id,e.type,e),content:{id:e.id,context:n},endOfContentBlock:(0,ta.H)(e,t.componentConfigs?.endOfContentBlockConfigs,t.localizedStrings?.endOfContentBlock,t.featureFlags,i),header:(0,ts.J)(e,t.featureFlags),rail:(0,tc.W)(e,t.componentConfigs?.rightRailConfigs,t.localizedStrings?.rightRail,i),topSpan:function(e,t){let{category:i,vertical:n}=(0,_.G)(e,!!t);return{jsonDataMap:e.jsonDataMap,category:i,vertical:n,scoredCategories:e.scoredCategories}}(e,i.useTeraForVerticalData)}}class tp{constructor(e,t,i){this.config=e,this.refs=t,this.onOutputChanged=i,this.isBannerAlreadySticky=!1,this.rubyStickyBannerVisible=!1,this.rubyStickyWindowOpen=!1,this.headerHeight=0,this.rubyStickyBannerSize=0,this.output={rubyStickyBannerClass:"",stickyBannerSizeStyle:"",stickyBannerAdStyle:"",exitTranslate:null},this.onExitScroll=()=>{if(null==this.stickyExitInitialNaturalTop||null==this.stickyExitInitialScrollY)return;let e=window.scrollY||window.pageYOffset||document.documentElement.scrollTop,t=this.stickyExitInitialNaturalTop-(e-this.stickyExitInitialScrollY);this.output.exitTranslate=`${t}px`,this.emitOutput()},this.endExit=()=>{window.removeEventListener("scroll",this.onExitScroll),this.output.rubyStickyBannerClass="",this.output.exitTranslate=null,this.stickyExitInitialNaturalTop=void 0,this.stickyExitInitialScrollY=void 0,this.rubyStickyBannerExitTimeoutId=void 0,this.emitOutput()}}arm(){this.output.rubyStickyBannerClass="ruby-sticky-banner",this.emitOutput(),this.rubyStickyWindowOpen=!0,this.rubyStickyBannerTimeoutId=window.setTimeout(()=>{this.rubyStickyWindowOpen=!1,this.rubyStickyBannerTimeoutId=void 0,this.rubyStickyBannerVisible&&this.beginExit()},eR)}onScroll(){!this.rubyStickyWindowOpen||this.isBannerAlreadySticky||(window.scrollY||window.pageYOffset||document.documentElement.scrollTop)>0&&(this.isBannerAlreadySticky=!0,this.rubyStickyBannerVisible=!0,this.output.rubyStickyBannerClass="ruby-sticky-banner-visible",this.updateBannerAdStyles(),this.emitOutput())}updateBannerAdStyles(){if(this.headerHeight=0,"u"<typeof window)return;let e=document.querySelector("msn-unified-consumption")?.shadowRoot;if(!e)return;let t=e.querySelector?.(".msn-header");if(t){let e=20*!this.config.enableResponsiveBannerAds;this.headerHeight=t.offsetHeight+e}let i=this.refs.getBannerAdRef();if(i){let e=this.config.enableResponsiveBannerAds,t=e?ep:ed,n=e?0:ed;this.rubyStickyBannerSize=i.offsetHeight,this.output.stickyBannerSizeStyle=`--ruby-sticky-banner-size:${this.rubyStickyBannerSize+this.headerHeight+n}px;`,this.output.stickyBannerAdStyle=`--headerHeight:${this.headerHeight}px;--ruby-sticky-banner-margin:${this.rubyStickyBannerSize+t}px;--bannerPaddingBottom:${n}px;`}this.emitOutput()}dispose(){this.rubyStickyBannerExitTimeoutId&&(clearTimeout(this.rubyStickyBannerExitTimeoutId),this.rubyStickyBannerExitTimeoutId=void 0),this.rubyStickyBannerTimeoutId&&(clearTimeout(this.rubyStickyBannerTimeoutId),this.rubyStickyBannerTimeoutId=void 0),window.removeEventListener("scroll",this.onExitScroll),this.rubyStickyWindowOpen=!1,this.rubyStickyBannerVisible=!1,this.stickyExitInitialNaturalTop=void 0,this.stickyExitInitialScrollY=void 0,this.output={rubyStickyBannerClass:"",stickyBannerSizeStyle:"",stickyBannerAdStyle:"",exitTranslate:null},this.emitOutput()}beginExit(){this.output.stickyBannerSizeStyle="--ruby-sticky-banner-size:80px;";let e=this.measureBannerNaturalTop();this.stickyExitInitialNaturalTop=e??void 0,this.stickyExitInitialScrollY=window.scrollY||window.pageYOffset||document.documentElement.scrollTop,null!=e&&(this.output.exitTranslate=`${e}px`),this.rubyStickyBannerVisible=!1,this.output.rubyStickyBannerClass="ruby-sticky-banner-visible ruby-sticky-banner-exit",this.emitOutput(),window.addEventListener("scroll",this.onExitScroll,{passive:!0}),this.rubyStickyBannerExitTimeoutId=window.setTimeout(this.endExit,300)}measureBannerNaturalTop(){let e=this.refs.getBannerAdRef();if(!e)return null;let t=eA.filter(t=>e.classList.contains(t));t.length>0&&e.classList.remove(...t);let i=e.getBoundingClientRect().top;return t.length>0&&e.classList.add(...t),i}emitOutput(){this.onOutputChanged({...this.output})}}var tg=i(36042),tu=i(87944);class th extends e8.U{contentTypeChanged(){this.contentType===a.i.Article?this.expTTVRDependentList.set(s.xP.ArticleContent,-1):this.markInfiniteReadingTTVRIfNeeded(),e3(e6(this.contentType,this.useMangaWCPage))}getDisplayAdHtmlId(e,t){if(!e||!t){(0,W.vV)(j.L8j,"Missing contentId or instanceId in config","",{contentId:e,instanceId:t}),this.enablePrefetchDisplay=!1;return}let i=`${e}_${t}`,n=this.displayAdHtmlIds.get(i);return n||(n=t+"_"+(0,e1.DA)(),this.displayAdHtmlIds.set(i,n)),n}get contentProviderCardConfig(){let e=this.contentProps?.rail?.config.slots.providerCarousel;if(e?.configRef)return{...e,instanceId:`${e?.instanceId}-${this.contentId}`}}get useRightRailMoreFromCard(){return!!((0,c.G)(this.config.featureFlags||{},c.T.enableRightRailMoreFromCard)&&this.config.featureFlags?.enableRubyConsumptionView&&this.isRubyRightRail&&!this.isRailBelow&&this.contentProviderCardConfig)}get bannerAdStyles(){let e=this.useLargeBannerContainer&&!this.config.enableResponsiveBannerAds?`height: ${(0,tu.c)(this.bannerAdHeight)};`:"";return`top: ${this.commonHeaderHeight}px; margin-inline-start: ${this.bannerAdStart}px;${e}`}get bkNewsStyles(){return`margin-inline-start: ${this.bannerAdStart}px;`}get riverHeadingClassnames(){return(0,eD.x)(this.config.centralizedUx?"consumption-page-river-heading-centralized":"consumption-page-river-heading","consumption-page-river-heading-ext",["arb-style-header",!!this.config.slots.aboveRiverBlock])}get contentAreaClassname(){let e=l[e6(this.contentType,this.useMangaWCPage)];if(!("gallery_content"===e&&(0,c.G)(this.config.featureFlags||{},c.T.enableAutoGalleryHeight)))return this.contentType?e:""}get displayAdWebComponentName(){return(0,e9.cQ)((0,te.lKb)(o.Wi9))}get errorText(){switch(this.errorState){case 1:return this.config.localizedStrings?.goneMessage;case 2:return this.config.localizedStrings?.missingMessage;default:return this.config.localizedStrings?.errorMessage}}get isRightRailReady(){return this.columnArrangement!==J.j1.c1&&this.config.componentConfigs?.rightRailConfigs&&(this.contentProps?.rail||this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)}get rightRailTopPosition(){return 0===this.commonHeaderHeight?0:this.bannerAdRef?80:127}get isRubyRightRail(){let e=this.config.enableBigRRAdWithViewport,t=this.config.featureFlags?.enableBigRRAd,i=this.getRightRailViewportCheck(e,t),n=this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2;return!!this.config.featureFlags?.enableRubyRightRail&&(t||e?i:n||i)&&!!this.config.componentConfigs?.rightRailConfigs&&(!!this.contentProps?.rail||this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)}getRightRailViewportCheck(e,t){if(e)return this.bigRRViewportValid;if(!(0,eO.S)())return!0;let i=t?s.CD:974;return window.matchMedia(`(min-width: ${(0,tu.c)(i)})`).matches}get isRubyRightRailSticky(){return this.isRubyRightRail&&(0,c.G)(this.config.featureFlags||{},c.T.enableRubyRailSticky)}get isRRStickyForLinearFeed(){return this.isRubyRightRailSticky&&(0,c.G)(this.config.featureFlags||{},c.T.enableRRStickyForLinearFeed)&&!this.trendingNowData&&!this.isExplodedFeedContent}get isRubyRightRailAds(){return this.isRubyRightRail&&(0,c.G)(this.config.featureFlags||{},c.T.enableRubyRightRailAds)}get consumptionPageContentHeaderStyles(){return(0,eD.x)("consumption-page-content-header",["consumption-page-content-header-no-border",!!this.config.slots?.socialBarWC||!!this.config.featureFlags?.enableRubyConsumptionView],["consumption-page-content-header-ss",(0,c.G)(this.config.featureFlags,c.T.enableGalleryHeaderMatchWidth)&&this.contentType===a.i.Gallery],["consumption-page-content-header-no-topmargin",!this.commonHeaderHeight],["align-left",!!this.config.featureFlags?.enableAlignLeft])}get bannerHeight(){return this.bannerAdHeight+this.bknewsBannerHeight}get shouldRenderActionTray(){return this.config.slots.actionTray&&this.contentProps?.actionTray&&!this.shouldRenderMobileATForDesktop&&!this.isFloatingSocialBarForRubyFeatureEnabled}get shouldRenderActionBar(){return!!(this.config.featureFlags?.enableRubyConsumptionView&&this.config.featureFlags?.showEndOfContentSocialBar&&this.config.componentConfigs?.viewsHeaderConfigs?.slots.socialBarWC&&!this.config.featureFlags?.enableMoveBylineAndActionBar)}get shouldRenderMobileActionTray(){return this.config.slots.actionTray&&this.contentProps?.actionTray&&(this.shouldRenderMobileATForDesktop||this.isFloatingSocialBarForRubyFeatureEnabled)}get deferRenderingRiver(){return(0,c.G)(this.config.featureFlags||{},c.T.deferRiverRendering)&&!this.isMainContent()&&!(this.getInitializedPromise()&&this.contentInitialized)}get hideRiver(){return!!(this.config.hideRiverWhenMsnReferrer&&(0,d.YC)())||!!(this.config.hideRiverWhenWPORiverFailed&&this.isWPORiverFailed)}get isFloatingSocialBarForRubyFeatureEnabled(){return this.config.featureFlags?.enableFloatingSocialBarT2||this.config.featureFlags?.enableFloatingSocialBarT3}get isMobileATCondition(){return window.matchMedia(`(max-width: ${s.ug}px)`).matches}get isNotEnoughSizeForDesktopAT(){return window.matchMedia(`(min-width: ${s.ug+1}px) and (max-width: ${s.Zn}px)`).matches}get shouldRenderAIConversationStarters(){return!this.noCopilotAPI&&(this.config?.infiniteCopilotFeats||this.isMainContent()||this.isExplodedFeedContent)&&this.config?.enableRubyAiConvStarter&&"AAD"!==(0,eN.eM)().accountType&&!this.contentProps?.header?.disableCopilotButtons}constructor(){super(),this.useMangaWCPage=!1,this.enableBigRRAd=!1,this.enableBigRRAdWithViewport=!1,this.enableRubyStickyBanner=!1,this.enableExtendedRRBreakpoints=!1,this.bigRRViewportValid=!0,this.enableSponsoredArticleLayout=!1,this.actionTrayGridAreaStyles="",this.actionTrayWrapperStyles="",this.commonHeaderHeight=0,this.consumptionPageContentHeight=0,this.showOneRowContent=!1,this.consumptionPageContentRefChanged=()=>{window.setTimeout(()=>{this.consumptionPageContentHeight=this.consumptionPageContentRef?.getBoundingClientRect().height||0})},this.consumptionPageRefChanged=()=>{window.setTimeout(()=>{this.consumptionPageRef&&this.attachObserverToPageContainer()})},this.hasFullyScrolledMainContent=!1,this.relatedVideosFetched=!1,this.expForPriorityLoading=[],this.dwellTimeStartAllowedClassName="",this.isImmersiveFullscreenOpen=!1,this.isRailBelow=!1,this.railBelowLoaded=!1,this.railRightLoaded=!1,this.viewsHeaderHeight=0,this.dataClarityRegion="",this.viewsHeaderRefChanged=()=>{this.viewsHeaderRef&&(this.config?.featureFlags?.enableWidgetsConsumptionView&&void 0!==window.IntersectionObserver&&this.viewsHeaderVisibilityChange&&(this.viewsHeaderRefIntersectionObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver=new window.IntersectionObserver((e,t)=>{this.viewsHeaderVisibilityChange?.(this.contentId,e,t)}),this.viewsHeaderRefIntersectionObserver.observe(this.viewsHeaderRef)),this.isFloatingSocialBarForRubyFeatureEnabled&&void 0!==window.IntersectionObserver&&(this.viewsHeaderRefIntersectionObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver=new window.IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&(this.contentData?.type===a.i.Video?document.dispatchEvent(new CustomEvent("hideFloatingSocialBar")):this.triggerFloatingActionTrayOnDesktop())})}),this.viewsHeaderRefIntersectionObserver.observe(this.viewsHeaderRef)),window.setTimeout(()=>{this.viewsHeaderRef&&(this.setBannerAdStart(),this.viewsHeaderHeight=this.viewsHeaderRef?.getBoundingClientRect().height||0,this.startRRStickyForLinearFeedTracking())}))},this.bannerAdStart=0,this.shouldRenderEoabLeadgen=!1,this.disableAds=!1,this.isOneRowContentReady=!1,this.bannerAdHeight=0,this.bknewsBannerHeight=0,this.visibleBannerAdHeight=0,this.contentWrapperWidth="",this.enableNativeAdXandr=!1,this.zhCnNativeAdsRefresh=!1,this.zhCnNativeAdsRefreshRate=1,this.enableDisplayAdKeyValuePairs=!1,this.delayDisplayAds=!1,this.enableNativeAdKeyValuePairs=!1,this.enableAdKeyValuePairs=!1,this.usePolishedStyles=!1,this.keyTakeawaysData=[],this.keyTakeawaysCollapsed=!0,this.renderKeyTakeawaysSection=!1,this.enableCopilotTheme=(0,eG.l)(),this.keyTakeawaysTelemetryObjects={},this.enablePrefetchDisplay=!1,this.useTeraForVerticalData=!1,this.displayAdHtmlIds=new Map,this._resizeRefreshInFlight=!1,this.markTimeToVisuallyReadyCalled=this.previouslyInit,this.expTTVRDependentList=new Map([[s.xP.ViewsContentHeader,-1],[s.xP.ViewsContentProvider,-1]]),this.viewsContentTopicId="",this.riverTMPLStamped=!1,this.redirectUrl="",this.stabilizeBannerAdSize=!1,this.useLargeBannerContainer=!1,this.contentInitialized=!1,this.gridOverriddenStyle="",this.stickyBannerAdStyle="",this.stickyBannerSizeStyle="",this.shouldRenderMobileATForDesktop=!1,this.updateBottomAdSticky=()=>{let e=this.rubyRailBottomAdRef,t=this.rubyRightRailRef;if(!e||!t)return;let i=t.getBoundingClientRect(),n=ek+e.offsetHeight,o=e.classList.contains("is-fixed");(o?i.bottom<n+eS:i.bottom<n+e$)?(e.style.left=`${i.left}px`,e.style.width=`${i.width}px`,e.classList.add("is-fixed")):o&&(e.classList.remove("is-fixed"),e.style.left="",e.style.width="",e.style.top=""),this.clampFixedBottomAdBelowMoreFrom(e,ek,eT)},this.clampFixedBottomAdBelowMoreFrom=(e,t,i)=>{if(!e.classList.contains("is-fixed"))return;if(!this.useRightRailMoreFromCard||!this.moreFromProviderData){e.style.top="";return}let n=e.previousElementSibling?.getBoundingClientRect().bottom??0;e.style.top=`${Math.max(t,n+i)}px`},this.rubyRailBottomAdRefChanged=()=>{this.rubyRailBottomAdRef&&(0,eO.S)()&&(this.startRRStickyForLinearFeedTracking(),this.updateBottomAdSticky())},this.articleBannerPlacementSignals=new Map,this.isOneRowContentHidden=!1,this.convoStarterVisible=!1,this.conversationStartersIframeStyles="",this.displayCSAT=!1,this.applyStickyBannerOutput=e=>{this.rubyStickyBannerClass=e.rubyStickyBannerClass,this.stickyBannerSizeStyle=e.stickyBannerSizeStyle,this.stickyBannerAdStyle=e.stickyBannerAdStyle,null!=e.exitTranslate?this.style.setProperty("--ruby-sticky-banner-exit-translate",e.exitTranslate):this.style.removeProperty("--ruby-sticky-banner-exit-translate")},this.rubyStickyBannerClass="",this.updateBigRRViewportValid=()=>{if(!this.enableBigRRAdWithViewport||!(0,eO.S)())return;let e=window.matchMedia(`(min-width: ${(0,tu.c)(s.SU)})`).matches,t=window.matchMedia(`(min-height: ${(0,tu.c)(s.t6)})`).matches;this.bigRRViewportValid=e&&t},this.rrStickyRAFId=0,this.rrStickyTrackingStarted=!1,this.startRRStickyForLinearFeedTracking=()=>{let e=!!this.contentProps?.rail?.config?.slots?.bottomDisplayAd;(this.isRRStickyForLinearFeed||e)&&(this.rrStickyTrackingStarted||(window.addEventListener("scroll",this.onRRStickyScroll,{passive:!0}),this.rrStickyTrackingStarted=!0),(this.enableBigRRAdWithViewport||this.enableBigRRAd)&&!this.rrStickyHeaderResizeObserver&&void 0!==window.ResizeObserver&&this.consumptionPageViewsHeaderAreaRef&&(this.rrStickyHeaderResizeObserver=new window.ResizeObserver(()=>{this.updateRRStickyPaddingTop()}),this.rrStickyHeaderResizeObserver.observe(this.consumptionPageViewsHeaderAreaRef)),this.updateRRStickyPaddingTop(),this.updateBottomAdSticky())},this.stopRRStickyForLinearFeedTracking=()=>{window.removeEventListener("scroll",this.onRRStickyScroll),this.rrStickyTrackingStarted=!1,this.rrStickyRAFId&&(cancelAnimationFrame(this.rrStickyRAFId),this.rrStickyRAFId=0),this.rrStickyHeaderResizeObserver?.disconnect(),this.rrStickyHeaderResizeObserver=void 0},this.onRRStickyScroll=()=>{this.rrStickyRAFId||(this.rrStickyRAFId=window.requestAnimationFrame(()=>{this.rrStickyRAFId=0,this.updateRRStickyPaddingTop(),this.updateBottomAdSticky()}))},this.updateRRStickyPaddingTop=()=>{if(!this.viewsHeaderRef||!this.rubyRightRailRef||this.contentProps?.rail?.config?.slots?.bottomDisplayAd)return;let e=this.rubyRightRailRef.firstElementChild;if(!e)return;let t=Math.max(0,this.viewsHeaderRef.getBoundingClientRect().bottom-80);e.style.paddingTop=`${t}px`},this.rubyRightRailRefChanged=()=>{if(!this.rubyRightRailRef)return;let e=this.enableBigRRAdWithViewport||this.enableBigRRAd,t=!!this.contentProps?.rail?.config?.slots?.bottomDisplayAd;(e||t)&&window.requestAnimationFrame(()=>{this.startRRStickyForLinearFeedTracking()})},this.isWPORiverFailed=!1,this.onWPORiverFailedChanged=({detail:e})=>{this.isWPORiverFailed=e.isWPORiverFailed},this.noCopilotAPI=!1,this.loadOneRowRubyContent=async()=>{let e="true"===(0,eW.n)(ej.sy);if(!this.config.enableOneRowContent||!this.config?.featureFlags?.enableRubyConsumptionView||!this.viewsFullPageConnector||(0,eq.T)()&&!e||this.isLastContent){this.showOneRowContent=!1;return}try{let{registerConsumptionMiniFeed:e}=await Promise.all([i.e("common-feed-libs"),i.e("card-action-dist"),i.e("consumption-mini-feed")]).then(i.bind(i,37070));e(),this.showOneRowContent=!0}catch(e){(0,W.c_)(e,j.pW_,"Error importing consumption-mini-feed from consumption page")}},this.triggerFloatingActionTrayOnDesktop=async()=>{if(!this.isFloatingSocialBarForRubyFeatureEnabled)return;let e=new CustomEvent("updateATFloatingBar",{detail:{previousContentId:"",contentId:this.contentId}});document.dispatchEvent(e)},this.initializeContent=()=>{this.infiniteReadingContext?.initializedPromise?.then(()=>{this.contentInitialized=!0})},this.setExperimentalValues=()=>{this.useMangaWCPage=this.isMangaContent(),this.enableNativeAdXandr=this.shouldEnableNativeAdXandr(),this.enableNativeAdKeyValuePairs=(0,c.G)(this.config.featureFlags||{},c.T.setNativeKvp),this.enableDisplayAdKeyValuePairs=(0,c.G)(this.config.featureFlags||{},c.T.setDisplayKvp),this.enableAdKeyValuePairs=this.enableNativeAdKeyValuePairs||this.enableDisplayAdKeyValuePairs||(0,c.G)(this.config.featureFlags||{},c.T.setVideoKvp),this.delayDisplayAds=(0,c.G)(this.config.featureFlags||{},c.T.setDisplayKvp),this.zhCnNativeAdsRefresh=(0,c.G)(this.config.featureFlags,c.T.zhCnNativeAdsRefresh),this.stabilizeBannerAdSize=(0,c.G)(this.config.featureFlags,c.T.stabilizeBannerAds),this.useLargeBannerContainer=(0,c.G)(this.config.featureFlags,c.T.useLargeBannerContainer),this.usePolishedStyles=(0,c.G)(this.config.featureFlags,c.T.usePolishedStyles),this.enablePrefetchDisplay=(0,c.G)(this.config.featureFlags,c.T.enablePrefetchDisplay),this.useTeraForVerticalData=(0,c.G)(this.config.featureFlags||{},c.T.useTeraForVerticalData)},this.loadDisplayAds=()=>{this.enableDisplayAdKeyValuePairs&&this.delayDisplayAds&&(this.delayDisplayAds=!1,this.enablePrefetchDisplay&&(this.shouldRenderBannerAd&&this.bannerAdConfig?.htmlId&&U(eU.L,this.config.slots.bannerAd,this.bannerAdConfig,this.bannerAdConfig.htmlId),this.checkTopDisplayAdPrefetch()&&this.extraInfoForRightRailTopDisplayAd?.htmlId&&U(eU.L,this.contentProps?.rail?.config.slots.topDisplayAd,{...this.contentInfoForRightRailAd,...this.extraInfoForRightRailTopDisplayAd},this.extraInfoForRightRailTopDisplayAd.htmlId)))},this.resizeObserverCallback=()=>{this.resizeObserverBehavior(!1,!!this.gridOverriddenStyle),this.updateBottomAdSticky()},this.resizeObserverBehavior=(e,t)=>{this.updateBannerAdStyle(),window.requestAnimationFrame(()=>{this.updateRightRailVisibility(),this.updateBigRRViewportValid(),(this.enableBigRRAdWithViewport||this.enableBigRRAd)&&this.updateRRStickyPaddingTop(),this.isTopBannerResizeEnabled()&&this.updateBannerAdSizeForViewport(),this.actionTrayGridAreaStyles=this.getActionTrayGridAreaStyles(),this.actionTrayWrapperStyles=this.getActionTrayWrapperStyles(),this.config.featureFlags?.enableExtendedRightRail?this.shouldRenderMobileATForDesktop=window.matchMedia(`(max-width: ${(0,tu.c)(s.kk)})`).matches:this.config.enableMobileATForTablet?this.shouldRenderMobileATForDesktop=this.isMobileATCondition:this.shouldRenderMobileATForDesktop=this.isFloatingSocialBarForRubyFeatureEnabled||this.columnArrangement===J.j1.c1,t&&this.consumptionPageGridStructureStyles(e)})},this.updateBannerAdSizeForViewport=()=>{let e=(0,K.iz)(window.innerWidth);if(void 0===this.extRRBannerZone){this.extRRBannerZone=e;return}if(e===this.extRRBannerZone)return;this.extRRBannerZone=e,this.bannerAdHeight=0===e?th.largeBannerAdContainerHeight:th.smallBannerAdContainerHeight,this.visibleBannerAdHeight=this.bannerAdHeight,this.updateVisibleBannerAdHeight();let t=X.T.adPlacements?.find(e=>e.htmlId?.startsWith("banner"));if(!t?.options)return;let{width:i,height:n}=(0,K.lo)(window.innerWidth);t.options.adsVNextHeight=n,t.options.adsVNextWidth=i,!this._resizeRefreshInFlight&&t.refreshAdCallback&&(this._resizeRefreshInFlight=!0,t.refreshAdCallback(t))},this.updateBannerAdContainerHeight=e=>{let{height:t=0,targetId:i=""}=e;if(i.startsWith("banner")&&(this._resizeRefreshInFlight=!1),i.startsWith("banner")&&(0,c.G)(this.config.featureFlags||{},c.T.stampBannerAdHeight)&&(0,p.ut)(this.contentId,"bannerAdHeight",t.toString()),this.useLargeBannerContainer)return;let n=this.bannerAdRef?.querySelector(this.displayAdWebComponentName);n?.shadowRoot?.getElementById?.(i)?this.bannerAdHeight=t>es+1?th.largeBannerAdContainerHeight:th.smallBannerAdContainerHeight:!n&&i.startsWith("banner")&&(this.bannerAdHeight=th.smallBannerAdContainerHeight),this.updateVisibleBannerAdHeight(),this.updateActionTrayStyles()},this.setCommonHeaderHeight=()=>{let e=this.commonHeaderRef;e&&(this.commonHeaderHeight=e.clientHeight,window.requestAnimationFrame(()=>{let t=e.clientHeight;t!==this.commonHeaderHeight&&(this.commonHeaderHeight=t)}))},this.markRiverVisibleTMPL=()=>{if(this.riverTMPLStamped||!this.riverElementRef)return;let e=(0,g.M)(this.riverElementRef);e>=0&&this.feedProps?.isInfiniteScrollFeed!==this.isInfiniteScrollFeed()&&(this.feedProps=this.getFeedData()),e>100&&(this.riverTMPLStamped=!0,(0,p.ut)(this.contentId,s.uB,"1"))},this.markFullyScrolledMainContent=()=>{!this.consumptionPageStructureRef||this.consumptionPageStructureRef.getBoundingClientRect().bottom<=(window.innerHeight||document.documentElement.clientHeight)&&(this.hasFullyScrolledMainContent=!0,(0,p.ut)(this.contentId,"eomc","1"),this.convoStarterVisible&&(0,p.ut)(this.contentId,"convosvisible"))},this.onScrollHandler=()=>{this.markRiverVisibleTMPL(),this.isMainContent()&&!this.hasFullyScrolledMainContent&&this.markFullyScrolledMainContent(),this.updateVisibleBannerAdHeight(),this.stickyBannerController?.onScroll()},this.updateVisibleBannerAdHeight=()=>{let e=this.bannerAdRef?.getBoundingClientRect().top,t=this.commonHeaderRef?.getBoundingClientRect().bottom;if(null==e||null==t)return;let i=this.config.featureFlags?.enableTopBannerResize?e+this.bannerAdHeight:this.bannerAdRef?.getBoundingClientRect().bottom;null!=i&&(e>t?this.visibleBannerAdHeight=this.bannerAdHeight:i>t?this.visibleBannerAdHeight=Math.max(i-t,0):this.visibleBannerAdHeight=0)},this.consumptionFeedActivityChange=e=>{e.detail?.contentId===this.contentId&&this.documentTitleCb&&this.documentTitleCb?.(this.contentData?.title)},this.setErrorState=e=>{e instanceof u.AD?this.errorState=1:e instanceof u.Rh?this.errorState=2:e instanceof TypeError?this.errorState=3:this.errorState=4},this.getAppErrorForErrorState=e=>e||(this.isMainContent()?1==this.errorState||2==this.errorState?j.dvI:3==this.errorState?j.j9X:j.PsF:j.Lf5),this.handleFatalError=async(e,t,i)=>{if(this.setErrorState(t),i=this.getAppErrorForErrorState(i),(0,W.vV)(i,e,`ContentId: ${this.contentId}`,{id:this.contentId,error:t}),this.isExplodedFeedContent)h.I.dwellTimePause(this.contentId);else{if(this.infiniteReadingContext?.markContentAsFailed&&!this.config.featureFlags?.enableRubyConsumptionView)return this.infiniteReadingContext.markContentAsFailed(this.contentId);this.infiniteReadingContext?.markContentAsFailed?.(this.contentId)}if(this.handleFatalErrorCallback&&this.handleFatalErrorCallback(this.contentId),this.isLoading=!1,this.infiniteReadingContext?.updateInitialContentLoadingState?.(2),this.isMainContent()||this.isExplodedFeedContent){if(this.enableConsumptionErrorPage=(0,c.G)(this.config.featureFlags||{},c.T.enableConsumptionErrorPage)||this.isExplodedFeedContent,await this.loadConsumptionErrorPage(),this.enableConsumptionErrorPage){(0,p.ut)(this.contentId,s.HA,"1"),this.redirectUrl=(0,eK.bI)(this.config.homepageUrl)??s.jb;let e=(0,ez.Kl)();eL.m.updateAboveTheFoldVisuallyReady.getActionSender(e).send(performance.now())}else(0,p.ut)(this.contentId,s.HA,"0"),this.config.featureFlags?.enableWidgetsConsumptionView||(this.redirectUrl=(0,m.FZ)(this.contentId,!0,this.infiniteReadingContext,this.config.homepageUrl),(0,b.bF)(this.redirectUrl));(0,f.p)().resolve(!1)}},this.getArticleBannerAdProperties=e=>{let t=(0,b.Ty)(e?.componentConfigs?.articlePageConfig?.edgeMappedPageType,e?.nativeAdMappedPageType??"");return{props:{adFetchHook:this.articleBannerAdBatchHook,storePlacementLevelSignals:this.addArticleBannerAdPlacementSignals,getPlacementLevelSignals:()=>this.articleBannerPlacementSignals,isFullWidth:!0,contentId:this.isMainContent()?void 0:this.contentId,isVerticalOrientation:!1,mappedPageType:t,partnerId:"article",enableNativeAdXandr:this.enableNativeAdXandr,placementIndex:0,skipCMSBackfill:(0,c.G)(e.featureFlags,c.T.collapseInarticleCMSAds)}}},this.mapContentDataToProps=async e=>{let t;if((this.config.componentConfigs?.slideshowConfigs?.featureFlags?.enableNextSlideshowCard||!this.config.featureFlags?.enableRubyConsumptionView&&!this.config.featureFlags?.enableWidgetsConsumptionView)&&e.type===a.i.Gallery){if(!this.viewsFullPageConnector.hasFetchStarted(this.contentId)){let e=this.infiniteReadingDynamicProps?this.infiniteReadingDynamicProps.hasInfiniteRiver:!this.config.featureFlags?.enableRubyConsumptionView;await this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),e,!1,!1,this.isLastContent)}let e=this.viewsFullPageConnector.getExperimentalSectionData(eP.v.NextSlideshowContent,this.contentId),i=(0,c.G)(this.config.featureFlags||{},c.T.useWebPImageFormat);t=(0,y.h)(e,i)}let i={columnArrangement:this.columnArrangement,disableAds:this.disableAds,infiniteReadingContext:this.infiniteReadingContext,infiniteReadingDynamicProps:this.infiniteReadingDynamicProps,onToggleImmersiveFullscreen:this.onToggleImmersiveFullscreen,nextSlideshowPromise:t,telemetryObject:this.telemetryObject,requestIdOverride:this.isFirstLoadedContent()?void 0:this.getRequestIdOverride(),mappedPageType:this.config.nativeAdMappedPageType,shouldShowPauseEndSlate:this.config.componentConfigs.videoContentConfigs?.shouldShowPauseEndSlate,useTeraForVerticalData:this.useTeraForVerticalData};this.contentProps=await td(e,this.config,i),this.setMainContentData?.(e)},this.checkTopDisplayAdPrefetch=()=>!!(!(this.contentProps?.rail?.disableAds||this.isImmersiveFullscreenOpen||this.isExplodedFeedContent)&&this.contentInfoForRightRailAd&&this.contentProps?.rail?.config.slots.topDisplayAd),this.loadAboveRiverBlockSection=()=>{this.config.slots.aboveRiverBlock&&this.viewsFullPageConnector.getAboveRiverBlockSectionCards(this.contentId).then(e=>{e?this.aboveRiverBlockData=e:(0,W.vV)(j.KXh,"Missing ARB section in WPO",`ContentId: ${this.contentId}`)}).catch(e=>{this.aboveRiverBlockData=[]})},this.getInitializedPromise=(()=>{let e;return()=>(!e&&this.infiniteReadingContext?.initializedPromise&&(e=this.infiniteReadingContext.initializedPromise.then(()=>{if(!this.inlineRefreshed||this.isConnected)return;let e="consumption page initialized after disconnecting";throw(0,W.vV)(j.G5T,e),Error(e)})),e)})(),this.postTTVRCallback=async()=>{if((0,c.G)(this.config.featureFlags,c.T.deferRiverRendering,!1)&&!this.isMainContent())try{await this.getInitializedPromise()}catch{return}if(this.inlineRefreshed&&!this.isConnected)return void(0,W.vV)(j.G5T,"consumption page postttvr initialized after disconnecting");this.markTimeToVisuallyReadyCalled||(this.markTimeToVisuallyReadyCalled=!0);try{this.loadTopSpanModuleContent(),this.loadAboveRiverBlockSection(),this.updateSeoTags(),this.updateLeadgen(),this.updateActionTrayStyles(),this.loadRubyViewsMetaInfo(),this.loadOneRowRubyContent(),this.isReadyForLoadMoreFromProvider()&&this.loadMoreFromProvider(),this.loadTrendingNow(),(0,eI.uR)().then(()=>{this.isMainContent()&&(0,b.Ig)()&&(0,W.vV)(j.oZ1,"Duplicate root element found in the DOM",`ContentId: ${this.contentId}`)}),this.initializeContextualFeedback()}catch(e){}},this.loadRubyViewsMetaInfo=()=>{let{updateDateTime:e,publishedDateString:t}=this.contentProps?.header||{},i=(0,b.DL)(e,t,this.actionBarStrings);this.publishedDateStringFormat=i.publishedDateStringFormat,this.publishedDateTimeString=i.publishedDateTimeString,this.publishedTimeStamp=i.publishedTimeStamp,this.updatedDateStringFormat=i.updatedDateStringFormat,this.updatedDateTimeString=i.updatedDateTimeString,this.updatedTimeStamp=i.updatedTimeStamp},this.isReadyForLoadMoreFromProvider=()=>!!(this.config.featureFlags?.enableRubyConsumptionView&&this.viewsFullPageConnector&&(this.contentType===a.i.Article||this.contentType===a.i.Gallery)),this.isFirstLoadedContent=()=>this.isMainContent()&&!this.inlineRefreshed,this.getActionTrayWrapperStyles=()=>{let e=(this.commonHeaderHeight??132)+8+this.bknewsBannerHeight;((0,c.G)(this.config.featureFlags||{},c.T.hideHeaderNavBar)||(0,c.G)(this.config.featureFlags||{},c.T.enableFixedAtTop))&&(e=119);let t=this.visibleBannerAdHeight;return`top: ${(0,tu.c)(e)}; transform: translateY(${(0,tu.c)(t)}); transition: transform 50ms ease-out;`},this.visibleBannerAdHeightChanged=()=>{this.updateActionTrayStyles()},this.commonHeaderHeightChanged=()=>{this.updateActionTrayStyles()},this.bknewsBannerHeightChanged=()=>{this.updateActionTrayStyles()},this.isMainContent=(0,eX.L)(()=>!this.infiniteReadingContext||this.infiniteReadingContext.isMainArticle),this.removePageFromTheFeed=()=>{this.removeArticleFromTheProvider?.(this.contentProps?.header?.provider?.id||"",this.contentId)},this.onBreakpointCallback=e=>{this.columnArrangement=e,this.updateRightRailVisibility(),this.feedProps=this.getFeedData()},this.updateBannerAdStyle=()=>{this.setBannerAdStart();let e=this.commonHeaderRef?.clientHeight;e&&this.commonHeaderHeight!==e&&this.setCommonHeaderHeight()},this.setBannerAdStart=()=>{if(this.viewsHeaderRef){if(G.Rb.MarketDir===e_.O.rtl){if((0,v.n)()){this.bannerAdStart=-Math.abs(window.innerWidth-this.viewsHeaderRef.offsetLeft-this.viewsHeaderRef.getBoundingClientRect().width);return}this.bannerAdStart=-Math.abs(window.innerWidth-this.viewsHeaderRef.offsetLeft);return}this.bannerAdStart=-Math.abs(this.viewsHeaderRef.offsetLeft)}},this.updateLeadgen=()=>{let e=this.contentProps?.content;if(e){let{provider:t}=e.context?.articleData||e.context?.slideshowData||{};if(!t||!t.leadgen)return;this.updateLeadgenData(t)}},this.stampPagePZeroTTVR=(e,t)=>{if(!e||this.previouslyInit)return;let i=t||window.performance.now();this.isMainContent()&&!this.markTimeToVisuallyReadyCalled&&(0,eI.yi)(e,!1,i),this.trySetTTVRAndMilestone(e,i)},this.onToggleImmersiveFullscreen=()=>{this.isImmersiveFullscreenOpen=!this.isImmersiveFullscreenOpen},this.markInfiniteReadingTTVRIfNeeded=(()=>{let e=this.previouslyInit;return async()=>{if(e||this.isFirstLoadedContent()||this.config.featureFlags?.enableRubyGemReaderWidth)return;e=!0;let t=null;try{t=(0,eH.cX)(`TTVR-${this.contentId}`,!0)}catch(e){L.YT.sendAppErrorEvent({...j.ohN,message:"Unable to mark refresh TTVR on infinite reading",pb:{...j.ohN.pb,customMessage:`Unable to mark refresh TTVR on infinite reading. ContentId: ${this.contentId} . Experience: ArticlePage . error:${e}`}})}let i=this.getInitializedPromise()||Promise.resolve();try{await i.then(()=>new Promise(e=>window.setTimeout(e)))}catch{return}if(t){let e={TTVR:t},i=s.iW[this.contentType];i&&(e[`TTVR.${i}`]=t),(0,p.gY)(this.contentId,{markers:e})}}})(),this.getTopSpanModuleContent=async e=>{if(!this.viewsFullPageConnector)return[];let t=await this.viewsFullPageConnector.getPageSectionData(this.contentId,eP.v.TopSpan,1,this.config.localizedStrings,{shouldStampTMPL:t=>eB.lq.has(t)&&!e},this.topSpanTelemetryObject);return t?.length?t:[]},this.breakingNewsWillRender=(e=0)=>{this.bknewsBannerHeight=e},this.backToFeed=()=>{let e=(0,ti.I)();this.config.featureFlags?.enableRubyConsumptionView&&((0,eY.op)()||e)&&(0,b.t1)(),this.redirectUrl&&!e&&window.open(this.redirectUrl,"_self")},this.loadConsumptionErrorPage=async()=>{if(this.enableConsumptionErrorPage)try{if(this.config.featureFlags?.enableRubyConsumptionView){let{RubyConsumptionErrorPageWC:e}=await i.e("web-components_ruby-consumption-error-page_dist_index_js").then(i.bind(i,73845));return e}let{MSNConsumptiponErrorPage:e}=await i.e("web-components_consumption-error-page_dist_index_js").then(i.bind(i,32307));return e}catch(e){this.enableConsumptionErrorPage=!1,(0,W.c_)(e,j.M6E,"Error importing consumption error page")}return null},this.stopEventPropagation=e=>{e.stopPropagation()},this.handleAIConversationStartersMessage=e=>{if(!(0,b.iZ)(e.origin))return;let{type:t,height:i,contentId:n}=e.data;if("noCopilotAPI"==t){this.noCopilotAPI=!0;return}if("conversationStartersSize"===t&&this.contentId===n){if(this.conversationStartersIframeStyles="",0===i){this.conversationStartersIframeStyles="display: none;";return}this.contentType!==a.i.Gallery||this.enableExtendedRRBreakpoints||(this.conversationStartersIframeStyles+="max-width: unset; padding: 0 24px;"),this.conversationStartersIframeStyles+=`height: ${i}px;`,this.convoStarterVisible=!0}},this.columnArrangement=(0,eF.TU)().currentColumnArrangement,this.onScrollHandler=(0,tg.A)(this.onScrollHandler,500),this.updateActionTrayStyles=(0,tg.A)(this.updateActionTrayStyles,16),this.articleBannerAdBatchHook=void 0,this.articleBannerPlacementSignals=new Map,this.addArticleBannerAdPlacementSignals=(e,t)=>{this.articleBannerPlacementSignals.set(e,t)}}getRequestIdOverride(){return this.requestIdOverride||(this.requestIdOverride=(0,p.OM)(this.contentId,!this.isFirstLoadedContent())),this.requestIdOverride}async experienceConnected(){this.showNativeAdBanner=this.config.enableNativeAdBanner&&(0,ti.I)()&&this.isMainContent(),this.config.enableBigRRAdWithViewport?(this.enableBigRRAdWithViewport=!0,this.enableBigRRAd=!1,this.updateBigRRViewportValid()):this.config.featureFlags?.enableBigRRAd&&(this.enableBigRRAd=!0,this.enableBigRRAdWithViewport=!1),this.config.sponsoredContent&&(0,eZ.G)()&&this.isMainContent()&&(this.enableSponsoredArticleLayout=!0),this.config.enableNativeAdBanner&&new URLSearchParams(location.search).get("forceNativeAdBanner")&&(this.showNativeAdBanner=!0),this.config.componentConfigs?.slideshowConfigs&&eV.vv.set(s.nR,this.config.componentConfigs.slideshowConfigs),this.enableRubyStickyBanner=!!this.config?.enableRubyStickyBanner,this.config?.enableRubyStickyBanner&&this.isMainContent()&&(this.stickyBannerController=new tp({enableResponsiveBannerAds:this.config.enableResponsiveBannerAds},{getBannerAdRef:()=>this.bannerAdRef,hostElement:this},this.applyStickyBannerOutput)),this.enableExtendedRRBreakpoints=!!this.config?.enableExtendedRRBreakpoints,this.stampSSRTmpl(),this.addPageBackIfNeeded(),this.isLoading=(0,c.G)(this.config.featureFlags||{},c.T.enableLoadStateOnCP),tt(this.config.slots,this.contentId),this.setExperimentalValues(),this.attachDisplayAdServiceEventListeners();let e=e4.V.getInstance().rootReducer.connector(r.xH);e&&(this.viewsFullPageConnector=e),this.viewsContentTopicId=this.isMainContent()&&new URLSearchParams(location.search).get("viewsContentTopicId")||"",this.showNativeAdBanner?this.articleBannerAdBatchHook=w.V(this.articleBannerAdBatchHook):this.setMainBannerAdProps(),this.aboveRiverBlockData=void 0;let t=this.loadContent();(0,x.D)()||await t,(0,eO.S)()&&(this.markTTVRIfSSREnabled(),this.resizeObserverCallback=(0,tg.A)(this.resizeObserverCallback,500),this.initializeContent()),this.config.componentConfigs?.viewsHeaderConfigs?.hideProviderLogoAndName&&this.expTTVRDependentList.delete(s.xP.ViewsContentProvider),this.shouldRenderAIConversationStarters&&window.addEventListener("message",this.handleAIConversationStartersMessage)}async initializeContextualFeedback(){if(this.config.slots?.contextualFeedbackWC)try{let e,{contextualFeedbackController:t}=await Promise.all([i.e("common-feed-libs"),i.e("libs_nurturing-internal-placement-provider_dist_InternalPlacementProvider_js-libs_wpo_dist_pr-44d366")]).then(i.bind(i,53349));t.setConfig({...this.config});let n=C.L.get("consumption-wpo-feed-contextual-feedback");if(n)try{let t=JSON.parse(n);(e=!!t?.showFeedCF)&&(this.csatDwellTimeThresholdMs=t?.dwellTimeThreshold?1e3*Number(t.dwellTimeThreshold):void 0,L.YT.addOrUpdateTmplProperty("wpopromflcf","1"))}catch(e){(0,W.c_)(e,j.q_v,`${e}. Type: consumption-wpo-feed-contextual-feedback`);return}this.displayCSAT=await t.shouldDisplayFeedLevelCSAT(e)}catch(e){(0,W.c_)(e,j.M6E,"Error importing consumption error page")}}addPageBackIfNeeded(){if(!(0,c.G)(this.config.featureFlags||{},c.T.enableAddNavHistory)||(0,b.b5)())return;let e=(0,eK.bI)(this.config.homepageUrl)??s.jb;(0,eJ.hN)(e,this.enableInlineRefresh)}markTTVRIfSSREnabled(){if(window.isSSREnabled&&window.isSSRCompleted&&!window.isCSRFallback&&this.isMainContent()){let e=window.performance.now();this.expTTVRDependentList.size>0&&window.requestAnimationFrame(()=>{this.expTTVRDependentList.forEach((t,i)=>{this.stampPagePZeroTTVR(i,e)})})}}shadowDomPopulated(){(0,x.D)()||this.updateDataForKVP(),(0,eF.TU)().subscribe(this.onBreakpointCallback),this.commonHeaderRef&&(this.commonHeaderMutationObserver=new MutationObserver(this.setCommonHeaderHeight),this.commonHeaderMutationObserver.observe(this.commonHeaderRef,{attributes:!0})),this.updateRightRailVisibility(),this.attachObserverToPageContainer(),window.addEventListener("resize",this.resizeObserverCallback),window.addEventListener("scroll",this.onScrollHandler),window.addEventListener(R.EU,this.onWPORiverFailedChanged),this.stickyBannerController&&(this.stickyBannerController.updateBannerAdStyles(),this.stickyBannerController.arm())}disconnectedCallback(){super.disconnectedCallback(),(0,eF.TU)().unsubscribe(this.onBreakpointCallback),this.commonHeaderMutationObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver?.disconnect(),this.stopRRStickyForLinearFeedTracking(),document.removeEventListener(R.Z7,this.consumptionFeedActivityChange),window.removeEventListener("resize",this.resizeObserverCallback),window.removeEventListener("scroll",this.onScrollHandler),window.removeEventListener(R.EU,this.onWPORiverFailedChanged),this.shouldRenderAIConversationStarters&&window.removeEventListener("message",this.handleAIConversationStartersMessage),this.stickyBannerController?.dispose(),this.stickyBannerController=void 0}setMainBannerAdProps(){if(!this.isMainContent()||this.mainBannerAdProps||!this.config?.slots?.bannerAd||!(0,eO.S)())return;let e={columnArrangement:this.columnArrangement,disableAds:this.disableAds,infiniteReadingContext:this.infiniteReadingContext,mappedPageType:this.config.nativeAdMappedPageType,useTeraForVerticalData:this.useTeraForVerticalData};this.mainBannerAdProps=(0,A.D)(this.config.featureFlags,e,this.contentId,G.Rb.ClientSettings.pagetype)}isTopBannerResizeEnabled(){return!!this.config.featureFlags?.enableTopBannerResize}attachObserverToPageContainer(){!this.consumptionPageRef||this.pageContainerModuleObserver||(this.pageContainerModuleObserver=new IntersectionObserver(this.onPageContainerModuleObserve.bind(this),{root:null,threshold:0}),this.pageContainerModuleObserver.observe(this.consumptionPageRef))}onPageContainerModuleObserve(e){e&&e.forEach(e=>{if(e.intersectionRatio>.001){this.dwellTimeStartAllowedClassName=(0,k._)(this.contentId);return}})}attachDisplayAdServiceEventListeners(){this.config.slots.bannerAd&&!this.disableAds&&(X.T.addEventListener(Y.v.AdReturned,this.updateBannerAdContainerHeight),this.stabilizeBannerAdSize||(X.T.addEventListener(Y.v.AdRefreshed,this.updateBannerAdContainerHeight),X.T.addEventListener(Y.v.AdNoBid,this.updateBannerAdContainerHeight)))}get shouldRenderBannerAd(){return!this.disableAds&&!this.isImmersiveFullscreenOpen&&!!this.config.slots.bannerAd&&(!!this.mainBannerAdProps||!!this.contentProps?.bannerAd)}get shouldRenderBannerAdAboveHeadline(){if(!this.shouldRenderBannerAd)return!1;if(this.config.featureFlags?.enableRubyDisplayAds){let e=this.enableGemContinuousReading||this.isMainContent(),t=this.config.enableResponsiveBannerAds;return"aboveHeadline"===this.config.bannerAdPosition&&e&&(t||this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2)}return!0}get shouldRenderBannerAdBelowHeadline(){return!!this.shouldRenderBannerAd&&!!this.config.featureFlags?.enableRubyDisplayAds&&"belowHeadline"===this.config.bannerAdPosition&&this.isMainContent()&&this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2}get bannerAdConfig(){return{...this.isMainContent()?this.mainBannerAdProps:this.contentProps?.bannerAd,delayFetch:this.delayDisplayAds,contentId:this.enableNativeAdKeyValuePairs?this.contentId:void 0,enablePrefetchDisplay:this.enablePrefetchDisplay,htmlId:this.enablePrefetchDisplay?this.getDisplayAdHtmlId(this.contentId,this.config.slots?.bannerAd?.instanceId||""):void 0,enableResponsiveBannerBackground:this.config.enableResponsiveBannerAds}}get isExplodedFeedContent(){return this.infiniteReadingContext?.pageOriginOverride===s.Nh}get contentInfoForRightRailAd(){if(this.contentProps?.rail?.adProperties)return{...this.contentProps.rail.adProperties,delayFetch:this.delayDisplayAds,contentId:this.enableNativeAdKeyValuePairs?this.contentId:void 0}}get extraInfoForRightRailTopDisplayAd(){if(this.enablePrefetchDisplay)return{enablePrefetchDisplay:this.enablePrefetchDisplay,htmlId:this.enablePrefetchDisplay?this.getDisplayAdHtmlId(this.contentId,this.contentProps?.rail?.config.slots.topDisplayAd?.instanceId||""):void 0}}get rubyRightRailProps(){return{...this.contentInfoForRightRailAd,...this.extraInfoForRightRailTopDisplayAd,pageTypeOverride:this.config.nativeAdMappedPageType}}get rubyRightRailBottomAdProps(){return{...this.contentInfoForRightRailAd,pageTypeOverride:this.config.nativeAdMappedPageType}}get rubyRightRailProviderCarouselProps(){return{contentId:this.contentProps?.rail?.contentId,contentTitle:this.contentProps?.rail?.contentTitle,isMainArticle:this.infiniteReadingContext?.isMainArticle,isMoreFromCard:this.useRightRailMoreFromCard,pageType:"view",publisherProfileId:this.contentProps?.header?.provider.profileId,railBelowLoaded:this.railBelowLoaded,railRightLoaded:this.railRightLoaded}}get actionBarStrings(){let e=this.config.localizedStrings;return e&&e.actionBar&&e.viewsHeader?{...e.actionBar,justNowSimple:e.viewsHeader.justNowSimple??"",hoursAgoSimple:e.viewsHeader.hoursAgoSimple??"",minutesAgoSimple:e.viewsHeader.minutesAgoSimple??"",daysAgoSimple:e.viewsHeader.daysAgoSimple??"",weeksAgoSimple:e.viewsHeader.weeksAgoSimple??"",yearsAgoSimple:e.viewsHeader.yearsAgoSimple??"",monthsAgoSimple:e.viewsHeader.monthsAgoSimple??"",updatedAgoLabel:e.viewsHeader.updatedAgoLabel??""}:{}}get shouldRenderEocb(){return(0,eO.S)()&&!!this.contentProps?.endOfContentBlock&&(!this.config.featureFlags?.enableRubyConsumptionView||this.config.featureFlags?.enableRubyConsumptionView&&this.contentType===a.i.Article)}isKeyTakeawaysEnabled(){return!!this.config.componentConfigs?.viewsHeaderConfigs?.enableKeyTakeaways||!!this.config.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot}shouldRenderKeyTakeawaysSection(){this.renderKeyTakeawaysSection=!!this.config?.componentConfigs?.viewsHeaderConfigs?.slots?.keyTakeawaysWC&&this.enableKeyTakeaways()}get disableAllAIFeatures(){return this.contentData?.stringAttributes?.isAiGeneratedContentDisabled==="1"||this.contentProps?.header?.disableCopilotButtons||!1}enableKeyTakeaways(){return!!(this.keyTakeawaysData&&this.keyTakeawaysData.length>0)&&(!!this.config?.infiniteCopilotFeats||!!this.isMainContent()||!!this.isExplodedFeedContent)&&!this.disableAllAIFeatures&&this.isKeyTakeawaysEnabled()}async loadContent(){try{let e=this.getCurrentContentData();this.contentData=await e}catch(e){this.handleFatalError("Failed to get content view data",e);return}if(this.config.featureFlags?.enableRubyArticleFlex&&[a.i.Article,a.i.Gallery,a.i.Video].includes(this.contentData.type)&&(this.enableRubyArticleFlex=!0),$.a.setContentViewData(this.contentId,this.contentData),(0,d.Ux)(this.contentData.locale))return void this.handleFatalError("Failed to get content view data",new u.Rh);if((0,d.ZE)(this.contentData.provider?.id))return void this.handleFatalError("Forbidden BBC content requested in UK",new u.Rh,j.lOg);if((0,eO.S)()){var e;(0,f.p)().resolve(!0),this.telemetryObject.contract.name="ConsumptionPage"+((e=s.kw.get(this.contentData.type))?">"+e7.get(e):""),this.setupViewsTracker(this.contentData),this.topSpanTelemetryObject=(0,e2.u)(s.zA.topSpan,{type:ey.get(this.contentData.type)}),document.addEventListener(R.Z7,this.consumptionFeedActivityChange),this.disableAds=!!this.shouldDisableAds(),this.config.slots.bannerAd&&!this.disableAds&&(this.bannerAdHeight=this.useLargeBannerContainer?th.largeBannerAdContainerHeight:th.smallBannerAdContainerHeight)}await this.mapContentDataToProps(this.contentData),(0,x.D)()&&this.updateDataForKVP(),this.feedProps=this.getFeedData(),this.contentType=this.contentData.type,this.updateSponsoredArticleLayout(),this.isLoading=!1,this.enableLoadingState&&this.infiniteReadingContext?.updateInitialContentLoadingState?.(1),this.updateDocumentTitle(this.contentData.title),this.config?.featureFlags?.enableRubyConsumptionView&&this.loadRubyViewsMetaInfo(),(0,eO.S)()&&(0,eI.dT)().then(()=>{this.postTTVRCallback()}),this.resizeObserverBehavior(!0,!this.shouldRenderMobileATForDesktop),this.setDataClarityRegion(),this.isKeyTakeawaysEnabled()&&this.loadKeyTakeawaysData()}loadKeyTakeawaysData(){let e=(0,b.WG)(this.contentData?.stringAttributes?.key_takeaways_latest)??[];if(!e||0===e.length)return;this.keyTakeawaysData.push(...e);let t=(0,b.PE)(this.contentProps?.header?.viewsHeaderTelemetryContentData);t&&(this.keyTakeawaysTelemetryObjects=t),this.keyTakeawaysCollapsed=!this.config?.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot&&!this.isExplodedFeedContent,this.shouldRenderKeyTakeawaysSection()}async getCurrentContentData(){if(this.contentViewData)return this.contentViewData;let e=$.a.getCurrentData(this.contentId);if(e)return e;let t=this.isMainContent()?"Main":"Scroll";return(0,S.c)(this.contentId,!0,t)}setDataClarityRegion(){this.dataClarityRegion=this.contentType+(this.infiniteReadingContext?.scrollDepth||"")}updateDataForKVP(){if(!this.enableAdKeyValuePairs||!this.contentData)return;(0,T.O)();let e=(0,F.I)(this.contentData);this.infiniteReadingContext&&this.setAdsMetadata||!e||eQ.t.setMetadatas(e,this.config.featureFlags?.enableContentSpecificAdKvp?this.contentId:void 0),this.setAdsMetadata?.(this.contentId,e),P.js.getPromise(this.contentId,"display").then(()=>{this.loadDisplayAds()})}updateDocumentTitle(e){this.documentTitleCb&&"function"==typeof this.documentTitleCb&&(this.documentTitleCb=this.infiniteReadingContext?this.documentTitleCb.bind(this,e):this.documentTitleCb,this.isMainContent()&&this.documentTitleCb(e))}trackThirdParty(e){if(this.contentData?.type===a.i.Article){let t=this.config.componentConfigs?.articlePageConfig?.partnerThirdPartyTrackers;(0,B.Z)(e,this.contentId,t)}}createAdapterParams(e){let{provider:t,id:i,title:n,type:o}=e,r=(0,e5.E)(e,this.useTeraForVerticalData);return{...r,providerData:(0,I.Y)(t),entityId:i,entitySrc:s.t3.get(o)||"",contentTitle:n,verticalKey:r.vertical,categoryKey:r.category,teraVertical:r.teraVertical,teraCategory:r.teraCategory,overridePersistPageMetadata:!(0,c.G)(this.config.featureFlags||{},c.T.discardOverridenPageMetadata,!1)}}async initializeTracker(e,t){let{id:i,type:n}=e,o=new H.$(t),r=s.kw.get(n)||"video";if(this.infiniteReadingContext){o.pageUrl=this.infiniteReadingContext.baseContentUrl,o.referralUrl=this.infiniteReadingContext.referralUrl,o.pageType=s.Xh.get(r),o.pageName=D.v.getPageName(r,void 0,void 0,!0);let e=null;this.isMainContent()?this.inlineRefreshed&&(e=s.vt):e=this.infiniteReadingContext.pageOriginOverride||s.pJ,o.pageOrigin=e,h.I.addContentEntry(i,o.getMetadataOverride());let t=this.getInitializedPromise();if(t)try{await t}catch{return null}this.isFirstLoadedContent()||(0,p.OE)(i,this.getRequestIdOverride()),null!=this.infiniteReadingContext.linearFeedCardIndex?((0,p.ut)(i,"linearFeedDepth",`${this.infiniteReadingContext.linearFeedCardIndex}`),(0,p.ut)(i,"expandedFeedDepth",`${this.infiniteReadingContext.expandedFeedDepth}`)):(0,p.ut)(i,`${s.A6}-depth`,`${this.infiniteReadingContext.scrollDepth}`)}else(0,p.ut)(i,`${s.A6}-depth`,"1");return this.sendTelemetryPromiseWidgets&&(o.pageType=s.Xh.get(r),o.pageName=D.v.getPageName(r,void 0,void 0,!0),o.pageUrl=this.telemetryExtraDataWidgets?.url,o.referralUrl=this.telemetryExtraDataWidgets?.referralUrl,await this.sendTelemetryPromiseWidgets),o}async setupViewsTracker(e){let{provider:t,id:i}=e,n=this.createAdapterParams(e),o=await this.initializeTracker(e,n);!o||(this.tracker=o,this.previouslyInit||(await this.tracker.trackPageAsync(void 0,1,void 0,!0),this.trackThirdParty(t)),this.config?.featureFlags?.enableIsMonetized&&this.tracker.setIsMonetized(),this.infiniteReadingContext&&h.I.dwellTimeStart(i))}processExperienceInitializeError(){super.processExperienceInitializeError(),(0,b.Bs)(this.getExperienceType())}getExperienceType(){return o.m$j}stampSSRTmpl(){try{let e=window.isSSREnabled?"1":"0";(0,p.ut)(this.contentId,s.T7,e);let t=window.isSSRCompleted?"1":"0";(0,p.ut)(this.contentId,s.H5,t)}catch(e){}}updateActionTrayStyles(){window.requestAnimationFrame(()=>{this.actionTrayGridAreaStyles=this.getActionTrayGridAreaStyles(),this.actionTrayWrapperStyles=this.getActionTrayWrapperStyles()})}getActionTrayGridAreaStyles(){let e="";if(window.matchMedia("(max-width: 767px)").matches&&this.consumptionPageContentHeight){let t=this.consumptionPageContentRef?.offsetHeight||0;e+=`height: ${t+this.viewsHeaderHeight+this.bannerHeight}px`}return e}updateRightRailVisibility(){this.isRailBelow=this.shouldShowRailBelow(),this.isRailBelow?this.railBelowLoaded=!0:this.railRightLoaded=!0}shouldShowRailBelow(){return this.enableSponsoredArticleLayout?this.columnArrangement===J.j1.c1||this.columnArrangement===J.j1.c2:this.config.featureFlags?.enableExtendedRightRail?this.columnArrangement===J.j1.c1||window.matchMedia(`(max-width: ${(0,tu.c)(s.tK)})`).matches:this.columnArrangement===J.j1.c2||window.matchMedia(`(max-width: ${(0,tu.c)(s.kk)})`).matches}getVerticalCategory(e){return{vertical:(e&&(0,_.G)(e,this.useTeraForVerticalData).vertical)??"other",category:(e&&(0,_.G)(e,this.useTeraForVerticalData).category)??"other"}}isRiverDisabled(){let{feedWC:e}=this.config.slots,t=(0,c.G)(this.config.featureFlags||{},c.T.enableRubyConsumptionView,!1),i=!this.getMaxFeedRows()||this.isInfiniteScrollFeed();return!e||t||!i&&this.config.disableNonInfRiver}getFeedData(){if(this.isRiverDisabled())return;let{vertical:e,category:t}=this.getVerticalCategory(this.contentData),i=s.kw.get(this.contentData?.type||a.i.Article)||"article",n={contentID:this.contentId,enableNativeAdXandr:this.enableNativeAdXandr,enableInlineRefresh:this.enableInlineRefresh,isInlineRefreshed:this.inlineRefreshed,verticalKeyOverride:e,categoryKeyOverride:t,disableAds:this.disableAds,mappedPageType:this.config.nativeAdMappedPageType,partnerId:i,pageNumber:this.infiniteReadingContext?.scrollDepth||1,pageType:i};return n.maxVisibleRows=this.getMaxFeedRows(),n.isInfiniteScrollFeed=this.isInfiniteScrollFeed(),this.infiniteReadingAvailableCards&&(n.infiniteReadingCards=this.infiniteReadingAvailableCards),this.infiniteReadingContext&&this.infiniteReadingContext.infiniteReadingRiverHelper&&(n.infiniteReadingRiverHelper=this.infiniteReadingContext.infiniteReadingRiverHelper),n}getMaxFeedRows(){if(this.infiniteReadingDynamicProps?.hasInfiniteRiver)return;let e=(0,c.G)(this.config.featureFlags||{},c.T.enable2RowRiver),t=(0,c.G)(this.config.featureFlags||{},c.T.enableExtendedRiver);return e&&t&&this.columnArrangement===J.j1.c5?2:(0,b.Q4)(this.config.maxFeedRows,!this.isMainContent(),this.config.nextContentMaxFeedRows)}isMangaContent(){return this.isMainContent()?(0,b.MW)(new e0.bb):!!this.infiniteReadingContext?.baseContentUrl?.includes("/manga/")}updateSponsoredArticleLayout(){this.enableSponsoredArticleLayout=!!(this.config.sponsoredContent&&(0,eZ.G)()&&this.contentType===a.i.Article&&this.isMainContent())}isInfiniteScrollFeed(){return!!this.infiniteReadingDynamicProps?.hasInfiniteRiver}composeActionTrayProps(e){if(e)return{...e,moreActions:{...e.moreActions,refreshFeedCallback:this.removePageFromTheFeed},shouldShowStartAppCoachmark:this.config.shouldShowStartAppCoachmark,shouldRenderMobileATForDesktop:this.shouldRenderMobileATForDesktop,showFullFloatingBar:!!(this.config.featureFlags?.enableFloatingSocialBarFull&&this.shouldRenderMobileATForDesktop),disableAutoHide:!!(this.config.featureFlags?.enableFloatingSocialBarT2&&this.shouldRenderMobileATForDesktop),hideOnScroll:!!(this.config.featureFlags?.enableFloatingSocialBarT3&&this.shouldRenderMobileATForDesktop),noGradientFloatingBar:!!(this.config.featureFlags?.enableFloatingSocialBarNoGrad&&this.shouldRenderMobileATForDesktop)}}updateLeadgenData(e){this.shouldRenderEoabLeadgen=!!this.shouldRenderLeadgenEoab(e),this.shouldRenderEoabLeadgen&&!this.leadGenCardProps&&(this.leadGenCardProps=this.getLeadgenProps(e))}shouldRenderLeadgenEoab(e){return!this.config.sponsoredContent&&e.leadgen&&!this.config.noSSOLeadgenProviders?.includes(e.id||"")}getLeadgenProps(e){let t=this.config.componentConfigs?.endOfContentBlockConfigs?.slots?.endOfContentLeadGen,i=this.getLeadgen(e.id,e.leadgen);return t&&i?{cardWidthType:this.config.componentConfigs?.endOfContentBlockConfigs?.leadGenCardWidthType,experienceConfigInfo:{...t,instanceId:`${t.instanceId}-${this.contentId}`},contentId:this.contentId,publisherProfileId:e.profileId||"",leadgen:i,providerLogoUrl:this.contentProps?.header?.provider.logo?.src,useKumoDesign:this.config.featureFlags?.enableRubyConsumptionView}:void 0}getLeadgen(e="",t){return this.config.componentConfigs?.articlePageConfig?.leadGenProviders?this.config.componentConfigs?.articlePageConfig?.leadGenProviders.find(t=>t.providerId===e)?.leadgen:t}shouldEnableNativeAdXandr(){return(0,c.G)(this.config.featureFlags||{},c.T.enableNativeAdXandr)}shouldDisableAds(){let e=this.contentData;if(!e)return;let t=(0,_.G)(e,this.useTeraForVerticalData).category||"other";return this.isFeatureDisabled()||this.isCategoryDisabled(t)||this.isSensitiveTopic(e.facets)||this.isAdsDisabledByCitemParams()}isFeatureDisabled(){return(0,c.G)(this.config?.featureFlags,c.T.forceDisableAds)}isCategoryDisabled(e){return!!(e&&this.config.disAdsForCategs&&this.config.disAdsForCategs[e])}isSensitiveTopic(e){return e&&(0,b.Um)(e)}isAdsDisabledByCitemParams(){return ee.T3.IsDebug&&"true"===(0,eW.n)(ej.tn)}trySetTTVRAndMilestone(e,t){if(this.handleTtvrCallback&&this.handleTtvrCallback(this.contentId,e,t),this.isFirstLoadedContent()){if(this.markTimeToVisuallyReadyCalled||-1!==this.expTTVRDependentList.get(e))return}else if(this.contentType===a.i.Article&&e===s.xP.ArticleContent)return void this.markInfiniteReadingTTVRIfNeeded();this.expTTVRDependentList.set(e,t);let i=-1;for(let e of this.expTTVRDependentList.values()){if(-1===e)return;e>i&&(i=e)}super.markVisuallyReady(i),this.markGemP0TTVR?.(o.m$j,i),this.markTimeToVisuallyReadyCalled=!0,(0,E.Fy)(i)}buildSeoMetadata(){let e=this.contentProps?.content?.context,t=e?.articleData||e?.slideshowData;if(!t)return;let i="";if(t.imageResources?.length){let e=t.imageResources[0];i=e.url+`?w=${e.width}&h=${e.height}&m=4&q=${e.quality}`}return{title:t.title||"Microsoft News Article",description:t.abstract||"",image:i,publishedTime:(new Date(t.publishedDateTime).getTime()/1e3).toString(),updatedTime:(new Date(t.updatedDateTime).getTime()/1e3).toString(),originalUrl:this.infiniteReadingContext?.baseContentUrl||ee.T3?.HostPage?.originalUrl,section:this.getVerticalCategory(t).vertical||"",authors:t.authors?.map(e=>e.name),tags:t.keywords,locale:t.locale,disallowIndexing:!!t.seo?.disallowIndexing,canonicalAuthority:t.seo?.canonicalAuthority||"",canonicalUrl:t.seo?.canonicalUrl||"",twitterCardType:"summary_large_image",providerId:t.provider?.id}}async updateSeoTags(){if(!this.isMainContent())return;this.inlineRefreshed&&((0,M.gw)(),(0,O.mI)());let e=this.buildSeoMetadata();if(!e)return;let t=new V.W(e.providerId),i=await t.getFeatureOptionsAsync();(0,M.UE)(e),(0,O.Uh)(e.canonicalAuthority,e.canonicalUrl),(0,z.js)(e.disallowIndexing,i[V.Q.NoArchive])}async loadTopSpanModuleContent(){(0,c.G)(this.config.featureFlags,c.T.disableTopSpan)||(this.topSpanModuleContent=await this.getTopSpanModuleContent(!!this.viewsContentTopicId))}isTopSpanContentDisabled(e){if(!e)return!1;let t=this.config.componentConfigs?.topSpanConfig?.[e];return!!t&&!!(t?.disabledForVertical?.includes(this.contentProps?.topSpan?.vertical||"")||t?.disabledForCategory?.includes(this.contentProps?.topSpan?.category||""))}consumptionPageGridStructureStyles(e=!0){if(!e){this.gridOverriddenStyle="";return}if(this.isNotEnoughSizeForDesktopAT){let e=Math.floor((document.documentElement.clientWidth-s.X7)/2);this.gridOverriddenStyle=`grid-template-columns: ${(0,tu.c)(e)} ${(0,tu.c)(s.X7)} ${(0,tu.c)(e)};`}}async loadMoreFromProvider(){(this.config.featureFlags?.enableContentLeftRail||this.config.featureFlags?.enableHeaderDigestStrip)&&!this.isMainContent()&&this.infiniteReadingContext?.initializedPromise&&await this.infiniteReadingContext.initializedPromise,this.viewsFullPageConnector.hasFetchStarted(this.contentId)||this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),void 0,!1,!1,this.isLastContent);let e=await this.viewsFullPageConnector?.getMoreProvider(this.contentId);e?.[0]?.provider?(this.moreFromProviderData=e[0],this.moreFromProviderData&&await i.e("web-components_ruby-provider-links_dist_index_js-_1a410").then(i.bind(i,33017))):(0,W.vV)(j.$q6,"No provider data found for more from provider")}async loadTrendingNow(){if(!this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)return;let e=this.consumptionPageContentHeight;(0,eO.S)()&&this.consumptionPageContentRef&&(e=this.consumptionPageContentRef.getBoundingClientRect().height,this.consumptionPageContentHeight=e||this.consumptionPageContentHeight);let t=600*!!this.isRubyRightRailAds;if(e>0&&e-t<=376)return;this.viewsFullPageConnector.hasFetchStarted(this.contentId)||this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),void 0,!1,!1,this.isLastContent);let i=await this.viewsFullPageConnector?.getTrendingNow(this.contentId);i&&0!==i.length&&i[0]?.subCards&&0!==i[0].subCards.length?this.trendingNowData=i[0]:(0,W.vV)(j.$q6,"No trending now data found")}get vfpConnectorNoScrollContentCount(){return this.viewsFullPageConnector?.config?.noScrollClickCurve||!this.isMainContent()}}th.definition={shadowOptions:null},th.smallBannerAdContainerHeight=es+el+1,th.largeBannerAdContainerHeight=ec+el+1,(0,n.Cg)([eE.sH],th.prototype,"cardActionRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableBigRRAd",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableBigRRAdWithViewport",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableRubyStickyBanner",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableExtendedRRBreakpoints",void 0),(0,n.Cg)([eE.sH],th.prototype,"bigRRViewportValid",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableSponsoredArticleLayout",void 0),(0,n.Cg)([eE.sH],th.prototype,"tracker",void 0),(0,n.Cg)([eE.sH],th.prototype,"actionTrayGridAreaStyles",void 0),(0,n.Cg)([eE.sH],th.prototype,"actionTrayWrapperStyles",void 0),(0,n.Cg)([eE.sH],th.prototype,"bannerAdRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"columnArrangement",void 0),(0,n.Cg)([eE.sH],th.prototype,"commonHeaderHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageContentHeaderRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageContentHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageContentRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"trendingNowData",void 0),(0,n.Cg)([eE.sH],th.prototype,"moreFromProviderData",void 0),(0,n.Cg)([eE.sH],th.prototype,"isLastContent",void 0),(0,n.Cg)([eE.sH],th.prototype,"showOneRowContent",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageStructureRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"hasFullyScrolledMainContent",void 0),(0,n.Cg)([eE.sH],th.prototype,"consumptionPageViewsHeaderAreaRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"contentProps",void 0),(0,n.Cg)([eE.sH],th.prototype,"contentType",void 0),(0,n.Cg)([eE.sH],th.prototype,"dwellTimeStartAllowedClassName",void 0),(0,n.Cg)([eE.sH],th.prototype,"feedProps",void 0),(0,n.Cg)([eE.sH],th.prototype,"isImmersiveFullscreenOpen",void 0),(0,n.Cg)([eE.sH],th.prototype,"isRailBelow",void 0),(0,n.Cg)([eE.sH],th.prototype,"railBelowLoaded",void 0),(0,n.Cg)([eE.sH],th.prototype,"railRightLoaded",void 0),(0,n.Cg)([eE.sH],th.prototype,"topSpanModuleContent",void 0),(0,n.Cg)([eE.sH],th.prototype,"topSpanRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"viewsHeaderHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"viewsHeaderRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"dataClarityRegion",void 0),(0,n.Cg)([eE.sH],th.prototype,"viewsHeaderVisibilityChange",void 0),(0,n.Cg)([eE.sH],th.prototype,"bannerAdStart",void 0),(0,n.Cg)([eE.sH],th.prototype,"leadGenCardProps",void 0),(0,n.Cg)([eE.sH],th.prototype,"shouldRenderEoabLeadgen",void 0),(0,n.Cg)([eE.sH],th.prototype,"disableAds",void 0),(0,n.Cg)([eE.sH],th.prototype,"errorState",void 0),(0,n.Cg)([eE.sH],th.prototype,"mainBannerAdProps",void 0),(0,n.Cg)([eE.sH],th.prototype,"contentDetailInitialCall",void 0),(0,n.Cg)([eE.sH],th.prototype,"isOneRowContentReady",void 0),(0,n.Cg)([eE.sH],th.prototype,"bannerAdHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"bknewsBannerHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"visibleBannerAdHeight",void 0),(0,n.Cg)([eE.sH],th.prototype,"contentWrapperWidth",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableNativeAdXandr",void 0),(0,n.Cg)([eE.sH],th.prototype,"zhCnNativeAdsRefresh",void 0),(0,n.Cg)([eE.sH],th.prototype,"zhCnNativeAdsRefreshRate",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableDisplayAdKeyValuePairs",void 0),(0,n.Cg)([eE.sH],th.prototype,"delayDisplayAds",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableNativeAdKeyValuePairs",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableAdKeyValuePairs",void 0),(0,n.Cg)([eE.sH],th.prototype,"setAdsMetadata",void 0),(0,n.Cg)([eE.sH],th.prototype,"isLoading",void 0),(0,n.Cg)([eE.sH],th.prototype,"usePolishedStyles",void 0),(0,n.Cg)([eE.sH],th.prototype,"aboveRiverBlockData",void 0),(0,n.Cg)([eE.sH],th.prototype,"publishedDateStringFormat",void 0),(0,n.Cg)([eE.sH],th.prototype,"publishedDateTimeString",void 0),(0,n.Cg)([eE.sH],th.prototype,"publishedTimeStamp",void 0),(0,n.Cg)([eE.sH],th.prototype,"updatedDateStringFormat",void 0),(0,n.Cg)([eE.sH],th.prototype,"updatedDateTimeString",void 0),(0,n.Cg)([eE.sH],th.prototype,"updatedTimeStamp",void 0),(0,n.Cg)([(0,eM.CF)({mode:"boolean",attribute:"enable-ruby-article-flex"})],th.prototype,"enableRubyArticleFlex",void 0),(0,n.Cg)([eE.sH],th.prototype,"keyTakeawaysData",void 0),(0,n.Cg)([eE.sH],th.prototype,"keyTakeawaysCollapsed",void 0),(0,n.Cg)([eE.sH],th.prototype,"renderKeyTakeawaysSection",void 0),(0,n.Cg)([eE.sH],th.prototype,"markTimeToVisuallyReadyCalled",void 0),(0,n.Cg)([eE.sH],th.prototype,"isNewlyReplacedArticle",void 0),(0,n.Cg)([eE.sH],th.prototype,"enableConsumptionErrorPage",void 0),(0,n.Cg)([eE.sH],th.prototype,"redirectUrl",void 0),(0,n.Cg)([eE.sH],th.prototype,"commonHeaderRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"stabilizeBannerAdSize",void 0),(0,n.Cg)([eE.sH],th.prototype,"useLargeBannerContainer",void 0),(0,n.Cg)([eE.sH],th.prototype,"contentInitialized",void 0),(0,n.Cg)([eE.sH],th.prototype,"gridOverriddenStyle",void 0),(0,n.Cg)([eE.sH],th.prototype,"stickyBannerAdStyle",void 0),(0,n.Cg)([eE.sH],th.prototype,"stickyBannerSizeStyle",void 0),(0,n.Cg)([eE.sH],th.prototype,"shouldRenderMobileATForDesktop",void 0),(0,n.Cg)([eE.sH],th.prototype,"rubyRightRailRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"rubyRailBottomAdRef",void 0),(0,n.Cg)([eE.sH],th.prototype,"isOneRowContentHidden",void 0),(0,n.Cg)([eE.sH],th.prototype,"markGemP0TTVR",void 0),(0,n.Cg)([eE.sH],th.prototype,"conversationStartersIframeStyles",void 0),(0,n.Cg)([eE.sH],th.prototype,"displayCSAT",void 0),(0,n.Cg)([eE.sH],th.prototype,"csatDwellTimeThresholdMs",void 0),(0,n.Cg)([eE.Jg],th.prototype,"useRightRailMoreFromCard",null),(0,n.Cg)([eE.Jg],th.prototype,"bannerAdStyles",null),(0,n.Cg)([eE.Jg],th.prototype,"bkNewsStyles",null),(0,n.Cg)([eE.Jg],th.prototype,"riverHeadingClassnames",null),(0,n.Cg)([eE.Jg],th.prototype,"contentAreaClassname",null),(0,n.Cg)([eE.sH],th.prototype,"rubyStickyBannerClass",void 0),(0,n.Cg)([eE.Jg],th.prototype,"errorText",null),(0,n.Cg)([eE.Jg],th.prototype,"isRightRailReady",null),(0,n.Cg)([eE.Jg],th.prototype,"rightRailTopPosition",null),(0,n.Cg)([eE.Jg],th.prototype,"isRubyRightRail",null),(0,n.Cg)([eE.Jg],th.prototype,"isRubyRightRailSticky",null),(0,n.Cg)([eE.Jg],th.prototype,"isRRStickyForLinearFeed",null),(0,n.Cg)([eE.Jg],th.prototype,"isRubyRightRailAds",null),(0,n.Cg)([eE.Jg],th.prototype,"consumptionPageContentHeaderStyles",null),(0,n.Cg)([eE.Jg],th.prototype,"bannerHeight",null),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderActionTray",null),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderActionBar",null),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderMobileActionTray",null),(0,n.Cg)([eE.Jg],th.prototype,"deferRenderingRiver",null),(0,n.Cg)([eE.Jg],th.prototype,"hideRiver",null),(0,n.Cg)([eE.sH],th.prototype,"isWPORiverFailed",void 0),(0,n.Cg)([eE.sH],th.prototype,"noCopilotAPI",void 0),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderAIConversationStarters",null),(0,n.Cg)([eE.sH],th.prototype,"showNativeAdBanner",void 0),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderBannerAd",null),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderBannerAdAboveHeadline",null),(0,n.Cg)([eE.Jg],th.prototype,"shouldRenderBannerAdBelowHeadline",null);var tm=i(89757),tb=i(69259),tf=i(60402),ty=i(68835),tv=i(92011);let tw=(0,tm.qy)`<div id=${e=>`${(0,b.N7)(e.props?.id||"")}-star-rating-observer`}></div>`,tx=(0,tm.qy)`<div class="article-content">${(0,tb.z)(e=>e.props?.context,(0,tm.qy)`<msn-article-page :articleId="${e=>e.props?.id}" :config="${e=>e.config}" :slideshowConfig=${e=>e.slideshowConfig} :localizedStrings="${e=>e.localizedStrings}" :infiniteReadingContext="${e=>(e.props?.context).infiniteReadingContext}" :infiniteReadingDynamicProps="${e=>(e.props?.context).infiniteReadingDynamicProps}" :stampPagePZeroTTVR="${e=>e.stampPagePZeroTTVR}" :handleFatalError="${e=>e.handleFatalError}" :onToggleImmersiveFullscreen="${e=>(e.props?.context).onToggleImmersiveFullscreen}" :articleData="${e=>(e.props?.context).articleData}" :rootTelemetryObject="${e=>e.rootTelemetryObject}" :disableAds="${e=>(e.props?.context).disableAds||(e.config?.featureFlags?.isSponsoredContent??!1)&&(0,eZ.G)()}" :shouldRenderEoabLeadgen="${e=>e.shouldRenderEoabLeadgen}" :providerLogoUrl=${e=>e.providerLogoUrl} :enableNativeAdXandr="${e=>(e.props?.context).enableNativeAdXandr}" :getNextContentCard="${e=>e.getNextContentCard}" :commonHeaderRef=${e=>e.commonHeaderRef} :trackingAdapter="${e=>e.trackingAdapter}" :rubyRightRailAdPxBottom=${e=>e.rubyRightRailAdPxBottom} :enableRubyArticleFlex=${e=>e.enableRubyArticleFlex} :unhideEocbCallback=${e=>e.unhideEocbCallback} :unhideRiverCallback=${e=>e.unhideRiverCallback} :useTeraForVerticalData=${e=>e.useTeraForVerticalData} :contentInfoForAd=${e=>e.contentInfoForAd} :skipInitialRenderingVisibilityCheckForAds=${e=>e.skipInitialRenderingVisibilityCheckForAds} :enableSponsoredEocbAd="${e=>(e.config?.featureFlags?.enableSponsoredEocbAd??!1)&&(0,eZ.G)()}" :sponsoredEocbAdSlot="${e=>e.config?.featureFlags?.isSponsoredContent&&(0,eZ.G)()?e.config?.slots?.sponsoredEocbAdWC:void 0}"></msn-article-page>`)}</div>${tw}
`;class tC extends tv.L{constructor(){super(...arguments),this.skipInitialRenderingVisibilityCheckForAds=!1}connectedCallback(){super.connectedCallback()}}(0,n.Cg)([eE.sH],tC.prototype,"props",void 0),(0,n.Cg)([eE.sH],tC.prototype,"config",void 0),(0,n.Cg)([eE.sH],tC.prototype,"localizedStrings",void 0),(0,n.Cg)([eE.sH],tC.prototype,"rootTelemetryObject",void 0),(0,n.Cg)([eE.sH],tC.prototype,"stampPagePZeroTTVR",void 0),(0,n.Cg)([eE.sH],tC.prototype,"shouldRenderEoabLeadgen",void 0),(0,n.Cg)([eE.sH],tC.prototype,"providerLogoUrl",void 0),(0,n.Cg)([eE.sH],tC.prototype,"handleFatalError",void 0),(0,n.Cg)([eE.sH],tC.prototype,"slideshowConfig",void 0),(0,n.Cg)([eE.sH],tC.prototype,"getNextContentCard",void 0),(0,n.Cg)([eE.sH],tC.prototype,"commonHeaderRef",void 0),(0,n.Cg)([eE.sH],tC.prototype,"trackingAdapter",void 0),(0,n.Cg)([eE.sH],tC.prototype,"rubyRightRailAdPxBottom",void 0),(0,n.Cg)([eE.sH],tC.prototype,"enableRubyArticleFlex",void 0),(0,n.Cg)([eE.sH],tC.prototype,"unhideEocbCallback",void 0),(0,n.Cg)([eE.sH],tC.prototype,"unhideRiverCallback",void 0),(0,n.Cg)([eE.sH],tC.prototype,"useTeraForVerticalData",void 0),(0,n.Cg)([eE.sH],tC.prototype,"contentInfoForAd",void 0),(0,n.Cg)([eE.sH],tC.prototype,"skipInitialRenderingVisibilityCheckForAds",void 0);let tR=class extends tC{};tR=(0,n.Cg)([(0,tv.E)({name:"desktop-article-content",template:tx,shadowOptions:null})],tR);var tA=i(59669);let tk=(0,tA.A)` :host(.hidden){display:none}social-lead-gen-in-article{margin-bottom:16px}`;var t$=i(94172);let tS=(0,tm.qy)` ${(0,tb.z)(e=>e.leadGenCardProps,(0,tm.qy)` ${e=>(0,t$.yN)(e.leadGenCardProps?.experienceConfigInfo,{properties:e.leadGenCardProps})} `)}
`,tT=(0,tm.qy)` ${(0,tb.z)(e=>e.eocbEntrypointProps,(0,tm.qy)` ${e=>(0,t$.yN)(e.eocbEntrypointProps?.config,{properties:e.eocbEntrypointProps?.properties})} `)}
`,tF=(0,tm.qy)`<div slot="${e=>e.contentId}-more-from-provider"><ruby-provider-links :collapsible=${e=>e.collapsible} :cardTitleString=${e=>e.moreFromProviderTitle} :moreFromProviderData=${e=>e.moreFromProviderData} :contentId=${e=>e.contentId}></ruby-provider-links></div>`,tP=(0,tm.qy)` ${(0,tb.z)(e=>e.shouldRenderEoabLeadgen,tS,tT)} ${(0,tb.z)(e=>e.moreFromProviderData&&!e.useSponsoredLayout,tF)}
`;class tB extends tv.L{constructor(){super(...arguments),this.loadState=0,this.shouldRenderEoabLeadgen=!1}leadGenCardPropsChanged(){this.leadGenCardProps&&(this.loadState=1)}configChanged(){this.socialEntrypointConfig||(this.socialEntrypointConfig=this.config.slots.endOfContentSocialEntrypoint),tt(this.config.slots,this.contentId),this.config?.enableSocialDataConnector&&e4.V.getInstance().rootReducer.getDataConnector(r.eX).then(e=>{this.socialDataConnector=e,e||L.YT.sendAppErrorEvent({...j.okg,message:"Social data connector not found in the root reducer",pb:{...j.okg.pb,customMessage:"Social data connector not found in the root reducer"}})}),this.loadState=1}get useSponsoredLayout(){return!!this.config?.sponsoredContent&&(0,eZ.G)()}get eocbEntrypointProps(){return this.contentId&&this.socialEntrypointConfig?{config:{...this.socialEntrypointConfig,instanceId:this.socialEntrypointConfig+"-"+this.contentId},properties:{contentId:this.contentId,topicId:this.contentId,category:this.category,isShowAsInfoSpan:!1,isShowAsEmbeddedCard:!0}}:null}}(0,n.Cg)([(0,eM.CF)({attribute:"content-id"})],tB.prototype,"contentId",void 0),(0,n.Cg)([eM.CF],tB.prototype,"vertical",void 0),(0,n.Cg)([eM.CF],tB.prototype,"category",void 0),(0,n.Cg)([eE.sH],tB.prototype,"columnView",void 0),(0,n.Cg)([eE.sH],tB.prototype,"loadState",void 0),(0,n.Cg)([eE.sH],tB.prototype,"isImmersiveFullscreenOpen",void 0),(0,n.Cg)([eE.sH],tB.prototype,"shouldRenderEoabLeadgen",void 0),(0,n.Cg)([eE.sH],tB.prototype,"leadGenCardProps",void 0),(0,n.Cg)([eE.sH],tB.prototype,"socialEntrypointConfig",void 0),(0,n.Cg)([eE.sH],tB.prototype,"moreFromProviderData",void 0),(0,n.Cg)([eE.sH],tB.prototype,"collapsible",void 0),(0,n.Cg)([eE.sH],tB.prototype,"moreFromProviderTitle",void 0),(0,n.Cg)([eE.sH],tB.prototype,"config",void 0),(0,n.Cg)([eE.Jg],tB.prototype,"useSponsoredLayout",null),(0,n.Cg)([eE.Jg],tB.prototype,"eocbEntrypointProps",null);let tI=class extends tB{};tI=(0,n.Cg)([(0,tv.E)({name:"desktop-end-of-content-block",template:tP,styles:tk})],tI);let tH=(0,tA.A)`
`;function tD(e,t){return 1===t?e:(0,tm.qy)`<div></div>`}let t_=(0,tm.qy)`<gallery-slideshow :overrideContentUrl=${e=>e.overrideContentUrl} :baseProps=${e=>e.slideshowProps} :onOpenImmersiveCallback=${e=>e.context?.onToggleImmersiveFullscreen} :enableRubyConsumptionView=${e=>e.enableRubyConsumptionView} :enableRubyProngView=${e=>e.enableRubyProngView} :enableWidgetsConsumptionView=${e=>e.enableWidgetsConsumptionView} :leadGenCardProps=${e=>e.leadGenCardProps} :shouldRenderEoabLeadgen=${e=>e.shouldRenderEoabLeadgen} :moreFromProviderData=${e=>(0,b.BZ)(e.moreFromProviderData)} :moreFromProviderTitle=${e=>e.moreFromProviderTitle}></gallery-slideshow>`,tE=(0,tm.qy)` ${e=>(0,t$.yN)(e.config.slots.immersiveFullscreen,{properties:{slideshowProps:e.fullscreenSlideshowProps,onCloseCallback:e.context?.onToggleImmersiveFullscreen}})}
`,tM=(0,tm.qy)`<div id=${e=>`${(0,b.N7)(e.props.id)}-star-rating-observer`}></div>`,tO=(0,tm.qy)` ${tM} ${(0,tb.z)(e=>e.isImmersiveFullscreenOpen,tE,t_)}
`,tV=(0,tm.qy)` ${e=>tD(tO,e.loadState)}
`;var tz=i(74395),tL=i(49523);class tN extends tv.L{constructor(){super(...arguments),this.loadState=0,this.enableRubyConsumptionView=!1,this.enableRubyProngView=!1,this.enableWidgetsConsumptionView=!1,this.shouldRenderEoabLeadgen=!1}connectedCallback(){super.connectedCallback(),tt(this.config.slots,this.props.id),this.context=this.props.context;let e={contentId:this.props.id,parentContentId:this.props.id,contentPageType:"gallery",parentPageType:"gallery",mappedPageType:this.context.mappedPageType,strings:this.localizedStrings,infiniteReadingContext:this.context.infiniteReadingContext,nextSlideshowPromise:this.context.nextSlideshowPromise,providerId:this.context.slideshowData.provider?.id,disableAds:this.context.disableAds,enableDisplayAdsSlideshowRefresh:(0,c.G)(this.config.featureFlags,c.T.enableDspAdsRefresh),enableSlidePreload:(0,c.G)(this.config.featureFlags,c.T.enableSlidePreload),relativeInterstitialIndex:(0,c.G)(this.config.featureFlags,c.T.relativeInterstitialIndex),passUnstableGalleryAdSignal:(0,c.G)(this.config.featureFlags,c.T.passUnstableGalleryAdSignal),isStableGAInterstitialAds:this.context.isStableGAInterstitialAds,adServiceConfig:this.config.adServiceConfig,passAdOcidRegSize:this.config.passAdOcidRegSize,enableAddingAdCoords:this.config.enableAddingAdCoords,adTemplateConfig:this.config.adTemplateConfig,adBeaconServiceConfig:this.config.adBeaconServiceConfig,disableImageHashDeeplink:this.config.disableImageHashDeeplink,enableAdLayoutChange:(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange),enableAdFullBleed:(0,c.G)(this.config.featureFlags,c.T.enableAdFullBleed),enableAdSponsoredText:(0,c.G)(this.config.featureFlags,c.T.enableAdSponsoredText),enableContainerBasedImgSizing:(0,c.G)(this.config.featureFlags,c.T.enableContainerBasedImgSizing),enableAdFeedback:this.config.enableAdFeedback,preventDisplayAdRefresh:this.config.preventDisplayAdRefresh,enableRubyVerticalAds:(0,c.G)(this.config.featureFlags,c.T.enableRubyVerticalAds)&&(0,eG.l)(),enableAdNewRubyGalleryT1:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT1)&&(0,eG.l)(),enableAdNewRubyGalleryT2:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT2)&&(0,eG.l)(),enableAdNewRubyGalleryT3:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT3)&&(0,eG.l)(),isIASEnabled:(0,c.G)(this.config.featureFlags,c.T.isIASEnabled),enableDVRubyGalleryAd:(0,c.G)(this.config.featureFlags,c.T.enableDVRubyGalleryAd),enableAdChoiceInCardActions:(0,c.G)(this.config.featureFlags,c.T.enableAdChoiceInCardActions),isThumbnailStripOnTop:(0,c.G)(this.config.featureFlags,c.T.isThumbnailStripOnTop),enableStackedGalleryLayout:(0,c.G)(this.config.featureFlags,c.T.enableStackedGalleryLayout),enableClassicGAHoverEffect:(0,c.G)(this.config.featureFlags,c.T.enableClassicGAHoverEffect),enableInsideFlippers:(0,c.G)(this.config.featureFlags,c.T.enableInsideFlippers)};this.slideshowProps={...e,slideshowData:this.slideshowData,autorotateTimeInMs:this.autorotateTimeInMs,zhCnNativeAdsRefreshRate:this.config.zhCnNativeAdsRefreshRate,autorotateAdRfshRate:this.config.autorotateAdRfshRate,enableNativeAdXandr:this.context.enableNativeAdXandr,zhCnNativeAdsRefresh:this.context.zhCnNativeAdsRefresh,disableSlideClick:(0,c.G)(this.config.featureFlags,c.T.disableSlideClick),enableAutorotate:(0,c.G)(this.config.featureFlags,c.T.enableAutorotate),enableDynamicAutorotate:(0,c.G)(this.config.featureFlags,c.T.dynamicAutorotate),enableWpoDynamicAutorotate:(0,c.G)(this.config.featureFlags,c.T.wpoDynamicAutorotate),autorotateOffByDefault:(0,c.G)(this.config.featureFlags,c.T.autorotateOffByDefault),enableExtendedArrowHitbox:(0,c.G)(this.config.featureFlags,c.T.enableExtendedArrowHitbox),enableImmersiveFullscreen:(0,c.G)(this.config.featureFlags,c.T.enableImmersiveFullscreen),enableImmersiveOnClick:(0,c.G)(this.config.featureFlags,c.T.enableImmersiveOnClick),useFullSizeAdCards:(0,c.G)(this.config.featureFlags,c.T.galleryFullAdCards),useFullWidthOnFiveCol:(0,c.G)(this.config.featureFlags,c.T.useFullWidthOnFiveCol),enableRubyNextSlideshow:(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard)&&this.enableRubyConsumptionView,enableLeftRailStyleOverride:this.enableRubyConsumptionView&&((0,c.G)(this.config.featureFlags,c.T.enableContentLeftRail)||(0,c.G)(this.config.featureFlags,c.T.enableLeftRailStyleOverride)),autorotateNextSlideshow:(0,c.G)(this.config.featureFlags,c.T.autorotateNextSlideshow)},this.fullscreenSlideshowProps={...e,slideshowData:this.slideshowFullscreenData,fullScreenSlots:this.config.fullScreenSlideshowSettings.slots,zhCnNativeAdsRefresh:this.context.zhCnNativeAdsRefresh,zhCnNativeAdsRefreshRate:this.config.zhCnNativeAdsRefreshRate,telemetryOverrides:{pageName:tz.$.ImmersiveGallery}},this.loadState=1}get slideshowData(){return(0,tL.h)(this.config.slideshowSettings.imageSettings,this.config.slideshowSettings.thumbnailImageSettings,this.config.slideshowSettings.interstitialNativeAds,(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange)?"":this.localizedStrings?.adSlideMetadataText||"",this.localizedStrings?.adSlideMetadataTitleText||"",this.context?.slideshowData,this.props.id,this.context?.disableAds,(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard),(0,c.G)(this.config.featureFlags,c.T.enableAdThumbnail),!1,this.enableRubyConsumptionView,(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT1)&&(0,eG.l)(),(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT2)&&(0,eG.l)(),(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT3)&&(0,eG.l)(),this.useTeraForVerticalData)}get slideshowFullscreenData(){return(0,tL.h)(this.config.fullScreenSlideshowSettings.imageSettings,this.config.fullScreenSlideshowSettings.thumbnailImageSettings,this.config.fullScreenSlideshowSettings.interstitialNativeAds,(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange)?"":this.localizedStrings?.adSlideMetadataText||"",this.localizedStrings?.adSlideMetadataTitleText||"",this.context?.slideshowData,this.props.id,this.context?.disableAds,(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard),(0,c.G)(this.config.featureFlags,c.T.enableAdThumbnail),!1,!1,!1,!1,!1,this.useTeraForVerticalData)}get autorotateTimeInMs(){if(!(0,c.G)(this.config.featureFlags,c.T.enableAutorotate))return;let e=this.config.autorotateTimeInMs,t=(0,eW.n)(ej.k0);return t&&(e=parseInt(t,10)),e}}(0,n.Cg)([eE.sH],tN.prototype,"isImmersiveFullscreenOpen",void 0),(0,n.Cg)([eE.sH],tN.prototype,"context",void 0),(0,n.Cg)([eE.sH],tN.prototype,"slideshowProps",void 0),(0,n.Cg)([eE.sH],tN.prototype,"fullscreenSlideshowProps",void 0),(0,n.Cg)([eE.sH],tN.prototype,"loadState",void 0),(0,n.Cg)([eE.sH],tN.prototype,"enableRubyConsumptionView",void 0),(0,n.Cg)([eE.sH],tN.prototype,"enableRubyProngView",void 0),(0,n.Cg)([eE.sH],tN.prototype,"enableWidgetsConsumptionView",void 0),(0,n.Cg)([eE.sH],tN.prototype,"shouldRenderEoabLeadgen",void 0),(0,n.Cg)([eE.sH],tN.prototype,"leadGenCardProps",void 0),(0,n.Cg)([eE.sH],tN.prototype,"moreFromProviderData",void 0),(0,n.Cg)([eE.sH],tN.prototype,"moreFromProviderTitle",void 0);let tG=class extends tN{};tG=(0,n.Cg)([(0,tv.E)({name:"desktop-gallery-content",template:tV,styles:tH,shadowOptions:null})],tG);let tW=(0,tA.A)`
`,tj=(0,tm.qy)`<manga-page-wc :contentId=${e=>e.props.id} :contentPageType=${e=>e.contentPageType} :localizedStrings=${e=>e.mangaPageLocalizedStrings} :infiniteReadingContext=${e=>e.context.infiniteReadingContext} :parentTelemetryObject=${e=>e.rootTelemetryObject} :slideshowData=${e=>e.slideshowData}></manga-page-wc>`,tq=(0,tm.qy)` ${e=>tD(tj,e.loadState)}
`;class tU extends tv.L{constructor(){super(...arguments),this.loadState=0,this.useWebPImageFormat=!1}connectedCallback(){super.connectedCallback(),tt(this.config.slots,this.props.id),this.context=this.props.context,this.contentPageType="gallery",this.parentPageType="gallery",this.useWebPImageFormat=(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),this.prepareSlideshowSettings(),this.loadState=1}prepareSlideshowSettings(){this.slideshowData=(0,tL.h)(this.config.slideshowSettings.imageSettings,this.config.slideshowSettings.thumbnailImageSettings,this.config.slideshowSettings.interstitialNativeAds,this.slideshowStrings?.adSlideMetadataText||"",this.slideshowStrings?.adSlideMetadataTitleText||"",this.context.slideshowData,this.props.id,this.context.disableAds,this.useWebPImageFormat,void 0,(0,c.G)(this.config.featureFlags,c.T.enableAutorotate),this.config.slideshowSettings.showMangaChapterList,!1,!1,!1,!1,this.useTeraForVerticalData)}}(0,n.Cg)([eE.sH],tU.prototype,"rootTelemetryObject",void 0),(0,n.Cg)([eE.sH],tU.prototype,"stampPagePZeroTTVR",void 0),(0,n.Cg)([eE.sH],tU.prototype,"shouldRenderEoabLeadgen",void 0),(0,n.Cg)([eE.sH],tU.prototype,"isImmersiveFullscreenOpen",void 0),(0,n.Cg)([eE.sH],tU.prototype,"loadState",void 0),(0,n.Cg)([eE.sH],tU.prototype,"mangaPageLocalizedStrings",void 0),(0,n.Cg)([eE.sH],tU.prototype,"slideshowStrings",void 0),(0,n.Cg)([eE.sH],tU.prototype,"slideshowData",void 0),(0,n.Cg)([eE.sH],tU.prototype,"slideshowFullscreenData",void 0);let tK=class extends tU{};tK=(0,n.Cg)([(0,tv.E)({name:"manga-content",template:tq,styles:tW,shadowOptions:null})],tK);let tX=(0,tA.A)` .video-content{aspect-ratio:16 / 9;width:100%}.ruby-video .video-content{border-radius:48px;overflow:hidden}.video-meta{margin-top:20px;font-size:14px}.video-abstract{margin-top:20px}.ruby-video .video-meta,.ruby-video .video-abstract{margin-inline:auto}.ruby-video .byline-under-title{margin:16px 0;max-width:100%}.action-bar-under-title social-bar-wc{flex-grow:0}.ruby-video .video-abstract{font-size:18px;font-weight:400;line-height:28px;font-family:var(--body-font)}.prong-ruby-consumption-video{max-width:var(--ruby-article-flex-max-width,624px);margin:0 auto}${(0,J.H5)(J.j1.c2)}{.ruby-video:not(.gem-video){width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)});margin-inline:auto}}${(0,J.H5)(J.j1.c1)}{.ruby-video .video-meta,.ruby-video .video-abstract{max-width:min(var(--ruby-article-flex-max-width,452px),100%)}.ruby-video .byline-under-title{margin:16px auto}}`;i(21627).c;let tY=(0,tm.qy)`<ruby-views-action-bar class="eocb ${e=>e.enableMoveBylineAndActionBar?"action-bar-under-title":""}" contentId=${e=>e.actionBarData?.contentId} locale=${e=>e.actionBarData?.locale} :config=${e=>e.actionBarData?.config} :templateType=${"eocb"} :localizedStrings=${e=>e.actionBarData?.localizedStrings} :props=${e=>e.actionBarData?.actionTrayProps} :providerName=${e=>e.actionBarData?.providerName} :providerLogoUrl=${e=>e.actionBarData?.providerLogoUrl} :updatedTimeStampFormat=${e=>e.actionBarData?.updatedTimeStampFormat} :shareUrl=${e=>e.actionBarData?.shareUrl} :enableMoveBylinePosition=${e=>e.enableMoveBylineAndActionBar}></ruby-views-action-bar>`,tZ=(0,tm.qy)`<div class=${e=>(0,eD.x)("video-content-wrapper",["prong-ruby-consumption-video",e.enableRubyProngView],["ruby-video",e.enableRubyConsumptionView],["gem-video",e.enableRubyGemView])}>${(0,tb.z)(e=>e.enableMoveBylineAndActionBar,(0,tm.qy)`<div class="video-meta byline-under-title"><span>${e=>e.publishedDateStringFormat}</span></div>`)} ${(0,tb.z)(e=>e.enableMoveBylineAndActionBar&&e.showActionBar,tY)}<div class="video-content">${e=>(0,t$.yN)((0,b.j1)(e.config.slots.content,`${e.config.slots.content.instanceId}-${e.props.id}`),{properties:e.videoCardProps})}</div>${(0,tb.z)(e=>e.enableRubyConsumptionView&&!e.enableMoveBylineAndActionBar,(0,tm.qy)`<div class="video-meta"><span>${e=>e.publishedDateStringFormat}</span></div>`)} ${(0,tb.z)(e=>!!e.abstract,(0,tm.qy)`<div class="video-abstract"><text-inline-expander :text=${e=>e.abstract} :strings=${e=>e.getLocalizedStringsToTextInlineStrings()} :lineCountClampSeeMore=${e=>e.config.abstractLineClamp} :shouldSeeMoreBelowText=${!0}></text-inline-expander></div>`)}</div>`,tJ=(0,tm.qy)`${e=>tD(tZ,e.loadState)}`;var tQ=i(54863);class t0 extends tv.L{constructor(){super(...arguments),this.loadState=0,this.enableRubyConsumptionView=!1,this.enableRubyGemView=!1,this.enableRubyProngView=!1,this.enableMoveBylineAndActionBar=!1,this.showActionBar=!1}connectedCallback(){super.connectedCallback(),tt(this.config.slots,this.props.id),this.loadState=1}getLocalizedStringsToTextInlineStrings(){return{seeLess:this.localizedStrings?.seeLessDescriptionLabel||"",seeMore:this.localizedStrings?.seeMoreDescriptionLabel||""}}get abstract(){let e=this.props.context.videoData.abstract||"";return(0,tQ.wR)(e)}get videoCardProps(){let e=this.props.context?.videoData;if(e.type===a.i.Video)return this.props;if(e.type===a.i.Webcontent){let{id:t,provider:i,sourceHref:n,title:o}=e;return{...this.props,id:n,context:{...this.props.context,autoplay:!0,directEmbedMediaPlayerProps:{rid:t,provider:i.name,title:o,providerId:i.id,metadata:{category:this.props.context.category,vertical:this.props.context.vertical},playerUrl:n},isAutoPlayEnabledForWebContent:!0,startVideoPositionSec:0}}}}}(0,n.Cg)([eE.sH],t0.prototype,"loadState",void 0),(0,n.Cg)([eE.sH],t0.prototype,"enableRubyConsumptionView",void 0),(0,n.Cg)([eE.sH],t0.prototype,"enableRubyGemView",void 0),(0,n.Cg)([eE.sH],t0.prototype,"enableRubyProngView",void 0),(0,n.Cg)([eE.sH],t0.prototype,"publishedDateStringFormat",void 0),(0,n.Cg)([eE.sH],t0.prototype,"enableMoveBylineAndActionBar",void 0),(0,n.Cg)([eE.sH],t0.prototype,"showActionBar",void 0),(0,n.Cg)([eE.sH],t0.prototype,"actionBarData",void 0),(0,n.Cg)([eE.Jg],t0.prototype,"abstract",null),(0,n.Cg)([eE.Jg],t0.prototype,"videoCardProps",null);let t1=class extends t0{};t1=(0,n.Cg)([(0,tv.E)({name:"video-content",template:tJ,styles:tX,shadowOptions:null})],t1);var t2=i(94462),t5=i(29158),t3=i(16378),t6=i(57996);t2.w,t3.x,t6._,t5._,(0,eO.S)()&&(0,eI.dT)().then(async()=>{let{ContentCardListicle:e}=await Promise.all([i.e("common-feed-libs"),i.e("web-components_content-card-listicle_dist_index_js-_d5552")]).then(i.bind(i,69338));return e});let t4=(0,tm.qy)`${e=>(0,t$.yN)(e.config.slots.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:"00000",surveyTemplate:"feed-level",cardType:"feed-level",displayDelayMs:e.csatDwellTimeThresholdMs,autoDismissEvent:e.config.dismissCSATOnScroll?R.Z7:void 0}})}`,t8=(0,tm.qy)`<ruby-views-trending-now slot="content" :trendingNowData=${e=>e.trendingNowData} :trendingNowRefreshIcon=${ei} :rootTelemetryObject=${e=>e.telemetryObject}></ruby-views-trending-now>`,t9=(0,tm.qy)`<div class="breaking-news-banner-wrap" style=${e=>e.bkNewsStyles}><div class="breaking-news-banner">${e=>(0,t$.yN)(e.config.slots.breakingNews,{properties:{currentContentId:e.contentId,breakingNewsWillRender:e.breakingNewsWillRender}})}</div></div>`,t7=(0,tm.qy)`${e=>(0,t$.yN)(e.config.slots.toastWC)}`,ie=(0,tm.qy)`<div class=${e=>(0,eD.x)("consumption-page-banner-ad",["below-headline","belowHeadline"===e.config.bannerAdPosition],["above-headline","aboveHeadline"===e.config.bannerAdPosition],["responsive-banner-ads",!!e.config.enableResponsiveBannerAds])} id=${e=>e.mainBannerAdProps?.id??e.contentProps?.bannerAd?.id}>${(0,tb.z)(e=>e.config.slots.bannerAd&&(e.isMainContent()&&e.mainBannerAdProps||e.contentProps?.bannerAd)&&!e.disableAds&&(0,eO.S)(),e=>(0,t$.yN)(e.config.slots.bannerAd,{properties:e.bannerAdConfig,memoize:!1}))}</div>`,it=(0,tm.qy)`<div class=${e=>(0,eD.x)("consumption-page-banner-wrapper",["below-headline","belowHeadline"===e.config.bannerAdPosition],["above-headline","aboveHeadline"===e.config.bannerAdPosition],[e.rubyStickyBannerClass,!!e.config.enableRubyStickyBanner],["responsive-banner-ads",!!e.config.enableResponsiveBannerAds])} style=${e=>`${e.config.featureFlags?.enableRubyDisplayAds?"":`${e.bannerAdStyles}background-color: var(--banner-background);`}`} slot=${e=>e.config.featureFlags?.enableRubyDisplayAds&&"belowHeadline"===e.config.bannerAdPosition?"header-slot":""} ${(0,tf.K)("bannerAdRef")}>${(0,tb.z)(e=>!!e.config.slots.bannerAd&&!e.disableAds,ie)}</div>`,ii=(0,tm.qy)`<div class="native-ad-banner-wrapper"><div class="native-ad-banner intra-article-ad-full-ruby">${e=>e.config?.slots?.bannerNativeAd&&(0,t$.yN)((0,b.j1)(e.config.slots.bannerNativeAd,"winlinear-article-inline-1"),{properties:{...e.getArticleBannerAdProperties(e.config)}})}</div></div>`,io=(0,tm.qy)` ${e=>(0,t$.yN)(e.config.slots.commentsWC,{properties:{contentId:e.contentId,topicId:e.contentId,useRubyStyles:!0,useConsumptionCopilotStyles:!0}})}
`,ir=e=>(0,tm.qy)`<ruby-views-action-bar slot=${"head"===e?"action-bar":""} class="${t=>(0,eD.x)(["no-border","head"===e&&t.contentType===a.i.Gallery],["head","head"===e],["eocb","eocb"===e],["below-byline","head"===e&&!!t.config.featureFlags?.enableMoveBylinePosition])}" contentId=${e=>e.contentId} locale=${e=>e.contentData?.locale} :config=${e=>e.config.componentConfigs?.viewsHeaderConfigs} :templateType=${t=>e} :localizedStrings=${e=>e.actionBarStrings} :props=${e=>e.contentProps?.actionTray} :providerName=${e=>e.contentProps?.header?.provider.name} :providerLogoUrl=${e=>e.contentProps?.header?.provider.logo?.src} :updatedTimeStampFormat=${e=>e.publishedTimeStamp} :shareUrl=${e=>e.shareUrl} :enableAlignLeft=${e=>e.config.featureFlags?.enableAlignLeft}></ruby-views-action-bar>`,ia=(0,tm.qy)`<div class=${e=>e.consumptionPageContentHeaderStyles} ${(0,tf.K)("consumptionPageContentHeaderRef")}><ruby-views-header :contentId=${e=>e.contentProps?.header?.contentId} :config=${e=>e.config.componentConfigs?.viewsHeaderConfigs} :isOpinion=${e=>e.contentProps?.header?.isOpinion} :localizedStrings=${e=>e.config.localizedStrings?.viewsHeader} :visualReadinessCallback=${e=>e.stampPagePZeroTTVR} :enablePublisherFlyout=${e=>e.contentProps?.header?.enablePublisherFlyout} :providerId=${e=>e.contentProps?.header?.provider.id} :providerLogoUrl=${e=>e.contentProps?.header?.provider.logo?.src} :providerName=${e=>e.contentProps?.header?.provider.name} :providerProfileId=${e=>e.contentProps?.header?.provider.profileId} :providerUrl=${e=>e.contentProps?.header?.provider.url} :publishedDateStringFormat=${e=>e.publishedDateStringFormat} :publishedDateTimeString=${e=>e.publishedDateTimeString} :updatedDateStringFormat=${e=>e.updatedDateStringFormat} :updatedDateTimeString=${e=>e.updatedDateTimeString} :updatedTimeStamp=${e=>e.updatedTimeStamp} :removeDivider=${e=>e.contentProps?.header?.removeDivider} :viewsAuthors=${e=>e.contentProps?.header?.author} :viewsHeaderText=${e=>e.contentProps?.header?.title} :isOneColumn=${e=>e.columnArrangement===J.j1.c1} :readTimeMin=${e=>e.contentProps?.header?.readTimeMin} :rootTelemetryObject=${e=>e.telemetryObject} :viewsHeaderTelemetryContentData=${e=>e.contentProps?.header?.viewsHeaderTelemetryContentData} :abstract=${e=>e.contentData?.abstract} :hideSocialBar=${e=>!e.config.featureFlags?.showStartOfContentSocialBar||e.contentType===a.i.Video} :enableRubyProngView=${e=>e.config.featureFlags?.enableWidgetsConsumptionView&&e.config.featureFlags?.enableRubyConsumptionView} :isArticleView=${e=>e.contentType===a.i.Article} :isVideoView=${e=>e.contentType===a.i.Video} :contentType=${e=>e.contentType} :shareUrl=${e=>e.shareUrl} :enableTitleEndDivider=${e=>e.shouldRenderMobileActionTray&&!e.config.featureFlags?.showStartOfContentSocialBar&&!e.config.featureFlags?.enableFloatingSocialBarFull&&(e.config.featureFlags?.enableFloatingSocialBarT2||e.config.featureFlags?.enableFloatingSocialBarT3)&&e.contentType!==a.i.Video} :enableReducedRubyTitle=${e=>e.config.featureFlags?.enableReducedRubyTitle} :enableAttributionWithMiniAT=${e=>(e.config.featureFlags?.enableFloatingSocialBarT2||e.config.featureFlags?.enableFloatingSocialBarT3)&&!e.config.featureFlags?.enableFloatingSocialBarFull&&e.contentType!==a.i.Video} :isFloatingBarEnabled=${e=>e.config.featureFlags?.enableFloatingSocialBarT2||e.config.featureFlags?.enableFloatingSocialBarT3} :locale=${e=>e.contentData?.locale} :actionTrayProps=${e=>e.contentProps?.actionTray} :actionBarStrings=${e=>e.actionBarStrings} :updatedTimeStampFormat=${e=>e.updatedTimeStamp} :enableMoveBylinePosition=${e=>e.config.featureFlags?.enableMoveBylinePosition} :enableAlignLeft=${e=>e.config.featureFlags?.enableAlignLeft} :enableFontSizeIncreasing=${e=>e.config.featureFlags?.enableFontSizeIncreasing} :enablePublisherAboveTitle=${e=>e.config.featureFlags?.enablePublisherAboveTitle} ${(0,tf.K)("viewsHeaderRef")}>${(0,tb.z)(e=>e.shouldRenderBannerAdBelowHeadline,it)} ${(0,tb.z)(e=>e.config.featureFlags?.showStartOfContentSocialBar&&e.contentType!==a.i.Video,ir("head"))}</ruby-views-header></div>`,is=(0,tm.qy)`<div class=${e=>e.consumptionPageContentHeaderStyles} ${(0,tf.K)("consumptionPageContentHeaderRef")}><views-header-wc :contentId=${e=>e.contentProps?.header?.contentId} :config=${e=>e.config.componentConfigs?.viewsHeaderConfigs} :disableCopilotButtons=${e=>e.disableAllAIFeatures} :isMainContent=${e=>e.isMainContent()} :isOpinion=${e=>e.contentProps?.header?.isOpinion} :localizedStrings=${e=>e.config.localizedStrings?.viewsHeader} :visualReadinessCallback=${e=>e.stampPagePZeroTTVR} :enablePublisherFlyout=${e=>e.contentProps?.header?.enablePublisherFlyout} :providerId=${e=>e.contentProps?.header?.provider.id} :providerLogoUrl=${e=>e.contentProps?.header?.provider.logo?.src} :providerName=${e=>e.contentProps?.header?.provider.name} :providerProfileId=${e=>e.contentProps?.header?.provider.profileId} :providerUrl=${e=>e.contentProps?.header?.provider.url} :publishedDateString=${e=>e.contentProps?.header?.publishedDateString} :removeDivider=${e=>e.contentProps?.header?.removeDivider} :viewsAuthors=${e=>e.contentProps?.header?.author} :viewsHeaderText=${e=>e.contentProps?.header?.title} :isOneColumn=${e=>e.columnArrangement===J.j1.c1} :readTimeMin=${e=>e.contentProps?.header?.readTimeMin} :rootTelemetryObject=${e=>e.telemetryObject} :viewsHeaderTelemetryContentData=${e=>e.contentProps?.header?.viewsHeaderTelemetryContentData} :usePolishedStyles=${e=>e.usePolishedStyles} ${(0,tf.K)("viewsHeaderRef")}></views-header-wc></div>`,ic=(0,tm.qy)`<div class=${e=>(0,eD.x)(["consumption-page-eocb",!e.leadGenCardProps],["consumption-page-gridarea_eocb_leadgen",!!e.leadGenCardProps],["kumo-consumption-page-eocb",!!e.config.featureFlags?.enableRubyConsumptionView])}><desktop-end-of-content-block :category=${e=>e.contentProps?.endOfContentBlock?.category} :columnView=${e=>e.columnArrangement} :config=${e=>e.contentProps?.endOfContentBlock?.config} :contentId=${e=>e.contentProps?.endOfContentBlock?.contentId} :enableEoabNativeXandr=${e=>e.contentProps?.endOfContentBlock?.enableEoabNativeXandr} :nativeAdMappedPageType=${e=>e.contentProps?.endOfContentBlock?.nativeAdMappedPageType} :nativeAdPartnerId=${e=>e.contentProps?.endOfContentBlock?.nativeAdPartnerId} :vertical=${e=>e.contentProps?.endOfContentBlock?.vertical} :disableAds=${e=>e.contentProps?.endOfContentBlock?.disableAds} :isImmersiveFullscreenOpen=${e=>e.isImmersiveFullscreenOpen} :leadGenCardProps=${e=>e.leadGenCardProps} :shouldRenderEoabLeadgen=${e=>e.shouldRenderEoabLeadgen} :moreFromProviderData=${e=>e.useRightRailMoreFromCard?void 0:e.moreFromProviderData} :collapsible=${e=>e.config?.componentConfigs?.articlePageConfig?.collapsibleMFP} :moreFromProviderTitle=${e=>e.config?.localizedStrings?.articlePage.moreFromProvider}></desktop-end-of-content-block></div>`,il=(0,tm.qy)`<views-right-rail :contentId=${e=>e.contentProps?.rail?.contentId} :contentTitle=${e=>e.contentProps?.rail?.contentTitle} :isAdsDisabled=${e=>e.contentProps?.rail?.disableAds||e.isImmersiveFullscreenOpen} :isHorizontalLayout=${e=>e.isRailBelow} :topPositionPx=${e=>e.rightRailTopPosition} :topDisplayAdConfig=${e=>e.contentProps?.rail?.config.slots.topDisplayAd} :bottomDisplayAdConfig=${e=>e.contentProps?.rail?.config.slots.bottomDisplayAd} :contentInfoForAd=${e=>e.contentInfoForRightRailAd} :extraInfoTopDisplayAd=${e=>e.extraInfoForRightRailTopDisplayAd} :skipInitialRenderingVisibilityCheckForAds=${e=>e.infiniteReadingContext?.isMainArticle||e.isNewlyReplacedArticle} :contentProviderCardConfig=${e=>e.config.componentConfigs?.rightRailConfigs?.topStoriesRequestConfig?null:e.contentProviderCardConfig} :publisherProfileId=${e=>e.contentProps?.header?.provider.profileId} :zhCnNativeAdsRefresh=${e=>e.zhCnNativeAdsRefresh} :isMainArticle=${e=>e.infiniteReadingContext?.isMainArticle} :pageType=${e=>"view"} :railBelowLoaded=${e=>e.railBelowLoaded} :railRightLoaded=${e=>e.railRightLoaded} :topStoriesConfig=${e=>e.config.componentConfigs?.rightRailConfigs?.topStoriesRequestConfig||e.config.componentConfigs?.rightRailConfigs?.topStoriesFallbackConfig} :topStoriesHeading=${e=>(e.config.componentConfigs?.rightRailConfigs?.localizedStrings?.topStoriesHeading??"Top Stories").toUpperCase()} :topStoriesIconSvg=${`<img src="${et}"/>`}></views-right-rail>`,id=(0,tm.qy)`<div class="consumption-page-feed-wrapper" ${(0,tf.K)("riverElementRef")}><h2 class=${e=>e.riverHeadingClassnames}>${e=>e.config.localizedStrings?.riverHeading||"More for You"}</h2>${e=>(0,t$.yN)((0,b.j1)(e.config.slots.feedWC,`${e.config.slots.feedWC.instanceId}-${e.contentId}`),{properties:e.feedProps})}</div>`,ip=(0,tm.qy)`
${e=>e.cardProps?.experienceConfigInfo?(0,t$.yN)((0,b.j1)(e.cardProps?.experienceConfigInfo,`${e.cardProps?.experienceConfigInfo?.instanceId}-${e.cardProps?.id}-top`),{properties:e.cardProps}):null}
`,ig=(0,tm.qy)`
${(0,tb.z)((e,t)=>e.cardProps?.experienceConfigInfo&&!t.parent.isTopSpanContentDisabled(e.card.type),ip)}
`,iu=(0,tm.qy)`<div class="top-span-module" ${(0,tf.K)("topSpanRef")}>${(0,ty.ux)(e=>e.topSpanModuleContent,ig)}</div>`,ih=(0,tm.qy)`<div class="consumption-page-gridarea_action" style=${e=>e.actionTrayGridAreaStyles} role="complementary"><div class="consumption-page-action-tray-wrapper" style=${e=>e.actionTrayWrapperStyles}>${e=>(0,t$.yN)(e.config.slots.actionTray,{properties:e.composeActionTrayProps(e.contentProps?.actionTray),includeTelemetryTag:!1,memoize:!1})}</div></div>`,im=(0,tm.qy)` ${e=>(0,t$.yN)({...e.config.slots.actionTray,instanceId:`action-tray-${e.contentId}`},{properties:e.composeActionTrayProps(e.contentProps?.actionTray),includeTelemetryTag:!1,memoize:!1})}
`,ib=(0,tm.qy)`<div class="consumption-page-gridarea_rail" style=${e=>`margin-top: ${e.bannerHeight}px;`}><div class="consumption-page-rail-wrapper" role="region">${il}</div></div>`,iy=(0,tm.qy)` ${e=>e.contentProviderCardConfig?(0,t$.yN)(e.contentProviderCardConfig,{properties:e.rubyRightRailProviderCarouselProps}):null}
`,iv=(0,tm.qy)`<div class=${e=>(0,eD.x)(["ruby-rail-sticky",!!e.isRubyRightRailSticky],["ruby-rail-sticky-banner",!!e.config.enableRubyStickyBanner],["ruby-rail-sticky-banner-exit",e?.rubyStickyBannerClass?.includes?.("ruby-sticky-banner-exit")])}>${e=>(0,t$.yN)(e.contentProps?.rail?.config?.slots?.topDisplayAd,{properties:e.rubyRightRailProps,memoize:!1})} ${(0,tb.z)(e=>e.useRightRailMoreFromCard,iy)} ${e=>e.trendingNowData&&e.isFirstLoadedContent()?t8:null}</div>`,iw=(0,tm.qy)`<div class="ruby-right-rail-extended"><div>${e=>(0,t$.yN)(e.contentProps?.rail?.config?.slots?.topDisplayAd,{properties:e.rubyRightRailProps,memoize:!1})}</div>${(0,tb.z)(e=>e.useRightRailMoreFromCard&&!!e.moreFromProviderData,iy)}<div class="ruby-rail-sticky-bottom" ${(0,tf.K)("rubyRailBottomAdRef")}>${e=>(0,t$.yN)(e.contentProps?.rail?.config?.slots?.bottomDisplayAd,{properties:e.rubyRightRailBottomAdProps,memoize:!1})}</div></div>`,ix=(0,tm.qy)`<div class=${e=>(0,eD.x)("consumption-page-ruby-right-rail",["rail-with-keytakeaways-section",!!e.renderKeyTakeawaysSection],["right-rail-with-ads",!!e.isRubyRightRailAds],["ruby-rail-sticky-full-height",!!e.isRRStickyForLinearFeed])} role="region" ${(0,tf.K)("rubyRightRailRef")}>${(0,tb.z)(e=>!e.contentProps?.rail?.config?.slots?.bottomDisplayAd,iv)} ${(0,tb.z)(e=>!!e.contentProps?.rail?.config?.slots?.bottomDisplayAd,iw)}</div>`,iC=(0,tm.qy)`<iframe id="consumptionAIConversationStartersIframe" class="conversationStartersCompanionIframe" sandbox="allow-scripts allow-same-origin" frameborder="0" src=${e=>(0,b.sT)(e.contentId,"aics")} scrolling="no" style="${e=>e.conversationStartersIframeStyles}"></iframe>`,iR=(0,tm.qy)` ${(0,tb.z)(e=>e.renderKeyTakeawaysSection,(0,tm.qy)`${e=>e.config?.componentConfigs?.viewsHeaderConfigs?.slots?.keyTakeawaysWC?(0,t$.yN)(e.config.componentConfigs.viewsHeaderConfigs.slots.keyTakeawaysWC,{properties:{collapsed:e.keyTakeawaysCollapsed,isPeekView:!!e.config?.componentConfigs?.viewsHeaderConfigs?.isPeekView,keyTakeaways:e.keyTakeawaysData,contentId:e.contentId,rootTelemetryObject:e.telemetryObject,disableCopilotButtons:e.contentProps?.header?.disableCopilotButtons||!e.isMainContent()&&e.config?.componentConfigs?.viewsHeaderConfigs.enableKTButtons===1,enableKTCopilot:!!e.config?.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot,enableCopilotTheme:e.enableCopilotTheme,isCopilotApp:!1,enableKTButtons:e.config?.componentConfigs?.viewsHeaderConfigs?.enableKTButtons,seeMoreTelemetryTag:e.keyTakeawaysTelemetryObjects?.seeMore?.getMetadataTag(),reportTelemetryTag:e.keyTakeawaysTelemetryObjects?.reportIssue?.getMetadataTag(),enableEntAIString:e.config?.componentConfigs?.viewsHeaderConfigs?.enableEntAIString&&(0,b.dk)()},memoize:!1}):""}`)}
`,iA=(0,tm.qy)`<consumption-mini-feed :contentId="${e=>e.contentId}" :columnArrangement="${e=>e.columnArrangement}" :sharedTimestampConfig="${e=>e.config.slots?.sharedTimestampUtil}" :contentType="${e=>e.contentType}" :noScrollContentCount="${e=>e.vfpConnectorNoScrollContentCount}" :titleString="${e=>e.config.miniRiverRelatedVideosHeading?e.config.localizedStrings?.relatedVideos:e.config.localizedStrings?.relatedStories}" :nativeAdConfig=${e=>e.config.miniRiverNativeAd} :mappedPageType="${e=>e.contentProps?.endOfContentBlock?.nativeAdMappedPageType}" :disableAds="${e=>e.disableAds}" :partnerId="${e=>e.contentProps?.endOfContentBlock?.nativeAdPartnerId}" :enableNativeAdXandr="${e=>e.contentProps?.endOfContentBlock?.enableEoabNativeXandr}" :cardActionRef="${e=>e.cardActionRef}"></consumption-mini-feed>`,ik=(0,tm.qy)`<div class="${e=>(0,eD.x)("consumption-page",e.dwellTimeStartAllowedClassName,["consumption-ruby",!!e.config.featureFlags?.enableRubyConsumptionView],["ruby-fitcontent",!!e.config.enableOneRowContent])} " id="${e=>ev(e.contentId)}" ${(0,tf.K)("consumptionPageRef")} data-clarity-region="${e=>e.dataClarityRegion}"><div class=${e=>(0,eD.x)("consumption-page-structure",["consumption-page-structure-no-grid",!!e.config.featureFlags?.enableRubyConsumptionView],["consumption-page-structure-gem",!!e.config.featureFlags?.enableRubyGemReaderWidth],["consumption-page-structure-widgets",!!e.config.featureFlags?.enableWidgetsConsumptionView],["consumption-page-structure-support-padding",!e.config.featureFlags?.enableRubyConsumptionView&&!!e.config.componentConfigs?.slideshowConfigs?.featureFlags?.enableClassicGAHoverEffect],["extended-right-rail",!!e.config.featureFlags?.enableExtendedRightRail&&!e.config.featureFlags?.enableRubyConsumptionView&&e.contentType===a.i.Article],e.contentAreaClassname||"")} ${(0,tf.K)("consumptionPageStructureRef")} style=${e=>e.gridOverriddenStyle+e.stickyBannerSizeStyle+e.stickyBannerAdStyle}>${(0,tb.z)(e=>e.shouldRenderActionTray&&(0,eO.S)(),ih)}<div class=${e=>(0,eD.x)("consumption-page-gridarea_content",["consumption-page-ruby-structure",!!e.config.featureFlags?.enableRubyRightRail],["action-bar-below-byline",!!e.config.featureFlags?.enableMoveBylinePosition],["responsive-banner-active",!!e.config.enableResponsiveBannerAds])}><div class=${e=>(0,eD.x)("viewsHeaderWrapper",["ruby-sticky-wrapper",e.rubyStickyBannerClass?.startsWith?.("ruby-sticky-banner-visible")])} ${(0,tf.K)("consumptionPageViewsHeaderAreaRef")}>${(0,tb.z)(e=>e.showNativeAdBanner,ii)} ${(0,tb.z)(e=>!e.showNativeAdBanner&&e.shouldRenderBannerAdAboveHeadline,it)} ${(0,tb.z)(e=>e.isMainContent()&&!!e.config.slots.breakingNews&&(0,eO.S)(),t9)} ${(0,tb.z)(e=>e.contentProps?.header,(0,tm.qy)` ${(0,tb.z)(e=>e.config.featureFlags?.enableRubyConsumptionView,ia,is)} `)}</div>${(0,tb.z)(e=>(0,eO.S)()&&e.topSpanModuleContent&&e.topSpanModuleContent.length,iu)}<div class=${e=>(0,eD.x)("consumption-page-content-wrapper",e.contentAreaClassname||"",["with-keytakeaways-section",e.renderKeyTakeawaysSection])} ${(0,tf.K)("consumptionPageContentRef")} role="main">${iR} ${e=>e.contentProps?.content&&((e,t,i,n)=>{let o=t.slots.content,r=t.localizedStrings,s={...t.componentConfigs?.slideshowConfigs,slideshowSettings:{...t.componentConfigs?.slideshowConfigs?.slideshowSettings}};switch(e){case a.i.Webcontent:case a.i.Video:let c,l;return c=i,l=t,l.componentConfigs?.videoContentConfigs&&(0,tm.qy)`<video-content :config=${l.componentConfigs.videoContentConfigs} :props=${c} :localizedStrings=${l.localizedStrings?.videoContent||{}} :enableRubyConsumptionView=${e=>e.config.featureFlags?.enableRubyConsumptionView} :enableRubyGemView=${e=>e.config.featureFlags?.enableRubyGemReaderWidth} :enableRubyProngView=${e=>e.config.featureFlags?.enableWidgetsConsumptionView&&e.config.featureFlags?.enableRubyConsumptionView} :publishedDateStringFormat=${e=>e.publishedDateStringFormat} :enableMoveBylineAndActionBar=${e=>e.config.featureFlags?.enableMoveBylineAndActionBar} :showActionBar=${e=>!!(e.config.featureFlags?.enableRubyConsumptionView&&e.config.featureFlags?.showEndOfContentSocialBar&&e.config.componentConfigs?.viewsHeaderConfigs?.slots.socialBarWC)} :actionBarData=${e=>({contentId:e.contentId,locale:e.contentData?.locale,config:e.config.componentConfigs?.viewsHeaderConfigs,localizedStrings:e.actionBarStrings,actionTrayProps:e.contentProps?.actionTray,providerName:e.contentProps?.header?.provider.name,providerLogoUrl:e.contentProps?.header?.provider.logo?.src,updatedTimeStampFormat:e.publishedTimeStamp,shareUrl:e.shareUrl})}></video-content>`;case a.e.Manga:let d,p,g,u,h;return d=i,p=n,g=t,u=r?.slideshow,h=r?.mangaPage,g?.componentConfigs?.slideshowConfigs&&(0,tm.qy)`<manga-content :config=${g.componentConfigs.slideshowConfigs} :mangaPageLocalizedStrings=${h??{}} :props=${d} :slideshowStrings=${u??{}} :stampPagePZeroTTVR=${e=>e.stampPagePZeroTTVR} :rootTelemetryObject=${p} :shouldRenderEoabLeadgen=${e=>e.shouldRenderEoabLeadgen} :useTeraForVerticalData=${e=>!!e.config?.featureFlags?.useTeraForVerticalData}></manga-content>`;case a.i.Gallery:let m,f,y;return m=i,f=s,y=r?.slideshow,f&&(0,tm.qy)`<desktop-gallery-content :config=${f} :props=${m} :localizedStrings=${y||{}} :isImmersiveFullscreenOpen=${e=>e.isImmersiveFullscreenOpen} :enableRubyConsumptionView=${e=>e.config.featureFlags?.enableRubyConsumptionView} :enableRubyProngView=${e=>e.config.featureFlags?.enableRubyProngView} :enableWidgetsConsumptionView=${e=>e.config.featureFlags?.enableWidgetsConsumptionView} :overrideContentUrl=${e=>e.telemetryExtraDataWidgets?.url} :leadGenCardProps=${e=>e.leadGenCardProps} :shouldRenderEoabLeadgen=${e=>e.shouldRenderEoabLeadgen} :moreFromProviderData=${e=>(0,b.BZ)(e.moreFromProviderData)} :moreFromProviderTitle=${e=>e.config?.localizedStrings?.articlePage.moreFromProvider} :useTeraForVerticalData=${e=>!!e.config?.featureFlags?.useTeraForVerticalData}></desktop-gallery-content>`;case a.i.Article:let v,w,x,C,R;return v=i,w=n,x=t.componentConfigs?.articlePageConfig,C=s,R={...r?.articlePage,...r?.slideshow},x&&(0,tm.qy)`<desktop-article-content :config=${x} :slideshowConfig=${C||{}} :rootTelemetryObject=${w} :localizedStrings=${R||{}} :props=${v} :stampPagePZeroTTVR=${e=>e.stampPagePZeroTTVR} :isImmersiveFullscreenOpen=${e=>e.isImmersiveFullscreenOpen} :shouldRenderEoabLeadgen=${e=>e.shouldRenderEoabLeadgen} :providerLogoUrl=${e=>e.contentProps?.header?.provider.logo?.src} :handleFatalError=${e=>e.handleFatalError} :commonHeaderRef=${e=>e.commonHeaderRef} :trackingAdapter=${e=>e.tracker} :useTeraForVerticalData=${e=>!!e.config?.featureFlags?.useTeraForVerticalData} :contentInfoForAd=${e=>e.contentInfoForRightRailAd} :disableAds=${e=>e.config.sponsoredContent}></desktop-article-content>`;default:return(0,t$.yN)(o,{properties:i})}})(e.useMangaWCPage?a.e.Manga:e.contentType,e.config,e.contentProps.content,e.telemetryObject)}</div>${(0,tb.z)(e=>e.shouldRenderEocb,ic)} ${(0,tb.z)(e=>!e.isRailBelow&&e.isRightRailReady&&e.isRubyRightRail,ix)} ${(0,tb.z)(e=>(e.enableBigRRAd||e.enableSponsoredArticleLayout)&&e.shouldRenderActionBar,ir("eocb"))} ${(0,tb.z)(e=>!e.noCopilotAPI&&e.shouldRenderAIConversationStarters&&e.contentType,iC)}</div>${(0,tb.z)(e=>!e.isRailBelow&&e.isRightRailReady&&!e.isRubyRightRail,ib)} ${(0,tb.z)(e=>!e.enableBigRRAd&&!e.enableSponsoredArticleLayout&&e.shouldRenderActionBar,ir("eocb"))}</div>${(0,tb.z)(e=>e.isRailBelow&&e.isRightRailReady&&!e.config.featureFlags?.enableRubyRightRail,(0,tm.qy)`<div class="railBelow_c2">${il}</div>`)}<div ${(0,tf.K)("aboveRiverBlockRef")}>${e=>i$(e)?(0,t$.yN)(e.config.slots.aboveRiverBlock,{properties:e.contentProps?.aboveRiverBlock,memoize:!1}):""}</div>${(0,tb.z)(e=>e.config.slots.feedWC&&e.feedProps&&!e.deferRenderingRiver&&!e.hideRiver&&(0,eO.S)(),id)} ${(0,tb.z)(e=>e.config.slots.toastWC&&(0,eO.S)(),t7)} ${(0,tb.z)(e=>e.shouldRenderMobileActionTray&&(0,eO.S)(),im)} ${(0,tb.z)(e=>e.config.featureFlags?.enableRubyConsumptionView&&!e.config.featureFlags.enableRubyGemReaderWidth&&!e.enableRubyInfRead&&!e.enableGemContinuousReading,io)} ${(0,tb.z)(e=>e.displayCSAT&&(0,eO.S)(),t4)}</div>${(0,tb.z)(e=>e.showOneRowContent&&!e.deferRenderingRiver&&(0,eO.S)(),iA)}
`;function i$(e){return!!(!e.disableAds&&e.config.slots.aboveRiverBlock&&e.contentProps?.aboveRiverBlock&&e.aboveRiverBlockData)&&!!(!e.config.disableNonInfRiver||e.feedProps)}let iS=(0,tm.qy)`<div class="consumption-error-page"><h1>${e=>e.errorText}</h1><p>${e=>e.config.localizedStrings?.redirectMessage}</p></div>`,iT=(0,tm.qy)`<div><consumption-error-page :contentId=${e=>e.contentId} :errorPageConfig=${e=>e.config.componentConfigs?.errorPageConfig} :localizedStrings=${e=>e.config.localizedStrings?.errorPage} :feedConfig=${e=>e.config.featureFlags?.enableRubyConsumptionView?void 0:e.config.slots.feedWC} :telemetryObject=${e=>e.telemetryObject} :backToFeed=${e=>e.backToFeed}></consumption-error-page><div>`,iF=(0,tm.qy)`<div class="ruby-consumption-error-page"><ruby-consumption-error-page :localizedStrings=${e=>e.config.localizedStrings?.rubyErrorPage} :telemetryObject=${e=>e.telemetryObject} :backToFeed=${e=>e.backToFeed}></ruby-consumption-error-page></div>`,iP=(0,tm.qy)` ${e=>e.enableConsumptionErrorPage?e.config.featureFlags?.enableRubyConsumptionView?iF:iT:iS}
`,iB=(0,tm.qy)`<loading-state-article :disableMrr=${e=>e.config.featureFlags?.enableWidgetsConsumptionView}></loading-state-article>`,iI=(0,tm.qy)` ${e=>e.errorState&&!e.config.featureFlags?.enableWidgetsConsumptionView?iP:e.isLoading?iB:(e.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow&&(0,eO.S)()&&(0,eI.dT)().then(async()=>{let{RubyViewsTrendingNow:e}=await i.e("web-components_ruby-views-trending-now-wc_dist_index_js").then(i.bind(i,29706));return e}),ik)}
`;var iH=i(88638),iD=i(82905),i_=i(25975),iE=i(33544),iM=i(25987);let iO="calc(100vw - 65px)",iV=(0,tA.A)`
consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:${iO}}${(0,J._D)(J.j1.c2,null)}{consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:clamp(${(0,tu.c)(iH.vT)},${iO},${(0,tu.c)(iH.sX)})}consumption-page[enable-ruby-article-flex] .consumption-page-content-header{width:${iO}}}${(0,J._D)(J.j1.c3,null)}{consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:${(0,tu.c)(iH.Nm)}}}`;var iz=i(4126),iL=i(47810);let iN=(0,tA.A)` .consumption-page-ruby-structure{grid-template-columns:var(--ruby-article-flex-max-width) ${(0,tu.c)(s.tY)} ${(0,tu.c)(s.zj)};grid-template-areas:"header header header" "content . right-rail" "eocb . ."}.consumption-page-structure-no-grid .consumption-page-content-header{margin:unset}@media (min-width:${(0,tu.c)(s.RA)}){.consumption-page-structure-no-grid .consumption-page-content-header{width:unset}consumption-page[enable-ruby-article-flex] .consumption-page-structure-no-grid .consumption-page-content-header{width:unset}}ruby-views-action-bar.eocb,.consumption-page-ruby-structure > .conversationStartersCompanionIframe{grid-column:1 / 3;margin:unset}.gallery_content .align-left ruby-views-header::part(ruby-views-header){display:block;padding:0}.gallery_content .consumption-page-content-header.align-left{max-width:var(--ruby-article-flex-max-width)}.gallery_content .consumption-page-content-header{margin-block:0;margin-inline:0 auto}.gallery_content ruby-views-action-bar.eocb{grid-area:eocb;margin:0 auto}@media (max-width:${(0,tu.c)(s.CD)}){.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:var(--ruby-article-flex-max-width)}.consumption-page-ruby-right-rail{display:none}.consumption-page-structure-no-grid .consumption-page-content-header{width:unset}ruby-views-action-bar.eocb,.consumption-page-ruby-structure > .conversationStartersCompanionIframe{margin:0px auto}.gallery_content .consumption-page-ruby-structure{grid-template-areas:"header""content""eocb"}}`,iG=(0,tA.A)`.consumption-page-ruby-structure{grid-template-columns:${(0,tu.c)(s.l$)} ${(0,tu.c)(s.D7)} 1fr ${(0,tu.c)(s.D7)} ${(0,tu.c)(s.zj)}}ruby-views-action-bar.eocb{grid-column:3 / 4;width:100%}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(s.D7+s.zj-s.l$-s.D7).toString()}px}@media (max-width:${(0,tu.c)(s.gk)}){.consumption-page-ruby-structure{grid-template-columns:${(0,tu.c)(s.l0)} ${(0,tu.c)(s.TO)} 1fr ${(0,tu.c)(s.TO)} ${(0,tu.c)(s.zj)}}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(s.TO+s.zj-s.l0-s.TO).toString()}px}}${(0,J.H5)(J.j1.c3)}{.consumption-page-ruby-structure{grid-template-columns:0px ${(0,tu.c)(s.Cv)} 1fr ${(0,tu.c)(s.Cv)} ${(0,tu.c)(s.zj)}}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(s.Cv+s.zj-s.Cv).toString()}px}}@media (max-width:1199px){.consumption-page-structure-no-grid .consumption-page-content-header{max-width:calc(100vw - ${(s.Cv+s.zj-s.Cv).toString()}px)}}@media (max-width:${(0,tu.c)(s.CD)}){.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}ruby-views-action-bar.eocb{grid-column:unset;width:100%}.consumption-page-ruby-right-rail{display:none}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:0;max-width:948px}}`,iW=(0,tA.A)` .consumption-page-ruby-right-rail.ruby-rail-sticky-full-height,.consumption-page-ruby-right-rail.ruby-rail-sticky-full-height .ruby-rail-sticky,.ruby-rail-sticky-bottom{z-index:0}.viewsHeaderWrapper.ruby-sticky-wrapper ~ .consumption-page-ruby-right-rail .ruby-rail-sticky-banner:not(.ruby-rail-sticky-banner-exit){top:94px}`,ij=(0,tA.A)`@media (min-width:${(0,tu.c)(s.DF)}) and (min-height:${(0,tu.c)(s.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-columns:${(0,tu.c)(s.zj)} ${(0,tu.c)(s.Kv)} 1fr ${(0,tu.c)(s.Kv)} ${(0,tu.c)(s.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{grid-column:3 / 4;width:100%}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:unset}}@media (min-width:${(0,tu.c)(s.HN)}) and (max-width:${(0,tu.c)(s.DF-1)}) and (min-height:${(0,tu.c)(s.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header header header header header" "left-rail . content . right-rail" "eocb eocb eocb . .";grid-template-columns:0px 0px 1fr ${(0,tu.c)(s.Kv)} ${(0,tu.c)(s.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:unset}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:420px}}@media (min-width:${(0,tu.c)(s.SU)}) and (max-width:${(0,tu.c)(s.HN-1)}) and (min-height:${(0,tu.c)(s.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header header header header header" "left-rail . content . right-rail" "eocb eocb eocb . .";grid-template-columns:0px 0px 1fr ${(0,tu.c)(s._$)} ${(0,tu.c)(s.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:unset}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:330px}consumption-page[enable-ruby-article-flex]{--article-content-width:592px;--ruby-article-flex-max-width:592px}.consumption-page-structure-no-grid.article_content .consumption-page-content-header.align-left{max-width:592px}}@media (max-width:${(0,tu.c)(s.SU-1)}),(max-height:${(0,tu.c)(s.t6-1)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{grid-column:unset;width:100%;margin:0px auto}.consumption-page-structure-no-grid.article_content .consumption-page-ruby-right-rail{display:none}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:0}}@media (max-width:663px){consumption-page[enable-ruby-article-flex]{--article-content-width:unset}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:0px auto}}`,iq=(0,tA.A)`consumption-page{--video-content-width:864px;--article-content-width:688px;--gallery-header-width:1216px;--gallery-header-title-width:864px;${(0,J.H5)(J.j1.c3)}{--video-content-width:864px;--article-content-width:688px;--gallery-header-width:min(1040px,calc(100vw - calc(2 * 58px)))}${(0,J.H5)(J.j1.c2)}{--video-content-width:min(688px,calc(100vw - calc(2 * ${i_.iIh})));--article-content-width:min(688px,calc(100vw - calc(2 * ${i_.iIh})));--gallery-header-width:min(688px,calc(100vw - calc(2 * ${i_.iIh})));--gallery-header-title-width:min(688px,calc(100vw - calc(2 * ${i_.iIh})))}${(0,J.H5)(J.j1.c1)}{--video-content-width:min(360px,calc(100vw - calc(2 * ${i_.iIh})));--article-content-width:min(360px,calc(100vw - calc(2 * ${i_.iIh})));--gallery-header-width:min(360px,calc(100vw - calc(2 * ${i_.iIh})));--gallery-header-title-width:min(360px,calc(100vw - calc(2 * ${i_.iIh})));--ruby-view-header-title-width:var(--article-content-width);--intra-article-margin:0 auto}}consumption-page{--article-content-padding:0}.consumption-page-structure:is(.video_content){max-width:min(var(--video-content-width),100%);--ruby-article-flex-max-width:var(--video-content-width)}.consumption-page-structure:is(.article_content){--ruby-article-flex-max-width:var(--article-content-width)}.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:var(--article-content-width);margin:0 auto}.consumption-page-structure:is(.video_content) .consumption-page-content-header{max-width:var(--video-content-width);margin:0 auto}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:unset}.consumption-page-structure:is(.gallery_content) .consumption-page-content-header{width:var(--gallery-header-width);max-width:unset;--ruby-view-header-title-width:var(--gallery-header-title-width)}${(0,J._D)(J.j1.c2,null)}{.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure{grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:1fr minmax(${i_.iIh},104px) minmax(616px,var(--ruby-article-flex-max-width,auto)) minmax(${i_.iIh},104px) 1fr}}${(0,J.H5)(J.j1.c1)}{.consumption-page-structure-no-grid .consumption-page-gridarea_content{max-width:var(--article-content-width);margin:0 auto}ruby-views-action-bar.eocb{max-width:var(--article-content-width)}.consumption-eoab{max-width:var(--article-content-width);margin:0 auto;overflow:hidden}.consumption-eoab .eoab-ad-full.adaptive,.consumption-eoab [class*="eoab-ad-full"].adaptive,.consumption-eoab.no-background .eoab-ad-full.adaptive,.consumption-eoab.no-background [class*="eoab-ad-full"].adaptive{margin-inline:0;width:100%}.content-consumption-container{padding:0}}`,iU=(0,tA.A)`consumption-page{--article-content-width:688px;--ruby-article-flex-max-width:688px;--sa-content-offset:92px}.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure{display:grid;justify-content:center;grid-template-areas:". header header header header ." ". . content . right-rail ." ". . eocb . . ." ". . eocb-bar . . .";grid-template-columns:minmax(24px,1fr) 92px minmax(0,688px) 92px 300px minmax(24px,1fr)}${(0,J.H5)(J.j1.c3)}{.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure{grid-template-columns:minmax(24px,1fr) 24px minmax(0,688px) 24px 300px minmax(24px,1fr)}consumption-page{--article-content-width:min(688px,calc(100vw - 300px - 24px - 24px - 24px - 24px));--ruby-article-flex-max-width:var(--article-content-width);--sa-content-offset:24px}}${(0,J._D)(null,J.j1.c2)}{.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure{grid-template-areas:"header" "content" "eocb" "eocb-bar";grid-template-columns:minmax(0,688px)}.consumption-page-structure:is(.article_content) .consumption-page-ruby-right-rail{display:none}consumption-page{--article-content-width:min(688px,calc(100vw - 32px));--ruby-article-flex-max-width:var(--article-content-width);--sa-content-offset:0px}}.consumption-page-structure:is(.article_content) ruby-views-action-bar.head{align-self:start;margin-inline-start:var(--sa-content-offset);margin-inline-end:auto}${(0,J.H5)(J.j1.c4)}{.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:none;margin:0;width:100%}}${(0,J.H5)(J.j1.c3)}{.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:none;margin:0;width:100%}}${(0,J._D)(null,J.j1.c2)}{.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:none;width:clamp(616px,calc(100vw - 65px),736px);margin:0 auto}}${(0,J.H5)(J.j1.c1)}{.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:none;width:calc(100vw - 65px);margin:0 auto}}.consumption-page-structure:is(.article_content) ruby-views-header{display:block;width:100%}.consumption-page-structure:is(.article_content) ruby-views-header::part(content-title){text-align:center}.consumption-page-structure:is(.article_content) ruby-views-header::part(provider-attribution),.consumption-page-structure:is(.article_content) ruby-views-header::part(attribution-action-bar-wrapper),.consumption-page-structure:is(.article_content) ruby-views-header::part(action-bar-placeholder){align-self:flex-start;align-items:flex-start;margin-inline-start:var(--sa-content-offset);margin-inline-end:auto;text-align:start}.sponsored-eocb-ad-slot{max-width:var(--article-content-width);margin:24px auto;width:100%;box-sizing:border-box}.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure > ruby-views-action-bar.eocb{grid-area:eocb-bar;max-width:100%;width:100%;margin:0}`,iK=(0,tA.A)` .consumption-page{--banner-background:#ffffff}@media (prefers-color-scheme:dark){.consumption-page{--banner-background:#242424}}.consumption-page-banner-ad{min-height:${(0,tu.c)(er)};padding-top:${(0,tu.c)(el)}}.consumption-ruby .consumption-page-banner-ad.above-headline,.consumption-ruby .consumption-page-banner-ad.below-headline{min-height:${(0,tu.c)(ea)};padding-top:0}.consumption-page-banner-ad.above-headline.responsive-banner-ads{min-height:0;padding-top:0}.railBelow_c2{display:flex}.railBelow_c2 *{margin:auto;margin-bottom:40px}.consumption-page-banner-wrapper{position:sticky;width:100vw;z-index:300;align-items:center;display:flex;flex-direction:column;justify-content:center;background-color:var(--banner-background);margin-bottom:4px}.consumption-ruby .consumption-page-banner-wrapper{position:relative;width:100%}.consumption-ruby .consumption-page-banner-wrapper.above-headline{background-color:transparent;margin-bottom:${(0,tu.c)(ep)}}.ruby-consumption-page:has(.consumption-page-banner-wrapper.above-headline.responsive-banner-ads){padding-top:0}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner{background-color:var(--container-background-color-override,${i_.Le$});top:var(--headerHeight,93px);position:sticky}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible .consumption-page-banner-ad{padding-bottom:var(--bannerPaddingBottom,0px)}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible{background-color:var(--container-background-color-override,${i_.Le$});position:fixed;width:100%;left:0px;top:0px;padding-top:var(--headerHeight,93px);z-index:${iM.P.Over.toString()};transition:transform 0.3s ease;transform:translateY(0);margin-bottom:0px}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible.ruby-sticky-banner-exit{transform:translateY(var(--ruby-sticky-banner-exit-translate,-100%))}.consumption-ruby .viewsHeaderWrapper.ruby-sticky-wrapper .consumption-page-content-header{margin-top:var(--ruby-sticky-banner-margin,146px)}.consumption-ruby .consumption-page-banner-wrapper.below-headline{background-color:transparent;margin-bottom:16px}.consumption-page-structure{display:grid;grid-template-areas:"actions . content . rail"". . eocb . .";grid-template-columns:${(0,tu.c)(s.zM)} ${(0,tu.c)(s.Lw)} ${(0,tu.c)(s.Ii)} ${(0,tu.c)(s.Lw)} ${(0,tu.c)(s.c_)};justify-content:center;position:relative}.consumption-page-structure.consumption-page-structure-support-padding{--ga-hover-support-padding:${(0,tu.c)(ef)}}.consumption-page-ruby-structure{display:grid;grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:${(0,tu.c)(160)} ${(0,tu.c)(92)} 1fr ${(0,tu.c)(92)} ${(0,tu.c)(160)};justify-content:center;position:relative}.consumption-page-ruby-structure > .viewsHeaderWrapper{grid-area:header}.consumption-page-ruby-structure > .consumption-page-content-wrapper{grid-area:content}.consumption-page-ruby-structure > .consumption-page-eocb{grid-area:eocb;width:100%}.consumption-page-ruby-structure > .conversationStartersCompanionIframe{grid-column:2 / -2}.consumption-page-structure.insight{grid-template-columns:${(0,tu.c)(s.zM)} ${(0,tu.c)(s.Lw)} ${(0,tu.c)(s.fA)} ${(0,tu.c)(s.Lw)} ${(0,tu.c)(s.zM)}}.consumption-page-structure.insight .breaking-news-banner-wrap{justify-content:flex-start;width:100%}.consumption-page-header_gradient{position:absolute;width:100%}.consumption-page-gridarea_action{grid-area:actions;z-index:${(iM.P.Over+1).toString()};// Needs to be above banner ad container z-index}.consumption-page-action-tray-wrapper{margin-inline-end:auto;background:transparent;position:sticky;width:fit-content;z-index:2;display:flex;flex-direction:column;align-items:center}.consumption-page-gridarea_content{grid-area:content}.consumption-page-content-wrapper{position:relative}.consumption-page-content-header{margin:32px 0px;border-bottom:1px solid rgba(0,0,0,0.1)}.consumption-page-content-header-no-border{border-bottom:none !important}.consumption-page-content-header-no-topmargin{margin-top:0}.consumption-page-gridarea_rail{grid-area:rail;background-color:transparent;position:relative;width:max-content;border-inline-start:1px solid rgba(0,0,0,0.06)}.consumption-page-ruby-right-rail{grid-area:right-rail;margin-top:${(0,tu.c)(s.M5)}}.right-rail-with-ads.consumption-page-ruby-right-rail{margin-top:32px}.right-rail-with-ads ruby-views-trending-now{margin-top:32px}.ruby-rail-sticky{position:sticky;top:80px}.ruby-rail-sticky right-rail-provider-carousel{margin-block-start:22px;display:block}.ruby-right-rail-extended{display:flex;flex-direction:column;gap:32px;height:100%}.ruby-rail-sticky-bottom > *{display:flex;justify-content:center;width:100%}.ruby-rail-sticky-bottom{position:sticky;top:80px;height:0}.ruby-rail-sticky-bottom.is-fixed{position:fixed;top:80px}.consumption-page-rail-wrapper{position:sticky;height:100%}.ruby-rail-sticky-full-height .ruby-rail-sticky{position:fixed;z-index:${iM.P.Over.toString()};top:88px}.ruby-rail-sticky-banner{top:var(--ruby-sticky-banner-size,80px)}.ruby-rail-sticky-banner-exit{transition:top 0.3s ease}.consumption-page-gridarea_eocb_leadgen{grid-area:eocb;width:100%}.consumption-page-eocb{margin:32px auto 0px}.consumption-page-feed-wrapper{background-color:var(--banner-background);padding-bottom:${(0,tu.c)(s.NR)}}.consumption-page-river-heading{margin:0 auto;color:${iL.l};font-size:20px;font-weight:bold;width:1236px;padding:20px 0}.consumption-page-river-heading-centralized{margin:0 auto;color:${iL.l};text-align:center;font-size:28px;text-transform:uppercase;font-weight:bold;padding:25px 0}.more-for-you-button-container{width:1236px;margin:0 auto;position:relative;padding:16px 0;display:flex;justify-content:end}.more-for-you-button-content{display:flex;justify-content:center;align-items:center;gap:8px}.more-for-you-button{border-radius:20px;padding:4px}.more-for-you-click-area{position:absolute;inset-inline-start:calc(50% - 100px);top:-30px;padding:10px;cursor:pointer}.more-for-you-button-content img{filter:invert(1)}.arb-style-header{font-weight:600}.top-span-module{width:100%;max-height:60px;margin-bottom:32px}.breaking-news-banner-wrap{width:100vw;display:flex;justify-content:center}.breaking-news-banner{width:1311px;--feed-width:1311px}.conversationStartersCompanionIframe{width:100%;display:block;margin:0px auto;height:0px;box-sizing:border-box}.consumption-error-page{margin:100px 150px;font-size:20px;color:${iL.l}}.consumption-error-page h1{font-size:25px}.gallery_content{min-height:${(0,tu.c)(680)}}.social-bar-wrapper{min-height:32px}.social-bar-wrapper social-bar-wc::part(social-bar-buttons-tooltip){bottom:9px;left:calc(100% + 10px);background:#3B3B3B;border-radius:2px;color:#fff;content:attr(data-content);font-size:14px;padding:4px 10px;white-space:nowrap;box-shadow:0 6.4px 14.4px rgba(0,0,0,0.13),0 0 5.6px rgba(0,0,0,0.11);outline:auto;outline-color:#3B3B3B;max-width:150px;transform:none}.star-rating-container{position:fixed;inset-block-end:140px;inset-inline-end:0;z-index:${iM.P.Banner.toString()}}.consumption-page-structure-widgets{display:block}.consumption-page-structure-no-grid{display:block;width:100%}.consumption-ruby{display:flex;justify-content:center;flex-direction:column}.consumption-ruby .gallery_content{min-height:unset}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.article_content),.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.gallery_content){margin-top:32px}.consumption-page-structure-no-grid .action-bar-below-byline .consumption-page-content-wrapper:is(.article_content,.gallery_content){margin-top:16px}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.with-keytakeaways-section){align-items:center;justify-content:center;display:flex;flex-direction:column;margin-top:16px}key-takeaways-wc{margin-bottom:32px}.rail-with-keytakeaways-section{margin-top:${(0,tu.c)(-1*s.M5)}}.consumption-page-structure-no-grid.consumption-page-structure-gem,.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.OH)};margin:32px auto;margin-bottom:16px}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.consumption-page-structure-no-grid .consumption-page-content-header{max-width:948px;margin:0 auto}.gallery_content .align-left ruby-views-header::part(ruby-views-header){align-items:start}.gallery_content .consumption-page-content-header.align-left{max-width:1392px}ruby-views-action-bar{padding-bottom:16px}ruby-views-action-bar.eocb{display:block;max-width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)});margin:0 auto}.video_content .consumption-page-content-header.align-left{width:100%}ruby-views-action-bar.action-bar-under-title{max-width:100%;margin-bottom:16px;margin-inline-start:8px}ruby-views-action-bar.head{width:100%;border-bottom:1px solid var(--stroke-divider);max-width:var(--ruby-article-flex-max-width,${s.Rq.toString()}px)}ruby-views-action-bar.below-byline{border-bottom:none}ruby-views-action-bar.head.no-border{border:none;padding-bottom:0}.conversationStartersCompanionIframe{display:block;max-width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)});margin:0 auto}.kumo-consumption-page-eocb{max-width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)});margin:0 auto 16px auto}.consumption-page-structure-no-grid.insight{width:unset;max-width:1272px}.consumption-page-structure-no-grid > .consumption-page-gridarea_rail{display:none}.consumption-page-structure-no-grid .consumption-page-content-header{border:none !important}.consumption-page-content-header-ss{width:${(0,tu.c)(750)}}.social-bar-wrapper-clp{border-width:1px 0px 1px 0px;border-style:solid;border-color:var(--neutral-stroke-active);margin:16px 0px 24px 0px;padding:8px 0px}.social-bar-wrapper-clp social-bar-wc::part(share-button){position:absolute;right:0}.more-for-you-peek{position:sticky;bottom:var(--mfy-peek-bottom-offset) !important;z-index:${(iM.P.Over+1).toString()};transition:bottom 300ms ease-in-out;background:#FAFAFA}.more-for-you-peek-close{background:transparent;border:none;cursor:pointer;padding-inline-end:0}.more-for-you-peek-close img{width:20px;height:20px}.native-ad-banner-wrapper{display:grid;justify-content:center;min-height:192px}.native-ad-banner{margin-bottom:32px;margin-top:0px;width:${(0,tu.c)(iH.Nm)}}.ruby-consumption-error-page{position:fixed;top:0;left:0;width:100vw;height:100vh;display:flex;justify-content:center;align-items:center}${(0,J.H5)(J.j1.c5)}{.consumption-page-river-heading,.more-for-you-button-container{width:${(0,tu.c)(eu)}}.consumption-page-content-header-ss{width:${(0,tu.c)(800)}}}${(0,J.H5)(J.j1.c4)}{.consumption-page-river-heading-centralized,.consumption-page-river-heading,.more-for-you-button-container{width:${(0,tu.c)(eh)}}.consumption-page-structure{grid-template-columns:${(0,tu.c)(s.zM)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.BE)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.c_)}}.consumption-page-structure.insight{grid-template-columns:${(0,tu.c)(s.zM)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.sj)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.zM)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,tu.c)(s.zM)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.BE+ef)} ${(0,tu.c)(s.xZ)} ${(0,tu.c)(s.c_)}}.gallery_content .align-left ruby-views-header::part(ruby-views-header){display:grid;grid-template-columns:repeat(16,minmax(63px,72px));gap:16px;align-items:start}ruby-views-action-bar.head.no-border{grid-column:1 / 13;width:calc(100% - 8px)}.above-river-heading{width:${(0,tu.c)(1236)}}.article_content .consumption-page-content-header.align-left{max-width:688px}}@media (max-width:${(0,tu.c)(s.gk)}){.consumption-page-structure{grid-template-areas:"actions . content . rail";grid-template-columns:${(0,tu.c)(48)} ${(0,tu.c)(36)} ${(0,tu.c)(b.e5)} ${(0,tu.c)(36)} ${(0,tu.c)(s.u9)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,tu.c)(48)} ${(0,tu.c)(36)} ${(0,tu.c)(b.e5+ef)} ${(0,tu.c)(36)} ${(0,tu.c)(s.u9)}}}${(0,J.H5)(J.j1.c3)}{.consumption-page-structure{grid-template-areas:"actions . content . rail";grid-template-columns:${(0,tu.c)(26)} ${(0,tu.c)(24)} ${(0,tu.c)(s.eq)} ${(0,tu.c)(s.ef)} ${(0,tu.c)(s.c_)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,tu.c)(26)} ${(0,tu.c)(24)} ${(0,tu.c)(s.eq+ef)} ${(0,tu.c)(s.ef)} ${(0,tu.c)(s.c_)}}.consumption-page-ruby-structure{grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:${(0,tu.c)(160)} ${(0,tu.c)(24)} 1fr ${(0,tu.c)(24)} ${(0,tu.c)(160)}}.consumption-page-structure.insight{grid-template-columns:${(0,tu.c)(26)} ${(0,tu.c)(24)} ${(0,tu.c)(s.N4)} ${(0,tu.c)(26)} ${(0,tu.c)(24)}}.consumption-page-river-heading,.more-for-you-button-container{width:924px}.consumption-page-river-heading-centralized{width:toPx(CONSUMPTION_PAGE_WIDTH_3_COL)}.consumption-page-structure > .consumption-page-gridarea_action{grid-area:none;margin-inline-start:16px;position:absolute}.consumption-page-gridarea_action{grid-area:none;position:absolute;margin-inline-start:16px;height:100%}.above-river-heading{width:${(0,tu.c)(924)}}.breaking-news-banner{width:999px;--feed-width:999px}.consumption-page-content-header-ss{width:${(0,tu.c)(534)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.article_content .consumption-page-content-header.align-left{max-width:688px}.gallery_content .consumption-page-content-header.align-left{max-width:1040px}}.above-river-block{padding-bottom:${(0,tu.c)(20)};min-height:${(0,tu.c)(353)};display:block}.above-river-block.river-bg{background:#F7F7F7;padding-bottom:${(0,tu.c)(0)}}.above-river-heading{margin:0 auto;color:${iL.l};font-size:${(0,tu.c)(20)};font-weight:${"600"};width:${(0,tu.c)(1548)};line-height:${(0,tu.c)(27)};padding-bottom:${(0,tu.c)(20)}}.above-river-block.river-bg .above-river-heading{padding-top:${(0,tu.c)(20)}}@media (max-width:${(0,tu.c)(s.kk)}){.consumption-page-structure,.consumption-page-structure.insight{grid-template-areas:"actions . content .";grid-template-columns:1fr 24px ${(0,tu.c)(s.T6)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr 24px ${(0,tu.c)(s.T6+ef)} 1fr}.consumption-page-structure > .consumption-page-gridarea_rail{display:none}.consumption-page-structure > .consumption-page-gridarea_action{grid-area:actions;position:static;margin-inline-start:16px;height:100%}.consumption-page-content-header-ss{width:${(0,tu.c)(612)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,tu.c)(s.uj)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.uj)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}}${(0,J.H5)(J.j1.c2)}{.consumption-page-structure{grid-template-areas:"actions . content .";grid-template-columns:1fr 24px ${(0,tu.c)(s.T6)} 1fr}.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-structure.insight{grid-template-columns:1fr 0px ${(0,tu.c)(s.k2)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr 24px ${(0,tu.c)(s.T6+ef)} 1fr}.consumption-page-river-heading,.more-for-you-button-container{width:612px}.consumption-page-river-heading-centralized{width:toPx(CONSUMPTION_PAGE_WIDTH_2_COL)}.above-river-heading{width:${(0,tu.c)(612)}}.breaking-news-banner{width:687px;--feed-width:687px}.consumption-page-structure-no-grid .consumption-page-content-header{width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,tu.c)(s.Rq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:calc(100vw - ${(0,tu.c)(s.C)})}.consumption-ruby .consumption-page-structure-no-grid:not(.consumption-page-structure-gem):is(.video_content) ruby-views-action-bar{width:${(0,tu.c)(s.Rq)}}.conversationStartersCompanionIframe{max-width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)});grid-column:1 / -1}.kumo-consumption-page-eocb{max-width:var(--ruby-article-flex-max-width,${(0,tu.c)(s.Rq)})}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.gallery_content .consumption-page-content-header.align-left{max-width:736px}}@media (max-width:${(0,tu.c)(s.KB)}){.consumption-page-structure,.consumption-page-structure.insight{gap:24px;grid-template-areas:"actions content .";grid-template-columns:1fr ${(0,tu.c)(s.X7)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr ${(0,tu.c)(s.X7+ef)} 1fr}}@media (max-width:${(0,tu.c)(s.RA)}){.consumption-page-structure,.consumption-page-structure.insight{gap:0;grid-template-areas:"actions content .";grid-template-columns:1fr ${(0,tu.c)(s.X7)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr ${(0,tu.c)(s.X7+ef)} 1fr}}@media (max-width:${(0,tu.c)(s.HQ)}){.consumption-page-content-header-ss{width:100%}}${(0,J.H5)(J.j1.c1)}{.consumption-page-structure,.consumption-page-structure.insight{grid-template-areas:"content content content";grid-template-columns:1fr 1fr 1fr}.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-gridarea_content{margin-top:8px;padding:0 8px}.consumption-page-gridarea_content.responsive-banner-active{margin-top:0}.consumption-page-structure-no-grid .consumption-page-gridarea_content{padding:0}.consumption-page-river-heading,.more-for-you-button-container{width:300px;text-align:center}.consumption-page-river-heading-centralized{max-width:440px;padding:0 24px}.breaking-news-banner{padding:0px 6px;width:93%}.consumption-page-gridarea_action,.consumption-page-gridarea_rail{display:none}.consumption-error-page{margin:10px}.consumption-page-structure-no-grid .consumption-page-content-header{max-width:100%;padding:0}ruby-views-action-bar.eocb{max-width:min(452px,100%);margin:0 auto}ruby-views-action-bar.action-bar-under-title{max-width:var(--ruby-article-flex-max-width,none);padding-inline-start:8px}.conversationStartersCompanionIframe{max-width:100%;padding:0 24px;grid-column:1 / -1}.kumo-consumption-page-eocb{max-width:452px;margin:0 auto 16px auto}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:calc(100vw - ${(0,tu.c)(s.C)})}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content),.consumption-page-structure-no-grid.consumption-page-structure-gem{width:100%}.gallery_content .consumption-page-content-header.align-left{max-width:360px}@media (min-width:360px) and (max-width:663px){.align-left ruby-views-header::part(ruby-views-header){padding:0}}}@media (max-height:350px){.consumption-page-banner-wrapper{position:unset}}@media (prefers-color-scheme:dark){.consumption-page-gridarea_rail{border-inline-start:1px solid rgba(255,255,255,0.06)}.consumption-page-gridarea_rail .ad-container,.consumption-page-gridarea_rail .mfp-container{background-color:${iD.py}}.consumption-page-content-header{border-bottom:1px solid rgba(255,255,255,0.1)}.consumption-page-feed-wrapper{background-color:#2B2B2B;padding-bottom:${(0,tu.c)(s.NR)}}.above-river-block.river-bg{background:#2B2B2B;padding-bottom:${"0"}}.more-for-you-peek{background:#1F1F1F}.more-for-you-peek-close img{filter:invert(1)}}.ruby-fitcontent{width:fit-content;margin:0 auto}${iV}@media (max-width:${(0,tu.c)(s.kk)}){.consumption-page-structure.extended-right-rail{grid-template-areas:". content . rail .";grid-template-columns:12px minmax(0,1fr) 24px 300px 24px;gap:0}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_rail{display:block;width:300px}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_action{display:none}}@media (max-width:${(0,tu.c)(s.tK)}){.consumption-page-structure.extended-right-rail{grid-template-areas:". content .";grid-template-columns:1fr minmax(0,${(0,tu.c)(s.T6)}) 1fr;gap:0}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_rail{display:none}}`.withBehaviors(new iE.P("prg-rbylyt-t3",iq),new iz.o("enableBigRRAd",!0,iG),new iz.o("enableBigRRAdWithViewport",!0,ij),new iz.o("enableRubyStickyBanner",!0,iW),new iz.o("enableSponsoredArticleLayout",!0,iU),new iz.o("enableExtendedRRBreakpoints",!0,iN)),iX={experienceConfigSchema:void 0}},25987:function(e,t,i){var n,o;i.d(t,{P:function(){return n}}),(o=n||(n={}))[o.Banner=999999]="Banner",o[o.CookieWall=1100]="CookieWall",o[o.Dialog=900]="Dialog",o[o.PersistentNav=800]="PersistentNav",o[o.Flyout=700]="Flyout",o[o.Overlay=600]="Overlay",o[o.Nav=500]="Nav",o[o.Over=300]="Over",o[o.Above=100]="Above",o[o.Default=0]="Default",o[o.Below=-1]="Below",o[o.Buried=-2]="Buried"},37630:function(e,t,i){i.d(t,{n:function(){return o}});var n=i(72627);function o(e=(0,n.$t)()){return/Version\/[\d.]+.*Safari/.test(e)}},72203:function(e,t,i){i.d(t,{$:function(){return o}});var n=i(92011);class o extends n.L{}},57996:function(e,t,i){i.d(t,{_:function(){return v}});var n=i(56911),o=i(60815),r=i(92011),a=i(89757),s=i(69259);let c=(0,a.qy)`<div class="flex-row" style="gap: 12px; align-items: center"><div class="skeleton" style="width: 32px; height: 32px; border-radius: 12px"></div><div class="skeleton" style="width: 108px; height: 14px"></div></div><div class="flex-col" style="gap: 12px; margin-top: 16px"><div class="skeleton" style="width: 100%; height: 24px"></div><div class="skeleton" style="width: 50%; height: 24px"></div></div><div class="flex-row" style="gap: 12px; margin-top: 20px; align-items: center"><div class="skeleton" style="width: 156px; height: 16px"></div><div class="skeleton" style="width: 1px; height: 16px"></div><div class="skeleton" style="width: 72px; height: 16px"></div><div class="skeleton" style="width: 72px; height: 16px"></div></div>`,l=(0,a.qy)`<div class="flex-row" style="justify-content: space-between"><div class="content-section"><div class="flex-col" style="gap: 12px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div><div class="skeleton image-placeholder" style="width: 100%; margin: 32px 0; border-radius: 6px"></div><div class="flex-col" style="gap: 12px; margin-bottom: 32px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div><div class="flex-col" style="gap: 12px; margin-bottom: 32px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div></div></div>`,d=(0,a.qy)`<div class="mrr-section skeleton" style="width: 350px;"></div>`,p=(0,a.qy)`<div class="content-container"><div className="placeholder"></div><div class="content-wrapper" style="overflow: initial">${c}<div class="skeleton" style="width: 100%; height: 1px; margin: 32px 0"></div>${l}</div>${(0,s.z)(e=>!e.disableMrr,d)}</div>`;var g=i(59669),u=i(34241),h=i(47300),m=i(13267),b=i(73686);let f=(0,g.A)` ${u.w} .content-container{position:relative;display:grid;max-width:1600px;margin:0 auto;grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${m.e5.toString()}px minmax(1px,1fr) 348px"}.content-wrapper{max-width:100%;margin:38px auto;grid-area:article;position:relative;width:${b.I7.VIEWS_CONTENT_WIDTH_4_COL.toString()}px}.skeleton{border-radius:100px}.mrr-section{grid-area:rail;margin-top:232px;border-radius:0px}.content-section{width:100%}.image-placeholder{height:448px}${(0,h.H5)(h.j1.c1)}{.content-wrapper{width:100%;margin:16px auto}.mrr-section{display:none}.content-container{position:relative;display:block;margin:0 16px}.image-placeholder{height:250px}}${(0,h.H5)(h.j1.c2)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_2_COL.toString()}px}.mrr-section{display:none}.content-container{grid-template-areas:"article article article";grid-template-columns:"1fr 1fr 1fr"}}${(0,h.H5)(h.j1.c3)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_3_COL.toString()}px}.content-container{grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${m.Xo.toString()}px minmax(1px,1fr) 348px"}}${(0,h.H5)(h.j1.c4)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_4_COL.toString()}px}.content-container{grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${m.e5.toString()}px minmax(1px,1fr) 348px"}}`;var y=i(72203);let v=class extends y.${};(0,n.Cg)([o.sH],v.prototype,"disableMrr",void 0),v=(0,n.Cg)([(0,r.E)({name:"loading-state-article",template:p,styles:f})],v)},21627:function(e,t,i){i.d(t,{c:function(){return I}});var n=i(56911),o=i(92011),r=i(23429),a=i(38493),s=i(60815),c=i(98378),l=i(66591),d=i(82281),p=i(44704);class g extends o.L{constructor(){super(...arguments),this.lineCountClampSeeMore=1,this.lineCountClampExpanded=null,this.isExpanded=!1,this.shouldShowExpanded=!0,this.shouldSeeMoreBelowText=!1,this.shouldImmediatelySeeMore=!1,this.useVideoDetailsStyle=!1,this.useEpisodeStyle=!1,this.telemetry=(()=>{let e=(0,p.N)("SeeMoreDescription",c.MS.More,c.EG.Click),t=(0,p.N)("SeeLessDescription",c.MS.Hide,c.EG.Click);return{externalLinkTelemetryObject:(0,p.N)("ExternalLink",c.MS.Navigate),seeMoreTelemetryObject:e,seeLessTelemetryObject:t}})()}connectedCallback(){super.connectedCallback(),this.setShowExpanded(),this.setupResizeObserver(),this.updateHostExpandedClass()}setShowExpanded(){this.abstractEl&&(this.shouldShowExpanded=this.abstractEl.offsetHeight<this.abstractEl.scrollHeight)}setupResizeObserver(){this.resizeObserver=new ResizeObserver(this.setShowExpanded.bind(this)),this.resizeObserver.observe(this.abstractEl)}updateHostExpandedClass(){this.isExpanded?this.classList.add("expanded"):this.classList.remove("expanded")}onClickToggleDescription(e){this.isExpanded=e,this.updateHostExpandedClass(),window.setTimeout(()=>{this.isExpanded?this.seeLessButton?.focus():this.seeMoreButton?.focus()},100)}onClickSeeMoreButton(){this.shouldImmediatelySeeMore?this.onClickToggleDescription(!0):window.setTimeout(()=>{this.onClickToggleDescription(!0)},100)}textChanged(){r.L.next().then(()=>{this.setShowExpanded(),this.isExpanded=!1,this.updateHostExpandedClass()})}get computedStyles(){return(0,l.x)("see-more",["see-more-bottom",this.shouldSeeMoreBelowText])}get shouldShowSeeMore(){return!!(!this.isExpanded&&this.shouldShowExpanded)}get enableFormattedText(){return(0,d.R)("prg-rich-desc")}disconnectedCallback(){super.disconnectedCallback(),this.resizeObserver&&this.resizeObserver.disconnect()}}(0,n.Cg)([a.CF],g.prototype,"text",void 0),(0,n.Cg)([(0,a.CF)({attribute:"line-count-clamp-see-more"})],g.prototype,"lineCountClampSeeMore",void 0),(0,n.Cg)([(0,a.CF)({attribute:"line-count-clamp-expanded"})],g.prototype,"lineCountClampExpanded",void 0),(0,n.Cg)([s.sH],g.prototype,"isExpanded",void 0),(0,n.Cg)([s.sH],g.prototype,"shouldShowExpanded",void 0),(0,n.Cg)([s.sH],g.prototype,"shouldSeeMoreBelowText",void 0),(0,n.Cg)([s.sH],g.prototype,"shouldImmediatelySeeMore",void 0),(0,n.Cg)([s.sH],g.prototype,"useVideoDetailsStyle",void 0),(0,n.Cg)([s.sH],g.prototype,"useEpisodeStyle",void 0),(0,n.Cg)([s.sH],g.prototype,"strings",void 0),(0,n.Cg)([s.sH],g.prototype,"abstractEl",void 0),(0,n.Cg)([s.Jg],g.prototype,"computedStyles",null),(0,n.Cg)([s.Jg],g.prototype,"shouldShowSeeMore",null);var u=i(47810),h=i(41123),m=i(24496),b=i(59669),f=i(50882),y=i(47300),v=i(13267);let w=(0,b.A)` :focus-visible{outline:solid var(--focus-stroke-outer)}.text-inline-expander-wrapper{display:flex;align-items:baseline;justify-content:space-between}.text-inline-expander-wrapper.see-more-bottom{display:block}.see-more{display:-webkit-box;-webkit-box-orient:vertical;margin-top:0;overflow:hidden;margin-bottom:var(--see-more-margin-bottom,24px);color:var(--expander-color);font-family:var(--expander-font-family);font-size:var(--expander-font-size);font-weight:var(--expander-font-weight);line-height:var(--expander-line-height)}.see-more-btn-container{overflow:initial}.see-more.see-more-bottom{margin-bottom:0}.see-more-btn.see-more-bottom{padding:0px}.text-inline-expander-wrapper .see-more-btn:focus-visible{outline-offset:-3px}${(0,y.H5)(y.j1.c1)}{.see-more{padding:0px;text-overflow:ellipsis}}.clamped-see-more{flex:7}.see-more-btn{background:none;border:none;color:${(0,v.DK)()?"#5CB6FF":"#0066CC"};cursor:pointer;flex:1;-webkit-user-select:none;letter-spacing:inherit;line-height:inherit;word-spacing:inherit;font-family:inherit}@media (forced-colors:active){.see-more-btn{color:${f.A.LinkText}}}.see-more-btn-new-styles{padding:0;margin:0;overflow:hidden;color:var(--expander-button-color,${u.l});font-family:var(--expander-button-font-family);font-size:var(--expander-button-font-size,${h.K});font-weight:var(--expander-button-font-weight,600);line-height:var(--expander-button-line-height,${h.Z})}.see-more-btn.see-more-bottom.see-more-btn-new-styles{padding-top:4px}.see-more-btn-episode{font-family:'Segoe UI';font-style:normal;font-weight:600;font-size:12px;line-height:16px;color:rgba(255,255,255,0.7)}.content a{text-decoration:none;color:${m.W_};pointer:cursor;overflow-wrap:break-word}.content a:hover,.content a:focus{text-decoration:underline}`;var x=i(89757),C=i(60402),R=i(69259),A=i(93809),k=i(7686),$=i(42277);let S=i(68244).F.create({trustedType:{createHTML:e=>k.A.sanitize(e,{RETURN_TRUSTED_TYPE:!0,ALLOWED_TAGS:["a","b","i","strong","em","ul","ol","li","p","span","br"],ALLOWED_ATTR:["href","target"]})},guards:{aspects:{[$.D.property]:{innerHTML:(e,t,i,n)=>(e,t,i,...o)=>{n(e,t,k.A.sanitize(i,{RETURN_TRUSTED_TYPE:!0,ALLOWED_TAGS:["a","b","i","strong","em","ul","ol","li","p","span","br"],ALLOWED_ATTR:["href","target"]}),...o)}}}}}),T=(0,x.qy)`<button ${(0,C.K)("seeLessButton")} tabindex="0" class=${e=>(0,l.x)("see-more-btn",["see-more-btn-new-styles",e.useVideoDetailsStyle],["see-more-btn-episode",e.useEpisodeStyle])} @click=${(e,t)=>e.onClickToggleDescription(!1)} data-t="${e=>e.telemetry.seeLessTelemetryObject.getMetadataTag()}">${e=>e.strings?.seeLess}</button>`,F=(0,x.qy)` ${(0,R.z)(e=>e.useVideoDetailsStyle,(0,x.qy)`<div class=${e=>(0,l.x)(e.computedStyles)}>${T}</div>`)}
`,P=(0,x.qy)` ${(0,R.z)(e=>!e.enableFormattedText,e=>(0,x.qy)`${e.text}`,(0,x.qy)`<div class="content" :innerHTML="${(0,A.U)(e=>{var t,i;let n;return t=e.text,i=e.telemetry.externalLinkTelemetryObject.getMetadataTag(),(n=document.createElement("div")).innerHTML=t,n.querySelectorAll("a").forEach(e=>{e.setAttribute("data-t",i),e.setAttribute("target","_blank")}),n.innerHTML},S)}"></div>`)}
`,B=(0,x.qy)`<div class=${e=>(0,l.x)("text-inline-expander-wrapper",["see-more-bottom",e.shouldSeeMoreBelowText])}><span ${(0,C.K)("abstractEl")} class=${e=>(0,l.x)(e.computedStyles,["clamped-see-more",!e.isExpanded])} tabIndex="0" title=${e=>e.text} style="-webkit-line-clamp:${e=>e.isExpanded?e.lineCountClampExpanded||"initial":e.lineCountClampSeeMore}">${P} ${(0,R.z)(e=>e.isExpanded,(0,x.qy)` ${e=>e.useVideoDetailsStyle?F:T} `)}</span>${(0,R.z)(e=>e.shouldShowSeeMore,(0,x.qy)`<div class=${e=>(0,l.x)(e.computedStyles,"see-more-btn-container")}><button ${(0,C.K)("seeMoreButton")} class=${e=>(0,l.x)("see-more-btn",["see-more-btn-new-styles",e.useVideoDetailsStyle],["see-more-bottom",e.shouldSeeMoreBelowText],["see-more-btn-episode",e.useEpisodeStyle])} @click=${e=>e.onClickSeeMoreButton()} data-t="${e=>e.telemetry.seeMoreTelemetryObject.getMetadataTag()}">${e=>e.strings?.seeMore}</button></div>`)}</div>`,I=class extends g{};I=(0,n.Cg)([(0,o.E)({name:"text-inline-expander",template:B,styles:w})],I)},53791:function(e,t,i){i.d(t,{x7:function(){return eY},VM:function(){return eX},On:function(){return eZ}});var n=i(59669),o=i(22131),r=i(87944),a=i(33544);let s=(0,n.A)`
    :host {
        --width-card-1u: ${(0,r.c)(336)};
        --max-height-adaptive: ${(0,r.c)(368)};
        --max-width-card-adaptive-2c: ${(0,r.c)(360)};
        --max-width-card-adaptive-1u: ${(0,r.c)(360)};
    }
`,c=(0,n.A)`
    :host {
        --min-width-card-adaptive: ${(0,r.c)(300)};
        --max-width-card-adaptive-1u: ${(0,r.c)(368)};
        --min-width-card-adaptive-1u: ${(0,r.c)(272)};
        --min-width-card-adaptive-2c: ${(0,r.c)(300)};
        --max-width-card-adaptive-2c: ${(0,r.c)(368)};
        --max-height-adaptive: ${(0,r.c)(368)};
        --min-height-adaptive: ${(0,r.c)(308)};
        --gutter-size-adaptive: ${(0,r.c)(24)};
    }
`.withBehaviors(new a.P("prg-lg-flex-rev",s)),l=(0,n.A)`
    :host {
        --gap-between-cards-on-feed: ${String(16)};
        --gap-between-cards-on-feed-px: calc(var(--gap-between-cards-on-feed) * 1px);
        --width-card-1u: ${(0,r.c)(368)};
        --width-card-2c: calc(var(--width-card-1u) * 2 + var(--gap-between-cards-on-feed-px));
        --width-card-3c: calc(var(--width-card-1u) * 3 + (var(--gap-between-cards-on-feed-px) * 2));
        --width-card-4c: calc(var(--width-card-1u) * 4 + (var(--gap-between-cards-on-feed-px) * 3));
        --height-card-1u: ${String(344)};
        --height-card-1u-px: calc(var(--height-card-1u) * 1px);
        --height-card-15u: ${String(368)};
        --height-card-15u-px: calc(var(--height-card-15u) * 1px);
    }
    ${c}
`;var d=i(34625),p=i(75117);class g{constructor(e,t){this.market=e,this.___styles=t}connectedCallback(e){let{source:t}=e;p.T3.CurrentMarket===this.market?t.$fastController.addStyles(this.___styles):t.$fastController.removeStyles(this.___styles)}}var u=i(26779);let h=(0,n.A)`
    :host {
        --smtc-text-style-default-header-weight: ${"400"};
    }
`,m=(0,n.A)`
    :host {
        --smtc-text-style-default-regular-font-family: ${u.F6};
        --smtc-style-default-regular-font-family: ${u.F6};
        --smtc-style-default-header-font-family: ${u.F6};
    }
`,b=(0,n.A)`
    :host {
        --smtc-text-style-default-header-weight: ${"500"};
        --smtc-text-style-default-regular-font-family: ${u.YP};
        --smtc-style-default-regular-font-family: ${u.YP};
        --smtc-style-default-header-font-family: ${u.YP};
    }
`,f=(0,n.A)`
    :host {
        --smtc-text-style-default-header-weight: ${"500"};
        --smtc-text-style-default-regular-font-family: ${u.uQ};
        --smtc-style-default-regular-font-family: ${u.uQ};
        --smtc-style-default-header-font-family: ${u.uQ};
    }
`,y=(0,n.A)`
    :host {
        --smtc-text-style-default-header-weight: ${"500"};
        --smtc-text-style-default-regular-font-family: ${u.XK};
        --smtc-style-default-regular-font-family: ${u.XK};
        --smtc-style-default-header-font-family: ${u.XK};
    }
`,v=(0,n.A)`
    :host {
        --min-width-card-adaptive: ${(0,r.c)(300)};
        --max-width-card-adaptive-1u: ${(0,r.c)(320)};
        --min-width-card-adaptive-1u: ${(0,r.c)(272)};
        --min-width-card-adaptive-2c: ${(0,r.c)(300)};
        --max-width-card-adaptive-2c: ${(0,r.c)(320)};
        --max-height-adaptive: ${(0,r.c)(368)};
        --min-height-adaptive: ${(0,r.c)(308)};
    }
`,w=(0,n.A)`
    :host {
        --gap-between-cards-on-feed: ${String(16)};
        --gap-between-cards-on-feed-px: calc(var(--gap-between-cards-on-feed) * 1px);
        --width-card-1u: ${(0,r.c)(300)};
        --width-card-2c: calc(var(--width-card-1u) * 2 + var(--gap-between-cards-on-feed-px));
        --width-card-3c: calc(var(--width-card-1u) * 3 + (var(--gap-between-cards-on-feed-px) * 2));
        --width-card-4c: calc(var(--width-card-1u) * 4 + (var(--gap-between-cards-on-feed-px) * 3));
        --height-card-1u: ${String(308)};
        --height-card-1u-px: calc(var(--height-card-1u) * 1px);
        --height-card-15u: ${String(368)};
        --height-card-15u-px: calc(var(--height-card-15u) * 1px);
        --height-card-2c: ${String(308)};
        --height-card-2c-px: calc(var(--height-card-2c) * 1px);
    }
    ${v}
`,x=(0,n.A)`
    :host {
        --smtc-mai-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.24);
        --smtc-mai-shadow-ctrl-neutral-key-color: rgba(0, 0, 0, 0.24);
        --smtc-theme-color-effect-inner-shine-strong: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-effect-shadow-medium: rgba(0, 0, 0, 0.18);
        --smtc-theme-color-overlay-white-45: rgba(0, 0, 0, 0.45);
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 1px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-color: rgba(255, 255, 255, 0.12);
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        --smtc-shadow-ctrl-button-neutral-rest-key-color: rgba(0, 0, 0, 0.40);
        --smtc-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.40);
        --smtc-shadow-ctrl-fab-rest-key-color: hsla(0, 0.00%, 100.00%, 0.00);
        --smtc-shadow-ctrl-fab-rest-ambient-color: rgba(0, 0, 0, 0.12);
        --smtc-shadow-ctrl-fab-disabled-key-color: hsla(0, 0.00%, 100.00%, 0.00);
        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
        --smtc-shadow-ctrl-fab-hover-key-color: rgba(0, 0, 0, 0.25);
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
        --smtc-theme-color-shadow-sm-key: rgba(0, 0, 0, 0.25);
        --smtc-theme-color-shadow-sm-ambient: rgba(0, 0, 0, 0.00);
        --smtc-theme-color-shadow-sm-contour: rgba(0, 0, 0, 0.08);
        --smtc-effect-shadow-sm-key-x-offset: 0px;
        --smtc-effect-shadow-sm-key-y-offset: 1px;
        --smtc-effect-shadow-sm-key-blur-radius: 3px;
        --smtc-effect-shadow-sm-key-spread: 0px;
        --smtc-effect-shadow-sm-ambient-x-offset: 0px;
        --smtc-effect-shadow-sm-ambient-y-offset: 0px;
        --smtc-effect-shadow-sm-ambient-blur-radius: 0px;
        --smtc-effect-shadow-sm-ambient-spread: 0px;
        --smtc-effect-shadow-sm-contour-x-offset: 0px;
        --smtc-effect-shadow-sm-contour-y-offset: 0px;
        --smtc-effect-shadow-sm-contour-blur-radius: 1px;
        --smtc-effect-shadow-sm-contour-spread: 0px;
    }
`,C=(0,n.A)`
    :host {
        --smtc-mai-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.12);
        --smtc-mai-shadow-ctrl-neutral-key-color: rgba(0, 0, 0, 0.12);
        --smtc-theme-color-effect-shadow-medium: rgba(0, 0, 0, 0.08);
        --smtc-theme-color-effect-inner-shine-strong: #FFFFFF;
        --smtc-theme-color-overlay-white-45: rgba(255, 255, 255, 0.45);
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-color: #FFFFFF;
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        --smtc-shadow-ctrl-button-neutral-rest-key-color: rgba(0, 0, 0, 0.20);
        --smtc-shadow-ctrl-brand-key-x: 0px;
        --smtc-shadow-ctrl-brand-key-y: 0.5px;
        --smtc-shadow-ctrl-brand-key-blur: 3px;
        --smtc-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.20);
        --smtc-shadow-ctrl-fab-rest-key-x: 0px;
        --smtc-shadow-ctrl-fab-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-key-blur: 3px;
        --smtc-shadow-ctrl-fab-rest-key-color: rgba(27, 53, 86, 0.08);
        --smtc-shadow-ctrl-fab-rest-ambient-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-blur: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-color: rgba(27, 53, 86, 0.04);
        --smtc-shadow-ctrl-fab-disabled-key-y: 4px;
        --smtc-shadow-ctrl-fab-disabled-key-blur: 6px;
        --smtc-shadow-ctrl-fab-disabled-key-color: rgba(0, 0, 0, 0.15);
        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
        --smtc-shadow-ctrl-fab-hover-key-color: rgba(0, 0, 0, 0.15);
        --smtc-shadow-flyout-ambient-blur: 0px;
        --smtc-shadow-flyout-ambient-color: rgba(255, 255, 255, 0);
        --smtc-shadow-flyout-ambient-x: 0px;
        --smtc-shadow-flyout-ambient-y: 0px;
        --smtc-shadow-flyout-key-blur: 12px;
        --smtc-shadow-flyout-key-color: rgba(0, 0, 0, 0.08);
        --smtc-shadow-flyout-key-x: 0px;
        --smtc-shadow-flyout-key-y: 6px;
        --smtc-effect-drop-shadow-medium-x-offset: 0px;
        --smtc-effect-drop-shadow-medium-y-offset: 6px;
        --smtc-effect-drop-shadow-medium-blur-radius: 12px;
        --smtc-effect-drop-shadow-medium-spread: 0px;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
        --smtc-theme-color-shadow-sm-key: rgba(0, 0, 0, 0.15);
        --smtc-theme-color-shadow-sm-ambient: rgba(0, 0, 0, 0.00);
        --smtc-theme-color-shadow-sm-contour: rgba(0, 0, 0, 0.15);
        --smtc-effect-shadow-sm-key-x-offset: 0px;
        --smtc-effect-shadow-sm-key-y-offset: 1px;
        --smtc-effect-shadow-sm-key-blur-radius: 3px;
        --smtc-effect-shadow-sm-key-spread: 0px;
        --smtc-effect-shadow-sm-ambient-x-offset: 0px;
        --smtc-effect-shadow-sm-ambient-y-offset: 0px;
        --smtc-effect-shadow-sm-ambient-blur-radius: 0px;
        --smtc-effect-shadow-sm-ambient-spread: 0px;
        --smtc-effect-shadow-sm-contour-x-offset: 0px;
        --smtc-effect-shadow-sm-contour-y-offset: 0px;
        --smtc-effect-shadow-sm-contour-blur-radius: 1px;
        --smtc-effect-shadow-sm-contour-spread: 0px;
    }
        
`,R=(0,n.A)`
    :host {
        --smtc-status-brand-tint-background: #586ba84d;
        --smtc-status-brand-tint-foreground: #97abea;
        --smtc-status-brand-tint-stroke: #9AACE1;
        --smtc-status-informative-tint-foreground: #e5ebfa;
        --smtc-status-informative-tint-background: #1f2431;
        --smtc-status-informative-tint-background-ad: #0F1119;
        --smtc-status-informative-background: #e5ebfa;
        --smtc-edge-ctrl-workspace-background-blue-rest: #69A1FA;
        --smtc-status-success-background: #6CC57B;
        --smtc-status-warning-background: #F3C357;
        --smtc-status-warning-foreground: #000000;
        --smtc-status-danger-background: #f98981;
        --smtc-status-danger-foreground: #000000;
        --smtc-status-danger-tint-foreground: #F98981;
        --smtc-status-danger-tint-background: rgba(157, 25, 32, 0.2);
        --smtc-status-danger-tint-stroke: #F98981;
        --smtc-status-success-tint-foreground: #6CC57B;
        --smtc-status-success-tint-background: rgba(9, 102, 32, 0.20);
        --smtc-status-success-tint-stroke: #6CC57B;
        --smtc-foreground-highlight-accent: #97ABEA;
    }
`,A=(0,n.A)`
    :host {
        --smtc-status-brand-tint-background: #e09e664d;
        --smtc-status-brand-tint-foreground: #6b3900;
        --smtc-status-brand-tint-stroke: #6B3900;
        --smtc-status-informative-foreground: #ffffff;
        --smtc-status-informative-tint-foreground: #272320;
        --smtc-status-informative-tint-background: #efeae7;
        --smtc-status-informative-tint-background-ad: #FFFBF8;
        --smtc-status-informative-background: #272320;
        --smtc-edge-ctrl-workspace-background-blue-rest: #2169EB;
        --smtc-status-success-background: #01712B;
        --smtc-status-warning-background: #A25A02;
        --smtc-status-warning-foreground: #ffffff;
        --smtc-status-danger-background: #ac1922;
        --smtc-status-danger-foreground: #ffffff;
        --smtc-status-danger-tint-foreground: #AC1922;
        --smtc-status-danger-tint-background: rgba(255, 181, 174, 0.2);
        --smtc-status-danger-tint-stroke: #AC1922;
        --smtc-status-success-tint-foreground: #01712B;
        --smtc-status-success-tint-background: rgba(148, 220, 127, 0.20);
        --smtc-status-success-tint-stroke: #01712B;
        --smtc-foreground-highlight-accent: #A25A02;
    }
`,k=(0,n.A)`
    :host {
        --smtc-background-ctrl-onBrand-hover: #525C7B;
        --smtc-background-ctrl-onBrand-pressed: #3E4760;
        --smtc-background-ctrl-neutral-pressed: #1f2330a6;
        --smtc-background-ctrl-subtle-selected-rest: #ffffff14;
        --smtc-background-ctrl-subtle-hover: #ffffff14;
        --smtc-background-flyout-color-blend: #ffffff00;
        --smtc-background-flyout-lum-blend: #ffffff00;
        --smtc-background-flyout-solid: #1b233ae8;
        --smtc-background-layer-primary-solid: #9da8d91a;
        --smtc-theme-color-accent-300: #5A2D1A;
        --smtc-theme-color-accent-450: #4458A0;
        --smtc-theme-color-background-200: #1f2431;
        --smtc-theme-color-background-250: #282d3e;
        --smtc-theme-color-background-300: #333A4E;
        --smtc-theme-color-background-700: #C2CADF;
        --smtc-theme-color-background-acrylic-thin-luminosity: rgba(27, 35, 58, 0.60);
        --smtc-theme-color-background-acrylic-thin-saturation: rgba(255, 255, 0, 0.05);
        --smtc-theme-color-background-acrylic-thin-tint: rgba(27, 35, 58, 0.50);
        --smtc-theme-color-background-page-chat-fade: #1F2431;
        --smtc-theme-color-background-page-chat-flat: #151a28;
        --smtc-theme-color-background-page-home-web-stop-0: #0C101C;
        --smtc-theme-color-background-page-home-web-stop-1: #171E32;
        --smtc-theme-color-background-page-home-web-stop-2: #242F50;
        --smtc-theme-color-background-acrylic-default-tint: rgba(27, 35, 58, 0.91);
        --smtc-theme-color-background-acrylic-default-saturation: rgba(255, 255, 0, 0.10);
        --smtc-background-web-page-primary: #111524;
        --smtc-background-ctrl-on-image-lum-blend: rgba(23, 30, 50, 0.60);
        --smtc-background-ctrl-on-image-rest: #455172;
        --smtc-background-ctrl-on-image-saturation-blend: rgba(255, 255, 255, 0.00);
        --smtc-background-card-on-primary-alt-hover: #9da8d91a;
        --smtc-background-card-on-primary-alt-pressed: #9da8d91a;
        --smtc-background-card-on-primary-alt-rest: #9da8d91a;
        --smtc-background-card-on-primary-default-rest: #9da8d91a;
        --smtc-background-card-on-secondary-default-rest: rgba(157, 168, 217, 0.05);
        --smtc-background-ctrl-active-brand-hover: #eef1f6ff;
        --smtc-background-ctrl-active-brand-pressed: #dce0e5ff;
        --smtc-background-ctrl-active-brand-rest: #f6fafeff;
        --smtc-background-ctrl-brand-hover: #525c7b;
        --smtc-background-ctrl-brand-rest: #4a5471;
        --smtc-background-ctrl-brand-pressed: #3e4760;
        --smtc-background-ctrl-brand-disabled: #ffffff0d;
        --smtc-background-ctrl-neutral-hover: #313a52a6;
        --smtc-background-ctrl-neutral-rest: #323f60a6;
        --smtc-background-ctrl-neutral-disabled: #ffffff0d;
        --smtc-background-ctrl-outline-rest: #ffffff00;
        --smtc-background-ctrl-outline-hover: #ffffff14;
        --smtc-background-ctrl-outline-pressed: #ffffff0d;
        --smtc-background-ctrl-outline-disabled: #ffffff00;
        --smtc-background-ctrl-subtle-rest: #ffffff00;
        --smtc-background-ctrl-subtle-pressed: #ffffff0d;
        --smtc-background-tint-neutral: #171E32;
        --smtc-background-webPage-primary: #1C2024;
        --smtc-ctrl-fab-background-rest: #151a28;
        --smtc-ctrl-fab-background-hover: #171a25;
        --smtc-ctrl-fab-background-pressed: #0f1119;
        --smtc-ctrl-input-background-rest: #47599740;
        --smtc-ctrl-choice-base-background-rest: #00000000;
        --smtc-ctrl-choice-switch-background-selected-rest: #4ba849ff;
        --smtc-ctrl-choice-switch-background-rest: rgba(255, 255, 255, 0.20);
        --smtc-ctrl-choice-switch-thumb-background-rest: rgba(255, 255, 255, 0.90);
        --smtc-ctrl-choice-switch-thumb-background-selected-rest: #ffffff;
        --smtc-ctrl-list-background-selected-rest: rgba(255, 255, 255, 0.08);
        --smtc-ctrl-list-background-selected-hover: rgba(255, 255, 255, 0.05);
        --smtc-ctrl-lite-filter-background-selected: #E5EBFA;
        --smtc-ctrl-progress-background-empty: #ffffff26;
        --smtc-ctrl-tooltip-background: #0f1119;
        --smtc-ctrl-tooltip-shadow-ambient-color: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-tooltip-shadow-key-color: rgba(0, 0, 0, 0.15);
        --smtc-edge-ctrl-workspace-background-blue-rest: #69A1FA;
        --mai-background-ctrl-onImage-rest: #1F2431;
        --mai-background-ctrl-onImage-hover: #282D3E;
        --mai-background-ctrl-onImage-pressed: #171A25;
        --smtc-background-window-tab-band-solid: #0e111b;
        --smtc-background-card-on-flyout-default-rest: #FFFFFF0D;
        --smtc-theme-color-shadow-highlight: rgba(255, 255, 255, 0.012);
        --smtc-status-warning-tint-background: rgba(162, 90, 2, 0.20);
    }
`,$=(0,n.A)`
    :host {
        --smtc-theme-color-background-acrylic-thin-tint: rgba(250, 244, 239, 0.60);
        --smtc-theme-color-background-page-chat-flat: #f8f4f1;
        --smtc-theme-color-background-page-home-web-stop-0: #F8F4F2;
        --smtc-theme-color-background-acrylic-default-tint: rgba(255, 255, 255, 0.94);
        --smtc-theme-color-background-acrylic-default-saturation: rgba(255, 255, 0, 0.10);
        --smtc-background-ctrl-onBrand-hover: #000000;
        --smtc-background-ctrl-onBrand-pressed: #322D29;
        --smtc-background-ctrl-neutral-pressed: #ffffff99;
        --smtc-background-ctrl-subtle-selected-rest: #00000014;
        --smtc-background-ctrl-subtle-hover: #0000000d;
        --smtc-background-flyout-color-blend: #ffffff00;
        --smtc-background-flyout-lum-blend: #ffffff00;
        --smtc-background-flyout-solid: #fffffff0;
        --smtc-background-layer-primary-solid: #ffffff73;
        --smtc-theme-color-accent-300: #F8BC8C;
        --smtc-theme-color-accent-450: #AD6446;
        --smtc-theme-color-background-200: #f0eae5;
        --smtc-theme-color-background-250: #e3ddd8;
        --smtc-theme-color-background-300: #CCC6C2;
        --smtc-theme-color-background-700: #3F3935;
        --smtc-theme-color-background-acrylic-thin-luminosity: rgba(240, 234, 229, 0.80);
        --smtc-theme-color-background-acrylic-thin-saturation: rgba(255, 255, 0, 0.10);
        --smtc-theme-color-background-page-chat-fade: #F0EAE5;
        --smtc-theme-color-background-page-home-web-stop-1: #FCF3EA;
        --smtc-theme-color-background-page-home-web-stop-2: #FDEDDE;
        --smtc-background-web-page-primary: #F8F4F1;
        --smtc-background-card-on-primary-default-rest: #ffffffcc;
        --smtc-background-card-on-primary-alt-hover: #ffffff73;
        --smtc-background-card-on-primary-alt-pressed: #ffffff73;
        --smtc-background-card-on-primary-alt-rest: #ffffff73;
        --smtc-background-card-on-secondary-default-rest: rgba(204, 196, 192, 0.20);
        --smtc-background-ctrl-active-brand-hover: #2b2e35ff;
        --smtc-background-ctrl-active-brand-pressed: #383b43ff;
        --smtc-background-ctrl-active-brand-rest: #24282fff;
        --smtc-background-ctrl-brand-hover: #000000;
        --smtc-background-ctrl-brand-rest: #272320;
        --smtc-background-ctrl-brand-pressed: #322d29;
        --smtc-background-ctrl-brand-disabled: #0000000d;
        --smtc-background-ctrl-neutral-hover: #ffffff;
        --smtc-background-ctrl-neutral-rest: #ffffffb3;
        --smtc-background-ctrl-neutral-disabled: #ffffff2e;
        --smtc-background-ctrl-outline-rest: #00000000;
        --smtc-background-ctrl-outline-hover: #0000000d;
        --smtc-background-ctrl-outline-pressed: #00000008;
        --smtc-background-ctrl-outline-disabled: #00000000;
        --smtc-background-ctrl-subtle-rest: #00000000;
        --smtc-background-ctrl-subtle-pressed: #00000008;
        --smtc-background-tint-neutral: #F4EFED;
        --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 0.10);
        --smtc-background-ctrl-on-image-lum-blend: rgba(228, 230, 241, 0.80);
        --smtc-background-ctrl-on-image-rest: #282523;
        --smtc-background-ctrl-on-image-saturation-blend: rgba(255, 255, 0, 0.10);
        --smtc-background-webPage-primary: #FFFFFF;
        --smtc-ctrl-fab-background-rest: #ffffff;
        --smtc-ctrl-fab-background-hover: #f8f4f1;
        --smtc-ctrl-fab-background-pressed: #fffbf8;
        --smtc-ctrl-input-background-rest: #0000000d;
        --smtc-ctrl-choice-base-background-rest: #ffffff00;
        --smtc-ctrl-choice-switch-background-selected-rest: #4ba849ff;
        --smtc-ctrl-choice-switch-background-rest: rgba(0, 0, 0, 0.20);
        --smtc-ctrl-choice-switch-thumb-background-rest: rgba(255, 255, 255, 0.90);
        --smtc-ctrl-choice-switch-thumb-background-selected-rest: #ffffff;
        --smtc-ctrl-list-background-selected-rest: rgba(0, 0, 0, 0.08);
        --smtc-ctrl-list-background-selected-hover: rgba(0, 0, 0, 0.05);
        --smtc-ctrl-lite-filter-background-selected: #272320;
        --smtc-ctrl-progress-background-empty: #00000026;
        --smtc-ctrl-tooltip-background: #FFFBF8;
        --smtc-ctrl-tooltip-shadow-ambient-color: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-tooltip-shadow-key-color: rgba(0, 0, 0, 0.08);
        --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 0.10);
        --mai-background-ctrl-onImage-rest: #272320;
        --mai-background-ctrl-onImage-hover: #000000;
        --mai-background-ctrl-onImage-pressed: #322D29;
        --smtc-background-window-tab-band-solid: #efeae7;
        --smtc-background-card-on-flyout-default-rest: #0000000D;
        --smtc-theme-color-shadow-highlight: rgba(255, 255, 255, 0.90);
        --smtc-status-warning-tint-background: rgba(243, 195, 87, 0.20);
    }
`,S=(0,n.A)`
    :host {
        --smtc-foreground-control-neutral-primary-rest: #FFFFFF;
        --smtc-foreground-ctrl-neutral-primary-rest: #e5ebfa;
        --smtc-theme-color-foreground-primary-100: #0f1119;
        --smtc-theme-color-foreground-primary-450: #525C7B;
        --smtc-theme-color-foreground-primary-550: #626D8F;
        --smtc-theme-color-foreground-primary-700: #a4adc8;
        --smtc-theme-color-foreground-primary-750: #c2cadf;
        --smtc-theme-color-foreground-primary-800: #d7deef;
        --smtc-theme-color-foreground-primary-850: #e5ebfa;
        --smtc-theme-color-foreground-primary-900: #f1f5ff;
        --smtc-theme-color-foreground-secondary-400: #626d8f;
        --smtc-theme-color-foreground-secondary-450: #8791b0;
        --smtc-theme-color-foreground-secondary-550: #8791b0;
        --smtc-theme-color-foreground-secondary-600: #a4adc8;
        --smtc-theme-color-foreground-secondary-650: #c2cadf;
        --smtc-theme-color-foreground-secondary-700: #d7deef;
        --smtc-theme-color-foreground-secondary-750: #e5ebfa;
        --smtc-theme-color-foreground-secondary-800: #f1f5ff;
        --smtc-theme-color-component-button-foreground-rest: #E5EBFA;
        --smtc-theme-color-component-button-foreground-pressed: #A4ADC8;
        --smtc-theme-color-component-button-strong-foreground-rest: #392D2E;
        --smtc-foreground-tint-neutral: #F2DDCC;
        --smtc-foreground-ctrl-neutral-primary-disabled: #ffffff4d;
        --smtc-foreground-ctrl-neutral-primary-pressed: #a4adc8;
        --smtc-foreground-ctrl-neutral-secondary-rest: #a4adc8;
        --smtc-foreground-ctrl-neutral-secondary-hover: #828BAC;
        --smtc-foreground-ctrl-active-brand-hover: #F1F5FF;
        --smtc-foreground-ctrl-active-brand-pressed: #D7DEEF;
        --smtc-foreground-ctrl-active-brand-rest: #E5EBFA;
        --smtc-foreground-ctrl-hint-default: #333A4E;
        --smtc-foreground-ctrl-on-brand-rest: #d7deef;
        --smtc-foreground-ctrl-on-brand-hover: #392D2E;
        --smtc-foreground-ctrl-on-brand-pressed: #a4adc8;
        --smtc-foreground-ctrl-on-brand-disabled: #ffffff4d;
        --smtc-foreground-ctrl-on-image-rest: #E3CBBC;
        --smtc-foreground-ctrl-on-outline-disabled: #5b5f64ff;
        --smtc-foreground-ctrl-on-outline-rest: #E5EBFA;
        --smtc-foreground-ctrl-on-outline-hover: #E5EBFA;
        --smtc-foreground-ctrl-on-outline-pressed: #a4adc8;
        --smtc-foreground-ctrl-on-subtle-hover: #D7DEEF;
        --smtc-foreground-ctrl-on-subtle-rest: #D7DEEF;
        --smtc-foreground-ctrl-on-subtle-pressed: #8791B0;
        --smtc-foreground-ctrl-on-transparent-rest: #E5EBFA;
        --smtc-foreground-ctrl-on-transparent-hover: #E5EBFA;
        --smtc-foreground-ctrl-on-transparent-pressed: #A4ADC8;
        --smtc-foreground-neutral-primary: #FFFFFF;
        --smtc-foreground-neutral-secondary: #C3C8CE;
        --smtc-foreground-link-rest: #3792FD;
        --smtc-ctrl-link-foreground-brand-rest: #5369b6;
        --smtc-ctrl-link-foreground-brand-hover: #5369b6;
        --smtc-ctrl-link-foreground-brand-pressed: #5369b6;
        --smtc-ctrl-link-foreground-neutral-rest: #E5EBFA;
        --smtc-ctrl-lite-filter-foreground-selected: #282D3E;
        --smtc-ctrl-tooltip-foreground: #D7DEEF;
        --smtc-status-warning-tint-foreground: #A25A02;
    }
`,T=(0,n.A)`
    :host {
        --smtc-foreground-control-neutral-primary-rest: #23272B;
        --smtc-foreground-ctrl-neutral-primary-rest: #272320;
        --smtc-theme-color-foreground-primary-100: #E5EBFA;
        --smtc-theme-color-foreground-primary-450: #746D68;
        --smtc-theme-color-foreground-primary-550: #635C57;
        --smtc-theme-color-foreground-primary-700: #3f3935;
        --smtc-theme-color-foreground-primary-750: #322d29;
        --smtc-theme-color-foreground-primary-800: #272320;
        --smtc-theme-color-foreground-primary-850: #191513;
        --smtc-theme-color-foreground-primary-900: #14110e;
        --smtc-theme-color-foreground-secondary-400: #98918b;
        --smtc-theme-color-foreground-secondary-450: #746d68;
        --smtc-theme-color-foreground-secondary-550: #635c57;
        --smtc-theme-color-foreground-secondary-600: #5a544f;
        --smtc-theme-color-foreground-secondary-650: #4c4642;
        --smtc-theme-color-foreground-secondary-700: #3f3935;
        --smtc-theme-color-foreground-secondary-750: #322d29;
        --smtc-theme-color-foreground-secondary-800: #272320;
        --smtc-theme-color-component-button-foreground-rest: #282523;
        --smtc-theme-color-component-button-foreground-pressed: #57514F;
        --smtc-theme-color-component-button-strong-foreground-rest: #F4EFED;
        --smtc-foreground-ctrl-neutral-primary-disabled: #0000004d;
        --smtc-foreground-ctrl-neutral-primary-pressed: #5a544f;
        --smtc-foreground-ctrl-neutral-secondary-rest: #4c4642;
        --smtc-foreground-ctrl-neutral-secondary-hover: #635D5A;
        --smtc-foreground-ctrl-active-brand-pressed: #322D29;
        --smtc-foreground-ctrl-active-brand-hover: #000;
        --smtc-foreground-ctrl-active-brand-rest: #272320ff;
        --smtc-foreground-ctrl-hint-default: #CCC6C2;
        --smtc-foreground-ctrl-on-brand-rest: #e2ddd9;
        --smtc-foreground-ctrl-on-brand-hover: #F4EFED;
        --smtc-foreground-ctrl-on-brand-pressed: #b3ada8;
        --smtc-foreground-ctrl-on-brand-disabled: #0000004d;
        --smtc-foreground-ctrl-on-image-rest: #ffffff;
        --smtc-foreground-ctrl-on-outline-disabled: #a4a9b0ff;
        --smtc-foreground-ctrl-on-outline-rest: #272320;
        --smtc-foreground-ctrl-on-outline-hover: #282523;
        --smtc-foreground-ctrl-on-outline-pressed: #5a544f;
        --smtc-foreground-ctrl-on-subtle-rest: #272320;
        --smtc-foreground-ctrl-on-subtle-hover: #272320;
        --smtc-foreground-ctrl-on-subtle-pressed: #5A544F;
        --smtc-foreground-ctrl-on-transparent-rest: #272320;
        --smtc-foreground-ctrl-on-transparent-hover: #272320;
        --smtc-foreground-ctrl-on-transparent-pressed: #5A544F;
        --smtc-foreground-neutral-primary: #23272B;
        --smtc-foreground-neutral-secondary: #474B50;
        --smtc-foreground-link-rest: #026FD7;
        --smtc-foreground-tint-blue: #4193ff;
        --smtc-foreground-tint-neutral: #282523;
        --smtc-ctrl-link-foreground-brand-rest: #8a4b01;
        --smtc-ctrl-link-foreground-brand-hover: #8a4b01;
        --smtc-ctrl-link-foreground-brand-pressed: #8a4b01;
        --smtc-ctrl-link-foreground-neutral-rest: #272320;
        --smtc-ctrl-lite-filter-foreground-selected: #E2DDD9;
        --smtc-ctrl-tooltip-foreground: #322D29;
        --smtc-status-warning-tint-foreground: #A25A02;
    }
`,F=(0,n.A)`
    :host {
        --smtc-stroke-divider-default: #354479;
        --smtc-theme-color-stroke-default-250: #282F42;
        --smtc-theme-color-stroke-default-300: #313A52;
        --smtc-theme-color-stroke-default-350: #455172;
        --smtc-theme-color-stroke-default-450: #6B7597;
        --smtc-theme-color-stroke-default-550: #3E5091;
        --smtc-theme-color-accent-350: #354479;
        --smtc-theme-color-accent-300: #2C3860;
        --smtc-theme-color-stroke-muted-200: #1F2330;
        --smtc-theme-color-stroke-muted-250:  #333A4E;
        --smtc-theme-color-stroke-muted-300: #3E4760;
        --smtc-stroke-ctrl-on-outline-disabled: #ffffff14;
        --smtc-stroke-ctrl-on-outline-hover: #ffffff14;
        --smtc-stroke-ctrl-on-outline-pressed: #ffffff14;
        --smtc-stroke-ctrl-on-outline-rest: #ffffff14;
        --smtc-stroke-card-on-primary-rest: #ffffff26;
        --smtc-stroke-divider-subtle: #ffffff1a;
        --smtc-stroke-flyout: #FFFFFF1F;
        --smtc-ctrl-input-stroke-rest: #ffffff0d;
        --smtc-ctrl-input-stroke-selected: #c2cadf;
        --smtc-ctrl-choice-base-stroke-rest: #9DA8D9;
        --smtc-ctrl-choice-base-stroke-disabled: rgba(255, 255, 255, 0.3);
        --smtc-ctrl-choice-switch-stroke-rest: rgba(255, 255, 255, 0);
        --smtc-ctrl-source-icon-border: #0F1119;
        --smtc-edge-ctrl-omnibox-stroke-focused: #ffffff;
        --smtc-status-informative-tint-stroke: #333A4E;
        --smtc-mai-ctrl-tooltip-stroke: rgba(0, 0, 0, 0.20);
    }
`,P=(0,n.A)`
    :host {
        --smtc-stroke-divider-default: #dac6b7;
        --smtc-theme-color-stroke-default-250: #F2DDCC;
        --smtc-theme-color-stroke-default-300: #E3CBBC;
        --smtc-theme-color-stroke-default-350: #BBA5A0;
        --smtc-theme-color-stroke-default-450: #867073;
        --smtc-theme-color-stroke-default-550: #CA7D36;
        --smtc-theme-color-accent-350: #E29C61;
        --smtc-theme-color-accent-300: #F8BC8C;
        --smtc-theme-color-stroke-muted-200: #F4EFED;
        --smtc-theme-color-stroke-muted-250: #E2DDD9;
        --smtc-theme-color-stroke-muted-300: #D0C9C4;
        --smtc-stroke-ctrl-on-outline-disabled: #00000014;
        --smtc-stroke-ctrl-on-outline-hover: #00000014;
        --smtc-stroke-ctrl-on-outline-pressed: #00000014;
        --smtc-stroke-ctrl-on-outline-rest: #00000014;
        --smtc-stroke-card-on-primary-rest: #0000001f;
        --smtc-stroke-divider-subtle: #0000001a;
        --smtc-stroke-flyout: #FFFFFFE5;
        --smtc-ctrl-input-stroke-rest: #0000000d;
        --smtc-ctrl-input-stroke-selected: #3f3935;
        --smtc-ctrl-choice-base-stroke-rest: #4A4543;
        --smtc-ctrl-choice-base-stroke-disabled: rgba(0, 0, 0, 0.3);
        --smtc-ctrl-choice-switch-stroke-rest: rgba(0, 0, 0, 0);
        --smtc-ctrl-badge-stroke: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-source-icon-border: #FFFBF8;
        --smtc-edge-ctrl-omnibox-stroke-focused: #000000;
        --smtc-status-informative-tint-stroke: #E2DDD9;
        --smtc-mai-ctrl-tooltip-stroke: rgba(255, 255, 255, 0.20);
    }
`,B=(0,n.A)`
   ${x}
   ${k}
   ${S}
   ${F}
   ${R}
`,I=(0,n.A)`
   ${C}
   ${$}
   ${T}
   ${P}
   ${A}
`.withBehaviors((0,o.G2)(B)),H=(0,n.A)`
    :host {
        --smtc-material-acrylic-blur: 60px;        
        --smtc-mai-shadow-ctrl-brand-key-blur: 3px;
        --smtc-mai-shadow-ctrl-brand-key-x: 0;
        --smtc-mai-shadow-ctrl-brand-key-y: 1px;
    }
`,D=(0,n.A)`
    :host {
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0.5px;
        
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        
        --smtc-shadow-ctrl-brand-key-x: 0px;
        --smtc-shadow-ctrl-brand-key-y: 0.5px;
        --smtc-shadow-ctrl-brand-key-blur: 3px;
    }
`,_=(0,n.A)`
    :host {
        --smtc-shadow-ctrl-fab-rest-key-x: 0px;
        --smtc-shadow-ctrl-fab-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-key-blur: 3px;
        
        --smtc-shadow-ctrl-fab-rest-ambient-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-blur: 0.5px;

        --smtc-shadow-ctrl-fab-disabled-key-y: 4px;
        --smtc-shadow-ctrl-fab-disabled-key-blur: 6px;

        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
    }
`,E=(0,n.A)`
    :host {
        --smtc-shadow-flyout-ambient-x: 0px;
        --smtc-shadow-flyout-ambient-y: 0px;
        --smtc-shadow-flyout-ambient-blur: 0px;
        
        --smtc-shadow-flyout-key-x: 0px;
        --smtc-shadow-flyout-key-y: 6px;
        --smtc-shadow-flyout-key-blur: 12px;
    }
`,M=(0,n.A)`
    :host {
        --smtc-effect-drop-shadow-medium-x-offset: 0px;
        --smtc-effect-drop-shadow-medium-y-offset: 6px;
        --smtc-effect-drop-shadow-medium-blur-radius: 12px;
        --smtc-effect-drop-shadow-medium-spread: 0px;
    }
`,O=(0,n.A)`
    ${D}
`;var V=i(25975);let z=(0,n.A)`
    :host {
        --cstm-corner-media-in-card: calc(28px * ${V.MU6});
    }
`;(0,n.A)`${z}`,(0,n.A)`${z}`;let L=(0,n.A)`${z}`,N=(0,n.A)`${z}`,G=(0,n.A)`
    :host {
        --smtc-corner-card-small-rest: 48px;
        --smtc-corner-card-rest: 24px;
        --smtc-corner-card-nested-small-outside: 36px;
        --smtc-corner-card-nested-small-inside: 36px;
        --smtc-corner-card-discover-nested-outside: 48px;
        --smtc-corner-card-discover-nested-inside: 32px;
        --smtc-corner-card-alternate-small-rest: 24px;
        --mai-smtc-corner-card-default: 60px;
        --mai-smtc-corner-card-nested-small-outside: 36px;
        --mai-smtc-corner-card-nested-default-inside: 32px;
        --mai-smtc-corner-card-nested-default-outside: 48px;
        --mai-smtc-corner-card-nested-large-inside: 32px;
        --mai-smtc-corner-card-nested-large-outside: 48px;
    }
`,W=(0,n.A)`
    :host {
        --smtc-corner-ctrl-fab-rest: 24px;
        --smtc-corner-ctrl-sm-rest: 12px;
        --smtc-corner-ctrl-lg-rest: 20px;
        --smtc-corner-ctrl-hover: 12px;
        --smtc-corner-ctrl-rest: 12px;
        --smtc-corner-ctrl-sm-hover: 14px;
        --smtc-ctrl-badge-corner: 8px;
        --smtc-ctrl-badge-sm-corner: 8px;
        --smtc-ctrl-choice-checkbox-corner: 9999px;
    }
`,j=(0,n.A)`
    :host {
        --smtc-corner-layer-default: 16px;
        --smtc-corner-favicon: 6px;
        --smtc-corner-flyout-rest: 20px;
        --smtc-corner-rounded-5-rem: 20px;
        --smtc-static-corner-rounded-3-base: 12px;
        --smtc-static-corner-rounded-5-base: 20px;
        --smtc-static-corner-rounded-6-base: 24px;
        --smtc-static-corner-rounded-3-5-rem: 14px;
        --smtc-static-corner-rounded-5-rem: 20px;
        --smtc-static-corner-rounded-6-rem: 24px;
    }
`,q=(0,n.A)`
    :host {
        --squircle-modifier: 1;
    }

    @supports (corner-shape: squircle) {
        :host {
            --squircle-modifier: 1.8;
        }
    }
`,U=(0,n.A)`
    :host {
        --mai-smtc-corner-card-default: 24px;
        --mai-smtc-corner-card-nested-default-outside: 16px;
        --cstm-corner-media-in-card: 24px;
        --smtc-corner-card-small-rest: 24px;
        --smtc-corner-card-discover-nested-outside: 24px;
        --smtc-corner-card-nested-small-inside: 24px;
        --smtc-corner-card-nested-small-outside: 24px;
    }
`.withBehaviors(new a.P("prg-cpad-t2",L),new a.P("prg-pr2-cpad-t2",N)),K=(0,n.A)`
    ${W}
    ${G}
    ${j}
`,X=(0,n.A)`
    :host {
        --smtc-padding-content-none: 0px;
        --smtc-padding-content-xxSmall: 4px;
        --smtc-padding-content-xSmall: 8px;
        --smtc-padding-content-xSmallNudge: 7px;
        --smtc-padding-content-small: 12px;
        --smtc-padding-content-medium: 16px;
        --smtc-padding-content-large: 20px;
        --smtc-padding-content-xLarge: 24px;
        --smtc-padding-content-xxLarge: 32px;
        --smtc-padding-content-xxxLarge: 40px;
    }
`,Y=(0,n.A)`
    :host {
        --smtc-gap-between-content-xx-small: 4px;
        --smtc-gap-between-content-x-small: 8px;
        --smtc-gap-between-content-small: 12px;
        --smtc-gap-between-content-medium: 16px;
        --smtc-gap-between-content-large: 20px;
        --smtc-gap-between-content-x-large: 22px;
        --smtc-gap-between-content-xxlarge: 32px;
        --smtc-gap-between-content-xx-large: 32px;
        --smtc-gap-between-content-xxx-large: 40px;
    }
`,Z=(0,n.A)`
    :host {
        --smtc-padding-ctrl-horizontal-default: 10px;
        --smtc-padding-ctrl-sm-horizontal-default: 8px;
        --smtc-padding-ctrl-sm-horizontal-icon-only: 6px;
        --smtc-padding-ctrl-lg-horizontal-default: 16px;
        --smtc-padding-ctrl-lg-button-default: 14px;
        --smtc-padding-ctrl-text-bottom: 10px;
        --smtc-padding-ctrl-text-side: 2px;
        --smtc-padding-ctrl-text-top: 10px;
        --smtc-padding-ctrl-lg-text-bottom: 11px;
        --smtc-padding-ctrl-lg-text-side: 2px;
        --smtc-padding-ctrl-lg-text-top: 11px;
    }
`,J=(0,n.A)`
    :host {
        --smtc-gap-inside-ctrl-default: 2px;
        --smtc-gap-inside-ctrl-to-label: 8px;
        --smtc-gap-inside-ctrl-to-secondary-icon: 4px;
        --smtc-gap-inside-ctrl-lg-to-secondary-icon: 6px;
        --smtc-gap-between-ctrl-default: 8px;
        --smtc-gap-between-ctrl-lg-default: 12px;
        --smtc-gap-between-text-large: 6px;
    }
`,Q=(0,n.A)`
    :host {
        --smtc-padding-card-default: 12px;
        --smtc-padding-card-body-default-horizontal-start: 20px;
    }
`,ee=(0,n.A)`
    :host {
        --smtc-padding-flyout-default: 8px;
    }
`,et=(0,n.A)`
    :host {
        --smtc-ctrl-badge-gap: 2px;
        --smtc-ctrl-badge-padding: 6px;
        --smtc-ctrl-badge-sm-padding: 4px;
        --smtc-ctrl-badge-text-padding-top: 4px;
        --smtc-ctrl-badge-sm-text-padding-top: 2px;
    }
`,ei=(0,n.A)`
    :host {
        --smtc-static-spacing-base: 4px;
        --smtc-static-spacing-0-5-base: 2px;
        --smtc-static-spacing-1-5-base: 6px;
        --smtc-static-spacing-3-5-base: 14px;
        --smtc-static-spacing-4-base: 16px;
        --smtc-static-spacing-8-base: 32px;
        --smtc-static-spacing-9-base: 36px;
        --smtc-static-spacing-2-rem: 8px;
        --smtc-static-spacing-2-5-rem: 10px;
    }
`,en=(0,n.A)`
    :host {
        --smtc-ctrl-choice-padding-horizontal: 4px;
    }
`,eo=(0,n.A)`
    ${X}
    ${Y}
    ${J}
`;var er=i(99563);let ea=(0,n.A)`
    :host {
        --smtc-text-ctrl-weight-default: 410;
        --smtc-text-style-default-header-weight: 650;
        --smtc-text-style-default-display-weight: 480;
        --smtc-text-style-default-regular-weight: 410;
        --smtc-text-style-default-display-letterSpacing: 0;
        --smtc-text-style-default-regular-letterSpacing: 0;
    }
`,es=(0,n.A)`
    :host {
        --smtc-text-global-body1-font-size: 18px;
        --smtc-text-global-body1-line-height: 26px;
        --smtc-text-global-body1-font-weight: 400;
        --smtc-text-global-body2-font-size: 16px;
        --smtc-text-global-body2-line-height: 22px;
        --smtc-text-global-body3-font-size: 14px;
        --smtc-text-global-body3-line-height: 20px;
        --smtc-text-global-body3-font-weight: 400;
        --smtc-text-global-body3-font-weight-strong: 550;
        --smtc-text-global-body4-font-size: 16px;
        --smtc-text-global-body4-line-height: 24px;
        --smtc-text-global-body5-font-size: 16px;
        --smtc-text-global-body5-line-height: 26px;
        --smtc-text-global-body5-font-weight: 410;
    }
`,ec=(0,n.A)`
    :host {
        --smtc-text-global-caption1-font-size: 12px;
        --smtc-text-global-caption1-line-height: 16px;
        --smtc-text-global-caption1-font-weight: 500;
        --smtc-text-global-caption2-font-size: 10px;
        --smtc-text-global-caption2-line-height: 14px;
    }
`,el=(0,n.A)`
    :host {
        --smtc-text-global-display1-font-size: 38px;
        --smtc-text-global-display1-line-height: 40px;
        --smtc-text-global-display2-font-size: 28px;
        --smtc-text-global-display2-line-height: 32px;
        --smtc-text-global-display2-font-weight: 620;
    }
`,ed=(0,n.A)`
    :host {
        --smtc-text-global-title1-font-size: 24px;
        --smtc-text-global-title1-line-height: 32px;
        --smtc-text-global-title2-font-size: 20px;
        --smtc-text-global-title2-line-height: 26px;
        --smtc-text-global-title2-font-weight: 500;
        --smtc-text-global-title3-font-size: 20px;
        --smtc-text-global-title3-line-height: 26px;
        --smtc-text-global-title3-font-weight: 500;
    }
`,ep=(0,n.A)`
    :host {
        --smtc-text-global-subtitle1-font-size: 20px;
        --smtc-text-global-subtitle1-line-height: 26px;
    }
`,eg=(0,n.A)`
    :host {
        --smtc-text-ramp-item-body-font-size: 14px;
        --smtc-text-ramp-item-body-line-height: 20px;
        --smtc-text-ramp-lg-item-body-font-size: 16px;
        --smtc-text-ramp-lg-item-body-line-height: 26px;
        --smtc-text-ramp-legal-font-size: 12px;
        --smtc-text-ramp-legal-line-height: 16px;
        --smtc-text-ramp-metadata-font-size: 14px;
        --smtc-text-ramp-metadata-line-height: 20px;
    }
`,eu=(0,n.A)`
    :host {
        --smtc-text-style-default-regular-font-family: ${u.er};
        --smtc-style-default-regular-font-family: ${u.er};
        --smtc-style-default-header-font-family: ${u.er};
    }
`,eh=(0,n.A)`
    :host {
        --smtc-typography-font-size-700: 24px;
        --smtc-typography-line-height-700: 31px;
        --smtc-typography-font-weight-700: 650;
        --smtc-typography-font-size-110: 39px;
        --smtc-typography-line-height-110: 40px;
        --smtc-typography-font-weight-110: 480;
    }
`,em=(0,n.A)`
    :host {
        --smtc-text-global-body1-font-size: 17px;
    }
`,eb=(0,n.A)`${em}`,ef=(0,n.A)`
    :host {
        --smtc-text-style-default-regular-font-family: ${u.Yn};
        --smtc-style-default-regular-font-family: ${u.Yn};
        --smtc-style-default-header-font-family: ${u.Yn};
    }
`,ey=(0,n.A)`
    :host {
        --smtc-text-style-default-regular-font-family: ${u.Hx};
        --smtc-style-default-regular-font-family: ${u.Hx};
        --smtc-style-default-header-font-family: ${u.Hx};
        --smtc-text-style-default-header-weight: 620;
    }
`,ev=(0,n.A)`${ey}`,ew=(0,n.A)`${ey}`,ex=(0,n.A)`
    ${ea}
    ${es}
    ${ec}
    ${el}
    ${ed}
    ${ep}
    ${eg}
    ${eu}
    ${eh}
`.withBehaviors(new a.P("prg-ntp-sysfnt",ef),new a.P("prg-ruby-segoe",ev),new a.P("prg-pr2-ruby-segoe",ew),new er.y(h,m,"prg-cnr-font-yh"),new er.y(h,b,"prg-cnr-font-nts"),new g("ja-jp",f),new g("ko-kr",y),new a.P("prg-lg-flex-rev",eb)),eC=(0,n.A)`
    @media (forced-colors: active) {
        :host {
            --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 1);
        }
    }
`,eR=(0,n.A)`
    :host {
        --smtc-static-color-overlay-black-8: rgba(0, 0, 0, 0.08);
        --smtc-static-color-overlay-black-10: rgba(0, 0, 0, 0.1);
        --smtc-static-color-alpha-white-80: #FFFFFFCC;
        --smtc-static-color-alpha-black-70: #000000B2;
        --smtc-static-color-blue-350: #78b0ff;
        --smtc-static-color-blue-550: #0159ba;
        --smtc-static-color-caramel-400: #CA7D36;
        --smtc-static-color-caramel-450: #A25A02;
        --smtc-static-color-green-400: #32AD52;
        --smtc-static-color-green-450: #008633;
        --smtc-static-color-green-550: #01712B;
        --smtc-static-color-green-600: #016826;
        --smtc-static-color-green-700: #014818;
        --smtc-static-color-green-800: #0D2B13;
        --smtc-static-color-lime-450: #667901;
        --smtc-static-color-midnight-450: #586BA8;
        --smtc-static-color-orange-450: #A25A02;
        --smtc-static-color-red-400: #E7615B;
        --smtc-static-color-red-550: #AC1922;
        --smtc-static-color-yellow-450: #8C6801;
    }
    
    ${eC}
`,eA=(0,n.A)`
    ${k}
    ${S}
    ${F}
`,ek=(0,n.A)`
    ${eR}
    ${$}
    ${T}
    ${P}
`.withBehaviors((0,o.G2)(eA)),e$=(0,n.A)`
    :host {
        --smtc-padding-card-default: 8px;
    }
`,eS=(0,n.A)`
    ${e$}
`,eT=(0,n.A)`
    ${e$}
`,eF=(0,n.A)`
    ${X}
    ${Y}
    ${Z}
    ${J}
    ${Q}
    ${ee}
    ${et}
    ${en}
    ${ei}
`.withBehaviors(new a.P("prg-cpad-t2",eS),new a.P("prg-pr2-cpad-t2",eT)),eP=(0,n.A)`
    ${q}
    ${G}
    ${W}
    ${j}
    ${d.VE}
    ${U}
`,eB=(0,n.A)`
    :host {
        --smtc-theme-color-component-attribution-item-background-hover: #FFF;
        --smtc-theme-color-component-attribution-item-background-rest: #FEFCFB;
        --smtc-theme-color-component-button-strong-background-rest: #282523;
        --smtc-theme-color-component-button-subtle-bright-background-pressed: rgba(255, 255, 255, 0.35);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-background-hover: rgba(0, 0, 0, 0.05);
        --smtc-theme-color-component-button-subtle-dimmed-background-pressed: rgba(0, 0, 0, 0.03);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-hover: rgba(0, 0, 0, 0.05);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-pressed: rgba(0, 0, 0, 0.03);
        --smtc-theme-color-component-button-outline-dimmed-inverted-stroke-pressed: rgba(177, 170, 166, 1);
        --smtc-theme-color-component-card-answer-background-inner: rgba(204, 196, 192, 0.2);
        --smtc-theme-color-component-card-answer-background-outer: rgba(255, 255, 255, 0.45);
        --smtc-theme-color-component-card-background-neutral: rgba(255, 255, 255, 0.80);
        --smtc-theme-color-component-citation-background-hover: #E3DDD8;
        --smtc-theme-color-component-citation-background-rest: #F0EAE5;
        --smtc-theme-color-component-composer-stop-button-background-hover: #E3B388;
        --smtc-theme-color-component-table-background-cell: rgba(255, 255, 255, 0.25);
        --smtc-theme-color-component-table-background-header: #FFEDDE;
        --smtc-theme-color-component-textbox-background-active: #0000000D;
        --smtc-theme-color-component-chip-background-rest: rgba(255, 255, 255, 0.3);
    }
`,eI=(0,n.A)`
    :host {
        --smtc-theme-color-component-attribution-item-background-hover: #1D2439;
        --smtc-theme-color-component-attribution-item-background-rest: #171E32;
        --smtc-theme-color-component-button-strong-background-rest: #E4E6F1;
        --smtc-theme-color-component-button-subtle-bright-background-pressed: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-dimmed-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-hover: rgba(255, 255, 255, 0.08);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-pressed: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-component-button-outline-dimmed-inverted-stroke-pressed: rgba(69, 81, 114, 1);
        --smtc-theme-color-component-card-answer-background-inner: rgba(157, 168, 217, 0.05);
        --smtc-theme-color-component-card-answer-background-outer: rgba(157, 168, 217, 0.10);
        --smtc-theme-color-component-card-background-neutral: rgba(157, 168, 217, 0.10);
        --smtc-theme-color-component-citation-background-hover: #282D3E;
        --smtc-theme-color-component-citation-background-rest: #1F2431;
        --smtc-theme-color-component-composer-stop-button-background-hover: #6777AF;
        --smtc-theme-color-component-table-background-cell: rgba(0, 0, 0, 0.25);
        --smtc-theme-color-component-table-background-header: #171E32;
        --smtc-theme-color-component-textbox-background-active: #4B5C9240;
        --smtc-theme-color-component-chip-background-rest: rgba(0, 0, 0, 0.03);
    }
`,eH=(0,n.A)`
    :host {
        --smtc-ctrl-coachmark-foreground: #FFFBF8;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
    }
`,eD=(0,n.A)`
    :host {
        --smtc-ctrl-coachmark-foreground: #0F1119;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
    }
`,e_=(0,n.A)`
    :host {
        --smtc-ctrl-focus-inner-stroke: #00000000;
        --smtc-ctrl-focus-outer-stroke: #322d29;
    }
`,eE=(0,n.A)`
    :host {
        --smtc-ctrl-focus-inner-stroke: #00000000;
        --smtc-ctrl-focus-outer-stroke: #d7deef;
    }
`,eM=`
    :host {
        --smtc-theme-color-overlay-black-30: rgba(255, 255, 255, 0.30);
        --smtc-theme-color-overlay-black-5: #0000000D;
    }
`,eO=`
    :host {
        --smtc-theme-color-overlay-black-30: rgba(255, 255, 255, 0.30);
        --smtc-theme-color-overlay-black-5: #FFFFFF0D;
        
    }
`,eV=(0,n.A)`
    ${$}
    ${eB}
    ${T}
    ${eH}
    ${P}
    ${e_}
    ${C}
    ${A}
    ${eM}
`,ez=(0,n.A)`
    ${k}
    ${eI}
    ${S}
    ${eD}
    ${F}
    ${eE}
    ${x}
    ${R}
    ${eO}
`,eL=(0,n.A)`
    ${H}
    ${D}
    ${_}
    ${E}
    ${M}
`,eN=(0,n.A)`
    :host {
        --smtc-ctrl-badge-size: 19px;
        --smtc-ctrl-badge-sm-size: 19px;
        --smtc-size-ctrl-choice-base: 20px;
        --smtc-size-ctrl-default: 40px;
        --smtc-size-ctrl-lg-default: 48px;
        --smtc-size-ctrl-sm-default: 36px;
    }
`,eG=(0,n.A)`
    :host {
        --smtc-ctrl-badge-icon-size: 16px;
        --smtc-ctrl-citation-icon-size: 16px;
        --smtc-ctrl-source-icon-size: 16px;
        --smtc-size-ctrl-xl-icon: 28px;
        --smtc-size-ctrl-lg-icon: 24px;
        --smtc-size-ctrl-sm-icon: 24px;
    }
`,eW=(0,n.A)`
    ${eN}
    ${eG}
`,ej=(0,n.A)`
    :host {
        --smtc-ctrl-input-stroke-width-rest: 1px;
        --smtc-stroke-width-ctrl-choice-rest: 2px;
        --smtc-stroke-width-ctrl-outline: 2px;
        --smtc-stroke-width-ctrl-outline-rest: 1px;
        --smtc-stroke-width-default: 1px;
        --mai-smtc-stroke-width-card-default: 0.5px;
    }
`,eq=(0,n.A)`
    ${ej}
`;var eU=i(46026);(0,n.A)` ${I} ${O} ${K} ${eo} ${ex} ${d.bX}
`,(0,n.A)` ${ek} ${ex} ${eF} ${eP}
`;let eK=(0,n.A)` :host{--smtc-corner-flyout-rest:20px}${eR}
`,eX=(0,n.A)` ${d._8} ${ez}
`,eY=(0,n.A)` ${eV} ${eF} ${ex} ${eL} ${eP} ${eW} ${eq}
`,eZ=(0,n.A)` ${eY} ${"winWidgets"===p.T3.AppType?w:l} ${d.bX} ${eK} ${"edgeChromium"===p.T3.AppType||"views"===p.T3.AppType||"winWidgets"===p.T3.AppType?eU.H:(0,n.A)``} ${"bingHomepage"===p.T3.AppType&&"dark"===window.__theme?eX:(0,n.A)``}
`.withBehaviors((0,o.G2)("bingHomepage"!==p.T3.AppType?eX:(0,n.A)``),new g("ja-jp",f),new g("ko-kr",y))},34241:function(e,t,i){i.d(t,{w:function(){return s}});var n=i(59669),o=i(22131);let r=(0,n.A)` .skeleton{background:rgba(0,0,0)}@keyframes pulse{0%{opacity:0.06}50%{opacity:0.1}100%{opacity:0.06}}`,a=(0,n.A)` .skeleton{background:rgba(255,255,255)}@keyframes pulse{0%{opacity:0.1}50%{opacity:0.15}100%{opacity:0.1}}`,s=(0,n.A)`.flex-row{display:flex;flex-direction:row}.flex-col{display:flex;flex-direction:column}.skeleton{animation:pulse 1.5s alternate infinite;animation-timing-function:linear}`.withBehaviors((0,o.C7)(r),(0,o.G2)(a))},82281:function(e,t,i){i.d(t,{R:function(){return o}});var n=i(75117);function o(e){let t=(0,n.rA)().CurrentRequestTargetScope?.pageExperiments||[];return t&&t.includes(e)}},54863:function(e,t,i){function n(e){return e?e.replace(RegExp("(ftp|http|https|rtp|rtmp|sftp)\\s*/{2}(?=[^\\s/])","g"),"$1://"):e}function o(e,t=!0){if(!e)return e;let i=n(e);return t?i.replace(/<a\b[^>]*>.*?<\/a>/gi,"").replace(/https?:\/\/[^\s]+|www\.[^\s]+/gi,""):i}i.d(t,{r3:function(){return n},wR:function(){return o}})}}]);