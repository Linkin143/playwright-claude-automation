"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["stripe-wc"],{36478(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M7.73 4.2a.75.75 0 0 1 1.06.03l5 5.25c.28.3.28.75 0 1.04l-5 5.25a.75.75 0 1 1-1.08-1.04L12.2 10l-4.5-4.73a.75.75 0 0 1 .02-1.06Z" fill="currentcolor"/></svg>'},12688(t,e,r){r.d(e,{$(){return i}});var a=r(89757),s=r(14475),o=r(33744);const i=t=>a.qy`<a class="ad-choice" data-t=${t.telemetryTag||""} href=${t.href||""} target="${s.z._blank}" title=${t.text||""}><img alt=${t.text||""} aria-hidden="true" src="${(0,o.rA)().StaticsUrl}/latest/responsive-card/adChoiceIcon.svg"></img></a>`},61666(t,e,r){r.d(e,{Q(){return c}});var a=r(89757),s=r(69259),o=r(14475),i=r(4670),n=r(2188);const l=(t,e)=>{e.event.preventDefault(),window.dispatchEvent(new CustomEvent("dsaClick",{detail:{adSelectionCriteria:t.adSelectionCriteria,anchorElement:e.event.target,strings:t.config.localizedStrings},bubbles:!0,composed:!0}))},d=(t,e)=>("Enter"===e.event.key&&l(t,e),!0),c=t=>a.qy` ${(0,s.z)(!!t.enableDSADialog,a.qy`<a class="ad-label dsa" data-t=${t.telemetryTag||""} title=${t.dsaDialogTooltip||""} ?no-border=${Boolean(t.noBorder)} @click=${l} @keydown=${d} tabindex="0">${t.text||"Ad"}</a>`)} ${(0,s.z)(!t.enableDSADialog,a.qy`<a class="ad-label" data-t=${t.telemetryTag||""} href=${t.href||""} target="${o.z._blank}" title=${(0,i.jj)()&&t.text||""} ?no-border=${Boolean(t.noBorder)} ${!(0,i.jj)()&&(0,n.Ib)(!0,!1)}>${t.text||"Ad"}</a>`)} `},33537(t,e,r){r.r(e),r.d(e,{StripeWCRiverStyles(){return ma},templateStyles(){return ha},ToolingInfo(){return Ya},StripeWC(){return Ia},topStripeStyles(){return pa},StripeWCFlippersStyles(){return ga},templateDarkStyles(){return ua},StripeWCTemplate(){return Za},StripeWCStyles(){return ca}});var a=r(4174),s=r(37180),o=r(75003),i=r(69329),n=r(65614),l=r(42320),d=r(651),c=r(12165),p=r(58757),h=r(55461),u=r(97964),g=r(56911),m=r(38493),f=r(60815),y=r(55230),C=r(56863),b=r(92011);class v extends b.L{}class w extends((0,C.rf)(v)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class x extends w{onTitleClicked(){this.$emit("action-title-clicked")}handleTextInput(){this.inputControl&&(this.value=this.inputControl.value,this.$emit("action-text-input",this.inputControl.value))}addToWatchlist(t){this.inputControl&&(this.inputControl.value="",this.value=""),this.$emit("action-add-to-watchlist",t)}handleOnKeyDownSearchBox(t){if(!this.moneyCardContentData.showSuggestions)return!0;switch(t.key){case y.I5:t.preventDefault(),this.activeSuggestion=this.searchSuggestions.length-1,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;case y.HX:t.preventDefault(),this.activeSuggestion=0,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;default:return!0}return!0}focusSelectedElement(){this.selectedSuggestion.querySelectorAll("li").forEach(t=>{if(t.id===this.activeId){t.focus()}})}handleOnKeyDownAutoSuggestBox(t){switch(t.key){case y.HX:t.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case y.I5:t.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+this.searchSuggestions.length-1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case" ":case"Enter":if(t.preventDefault(),this.searchSuggestions.length>0){this.inputControl.value="",this.activeSuggestion=-1;this.selectedSuggestion.querySelectorAll("li").forEach(t=>{if(t.id===this.activeId){t.click()}})}break;case"Escape":t.preventDefault(),this.activeSuggestion=-1,this.inputControl.value="",this.$emit("action-text-input",this.inputControl.value);break;default:return}}getSuggestionClass(t,e,r){return t===this.activeId?r:e}}(0,g.Cg)([(0,m.CF)({attribute:"layout"})],x.prototype,"layout",void 0),(0,g.Cg)([f.sH],x.prototype,"moneyCardContentData",void 0),(0,g.Cg)([f.sH],x.prototype,"searchSuggestions",void 0),(0,g.Cg)([f.sH],x.prototype,"goBackTelemetryTag",void 0),(0,g.Cg)([f.sH],x.prototype,"addToWatchlistTelemetryTag",void 0),(0,g.Cg)([f.sH],x.prototype,"activeSuggestion",void 0),(0,g.Cg)([f.sH],x.prototype,"activeId",void 0);var $=r(89757),k=r(60402),P=r(69259),S=r(68835);const _=$.qy`<li id="${t=>t.quoteId}" tabindex="0" active=${(t,e)=>t.quoteId===e.parent.activeId||null} class="${(t,e)=>e.parent.getSuggestionClass(t.quoteId,"suggestion-entry","suggestion-entry-selected")}" part="${(t,e)=>e.parent.getSuggestionClass(t.quoteId,"suggestion-entry","suggestion-entry-selected")}" aria-label="${t=>t.longName} ${t=>t.exchangeName}" @click="${(t,e)=>e.parent.addToWatchlist(t.quoteId)}" data-t="${(t,e)=>e.parent.addToWatchlistTelemetryTag}"><div class="suggestion-item" part="suggestion-item"><div class="suggestion-company" part="suggestion-company"><span class="suggestion-symbol" part="suggestion-symbol">${t=>t.equitySymbol}</span><span class="suggestion-name" part="suggestion-name">${t=>t.longName}</span></div><div class="suggestion-market" part="suggestion-market"><span class="suggestion-market-str">${t=>t.exchangeName}</span></div><div class="suggestion-add-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17 9.53v.94h-6.53V17h-.94v-6.53H3v-.94h6.53V3h.94v6.53H17z" /></svg></div></div></li>`,A=$.qy`<div class="search-area" part="search-area"><div class="search-icon" part="search-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 3a5.5 5.5 0 014.23 9.02l4.12 4.13a.5.5 0 01-.63.76l-.07-.06-4.13-4.12A5.5 5.5 0 118.5 3zm0 1a4.5 4.5 0 100 9 4.5 4.5 0 000-9z" /></svg></div><input class="search-input" part="search-input" type="search" autofocus="autofocus" @input=${t=>t.handleTextInput()} @keydown="${(t,e)=>t.handleOnKeyDownSearchBox(e.event)}" aria-label="${t=>t.moneyCardContentData?.searchPlaceholder}" placeholder="${t=>t.moneyCardContentData?.searchPlaceholder}" :value="${t=>t.value}" ${(0,k.K)("inputControl")} />${(0,P.z)(t=>!0===t.moneyCardContentData?.showSuggestions,$.qy`<ul class="suggestions-list" part="suggestions-list" tabindex="-1" @keydown="${(t,e)=>t.handleOnKeyDownAutoSuggestBox(e.event)}" ${(0,k.K)("selectedSuggestion")}>${(0,S.ux)((t,e)=>t.searchSuggestions,_)}</ul>`)} ${(0,P.z)(t=>!0===t.moneyCardContentData?.noSuggestion,$.qy`<div class="suggestions-list" part="suggestions-list"><div class="no-suggestion-str">${t=>t.moneyCardContentData?.noSuggestionHint}</div></div>`)}</div>`,D=$.qy`<div class="title" part="title"><button class="title-button" part="title-button" @click="${t=>t.onTitleClicked()}" aria-label="${t=>t.moneyCardContentData?.goBackLabel}" data-t="${t=>t.goBackTelemetryTag}"><span class="title-content">&lrm;${t=>t.moneyCardContentData?.titleContent}</span></button></div>${A}
`;var R=r(59669),M=r(64187),T=r(22131),I=r(73477),O=r(61138),B=r(6032),U=r(48196),z=r(33113),F=r(47810),N=r(41123),L=r(95403),E=r(37998),q=r(7896),H=r(83252),W=r(86856),j=r(50882);const J=R.A` .suggestion-add-icon{padding-left:10px}`,G=R.A` .suggestion-add-icon{padding-right:10px}`,V=R.A` ${(0,M.V)("grid")} :host{box-sizing:border-box;position:relative;width:100%;outline:none;padding:12px 16px;height:100%;grid-template-rows:auto 1fr}:host([layout="full"]) .title{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:1fr auto;height:24px;margin-bottom:11px}:host([layout="half"]) .title{align-items:center;display:grid;grid-template-columns:1fr auto;grid-column-gap:8px;margin-bottom:8px;height:16px}.title-button{border:none;display:flex;font-size:${O.k};line-height:${O.F};font-weight:500;color:${B.c};background-color:transparent;outline:none;cursor:pointer;padding:0px}.title-button:focus{text-decoration:underline}.title-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-inline-end:12px}.search-area{display:grid;grid-template-columns:auto 1fr;height:calc(${U.D} * 1px);position:relative;border:1px solid ${z.I2}}.search-icon{width:20px;padding:6px 10px}svg path{fill:${F.l}}.search-input{color:${F.l};background:transparent;font-size:${N.K};line-height:${N.Z};height:calc(${U.D} * 1px);border:none;outline:none}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.suggestion-add-icon{padding-left:10px}.suggestions-list{margin:0px;display:block;position:absolute;box-sizing:border-box;top:40px;width:100%;padding:4px;background:${L.Wl};--elevation:10;${E.ET};z-index:9999;border:1px solid transparent}.no-suggestion-str{margin:3px 9px;font-size:${N.K};line-height:${N.Z}}.suggestion-entry-selected{font-family:${q.O};outline:none;list-style:none;border:none;width:258px;height:47px;padding:0px;background:${H.Xt};text-decoration:none;cursor:pointer}.suggestion-entry{border:none;outline:none;list-style:none;width:258px;height:47px;padding:0px;background:${L.Wl};text-decoration:none;cursor:pointer}.suggestion-entry:hover .suggestion-item{background:${H.Xt}}.suggestion-entry,.search-input,.title-button{font-family:${q.O}}.suggestion-item{display:grid;grid-template-columns:140px 66px 32px;grid-column-gap:2px;height:40px;padding:5px 8px 2px 8px}.suggestion-company{display:grid;text-align:start;grid-template-rows:20px 20px}.suggestion-add-icon{padding-top:9px}.suggestion-symbol{display:block;font-weight:800;font-size:${N.K};line-height:${N.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${F.l}}.suggestion-name{display:block;font-weight:600;font-size:${O.k};line-height:${O.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${F.l}}.suggestion-market{display:flex;position:relative;padding-top:8px}.suggestion-market-str{position:absolute;right:0px;font-weight:600;text-align:end;font-size:${O.k};line-height:${O.F};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${F.l}}`.withBehaviors(new W.t(J,G),(0,T.mr)(R.A` :host{forced-color-adjust:auto}svg path{fill:${j.A.ButtonText}}.suggestion-entry:hover .suggestion-item,.suggestion-entry:${I.N} .suggestion-item{forced-color-adjust:none;background:${j.A.Highlight}}.suggestion-entry:hover .suggestion-item *,.suggestion-entry:hover .suggestion-item svg path,.suggestion-entry:${I.N} .suggestion-item *,.suggestion-entry:${I.N} .suggestion-item svg path{color:${j.A.HighlightText};fill:currentcolor}`)),X=x.compose({name:`${d.i.prefix}-add-watchlist-money-card`,template:D,styles:V});var K,Q,Z,Y,tt=r(47131),et=r(61851),rt=r(34897),at=r(8746),st=r(85981),ot=r(19511),it=r(61473),nt=r(2684),lt=r(47211);(Q=K||(K={})).AutosEntityList="AutosEntityList",Q.AutosCarousel="AutosCarousel",(Y=Z||(Z={})).AnaheimNtpFeeds="anaheim-ntp-feeds",Y.MSNArticle="articles-startshop-feeds",Y.MSNHomePage="hponeservicefeed";var dt=r(87906),ct=r(40450),pt=r(33744),ht=r(43672),ut=r(12776),gt=r(23057),mt=r(83826);const ft='{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';async function yt(t,e=Z.AnaheimNtpFeeds,r,a){const s=function(t){switch(t){case Z.AnaheimNtpFeeds:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";case Z.MSNArticle:return"TUvfxJjXdl3YnnSTtb4nTd6OHIbDUzhvcgJt26A7Bi";case Z.MSNHomePage:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";default:return""}}(e),o=new URL(`https://assets.msn.com/service/news/feed/segments/autosMarketplace?apikey=${s}&ocid=${e}`),i=2===await(0,gt.XK)()?ut.WR.getOneServiceParamsWithAuth((0,pt.rA)().UserId,e):ut.WR.getOneServiceParamsWithoutAuth((0,pt.rA)().UserId,e),n=new Set(["apikey","ocid"]);var l;a&&i.push({key:"contentId",value:a}),(l=i)&&l.forEach(t=>{t.value&&!n.has(t.key)&&o.searchParams.set(t.key,t.value)});let d=await(0,mt.w)(()=>fetch(o.href),"GetAutosEntityList"),c=3;if(!d.ok&&!t)return"{}";if(!d.ok&&t)switch(pt.T3.CurrentMarket){case ht.DX.ENUS:return ft;case ht.DX.ENCA:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';case ht.DX.ENGB:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';default:return ft}for(;c>0&&200!==d?.status;){try{d=await(0,mt.w)(()=>fetch(o.href),"GetAutosEntityList")}catch(t){(0,dt.c_)(Error("Response Fetch Error"),ct.uqN,"send request to segments api failed")}c--}if(!d.ok)throw new Error(d.statusText);const p=await d.json();let h=p&&p[0]&&p[0].data;if(r&&p.length>0){const t=p.filter(t=>t.type==r);h=t&&t[0]&&t[0].data}return h}var Ct,bt,vt=r(32247),wt=r(13507),xt=r(2274),$t=r(10316),kt=r(84289),Pt=r(44646),St=r(45596),_t=r(52226),At=r(37125),Dt=r(5977);(bt=Ct||(Ct={})).casualGamesCard="casual-games-card",bt.casualGamesStripeCarouselCard="casual-games-stripe-carousel-card",bt.contentCard="content-card",bt.contentCardPreview1x="content-card-preview-1x",bt.denseCard="dense-card",bt.displayAdCard="display-ad-card",bt.infopaneCard="infopane-card",bt.infopaneSlideCard="infopane-slide-card",bt.moneyInfoCardWC="money-info-card",bt.healthArticlesCardWC="health-articles-card",bt.nativeAdCard="native-ad-card",bt.placeholderCard="placeholder-card",bt.pollsCard="polls-card",bt.shoppingCarouselCard="shopping-carousel-card",bt.shoppingVideoCarousel="shopping-video-carousel-card",bt.superappUpsellCard="superapp-upsell-card",bt.trendingNowCard="trending-now-card",bt.weatherCard="weather-card",bt.webContentCard="web-content-card",bt.videoCard="video-card",bt.travelDestinationCard="travel-destination";var Rt=r(77833);const Mt={[Rt.pL.Article]:Ct.contentCard,[Rt.pL.CasualGamesStripeCarousel]:Ct.casualGamesStripeCarouselCard,[Rt.pL.EsportsCasualGames]:Ct.casualGamesCard,[Rt.pL.Slideshow]:Ct.contentCard,[Rt.pL.ExternalLink]:Ct.contentCard,[Rt.pL.Video]:Ct.contentCard,[Rt.pL.WebContent]:Ct.contentCard,[Rt.pL.Infopane]:Ct.infopaneCard,[Rt.pL.ShoppingCarousel]:Ct.shoppingCarouselCard,[Rt.pL.Dense]:Ct.denseCard,[Rt.pL.TrendingInTenMinutes]:Ct.trendingNowCard,[Rt.pL.NativeAd]:Ct.nativeAdCard};var Tt=r(69828);const It=R.A`

:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Ot={cardCount:4,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:It},Bt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
  
`.withBehaviors(),Ut={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Bt},zt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot6"
        "slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Ft={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:zt},Nt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot7"
        "slot1 slot2 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Lt={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Nt},Et=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot6"
        "slot1 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),qt={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Et},Ht=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot7"
        "slot1 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Wt={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Ht},jt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot8"
        "slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Jt={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:jt},Gt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot10"
        "slot3 slot6 slot9 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Vt={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Gt},Xt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot9"
        "slot1 slot4 slot7 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Kt={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot9",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot10",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Xt},Qt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Zt={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:Tt.uE._2x_3y,C3:Tt.uE._2x_3y,C2:Tt.uE._2x_3y}}],styles:Qt},Yt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),te={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:Tt.uE._3x_3y,C3:Tt.uE._3x_3y,C2:Tt.uE._3x_3y}}],styles:Yt},ee=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),re={cardCount:2,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y,C1:Tt.uE._1x_3y}}],styles:ee},ae=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot5";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),se={cardCount:5,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._2x_3y,C3:Tt.uE._2x_3y,C2:Tt.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ae},oe=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot6"
        "slot1 slot1 slot2 slot4 slot6"
        "slot1 slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ie={cardCount:6,cardSlots:[{grid_area:"slot1",layouts:{C5:Tt.uE._2x_3y,C4:Tt.uE._2x_3y,C3:Tt.uE._2x_3y,C2:Tt.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:Tt.uE._1x_3y,C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}},{grid_area:"slot3",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:Tt.uE._1x_3y,C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}}],styles:oe},ne=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot4 slot7";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),le={cardCount:7,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._2x_3y,C3:Tt.uE._2x_3y,C2:Tt.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ne},de=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot8"
        "slot1 slot1 slot3 slot6 slot8"
        "slot1 slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ce={cardCount:8,cardSlots:[{grid_area:"slot1",layouts:{C5:Tt.uE._2x_3y,C4:Tt.uE._2x_3y,C3:Tt.uE._2x_3y,C2:Tt.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot3",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot7",layouts:{C5:Tt.uE._1x_1y,C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y}},{grid_area:"slot8",layouts:{C5:Tt.uE._1x_3y,C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y}}],styles:de};var pe=r(47300);const he=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas: 
        "slot1 slot1 slot1 slot2"
        "slot1 slot1 slot1 slot2";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0 16px;
}

${(0,pe.H5)(pe.j1.c3)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2";
    };
}

${(0,pe.H5)(pe.j1.c2)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),ue={cardCount:2,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._3x_2y,C3:Tt.uE._2x_2y,C2:Tt.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_2y,C3:Tt.uE._1x_2y,C2:Tt.uE._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[1,2]}}],styles:he},ge=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
${(0,pe.H5)(pe.j1.c3)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot1"
            "slot1 slot1 slot1"
            "slot1 slot1 slot1";
    };
}

${(0,pe.H5)(pe.j1.c2)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),me={cardCount:1,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._4x_2y,C3:Tt.uE._3x_2y,C2:Tt.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:ge},fe=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
`.withBehaviors(),ye={cardCount:1,cardSlots:[{grid_area:"slot1",layouts:{C5:Tt.uE._5x_2y,C4:Tt.uE._4x_2y,C3:Tt.uE._3x_2y,C2:Tt.uE._2x_2y}}],styles:fe},Ce=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),be={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Ce},ve=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot7"
        "slot3 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),we={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ve},xe=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot8"
        "slot2 slot4 slot6 slot8"
        "slot3 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),$e={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:xe},ke=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot8"
        "slot2 slot5 slot7 slot8"
        "slot3 slot6 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Pe={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_3y,C3:Tt.uE._1x_3y,C2:Tt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:ke},Se=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot11"
        "slot3 slot6 slot9 slot12";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot10"],
:host fluent-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot11"],
:host fluent-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot10"],
:host cs-responsive-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot11"],
:host cs-responsive-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),_e={cardCount:12,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot11",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot12",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Se},Ae=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot7"
        "slot2 slot3 slot12 slot7"
        "slot4 slot5 slot13 slot7";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C4"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot3"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot5"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot3"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot5"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}
    
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot7"
        "slot2 slot3 slot7"
        "slot4 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot7"
        "slot4 slot7"
        "slot8 slot7";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),De={cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._2x_2y,C3:Tt.uE._2x_2y,C2:Tt.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_4y,C3:Tt.uE._1x_4y,C2:Tt.uE._1x_4y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C2:[6,1]}},{grid_area:"slot9",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:9}},{grid_area:"slot10",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:10}},{grid_area:"slot11",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:Ae},Re=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot8"
        "slot2 slot3 slot12 slot9"
        "slot4 slot5 slot13 slot10";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot8"
        "slot2 slot3 slot9"
        "slot4 slot5 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot3"
        "slot4 slot5"
        "slot8 slot9";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),Me={"msn-home-page-river-section-1111":Ot,"msn-home-page-river-section-1113":Ut,"msn-home-page-river-section-1131":Ft,"msn-home-page-river-section-1133":Lt,"msn-home-page-river-section-1311":qt,"msn-home-page-river-section-1313":Wt,"msn-home-page-river-section-1331":Jt,"msn-home-page-river-section-1333":Kt,"msn-home-page-river-section-3331":Vt,"msn-home-page-river-section-1W13":se,"msn-home-page-river-section-1W131":ie,"msn-home-page-river-section-1WWW":me,"msn-home-page-river-section-1WWWW":ye,"msn-home-page-river-section-1WW1":ue,"msn-home-page-river-section-1W33":le,"msn-home-page-river-section-1W331":ce,"msn-home-page-river-section-3111":be,"msn-home-page-river-section-3113":we,"msn-home-page-river-section-3131":$e,"msn-home-page-river-section-3333":_e,"msn-home-page-river-section-3311":Pe,"msn-home-page-river-section-111W":Zt,"msn-home-page-river-section-111WW":te,"msn-home-page-river-section-11WW":re,"msn-home-page-top-stripe-view-no-segment":{cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:Tt.KF,gutterPx:Tt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Tt.uE._2x_2y,C3:Tt.uE._2x_2y,C2:Tt.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[4,2]}},{grid_area:"slot4",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C4:[2,4],C3:[2,3],C2:[6,1]}},{grid_area:"slot9",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:9},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[6,2]}},{grid_area:"slot10",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:10},telemetryRowCol:{C4:[4,4],C3:[4,3]}},{grid_area:"slot11",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:Tt.uE._1x_1y,C3:Tt.uE._1x_1y,C2:Tt.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:Re},"msn-home-page-top-stripe-view-big-forth-col-no-segment":De};var Te=r(72287),Ie=r(37914),Oe=r(7961),Be=r(60640),Ue=r(19e3),ze=r(10862),Fe=r(9039),Ne=r(50365),Le=r(18420),Ee=r(65455),qe=r(52600),He=r(71733),We=r(33485),je=r(90466),Je=r(18176),Ge=r(26144),Ve=r(34900),Xe=r(18755),Ke=r(59409),Qe=r(245),Ze=r(71084),Ye=r(56525),tr=r(96245),er=r(8097),rr=r(32361),ar=r(13162),sr=r(95583),or=r(94972),ir=r(27970),nr=r(37899),lr=r(41291),dr=r(32460),cr=r(88466),pr=r(94172);const hr=$.qy`
<fluent-card
    id="health-articles-card"
    style="grid-area:${t=>t.gridArea};border-radius:6px"
    class="${t=>t.cardSize}"
>
    ${t=>t.healthArticlesConfigInfo&&(0,pr.yN)(t.healthArticlesConfigInfo,{includeTelemetryTag:!1,properties:{parentTelemetryObject:t.parentTelemetryObject,telObjectBase:t.parentTelemetryObject,healthArticleData:t.healthArticleData,refreshSDCardSection:t.refreshSDCardSection,sdCardActionClickHandler:t.sdCardActionClickHandler,refreshFeed:t.refreshFeed,cardSize:t.cardSize},events:{goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback}})}

</fluent-card>
`;var ur=r(66728),gr=r(98794),mr=r(7074);function fr(t){try{const{configOptions:e,parentTelemetryObject:r,cardMetadata:a,refreshSDCardSection:s,sdCardActionClickHandler:o,refreshFeedCallback:i,goToPersonalizeSettingsCallback:n}=t,l=e&&e,d={id:"healthArticlesCard",childTemplateType:"health-articles-card",parentTelemetryObject:r,telObjectBase:r,healthArticlesConfigInfo:l,healthArticleData:a&&a.data&&function(t){let e=null;if(!t)return e;const r=JSON.parse(t);if(!r)return e;let a=[],s=[];if(r.items)for(let t=0;t<r.items.length;t++)r.items[t].imageUrl&&a.push(r.items[t]);if(r.randomItems)for(let t=0;t<r.randomItems.length;t++)s.push(r.randomItems[t]);a=vr(a),s=vr(s),(a.length>0||s.length>0)&&(e=[]);for(let t=0;t<a.length&&t<2;t++)e.push(Cr(a[t]));for(let t=0;t<s.length&&e.length<4;t++)e.push(br(s[t]));return e}(a.data),sdCardActionClickHandler:o,refreshFeed:s||i,goToPersonalizeSettingsCallback:n,refreshSDCardSection:s};return(0,gr.bw)({id:"healthArticlesCard",experienceType:l?.configRef?.experienceType,mapperArgs:t},d)}catch(e){(0,dt.vV)(ur.NZ,`Error in feed layout: ${e}, mapperargs = ${JSON.stringify(t)}`)}return null}function yr(t){try{if(!t)throw new Error(`Invalid color string = ${t}`);const e=t?.substr(1),r=parseInt(e?.substr(0,2),16),a=parseInt(e?.substr(2,2),16),s=parseInt(e?.substr(4,2),16);if(!(0,mr.A)(r)||!(0,mr.A)(a)||!(0,mr.A)(s))throw new Error(`Could not extract color from = ${t}`);return`${r}, ${a}, ${s}`}catch(t){return"58, 52, 45"}}function Cr(t){return{title:t.title,clickUrl:t.url,mainImageUrl:t.imageUrl,brandLogoUrl:t.additionalAttributes.find(t=>"ProviderLogo"==t.key).value,brandName:t.additionalAttributes.find(t=>"ProviderName"==t.key).value,gradientColor:yr(t.additionalAttributes.find(t=>"DarkModeColor"==t.key).value),category:"recommendation"}}function br(t){return{title:t.title,clickUrl:t.url,mainImageUrl:t.imageUrl,brandLogoUrl:t.additionalAttributes.find(t=>"ProviderLogo"==t.key).value,brandName:t.additionalAttributes.find(t=>"ProviderName"==t.key).value,gradientColor:yr(t.additionalAttributes.find(t=>"DarkModeColor"==t.key).value),category:"suggestion"}}function vr(t){let e,r=t.length;for(;0!=r;)e=Math.floor(Math.random()*r),r--,[t[r],t[e]]=[t[e],t[r]];return t}const wr={getFeedDataForCard(t){return fr(t)},viewTemplate:hr},xr={"casual-games-card":Ke.H,"casual-games-stripe-carousel-card":Xe.K,"content-card":Ie.K,"content-card-preview-1x":Oe.T,"infopane-card":nr.P,"infopane-slide-card":Be.g,"dense-card":ze.e,"display-ad-card":Ne.s,"money-info-card":Ee.P,"health-articles-card":hr,"native-ad-card":He.DO,"placeholder-card":je.u,"polls-card":Ge.d,"shopping-carousel-card":Qe.j,"weather-card":or.p,"web-content-card":Oe.T,"video-card":ar.Q,"trending-now-card":er.A,"travel-destination-card":Ye.T,"responsive-card":dr.t},$r={[Ct.casualGamesCard]:Ke.D,[Ct.casualGamesStripeCarouselCard]:Xe.O,[Ct.contentCard]:cr.v,[Ct.contentCardPreview1x]:cr.v,[Ct.denseCard]:Fe.o,[Ct.infopaneCard]:lr.V,[Ct.infopaneSlideCard]:cr.v,[Ct.displayAdCard]:Le.E,[Ct.moneyInfoCardWC]:qe.j,[Ct.healthArticlesCardWC]:wr,[Ct.nativeAdCard]:We.$,[Ct.placeholderCard]:Je.M,[Ct.pollsCard]:Ve.N,[Ct.shoppingCarouselCard]:Ze.f,[Ct.trendingNowCard]:rr.Q,[Ct.weatherCard]:ir.j,[Ct.webContentCard]:Ue.m,[Ct.videoCard]:sr.O,[Ct.travelDestinationCard]:tr.t};var kr=r(29871),Pr=r(94108),Sr=r(58319),_r=r(96897),Ar=r(83756),Dr=r(66546),Rr=r(69846),Mr=r(7446),Tr=r(98378),Ir=r(87283);const Or=(t,e)=>{const r=t.split(" ");let a=e;const s=()=>{const t=r.shift();return a=a?.shadowRoot?.querySelector?.(t)||a?.querySelector?.(t),r.length&&a?s():a};return s()},Br=(t,e)=>{const r=t?.shadowRoot||t;if(!r||r.querySelector("style.stripe-style"))return;const a=document.createElement("style");a.className="stripe-style",Object.keys(e).forEach(t=>{a.innerHTML+=`${t} { ${e[t]} }\n`}),r.prepend(a)},Ur=(t,e)=>{const r=document.createElement("style");r.innerHTML=e,t.prepend(r)};var zr=r(87440),Fr=r(63456),Nr=r(29307),Lr=r(12867);const Er=600,qr="local",Hr="promotions",Wr="fromOurPartners",jr="bannerAd",Jr="quizCardWC",Gr={"ar-ae":"BBlFCyr","ar-eg":"BBlmAAj","ar-sa":"BBlFPtc","bn-in":"BBU7Qw4","da-dk":"BBlrVvd","de-at":"BBlROe9","de-ch":"BBZ1dPy","de-de":"BB19Lup4","el-gr":"BBlpx0F","en-ae":"BBlFzXn","en-au":"BB12Wlad","en-ca":"BB15zxqh","en-gb":"BB131KqR","en-ie":"BBlSybW","en-in":"BBlJDWj","en-my":"BBnmzKF","en-nz":"BBloYCJ","en-ph":"BBpkImc","en-sg":"BBnkfV1","en-xl":"BBJLSPs","en-za":"BBlq660","es-ar":"BBnlJDa","es-cl":"BBlrlMA","es-co":"BBloOIy","es-es":"BB12XBRm","es-mx":"BBu6hpo","es-pe":"BBlqzW8","es-us":"BBlsKCT","es-ve":"BBloH3J","es-xl":"BBlsFUm","fi-fi":"BBltzSJ","fr-be":"BBltAia","fr-ca":"BBHSUQ1","fr-ch":"BBm7onJ","fr-fr":"BB1fEVKT","he-il":"BBlrTD9","hi-in":"BBH8j5q","id-id":"BBqRsFe","it-it":"BB1334rQ","ja-jp":"CChcKo","ko-kr":"AAfBokA","mr-in":"AAEnx4n","nb-no":"BBlG6uP","nl-be":"BBltzP7","nl-nl":"BBlpya4","pl-pl":"BBls505","pt-br":"BBlrUUd","pt-pt":"AAg0WfA","sv-se":"BBlu2g8","te-in":"AAEns3L","th-th":"BBot3Jh","tr-tr":"BBlppGp","vi-vn":"BBov02b","zh-cn":"AAFsW17","zh-hk":"BBlBHZI"};function Vr(t,e,r,a,s,o,i){if(!i)return;const n=t.indexOf(i);if(-1===n)return;const l=new Date,d=l.getDay(),c="#"+Math.trunc(l.getHours()).toString()+"#";if(a){d>=1&&d<=5&&a.includes(c)||(s=-1)}if(r&&d>=1&&d<=5&&r.includes(c)&&(s=1),!(null==s||s<0||s>=t.length||s>=e.length))if("1"===o)for(let r=s;r<n;r++){const a=e[r],{cardProviderConfig:s}=a||{},{initialRequest:o}=s||{},{feedId:i,_:l}=o||{};if(i===jr||i===Hr||i===Wr);else{const a=t[r];t[r]=t[n],t[n]=a;const s=e[r];e[r]=e[n],e[n]=s}}else if("2"===o){const r=t[s];t[s]=t[n],t[n]=r;const a=e[s];e[s]=e[n],e[n]=a}else{const r=t.splice(n,1)[0];t.splice(s,0,r);const a=e.splice(n,1)[0];e.splice(s,0,a)}}function Xr(t,e){return t.personalizedStripeConfig?.[e]}var Kr=r(25854),Qr=r(59010),Zr=r(36597),Yr=r(49371);const ta=(0,Zr.wg)("debugalert");class ea{static getServiceUrl(t,e,r){const a=(0,Yr.e3)()?new URL(this.baseUrlForBot):new URL(this.baseUrl),s=new Qr.m;return s.set(pt.T3.OneServiceContentMarketQspKey,e),s.set("ocid","health-verthp-feeds"),s.set("apikey","FywQv6H345wNCU4yKWraF2esI9qiMQFx90v53mMHrm"),s.set("$top","20"),pt.T3?.UserId&&s.set("user",pt.T3.UserId),pt.T3.ShouldUseFdheadQsp&&s.set("fdhead","prg-wpo-healthcs"),s.set("noCache","true"),s.set("$select",t),!1===r&&s.set("ranid",`${Math.random().toString().replace("0.","")}`),a.search=s.toString(),a.href}static async getDataFromOneService(t,e,r){try{if(!e)throw new Error("Null or empty market");if("1"===ta)throw new Error("this is a test alert");const a={method:"GET",headers:{accept:"application/json"}};let s="en";e&&5===e.length&&(s=e.substr(0,2));const o=this.getServiceUrl(t,e,r),i=await(0,mt.w)(async()=>{const t=await fetch(o,a);if(!t)throw Error(`Null response. Url = ${o}`);if(!t.ok)throw Error(`Status:${t.status} Url = ${o}`);return t.json()},"getContentFromOneService");if(!(i&&i.length&&i[0]&&i[0].data))throw new Error(`Null, empty or invalid response Json. Url = ${o}`);return JSON.parse(i[0].data)}catch(t){let e;throw"object"==typeof t?e=t.message:"string"==typeof t&&(e=t),new Error(`Error in one service call. ${e}`)}}}ea.baseUrl="https://api.msn.com/news/feed/segments/health",ea.baseUrlForBot="https://assets.msn.com/service/news/feed/segments/health";var ra=r(94818),aa=r(72627),sa=r(47616),oa=r(73632);const ia=(()=>{if((0,oa.S)())return window.fetch.bind(window);{const t=800;return(e,r)=>(0,sa.hv)(e,t,r)}})();class na{async getUserPreferences(){const t=pt.T3.CurrentMarket||"en-us",e=pt.T3.UserId,r=`/api/v1/getpref/${e}?market=${t}`;let a;try{if(a=await ia(this.getFalconServiceUrl("userpreferencefetcher","bing-shopping",r),this.getFalconRequestInit("GET")),!a||!a.ok)return[];const t=await a.json();if(!t||!t.orderedVerticals)return[];const e=t&&t.orderedVerticals&&{orderedVerticals:t.orderedVerticals.map(t=>({...t,name:t.name}))};return e.orderedVerticals.map(t=>t.name)}catch(t){return(0,dt.c_)(t,ct.QyC,"Error fetching user preference data",`usermuid: ${e}`),[]}}getFalconServiceUrl(t,e,r){let a;return a=(0,aa.ou)().startsWith("localhost.msn.com")?`https://${t}.${e}.microsoft-testing-falcon.io`:`https://services.bingapis.com/${e}.${t}`,a+r}getFalconRequestInit(t){return{method:t}}}const la=R.A`
.stripe-slider-container{left:-52px}`,da=R.A`
.title-arrow{-moz-transform:scale(-1,1);-webkit-transform:scale(-1,1);-o-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.stripe-slider-container{right:-52px}.scrollDownButtonContainerRight{right:inherit;left:25px}`,ca=R.A`
:host{--border-color:#e6e6e6;--heading-font-size:14px;--heading-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--heading-line-height:20px;--heading-start-padding:8px;--abstract-start-padding:8px;--dense-card-hero-width:300px;--dense-card-news-list-width:263px;--dense-list-item-height:39px;--dense-list-item-title-opacity:1;--dense-list-item-title-line-height:19px;--dense-card-new-layout1-margin-top:2px;--dense-card-new-layout1-width:280px;--dense-card-new-layout1-margin:0 11px;--dense-new-layout1-list-item-height:36px;--dense-new-layout1-list-item-max-width:261px;--dense-new-layout1-list-item-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--dense-new-layout1-list-item-font-size:15px;--fill-color:#fff;--heading-max-lines:2}.stripe-feed{height:100%;padding:0px 0px 60px;box-sizing:border-box}.river-section{margin-bottom:8px;display:flex;flex-flow:column;position:relative}.progress-ring-wrapper{display:flex;justify-content:center}.river-section-header-group{align-items:baseline;border-top:2px solid var(--border-color,#e6e6e6);display:flex;width:100%}.river-section-footer-group{align-items:baseline;display:flex;justify-content:space-between;width:100%}.stripe-title{padding-top:5px}.stripe-title h2{font-size:20px;font-weight:600;margin-top:unset;margin-bottom:20px;white-space:nowrap;display:inline-flex;align-items:center}msft-ad-label{min-width:32px;height:13px;margin-right:8px}.stripe-title h2 a{border-bottom:none;color:${F.l};position:relative;text-decoration:none}.stripe-title h2 a:hover{text-decoration:underline}.stripe-title h2 a span{position:absolute;top:.29rem}.stripe-title svg path{stroke:currentColor;stroke-width:1px}.sub-nav{display:grid;grid-template-columns:minmax(0,1fr);margin-inline-start:33px;writing-mode:horizontal-tb}.see-more{min-width:max-content;margin-top:5px;position:absolute;right:0;bottom:-4px}.see-more a{color:#0070c9;font-size:12px;font-weight:600;letter-spacing:0.64px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;text-decoration:none}.in-stripe-banner-ad{width:auto;height:auto;display:flex;justify-content:center;overflow:hidden}.pagination-sentinel{position:absolute;bottom:0;left:0;right:0;z-index:-1;height:200px}.stripe-slider-container{box-sizing:border-box;width:calc(100% + 106px);padding:0px 50px 0px}.stripe-slider-container.more-space{padding-bottom:16px}.stripe-slider-container-rail{padding-right:49px !important;padding-left:49px !important}.stripe-river-section{margin-right:3px}cs-feed-layout:part(heading){font-family:var(--heading-font-family)}msft-ad-label{--ad-label-fill-green:#1E6525;--ad-label-color-white:#FFF}msft-ad-label::part(control){box-sizing:border-box;display:inline-block;border-radius:2px;border-color:transparent;vertical-align:bottom}#liveshopping{display:none}#secondaryStripe{margin-top:-12px}`.withBehaviors(new W.t(la,da),(0,T.G2)(R.A` :host{--fill-color:#2b2b2b}`)),pa="\n:host{--heading-start-padding:16px;--heading-max-lines:2;--heading-line-height:28px}",ha=' fluent-card,fluent-card msn-info-pane{position:relative}fluent-card .placeholder-card{animation:placeholder-animation 1s linear infinite;background-image:linear-gradient(90deg,#fafafa 0%,white 50%,#fafafa 100%);background-size:100px 100%;background-color:#fafafa;background-repeat:no-repeat;background-position:-50%}fluent-card msn-info-pane::part(previous-flipper),fluent-card msn-info-pane::part(next-flipper){opacity:1}@keyframes placeholder-animation{to{background-position:150%}}:host([data-section="finance"]) fluent-card[class="full"]:nth-of-type(1){background:none}:host([data-section="weather"]) fluent-card money-info-card::part(money-card),:host([data-section="tools"]) fluent-card money-info-card::part(money-card),:host([data-section="finance"]) fluent-card money-info-card::part(money-card){height:100%;width:100%;border-radius:4px;display:flex;justify-content:center}:host(cs-feed-layout[data-section="liveshopping"]){width:1271px;margin-right:0px !important;margin-left:0px !important}:host([data-section="partners"]) fluent-card msft-content-card img[slot="media"],:host([data-section="promotions"]) fluent-card msft-content-card img[slot="media"]{width:306px;height:200px;object-fit:cover}#displayAdCard{--elevation:4;display:flex;justify-content:center;height:var(--card-height,100%);width:var(--card-width,100%);padding-top:3px;box-sizing:border-box;background:var(--fill-color);border-radius:calc(var(--layer-corner-radius) * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))))}.info-pane-slide-title{-webkit-line-clamp:2 !important}',ua=" @media (prefers-color-scheme:dark){fluent-card .placeholder-card{background:#2b2b2b !important}}",ga=' .next-arrow,.previous-arrow{height:45px;width:45px}.next::part(next),.previous::part(previous){height:45px;width:45px}.next-arrow:before,.previous-arrow:before{content:"";opacity:0;position:absolute;inset:0px;transition:all 0.1s ease-in-out 0s}',ma="\n.msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.msft-horizontal-card-slider::part(arrow-container){padding:5px 10px}.msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}";var fa=r(44704);const ya={topStripe:{name:"today.Hero",action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Section},secondaryStripe:{name:"today.Hero.standaloneEP",action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Section},headlineItemViewModel:{name:"HeadlineItemViewModel",action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Headline},todayHeadlines:{name:"todayHeadlines",action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Headline},todayStripeHeadlines:{name:"todayStripeHeadlines",action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Headline},title:{name:"title",action:Tr.EG.Click,behavior:Tr.MS.Navigate,type:Tr.MJ.NavBar},seeMore:{name:"seeMore",action:Tr.EG.Click,behavior:Tr.MS.Navigate}};class Ca{getSectionTelemetryTag(t,e){return t in ya?this.getTelemetryTag(ya[t]):this.getTelemetryTag({name:e||`stripe.${t}`,action:Tr.EG.View,behavior:Tr.MS.Show,type:Tr.MJ.Section})}getTelemetryTag(t){return(0,fa.N)(t.name,t.behavior,t.action,t.type).getMetadataTag()}}var ba=r(65794),va=r(12673),wa=r(12882),xa=r(4934),$a=r(31216);const ka=(t,e)=>{const r=e.findIndex(t=>(0,$a.RD)((0,$a.qK)(t)));if(-1!==r){const t=[...e],a=t[r];return t.splice(r,1),t.unshift(a),{backfillMetadata:t,backfillTemplateId:void 0,backfillCardTypeSlot:void 0}}return{backfillMetadata:e,backfillTemplateId:t?.templateId,backfillCardTypeSlot:[]}},Pa=new Map([["video",ka],["video_stripe",ka]]),Sa=(t,e,r)=>{const a={backfillMetadata:void 0,backfillTemplateId:void 0,backfillCardTypeSlot:void 0};try{const s=Pa.get(t);return s&&r?s(r,e):a}catch{return a}};var _a=r(38118);const Aa=(0,Lr.a)().get("vptest"),Da=(0,vt.ZF)(),Ra="AdServiceCall.StripeWC",Ma="inserted-card";function Ta(t){return`stripewc.${t}`}class Ia extends ba.U{constructor(){super(...arguments),this.isFetchingStripes=!1,this.riverSectionLayoutData=[],this.ttvrFired=!1,this.isFeedExhausted=!1,this.enableRail=!1,this.visualReadinessCallbackSet=!1,this.appliedStyles=[],this.defaultLoadCount=2,this.infopaneSubItems=[],this.loadedWebComponents=[],this.nativeAdPlacementsMap={},this.pollsData={poll:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null},quiz:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null}},this.autosData={fallbackToContentCard:!1,data:null,enableStaticResponse:!1},this.riverSectionIndex=0,this.riverSectionResponses={},this.retryCountRecord={},this.nativeAdIsLoaded={},this.nativeAdIndiceRegionFilters=[],this.ttvrLogInfo={topStripeStartAt:[],topStripeFetchedAt:[],topStripeRetryAt:[],topStripeRenderedAt:void 0,topStripeAdsReadyAt:void 0,aboveThefoldReadyAt:void 0,ttvrFiredAt:void 0,ttvrBoundedImage:[]},this.hasSectionInterest={},this.dynamicRankingInterests=[],this.dynamicInterestsFetched=!1,this.shoppingCarouselData={data:[],fallbackToContentCard:!1},this.replacementInfopaneCards={},this.shouldOverrideInfopaneCards=!1,this.customInsertedCards={},this.overrideHasSlideShow=!1,this.dependencies=new Set,this.onBreakpointCallback=t=>{this.columnArrangement=t.toUpperCase(),window.setTimeout(()=>{this.updateShowDot(),this.updateStripes()})},this.initCardAction=t=>{this.cardActionRef||(this.cardActionRef=this.shadowRoot.querySelector?.("card-action")),this.cardActionRef?.updateCardActionProps({...t})},this.getVisualReadinessCallback=(t,e,r)=>{const a=e===Ct.infopaneCard?Ct.infopaneCard:t?.cardContent?.id,s=this.riverSectionIds[0];return this.getSectionAdPlacementIndices(s).includes(r)||this.dependencies.add(a),()=>{this.dependencies.has(a)&&this.dependencies.delete(a),0===this.dependencies.size&&this.setVisuallyReadyMarkers()}},this.getSectionAdPlacementIndices=t=>{const e=[...this.config?.adPlacements?.[t]?.placements||[],...this.config?.cmsAdPlacements?.[t]?.placements||[]],r=[];return e.forEach(t=>{t.region!==Rt.pL.Infopane&&t.indices?.length&&r.push(...t.indices)}),r},this.setVisuallyReadyMarkers=()=>{this.ttvrFired||(this.ttvrFired=!0,(0,wt.D)(()=>{this.markVisuallyReady(),this.ttvrLogInfo.ttvrFiredAt=performance.now(),this.config.enableBulkFetch?this.updateStripes():this.updateStripes(this.riverSectionIds[this.riverSectionLayoutData.findIndex(t=>void 0!==t)]),this.initTopStripeNativeAds().then(()=>{const t=(0,Ar.Kl)();t&&Dr.m?.updateVisuallyReadyTiming?.getActionSender(t)?.send((0,Ar.ez)(it.p_1,void 0,void 0,void 0,window.performance.now()))})}))},this.setPaginationObserver=()=>{"IntersectionObserver"in window&&this.paginationSentinelRef&&(this.sentinelObserver=new IntersectionObserver(this.onSentinelChange),window.requestAnimationFrame(()=>{this.sentinelObserver.observe(this.paginationSentinelRef)}))},this.onSentinelChange=t=>{if(!t||t.length<1||!this.ttvrFired)return;t[0].isIntersecting&&this.onUserPaginate()},this.onUserPaginate=()=>{this.riverSectionIndex<this.riverSections.length?this.fetchStripes(this.config.lazyLoadCount):this.isFeedExhausted=!0},this.isPaginationVisible=()=>{if(!this.paginationSentinelRef)return!1;const{y:t,height:e}=this.paginationSentinelRef.getBoundingClientRect();return t-e<Math.max(document.documentElement.clientHeight,window.innerHeight)},this.processLayoutStyles=()=>{const{stripeStyles:t={}}=this.config;Object.keys(t).forEach(e=>{if(!this.appliedStyles.includes(e)){const r=((t,e,r)=>{const a=Or(t,r);return Br(a,e),a})(e,t[e],this);r&&this.appliedStyles.push(e)}})},this.onDisplayAdHeightChange=t=>{const{htmlId:e,height:r}=t?.detail||{};if(e?.startsWith("rectangle1")&&r&&!this.enableRail){const{longDisplayAdLayoutTemplate:t}=this.config,e=this.riverSectionIds[0];if(!t)return;this.riverSectionLayoutData[0].templateId=r===Er?t:this.riverSections[0].riverSectionTemplate,this.updateStripes(e)}}}isFeedExhaustedChanged(t,e){if(!e)return;this.sentinelObserver?.disconnect();const r=this.config?.cardProviderConfig?.initialRequest?.count||30;this.onFeedEndCb?.({cardCount:r})}async enableRailChanged(t){if("boolean"!=typeof t||!this.config)return;await new Promise(t=>window.setTimeout(t));const{longDisplayAdLayoutTemplate:e}=this.config;this.enableRail&&e&&this.riverSectionLayoutData[0]?.templateId===e&&(this.riverSectionLayoutData[0].templateId=this.riverSections[0].riverSectionTemplate,this.updateStripes(this.riverSectionIds[0]))}async experienceConnected(){this.stripeWCTelemetry||(this.stripeWCTelemetry=new Ca),await _a.D.initConfig(),(0,at.registerCSResponsiveCard)(),(0,st.C)(),ot.T.define(n.G.registry),this.initRiverSectionAndId(),Aa&&(this.riverSectionIds.forEach(t=>(0,xt.cX)(Ta(t))),(0,xt.gR)().then(()=>{Object.assign(Da,{vpready:performance.now()}),performance.mark("vpready")})),this.initFeedLayoutData(),this.topStripeCardProvider=new Rr.f(this.config.cardProviderConfig),this.config.paginationSentinelHeight&&(this.sentinelHeight=`height: ${this.config.paginationSentinelHeight}px;`);const{nativeAdIndiceRegionFilters:t=[]}=this.config;if(this.nativeAdIndiceRegionFilters=t.map(t=>t.toLowerCase()),this.fetchStripes(this.config.initialLoadCount),this.config.buyDirectInfopaneCard?.primaryServiceClientSettings&&this.config.buyDirectInfopaneCard?.shoppingCarouselAPISettings)try{this.shoppingPrimaryServiceClient=this.shoppingPrimaryServiceClient||new ra.J(window.fetch.bind(window),this.config.buyDirectInfopaneCard.primaryServiceClientSettings,this.config.buyDirectInfopaneCard.shoppingCarouselAPISettings,null,location.href)}catch(t){Mr.YT.sendAppErrorEvent({...ct.PxO,message:"Failed to initialize buy direct infopane service client",pb:{...ct.PxO.pb,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}}async initFinanceUserService(){try{const t={experienceType:it.ahW,instanceSrc:"default"};if(this.moneyInfoCardWCConfig=(await kr.L.getConfig(t)).properties,!this.financeUserService){const{FinanceServices:t,getFinanceDataConnector:e}=await Promise.all([r.e("node_modules_crypto-js_index_js"),r.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),r.e("libs_finance-service-library_dist_index_js")]).then(r.bind(r,43818));e().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=t.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)}}catch(t){(0,dt.vV)(ct.yIP,`Failed to initialize finance services: ${t.message}`)}}async initBuyDirectUserService(){try{const t={experienceType:it.Yeu,instanceSrc:"index_Buydirect"};this.buyDirectConfig=(await kr.L.getConfig(t)).properties,this.buyDirectServiceClient||(this.buyDirectServiceClient=new ra.J(window.fetch.bind(window),this.buyDirectConfig.primaryServiceClientSettings,this.buyDirectConfig.shoppingCarouselAPISettings,null,location.href))}catch(t){(0,dt.vV)(ct.$oH,`Failed to initialize buy direct services: ${t.message}`)}}async initUserPreferenceFetcherService(){try{this.userPreferenceFetcherService||(this.userPreferenceFetcherService=new na)}catch(t){(0,dt.vV)(ct.QyC,`Failed to initialize user reference service: ${t.message}`)}}initRiverSectionAndId(){if(this.config.stripePlacementOverwrite){const t=new Set(this.config.stripePlacementOverwrite);Object.entries(this.config.childExperienceReferencesWC).forEach(([e,{hide:r}])=>{r||t.has(e)||Mr.YT.sendAppErrorEvent({...ct.nlb,message:"stripe key from childExperienceReferencesWC does not exist in stripePlacementOverwrite",pb:{...ct.nlb.pb,customMessage:`stripe key: ${e}`}})});const e=[];for(const t of this.config.stripePlacementOverwrite){const r=this.config.childExperienceReferencesWC[t];r?r.hide||e.push(t):Mr.YT.sendAppErrorEvent({...ct.nlb,message:"stripe key from stripePlacementOverwrite does not exist in childExperienceReferencesWC",pb:{...ct.nlb.pb,customMessage:`stripe key: ${t}`}})}this.riverSectionIds=e}else{const t=[];Object.keys(this.config.childExperienceReferencesWC).forEach(e=>{this.config.childExperienceReferencesWC[e].hide||t.push(e)}),this.riverSectionIds=t}const t=this.config.riverSectionCardProviderConfig;this.riverSections=this.riverSectionIds.map(e=>{const r=this.config.childExperienceReferencesWC[e];return{...r,riverCardProvider:new Rr.f((0,zr.A)({},t,r.cardProviderConfig))}})}getExperienceType(){return it.p_1}shadowDomPopulated(){this.columnArrangement=(0,Pt.TU)().currentColumnArrangement.toUpperCase(),(0,Pt.TU)().subscribe(this.onBreakpointCallback),this.updateShowDot(),window.addEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange),this.config&&this.config.adCookieSyncConfig&&this.config.adCookieSyncConfig.isCookieSyncEnabled&&(this.cookieSyncService=new Kr.n(this.config.adCookieSyncConfig||{}),this.cookieSyncService.processCookieSync()),this.setPaginationObserver()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange)}updateShowDot(){const t=this.getDisplayedColumnLayout();this.isShowDot=["C2","C3"].includes(t)||"C4"===t&&this.config.isC5Enabled}async refreshFeed(){this.riverSections.forEach(({riverCardProvider:t})=>t.clearCache()),this.nativeAdPlacementsMap={},this.riverSectionIndex=0,this.initFeedLayoutData(),this.fetchStripes(this.config.initialLoadCount)}initFeedLayoutData(){this.riverSectionLayoutData=new Array(this.riverSectionIds.length).fill(void 0)}async fetchStripes(t=this.defaultLoadCount){if(this.isFetchingStripes)return;let e=0;this.isFetchingStripes=!0;const r=()=>{this.isFetchingStripes=!1,(this.isPaginationVisible()||this.config.enableBulkFetch)&&this.riverSectionIndex<this.riverSections.length&&this.fetchStripes(this.config.lazyLoadCount),this.riverSectionIndex>=this.riverSections.length&&($t.M.singleMark("StripeWC-FullPageLoaded"),this.isFeedExhausted=!0)},a=Xr(this.config,"finance"),s=Xr(this.config,"buydirect"),o=Xr(this.config,"dynamicStripe"),i=[];if((a?.moveStripePosition||a?.personalizeInsertCard)&&i.push(this.fetchFinanceInterests()),o?.enabled&&i.push(this.fetchDynamicInterests()),await Promise.all(i),o?.runBeforeFinanceRanking&&this.updateDynamicSectionRanking(o),o?.skipFinanceRanking&&0!=this.dynamicRankingInterests.length||this.updateFinanceSectionRanking(a),o?.runBeforeFinanceRanking||this.updateDynamicSectionRanking(o),s?.moveStripePosition&&(await this.initBuyDirectUserService(),this.buyDirectServiceClient&&(null==this.hasSectionInterest.buydirect&&await this.updateUserBuyDirectInterest(),this.hasSectionInterest.buydirect>0&&(Vr(this.riverSectionIds,this.riverSections,void 0,void 0,s.newStripePositionIndex,"1","buydirect"),Mr.YT.addOrUpdateTmplString("BuyDirectStripeMovedToTop")))),this.riverSectionIndex>0&&this.config.enableBulkFetch){const e=[],a=this.riverSectionIndex;for(let r=a;r<Math.min(this.riverSections.length,a+t);r++){const t=this.riverSectionIds[r],a=this.riverSections[r],{feedId:s,count:o}=a.cardProviderConfig.initialRequest;s===jr||s===Hr||s===Wr?e.push(new Promise(t=>t(void 0))):s===qr?e.push(this.fetchLocalNewsRiverContent(o)):e.push(this.fetchRiverContent(t,a))}Promise.all(e).then(async e=>{for(let r=a;r<Math.min(this.riverSections.length,a+t);r++){const t=this.riverSectionIds[r];this.riverSectionResponses[t]=e[r-a],await this.fetchStripe(this.riverSectionIndex++)}this.isFetchingStripes=!1}).catch(async t=>{console.error(t)}).finally(()=>{r()})}else{const a=async()=>{if(this.riverSectionIndex<this.riverSections.length&&e<t){try{await this.fetchStripe(this.riverSectionIndex++),this.riverSectionLayoutData[this.riverSectionIndex-1]&&e++}catch(t){console.error(t)}!this.ttvrFired&&this.riverSectionLayoutData[this.riverSectionIndex-1]?((0,Ar.Qc)().then(async()=>{this.ttvrLogInfo.aboveThefoldReadyAt=performance.now(),this.ttvrFired||(this.setVisuallyReadyMarkers(),Mr.YT.sendAppErrorEvent({...ct.HR1,message:"TTVR is blocked due to the first image is not available.",pb:{...ct.HR1.pb,customMessage:JSON.stringify(this.ttvrLogInfo)}}))}),await(0,kt.dT)(),await a()):await a()}};await a(),r()}}async fetchFinanceInterests(){await this.initFinanceUserService(),this.financeUserService&&(null!=this.hasSectionInterest.finance&&null!=this.hasSectionInterest.casualGames||await this.updateUserFinanceInterest())}async fetchDynamicInterests(){await this.initUserPreferenceFetcherService(),this.userPreferenceFetcherService&&(this.dynamicInterestsFetched||this.updateDynamicRankingInterests())}updateFinanceSectionRanking(t){t?.moveStripePosition&&this.hasSectionInterest.finance>t.financeInterestScore&&Vr(this.riverSectionIds,this.riverSections,t.moveStripeToTopHours,t.moveStripeToIndexHours,t.newStripePositionIndex,t.adsLocStrategy,"finance")}updateDynamicSectionRanking(t){if(this.dynamicRankingInterests.length>0){let e=t.newStripePositionIndex;for(let r=0;r<this.dynamicRankingInterests.length;r++){const a=this.dynamicRankingInterests[r];Vr(this.riverSectionIds,this.riverSections,void 0,void 0,e,t.adsLocStrategy,a),-1!=this.riverSectionIds.indexOf(a)&&(e=this.riverSectionIds.indexOf(a)+1)}}}async getWeatherData(t){const e={};e.requestInfo={isStaleRefresh:t};const{PageBase:a}=await r.e("libs_experiences-page-base-wc_dist_index_js").then(r.bind(r,40817));this.weatherDataConnector=await a.getInstance().rootReducer.getDataConnector(nt.ni),this.weatherDataConnector&&(this.activeLocation=await this.weatherDataConnector.fetchActiveStateforWeather(null,null,e))}async fetchAutosData(t){try{const e=await yt(this.autosData.enableStaticResponse,Z.MSNHomePage);e.includes("Listing")?(this.autosData.data=e,this.updateStripes(t)):this.autosData.fallbackToContentCard=!0}catch(t){this.autosData.fallbackToContentCard=!0,(0,dt.c_)(t,ct.uqN,"send request to segments api failed")}}async fetchStripe(t){const e=this.riverSections[t],r=this.riverSectionIds[t],{feedId:a,count:s}=e.cardProviderConfig.initialRequest;let o,i=!1,n=[];if(0===t&&this.ttvrLogInfo.topStripeStartAt.push(performance.now()),this.hasMoneyInfoCardWC(r)&&!this.loadedWebComponents.includes[Ct.moneyInfoCardWC]?this.fetchMoneyInfoCardData(r):this.hashealthArticleInfoCardWC(r)&&!this.loadedWebComponents.includes[Ct.healthArticlesCardWC]?this.fetchHealthInfoCardData(r):this.hasTravelDestinationCardWC(r)&&!this.loadedWebComponents.includes[Ct.travelDestinationCard]&&this.fetchTravelDestinationCardData(r),a===jr)n=Array(s).fill({type:Rt.pL.Article});else if(a===Hr||a===Wr)n=this.createStripeAdCardDefaultMetadata(s),this.config.cmsAdPlacements?.[r]&&this.loadNativeAd(r,!0),this.loadNativeAd(r),i=!0;else if(a===qr){await this.getWeatherData(),o=this.riverSectionResponses[r]||await this.fetchLocalNewsRiverContent(s);const t=Pr.Rb.Locale;if(Pr.Rb.ClientSettings.locale.market===this.activeLocation.isoCode.toLowerCase()){const{locality:r,displayName:a}=this.activeLocation;(0,Fr.A)(o,"value[0].subCards[0].feed.feedName",r);e.riverSectionTitle=a,"es-ar"!=t&&(e.seeMoreUrl+="local"),n=o.subCards||[]}}else o=this.riverSectionResponses[r]||await this.fetchRiverContent(r,e),o?.cardMetadata?.length?(ut.WR.removeOcidFromRiverCardProviderResponse(o),n=o.cardMetadata,this.loadNativeAd(r),0===t&&this.ttvrLogInfo.topStripeFetchedAt.push(performance.now())):this.retryFetchingStripe(t),i=!0;this.addRiverSection(t,e,n,i)}async retryFetchingStripe(t){const e=this.config.retryTimeOutMs&&this.config.retryTimeOutMs>=0?this.config.retryTimeOutMs:1e3,r=this.config.maxRetryTimes&&this.config.maxRetryTimes>=0?this.config.maxRetryTimes:0,a=this.riverSectionIds[t];this.retryCountRecord[a]||(this.retryCountRecord[a]=0),this.retryCountRecord[a]>=r||(this.retryCountRecord[a]++,Mr.YT.sendAppErrorEvent({...ct.sOF,message:`Start retrying to fetch [${a}] in ${e}ms.`,pb:{...ct.sOF.pb,customMessage:`Retry count: ${this.retryCountRecord[a]}`}}),window.setTimeout(async()=>{0===t&&this.ttvrLogInfo.topStripeRetryAt.push(performance.now()),await this.fetchStripe(t),0===t&&await this.initTopStripeNativeAds()},e))}addRiverSection(t,e,r=[],a=!0){const s=r.filter(t=>{if(Mt[t.type])return t;Mr.YT.sendAppErrorEvent({...ct.vES,message:"Unsupported content card type in OneService metadata.",pb:{...ct.vES.pb,customMessage:`Card type [${t.type}] needs to be added to MSNHomepageOneServiceMetadataTypeToCardTypeMap`}})});if(!s?.length)return;const o=this.riverSectionIds[t];let i=e.riverSectionTemplate,n=s,l=[];const{adPlacements:d={},cmsAdPlacements:c={},insertCardInSlot:p={}}=this.config,h=this.config.slotToCardType||{};let u=(0,Nr.A)(h[o])||[];const{backfillMetadata:g,backfillCardTypeSlot:m,backfillTemplateId:f}=Sa(o,n,this.config.childExperienceReferencesWC?.[o]?.backfillConfigs);n=g||n,u=m||u,i=f||i;const y=Me[i]||{},C=Xr(this.config,o);C?.personalizeInsertCard&&this.hasSectionInterest[o]>0&&(p[o]=p[o].filter(t=>t?.cardType!==C.cardToDisable));const b=[...d[o]?.placements||[],...c[o]?.placements||[]],v=[...u||[],...p[o]||[]];b.forEach(t=>{t&&t.region!==Rt.pL.Infopane&&t?.indices.forEach(t=>{const e=t-1;l.includes(e)||l.push(e)})});const w=[];v.forEach(t=>{t&&t?.cardType!==Ct.contentCard&&t?.cardType!==Ct.videoCard&&t?.cardType!==Ct.pollsCard&&(t?.cardType!==Ct.denseCard?t.positions?.forEach(t=>{let e=parseInt(t.slot.replace("slot",""))-1;w.forEach(t=>{t.index<e&&(e+=t.count-1)}),l.includes(e)||l.push(e)}):t.positions?.forEach(e=>{const r=parseInt(e.slot.replace("slot",""))-1;w.push({index:r,count:t.args?.denseListSize||0})}))}),l=l.sort((t,e)=>t>e?1:t<e?-1:0),l.forEach(t=>{const e=n.pop();n.splice(t,0,e)}),this.riverSectionLayoutData[t]={cardMetadataList:n,feedData:this.mapFeedData(o,n,y,this.config.openLinksInNewTab,this.telemetryObject,u,t),hasPlaceHolderAds:a,insertBannerAd:e?.insertBannerAd,pivotsNav:e?.pivotsNav,riverSectionTitle:e?.riverSectionTitle,riverSectionTitleUrl:(0,Sr.bI)(e?.riverSectionTitleUrl?e.riverSectionTitleUrl:e?.seeMoreUrl),riverSectionTitleColor:e?.riverSectionTitleColor,seeMoreUrl:(0,Sr.bI)(e?.seeMoreUrl),seeMoreText:e?.seeMoreText,adLabel:e?.adLabel,sectionId:o,telemetryName:e?.telemetryName,templateId:i,adSlugGA:this.config.adSlugGA,isMsnHPAdSlug:this.config.isMsnHPAdSlug,enableSafeAds:!!this.config?.enableSafeAds,disableSlider:this.config.disableStripeSlider,leftArrow:this.config.localizedStrings.previousArrow,rightArrow:this.config.localizedStrings.nextArrow,disableStripeTheme:this.config.disableStripeTheme,isC5Enabled:this.config.isC5Enabled,isDVEnabled:this.config?.isDVEnabled},0===t&&((0,kt.yi)(`${this.getExperienceType()}TopStripeRendered`),this.ttvrLogInfo.topStripeRenderedAt=performance.now()),"shopping"===o&&this.config.overrideBingUrlsAugmentations&&(this.riverSectionLayoutData[t].riverSectionTitleUrl=St.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[t].riverSectionTitleUrl,"msn"),this.riverSectionLayoutData[t].seeMoreUrl=St.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[t].seeMoreUrl,"msn")),this.riverSectionLayoutData=[...this.riverSectionLayoutData]}async addFlipperStyles(){const t=await(e="msft-horizontal-card-slider",r=this.shadowRoot,new Promise(t=>{const a=(0,Ir.A)(()=>{t(r.querySelectorAll(e)),s.disconnect()}),s=new MutationObserver(a);s.observe(r,{childList:!0,subtree:!0})}));var e,r;if(t?.length&&t[0].shadowRoot)for(let e=0;e<t.length-1;e++)Ur(t[e].shadowRoot,ga)}async fetchRiverContent(t,e){let r;const a=this.riverSectionIds[0];let s="";t===a&&(s=` TTVR log: ${JSON.stringify(this.ttvrLogInfo)}`);try{if(t===a){if(_r.WD&&e.enableWebWorker&&!this.config.disableWWForTopStripe){const t=this.config?.cardProviderConfig?.initialRequest?.timeoutMs||1e3;r=await e.riverCardProvider.fetchFromWebWorker("myfeed",t)}else window.enableEarlyRiverRequest&&window.topStripeResponse&&(window.enableEarlyRiverRequest=!1,r=window.topStripeResponse);r?.cardMetadata?.length||(r=await this.topStripeCardProvider.fetch())}else r=await e.riverCardProvider.fetch({})}catch(e){Mr.YT.sendAppErrorEvent({...ct.sOF,message:`Content fetch failed for Stripe WC river section when loading ${t}`,pb:{...ct.sOF.pb,customMessage:`Failed with exception : ${JSON.stringify(e)} ${s}`}})}if(r?.cardMetadata?.length){if(t!==a&&r.cardMetadata[0]?.type===Rt.pL.Infopane)r.cardMetadata=r.cardMetadata.filter(t=>t.type!==Rt.pL.Infopane);else if(t===a&&r.cardMetadata[0]?.type===Rt.pL.Infopane){const t=this.config.cardProviderConfig?.initialRequest?.infopaneItemCount;t&&r.cardMetadata[0].subItems.length>t&&(r.cardMetadata[0].subItems=r.cardMetadata[0].subItems.slice(0,t))}"esports"===t&&r?.cardMetadata?.length<8&&Mr.YT.sendAppErrorEvent({...ct.nZM,message:`Content fetch content is less than 8 for Stripe WC river section when loading ${t}`,pb:{...ct.nZM.pb,customMessage:`Returned response: ${JSON.stringify(r)} ${s}`}})}else Mr.YT.sendAppErrorEvent({...ct.uIm,message:`Content fetch failed for invalid empty Stripe WC river section when loading ${t}`,pb:{...ct.uIm.pb,customMessage:`Returned response: ${JSON.stringify(r)} ${s}`}});return r}async fetchLocalNewsRiverContent(t){let e,a;const{PageBase:s}=await r.e("libs_experiences-page-base-wc_dist_index_js").then(r.bind(r,40817));this.weatherDataConnector=await s.getInstance().rootReducer.getDataConnector(nt.ni);const o=this.weatherDataConnector.getCurrentState().currentLocation||this.activeLocation,{latitude:i,longitude:n}=o,l=`${i}|${n}`,{apikey:d}=this.config,{ocid:c}=this.config.riverSectionCardProviderConfig.initialRequest,p=pt.T3.CurrentMarket;if(a=`${pt.T3.AssetsUrl}/service/MSN/Feed/me?$top=${t}&cm=${p}&location=${l}&ocid=${c}&apikey=${d}&cipenabled=false&DisableTypeSerialization=true&query=localnews&queryType=myfeed&wrapodata=false&responseSchema=cardview`,this.has1SFlight("1s-viewurldomain")){const t="1s-viewurldomain";a=`${a}&${["fd","head"].join("")}=${t}`}try{e=await fetch(a)}catch(t){Mr.YT.sendAppErrorEvent({...ct.sOF,message:"Content fetch failed for Local News River section.",pb:{...ct.sOF.pb,url:a,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}return e?.json()}async fetchShoppingCarouselData(t){try{this.shoppingCarouselData.data?.length?this.updateStripes(t):this.shoppingCarouselData.fallbackToContentCard=!0}catch(t){this.shoppingCarouselData.fallbackToContentCard=!0}}async fetchShoppingCarouselBDData(t){const e=await t.getShoppingEntitiesDataUsing1S(!0,1e3);return e||null}async getBuyDirectCard(){const t=await this.fetchShoppingCarouselBDData(this.shoppingPrimaryServiceClient);if(!t||!t.shoppingEntities||!t.shoppingEntities.length)return Mr.YT.sendAppErrorEvent({...ct.ca0,message:"No buy direct infopane card data from 1S.",pb:{...ct.ca0.pb,customMessage:"No buy direct infopane card data from 1S."}}),null;const e=t.shoppingEntities[0];if(!e.globalOfferId||!e.title||!e.imageInfo.sourceImageUrl)return Mr.YT.sendAppErrorEvent({...ct.ca0,message:"Invalid buy direct infopane card data data from 1S.",pb:{...ct.ca0.pb,customMessage:"Invalid buy direct infopane card data from 1S."}}),null;const r=this.config.buyDirectInfopaneCard.formcode,a=this.config.buyDirectInfopaneCard.trafsrc,s=this.config.bwmCampaignCode??"";let o=this.config.bdBlurredBackground?"InfoBuyDirectCard":"BuyDirectCard";o+=this.config.buyDirectEventDecoration?this.config.buyDirectEventDecoration:"",o+=this.config.disableBuyDirectCashback?"_NoCashback":"";const i=_t.u.buildAbsoluteUrl({market:pt.T3.CurrentMarket,pid:e.globalOfferId,title:e.title,trafsrc:a,ocid:a,formCode:r,isBing:this.config.bdDirectToBing,isBWM:this.config.isBWM,campaignCode:s}),n=e.cashbackInfo?.cashbackPercentage&&e.cashbackInfo?.cashbackPercentage>0?`${e.cashbackInfo.cashbackPercentage}%`:void 0;this.config?.enableForumCashback&&!n&&Mr.YT.sendAppErrorEvent({...ct.LOQ,message:"Buy Direct stripe offer failed to fetch dynamic cashback",pb:{...ct.LOQ.pb,customMessage:"Empty cashback info"}});const l=(0,At.Yd)((0,At.Lm)()),d=n||l;let c=d?`Buy with Microsoft - ${d} Cash back and free shipping on all orders`:"Buy with Microsoft - Earn Cash back";c=this.config.disableBuyDirectCashback?"Buy with Microsoft - Free shipping on all orders":c;return{type:"link",cardContent:{abstract:c,destinationUrl:`${i}`,id:`${e.id}`,kicker:`${e.title}`,title:`${e.priceInfo?.price?e.priceInfo.price+" ":""}${e.title}`,type:"link",category:{product:"news"},images:[{id:`${e.globalOfferId}`,url:`${e.imageInfo.sourceImageUrl}`}]},id:o}}getInfopaneCardOverride(t,e,r,a,s,o){return{type:"link",cardContent:{destinationUrl:a,title:s,type:"link",category:{product:"news"},images:[{url:(0,Dt.Je)(o,r,e)}]},id:t}}mapFeedData(t,e,r,a,s,o,i){if(!e||!e.length||!r)return null;const n={defaultLayout:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]},{rowHeightPx:l,colWidthPx:d,gutterPx:c,cardSlots:p=[]}=r,h=i>2?i-2:i-1,u="topStripe"===t?{C5:0,C4:0,C3:0,C2:0}:{C5:4+3*h,C4:4+3*h,C3:4+3*h,C2:6+3*h},g=this.columnArrangement.toLowerCase(),{slotToCardType:m={},insertCardInSlot:f={}}=this.config,y={...this.config.infopaneConfig||{}},C={};return f[t]&&f[t].forEach(({cardType:r,positions:a,args:s})=>{const o=a.find(t=>!t.column||t.column===g);if(o){const a=p.findIndex(t=>t.grid_area===o.slot);if(C[o.slot]=r,a>-1){const o={type:Ma,cardContent:{insertedCardType:r,insertedCardArgs:s},id:`${r}-slot-${a+1}`};if(e[a]?.id===o.id)return;if(r===Ct.pollsCard){const r=s.pollsCardConfigInfo.instanceId===Jr,i=r?this.pollsData.quiz:this.pollsData.poll;i.fallbackToContentCard||(i.fetchingTriggered?i.data&&(e[a]&&e.push(e[a]),e[a]=o):this.fetchQuizData(t,r))}else if(r===Ct.denseCard){const{denseListSize:t,denseDataConfigOptions:r}=s,i=e.splice(a,t);r?.enableDenseLayout1&&i.unshift(i[0]),o.subItems=i,e.splice(a,0,o)}else if(r===Ct.shoppingCarouselCard){const r=["index_LiveShopping_Shopping","index_LiveShopping_Lifestyle"];r.includes(s.configOptions.configRef.instanceSrc)&&!this.shoppingCarouselData?.fallbackToContentCard&&(this.shoppingCarouselData.data?.length?(e[a]&&e.push(e[a]),e[a]=o):this.fetchShoppingCarouselData(t)),!this.shoppingCarouselData.data?.length&&r.includes(s.configOptions.configRef.instanceSrc)||(e[a]&&e.push(e[a]),e[a]=o)}else e[a]&&(e.push(e[a]),this.customInsertedCards[r]={metadataIndex:a,cardData:e[a],backupIndex:e.length-1}),e[a]=o}}else if(this.customInsertedCards[r]){const{metadataIndex:t,cardData:a,backupIndex:s}=this.customInsertedCards[r];e.splice(s,1),e[t]=a,this.customInsertedCards[r]=void 0}}),p.forEach((r,i)=>{const p=e[i];if(!p)return;let h=p.cardContent?.insertedCardType||Mt[p.type];const f=o||m[t],b=f?f.find(({positions:t})=>t.some(t=>(!t.column||t.column&&t.column===g)&&t.slot===r?.grid_area)):null;if(b&&(h=b.cardType),!h)return;const v=parseFloat(r?.grid_area?.replace("slot",""));let w=null;const x=()=>this.config.enableNewTTVR?this.getVisualReadinessCallback(p,h,v):this.setVisuallyReadyMarkers;if(!this.ttvrFired){const e=this.riverSectionIds[0];if(t===e)if(this.visualReadinessCallbackSet&&!this.config.enableNewTTVR||h!==Ct.infopaneCard){if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&h===Ct.contentCard){this.visualReadinessCallbackSet=!0;const t=(0,Te.Ie)(p);t&&(this.ttvrLogInfo.ttvrBoundedImage.push(`today hero content: ${t.url}`),w=x())}}else this.visualReadinessCallbackSet=!0,w=x(),p.subItems=p.subItems.map(t=>({...t,visualReadinessCallback:w})),this.ttvrLogInfo.ttvrBoundedImage.push(`today hero infopane: ${p.subItems[0]?.cardContent?.images[0]?.url}`);else if(h===Ct.contentCard){const t=(0,Te.Ie)(p);t&&(this.ttvrLogInfo.ttvrBoundedImage.push(`river content: ${t.url}`),w=this.setVisuallyReadyMarkers)}}const $={...this.config,...this.config.childExperienceReferencesWC[t],isMsnHpExternalLinkCard:"link"===p.type},k=this.nativeAdPlacementsMap[t];h!==Ct.nativeAdCard&&h!==Ct.infopaneCard||!k?.length||($.isGreyAdsLabelEnabled=k[0]?.isGreyAdsLabelEnabled),p.type===Rt.pL.Infopane&&($.useMsnHomepageCardTemplate=!0,this.ttvrFired||(y.disableAutoRotate=!0));const P=p?.cardContent?.insertedCardArgs?.pollsCardConfigInfo?.instanceId===Jr?this.pollsData.quiz:this.pollsData.poll;(!this.ttvrFired&&p.type===Ma||this.getSectionAdPlacementIndices(t).includes(v)&&!this.nativeAdIsLoaded[t]||C[r?.grid_area]===Ct.pollsCard&&P.isFetching)&&(h=Ct.placeholderCard);const S=(p?.cardContent?.type||p?.type)===Rt.pL.WebContent;let _={cardMetadata:p,cardSlot:r,parentTelemetryObject:s,openLinksInNewTab:a||$.isMsnHpExternalLinkCard,openLinksInCurrentTab:!a&&!$.isMsnHpExternalLinkCard,isAnaheimDesign:!0,refreshFeedCallback:()=>this.refreshFeed(),visualReadinessCallback:w,localizedStrings:this.config.localizedStrings||{},isProviderInFooter:!0,hideComments:S,enableRichSocialReaction:!!this.config.childExperienceReferences?.socialBarWC,initCardAction:this.initCardAction,configOptions:{...$,disableOptedOutButton:!0,enableWCCardAction:!0,enableHoverCardAction:!!this.config.childExperienceReferences?.cardAction,useSmallFontSize:h!==Ct.infopaneCard,isImage32:!0,useHomepageTelemetry:!0,enableWebContentSocialReactions:!0,socialBarInRight:!0,providerOnTop:!0,providerOnTopInfopane:!0,hideCommentsInHalfUCards:!0,disableSlideShow:!this.overrideHasSlideShow&&this.config.disableSlideShow},isIASEnabled:this.config.isIASEnabled,appendIdxForId:this.config.appendIdxForId,rowHeightPx:l,colWidthPx:d,gutterPx:c,rowCount:u};if(p.cardContent?.insertedCardArgs&&(_=(0,zr.A)({},_,p.cardContent.insertedCardArgs)),b&&(_=(0,zr.A)({},_,b.args)),_.configOptions.useInfopaneSlideTemplate&&(_.immersiveCard=!0),h===Ct.infopaneCard)if(!this.infopaneSubItems?.length&&p?.subItems?.length&&(this.infopaneSubItems=p.subItems.slice()),this.ttvrFired||(this.config.enableDenseSlide&&this.config.denseListSize?p.subItems=p.subItems.slice(0,this.config.denseListSize+1):p.subItems=p.subItems.slice(0,1)),_=(0,zr.A)({},_,y),this.config.enableDenseSlide&&this.config.denseListSize){const t=this.config.denseCardCount||1,e=this.config.denseListSize+1,r=_.cardMetadata.subItems,a=[];for(let s=0;s<t;s++){const t=s*e,o=(s+1)*e,i={size:0,subItems:r.slice(t,o).map(t=>({...t,visualReadinessCallback:void 0})),type:"densetab",visualReadinessCallback:r&&r[0].visualReadinessCallback};i.subItems.length>0&&a.push(i)}r.splice(t*e).forEach(t=>{a.push(t)}),_.cardMetadata.subItems=a}else if(_.cardMetadata?.subItems?.length){const t=_.cardMetadata.subItems;_.cardMetadata.subItems=t.map(t=>t?.subItems&&t?.subItems.length>0?t.subItems[0]:t)}if(h!==Ct.contentCard&&h!==Ct.infopaneCard||!this.ttvrFired||this.config.childExperienceReferences?.socialBarWC&&(0,wa.uC)(this.config.childExperienceReferences.socialBarWC),"video"===t&&h===Ct.contentCard&&p.type===Rt.pL.WebContent){const t=_.cardMetadata&&_.cardMetadata.cardContent;if(t){const{destinationUrl:e,title:r,id:a}=t;_.cardMetadata.cardContent.destinationUrl=(0,va.C)(a,e,r)}}if(this.ttvrFired&&h===Ct.trendingNowCard&&!this.loadedWebComponents.includes(Ct.trendingNowCard))try{(0,wa.uC)(_.configOptions),this.loadedWebComponents.push(Ct.trendingNowCard)}catch(t){Mr.YT.sendAppErrorEvent({...ct.oUl,message:"Failed to load Trending Now WC",pb:{...ct.oUl.pb,errorMessage:JSON.stringify(t)}})}if(this.ttvrFired&&h===Ct.pollsCard){const t=p.cardContent.insertedCardArgs.pollsCardConfigInfo.instanceId===Jr;_.cardMetadata.data=t?this.pollsData.quiz.data:this.pollsData.poll.data}if(this.ttvrFired&&h===Ct.moneyInfoCardWC&&(this.moneyInfoCardWCData?_.cardMetadata.data=this.moneyInfoCardWCData:_.cardMetadata.data="{}",this.loadedWebComponents.includes(Ct.moneyInfoCardWC)||((0,wa.uC)(_.configOptions),this.loadedWebComponents.push(Ct.moneyInfoCardWC))),this.ttvrFired&&h===Ct.healthArticlesCardWC&&(_.cardMetadata.data=this.healthInfoCardWCData||"{}",this.loadedWebComponents.includes(Ct.healthArticlesCardWC)||((0,wa.uC)(_.configOptions),this.loadedWebComponents.push(Ct.healthArticlesCardWC))),this.ttvrFired&&h===Ct.travelDestinationCard){_.cardMetadata={..._.cardMetadata,...this.travelDestinationCardWCData};const t=this.travelDestinationCardWCData?.dataType;let e;e=["HotelList","HotelListingResult"].includes(t)?it.S6:e,e=["FlightPriceTrends","FlightPriceTrendsList"].includes(t)?it.aJb:e,e=["ThemeCardList","ThemeInspiration"].includes(t)?it.znl:e,e=["DestinationList","Destination"].includes(t)?it.Qs5:e,e&&_.configOptions.configRef?.experienceType&&(_.configOptions.configRef.experienceType=e),this.loadedWebComponents.includes(Ct.travelDestinationCard)||((0,wa.uC)(_.configOptions),this.loadedWebComponents.push(Ct.travelDestinationCard))}const A=$r[h].getFeedDataForCard(_);h===Ct.denseCard&&p.cardContent.insertedCardArgs?.denseDataConfigOptions&&(A.defaultLayout[0].denseData.configOptions=p.cardContent.insertedCardArgs?.denseDataConfigOptions),Object.keys(A).forEach(t=>{n[t]&&(n[t]=n[t].concat(A[t]))})}),n}async fetchQuizData(t,e){let a;a=this.config.disableQuizCard?e?null:this.config.pollsCardWCConfig:e?this.config.quizCardWCConfig:this.config.pollsCardWCConfig;const s=e?"quiz":"poll";if(this.pollsData[s].fetchingTriggered=!0,this.pollsData[s].isFetching=!0,a)try{const{contentId:o,timezoneDiffToUTC:i}=a,{PollsCardWCActionServiceClient:n}=await r.e("polls-service").then(r.bind(r,50612)),l=new n(window.fetch.bind(window)),d=await l.getPollsData(o,e,i);d?.length>0?this.pollsData[s].data=d:this.pollsData[s].fallbackToContentCard=!0,$t.M.singleMark("StripeWC-PollsCardLoadEnd"),this.pollsData[s].isFetching=!1,this.updateStripes(t)}catch(t){this.pollsData[s].fallbackToContentCard=!0;const e={...ct.V9L,message:"Failed fetching Poll/Quiz data for stripe wc",pb:{...ct.V9L.pb,customMessage:t.message}};Mr.YT.sendAppErrorEvent(e)}else this.pollsData[s].fallbackToContentCard=!0}async initTopStripeNativeAds(){const t=this.riverSectionIds[0];try{if(!this.ttvrFired||!this.riverSectionLayoutData[0])return;await this.initNativeAdService();const e=[this.fetchNativeAdsContent(t),this.fetchNativeAdsContent(t,!0)];Promise.all(e).then(e=>{const[r=[],a=[]]=e;this.updateAdPlacementData(t,[...r,...a]),$t.M.singleMark("StripeWC-topStripeReady"),this.startInfopaneAutoRotation(),this.ttvrLogInfo.topStripeAdsReadyAt=performance.now()})}catch(e){return Mr.YT.sendAppErrorEvent({...ct.sHf,message:"Error when fetching top stripe nativeAds data",pb:{...ct.sHf.pb,errorMessage:JSON.stringify(e)}}),this.updateStripes(t),void this.startInfopaneAutoRotation()}}hasTravelDestinationCardWC(t){const e=this.config.insertCardInSlot?.[t]||[];let r=!1;return e.forEach(t=>{t?.cardType===Ct.travelDestinationCard&&(r=!0)}),r}hashealthArticleInfoCardWC(t){const e=this.config.insertCardInSlot?.[t]||[];let r=!1;return e.forEach(t=>{t?.cardType===Ct.healthArticlesCardWC&&(r=!0)}),r}hasMoneyInfoCardWC(t){const e=this.config.insertCardInSlot?.[t]||[];let r=!1;return e.forEach(t=>{t?.cardType===Ct.moneyInfoCardWC&&(r=!0)}),r}async updateUserFinanceInterest(){const t=await this.financeUserService.getFinanceInterest();t&&(this.hasSectionInterest.finance=0,t.explicit?.length>0&&(this.hasSectionInterest.finance+=1e3),t.implicit?.length>0&&(this.hasSectionInterest.finance+=1))}async updateDynamicRankingInterests(){this.dynamicRankingInterests=await this.userPreferenceFetcherService.getUserPreferences(),this.dynamicInterestsFetched=!0}async updateUserBuyDirectInterest(){await this.buyDirectServiceClient.hasBuyDirectInterest()&&(this.hasSectionInterest.buydirect=1)}async fetchTravelDestinationCardData(t){await xa.Iw.GetSDCardData().then(e=>{e&&Array.isArray(e)&&e.length>0&&(this.travelDestinationCardWCData=e[0],this.travelDestinationCardWCData&&this.travelDestinationCardWCData.length>0&&this.updateStripes(t))})}async fetchHealthInfoCardData(t){const e=pt.T3.CurrentMarket,r=`recommendations|articleData|1|${e}`;await ea.getDataFromOneService(r,e,!0).then(e=>{e&&(this.healthInfoCardWCData=JSON.stringify(e),this.healthInfoCardWCData&&this.healthInfoCardWCData.length>0&&this.updateStripes(t))})}async fetchMoneyInfoCardData(t){const e={experienceType:it.ahW,instanceSrc:"default"};this.moneyInfoCardWCConfig=(await kr.L.getConfig(e)).properties;try{if(!this.financeUserService||!this.financeAutoSuggestService||!this.financeService){const{FinanceServices:t,getFinanceDataConnector:e}=await Promise.all([r.e("node_modules_crypto-js_index_js"),r.e("libs_finance-service-library_dist_common_FinanceRoute_js-libs_finance-service-library_dist_re-862025"),r.e("libs_finance-service-library_dist_index_js")]).then(r.bind(r,43818));this.financeUserService||(e().config.enableUnsignedWatchlist=this.moneyInfoCardWCConfig?.enableUnsignedWatchlist,this.financeUserService=t.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)),this.financeAutoSuggestService=t.getAutoSuggestService(),this.financeService=t.getCachedFinanceService()}const e={userSignedIn:!1,dataFrom:"watchlist",dataTimestamp:null,data:null,fullWatchlistQuoteIds:null};if(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)e.userSignedIn=!0;else{const{getUserSignInState:t}=await r.e("libs_auth_dist_index_js").then(r.bind(r,9788));e.userSignedIn=2===await t()}let a=[];(e.userSignedIn||this.moneyInfoCardWCConfig.enableUnsignedWatchlist)&&(a=await this.financeUserService.getWatchlist(!1),e.fullWatchlistQuoteIds=a),a&&0!==a.length||this.moneyInfoCardWCConfig.enableUnsignedWatchlist?e.dataFrom="watchlist":e.dataFrom="market";const s="watchlist"===e.dataFrom?a:this.moneyInfoCardWCConfig.apiConfig.marketQuoteIds;this.financeService.cleanCache();const o=await this.financeService.getRecommendation(),i=[s,o||this.moneyInfoCardWCConfig.apiConfig.recommendedQuoteIds],n=[].concat(...i),l=await this.financeService.getQuoteSummary(n),d={};l.forEach(t=>{t?.id&&(d[t.id]=t)});const c=i.map(t=>t.map(t=>d[t]).filter(t=>t)),[p,h]=c;e.data={recommend:{quoteItems:h,quoteIds:h.map(t=>t.id)},[e.dataFrom]:{quoteItems:p,quoteIds:p.map(t=>t.id)}},e.data.watchlist||(e.data.watchlist={quoteItems:[],quoteIds:[]}),e.dataTimestamp=(new Date).getTime();const u=[...this.moneyInfoCardWCConfig.defaultTabs];"watchlist"!==e.dataFrom&&u.splice(u.indexOf("watchlist"),1);const g={userSignedIn:e.userSignedIn,dataFrom:e.dataFrom,fullWatchlistQuoteIds:"watchlist"===e.dataFrom?s:[],recommendQuoteItems:h,tabListDetails:e.data,notifications:null,tabs:u};this.moneyInfoCardWCData=JSON.stringify(g),this.updateStripes(t)}catch(t){Mr.YT.sendAppErrorEvent({...ct.B0w,message:"MoneyInfoCard content fetch failed",pb:{...ct.B0w.pb,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}}getDisplayedColumnLayout(){const t=this.columnArrangement;if(!this.enableRail||!t)return t;const e=parseInt(t.replace("C",""),10);return Number.isNaN(e)?t:"C"+(e-1)}updateStripes(t){this.updateRiverSections(t),this.config.stripeStyles&&this.processLayoutStyles(),Aa&&t&&(0,xt.CI)(Ta(t))}updateRiverSections(t){this.riverSectionLayoutData=this.riverSectionLayoutData.map((e,r)=>{if(!e)return;const{templateId:a,sectionId:s}=e;let o=Me[a];if(void 0!==t&&t!==s)return e;let i=(0,Nr.A)(this.config.slotToCardType?.[s]||[])||[],n=e.cardMetadataList;const{backfillCardTypeSlot:l,backfillMetadata:d,backfillTemplateId:c}=Sa(s,n,this.config.childExperienceReferencesWC?.[s]?.backfillConfigs);if(n=d||n,i=l||i,o=c?Me[c]:o,e.hasPlaceHolderAds||t===s){const a=this.nativeAdPlacementsMap[s];if(a&&e?.cardMetadataList?.length===a.length){let t=!1;if(a.forEach(e=>t=t||this.hasAdsContent(e)),!t)return void(0,dt.vV)(ct.Koy,"No ads content for entire stripe",`sectionId: ${s}, adsConfig: ${this.config.adPlacements?.[s]}, cmsConfig: adsConfig: ${this.config.adPlacements?.[s]}`)}const l=a?.filter(t=>t.region===Rt.pL.Infopane),d=a?.filter(t=>t.region!==Rt.pL.Infopane),c=n.map((r,a)=>{if(r.type===Rt.pL.Infopane){if(!this.ttvrFired||!this.nativeAdIsLoaded[t])return r;if(r.subItems=this.infopaneSubItems.slice(),l?.length){const t=l.sort((t,e)=>t.regionIndex>e.regionIndex?1:t.regionIndex<e.regionIndex?-1:0),e=[];t.forEach(t=>{const a=t.regionIndex-1;!e.includes(a)&&r.subItems[a]&&this.hasAdsContent(t)&&(e.push(a),r.subItems.splice(a,0,this.createNativeAdCardMetadata(t)))})}if(this.shouldOverrideInfopaneCards&&this.ttvrFired&&"topStripe"==t)for(let t=0;t<r?.subItems?.length;t++){const e=r.subItems[t];if(e?.id&&this.replacementInfopaneCards[e.id]){const a=this.replacementInfopaneCards[e.id];r.subItems[t]=a.card,a.tmplStringPrefix&&Mr.YT.addOrUpdateTmplString(`${a.tmplStringPrefix}-${e.cardContent.id}`)}}return r}{let t,s=0;for(let t=0;t<a;t++)e.cardMetadataList[t].type===Ma&&e.cardMetadataList[t].subItems?.length?s+=e.cardMetadataList[t].subItems.length-1:s++;return r.cardContent?.insertedCardType===Ct.denseCard?d?.forEach(t=>{if(this.hasAdsContent(t)&&t.regionIndex>s){const e=t.regionIndex-s,a=r.subItems?.[e];a&&a.type!==Rt.pL.NativeAd&&(r.subItems[e]=this.createNativeAdCardMetadata(t))}}):t=d?.find(t=>t.regionIndex===s+1),t&&this.hasAdsContent(t)?this.createNativeAdCardMetadata(t):r}});return{...e,feedData:this.mapFeedData(s,c,o,this.config.openLinksInNewTab,this.telemetryObject,i,r),hasPlaceHolderAds:!1,cardMetadataList:(0,Nr.A)(c)}}return{...e,feedData:this.mapFeedData(s,e.cardMetadataList,o,this.config.openLinksInNewTab,this.telemetryObject,i,r)}})}updateAdPlacementData(t,e){const r=this.nativeAdPlacementsMap[t];r?.length&&e?.length&&r.forEach((t,a)=>{const s=e.filter(e=>e.region===t.region&&e.regionIndex===t.regionIndex)[0];s?.items?.length&&(r[a]=s)}),this.updateStripes(t)}async fetchNativeAdsContent(t,e){let r=this.getAdRequestForRiver(t,e);const a=Pr.Rb.Locale,s=Gr[a]||lt.F3[a];if(!r)return;a&&(r.locale=a);const o=[];try{await this.initNativeAdService(),r.placements?.length&&(r=(0,Nr.A)(r),r.placements.forEach(t=>{this.nativeAdIndiceRegionFilters.length&&!this.nativeAdIndiceRegionFilters.includes(t.region.toLowerCase())&&(t.indices=t.indices.map((t,e)=>e+1))})),$t.M.startMark(Ra);const a=e?await this.nativeAdService.fetchCmsAds(r,s,[]):await this.nativeAdService.fetchNativeAds(r),{placements:i,adLabelText:n,isGreyAdsLabelEnabled:l}=a;i?.length&&i.forEach(r=>{if(t!==this.riverSectionIds[0]&&!this.nativeAdIndiceRegionFilters.includes(r.region.toLowerCase())){(e?this.config.cmsAdPlacements?.[t]:this.config.adPlacements?.[t]).placements.forEach(t=>{t.region===r.region&&(r.regionIndex=t.indices[r.regionIndex-1])})}const a=r;a.adLabelText=n,a.isGreyAdsLabelEnabled=l,this.config.isMsnHPAdSlug&&(a.isGreyAdsLabelEnabled=!1),o.push(a)})}catch(e){this.nativeAdIsLoaded[t]=!0,(0,dt.c_)(e,ct.sHf,"Call to Ad Service failed")}finally{$t.M.endMark(Ra),this.nativeAdIsLoaded[t]=!0}return o}async initNativeAdService(){if(!this.nativeAdService){const{NativeAdService:t}=await r.e("libs_ad-service_dist_index_js").then(r.bind(r,73487));this.nativeAdService=new t(void 0,this.config&&this.config.adServiceConfig)}}loadNativeAd(t,e){this.ttvrFired&&this.fetchNativeAdsContent(t,e).then(e=>{this.updateAdPlacementData(t,e)})}createStripeAdCardDefaultMetadata(t){const e=[];for(let r=1;r<=t;r++)e.push({type:Rt.pL.NativeAd,regionIndex:r,placement:{items:[]}});return e}createNativeAdCardMetadata(t){if(!t?.items?.length)return;return{type:Rt.pL.NativeAd,id:`${Rt.pL.NativeAd}-${t.regionIndex}`,placement:t}}hasAdsContent(t){return Object.keys(t?.items[0]||{}).length>0}getAdRequestForRiver(t,e){const r=e?this.config.cmsAdPlacements?.[t]:this.config.adPlacements?.[t];if(!r)return;let a;if(r?.placements){const e=[];if(r.placements.forEach(t=>{if(t.region.indexOf(Rt.pL.Infopane)>=0)e.push({...t,img:this.config.adTemplateConfig?.imageSizeConfig?.infopane});else{const r=t.indices;if(r.length){const a={...t,indices:r};e.push(a)}}}),e.length){const s=this.getDefaultAdPlaceholderPlacements(e);this.nativeAdPlacementsMap[t]?this.nativeAdPlacementsMap[t].push(...s):this.nativeAdPlacementsMap[t]=s,a={placements:e,pageType:r.pageType}}}return a}getDefaultAdPlaceholderPlacements(t){let e=[];return t&&t.forEach(t=>{const r=t.indices.map(e=>({...t,regionIndex:e,items:[{}]}));e=e.concat(r)}),e}getNavigationButonTelemetryTag(t){return(0,fa.N)(t,Tr.MS.Paginate,Tr.EG.Click,Tr.MJ.ActionButton).getMetadataTag()}startInfopaneAutoRotation(){const t=this.config.infopaneConfig||{};if(t.autoRotate&&!t.disableAutoRotate){const t=this.riverSectionIds[0],e=this.shadowRoot.querySelector?.(`#${t} cs-feed-layout`)?.shadowRoot,r=e?.querySelector("cs-responsive-infopane");r&&window.setTimeout(()=>{r.hasSlideShow=!0,this.overrideHasSlideShow=!0},1e3)}}has1SFlight(t){const e=pt.T3.CurrentRequestTargetScope&&pt.T3.CurrentRequestTargetScope.pageExperiments;if(e){const t="1s-viewurldomain";return e.includes(t)}return!1}handleContentOverlap(t,e){const r=t.target.getBoundingClientRect();r.top<160&&window.scrollBy(0,r.top-160)}overrideInfopaneSlideCardToElectionCard(t){t.cardMetadata={id:"electionCard",cardContent:{abstract:"US Elections: Latest news, results and more",destinationUrl:"https://www.msn.com/en-us/channel/topic/US%20Elections/tp-Y_cc072da4-ecb2-413a-9ffe-5ec5ad54ca41",id:"electionCard",images:[{id:"USElectionCard",caption:"US Elections: Latest news, results and more",url:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sKqsZ.img"}],type:"ArticlePreview",title:"US Elections: Latest news, results and more"},metadata:{},type:"article"}}}(0,g.Cg)([f.sH],Ia.prototype,"columnArrangement",void 0),(0,g.Cg)([f.sH],Ia.prototype,"isShowDot",void 0),(0,g.Cg)([f.sH],Ia.prototype,"isFetchingStripes",void 0),(0,g.Cg)([f.sH],Ia.prototype,"requestContext",void 0),(0,g.Cg)([f.sH],Ia.prototype,"riverSectionLayoutData",void 0),(0,g.Cg)([f.sH],Ia.prototype,"ttvrFired",void 0),(0,g.Cg)([f.sH],Ia.prototype,"cardActionRef",void 0),(0,g.Cg)([f.sH],Ia.prototype,"isFeedExhausted",void 0),(0,g.Cg)([f.sH],Ia.prototype,"onFeedEndCb",void 0),(0,g.Cg)([f.sH],Ia.prototype,"enableRail",void 0);var Oa=r(66591),Ba=r(36478),Ua=r(72691),za=r(31157),Fa=r(36042);const Na=R.A` .container{left:3px}`,La=R.A` .container{right:3px}`,Ea=R.A`
.arrow-container-rail{display:none}${(0,pe.H5)(pe.j1.c3)}{.arrow-container.arrow-container-rail{width:697px}}${(0,pe.H5)(pe.j1.c4)}{.arrow-container.arrow-container-rail{width:1019px}}${(0,pe.H5)(pe.j1.c5)}{.arrow-container.arrow-container-rail{width:1341px}}`,qa=R.A`
:host{--viewport-width:auto;--viewport-height:auto;--element-gap:16px;height:var(--viewport-height);width:var(--viewport-width);position:relative;display:flex}.arrow-container{position:absolute;display:flex;justify-content:space-between;align-items:flex-end;align-self:end;pointer-events:none;z-index:0;right:20px;bottom:4px}${(0,pe.H5)(pe.j1.c2)}{.arrow-container{width:697px}}${(0,pe.H5)(pe.j1.c3)}{.arrow-container{width:1019px}}${(0,pe.H5)(pe.j1.c4)}{.arrow-container{width:1341px}}.viewport{height:303px;overflow-x:hidden;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.viewport-weather{height:303px;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.disable-overflow-hidden{overflow:visible;height:var(--viewport-height)}.page-indicator{font-size:var(--page-number-font-size,12px);color:var(--page-number-color);line-height:16px;pointer-events:all}.page-indicator span{background:#c2c2c2;border-radius:50%;height:6px;width:6px;display:inline-block;margin:0 4px;cursor:pointer}.page-indicator span.active{background:#333;cursor:default}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content;height:100%;left:3px;position:relative}.slider-arrow{pointer-events:all;z-index:2;outline:none;background:var(--flipper-background,transparent);width:var(--flipper-width,20px);height:var(--flipper-height,20px);display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;border:none;margin-bottom:162px;width:28px}.slider-arrow.hide{pointer-events:none;visibility:hidden}.slider-arrow svg{width:var(--flipper-icon-width);color:var(--flipper-icon-color,buttonText);fill:#9b9b9b}${Ea}
`.withBehaviors(new W.t(Na,La)),Ha=$.qy`<svg width="24" height="24" viewBox="0 0 5 8" style="transform: scale(-1, 1);" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,Wa=$.qy`<svg width="24" height="24" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,ja=$.qy` ${(0,S.ux)(t=>t.pageIndicatorData,$.qy`<span class="${t=>t.active?"active":""}" id=${t=>t.pageIndex} @click=${(t,e)=>e.parent.handlePageIndicatorClick(e.event)} data-t="${(t,e)=>e.parent.pageIndicatorTelemetryTag}"></span>`)}
`,Ja=$.qy`<div ${(0,k.K)("viewport")} class="${t=>"weather"==t.sectionId?"viewport-weather":"viewport"}" part="viewport" direction="${t=>t.direction?t.direction:"ltr"}"><div class="container" part="container" ${(0,k.K)("container")}><slot ${(0,k.K)("viewportSlot")} @slotchange=${t=>t.setCurrentSlotWidth()}></slot></div></div><div class="${t=>(0,Oa.x)("arrow-container",["arrow-container-rail",t.isRailEnabled])}" part="arrow-container"><slot ${(0,k.K)("previousArrow")} name="previous-arrow"><button class="slider-arrow previous-arrow" @mousedown="${(t,e)=>e.event&&t.mouseDownHandler(e.event)}" @click="${t=>t.slideKeyPressHandler(-1)}" aria-label="${t=>t.leftArrow}" data-t="${t=>t.previousArrowTelemetryTag}" hidden tabindex="-1">${(0,P.z)(t=>t.renderSlider&&"ltr"===t.direction,Ha)} ${(0,P.z)(t=>t.renderSlider&&"rtl"===t.direction,Wa)}</button></slot><div class="page-indicator">${(0,P.z)(t=>t.renderSlider,ja)}</div><slot ${(0,k.K)("nextArrow")} name="next-arrow"><button class="slider-arrow next-arrow" @mousedown="${(t,e)=>e.event&&t.mouseDownHandler(e.event)}" @click="${t=>t.slideKeyPressHandler(1)}" aria-label="${t=>t.rightArrow}" data-t="${t=>t.nextArrowTelemetryTag}" hidden tabindex="-1">${(0,P.z)(t=>t.renderSlider&&"ltr"===t.direction,Wa)} ${(0,P.z)(t=>t.renderSlider&&"rtl"===t.direction,Ha)}</button></slot></div>`;let Ga=class extends b.L{columnArrangementChanged(t,e){t&&this.container&&this.handleBreakpointChange()}constructor(){super(),this.direction=za.O.ltr,this.nextArrowTelemetryTag="",this.previousArrowTelemetryTag="",this.pageIndicatorTelemetryTag="",this.columnArrangement="C4",this.currentPageIndex=1,this.totalNumPages=1,this.pageIndicatorData=[],this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.handleBreakpointChange=()=>{this.setSliderStates(),this.refreshSliderControls(this.viewport.scrollLeft)},this.handleBreakpointChange=(0,Fa.A)(this.handleBreakpointChange,200)}connectedCallback(){super.connectedCallback(),this.direction=Ua.o.getValueFor(this),this.setSliderStates(),this.refreshSliderControls(0)}setCurrentSlotWidth(){const t=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=t?Number(t.replace(/px/,"")):0;this.viewportSlot.assignedElements().length>0&&("C4"===this.columnArrangement&&this.isC5Enabled?this.currentSlotElementWidth=1273:"C3"===this.columnArrangement?this.currentSlotElementWidth=951:"C2"===this.columnArrangement?this.currentSlotElementWidth=629:this.currentSlotElementWidth=0)}slideKeyPressHandler(t){if(this.disableSliderInColumnArrangement())return;const e=this.viewport.clientWidth,r=this.container.clientWidth;if(e<=0||r<=0)return;const a="rtl"!==this.direction,s=this.viewport.scrollLeft;if(a||(t*=-1),!a&&t>0&&0===s)return;if(a&&t<0&&0===s)return;const o=t*this.getScrollDistance();if(s+o>r)return;this.currentPageIndex=Math.floor(Math.abs(s+o)/e)+1,this.currentPageIndex<=0&&(this.currentPageIndex=1),this.onSlideIndexChange?.(this.currentPageIndex-1);const i=s+o;window.requestAnimationFrame(()=>{this.viewport.scrollTo(i,0),this.refreshSliderControls(i)})}mouseDownHandler(t){t.preventDefault(),t.stopPropagation()}setArrowVisibility(t){const e=t*("ltr"===this.direction?1:-1);e<=0?this.setArrowsHiddenVisibility(!0,!1):this.viewport.clientWidth+e>this.container.clientWidth?this.setArrowsHiddenVisibility(!1,!0):this.setArrowsHiddenVisibility(!1,!1)}hideNextArrow(t){t?this.nextArrow.children[0].classList.add("hide"):this.nextArrow.children[0].classList.remove("hide")}hidePreviousArrow(t){t?this.previousArrow.children[0].classList.add("hide"):this.previousArrow.children[0].classList.remove("hide")}setArrowsHiddenVisibility(t,e){this.hidePreviousArrow(t),this.hideNextArrow(e)}getScrollDistance(){return this.currentSlotElementWidth+this.currentContentGapSize}refreshSliderControls(t){this.setPageIndicator(),this.setArrowVisibility(t)}setSliderStates(){this.calculateTotalNumPages(),this.setCurrentSlotWidth(),this.setSliderVisibility()}calculateTotalNumPages(){return"C4"===this.columnArrangement&&this.isC5Enabled||["C2","C3"].includes(this.columnArrangement)?this.totalNumPages=2:this.totalNumPages=0}setSliderVisibility(){this.renderSlider=!(this.disableSlider||"C5"===this.columnArrangement||"C4"===this.columnArrangement&&!this.isC5Enabled||["topStripe","buydirect","shopping"].includes(this.sectionId)),"topStripe"!==this.sectionId&&this.disableSliderInColumnArrangement?this.viewport.classList.remove("disable-overflow-hidden"):this.viewport.classList.add("disable-overflow-hidden")}disableSliderInColumnArrangement(){const t=["C2","C3"];return this.isC5Enabled&&t.push("C4"),this.disableSlider||!t.includes(this.columnArrangement)}setPageIndicator(){this.pageIndicatorData=[];for(let t=1;t<=this.totalNumPages;t++){const e={active:this.currentPageIndex===t,pageIndex:t};this.pageIndicatorData.push(e)}}handlePageIndicatorClick(t){if(this.disableSliderInColumnArrangement())return;const e="ltr"===this.direction?1:-1,r=Number(t?.target.id),a=(r-1)*this.getScrollDistance();this.currentPageIndex=r,window.requestAnimationFrame(()=>{this.viewport.scrollTo(a*e,0),this.refreshSliderControls(a)})}};(0,g.Cg)([f.sH],Ga.prototype,"direction",void 0),(0,g.Cg)([f.sH],Ga.prototype,"nextArrowTelemetryTag",void 0),(0,g.Cg)([f.sH],Ga.prototype,"previousArrowTelemetryTag",void 0),(0,g.Cg)([f.sH],Ga.prototype,"pageIndicatorTelemetryTag",void 0),(0,g.Cg)([f.sH],Ga.prototype,"columnArrangement",void 0),(0,g.Cg)([f.sH],Ga.prototype,"currentPageIndex",void 0),(0,g.Cg)([f.sH],Ga.prototype,"totalNumPages",void 0),(0,g.Cg)([f.sH],Ga.prototype,"sectionId",void 0),(0,g.Cg)([f.sH],Ga.prototype,"disableSlider",void 0),(0,g.Cg)([f.sH],Ga.prototype,"isC5Enabled",void 0),(0,g.Cg)([f.sH],Ga.prototype,"leftArrow",void 0),(0,g.Cg)([f.sH],Ga.prototype,"rightArrow",void 0),(0,g.Cg)([f.sH],Ga.prototype,"renderSlider",void 0),(0,g.Cg)([f.sH],Ga.prototype,"pageIndicatorData",void 0),(0,g.Cg)([f.sH],Ga.prototype,"isRailEnabled",void 0),Ga=(0,g.Cg)([(0,b.E)({name:"stripe-slider",template:Ja,styles:qa,shadowOptions:{delegatesFocus:!0}})],Ga);const Va=$.qy` ${(t,e)=>(0,pr.yN)(t.pivotsNav,{properties:{parentTelemetry:e.parent.telemetryObject}})}
`,Xa=$.qy`<div class="river-section-header-group" style="${t=>t.riverSectionTitleColor&&!t.disableStripeTheme?`border-color: ${t.riverSectionTitleColor};`:""} ${t=>t.seeMoreText?"border-width: 1px;":""}"><div class="stripe-title"><h2>${(0,P.z)(t=>t.adLabel,$.qy`<msn-native-ad-ad-label type="${t=>t.adSlugGA?"defaultLabel":"greenLabel"}" ad-label-text=${t=>t.adLabel} ad-label-text-opacity="${t=>t.adSlugGA?"0.81":"0.7"}" should-adjust-gap is-msn-hp-ad-slug=${t=>t.isMsnHPAdSlug} enable-safe-ads=${t=>t.enableSafeAds}></msn-native-ad-ad-label>`)}<a href="${t=>t.riverSectionTitleUrl}" target="${(t,e)=>e.parent.config.openLinksInNewTab?"_blank":"_self"}" style="${t=>t.riverSectionTitleColor&&!t.disableStripeTheme?`color: ${t.riverSectionTitleColor}`:""};${t=>t.riverSectionTitleUrl?"":"text-decoration: none;"}" data-t="${(t,e)=>e.parent.stripeWCTelemetry.getTelemetryTag(ya.title)}" title="${t=>t.seeMoreText}" aria-label="${t=>t.seeMoreText}">${t=>t.riverSectionTitle} ${(0,P.z)(t=>t.riverSectionTitleUrl||t.adLabel,$.qy`<span class="title-arrow">${$.qy.partial(Ba.A)}</span>`)}</a></h2></div><div class="sub-nav">${(0,P.z)(t=>t.pivotsNav,Va)}</div></div>`,Ka=$.qy`<div class="feed-section">${(0,S.ux)(t=>t.riverSectionLayoutData.filter(t=>null!=t),$.qy` ${(0,P.z)(t=>t.insertBannerAd,$.qy`<div class="in-stripe-banner-ad" id="${(t,e)=>t.sectionId}"><display-ads config-instance-src="default" instance-id="banner2"></display-ads></div>`)} ${(0,P.z)(t=>!t.insertBannerAd,$.qy`<div class="river-section" data-t="${(t,e)=>e.parent.stripeWCTelemetry.getSectionTelemetryTag(t.sectionId,t.telemetryName)}" id="${(t,e)=>t.sectionId}" @focusin="${(t,e)=>e.parent.handleContentOverlap(e.event,t.sectionId)}">${(0,P.z)(t=>t.riverSectionTitle,Xa)}<stripe-slider class="${(t,e)=>(0,Oa.x)("stripe-slider-container",["stripe-slider-container-rail",e.parent.enableRail],["more-space","topStripe"===t.sectionId||e.parent.isShowDot])}" part="stripe-slider-container" :isRailEnabled=${(t,e)=>e.parent.enableRail} :previousArrowTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("leftarrow")} :nextArrowTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("rightarrow")} :pageIndicatorTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("pageIndicator")} :leftArrow=${t=>t.leftArrow||{}} :rightArrow=${t=>t.rightArrow||{}} :columnArrangement=${(t,e)=>e.parent.getDisplayedColumnLayout()} :disableSlider=${t=>t.disableSlider} :isC5Enabled=${t=>t.isC5Enabled} :sectionId=${t=>t.sectionId}><cs-feed-layout class="stripe-river-section" data-section=${t=>t.sectionId} layout=${(t,e)=>e.parent.getDisplayedColumnLayout()} :data=${t=>t.feedData} :childTemplateMap=${t=>xr} :layoutStyles=${t=>(t=>{const e=Me[t].styles,r=ua+ha;return t.indexOf("top-stripe-view")>=0?R.A`${e}${r}${pa}`:R.A`${e}${r}`})(t.templateId)} data-t="${(t,e)=>"topStripe"===t.sectionId?e.parent.stripeWCTelemetry.getTelemetryTag(ya.todayHeadlines):null}"></cs-feed-layout></stripe-slider></div>`)} `)}<div ${(0,k.K)("paginationSentinelRef")} style=${t=>t.sentinelHeight} class="pagination-sentinel"></div></div>`,Qa=$.qy` ${t=>t.config.childExperienceReferences?.cardAction&&(0,pr.yN)(t.config.childExperienceReferences.cardAction)}
`,Za=$.qy`<fluent-design-system-provider id="sf-design-system" style="background: transparent" fill=""><div class="stripe-feed" style="${t=>t.config.noPaddingEnd&&t.isFeedExhausted?"padding-bottom: 4px":null}">${(0,P.z)(t=>t.riverSectionLayoutData,Ka)} ${(0,P.z)(t=>t.isFetchingStripes&&t.ttvrFired,$.qy`<div class="progress-ring-wrapper"><fluent-progress-ring></fluent-progress-ring></div>`)}</div>${(0,P.z)(t=>t.ttvrFired,Qa)}</fluent-design-system-provider>`;a.m.define(s.c.registry),o.m.define(s.c.registry),i.m.define(s.c.registry),et.m.define(n.G.registry),l.Ob.define(d.i.registry),c.Id.define(d.i.registry),p.Af.define(d.i.registry),h.yr.define(d.i.registry),u.rX.define(d.i.registry),X.define(d.i.registry),tt.Bb.define(d.i.registry),rt.L.define(d.u.registry);const Ya={experienceConfigSchema:void 0}},18755(t,e,r){r.d(e,{K(){return i},O(){return n}});var a=r(89757),s=r(94172),o=r(73559);const i=a.qy`
    ${t=>t.configInfo&&(0,s.yN)(t.configInfo,{properties:{mapperArgs:t.mapperArgs,parentTelemetry:t.telemetryObject,feedLayoutCardSize:t.cardSize},attributes:{style:`grid-area:${t.gridArea}`,class:`${t.cardSize}`},telemetryObject:t.telemetryObject})}
`,n={getFeedDataForCard(t){return(0,o.BQ)(t)},viewTemplate:i}},7961(t,e,r){r.d(e,{T(){return h}});var a=r(11803),s=r(44776),o=r(46659),i=r(21386),n=r(89757),l=r(69259),d=r(33744),c=r(2375);const p=n.qy`      
    <msft-attribution slot="attribution">
    ${(0,l.z)(t=>t.providerData.logoImage,n.qy`
        <img 
            slot="image" 
            src="${t=>t.providerData.logoImage}" 
            alt="${t=>t.providerData.name}" 
            @load=${t=>{t.imageData&&t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(1,a.j.provider)}} />
    `)}
    <div class="attribution_container_${t=>t.id}" id="attribution_container">
        <div class="attribution_Content_${t=>t.id}" style="${t=>"rtl"===t.dir?"right":"left"}:0px;">
            ${(0,l.z)(t=>t.providerData&&t.providerData.name,n.qy`<span style="unicode-bidi: embed;">${t=>t.providerData.name}</span>`)}
            ${(0,l.z)(t=>t.providerData&&t.providerData.name&&t.publishedDateTime,n.qy` · `)}
            ${(0,l.z)(t=>t.publishedDateTime,n.qy`<span style="unicode-bidi: embed;">${t=>t.publishedDateTime}</span>`)}
            ${(0,l.z)(t=>t.isWebContent&&t.crawledContentLabel,n.qy` · `)}
            ${(0,l.z)(t=>t.isWebContent&&t.crawledContentLabel,n.qy`${t=>t.crawledContentLabel}`)}
        </div>
    </div>
    </msft-attribution>

`,h=n.qy`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card.msft-content-card-preview {
            height: 100px;
        }
        msft-content-card.msft-content-card-preview::part(body) {
            height: 100%;
        }
        msft-content-card.msft-content-card-preview .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card.msft-content-card-preview fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.msft-content-card-preview::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.msft-content-card-preview msft-attribution {
            position: relative;
            overflow: hidden;
            margin-top: 0;
            margin-bottom: 0;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl msft-attribution {
            margin-right: 5px;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            padding: 8px;
            display: flex;
            flex-flow: column-reverse;
            height: 100%;
            box-sizing: border-box;
            justify-content: space-between;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            height: 100%;
        }

        ${t=>"end"===t.imagePosition?'\n            msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: right;\n                margin-top: unset;\n                margin: 8px 8px 8px 0px;\n            }\n            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: left;\n                margin: 8px 0px 8px 8px;\n            }\n            ':'        \n            msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: left;\n                margin-top: unset;\n                margin: 8px 0 8px 8px;\n            }\n            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: right;\n                margin: 8px 8px 8px 0;\n            }\n            '}
        msft-content-card.msft-content-card-preview::part(media),
        msft-content-card.msft-content-card-preview::part(media) img {
            border-radius: unset;
        }
        msft-content-card.msft-content-card-preview::part(heading) {
            font-size: 14px;
            line-height: 20px;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper {
            display: flex;
            gap: 8px;
        }

        msft-content-card.msft-content-card-preview .attribution-wrapper .social-bar-wrapper {
            position: relative;
            z-index: 99999;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl .social-bar-wrapper::before {
            left: unset;
            right: 0px;
            transform: translateX(100%);
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper {
            height: 100%;
            position: absolute;
            top: 0;
            right: 0;
            width: calc(100% - 120px);
            padding: 8px 0;
            box-sizing: border-box;
            display: flex;
            flex-flow: column;
            justify-content: space-between;
            z-index: 2;
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper.image-end {
            right: unset;
            left: 0;
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-attribution-wrapper.no-image {
            width: 100%; 
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-container {
            padding-right: 8px;
            height: 60px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }
        msft-content-card.msft-content-card-preview .image-end .title-container {
            padding-right: 0;
        }
            
        msft-content-card.msft-content-card-preview .provider-top .title-container {
            height:40px;
            -webkit-line-clamp: 2;
            padding-top: 4px;
        }  

        msft-content-card.msft-content-card-preview .title-container:hover {
            text-decoration: underline;
        }
        msft-content-card.msft-content-card-preview .title-container:focus {
            outline: none;
            text-decoration: underline;
        }
        /* 
         *  Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position: absolute;
            transition: all 0.5s ease-out;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }

    /**
    *  To support high contrast mode for accessibility
    **/
    @media (forced-colors: active) {
        msft-content-card.msft-content-card-preview .title-container {
            color: linktext;
        }
    }
    </style>
    <fluent-card
        style="grid-area:${t=>t.gridArea}"
        class="${t=>t.cardSize} msft-content-card-preview-wrapper"
    >
        <msft-content-card
            exportparts="heading"
            id="contentcard_${t=>t.id}"
            href=${t=>t.destinationUrl}
            target=${t=>t.openLinksInNewTab?"_blank":"_self"}
            title=${t=>t.disableCardTitleTooltip?"":t.title}
            style="--heading-max-lines: 2;"
            class="msft-content-card-preview"
            data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}"
            :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
            @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
            @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
        >
            ${(0,l.z)(t=>t.imageData,n.qy`
                <img
                    slot="media"
                    src="${t=>t.imageData.source}"
                    alt="${t=>t.imageData.altText}"
                    height="${o.L._104x84.height}"
                    width="${o.L._104x84.width}"
                    @load="${t=>{t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(3,a.j.image)}}"
                />
            `)}
            ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}}
            <div class="title-attribution-wrapper ${t=>t.imageData?.source?"":"no-image"} ${t=>"end"===t.imagePosition?"image-end":""} ${t=>t.providerAboveHeader?"provider-top":""}">
                ${(0,l.z)(t=>t.providerData&&t.providerAboveHeader,p)}
                <div class="title-wrapper">
                    <div class="title-container" tabindex="0" role="link" @keypress="${(t,e)=>"Enter"==e.event.key&&e.event.target.click()}">${n.qy`${t=>t.title}`}</div>
                    ${(0,l.z)(t=>t.abstract,n.qy`
                        <p slot="abstract" style="color: var(--neutral-foreground-rest);">${t=>t.abstract}</p>
                    `)}
                </div>
                <div class="attribution-wrapper ${t=>"rtl"===t.dir?"attribution-rtl":""}">
                    ${(0,l.z)(t=>t.providerData&&!t.providerAboveHeader,p)}
                    ${(0,l.z)(t=>t.enableRichSocialReaction,t=>n.qy`
 <div class="social-bar-wrapper" style="display: flex; gap: 4px; margin-right: 5px;">
     ${(0,l.z)(t=>t.optedOutOfReactions,n.qy`
         ${s.LW}
         ${s.tB}
     `)}
     <social-bar-wc
         config-instance-src=${t=>t.socialBarWCConfigInfo&&(0,c.v)(t.socialBarWCConfigInfo)}
         instance-id=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.instanceId}
         config-shared-ns=${t=>t.socialBarWCConfigInfo?.configRef?.sharedNs}
         :contentId=${t=>t.id}
         :destinationUrl=${t=>t.destinationUrl}
         :locale=${t=>d.T3.CurrentMarket||t.locale}
         :rootTelemetryObject=${t=>t.telemetryContext&&(t.telemetryContext.contentCardTelemetryObject||t.telemetryContext.contentCard)}
         :hideComments=${()=>!0}
         :isRightPos=${t=>t.socialBarInRight}
         :socialMetadata=${t=>({...t.metadata,imageData:t.imageData,providerData:t.providerData,title:t.title})}
        theme="superappListCard"
    ></social-bar-wc>
 </div>
 `)}
                </div>
            </div>
            ${(0,l.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,i.p)}
        </msft-content-card>
    </fluent-card>
`},60640(t,e,r){r.d(e,{g(){return y}});var a=r(36880),s=r(51122),o=r(40201),i=r(62679),n=r(99381),l=r(44776),d=r(26330),c=r(21386),p=r(69828),h=r(89757),u=r(69259),g=r(44978),m=r(77833),f=r(41483);a.m,s.m;const y=h.qy`
    <style>
        :host fluent-card {
            content-visibility: auto;
        }
        ${(0,u.z)(t=>t.contentType===m.pL.Video,h.qy`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            fluent-card._1x_1y msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card span.infopane-title {
            font-size: var(--infopane-title-font-size, 28px);
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        ${t=>b(t)}

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <fluent-card
        style="grid-area:${t=>t.gridArea};"
        class="${t=>t.cardSize}"
    >
        <fluent-design-system-provider
            fill-color="#333333"
            style="display: flex; padding: 0; height: 100%;"
        >
            <msft-content-card
                id="contentcard_${t=>t.id}"
                class="${t=>(0,f.dU)(t)}"
                href=${t=>t.destinationUrl}
                target=${t=>t.openLinksInNewTab?"_blank":"_self"}
                title=${t=>t.disableCardTitleTooltip?"":t.title}
                layout="infoPane"
                style="${t=>C(t)}"
                data-t="${t=>t.telemetryContext?.contentCard?.getMetadataTag()}"
                :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
                @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
            >
            ${(0,u.z)(t=>t.contentIndicator,t=>(0,o.Z)(t.contentIndicator))}
            ${(0,u.z)(t=>!t.isAnaheimDesign,h.qy`${t=>t.title}`)}
            ${(0,u.z)(t=>t.isAnaheimDesign,h.qy`<span class="infopane-title">${t=>t.title}</span>`)}
                <img
                    slot="background-image"
                    alt="${t=>t.imageData&&t.imageData.altText}"
                    src="${t=>t.imageData&&t.imageData.source}"
                    @load="${t=>t.imageData&&t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback()}"
                />
                ${t=>(0,i.fn)(t.isProviderInFooter?"start-actions":"attribution")}
                ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled,n.K)}
                ${(0,u.z)(t=>!t.isAnaheimDesign,h.qy`
                    <div slot="start-actions" style="gap:0">
                        ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled&&!t.enableRichSocialReaction,h.qy`
                            ${l.LW}
                            ${l.tB}
                        `)}
                    </div>
                `)}
                <div slot="${t=>t.isProviderInFooter?"end-actions":"start-actions"}" style="gap:0">
                    <style>
                        .card-button:not(:hover) {
                            background: transparent;
                        }
                        msft-content-card fluent-button::part(control) {
                            padding: 0;
                        }
                    </style>
                    ${(0,u.z)(t=>t.enableRichSocialReaction,(0,l.nj)({}))}
                    ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled,h.qy`
                        ${(0,u.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,h.qy`
                            ${(0,u.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&g.J.showMore,l.LW)}
                            ${(0,u.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&g.J.showFewer,l.tB)}
                        `)}
                        ${(0,u.z)(t=>t.enableWCCardAction,d.L)}
                    `)}
                </div>
                ${(0,u.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,c.p)}
            </msft-content-card>
        </fluent-design-system-provider>
    </fluent-card>
`,C=t=>{let e="width: 100%;";return t.cardSize!==p.uE._2x_2y&&t.cardSize!==p.uE._2x_3y||(e+=" --heading-font-size: 20px; --heading-line-height: 28px;"),t.cardSize!==p.uE._1x_1y&&t.cardSize!==p.uE._1x_2y||!t.useInfopaneSlideTemplate||(e+=" --infopane-title-font-size: 20px;"),e},b=t=>{let e="";return t.cardSize!==p.uE._1x_1y&&t.cardSize!==p.uE._1x_2y||!t.useInfopaneSlideTemplate||(e+='\n            msft-content-card[layout="infoPane"]::part(footer) {\n                padding: 0 16px 4px;\n                margin-bottom: 0;\n                height: 40px;\n            }\n        '),e}},9039(t,e,r){r.d(e,{o(){return h}});var a=r(10862),s=r(46659),o=r(35667),i=r(98669),n=r(77833),l=r(98794),d=r(3006),c=r(72287),p=r(25658);const h={getFeedDataForCard(t){return function(t){const{cardSlot:e,configOptions:r,parentTelemetryObject:a,cardMetadata:h,openLinksInNewTab:u,visualReadinessCallback:g,isAnaheimDesign:m,isProviderInFooter:f,enableArticleTimestamps:y,localizedStrings:C,enableNewTimestampFormatForJAJP:b}=t;if(!h||!h.subItems||0===h.subItems.length)return(0,d.wc)();const v=h?.subItems[0]?.type===n.pL.WebContent,w=r&&r,x=h.subItems[0].cardContent,{id:$,destinationUrl:k,title:P,provider:S,type:_}=x;w&&(w.instanceId=`denseCard-${$}`);const A={id:$,destinationUrl:k,openLinksInNewTab:u,title:P,ariaLabel:(0,c.yL)(P,S,r?.localizedStrings),imagePriority:!1,providerData:(0,c.p_)(S,v),isProviderInFooter:f,imageData:(0,i.po)(h.subItems[0],s.L._240x129,g,m),publishedDateTime:y&&`${(0,i.fL)(b,new Date(x.publishedDateTime),x.locale,C)}`},D=h.subItems.slice(1),R={heroNews:A,newsList:D?.map(t=>{const e=t.type===n.pL.NativeAd||t.type===n.pL.CmsAd,l=t?.cardContent;if(!e){const d=t.type===n.pL.WebContent;return{abstract:t.cardContent.abstract,imageData:(0,i.po)(t,s.L._240x129,g,m),destinationUrl:t.cardContent.destinationUrl,title:t.cardContent.title,ariaLabel:(0,c.yL)(t.cardContent.title,t.cardContent.provider,r?.localizedStrings),providerData:(0,c.p_)(t.cardContent.provider,d),isNativeAd:e,telemetryContext:(0,o.dj)(a,t.cardContent,t.metadata,null,d),isNarrowNewsItem:r?.isNarrowNewsItem,publishedDateTime:y&&`${(0,i.fL)(b,new Date(l.publishedDateTime),l.locale,C)}`}}const d=t.placement?.items[0]||{},{beaconsJson:h,privacyUrl:u,adLabelText:f,isGreyAdsLabelEnabled:v,geminiViewabilityDataJson:w}=t.placement||{};return{...d,beaconsJson:h,privacyUrl:u,adLabelText:f,geminiViewabilityDataJson:w,isNativeAd:e,adTelemetryContext:(0,p.u)(t,a,"river",0),isNarrowNewsItem:r?.isNarrowNewsItem,isGreyAdsLabelEnabled:v}})},M={id:w?.instanceId,childTemplateType:"dense-card",telemetryObject:a,denseConfigInfo:w,denseData:R,visualReadinessCallback:g};return(0,l.bw)({id:"denseCard",experienceType:w?.configRef?.experienceType,mapperArgs:t},M,(t,e)=>{const r=e.telemetryExt;return R.newsList.forEach((t,e)=>{if(!t.isNativeAd&&t.telemetryContext?.destination&&!t.telemetryContext.destination?.contract?.ext){const a=D[e],{traceIdIndex:s}=a||{},{recoId:o,ri:i}=a?.metadata||{},n={...r,recoId:o,ri:i,traceIdIndex:s};t.telemetryContext.destination=t.telemetryContext.contentCard.addOrUpdateChild({...t.telemetryContext.destination.contract,ext:n})}}),{denseData:R}})}(t)},viewTemplate:a.e}},10862(t,e,r){r.d(e,{e(){return o}});var a=r(89757),s=r(94172);const o=a.qy`
<fluent-card
    style="grid-area:${t=>t.gridArea};contain:unset"
    class="${t=>t.cardSize}"
>
    ${t=>(0,s.yN)(t.denseConfigInfo,{properties:{denseData:t.denseData,telemetryObject:t.telemetryObject},memoize:!1,includeTelemetryTag:!1})}
</fluent-card>
`},18420(t,e,r){r.d(e,{E(){return l}});var a=r(50365),s=r(98794),o=r(94108),i=r(68866);function n(t){const{configOptions:e={},cardMetadata:r}=t,a=function(t){return!(0,o.Th)().CurrentFlightSet?.has("prg-hp-fvrf")&&t.isWaterfallFeed&&"hp"===(0,o.Th)().ClientSettings?.pagetype}(e),n=r.instanceId||(a?"rectangle1":void 0),l=a?"waterfall":"default",d=(0,i.$q)(window.location.href);let c="hp2";(0,i._f)(d)?c="hp2lock":(0,i.AO)(d)&&(c="winweb");const p={id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",type:r.type,enableSafeAds:!!e.enableSafeAds,childTemplateType:"display-ad-card",configInstanceSrc:r.configInstanceSrc||l,instanceId:n,pageTypeOverride:a?c:void 0,shimmerIdOverride:a?"rectangle1":void 0,batchCallAdCountOverride:e.displayAdBatchCountOverride,enableExtraAdSlug:!("rectangle1"!==n||!a)||void 0};return(0,s.bw)({id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",experienceType:e?.configRef?.experienceType,mapperArgs:t},p)}const l={getFeedDataForCard(t){return n(t)},viewTemplate:a.s}},50365(t,e,r){r.d(e,{s(){return a}});const a=r(89757).qy`
<div 
    id="${t=>t.id}"
    style="grid-area:${t=>t.gridArea};
    ${t=>"DisplayAdBanner"===t.type?"display: flex; justify-content: center; overflow: hidden;":""}
    ${t=>"DisplayAdBanner"===t.type&&"_1x_2y"===t.cardSize?"max-width: 300px;":""}
    ${t=>"DisplayAdBanner"===t.type&&"_2x_2y"===t.cardSize?"max-width: 612px;":""}"
    class="${t=>t.cardSize}"
> 
    <display-ads 
        config-instance-src="${t=>t.configInstanceSrc}" 
        instance-id="${t=>t.instanceId}" 
        :enableExtraAdSlug="${t=>t.enableExtraAdSlug}"
        :shimmerIdOverride="${t=>t.shimmerIdOverride}"
        :batchCallAdCountOverride="${t=>t.batchCallAdCountOverride}"
        :pageTypeOverride="${t=>t.pageTypeOverride}"
    >
    
    </display-ads>
</div>
`},71084(t,e,r){r.d(e,{f(){return n}});var a=r(245),s=r(87906),o=r(40450),i=r(98794);const n={getFeedDataForCard(t){return function(t){try{const{configOptions:e,cardMetadata:r,parentTelemetryObject:a,openLinksInNewTab:s,sdCardActionClickHandler:o,useInlineSvgIcons:n,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d}=t,c="shopping-carousel",p={id:c,childTemplateType:"shopping-carousel-card",openLinksInNewTab:s,sdCardActionClickHandler:o,refreshFeedCallback:l,goToPersonalizeSettingsCallback:d,parentTelemetryObject:a,shoppingCardMetadata:r,shoppingCarouselCardConfigInfo:e&&e,useInlineSvgIcons:n};return(0,i.bw)({id:c,experienceType:p.shoppingCarouselCardConfigInfo?.configRef?.experienceType,mapperArgs:t},p)}catch(t){(0,s.c_)(t,o.Odo,"Error in Shopping Carousel Mapper")}}(t)},viewTemplate:a.j}},245(t,e,r){r.d(e,{j(){return o}});var a=r(89757),s=r(94172);const o=a.qy`
    ${t=>(0,s.yN)(t.shoppingCarouselCardConfigInfo,{attributes:{style:`grid-area:${t.gridArea}`,class:`${t.cardSize}`,tabindex:t.customTabIndex??0},properties:{parentTelemetry:t.parentTelemetryObject,openLinksInNewTab:t.openLinksInNewTab,sdCardActionClickHandler:t.sdCardActionClickHandler,goToPersonalizeCallback:t.goToPersonalizeSettingsCallback,refreshFeedCallback:t.refreshFeedCallback,shoppingCardMetadata:t.shoppingCardMetadata,useInlineSvgIcons:t.useInlineSvgIcons,cardSize:t.cardSize}})}
`},32361(t,e,r){r.d(e,{Q(){return i}});var a=r(8097),s=r(98794),o=r(73559);const i={getFeedDataForCard(t){return function(t){const{cardMetadata:e,configOptions:r,parentTelemetryObject:a,visualReadinessCallback:i}=t;if(r&&r.useSharedTelemetry)return(0,o.BQ)(t,"trending-now-card");const n=r&&r,l={id:"trendingNowCard",childTemplateType:"trending-now-card",parentTelemetryObject:a,visualReadinessCallback:i,trendingNowCardConfigInfo:n,trendingNowCardMetadata:e};return(0,s.bw)({id:"trendingNowCard",experienceType:n?.configRef?.experienceType,mapperArgs:t},l,null,!0)}(t)},viewTemplate:a.A}},8097(t,e,r){r.d(e,{A(){return s}});var a=r(2375);const s=r(89757).qy`
<fluent-card
    style="grid-area:${t=>t.gridArea};"
    class="${t=>t.cardSize}"
>
    <trending-now-card
        config-instance-src=${t=>t.trendingNowCardConfigInfo&&(0,a.v)(t.trendingNowCardConfigInfo)}
        config-shared-ns=${t=>t.trendingNowCardConfigInfo&&t.trendingNowCardConfigInfo.configRef&&t.trendingNowCardConfigInfo.configRef.sharedNs}
        instance-id=${t=>t.trendingNowCardConfigInfo&&t.trendingNowCardConfigInfo.instanceId}
        :feedLayoutCardSize=${t=>t.cardSize}
        :parentTelemetry=${t=>t.parentTelemetryObject}
        :trendingNowCardMetadata=${t=>t.trendingNowCardMetadata}
        :visualReadinessCallback="${t=>t.visualReadinessCallback}"
    >
    </trending-now-card>
</fluent-card>
`},36597(t,e,r){r.d(e,{g8(){return i},gq(){return l},wg(){return s}});var a=r(83593);function s(t,e=""){const r=new URLSearchParams(window.location.search).get(t);return r&&""!==r?String(r):e}r(68866);const o=(new a.bb).data;function i(t,e,r){if(t&&t.length>0){let s=(0,a.KP)(o.devicePixelRatio,"devicePixelRatio");s=s&&s>0?s:1;const i=r*s;let n=1;if(i<100?n=1.5:i<350&&(n=1.2),t.startsWith("https://www.bing.com/th?id=")||t.startsWith("https://bing.com/th?id=")||t.startsWith("https://th.bing.com/th?id=")){const a=new URLSearchParams(t.substring(t.indexOf("?")+1)).get("id");t=`${t=t.substring(0,t.indexOf("?"))}?id=${a}&${e}=${Math.floor(r*s*n)}&p=0`}else if(t.startsWith("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/")){t.includes("?")&&(t=t.substring(0,t.indexOf("?")));const a=Math.floor(r*s*n);t=`${t}?${e}=${Math.floor(a)}`}}return t}const n="ABT748875623C1C490A64E339BEF5741D0A4D98E2E4B21323BED0D12971212C1C24";function l(t,e,r,a){return t&&""!==t||(t=n),t.startsWith("https://www.bing.com/th?id=")||t.startsWith("https://bing.com/th?id=")||t.startsWith("https://th.bing.com/th?id=")?`${t}${e?"&w="+e:""}${r?"&h="+r:""}${a}`:`https://www.bing.com/th?id=${t}${e?"&w="+e:""}${r?"&h="+r:""}${a||""}`}},94818(t,e,r){r.d(e,{J(){return v}});var a,s,o=r(33744),i=r(42826),n=r(53128),l=r(96882);(s=a||(a={}))[s.ntp=0]="ntp",s[s.dhp=1]="dhp";const d="v1";var c,p,h=r(87906),u=r(40450),g=r(96500);(p=c||(c={})).MIT="MIT",p.Topic="Topic",p.Category="category";var m=r(7446),f=r(68018),y=r(12776),C=r(52306);const b="XGP6bGECtXattHPaMTSEtXAJpanIfDLqAumdUN8Bpi";class v{constructor(t,e,r,a,s){this.fetchImpl=t,this.ocid="Peregrine",this.serviceClientSettings=e,this.APISettings=r,this.formCodes=a,this.generateServiceClientSettings(s)}generateServiceClientSettings(t){const e=(0,o.rA)(),r=((0,f.ab)(),i._3.getQueryParameterByName("userid",t)),a=i._3.getQueryParameterByName("testhooks",t),{enableLocalization:s,addFlightParam:n,queryParamsToForward:l}=this.APISettings;if(this.ocid="Peregrine",this.serviceClientSettings.queryParams){if(this.queryParamsMap=new Map(Object.entries(this.serviceClientSettings.queryParams)),this.queryParamsMap.set("apikey",this.serviceClientSettings.queryParams.apiKey||e.OneServiceApiKey),this.queryParamsMap.set(e.OneServiceContentMarketQspKey,e.CurrentMarket),this.queryParamsMap.set("ocid",this.ocid),this.queryParamsMap.set("trackingid",e.ActivityId),this.queryParamsMap.set("testhooks",a),"1"===a&&r&&this.queryParamsMap.set("userid",r),s&&e.Latitude&&e.Longitude&&(this.queryParamsMap.set("lat",e.Latitude),this.queryParamsMap.set("long",e.Longitude)),e.ShouldUseFdheadQsp){const t=n&&e.CurrentRequestTargetScope&&e.CurrentRequestTargetScope.pageExperiments,r=t&&t.join(",");this.queryParamsMap.set("fltids",r)}if(l){const e=new Set(l),r=new URL(t);if(r&&r.search){new URLSearchParams(r.search).forEach((t,r)=>{e.has(r)&&this.queryParamsMap.set(r,t)})}}}this.serviceClientSettings.pathComponents?this.pathComponentsMap=new Map(Object.entries(this.serviceClientSettings.pathComponents)):this.pathComponentsMap=new Map,this.pathComponentsMap.set(e.OneServiceContentMarketQspKey,e.CurrentMarket),this.pathComponentsMap.set("version",d)}async getShoppingEntitiesData(t=null){let e=null;return await this.getShoppingEntitiesDataJson(t).then(t=>{e=this.TryGetShoppingEntitiesData(t)}).catch(t=>{(0,h.c_)(t,u.xkP,"Failed to fetch Shopping entities response")}),e}async getShoppingEntitiesDataJson(t=null){const e={method:"GET",headers:{accept:"application/json"}};let{pathComponents:r,queryParams:a,serviceBaseUrl:s,servicePath:o}=this.serviceClientSettings;const n=[];if(a)for(const t of this.queryParamsMap.entries())n.push({key:t[0],value:t[1]});if(r)for(const t of this.pathComponentsMap.entries())o=o.replace(`{${t[0]}}`,t[1]);const l=new URL(o,s);if(l.search=i._3.keyValueArrayToQueryString(n),this.serviceClientSettings.additionalUrlAugmentations&&(l.search=l.search.concat(this.serviceClientSettings.additionalUrlAugmentations)),!t||!t.data){const t=await this.fetchImpl(l.href,e);return t.ok?t.json():(m.YT.sendAppErrorEvent({...u.xkP,message:"Shopping carousel response not ok.",pb:{...u.xkP.pb,customMessage:`Shopping carousel response not ok. Status: ${t.status}, StatusText: ${t.statusText}`}}),null)}try{const e=JSON.parse(t.data);return g.v.log("shoppingEntitiesData provided by parent in serviceContextMetadata"),e}catch(t){return(0,h.c_)(t,u.ECJ,"Error in getShoppingEntitiesDataJson, unable to parse serviceContextMetadata"),null}}convertBlackJackDealsDataToShoppingEntitiesData(t){const e=t.shoppingEntities.map(t=>({...t,communityInfo:this.ensureSocialBarDataForBlackjackDealsCommunityInfo(t.communityInfo,t.title,t.id),viewsCount:t.productInsightsData.uxInsightDecoration.find(t=>t.startsWith("ViewCountInsight"))?.match(/--(.+)/)?.[1]})).filter(t=>0!==Object.keys(t).length);return e.length>0?{shoppingEntities:e}:null}ensureSocialBarDataForBlackjackDealsCommunityInfo(t,e,r){const{itemId:a,itemUrl:s}=t??{};if(a&&s)return t;const o=C.E.buildAbsoluteUrl(e,void 0,r),i={itemId:o,itemUrl:o};return t?{...t,...i}:i}TryGetShoppingEntitiesData(t){const{enablemsnsdcardcms:e}=this.APISettings;if(!t)return m.YT.sendAppErrorEvent({...u.Fjq,message:"Received empty ShoppingEntitiesData response.",pb:{...u.Fjq.pb,customMessage:JSON.stringify(t)}}),null;if(t.prongCards&&t.prongCards.length>0)return this.GetProngCardItems(t);if(t.productCards&&t.productCards.length>0)return t;if(t.shopping&&t.shopping.length>0)return JSON.parse(t.shopping[0].data);if(t.length>0&&"ShoppingCard"==t[0]?.type)return JSON.parse(t[0].data);if(t.length>0&&"ShoppingCarousel"==t[0]?.type){const e=JSON.parse(t[0].data);if(e.topics&&e.topics.some(t=>"Blackjack"===t.title&&t.shoppingEntities?.length>0))return this.convertBlackJackDealsDataToShoppingEntitiesData(e.topics.find(t=>"Blackjack"===t.title))}let r,a=[];if("ShoppingBuyDirectCard"==t[0]?.type?(r=t[0].type,a=JSON.parse(t[0].data),a.forEach(t=>{t&&t.imageInfo&&""==t.imageInfo.sourceImageUrl&&t.imageInfo.images&&(t.imageInfo.sourceImageUrl=t.imageInfo.images[0].url)})):"ShoppingFeedResponse"==t[0]?.type&&e?(r=t[0].type,a=JSON.parse(t[0].data)?.categories,a.forEach(t=>{t&&t.backgroundImage&&null==t.imageInfo&&(t.imageInfo=t.backgroundImage,t.clickUrl=t.backgroundImage.clickUrl)})):a="ShoppingFeedResponse"==t[0]?.type?JSON.parse(t[0].data)?.trendingProducts:t.shoppingEntities,!a||0==a.length)return m.YT.sendAppErrorEvent({...u.dMO,message:"Missing required fields in ShoppingEntitiesData response.",pb:{...u.dMO.pb,customMessage:JSON.stringify(t)}}),null;const{enbaleFirstCarouselItems:s,enbaleSecondCarouselItems:o,minCarouselItems:i,maxCarouselItems:n,randomizeCarouselItems:l}=this.APISettings;if(l&&(a=a.sort(()=>.5-Math.random())),a.length<i)return m.YT.sendAppErrorEvent({...u.c7V,message:"Insufficient shoppingEntities items in shoppingEntitiesData response.",pb:{...u.c7V.pb,customMessage:`MinimumRequired=${i}, shoppingEntitiesCount=${a.length}`}}),null;a.length>n&&(a=a.slice(0,n)),a.length>1&&s&&(a=a.slice(0,Math.ceil(a.length/2))),a.length>1&&o&&(a=a.slice(Math.ceil(a.length/2)));const d=this.GetFormCode("shoppingEntities");return a.forEach(t=>{t&&t.clickUrl&&(t.clickUrl=`${t.clickUrl}&FORM=${d}`)}),t.shoppingEntities=a,t.type=r,t}GetFormCode(t){const e=n.U0.isDhpPage()?a.dhp:a.ntp;return this.formCodes&&this.formCodes[t]&&this.formCodes[t][a[e]]}GetProngCardItems(t){if(!this.serviceClientSettings.usingPreviewTable&&!this.serviceClientSettings.usingProductionTable){const e=t.prongCards.filter(t=>t.type===c.Category).sort(()=>.5-Math.random()),r=t.prongCards.filter(t=>t.type!==c.Category).sort(()=>.5-Math.random());t.prongCards=e.concat(r).slice(0,10)}return t}getDealsSDCardRequestBody(){return JSON.stringify({categoryId:"All",getProductDeals:!0,skip:0,take:this.serviceClientSettings.queryParams.take||30,userMuid:(0,f.ab)()})}async getShoppingEntitiesDataUsing1S(t=!0,e,r=u.xkP){let a=null;const s="shopping/blackjack/getblackjackdeals"===this.serviceClientSettings.servicePath?await this.fetchFrom1S(e,"POST",this.getDealsSDCardRequestBody()):await this.fetchFrom1S(e,"GET");return s?a=this.TryGetShoppingEntitiesData(s):t&&(0,h.c_)(new Error("Failed to fetch Shopping entities response"),r,`Failed to fetch Shopping entities response, with filter ${this.serviceClientSettings?.queryParams?.filter}`),a}async fetchFrom1S(t,e="GET",r=null){const a=(0,o.rA)(),s={method:e,headers:await y.WR.getOneServiceHeaders(),body:r,timeoutMs:t},n=[];if((0,f.ab)()&&!this.APISettings.skipUserMUID&&(n.push({key:"user",value:"m-"+(0,f.ab)()}),s.headers||(s.headers={MUID:(0,f.ab)()}),s.headers.MUID=(0,f.ab)()),this.serviceClientSettings.queryParams){n.push({key:"apikey",value:this.serviceClientSettings.queryParams.apikey||b}),n.push({key:a.OneServiceContentMarketQspKey,value:a.CurrentMarket}),this.serviceClientSettings.queryParams.ocid&&n.push({key:"ocid",value:this.serviceClientSettings.queryParams.ocid}),this.serviceClientSettings.queryParams.top&&n.push({key:"$top",value:this.serviceClientSettings.queryParams.top}),this.serviceClientSettings.queryParams.contentType&&n.push({key:"contentType",value:this.serviceClientSettings.queryParams.contentType});let t="";a.ShouldUseFdheadQsp&&a.CurrentRequestTargetScope?.pageExperiments&&(t=a.CurrentRequestTargetScope.pageExperiments.join()),a.ShouldUseFdheadQsp&&this.serviceClientSettings.queryParams.fdhead&&(t=t+","+this.serviceClientSettings.queryParams.fdhead),t&&n.push({key:"fdhead",value:t}),this.serviceClientSettings.queryParams.select&&n.push({key:"$select",value:this.serviceClientSettings.queryParams.select}),this.serviceClientSettings.queryParams.filter&&n.push({key:"$filter",value:this.serviceClientSettings.queryParams.filter}),this.serviceClientSettings.queryParams.setactivityid&&n.push({key:"activityId",value:(0,l.G)()})}else n.push({key:"apikey",value:b});const d=new URL(this.serviceClientSettings.servicePath,this.serviceClientSettings.serviceBaseUrl);d.search=i._3.keyValueArrayToQueryString(n);try{const t=await this.fetchImpl(d.href,s);if(t.ok){return await t.json()}}catch(t){(0,h.c_)(t,u.F6z,`MSN homepage shopping carousel fetch data failed, request url: ${d.href}`)}n.pop(),d.search=i._3.keyValueArrayToQueryString(n);try{const t=await this.fetchImpl(d.href,s);if(t.ok){return await t.json()}}catch(t){return(0,h.c_)(t,u.F6z,`MSN homepage shopping carousel second call fetch data failed, request url: ${d.href}`),null}}async hasBuyDirectInterest(){const t=await this.getShoppingEntitiesDataUsing1S(!0);if(!t||!t.shoppingEntities||!t.shoppingEntities.length)return!1;const e=t.shoppingEntities[0];return!(!e.id||!e.id.startsWith("Reco-"))}}},50880(t,e,r){r.d(e,{rF(){return M},Cb(){return I},os(){return P},nt(){return R},eJ(){return S},py(){return v},B(){return _},VN(){return A},z7(){return k},KA(){return D},Y6(){return T},yA(){return w},HU(){return b}});var a,s,o=r(33744),i=r(43672),n=r(54837),l=r(12420),d=r(93653),c=r(56018),p=r(87827),h=r(78285),u=r(53867),g=r(9790),m=r(6809),f=r(26888),y=function(t,e,r){var a=(0,h.A)(t),s=a||(0,u.A)(t)||(0,f.A)(t);if(e=(0,c.A)(e,4),null==r){var o=t&&t.constructor;r=s?a?new o:[]:(0,m.A)(t)&&(0,g.A)(o)?(0,l.A)((0,p.A)(t)):{}}return(s?n.A:d.A)(t,function(t,a,s){return e(r,t,a,s)}),r},C=r(96883);function b(t){if(!t)return"";const e=t.split("-");return 2===e.length?e[1]:t}function v(t){const e=b(t);return!isNaN(Number(e))}function w(t){if(!t)return"";const e=t.split("-");return 2===e.length?e[1]:t}function x(t,e){return t?(t=function(t){return o.T3.CurrentMarket===i.DX.JAJP&&(t+"").indexOf(".00")>-1?(t+"").replace(".00",""):t+""}(t),e&&-1==t.indexOf(e)?e+t:t):""}function $(t){const e=t.length;return t.slice(0,e-3)+t.slice(e-2,e)}function k(t,e,r=i.DX.ENUS){if(t){let a;a=-1!==(t+="").indexOf(e)?t.replace(e,""):t;const s=a.replace(/,/g,""),o=parseFloat(s);return o+"00"!==$(s)&&o+""!==s?t:r===i.DX.JAJP?x(o.toLocaleString(r),e):x(o.toLocaleString(r,{minimumFractionDigits:2,maximumFractionDigits:2}),e)}return t}function P(t,e){if(t&&e){return String(t)+"+"+e}return""}function S(t,e,r){if(t&&e&&t>=e){const a=(t-e)/1e3;let s=String(parseInt(String(a/60/60%24)));s=Number(s)<10?"0"+s:s;let o=String(parseInt(String(a/60%60)));o=Number(o)<10?"0"+o:o;let i=String(parseInt(String(a%60)));return i=Number(i)<10?"0"+i:i,r+String(s+":"+o+":"+i)}return""}function _(t){const e=[],r=[];return t&&t.length>0&&t.forEach(t=>{if(t&&t.id&&t?.imageInfo?.sourceImageUrl){const a=new URLSearchParams(new URL(t.imageInfo.sourceImageUrl).search);a.has("id")&&(e.push(b(t.id)),r.push(a.get("id")))}}),[e,r]}function A(t=(new Date).getHours(),e=(new Date).toLocaleDateString(),r=72e5){return new Date(e+(t>=10?" "+t:" 0"+t)+":00:00").getTime()+r}function D(t){const e=(new TextEncoder).encode(t),r=Array.from(e).map(t=>String.fromCharCode(t)).join("");return btoa(r)}function R(t,e,r){if(!t||!e||!r)return;const a=+t.replace(r,"").replace(",",""),s=+e.replace(r,"").replace(",","");if(!a||!s)return;const o=a-s;return o<=0?void 0:o}function M(t,e,r,a=!1){const s=R(t,e,r);if(!s)return;const o=100*s/+t.replace(r,"").replace(",","");return(a?Math.ceil(o):Math.floor(o))+"%"}function T(t,e){if(t){let r=t;return e?.forEach(t=>{r=r.replace(new RegExp(t+"$"),"")}),r=r.replace(/[^a-z0-9]/gi,"").toLowerCase(),r}return t}function I(t){return y(t,function(e,r,a){e[Array.isArray(t)?a:(0,C.A)(""+a)]=(0,m.A)(r)?I(r):r})}(s=a||(a={})).el="el",s.es="es",s.da="da",s.fi="fi",s.fr="fr",s.hu="hu",s.it="it",s.ja="ja",s.nl="nl",s.pl="pl",s.pt="pt"},37125(t,e,r){r.d(e,{Lm(){return s},Yd(){return o}});var a=r(69326);function s(t=!1){return function(){const t=new Date,e=t.getUTCDay(),r=t.getUTCHours();return!(1==e&&r>=18||5==e&&r<22||e>=2&&e<=4)||(0,a.kg)()}()||t?30:20}function o(t){return t.toString()+"%"}},5977(t,e,r){r.d(e,{AO(){return c},Ep(){return m},Je(){return d},iD(){return h}});var a=r(33744),s=r(45596),o=r(87906),i=r(40450);(0,a.rA)().StaticsUrl;const n=50;function l(t,e){(0,o.c_)(t,i.Wbw,`url: ${e}`)}function d(t,e,r,a,s){try{if(!t)return"";if(!e&&!r||0===e||0===r)return"";const o=new URL(t),i=o.searchParams.get("bw"),n=i?parseInt(i):0;n&&(e=e?e-2*n:e,r=r?r-2*n:r),e&&o.searchParams.set("h",e.toString()),r&&o.searchParams.set("w",r.toString()),void 0===a||o.searchParams.get("c")||o.searchParams.set("c",a),null!=s&&""!==s?o.searchParams.set("rs",s):o.searchParams.set("rs","1");const l=o.toString();e&&o.searchParams.set("h",(2*e).toString()),r&&o.searchParams.set("w",(2*r).toString()),n&&o.searchParams.set("bw",(2*n).toString());return`${l} 1x, ${o.toString()} 2x`}catch(e){return l(e,t),`${t} 1x`}}function c(t){const e=t.imageInfo?.images;if(!e)return;if(e.length>1){const r=e.map(t=>({...t,sourceImageUrl:(0,s.zt)(t.url)}));t.imageInfo.sourceImageUrl||(t.imageInfo.sourceImageUrl=r[0].sourceImageUrl),t.images=r.filter(e=>e.sourceImageUrl!==t.imageInfo.sourceImageUrl)}}function p(t,e=n){const r=new URL(t);return r.searchParams.set("w",e.toString()),r.searchParams.delete("h"),r.toString()}function h(t,e=0){const r=t.imageInfo?.sourceImageUrl;r&&(t.imageInfo.sourceImageUrl=u(g(r,e),"17"))}function u(t,e){try{const r=new URL(t);return r.searchParams.set("c",e.toString()),r.toString()}catch(e){return l(e,t),t}}function g(t,e=0,r="FFFFFF"){if(!e||!r)return t;try{const a=new URL(t);return a.searchParams.set("bw",e.toString()),a.searchParams.set("bc",r),a.toString()}catch(e){return l(e,t),t}}async function m(t,e="",r="",a=1,s=0){if(!e&&!r)return;if(!t.imageInfo?.sourceImageUrl)return;const o=await async function(t){try{const e=!0,r=t.imageInfo?.sourceImageUrl;if(!r)return e;const a=await f(p(r)),s=a.naturalWidth,o=a.naturalHeight,i=s/o;return s&&o?(t.imageInfo.ratio=i,y(a)):e}catch(t){return!0}}(t);let i="";o&&e&&(i=e),!o&&r&&(a=function(t){try{const e=new URL(t),r=e.searchParams.get("w"),a=e.searchParams.get("h"),s=r?parseInt(r):0,o=a?parseInt(a):0;if(!s||!o)return;return s/o}catch(e){return void l(e,t)}}(t.imageInfo.sourceImageUrl)||a,t.imageInfo.ratio&&Math.abs(t.imageInfo.ratio-a)<.2&&(i=r)),t.imageInfo.hasWhiteBackground=o,i&&(t.imageInfo.sourceImageUrl=u(t.imageInfo.sourceImageUrl,i),s&&o&&(t.imageInfo.sourceImageUrl=g(t.imageInfo.sourceImageUrl,s)))}async function f(t){const e=new Image;return e.crossOrigin="anonymous",e.src=t,await e.decode(),e}function y(t){try{t.crossOrigin="anonymous";const e=document.createElement("canvas"),r=t.naturalWidth,a=t.naturalHeight;e.width=r,e.height=a;const s=e.getContext("2d");s?.drawImage(t,0,0);const o=s?.getImageData(0,0,e.width,e.height),i=o?.data;if(!i)return!0;const n=function(t,e,r,a=5,s=20){let o=0;const i=2*a*(e+r-2*a);for(let i=0;i<r;i++)for(let n=0;n<e;n++)if(n<a||n>=e-a||i<a||i>=r-a){const r=4*(i*e+n),a=t[r],l=t[r+1],d=t[r+2],c=255-s;a>c&&l>c&&d>c&&o++}return o/i*100}(i,r,a);return n>=25}catch(e){return l(e,t.src),!0}}},52306(t,e,r){r.d(e,{E(){return o}});var a=r(45596),s=r(50880);class o extends a.dN{static buildAbsoluteUrl(t,e,r,a,o=!0,i){r=(0,s.yA)(r);const n=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(n,"msnembedded",e,o),n.searchParams.append("filters",this.getFiltersQueryParam(r,i)),n.searchParams.append("q",t),n.searchParams.append("productpage","true"),a&&n.searchParams.set("overlay","true"),n.href}static getFiltersQueryParam(t,e){const r=new URLSearchParams(window?.location?.search||"");let a=`pdprecocache:"true" scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`;return e&&(a+=' brqenabled:"true"'),t?a:r.get("filters")||""}}o.bingBaseUrl="https://www.bing.com/shop/productpage"},52226(t,e,r){r.d(e,{u(){return o}});var a=r(45596),s=r(7446);class o extends a.X9{static buildAbsoluteUrl({market:t,pid:e,title:r,clickSource:o,trafsrc:i,ocid:n,formCode:l,isBing:d,isBWM:c,campaignCode:p,addEntrypoint:h=!0}){if(d){const o=new URLSearchParams;if(r){const t=r.split(" ");r=t.length>2?t.slice(0,-2).join(" "):t.join(" "),o.set("q",r??"")}e&&(h&&o.set("entrypoint","buydirect"),o.set("productpage","true"),o.set("browse","true"),o.set("filters",`scenario:"17" gType:"12" gId:"${e}" gGlobalOfferIds:"${e}"`)),t&&o.set("setmkt",t),i&&o.set("trafsrc",i),n&&o.set("ocid",n),l&&o.set("FORM",l),p&&o.set("CBC",p),o.set("msnrid",s.YT?s.YT.getRequestId():"Telemetry not initialized"),o.set("adunitId","378983"),o.set("propertyId","316966");const d=(0,a.wW)(o);return e?"https://www.bing.com/shop/productpage"+(d?"?"+d:""):"https://www.bing.com/shop/buywithmicrosoft"+(d?"?"+d:"")}{const s=new URLSearchParams;e&&s.set("pid",e),o&&s.set(a.Ts.ClickSourceQueryParam,o),r&&s.set("title",r),n&&s.set("ocid",n),i&&s.set("trafsrc",i),l&&s.set("FORM",l);const d=(0,a.wW)(s);return e?`${this.getSchemeAndDomain()}/${t}/shopping/buydirect/product${d?"?"+d:""}`:`${this.getSchemeAndDomain()}/${t}/shopping/buydirect/superdeals${d?"?"+d:""}`}}static addSearchParams({url:t,pid:e,title:r,clickSource:s,trafsrc:o,ocid:i,formCode:n},l){if(!t)return t;const d=new URLSearchParams;r&&d.set("title",r),e&&d.set("pid",e),s&&d.set(a.Ts.ClickSourceQueryParam,s),i&&d.set("ocid",i),o&&d.set("trafsrc",o),n&&d.set("FORM",n);const[c,p]=t.split("?"),h=(0,a.$c)(new URLSearchParams(p),d),u=(0,a.wW)(h);if(l&&!e){const t=c.indexOf("/buydirect");if(-1!==t){return`https://www.bing.com/shop/buywithmicrosoft${c.slice(t+10)}${u?`?${u}`:""}`}}return c+(u?`?${u}`:"")}}},45596(t,e,r){r.d(e,{$c(){return u},DH(){return w},F7(){return v},Ts(){return a},X9(){return g},dN(){return f},eA(){return m},h3(){return b},wA(){return c},wQ(){return x},wW(){return h},zt(){return y}});var a,s=r(72627),o=r(7446),i=r(33744),n=r(43672),l=r(69326),d=r(50880);function c(t){return new URLSearchParams((0,s.iA)()).get(t)}function p(t){const e=["modal-offer-ids","modal-image-ids","pid","title","clksrc","modal-ec-ids"];for(let r=0;r<e.length;r++){const a=e[r];t.delete(a)}}function h(t,e=!1,r=!1){const a=new URLSearchParams(location.search);e&&p(a),r&&a.delete("disableheader"),t&&t.forEach((t,e)=>{a.set(e,t)});const s=new URLSearchParams;return a.getAll("item").forEach(t=>s.append("item",t)),a.delete("item"),`${a}${s.getAll("item").length>0?"&"+decodeURIComponent(s.toString()):""}`}function u(t,e){const r=new URLSearchParams(t);return e&&e.forEach((t,e)=>{r.set(e,t)}),r}!function(t){t.ClickSourceQueryParam="clksrc",t.ModalCarouselOfferIdsQueryParam="modal-offer-ids",t.ModalCarouselImageIdsQueryParam="modal-image-ids",t.ModalCarouselECIdsQueryParam="modal-ec-ids",t.gameFirstPositionQueryParam="game-first-position",t.itemQueryParam="item",t.AutoShowEdgeSidePane="auto_show_edge_shopping_pane",t.FeaturedComponentKey="featc",t.FeaturedComponentIndex="feati"}(a||(a={}));class g{static getSchemeAndDomain(){return window.location.origin.indexOf("localhost")>-1?window.location.origin:`https://${i.T3.NavTargetHostName}`}}const m=Object.freeze({NtpSdCard:"SDPDP1",NtpEventCard:"NTPMIT",NtpEventCard2:"NTPMIF",NtpCarousel:"CARPDP",NtpToL2Overlay:"STPDPI",NtpToL2OverlayWithoutOfferIds:"STPDPF",NtpToL2OverlayWithBRQ:"STPDPK",NtpAugmentCard:"SHAUG1",NtpSdCardControl:"STPDPG",NtpCarouselControl:"STPDPH",NtpToL2OverlayControl:"STPDPJ",Bing:"SHOPHP",Start:"SSPD01",FullPage:"ANNTS2",BingSDCardclick:"bhshpc",MeStripe:"msmstb",TopNav:"mstntb",AtfTitle:"mscatft",AtfCard:"msatfc",ShoppingTopSpan:"TOPARC",ShoppingViewsCarousel:"arcarc",ShoppingViewsCarousel2:"SHCAR2",ShoppingViewsCarousel1:"SHCAR1",Prong2Pivot:"P2SHPV",Prong2:"P2SHOP",Prong2Fashion:"P2SHFS",Prong2BGPremium:"P2BGPM",Prong2BGPremiumProduct:"P2BGPD",Prong1:"PRSHOP",Prong1BGPremium:"P1BGPM",Prong1BGPremiumProduct:"P1BGPD",MITSHP:"MITSHP",BuyingGuide1:"BGPDP1",BuyingGuideRelatedSearch:"BGLIRS",BuyingGuideInfoPane:"INFOBG",BuyingGuideAds:"SSBG01"});class f{static getBingShoppingQueryParameters(t,e,r=!0){const a=new URLSearchParams;return a.set("entryPoint",t),e&&a.set("FORM",e),"msn"!==t||(0,l.kg)()||a.set("msnrid",o.YT.getRequestId()),r&&i.T3.CurrentMarket!==n.DX.FRFR&&(a.set("adunitId","378983"),a.set("propertyId","316966")),a}static updateBingShoppingQueryParameters(t,e,r,a=!0,s){t.searchParams.delete("adunitid"),t.searchParams.delete("propertyid");return this.getBingShoppingQueryParameters(e,r,a).forEach((e,r)=>t.searchParams.set(r,e)),s&&t.searchParams.set("ocid",s),t.toString()}static updateUrlIfBingShopping(t,e){return t?.startsWith("https://www.bing.com/shop")?f.updateBingShoppingQueryParameters(new URL(t),e):t}}function y(t){return t?t.replace("?id=/th?","?"):""}const C="isembedded";function b(){return"1"===c(C)||"1"===c("disableheader")}function v(t){return!t.find(t=>t&&!(0,d.py)(t))}function w(t,e){const r=new URL(t);return Object.keys(e).forEach(t=>{r.searchParams.set(t,e[t])}),r.toString()}function x(t,e,r,a=!0){const s=new URL(t);s.searchParams.delete("adunitid"),s.searchParams.delete("propertyid");const d=new URLSearchParams;return d.set("entryPoint",e),r&&d.set("FORM",r),"msn"!==e||(0,l.kg)()||d.set("msnrid",o.YT.getRequestId()),a&&i.T3.CurrentMarket!==n.DX.FRFR&&(d.set("adunitId","378983"),d.set("propertyId","316966")),d.forEach((t,e)=>s.searchParams.set(e,t)),s.toString()}},31216(t,e,r){r.d(e,{H8(){return n},RD(){return o},Wr(){return l},qK(){return d}});var a=r(40450),s=r(87906);const o=(t,e,r)=>t?.title?(t?.thumbnail?.image||l(a.r5T,`Video ID [${n(t?.id,e,r)}] has an empty headline image but the content is valid.`),i(t,e,r)):(l(a.Ta7,`Video ID [${n(t?.id,e,r)}] has an empty headline.`),!1),i=(t,e,r)=>{if(t?.videoMetadata?.externalVideoFiles?.length){const s=t.videoMetadata.externalVideoFiles,o=s?.find(t=>!t.url&&!t.format);return!o||(l(a.WWk,`Video ID [${n(t.id,e,r)}] has an invalid 1pp video file.`),!1)}return!1},n=(t,e,r)=>`${t??e??"N/A"}${r?" (playlist) ":""}`,l=(t,e)=>{(0,s.vV)(t,"Data returned by content view does not contain expected video data.",e,{...t.pb})},d=t=>{const{cardContent:e,metadata:r}=t;return{id:t.id,title:e?.title,thumbnail:{image:e?.images?.[0]},videoMetadata:{playTime:r?.videoMetadata.playTime,externalVideoFiles:e?.videoFiles},sourceId:e?.sourceId||""}}},49371(t,e,r){r.d(e,{e3(){return o},fR(){return s}});var a=r(72627);function s(t=(0,a.$t)()){return/^python-requests|^CriteoBot|^ias-|GrapeshotCrawler/.test(t)}function o(t=(0,a.$t)()){if(!t)return!1;const e=(0,a.iA)(),r=e&&e.includes("reqsrc=vp");return-1!==t.indexOf("Yahoo")||-1!==t.indexOf("Yandex")||-1!==t.indexOf("Baiduspider")||-1!==t.indexOf("Bingbot")||-1!==t.indexOf("Googlebot")||-1!==t.indexOf("Google-InspectionTool")||-1!==t.indexOf("msnbot")||!r&&-1!==t.indexOf("HeadlessChrome")}},9723(t,e,r){r.d(e,{B(){return i}});var a=r(59669),s=r(63033);const o=a.A`
.ad-choice{filter:var(--filter-color)}`,i=a.A`
:host{--filter-color:invert(99%) sepia(10%) saturate(0%) hue-rotate(244deg) brightness(120%) contrast(100%)}.ad-choice{align-items:center;display:flex;width:12px;z-index:${"1"}}@media (forced-colors:active){.ad-choice{filter:invert(1) !important}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice{filter:var(--filter-color) !important}}`.withBehaviors(new s.N(null,o))},27742(t,e,r){r.d(e,{E(){return i}});var a=r(59669),s=r(4126);const o=a.A`
.ad-label{font-size:12px;border:unset;padding:unset}`,i=a.A`
.ad-label{align-items:center;border-radius:4px;border:0.5px solid var(--color-neutral-stroke-1,var(--neutral-foreground-rest));color:inherit;display:flex;font-size:11px;padding:0 4px 1px 4px;text-decoration:none;z-index:${"1"}}a[no-border]{border:unset;padding:unset;display:inline-flex}.dsa:hover{text-decoration:underline}`.withBehaviors(new s.o("ruby",!0,o))},75003(t,e,r){r.d(e,{m(){return n}});var a=r(37180),s=r(72526),o=r(46439),i=r(38380);const n=s.L.compose({name:`${a.c.prefix}-card`,template:i.v,styles:o.R})},72526(t,e,r){r.d(e,{L(){return g}});var a=r(56911),s=r(96193),o=r(33045),i=r(47429),n=r(60815),l=r(38493),d=r(95239),c=r(31023),p=r(69809),h=r(5291),u=r(99758);class g extends s.z{cardFillColorChanged(t,e){if(e){const t=(0,o.Hs)(e);null!==t&&(this.neutralPaletteSource=e,d.p.setValueFor(this,h.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,o.Hs)(e),r=h.q.create(t.r,t.g,t.b);c.r.setValueFor(this,u.p.create(r))}}handleChange(t,e){this.cardFillColor||d.p.setValueFor(this,t=>t(p.M3).evaluate(t,t(d.p)))}connectedCallback(){super.connectedCallback();const t=(0,i.Zo)(this);if(t){const e=n.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,a.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,a.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,a.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,a.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},38380(t,e,r){r.d(e,{v(){return a}});const a=(0,r(25717).T)()},69329(t,e,r){r.d(e,{m(){return b}});var a=r(75261);class s extends a.t{}var o=r(37180),i=r(59669),n=r(64187),l=r(22131),d=r(50882),c=r(48196),p=r(83252),h=r(64835),u=r(6032);const g=i.A` ${(0,n.V)("flex")} :host{align-items:center;outline:none;height:calc(${c.D} * 1px);width:calc(${c.D} * 1px);margin:calc(${c.D} * 1px) 0}.progress{height:100%;width:100%}.background{stroke:${p.F7};fill:none;stroke-width:2px}.determinate{stroke:${h.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out}.indeterminate-indicator-1{stroke:${h.IR};fill:none;stroke-width:2px;stroke-linecap:round;transform-origin:50% 50%;transform:rotate(-90deg);transition:all 0.2s ease-in-out;animation:spin-infinite 2s linear infinite}:host([paused]) .indeterminate-indicator-1{animation-play-state:paused;stroke:${p.F7}}:host([paused]) .determinate{stroke:${u.c}}@keyframes spin-infinite{0%{stroke-dasharray:0.01px 43.97px;transform:rotate(0deg)}50%{stroke-dasharray:21.99px 21.99px;transform:rotate(450deg)}100%{stroke-dasharray:0.01px 43.97px;transform:rotate(1080deg)}}`.withBehaviors((0,l.mr)(i.A` .indeterminate-indicator-1,.determinate{stroke:${d.A.FieldText}}.background{stroke:${d.A.Field}}:host([paused]) .indeterminate-indicator-1{stroke:${d.A.Field}}:host([paused]) .determinate{stroke:${d.A.GrayText}}`));var m=r(89757),f=r(69259),y=r(18893);const C=function(t={}){return m.qy`
        <template
            role="progressbar"
            aria-valuenow="${t=>t.value}"
            aria-valuemin="${t=>t.min}"
            aria-valuemax="${t=>t.max}"
        >
            ${(0,f.z)(t=>"number"==typeof t.value,m.qy`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${t=>44*t.percentComplete/100+"px 44px"}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,m.qy`
                    <slot name="indeterminate">
                        ${(0,y.R)(t.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:m.qy`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),b=s.compose({name:`${o.c.prefix}-progress-ring`,template:C,styles:g})},25717(t,e,r){r.d(e,{T(){return s}});var a=r(89757);function s(){return a.qy`
        <slot></slot>
    `}},75261(t,e,r){r.d(e,{t(){return n}});var a=r(56911),s=r(92011),o=r(38493),i=r(60815);class n extends s.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const t="number"==typeof this.min?this.min:0,e="number"==typeof this.max?this.max:100,r="number"==typeof this.value?this.value:0,a=e-t;this.percentComplete=0===a?0:Math.fround((r-t)/a*100)}}(0,a.Cg)([(0,o.CF)({converter:o.R$}),(0,a.Sn)("design:type",Object)],n.prototype,"value",void 0),(0,a.Cg)([(0,o.CF)({converter:o.R$}),(0,a.Sn)("design:type",Number)],n.prototype,"min",void 0),(0,a.Cg)([(0,o.CF)({converter:o.R$}),(0,a.Sn)("design:type",Number)],n.prototype,"max",void 0),(0,a.Cg)([(0,o.CF)({mode:"boolean"}),(0,a.Sn)("design:type",Boolean)],n.prototype,"paused",void 0),(0,a.Cg)([i.sH,(0,a.Sn)("design:type",Number)],n.prototype,"percentComplete",void 0)},34054(t,e,r){var a=r(15420);e.A=function(t,e,r){var s=t.length;return r=void 0===r?s:r,!e&&r>=s?t:(0,a.A)(t,e,r)}},82393(t,e,r){r.d(e,{A(){return F}});var a=r(6574),s=function(t){return function(e){return null==t?void 0:t[e]}}({À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"}),o=r(57842),i=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,n=RegExp("[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]","g"),l=function(t){return(t=(0,o.A)(t))&&t.replace(i,s).replace(n,"")},d=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,c=function(t){return t.match(d)||[]},p=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,h=function(t){return p.test(t)},u="\\ud800-\\udfff",g="\\u2700-\\u27bf",m="a-z\\xdf-\\xf6\\xf8-\\xff",f="A-Z\\xc0-\\xd6\\xd8-\\xde",y="\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",C="["+y+"]",b="\\d+",v="["+g+"]",w="["+m+"]",x="[^"+u+y+b+g+m+f+"]",$="(?:\\ud83c[\\udde6-\\uddff]){2}",k="[\\ud800-\\udbff][\\udc00-\\udfff]",P="["+f+"]",S="(?:"+w+"|"+x+")",_="(?:"+P+"|"+x+")",A="(?:['’](?:d|ll|m|re|s|t|ve))?",D="(?:['’](?:D|LL|M|RE|S|T|VE))?",R="(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?",M="[\\ufe0e\\ufe0f]?",T=M+R+("(?:\\u200d(?:"+["[^"+u+"]",$,k].join("|")+")"+M+R+")*"),I="(?:"+[v,$,k].join("|")+")"+T,O=RegExp([P+"?"+w+"+"+A+"(?="+[C,P,"$"].join("|")+")",_+"+"+D+"(?="+[C,P+S,"$"].join("|")+")",P+"?"+S+"+"+A,P+"+"+D,"\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])","\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",b,I].join("|"),"g"),B=function(t){return t.match(O)||[]},U=function(t,e,r){return t=(0,o.A)(t),void 0===(e=r?void 0:e)?h(t)?B(t):c(t):t.match(e)||[]},z=RegExp("['’]","g"),F=function(t){return function(e){return(0,a.A)(U(l(e).replace(z,"")),t,"")}}},16670(t,e){var r=RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]");e.A=function(t){return r.test(t)}},29952(t,e,r){r.d(e,{A(){return C}});var a=function(t){return t.split("")},s=r(16670),o="\\ud800-\\udfff",i="["+o+"]",n="[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]",l="\\ud83c[\\udffb-\\udfff]",d="[^"+o+"]",c="(?:\\ud83c[\\udde6-\\uddff]){2}",p="[\\ud800-\\udbff][\\udc00-\\udfff]",h="(?:"+n+"|"+l+")"+"?",u="[\\ufe0e\\ufe0f]?",g=u+h+("(?:\\u200d(?:"+[d,c,p].join("|")+")"+u+h+")*"),m="(?:"+[d+n+"?",n,c,p,i].join("|")+")",f=RegExp(l+"(?="+l+")|"+m+g,"g"),y=function(t){return t.match(f)||[]},C=function(t){return(0,s.A)(t)?y(t):a(t)}},96883(t,e,r){r.d(e,{A(){return i}});var a=r(57842),s=r(33610),o=function(t){return(0,s.A)((0,a.A)(t).toLowerCase())},i=(0,r(82393).A)(function(t,e,r){return e=e.toLowerCase(),t+(r?o(e):e)})},33610(t,e,r){r.d(e,{A(){return n}});var a=r(34054),s=r(16670),o=r(29952),i=r(57842),n=function(t){return function(e){e=(0,i.A)(e);var r=(0,s.A)(e)?(0,o.A)(e):void 0,n=r?r[0]:e.charAt(0),l=r?(0,a.A)(r,1).join(""):e.slice(1);return n[t]()+l}}("toUpperCase")},12165(t,e,r){r.d(e,{Id(){return v}});var a=r(56911),s=r(92011),o=r(38493);class i extends s.L{constructor(){super(...arguments),this.appearance="primary"}}(0,a.Cg)([o.CF],i.prototype,"appearance",void 0),(0,a.Cg)([(0,o.CF)({attribute:"fill"})],i.prototype,"fill",void 0),(0,a.Cg)([(0,o.CF)({attribute:"color"})],i.prototype,"color",void 0),(0,a.Cg)([o.CF],i.prototype,"download",void 0),(0,a.Cg)([o.CF],i.prototype,"href",void 0),(0,a.Cg)([o.CF],i.prototype,"hreflang",void 0),(0,a.Cg)([o.CF],i.prototype,"ping",void 0),(0,a.Cg)([o.CF],i.prototype,"referrerpolicy",void 0),(0,a.Cg)([o.CF],i.prototype,"rel",void 0),(0,a.Cg)([o.CF],i.prototype,"target",void 0),(0,a.Cg)([o.CF],i.prototype,"type",void 0);const n=r(89757).qy`<a class="control" part="control" download="${t=>t.download}" href="${t=>t.href}" hreflang="${t=>t.hreflang}" ping="${t=>t.ping}" referrerpolicy="${t=>t.referrerpolicy}" rel="${t=>t.rel}" target="${t=>t.target}" type="${t=>t.type}" style="${t=>t.fill&&t.color?`background-color: var(--ad-label-fill-${t.fill}); color: var(--ad-label-color-${t.color})`:void 0}"><slot></slot></a>`;var l=r(59669),d=r(64187),c=r(73477),p=r(22131),h=r(7896),u=r(62047),g=r(57416),m=r(26920),f=r(47810),y=r(14996);const C=l.A` ${(0,d.V)("inline-block")} :host{box-sizing:border-box;font-family:${h.O};font-size:${u.t};font-weight:400;${""} z-index:4}.control{text-align:center;border-radius:calc(${g.Pb} * 1px);padding:0 6px;min-width:24px;text-decoration:none;height:16px;border:calc(${m.XA} * 1px) solid ${f.l};color:${f.l}}.control:${c.N}{outline:none;border:calc(${m.XA} * 1px) solid ${y.WN}}`.withBehaviors((0,p.mr)(l.A` :host{forced-color-adjust:auto}`));var b=r(651);const v=i.compose({name:`${b.i.prefix}-ad-label`,template:n,styles:C,shadowOptions:{delegatesFocus:!0}})},36880(t,e,r){r.d(e,{m(){return s}});var a=r(92011);class s extends a.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},58757(t,e,r){r.d(e,{Af(){return y}});var a=r(36880),s=r(89757),o=r(60402);const i=s.qy`<span part="image" ${(0,o.K)("imageContainer")}><slot name="image" ${(0,o.K)("image")} @slotchange=${t=>t.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var n=r(59669),l=r(64187),d=r(22131),c=r(7896),p=r(61138),h=r(6032),u=r(74838),g=r(50882);const m=n.A` ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};font-size:${p.k};font-weight:400;line-height:${p.F};align-items:center;color:${h.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${u.vR} * 2px)}`.withBehaviors((0,d.mr)(n.A` :host,.content{color:${g.A.CanvasText};fill:currentcolor}`));var f=r(651);const y=a.m.compose({name:`${f.i.prefix}-attribution`,template:i,styles:m})},51122(t,e,r){r.d(e,{S(){return a},m(){return d}});var a,s=r(56911),o=r(92011),i=r(38493),n=r(60815),l=r(93856);!function(t){t.default="default",t.condensed="condensed",t.infoPane="infoPane",t.infoPane1x3y="infoPane1x3y",t.infoPaneSplitVertical="infoPaneSplitVertical",t.infoPaneSplitHorizontal="infoPaneSplitHorizontal"}(a||(a={}));class d extends o.L{constructor(){super(...arguments),this.layout=a.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(t){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(t):(this.$emit("link-invoked",t),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(t=>t instanceof l.L)}setExpanded(t){this.filteredContentIndicator().forEach(e=>e.expanded=t)}}(0,s.Cg)([i.CF],d.prototype,"layout",void 0),(0,s.Cg)([(0,i.CF)({attribute:"heading-level",mode:"fromView",converter:i.R$})],d.prototype,"headinglevel",void 0),(0,s.Cg)([(0,i.CF)({mode:"fromView"})],d.prototype,"href",void 0),(0,s.Cg)([n.sH],d.prototype,"isGrid",void 0),(0,s.Cg)([n.sH],d.prototype,"anchorTelemetryTag",void 0),(0,s.Cg)([n.sH],d.prototype,"mediaNodes",void 0),(0,s.Cg)([n.sH],d.prototype,"hasAbstract",void 0),(0,s.Cg)([n.sH],d.prototype,"abstract",void 0),(0,s.Cg)([n.sH],d.prototype,"iconSlottedNodes",void 0),(0,s.Cg)([(0,i.CF)({attribute:"image-priority",mode:"boolean"})],d.prototype,"imagePriority",void 0),(0,s.Cg)([i.CF],d.prototype,"target",void 0),(0,s.Cg)([n.sH],d.prototype,"hoverActionsSlottedNodes",void 0),(0,s.Cg)([n.sH],d.prototype,"handleContentCardClickOverride",void 0),(0,s.Cg)([n.sH],d.prototype,"contentIndicatorNodes",void 0)},55461(t,e,r){r.d(e,{yr(){return F}});var a=r(51122),s=r(89757),o=r(60402),i=r(69259),n=r(416),l=r(10108),d=r(82774),c=r(33744);const p=(0,r(69326).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),h=s.qy`<div class="footer ${t=>t.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,o.K)("startActionsContainer")}><slot name="start-actions" ${(0,o.K)("startActions")} @slotchange=${t=>t.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,o.K)("endActionsContainer")}><slot name="end-actions" ${(0,o.K)("endActions")} @slotchange=${t=>t.handleEndActionsContentChange()}></slot></span></div>`,u=s.qy`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,m=s.qy`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${t=>(t.title&&t.title.match(g)?.[0])??"Earn cash back"}</span></div>`,f=(t,e)=>s.qy`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${e}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${t.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${t}</span></div>`,y=s.qy`<div style="display: flex;">${t=>t.id.includes("__")?s.qy` ${(0,i.z)(t=>t.id.includes("_Christmas"),f("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,i.z)(t=>t.id.includes("_BlackFriday"),f("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,i.z)(t=>t.id.includes("_CyberMonday"),f("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:s.qy` ${(0,i.z)(t=>t&&!t.id.includes("_NoCashback"),m)} ${(0,i.z)(t=>t,u)} `}</div>`,C=s.qy`<div style="background: no-repeat center url('${t=>t.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,b=s.qy`<div class="logo-container"><img src=${p} alt="Microsoft Logo" aria-hidden="true" /></div>`,v=s.qy`<template ${(0,n.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${t=>t.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,i.z)(t=>t.id.includes("contentcard_tripleCashback"),b)} ${(0,i.z)(t=>t.id.includes("contentcard_edgeReclaim"),b)} ${(0,i.z)(t=>t.id.includes("contentcard_InfoBuyDirectCard"),C)}<slot name="background-image" ${(0,o.K)("backgroundImage")}></slot></span>${(0,i.z)(t=>t.id.includes("BuyDirectCard"),y)}<div class="mask" part="mask"></div><div class="body ${t=>t.hasAbstract?"has-abstract":""} ${t=>t.isGrid?"grid":""}" part="body">${(0,i.z)(t=>t?.mediaNodes?.length>0,s.qy`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,o.K)("mediaContainer")}><slot name="media" ${(0,o.K)("media")} @slotchange=${t=>t.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,o.K)("iconContainer")} class="${t=>t.iconSlottedNodes&&t.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,o.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,i.z)(t=>0===t?.mediaNodes?.length,s.qy`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${t=>t.headinglevel} name="heading"><a class="heading" part="heading" href=${t=>t.href?t.href:void 0} target=${t=>t.target?t.target:void 0} @click=${(t,e)=>t.handleContentCardLinkClick(e.event)} data-t="${t=>t.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,i.z)(t=>t.layout!==a.S.default,h)}</div>${(0,i.z)(t=>t.layout===a.S.default,h)}<span part="hover-actions" class="${t=>t.hoverActionsSlottedNodes&&t.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var w=r(64187),x=r(73477),$=r(22131),k=r(59669),P=r(50882),S=r(7896),_=r(61138),A=r(6032),D=r(41123),R=r(47810),M=r(89580),T=r(95239),I=r(86856);const O=k.A` :host([layout="default"]) .media-wrapper{float:right}`,B=k.A` :host([layout="default"]) .media-wrapper{float:left}`,U=k.A` ${(0,w.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${S.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${_.k});line-height:var(--footer-line-height,${_.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${A.c};fill:${A.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${D.K});line-height:var(--abstract-line-height,${D.Z});font-weight:400;grid-column:span 2;box-sizing:content-box;color:${A.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${A.c};fill:${A.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${R.l};font-size:var(--heading-font-size,${M.Y});line-height:var(--heading-line-height,${M.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${x.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${T.p};box-shadow:0px -25px 15px ${T.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${R.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${R.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${T.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${T.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new I.t(O,B),(0,$.mr)(k.A` .heading{color:${P.A.LinkText};background:${P.A.ButtonFace}}.abstract{color:${P.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${P.A.ButtonText};background:${P.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${P.A.ButtonFace};color:${P.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${P.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${P.A.ButtonFace}}`));var z=r(651);const F=a.m.compose({name:`${z.i.prefix}-content-card`,template:v,styles:U,shadowOptions:{delegatesFocus:!0}})},93856(t,e,r){r.d(e,{L(){return n}});var a=r(56911),s=r(92011),o=r(38493),i=r(60815);class n extends s.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,a.Cg)([(0,o.CF)({mode:"boolean"})],n.prototype,"expanded",void 0),(0,a.Cg)([i.sH],n.prototype,"defaultItems",void 0),(0,a.Cg)([(0,o.CF)({mode:"boolean",attribute:"animate"})],n.prototype,"shouldanimate",void 0)},97964(t,e,r){r.d(e,{rX(){return x}});var a=r(93856),s=r(89757),o=r(82774);const i=s.qy`<span class="icon-container" part="icon-container" aria-hidden="true"><slot name="icon"></slot></span><span class="label-container" part="label-container"><span class="label" part="label"><slot ${(0,o.e)({property:"defaultItems",filter(t){return t instanceof HTMLElement&&null!==t.offsetParent||t instanceof Text&&!!t.textContent?.trim().length}})}></slot></span></span>`;var n=r(7896),l=r(61138),d=r(86856),c=r(57416),p=r(64187),h=r(22131),u=r(59669),g=r(63033),m=r(50882);const f=u.A` :host::after{transform:translateX(-100%) translateX(20px)}:host([animate]) .label{transform:translateX(-100%)}`,y=u.A` :host::after{transform:translateX(100%) translateX(-20px)}:host([animate]) .label{transform:translateX(100%)}`,C=u.A` :host{color:#000}:host::after{background:rgba(255,255,255,0.46)}`,b=u.A` :host{color:#fff}:host::after{background:rgba(0,0,0,0.54)}`,v=u.A` ${(0,p.V)("inline-flex")} :host{align-items:center;box-sizing:border-box;contain:content;overflow:hidden}.label-container{overflow:hidden}:host,:host::after{${""} border-radius:4px}:host::after{content:"";height:100%;position:absolute;width:100%;z-index:-1}.icon-container,.label{min-height:20px;min-width:20px;display:flex;align-items:center;justify-content:center;fill:currentcolor}:host([animate])::after,.label{transition:transform 250ms cubic-bezier(0.17,0.17,0,1)}.label{font-family:${n.O};font-size:${l.k};font-weight:600;line-height:${l.F};text-overflow:ellipsis;padding:0 4px}:host([expanded][animate])::after,:host([expanded][animate]) .label{transform:translateX(0%)}.label{transform:translateX(-100%)}::slotted([slot="icon"]){display:block;fill:currentcolor}`.withBehaviors(new d.t(f,y),new g.N(C,b),(0,h.mr)(u.A` :host{forced-color-adjust:auto}::slotted([slot="icon"]){color:${m.A.ButtonText};fill:currentcolor}.icon-container,:host([expanded][animate]) .label,:host::after{background:${m.A.ButtonFace};color:${m.A.ButtonText};fill:currentcolor;border-radius:calc(${c.Pb} * 10px)}.label{background:transparent}`));var w=r(651);const x=a.L.compose({name:`${w.i.prefix}-content-indicator`,template:i,styles:v})},42320(t,e,r){r.d(e,{Ob(){return w}});var a=r(94020),s=r(89757),o=r(82774),i=r(69259);const n=s.qy`<template><slot ${(0,o.e)({property:"items",filter(t){return t instanceof HTMLElement&&null!==t.offsetParent}})}></slot>${(0,i.z)(t=>t.layout===a.Y.list,s.qy` <span class="topic">${t=>t.topic}</span> `)} ${t=>t.dividerTemplate}</template>`;var l=r(7896),d=r(41123),c=r(47810),p=r(95239),h=r(89580),u=r(86856),g=r(59669),m=r(64187),f=r(22131);const y=g.A` :host([layout="double"]) .divider-1{left:0}:host([layout="triple"]) .divider-1{left:0}:host([layout="triple"]) .divider-2{left:0}:host([layout="mosaic"]) .divider-1{left:0}:host([layout="mosaic"]) .divider-2{left:1px}`,C=g.A` :host([layout="double"]) .divider-1{right:0}:host([layout="triple"]) .divider-1{right:0}:host([layout="triple"]) .divider-2{right:0}:host([layout="mosaic"]) .divider-1{right:0}:host([layout="mosaic"]) .divider-2{right:1px}`,b=g.A` ${(0,m.V)("grid")} :host{box-sizing:border-box;font-family:${l.O};font-size:${d.K};line-height:${d.Z};color:${c.l};height:100%;width:100%;position:relative}:host([layout="single"]){grid-template-columns:1fr}:host([layout="double"]){grid-template-columns:1fr 1fr}:host([layout="split"]){grid-template-rows:1fr 1fr}:host([layout="triple"]){grid-template-columns:1fr 1fr 1fr}:host([layout="mosaic"]){grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}:host([layout="mosaic"]) ::slotted(:first-child){grid-row:1 / span 2;grid-column:1}:host([layout="mosaic"]) ::slotted(msft-content-card:not(:first-child)){--mask-gradient:linear-gradient(rgba(0,0,0,0),${p.p})}:host([layout="list"]){grid-template-rows:auto 1fr 1fr 1fr;grid-template-columns:3fr 2fr}:host([layout="list"]) ::slotted(:first-child){grid-row:1 / span 4;grid-column:1}:host([layout="list"]) ::slotted(msft-content-card:not(:first-child)){background:${p.p};--heading-font-size:${d.K};--heading-line-height:${d.Z}}.topic{grid-row:1;grid-column:2;font-size:${h.Y};line-height:${h.v};background:${p.p};padding:6px 12px}.divider{background:rgba(255,255,255,0.4);position:absolute;left:20px;right:20px;top:20px;bottom:20px;z-index:1;pointer-events:none;opacity:0}:host([layout="double"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="split"]) .divider-1{grid-row:2;height:1px;top:0;opacity:1}:host([layout="triple"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="triple"]) .divider-2{grid-column:3;width:1px;opacity:1}:host([layout="mosaic"]) .divider-1{grid-column:2;grid-row:1 / span 2;width:1px;opacity:1}:host([layout="mosaic"]) .divider-2{grid-column:2;grid-row:2;height:1px;top:0;opacity:1}`.withBehaviors(new u.t(y,C),(0,f.mr)(g.A` .divider{background:none}`));var v=r(651);const w=a.s.compose({name:`${v.i.prefix}-info-pane-slide`,template:n,styles:b})},94020(t,e,r){r.d(e,{Y(){return a},s(){return c}});var a,s=r(56911),o=r(89757),i=r(92011),n=r(60815),l=r(38493);!function(t){t.single="single",t.double="double",t.split="split",t.triple="triple",t.mosaic="mosaic",t.list="list"}(a||(a={}));const d=new Map;class c extends i.L{constructor(){super(...arguments),this.dividerTemplate=null,this.layout=a.single}itemsChanged(t,e){this.$fastController.isConnected&&(this.dividerTemplate=function(t){if(d.has(t))return d.get(t);if(t<1)return d.set(t,null),null;const e=new Array(t).fill("").map((t,e)=>o.qy`<div class="divider divider-${e+1}" part="divider"></div>`).reduce((t,e)=>o.qy`${t}${e}`);return d.set(t,e),e}(this.items.length-1))}}(0,s.Cg)([n.sH],c.prototype,"items",void 0),(0,s.Cg)([n.sH],c.prototype,"dividerTemplate",void 0),(0,s.Cg)([l.CF],c.prototype,"layout",void 0),(0,s.Cg)([l.CF],c.prototype,"topic",void 0)},47131(t,e,r){r.d(e,{Bb(){return _}});var a=r(56911),s=r(92011),o=r(38493),i=r(60815);class n extends s.L{moneyCardContentDataChanged(){"Default"!==this.cardStyle&&void 0===this.moneyCardContentData.actionAppearance&&(this.moneyCardContentData.actionAppearance="outline")}getQuoteColor(t,e,r,a,s){return e?s:this.moneyCardContentData.swapGainLossColor?t?r:a:t?a:r}changeShowingValue(){this.showChangeValue=!this.showChangeValue}connectedCallback(){super.connectedCallback(),this.showChangeValue=!1}}(0,a.Cg)([(0,o.CF)({attribute:"layout"})],n.prototype,"layout",void 0),(0,a.Cg)([o.CF],n.prototype,"cardStyle",void 0),(0,a.Cg)([o.CF],n.prototype,"target",void 0),(0,a.Cg)([i.sH],n.prototype,"moneyCardContentData",void 0),(0,a.Cg)([i.sH],n.prototype,"quoteItems",void 0),(0,a.Cg)([i.sH],n.prototype,"showChangeValue",void 0),(0,a.Cg)([i.sH],n.prototype,"headerTelemetryTag",void 0),(0,a.Cg)([i.sH],n.prototype,"switchValueTelemetryTag",void 0),(0,a.Cg)([i.sH],n.prototype,"seeMoreTelemetryTag",void 0);var l=r(89757),d=r(69259),c=r(68835);const p=l.qy`<a class="quote-row" part="quote-row" href="${t=>t.quoteHref}" target=${(t,e)=>e.parent.target} aria-label="${t=>t.displayName} ${t=>t.symbol} ${t=>t.price} ${t=>t.changePcnt}" data-t="${t=>t.telemetryTag}"><div class="quote-view" part="quote-view"><div class="quote-title-container" part="quote-title-container"><span class="quote-title" part="quote-title"><p class="quote-title-content" part="quote-title-content" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.symbol}</p></span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.displayName}</p></span></div><div class="quote-title-container" part="quote-title-container"><div class="price" part="price"><span class="price-str" part="price-str">${t=>t.price}</span></div></div><button class="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(t,e)=>e.parent.changeShowingValue()}" aria-label="${(t,e)=>e.parent.showChangeValue?`${t.changeValue} ${t.displayName} ${t.changePcnt}`:`${t.changePcnt} ${t.displayName} ${t.changeValue}`}" data-t="${(t,e)=>e.parent.switchValueTelemetryTag}">${(0,d.z)((t,e)=>e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changeValue}</span></span>`)} ${(0,d.z)((t,e)=>!e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changePcnt}&lrm;</span></span>`)}</button></div></a>`,h=l.qy`<msft-structured-data-card target=${t=>t.target} :headerTelemetryTag=${t=>t.headerTelemetryTag} :seeMoreTelemetryTag=${t=>t.seeMoreTelemetryTag} :data=${t=>t.moneyCardContentData}><slot name="more-actions" slot="more-actions"></slot><slot name="pin" slot="pin"></slot><slot name="title-icon" slot="title-icon"></slot><div class="quote-list" part="quote-list">${(0,c.ux)(t=>t.quoteItems,p)}</div><slot name="footer-start" slot="footer-start"></slot><slot name="footer-end" slot="footer-end"></slot></msft-structured-data-card>`;var u=r(47810),g=r(89580),m=r(41123),f=r(6032),y=r(61138),C=r(95403),b=r(14996),v=r(26920),w=r(59669),x=r(64187),$=r(22131),k=r(50882);const P=w.A` ${(0,x.V)("flex")} :host{height:100%;--quote-grid-columns:111px 81px 56px}:host(:focus){outline:none}msft-structured-data-card::part(title-link)::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}.price-str{color:${u.l};font-weight:600;text-align:end;width:100%;font-size:var(--price-content-font-size,${g.Y});line-height:var(--price-content-line-height,${g.v})}.quote-list{margin-top:var(--quote-list-margin-top,12px);display:grid;grid-template-rows:var(--quote-list-grid-rows,repeat(auto-fill,52px));row-gap:var(--quote-list-grid-gap,2px);z-index:1}.quote-title-content{color:${u.l};font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0;font-size:var(--quote-title-font-size,${m.K});line-height:var(--quote-title-line-height,${m.Z})}.sec-title-str{color:${f.c};margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:${y.k};line-height:${y.F}}.quote-row{cursor:pointer;text-decoration:none;padding:var(--quote-row-padding,8px 8px);margin:var(--quote-row-margin,0px 8px)}.quote-row:hover{background:${C.oO}}.change-values{height:24px;font-family:var(--body-font);border-radius:4px;border:0;padding:0;cursor:pointer;outline:none}.change-values:focus-visible{outline-color:${b.WN};outline-width:2px;outline-style:auto}.change-button-area{display:flex;flex-direction:column;justify-content:flex-end}.change-values-percentage{margin-top:4px;margin-bottom:4px;margin-inline-end:8px;display:block;font-size:${y.k};font-weight:600;line-height:${y.F};text-align:end}.price{align-items:center;display:flex}.quote-title-container{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:var(--quote-grid-columns)}.quote-green{color:#ffffff;background:#107c10}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}`.withBehaviors((0,$.mr)(w.A` :host{forced-color-adjust:auto}.title-link:hover{text-decoration:underline}.change-values,.quote-row:hover{forced-color-adjust:none;background:${k.A.ButtonFace};box-shadow:0 0 0 calc((${v.vd} - ${v.XA}) * 1px) ${k.A.LinkText};color:${k.A.ButtonText}}::slotted(*[slot="option-button"]){fill:${k.A.ButtonText}}::slotted([slot="option-button"]:hover){background:${k.A.Highlight};fill:${k.A.HighlightText}}.change-values:focus-visible{outline-color:${k.A.Highlight}}`));var S=r(651);const _=n.compose({name:`${S.i.prefix}-show-quotes-money-card`,template:h,styles:P})},46439(t,e,r){r.d(e,{R(){return p}});var a=r(59669),s=r(64187),o=r(22131),i=r(50882),n=r(37998),l=r(95239),d=r(47810),c=r(57416);const p=a.A` ${(0,s.V)("block")} :host{--elevation:4;display:block;contain:content;height:var(--card-height,100%);width:var(--card-width,100%);box-sizing:border-box;background:${l.p};color:${d.l};border-radius:calc(${c.JU} * 1px);${n.ET}}:host(:hover){--elevation:8}:host(:focus-within){--elevation:8}:host{content-visibility:auto}`.withBehaviors((0,o.mr)(a.A` :host{forced-color-adjust:none;background:${i.A.Canvas};box-shadow:0 0 0 1px ${i.A.CanvasText}}`))}}]);