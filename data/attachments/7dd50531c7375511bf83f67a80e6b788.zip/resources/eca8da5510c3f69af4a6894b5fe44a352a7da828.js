"use strict";(self.viewsWebpackChunks=self.viewsWebpackChunks||[]).push([["consumption-page"],{34625(t,e,i){i.d(e,{Aw(){return $},K1(){return S},M(){return u},M_(){return _},Mw(){return T},O3(){return p},VE(){return d},Vj(){return F},Vq(){return b},XM(){return R},_8(){return c},a1(){return h},aO(){return x},bX(){return l},iN(){return w},ik(){return C},nV(){return m},qY(){return I},q_(){return f},tM(){return v},th(){return A},ts(){return k},xp(){return y},zC(){return g}});var r=i(59669),s=i(22131),o=i(25975),n=i(32257),a=i(75117);const c=r.A`
    :host {
        --cstm-foreground-ctrl-neutral-primary-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(2%) saturate(1678%) hue-rotate(190deg) brightness(95%) contrast(96%);
        --cstm-foreground-ctrl-neutral-primary-pressed-filter: brightness(0) saturate(100%) invert(64%) sepia(10%) saturate(836%) hue-rotate(188deg) brightness(89%) contrast(89%);
        --cstm-foreground-ctrl-neutral-secondary-rest-filter: brightness(0) saturate(100%) invert(56%) sepia(80%) saturate(138%) hue-rotate(190deg) brightness(85%) contrast(82%);
        --cstm-foreground-ctrl-on-subtle-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(3%) saturate(1502%) hue-rotate(191deg) brightness(95%) contrast(97%);
        --cstm-foreground-ctrl-on-brand-rest-filter: brightness(0) saturate(100%) invert(92%) sepia(3%) saturate(1158%) hue-rotate(190deg) brightness(97%) contrast(92%);
        --cstm-status-danger-tint-foreground-filter: brightness(0) saturate(100%) invert(63%) sepia(19%) saturate(1420%) hue-rotate(314deg) brightness(103%) contrast(95%);
        --cstm-subtle-button-border-color: rgba(255, 255, 255, 0.08);
        --cstm-status-informative-background: #E5EBFA;
        --cstm-status-informative-foreground: #000000;
        --cstm-foreground-ranked-badge: #798FD4;
        --cstm-status-warning-tint-foreground: #F3C357;
        --cstm-theme-color-accent-200: #1C2338;
    }
`,d=r.A`
    :host {
        --cstm-corner-media-outside-radius: calc(${o.y3Q} * ${o.MU6});
        --cstm-corner-media-inside-radius: calc(${o.xl2} * ${o.MU6});
        --cstm-corner-media-in-card: var(--cstm-corner-media-outside-radius) var(--cstm-corner-media-outside-radius) var(--cstm-corner-media-inside-radius) var(--cstm-corner-media-inside-radius);
    }
`,l=r.A`
    :host {
        --cstm-border-on-squircle-px: 1px;
        --cstm-foreground-ctrl-neutral-primary-rest-filter: brightness(0) saturate(100%) invert(10%) sepia(8%) saturate(616%) hue-rotate(341deg) brightness(94%) contrast(88%);
        --cstm-foreground-ctrl-neutral-primary-pressed-filter: brightness(0) saturate(100%) invert(30%) sepia(4%) saturate(768%) hue-rotate(329deg) brightness(97%) contrast(86%);
        --cstm-foreground-ctrl-neutral-secondary-rest-filter: brightness(0) saturate(100%) invert(39%) sepia(2%) saturate(1223%) hue-rotate(335deg) brightness(91%) contrast(90%);
        --cstm-foreground-ctrl-on-subtle-rest-filter: brightness(0) saturate(100%) invert(10%) sepia(3%) saturate(2871%) hue-rotate(343deg) brightness(94%) contrast(88%);
        --cstm-foreground-ctrl-on-brand-rest-filter: brightness(0) saturate(100%) invert(90%) sepia(7%) saturate(146%) hue-rotate(345deg) brightness(101%) contrast(89%);
        --cstm-status-danger-tint-foreground-filter: brightness(0) saturate(100%) invert(15%) sepia(93%) saturate(4284%) hue-rotate(349deg) brightness(69%) contrast(91%);
        --cstm-status-danger-background-light: #AC1922;
        --cstm-status-danger-foreground-light: #FFFFFF;
        --cstm-status-informative-background: #272320;
        --cstm-status-informative-foreground: #FFFFFF;
        --cstm-foreground-ranked-badge: #A25A02;
        --cstm-status-warning-tint-foreground: #A25A02;
        --cstm-theme-color-accent-200: #FEE6D4;
        --cstm-subtle-button-border-color: rgba(0, 0, 0, 0.08);
        --cstm-background-flyout-linear-gradient: linear-gradient(0deg, ${n.RKA} 0%, ${n.RKA} 100%),
            linear-gradient(0deg, ${n.Pgz} 0%, ${n.Pgz} 100%),
            linear-gradient(0deg, ${n.oXU} 0%, ${n.oXU} 100%), ${o.vJX};
    }
`.withBehaviors((0,s.G2)("bingHomepage"!==a.T3.AppType?c:r.A``)),h="var(--cstm-foreground-ctrl-neutral-primary-rest-filter)",u="var(--cstm-foreground-ctrl-neutral-primary-pressed-filter)",p="var(--cstm-foreground-ctrl-neutral-secondary-rest-filter)",m="var(--cstm-foreground-ctrl-on-subtle-rest-filter)",g="var(--cstm-background-flyout-linear-gradient)",b=`${o.ry_} ${o.kf9} ${o.Ws$} 0px ${o.Ci3},\n    ${o.MSR} ${o.FeE} ${o.XES} 0px ${o.xEt}`,f="var(--cstm-border-on-squircle-px)",v="var(--cstm-corner-media-in-card)",y=`${o.yds} ${o.Tb$} ${o.ruk} ${o.FkA} ${o.fxR} inset, ${o.wvE} ${o.pTq} ${o.XLk} 0px ${o.VVH}`,w=`${o.Y4F} ${o.Rqs} ${o.rOe} 0px ${o.JMw}, 0px ${o.qcT} ${o.cjA} 0px ${o.I5k}`,x=`0px ${o.VVF} ${o.Ziq} 0px ${o.nWb}, 0px ${o.qcT} ${o.cjA} 0px ${o.I5k}`,$=`0px ${o.ZTc} ${o.$rc} 0px ${o.H2V}, 0px ${o.qcT} ${o.cjA} 0px ${o.I5k}`,k="var(--cstm-subtle-button-border-color)",A=`${o._SK} ${o.Tex} ${o.Dpq} 0px ${o.ze9}`,C="var(--cstm-status-danger-background-light)",F="var(--cstm-status-danger-foreground-light)",R="var(--cstm-status-informative-background)",S="var(--cstm-status-informative-foreground)",_="var(--cstm-foreground-ranked-badge)",T="var(--cstm-status-warning-tint-foreground)",I="var(--cstm-theme-color-accent-200)"},26779(t,e,i){i.d(e,{F6(){return s},Hx(){return d},NZ(){return l},XK(){return a},YP(){return o},Yn(){return c},er(){return r},uQ(){return n}});const r='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue",sans-serif',s='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue", "Microsoft YaHei",sans-serif',o='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans SC",sans-serif',n='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans JP",sans-serif',a='"Ginto Copilot Variable", "Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue","Noto Sans KR",sans-serif',c="Segoe UI, Segoe UI Midlevel, Segoe WP, Arial, sans-serif",d='"Segoe Sans", "Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue",sans-serif',l='"Segoe UI", "Segoe UI Web (West European)",-apple-system,BlinkMacSystemFont,Roboto,"Helvetica Neue", "Microsoft YaHei",sans-serif'},46026(t,e,i){i.d(e,{H(){return d}});var r=i(59669);const s=r.A`
    :host {
        --smtc-text-global-body1-font-size: 20px;
        --smtc-text-global-body2-font-size: 15px;
        --smtc-text-global-body2-line-height: 20px;
    }
`,o=r.A`
    :host {
        --smtc-text-global-subtitle1-line-height: 28px;
    }
`,n=r.A`
    :host {
        --smtc-text-style-default-header-weight: 550;
    }
`,a=r.A`
    :host {
        --smtc-text-ramp-lg-item-body-font-size: 17px;
    }
`,c=r.A`
    :host {
        --smtc-text-global-title1-font-size: 28px;
        --smtc-text-global-title2-font-size: 24px;
        --smtc-text-global-title2-line-height: 31px;
    }
`,d=r.A`
    ${s}
    ${o}
    ${c}
    ${n}
    ${a}
`},99563(t,e,i){i.d(e,{y(){return o}});var r=i(75117),s=i(94108);class o{constructor(t,e,i){this.k=t,this.B=e,this.j=i}connectedCallback(t){const{source:e}=t;"zh-cn"===r.T3.CurrentMarket?this.j&&s.Rb.CurrentFlightSet.has(this.j)?(e.$fastController.addStyles(this.B),e.$fastController.removeStyles(this.k)):(e.$fastController.addStyles(this.k),e.$fastController.removeStyles(this.B)):(e.$fastController.removeStyles(this.k),e.$fastController.removeStyles(this.B))}}},33544(t,e,i){i.d(e,{P(){return s}});var r=i(94108);class s{constructor(t,e){this.j=t,this.k=e}connectedCallback(t){const{source:e}=t;r.Rb.CurrentFlightSet.has(this.j)?e.$fastController.addStyles(this.k):e.$fastController.removeStyles(this.k)}}},15189(t,e,i){i.d(e,{l(){return s},o(){return r}});const r=()=>{if(!window?.matchMedia||!window.matchMedia("(forced-colors: active)")?.matches)return null;const t=window.getComputedStyle(document.documentElement).backgroundColor.toLowerCase();let e=0,i=0,r=0;if(t.startsWith("#")){let s=t.replace("#","");3===s.length&&(s=s.split("").map(t=>t+t).join("")),e=parseInt(s.substring(0,2),16),i=parseInt(s.substring(2,4),16),r=parseInt(s.substring(4,6),16)}else{const s=t.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);s&&(e=parseInt(s[1]),i=parseInt(s[2]),r=parseInt(s[3]))}return e>220&&i>220&&r>220?"light":"dark"};class s{constructor(t,e){this.q=t,this.X=e,this._sourceList=[],this._mediaQuery=null,this._handleChange=()=>{const t=r();this._sourceList&&0!==this._sourceList.length&&this._sourceList.forEach(e=>{e&&e.bgtheme!==t&&(e.bgtheme=t,"light"===t?e.$fastController.addStyles(this.X):e.$fastController.removeStyles(this.X),"dark"===t?e.$fastController.addStyles(this.q):e.$fastController.removeStyles(this.q))})}}connectedCallback(t){const{source:e}=t;this._sourceList||(this._sourceList=[]),this._sourceList.includes(e)||this._sourceList.push(e),!this._mediaQuery&&window?.matchMedia&&(this._mediaQuery=window.matchMedia("(forced-colors: active)"),this._addMediaQueryListener()),this._handleChange()}disconnectedCallback(t){const e=t?.source;if(e&&this._sourceList){const t=this._sourceList.indexOf(e);t>=0&&this._sourceList.splice(t,1)}this._sourceList&&0===this._sourceList.length&&(this._removeMediaQueryListener(),this._mediaQuery=null)}_addMediaQueryListener(){"function"==typeof this._mediaQuery?.addEventListener?this._mediaQuery.addEventListener("change",this._handleChange):"function"==typeof this._mediaQuery?.addListener&&this._mediaQuery.addListener(this._handleChange)}_removeMediaQueryListener(){"function"==typeof this._mediaQuery?.removeEventListener?this._mediaQuery.removeEventListener("change",this._handleChange):"function"==typeof this._mediaQuery?.removeListener&&this._mediaQuery?.removeListener(this._handleChange)}}},40764(t,e,i){i.r(e),i.d(e,{closeIcon(){return ot},BANNER_AD_MARGIN_PADDING_BOTTOM_RUBY(){return ut},CONSUMPTION_PAGE_WIDTH_4_COL(){return gt},RUBY_STICKY_BANNER_ACTIVATION_WINDOW_MS(){return At},CONTENT_PEEK_HEIGHT(){return $t},RUBY_BANNER_AD_MIN_HEIGHT(){return at},CONSUMPTION_PAGE_WIDTH_2_COL(){return ft},LoadedPageTemplate(){return Ui},ErrorTemplate(){return Yi},BANNER_AD_MIN_HEIGHT(){return nt},BANNER_AD_HEIGHT_SMALL(){return ct},trendingNewsRRIcon(){return it},arrowDownIcon(){return st},viewsPageId(){return wt},getBottomOffsetBasedOnViewport(){return xt},CONSUMPTION_PAGE_WIDTH_5_COL(){return mt},staticInstanceIdSlots(){return pt},SUPPORT_PADDING_FOR_CLASSIC_GA_HOVER_EFFECT(){return vt},ConsumptionPage(){return we},ContentTypeToTelemetryContentTypeMap(){return yt},CONTENT_PEEK_RRAD_GAP(){return kt},RUBY_STICKY_BANNER_CLASSES(){return Ct},BANNER_AD_HEIGHT_LARGE(){return dt},trendingNowRefreshIcon(){return rt},BannerAdTemplate(){return wi},ConsumptionPageTemplate(){return Xi},BANNER_AD_MARGIN_PADDING_BOTTOM(){return ht},CONSUMPTION_PAGE_WIDTH_3_COL(){return bt},shouldRenderAboveRiverBlock(){return Wi},ConsumptionPageStyles(){return lr},BANNER_AD_PADDING_TOP(){return lt},BannerTemplate(){return xi},ToolingInfo(){return hr}});var r=i(56911),s=i(61473),o=i(2684),n=i(30101),a=i(57531),c=i(36261);const d={article:"article_content",slideshow:"gallery_content",video:"video_content",webcontent:"video_content",manga:"manga_content",GemArticle:"gem_content",GemRail:"gem_content"};var l=i(61043),h=i(24895),u=i(74079),p=i(25523),m=i(95629),g=i(58581),b=i(13267),f=i(34120),v=i(44439),y=i(37630),w=i(26151),x=i(35363),$=i(76284),k=i(50980),A=i(69917),C=i(18091),F=i(64049),R=i(14881),S=i(22525),_=i(80044),T=i(90389),I=i(91384),B=i(78604),D=i(43803),P=i(77653),E=i(41293),z=i(8231),N=i(11076),O=i(84592),M=i(1661),H=i(46386),L=i(7446),V=i(90286),U=i(94108),W=i(87906),j=i(40450);const G=(t,e)=>{const{adPlacements:i,enableBannerstreamVideo:r,appNexusFlightKeywords:s,nativeAdConfigs:o,useLargeBannerContainer:n,useSimplifiedAppNexusLBSizing:a,useSmallBannerSize:c}=t,{enableExtraAdSlug:d,htmlId:l,instanceId:h,pageTypeOverride:u,providerIdBase62:p,providerIdBase32:m,requestIdOverride:g,subverticalKeyOverride:b,useSimplifiedRRSizing:f,verticalKeyOverride:v}=e,y=g||L.YT.getRequestId(),w=m||(t=>{let e;try{e=(0,V.$)(t,62,32)}catch(e){(0,W.vV)(j.LkX,"Error encoding CMS provider ID from base 62 to 32",`${e.message}. Could not encode provider id: ${t}`)}return e})(p)||"7HD66FC",x=u||U.Rb?.ClientSettings?.pagetype,$=v||U.Rb?.ClientSettings?.verticalKey||"",k=((t,e,i,r)=>{if(!t?.length)return;const s=`${i}_${r}`,o=[`${e}_${s}`,s,i,r,"default"];for(const e of o){const i=t.find(t=>t.adName.toLowerCase()===e.toLowerCase());if(i)return i}})(i,b||U.Rb?.ClientSettings?.categoryKey||"",$,h),A=n&&k?.adName?.includes("banner")||!1,C=r||k?.enableBannerstreamVideo||!1,F=((t,e,i)=>{if(!e||!t)return null;const r=e.adName?e.adName.toLowerCase():"";return r.indexOf("rectangle1")>=0?t.rectangle1:r.indexOf("rectangle2")>=0?t.rectangle2:r.indexOf("rectangle4")>=0?t.rectangle4:r.indexOf("banner")>=0?t.banner:"weather"==i?t.rectangle1:null})(o,k,$),R=F?.properties?.props?.enableNativeAdXandr||!1,S=k?.adName?.indexOf("banner")>=0;let _=S&&c?90:k?.appNexusAdsHeight,T=S&&c?728:k?.appNexusAdsWidth;return d&&(_=250,T=300),{enableNativeAdXandr:R,rid:y,providerIdBase32:w,pageType:x,placements:[{targetId:l,pageGroup:k?.pageGroup,width:T,height:_,useSimplifiedLBSize:a,remove300LBSize:A,useSimplifiedRRSize:f,flightKeywords:s,enableBannerstreamVideo:C,adName:k?.adName}]}};var K=i(47815);const Y=async(t,e,i,r)=>{const s=await t.getConfig(e.configRef),{enableExtraAdSlug:o,pageTypeOverride:n,providerId:a,requestIdOverride:c,subverticalKeyOverride:d,useSimplifiedRRSizing:l,verticalKeyOverride:h}=i,u={htmlId:r,enableExtraAdSlug:o,instanceId:e.instanceId,pageTypeOverride:n,providerIdBase62:a,requestIdOverride:c,subverticalKeyOverride:d,useSimplifiedRRSizing:l,verticalKeyOverride:h},p=G(s.properties,u);(0,K.xy)(p)};var q=i(71267),X=i(60624),Z=i(62690),Q=i(73686),J=i(47300),tt=i(98378),et=i(75117);const it=`${(0,et.rA)().StaticsUrl}latest/views/watch/icons/TrendingNewsRR.svg`,rt=`${(0,et.rA)().StaticsUrl}latest/fluent-icons/arrow_sync_20_regular.svg`,st=`${(0,et.rA)().StaticsUrl}latest/fluent-icons/arrow_circle_down_20_filled.svg`,ot=`${(0,et.rA)().StaticsUrl}latest/views/icons/Close.svg`,nt=112,at=114,ct=110,dt=270,lt=4,ht=32,ut=40,pt=["bannerAd","topDisplayAd","bottomDisplayAd","publisherSubscribeFollowButton"],mt=(0,Q.Rs)(20,19),gt=(0,Q.Rs)(16,15),bt=(0,Q.Rs)(12,11),ft=(0,Q.Rs)(8,7),vt=20,yt=new Map([[n.i.Article,tt.b5.Article],[n.i.Gallery,tt.b5.Gallery],[n.i.Video,tt.b5.Video],[n.i.Webcontent,tt.b5.WebContent]]),wt=t=>`ViewsPageId-${t}`,xt={[J.j1.c5]:332,[J.j1.c4]:642,[J.j1.c3]:642,[J.j1.c2]:0,[J.j1.c1]:0},$t=168,kt=40,At=3e3,Ct=["ruby-sticky-banner","ruby-sticky-banner-visible","ruby-sticky-banner-exit"];var Ft=i(44646),Rt=i(99215),St=i(23183),_t=i(84289),Tt=i(46376),It=i(66591),Bt=i(31157),Dt=i(60815),Pt=i(38493),Et=i(73632),zt=i(2018),Nt=i(70399),Ot=i(66546),Mt=i(85652),Ht=i(11720),Lt=i(36909),Vt=i(87960),Ut=i(86987),Wt=i(68537),jt=i(58319),Gt=i(51856),Kt=i(8098),Yt=i(5917),qt=i(43190),Xt=i(83593),Zt=i(47725),Qt=i(44704),Jt=i(61285);const te=(t,e=!1)=>e?n.e.Manga:t;var ee=i(15135),ie=i(46082),re=i(91277);const se=new Map([["article","ArticlePage"],["gallery","GalleryPage"],["video","VideoPage"]]);var oe=i(55265);function ne(t,e){if(!t)return;const i=Object.entries(t);for(const[t,r]of i)!pt.includes(t)&&r&&(r.instanceId=r.instanceId||"",r.instanceId+="_"+e)}var ae=i(57566),ce=i(46120),de=i(88620);function le(t,e,i){if(!i.disableAds)return{contentId:t.id,mappedPageType:i.mappedPageType,partnerId:a.kw.get(t.type)||"",pageNumber:i.infiniteReadingContext?.scrollDepth||1,enableNativeAdXandr:(0,c.G)(e||{},c.T.enableNativeAdXandr)}}var he=i(66146),ue=i(49415),pe=i(7547),me=i(51496);function ge(t,e){const{category:i,vertical:r}=(0,E.G)(t,Boolean(e));return{jsonDataMap:t.jsonDataMap,category:i,vertical:r,scoredCategories:t.scoredCategories}}var be=i(90499);async function fe(t,e,i){let r;switch(t.type){case n.i.Article:r=(0,ce.o)(t,e.featureFlags,i);break;case n.i.Gallery:r=(0,de.K)(t,e.featureFlags,i);break;case n.i.Video:case n.i.Webcontent:t.type!==n.i.Webcontent||e?.featureFlags?.enableRubyConsumptionView||(0,be.P)(t.type),r=function(t,e){const{vertical:i,category:r}=(0,E.G)(t,Boolean(e.useTeraForVerticalData));return{videoData:t,vertical:i,category:r,inStreamVideoAd:{verticalKeyOverride:i,pageTypeOverride:"video"},addRelatedPlayListOverride:!e.shouldShowPauseEndSlate}}(t,i);break;default:(0,be.P)(t.type)}return{aboveRiverBlock:le(t,e.featureFlags,i),actionTray:(0,he.c)(t,e.featureFlags),bannerAd:(0,A.D)(e.featureFlags,i,t.id,t.type,t),content:{id:t.id,context:r},endOfContentBlock:(0,ue.H)(t,e.componentConfigs?.endOfContentBlockConfigs,e.localizedStrings?.endOfContentBlock,e.featureFlags,i),header:(0,pe.J)(t,e.featureFlags),rail:(0,me.W)(t,e.componentConfigs?.rightRailConfigs,e.localizedStrings?.rightRail,i),topSpan:ge(t,i.useTeraForVerticalData)}}var ve=i(36042),ye=i(87944);class we extends ie.U{contentTypeChanged(){this.contentType===n.i.Article?this.expTTVRDependentList.set(a.xP.ArticleContent,-1):this.markInfiniteReadingTTVRIfNeeded(),(async t=>{switch(t){case n.i.Article:return await Promise.all([i.e("web-components_article-page-wc_dist_index_js"),i.e("cs-core-desktop_libs_dist_design-system_design-units_js")]).then(i.bind(i,35125));case n.i.Gallery:return await Promise.all([i.e("card-action-dist"),i.e("libs_ad-service_dist_BeaconService_js"),i.e("libs_ad-service_dist_VideoPropsMapper_js-libs_ad-service_dist_template-selection_config-descr-804c31"),i.e("libs_ad-service_dist_NativeAdService_js"),i.e("web-components_slideshow-base_dist_slideshow-components_immersive-slideshow_index_js"),i.e("web-components_slideshow-base_dist_index_js"),i.e("libs_views-base-class-utils_dist_ViewsBaseElementClass_js-libs_views-helpers_dist_slideshow_S-781d95")]).then(i.bind(i,92130));case n.e.Manga:return await Promise.all([i.e("common-feed-libs"),i.e("libs_super-component-theme_dist_SuperComponentTheme_helper_js-node_modules_cs-core_design-sys-aaae0a"),i.e("web-components_manga-page-wc_dist_index_js")]).then(i.bind(i,66004));default:;}})(te(this.contentType,this.useMangaWCPage))}getDisplayAdHtmlId(t,e){if(!t||!e)return(0,W.vV)(j.L8j,"Missing contentId or instanceId in config","",{contentId:t,instanceId:e}),void(this.enablePrefetchDisplay=!1);const i=`${t}_${e}`;let r=this.displayAdHtmlIds.get(i);return r||(r=e+"_"+(0,Zt.DA)(),this.displayAdHtmlIds.set(i,r)),r}get contentProviderCardConfig(){const t=this.contentProps?.rail?.config.slots.providerCarousel;if(t?.configRef)return{...t,instanceId:`${t?.instanceId}-${this.contentId}`}}get useRightRailMoreFromCard(){return Boolean((0,c.G)(this.config.featureFlags||{},c.T.enableRightRailMoreFromCard)&&this.config.featureFlags?.enableRubyConsumptionView&&this.contentType===n.i.Article&&this.isRubyRightRail&&!this.isRailBelow&&this.contentProviderCardConfig)}get bannerAdStyles(){const t=this.useLargeBannerContainer&&!this.config.enableResponsiveBannerAds?`height: ${(0,ye.c)(this.bannerAdHeight)};`:"";return`top: ${this.commonHeaderHeight}px; margin-inline-start: ${this.bannerAdStart}px;${t}`}_UpdateRubyBannerAdStyles(){if(this.headerHeight=0,"undefined"==typeof window)return;const t=document.querySelector("msn-unified-consumption")?.shadowRoot;if(!t)return;const e=t.querySelector?.(".msn-header");if(e){const t=this.config.enableResponsiveBannerAds?0:20;this.headerHeight=e.offsetHeight+t}if(this.bannerAdRef){const t=this.config.enableResponsiveBannerAds,e=t?ut:ht,i=t?0:ht;this.rubyStickyBannerSize=this.bannerAdRef.offsetHeight,this.stickyBannerSizeStyle=`--ruby-sticky-banner-size:${this.rubyStickyBannerSize+this.headerHeight+i}px;`,this.stickyBannerAdStyle=`--headerHeight:${this.headerHeight}px;--ruby-sticky-banner-margin:${this.rubyStickyBannerSize+e}px;--bannerPaddingBottom:${i}px;`}}get bkNewsStyles(){return`margin-inline-start: ${this.bannerAdStart}px;`}get riverHeadingClassnames(){return(0,It.x)(this.config.centralizedUx?"consumption-page-river-heading-centralized":"consumption-page-river-heading","consumption-page-river-heading-ext",["arb-style-header",Boolean(this.config.slots.aboveRiverBlock)])}get contentAreaClassname(){const t=d[te(this.contentType,this.useMangaWCPage)];if("gallery_content"!==t||!(0,c.G)(this.config.featureFlags||{},c.T.enableAutoGalleryHeight))return this.contentType?t:""}get displayAdWebComponentName(){return(0,re.cQ)((0,oe.lKb)(s.Wi9))}get errorText(){switch(this.errorState){case 1:return this.config.localizedStrings?.goneMessage;case 2:return this.config.localizedStrings?.missingMessage;default:return this.config.localizedStrings?.errorMessage}}get isRightRailReady(){return this.columnArrangement!==J.j1.c1&&this.config.componentConfigs?.rightRailConfigs&&(this.contentProps?.rail||this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)}get rightRailTopPosition(){return 0===this.commonHeaderHeight?0:this.bannerAdRef?80:127}get isRubyRightRail(){const t=this.config.enableBigRRAdWithViewport,e=this.config.featureFlags?.enableBigRRAd,i=this.getRightRailViewportCheck(t,e),r=this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2;return Boolean(this.config.featureFlags?.enableRubyRightRail)&&(e||t?i:r||i)&&Boolean(this.config.componentConfigs?.rightRailConfigs)&&(Boolean(this.contentProps?.rail)||this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)}getRightRailViewportCheck(t,e){if(t)return this.bigRRViewportValid;if(!(0,Et.S)())return!0;const i=e?a.CD:974;return window.matchMedia(`(min-width: ${(0,ye.c)(i)})`).matches}get isRubyRightRailSticky(){return this.isRubyRightRail&&(0,c.G)(this.config.featureFlags||{},c.T.enableRubyRailSticky)}get isRRStickyForLinearFeed(){return this.isRubyRightRailSticky&&(0,c.G)(this.config.featureFlags||{},c.T.enableRRStickyForLinearFeed)&&!this.trendingNowData&&!this.isExplodedFeedContent}get isRubyRightRailAds(){return this.isRubyRightRail&&(0,c.G)(this.config.featureFlags||{},c.T.enableRubyRightRailAds)}get consumptionPageContentHeaderStyles(){return(0,It.x)("consumption-page-content-header",["consumption-page-content-header-no-border",Boolean(this.config.slots?.socialBarWC)||Boolean(this.config.featureFlags?.enableRubyConsumptionView)],["consumption-page-content-header-ss",(0,c.G)(this.config.featureFlags,c.T.enableGalleryHeaderMatchWidth)&&this.contentType===n.i.Gallery],["consumption-page-content-header-no-topmargin",!this.commonHeaderHeight],["align-left",!!this.config.featureFlags?.enableAlignLeft])}get bannerHeight(){return this.bannerAdHeight+this.bknewsBannerHeight}get shouldRenderActionTray(){return this.config.slots.actionTray&&this.contentProps?.actionTray&&!this.shouldRenderMobileATForDesktop&&!this.isFloatingSocialBarForRubyFeatureEnabled}get shouldRenderMobileActionTray(){return this.config.slots.actionTray&&this.contentProps?.actionTray&&(this.shouldRenderMobileATForDesktop||this.isFloatingSocialBarForRubyFeatureEnabled)}get deferRenderingRiver(){return(0,c.G)(this.config.featureFlags||{},c.T.deferRiverRendering)&&!this.isMainContent()&&!(this.getInitializedPromise()&&this.contentInitialized)}get hideRiver(){return Boolean(this.config.hideRiverWhenMsnReferrer&&(0,l.YC)())||Boolean(this.config.hideRiverWhenWPORiverFailed&&this.isWPORiverFailed)}get isFloatingSocialBarForRubyFeatureEnabled(){return this.config.featureFlags?.enableFloatingSocialBarT2||this.config.featureFlags?.enableFloatingSocialBarT3}get isMobileATCondition(){return window.matchMedia(`(max-width: ${a.ug}px)`).matches}get isNotEnoughSizeForDesktopAT(){return window.matchMedia(`(min-width: ${a.ug+1}px) and (max-width: ${a.Zn}px)`).matches}get shouldRenderAIConversationStarters(){return!this.noCopilotAPI&&(this.config?.infiniteCopilotFeats||this.isMainContent()||this.isExplodedFeedContent)&&this.config?.enableRubyAiConvStarter&&"AAD"!==(0,Mt.eM)().accountType&&!this.contentProps?.header?.disableCopilotButtons}constructor(){super(),this.useMangaWCPage=!1,this.enableBigRRAd=!1,this.enableBigRRAdWithViewport=!1,this.enableRubyStickyBanner=!1,this.bigRRViewportValid=!0,this.actionTrayGridAreaStyles="",this.actionTrayWrapperStyles="",this.commonHeaderHeight=0,this.consumptionPageContentHeight=0,this.showOneRowContent=!1,this.consumptionPageContentRefChanged=()=>{window.setTimeout(()=>{this.consumptionPageContentHeight=this.consumptionPageContentRef?.getBoundingClientRect().height||0})},this.consumptionPageRefChanged=()=>{window.setTimeout(()=>{this.consumptionPageRef&&this.attachObserverToPageContainer()})},this.hasFullyScrolledMainContent=!1,this.relatedVideosFetched=!1,this.expForPriorityLoading=[],this.dwellTimeStartAllowedClassName="",this.isImmersiveFullscreenOpen=!1,this.isRailBelow=!1,this.railBelowLoaded=!1,this.railRightLoaded=!1,this.viewsHeaderHeight=0,this.dataClarityRegion="",this.viewsHeaderRefChanged=()=>{this.viewsHeaderRef&&(this.config?.featureFlags?.enableWidgetsConsumptionView&&void 0!==window.IntersectionObserver&&this.viewsHeaderVisibilityChange&&(this.viewsHeaderRefIntersectionObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver=new window.IntersectionObserver((t,e)=>{this.viewsHeaderVisibilityChange?.(this.contentId,t,e)}),this.viewsHeaderRefIntersectionObserver.observe(this.viewsHeaderRef)),this.isFloatingSocialBarForRubyFeatureEnabled&&void 0!==window.IntersectionObserver&&(this.viewsHeaderRefIntersectionObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver=new window.IntersectionObserver(t=>{t.forEach(t=>{t.isIntersecting&&(this.contentData?.type===n.i.Video?document.dispatchEvent(new CustomEvent("hideFloatingSocialBar")):this.triggerFloatingActionTrayOnDesktop())})}),this.viewsHeaderRefIntersectionObserver.observe(this.viewsHeaderRef)),window.setTimeout(()=>{this.viewsHeaderRef&&(this.setBannerAdStart(),this.viewsHeaderHeight=this.viewsHeaderRef?.getBoundingClientRect().height||0,this.startRRStickyForLinearFeedTracking())}))},this.bannerAdStart=0,this.shouldRenderEoabLeadgen=!1,this.disableAds=!1,this.isOneRowContentReady=!1,this.bannerAdHeight=0,this.bknewsBannerHeight=0,this.visibleBannerAdHeight=0,this.contentWrapperWidth="",this.enableNativeAdXandr=!1,this.zhCnNativeAdsRefresh=!1,this.zhCnNativeAdsRefreshRate=1,this.tallerRightRailAdOnTop=!1,this.enableDisplayAdKeyValuePairs=!1,this.delayDisplayAds=!1,this.enableNativeAdKeyValuePairs=!1,this.enableAdKeyValuePairs=!1,this.usePolishedStyles=!1,this.keyTakeawaysData=[],this.keyTakeawaysCollapsed=!0,this.renderKeyTakeawaysSection=!1,this.enableCopilotTheme=(0,Ht.l)(),this.keyTakeawaysTelemetryObjects={},this.enablePrefetchDisplay=!1,this.useTeraForVerticalData=!1,this.displayAdHtmlIds=new Map,this._resizeRefreshInFlight=!1,this.markTimeToVisuallyReadyCalled=this.previouslyInit,this.expTTVRDependentList=new Map([[a.xP.ViewsContentHeader,-1],[a.xP.ViewsContentProvider,-1]]),this.viewsContentTopicId="",this.riverTMPLStamped=!1,this.redirectUrl="",this.stabilizeBannerAdSize=!1,this.useLargeBannerContainer=!1,this.contentInitialized=!1,this.gridOverriddenStyle="",this.stickyBannerAdStyle="",this.stickyBannerSizeStyle="",this.shouldRenderMobileATForDesktop=!1,this.updateBottomAdSticky=()=>{const t=this.rubyRailBottomAdRef,e=this.rubyRightRailRef;if(!t||!e)return;const i=e.getBoundingClientRect(),r=80+t.offsetHeight,s=t.classList.contains("is-fixed"),o=s?i.bottom<r+64:i.bottom<r+32;o&&!s?t.classList.add("is-fixed"):!o&&s&&t.classList.remove("is-fixed")},this.rubyRailBottomAdRefChanged=()=>{this.rubyRailBottomAdRef&&(0,Et.S)()&&(this.startRRStickyForLinearFeedTracking(),this.updateBottomAdSticky())},this.articleBannerPlacementSignals=new Map,this.isOneRowContentHidden=!1,this.convoStarterVisible=!1,this.conversationStartersIframeStyles="",this.displayCSAT=!1,this.headerHeight=0,this.rubyStickyBannerSize=0,this.rubyStickyBannerClass="",this.updateBigRRViewportValid=()=>{if(!this.enableBigRRAdWithViewport||!(0,Et.S)())return;const t=window.matchMedia(`(min-width: ${(0,ye.c)(a.SU)})`).matches,e=window.matchMedia(`(min-height: ${(0,ye.c)(a.t6)})`).matches;this.bigRRViewportValid=t&&e},this.rrStickyRAFId=0,this.rrStickyTrackingStarted=!1,this.startRRStickyForLinearFeedTracking=()=>{const t=!!this.contentProps?.rail?.config?.slots?.bottomDisplayAd;(this.isRRStickyForLinearFeed||t)&&(this.rrStickyTrackingStarted||(window.addEventListener("scroll",this.onRRStickyScroll,{passive:!0}),this.rrStickyTrackingStarted=!0),(this.enableBigRRAdWithViewport||this.enableBigRRAd)&&!this.rrStickyHeaderResizeObserver&&void 0!==window.ResizeObserver&&this.consumptionPageViewsHeaderAreaRef&&(this.rrStickyHeaderResizeObserver=new window.ResizeObserver(()=>{this.updateRRStickyPaddingTop()}),this.rrStickyHeaderResizeObserver.observe(this.consumptionPageViewsHeaderAreaRef)),this.updateRRStickyPaddingTop(),this.updateBottomAdSticky())},this.stopRRStickyForLinearFeedTracking=()=>{window.removeEventListener("scroll",this.onRRStickyScroll),this.rrStickyTrackingStarted=!1,this.rrStickyRAFId&&(cancelAnimationFrame(this.rrStickyRAFId),this.rrStickyRAFId=0),this.rrStickyHeaderResizeObserver?.disconnect(),this.rrStickyHeaderResizeObserver=void 0},this.onRRStickyScroll=()=>{this.rrStickyRAFId||(this.rrStickyRAFId=window.requestAnimationFrame(()=>{this.rrStickyRAFId=0,this.updateRRStickyPaddingTop(),this.updateBottomAdSticky()}))},this.updateRRStickyPaddingTop=()=>{if(!this.viewsHeaderRef||!this.rubyRightRailRef||this.contentProps?.rail?.config?.slots?.bottomDisplayAd)return;const t=this.rubyRightRailRef.firstElementChild;if(!t)return;const e=this.viewsHeaderRef.getBoundingClientRect().bottom,i=Math.max(0,e-80);t.style.paddingTop=`${i}px`},this.rubyRightRailRefChanged=()=>{if(!this.rubyRightRailRef)return;const t=this.enableBigRRAdWithViewport||this.enableBigRRAd,e=!!this.contentProps?.rail?.config?.slots?.bottomDisplayAd;(t||e)&&window.requestAnimationFrame(()=>{this.startRRStickyForLinearFeedTracking()})},this.isWPORiverFailed=!1,this.onWPORiverFailedChanged=({detail:t})=>{this.isWPORiverFailed=t.isWPORiverFailed},this.noCopilotAPI=!1,this.loadOneRowRubyContent=async()=>{const t="true"===(0,Lt.n)(Vt.sy);if(this.config.enableOneRowContent&&this.config?.featureFlags?.enableRubyConsumptionView&&this.viewsFullPageConnector&&(!(0,Ut.T)()||t)&&!this.isLastContent)try{const{registerConsumptionMiniFeed:t}=await Promise.all([i.e("common-feed-libs"),i.e("card-action-dist"),i.e("consumption-mini-feed")]).then(i.bind(i,37070));t(),this.showOneRowContent=!0}catch(t){(0,W.c_)(t,j.pW_,"Error importing consumption-mini-feed from consumption page")}else this.showOneRowContent=!1},this.triggerFloatingActionTrayOnDesktop=async()=>{if(!this.isFloatingSocialBarForRubyFeatureEnabled)return;const t=new CustomEvent("updateATFloatingBar",{detail:{previousContentId:"",contentId:this.contentId}});document.dispatchEvent(t)},this.initializeContent=()=>{this.infiniteReadingContext?.initializedPromise?.then(()=>{this.contentInitialized=!0})},this.setExperimentalValues=()=>{this.useMangaWCPage=this.isMangaContent(),this.enableNativeAdXandr=this.shouldEnableNativeAdXandr(),this.enableNativeAdKeyValuePairs=(0,c.G)(this.config.featureFlags||{},c.T.setNativeKvp),this.enableDisplayAdKeyValuePairs=(0,c.G)(this.config.featureFlags||{},c.T.setDisplayKvp),this.enableAdKeyValuePairs=this.enableNativeAdKeyValuePairs||this.enableDisplayAdKeyValuePairs||(0,c.G)(this.config.featureFlags||{},c.T.setVideoKvp),this.delayDisplayAds=(0,c.G)(this.config.featureFlags||{},c.T.setDisplayKvp),this.zhCnNativeAdsRefresh=(0,c.G)(this.config.featureFlags,c.T.zhCnNativeAdsRefresh),this.tallerRightRailAdOnTop=(0,c.G)(this.config.featureFlags,c.T.tallerRightRailAdOnTop),this.stabilizeBannerAdSize=(0,c.G)(this.config.featureFlags,c.T.stabilizeBannerAds),this.useLargeBannerContainer=(0,c.G)(this.config.featureFlags,c.T.useLargeBannerContainer),this.usePolishedStyles=(0,c.G)(this.config.featureFlags,c.T.usePolishedStyles),this.enablePrefetchDisplay=(0,c.G)(this.config.featureFlags,c.T.enablePrefetchDisplay),this.useTeraForVerticalData=(0,c.G)(this.config.featureFlags||{},c.T.useTeraForVerticalData)},this.loadDisplayAds=()=>{this.enableDisplayAdKeyValuePairs&&this.delayDisplayAds&&(this.delayDisplayAds=!1,this.enablePrefetchDisplay&&(this.shouldRenderBannerAd&&this.bannerAdConfig?.htmlId&&Y(Wt.L,this.config.slots.bannerAd,this.bannerAdConfig,this.bannerAdConfig.htmlId),this.checkTopDisplayAdPrefetch()&&this.extraInfoForRightRailTopDisplayAd?.htmlId&&Y(Wt.L,this.contentProps?.rail?.config.slots.topDisplayAd,{...this.contentInfoForRightRailAd,...this.extraInfoForRightRailTopDisplayAd},this.extraInfoForRightRailTopDisplayAd.htmlId)))},this.resizeObserverCallback=()=>{this.resizeObserverBehavior(!1,!!this.gridOverriddenStyle),this.updateBottomAdSticky()},this.resizeObserverBehavior=(t,e)=>{this.updateBannerAdStyle(),window.requestAnimationFrame(()=>{this.updateRightRailVisibility(),this.updateBigRRViewportValid(),(this.enableBigRRAdWithViewport||this.enableBigRRAd)&&this.updateRRStickyPaddingTop();const i=this.getTopBnrRszTreatment();i&&this.updateBannerAdSizeForViewport(i),this.actionTrayGridAreaStyles=this.getActionTrayGridAreaStyles(),this.actionTrayWrapperStyles=this.getActionTrayWrapperStyles(),this.config.featureFlags?.enableExtendedRightRail?this.shouldRenderMobileATForDesktop=window.matchMedia(`(max-width: ${(0,ye.c)(a.kk)})`).matches:this.config.enableMobileATForTablet?this.shouldRenderMobileATForDesktop=this.isMobileATCondition:this.shouldRenderMobileATForDesktop=this.isFloatingSocialBarForRubyFeatureEnabled||this.columnArrangement===J.j1.c1,e&&this.consumptionPageGridStructureStyles(t)})},this.updateBannerAdSizeForViewport=t=>{const e=(0,q.iz)(window.innerWidth,t);if(void 0===this.extRRBannerZone)return void(this.extRRBannerZone=e);if(e===this.extRRBannerZone)return;this.extRRBannerZone=e,this.bannerAdHeight=0===e?we.largeBannerAdContainerHeight:we.smallBannerAdContainerHeight,this.visibleBannerAdHeight=this.bannerAdHeight,this.updateVisibleBannerAdHeight();const i=X.T.adPlacements?.find(t=>t.htmlId?.startsWith("banner"));if(!i?.options)return;const{width:r,height:s}=(0,q.lo)(window.innerWidth,t);i.options.adsVNextHeight=s,i.options.adsVNextWidth=r,this._resizeRefreshInFlight||i.refreshAdCallback&&(this._resizeRefreshInFlight=!0,i.refreshAdCallback(i))},this.updateBannerAdContainerHeight=t=>{const{height:e=0,targetId:i=""}=t;if(i.startsWith("banner")&&(this._resizeRefreshInFlight=!1),i.startsWith("banner")&&(0,c.G)(this.config.featureFlags||{},c.T.stampBannerAdHeight)&&(0,h.ut)(this.contentId,"bannerAdHeight",e.toString()),this.useLargeBannerContainer)return;const r=this.bannerAdRef?.querySelector(this.displayAdWebComponentName);r?.shadowRoot?.getElementById?.(i)?this.bannerAdHeight=e>ct+1?we.largeBannerAdContainerHeight:we.smallBannerAdContainerHeight:!r&&i.startsWith("banner")&&(this.bannerAdHeight=we.smallBannerAdContainerHeight),this.updateVisibleBannerAdHeight(),this.updateActionTrayStyles()},this.setCommonHeaderHeight=()=>{const t=this.commonHeaderRef;t&&(this.commonHeaderHeight=t.clientHeight,window.requestAnimationFrame(()=>{const e=t.clientHeight;e!==this.commonHeaderHeight&&(this.commonHeaderHeight=e)}))},this.markRiverVisibleTMPL=()=>{if(this.riverTMPLStamped||!this.riverElementRef)return;const t=(0,u.M)(this.riverElementRef);t>=0&&this.feedProps?.isInfiniteScrollFeed!==this.isInfiniteScrollFeed()&&(this.feedProps=this.getFeedData()),t>100&&(this.riverTMPLStamped=!0,(0,h.ut)(this.contentId,a.uB,"1"))},this.markFullyScrolledMainContent=()=>{if(!this.consumptionPageStructureRef)return;this.consumptionPageStructureRef.getBoundingClientRect().bottom<=(window.innerHeight||document.documentElement.clientHeight)&&(this.hasFullyScrolledMainContent=!0,(0,h.ut)(this.contentId,"eomc","1"),this.convoStarterVisible&&(0,h.ut)(this.contentId,"convosvisible"))},this.onScrollHandler=()=>{this.markRiverVisibleTMPL(),this.isMainContent()&&!this.hasFullyScrolledMainContent&&this.markFullyScrolledMainContent(),this.updateVisibleBannerAdHeight(),this.config.enableRubyStickyBanner&&this.isMainContent()&&this._updateRubyStickyVisibleBanner()},this.updateVisibleBannerAdHeight=()=>{const t=this.bannerAdRef?.getBoundingClientRect().top,e=this.commonHeaderRef?.getBoundingClientRect().bottom;if(null==t||null==e)return;const i=this.config.featureFlags?.enableTopBnrRszT1||this.config.featureFlags?.enableTopBnrRszT2?t+this.bannerAdHeight:this.bannerAdRef?.getBoundingClientRect().bottom;null!=i&&(this.visibleBannerAdHeight=t>e?this.bannerAdHeight:i>e?Math.max(i-e,0):0)},this.rubyStickyBannerVisible=!1,this.rubyStickyWindowOpen=!1,this.tt=()=>{this.rubyStickyWindowOpen=!0,this.rubyStickyBannerTimeoutId=window.setTimeout(()=>{this.rubyStickyWindowOpen=!1,this.rubyStickyBannerTimeoutId=void 0,this.rubyStickyBannerVisible&&this.et()},At)},this._updateRubyStickyVisibleBanner=()=>{if(!this.rubyStickyWindowOpen||this.isBannerAlreadySticky)return;(window.scrollY||window.pageYOffset||document.documentElement.scrollTop)>0&&(this.isBannerAlreadySticky=!0,this.rubyStickyBannerVisible=!0,this.rubyStickyBannerClass="ruby-sticky-banner-visible",this._UpdateRubyBannerAdStyles())},this.it=()=>{const t=this.bannerAdRef;if(!t)return null;const e=Ct.filter(e=>t.classList.contains(e));e.length>0&&t.classList.remove(...e);const i=t.getBoundingClientRect().top;return e.length>0&&t.classList.add(...e),i},this.rt=()=>{this.stickyBannerSizeStyle=`--ruby-sticky-banner-size:${we.RUBY_STICKY_BANNER_SIZE_DEFAULT_PX}px;`},this.et=()=>{this.rt();const t=this.it();this.st=t??void 0,this.ot=window.scrollY||window.pageYOffset||document.documentElement.scrollTop,null!=t&&this.style.setProperty("--ruby-sticky-banner-exit-translate",`${t}px`),this.rubyStickyBannerVisible=!1,this.rubyStickyBannerClass="ruby-sticky-banner-visible ruby-sticky-banner-exit",window.addEventListener("scroll",this.nt,{passive:!0}),this.rubyStickyBannerExitTimeoutId=window.setTimeout(this.ct,300)},this.nt=()=>{if(null==this.st||null==this.ot)return;const t=window.scrollY||window.pageYOffset||document.documentElement.scrollTop,e=this.st-(t-this.ot);this.style.setProperty("--ruby-sticky-banner-exit-translate",`${e}px`)},this.ct=()=>{window.removeEventListener("scroll",this.nt),this.rubyStickyBannerClass="",this.style.removeProperty("--ruby-sticky-banner-exit-translate"),this.st=void 0,this.ot=void 0,this.rubyStickyBannerExitTimeoutId=void 0},this.consumptionFeedActivityChange=t=>{t.detail?.contentId===this.contentId&&this.documentTitleCb&&this.documentTitleCb?.(this.contentData?.title)},this.setErrorState=t=>{t instanceof p.AD?this.errorState=1:t instanceof p.Rh?this.errorState=2:t instanceof TypeError?this.errorState=3:this.errorState=4},this.getAppErrorForErrorState=t=>t||(this.isMainContent()?1==this.errorState||2==this.errorState?j.dvI:3==this.errorState?j.j9X:j.PsF:j.Lf5),this.handleFatalError=async(t,e,i)=>{if(this.setErrorState(e),i=this.getAppErrorForErrorState(i),(0,W.vV)(i,t,`ContentId: ${this.contentId}`,{id:this.contentId,error:e}),this.isExplodedFeedContent)m.I.dwellTimePause(this.contentId);else{if(this.infiniteReadingContext?.markContentAsFailed&&!this.config.featureFlags?.enableRubyConsumptionView)return this.infiniteReadingContext.markContentAsFailed(this.contentId);this.infiniteReadingContext?.markContentAsFailed?.(this.contentId)}if(this.handleFatalErrorCallback&&this.handleFatalErrorCallback(this.contentId),this.isLoading=!1,this.infiniteReadingContext?.updateInitialContentLoadingState?.(2),this.isMainContent()||this.isExplodedFeedContent){if(this.enableConsumptionErrorPage=(0,c.G)(this.config.featureFlags||{},c.T.enableConsumptionErrorPage)||this.isExplodedFeedContent,await this.loadConsumptionErrorPage(),this.enableConsumptionErrorPage){(0,h.ut)(this.contentId,a.HA,"1"),this.redirectUrl=(0,jt.bI)(this.config.homepageUrl)??a.jb;const t=(0,Nt.Kl)();Ot.m.updateAboveTheFoldVisuallyReady.getActionSender(t).send(performance.now())}else(0,h.ut)(this.contentId,a.HA,"0"),this.config.featureFlags?.enableWidgetsConsumptionView||(this.redirectUrl=(0,g.FZ)(this.contentId,!0,this.infiniteReadingContext,this.config.homepageUrl),(0,b.bF)(this.redirectUrl));(0,f.p)().resolve(!1)}},this.getArticleBannerAdProperties=t=>{const e=(0,b.Ty)(t?.componentConfigs?.articlePageConfig?.edgeMappedPageType,t?.nativeAdMappedPageType??"");return{props:{adFetchHook:this.articleBannerAdBatchHook,storePlacementLevelSignals:this.addArticleBannerAdPlacementSignals,getPlacementLevelSignals:()=>this.articleBannerPlacementSignals,isFullWidth:!0,contentId:this.isMainContent()?void 0:this.contentId,isVerticalOrientation:!1,mappedPageType:e,partnerId:"article",enableNativeAdXandr:this.enableNativeAdXandr,placementIndex:0,skipCMSBackfill:(0,c.G)(t.featureFlags,c.T.collapseInarticleCMSAds)}}},this.mapContentDataToProps=async t=>{let e;if((this.config.componentConfigs?.slideshowConfigs?.featureFlags?.enableNextSlideshowCard||!this.config.featureFlags?.enableRubyConsumptionView&&!this.config.featureFlags?.enableWidgetsConsumptionView)&&t.type===n.i.Gallery){if(!this.viewsFullPageConnector.hasFetchStarted(this.contentId)){const t=this.infiniteReadingDynamicProps?this.infiniteReadingDynamicProps.hasInfiniteRiver:!this.config.featureFlags?.enableRubyConsumptionView;await this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),t,!1,!1,this.isLastContent)}const t=this.viewsFullPageConnector.getExperimentalSectionData(Rt.v.NextSlideshowContent,this.contentId),i=(0,c.G)(this.config.featureFlags||{},c.T.useWebPImageFormat);e=(0,v.h)(t,i)}const i={columnArrangement:this.columnArrangement,disableAds:this.disableAds,infiniteReadingContext:this.infiniteReadingContext,infiniteReadingDynamicProps:this.infiniteReadingDynamicProps,onToggleImmersiveFullscreen:this.onToggleImmersiveFullscreen,nextSlideshowPromise:e,telemetryObject:this.telemetryObject,requestIdOverride:this.isFirstLoadedContent()?void 0:this.getRequestIdOverride(),mappedPageType:this.config.nativeAdMappedPageType,shouldShowPauseEndSlate:this.config.componentConfigs.videoContentConfigs?.shouldShowPauseEndSlate,useTeraForVerticalData:this.useTeraForVerticalData};this.contentProps=await fe(t,this.config,i),this.setMainContentData?.(t)},this.checkTopDisplayAdPrefetch=()=>!(!(!(this.contentProps?.rail?.disableAds||this.isImmersiveFullscreenOpen||this.isExplodedFeedContent)&&this.contentInfoForRightRailAd)||!this.contentProps?.rail?.config.slots.topDisplayAd),this.loadAboveRiverBlockSection=()=>{this.config.slots.aboveRiverBlock&&this.viewsFullPageConnector.getAboveRiverBlockSectionCards(this.contentId).then(t=>{t?this.aboveRiverBlockData=t:(0,W.vV)(j.KXh,"Missing ARB section in WPO",`ContentId: ${this.contentId}`)}).catch(t=>{this.aboveRiverBlockData=[]})},this.getInitializedPromise=(()=>{let t;return()=>(!t&&this.infiniteReadingContext?.initializedPromise&&(t=this.infiniteReadingContext.initializedPromise.then(()=>{if(!this.inlineRefreshed||this.isConnected)return;const t="consumption page initialized after disconnecting";throw(0,W.vV)(j.G5T,t),new Error(t)})),t)})(),this.postTTVRCallback=async()=>{if((0,c.G)(this.config.featureFlags,c.T.deferRiverRendering,!1)&&!this.isMainContent())try{await this.getInitializedPromise()}catch{return}if(!this.inlineRefreshed||this.isConnected){this.markTimeToVisuallyReadyCalled||(this.markTimeToVisuallyReadyCalled=!0);try{this.loadTopSpanModuleContent(),this.loadAboveRiverBlockSection(),this.updateSeoTags(),this.updateLeadgen(),this.updateActionTrayStyles(),this.loadRubyViewsMetaInfo(),this.loadOneRowRubyContent(),this.isReadyForLoadMoreFromProvider()&&this.loadMoreFromProvider(),this.loadTrendingNow(),(0,_t.uR)().then(()=>{this.isMainContent()&&(0,b.Ig)()&&(0,W.vV)(j.oZ1,"Duplicate root element found in the DOM",`ContentId: ${this.contentId}`)}),this.initializeContextualFeedback()}catch(t){}}else(0,W.vV)(j.G5T,"consumption page postttvr initialized after disconnecting")},this.loadRubyViewsMetaInfo=()=>{const{updateDateTime:t,publishedDateString:e}=this.contentProps?.header||{},i=(0,b.DL)(t,e,this.actionBarStrings);this.publishedDateStringFormat=i.publishedDateStringFormat,this.publishedDateTimeString=i.publishedDateTimeString,this.publishedTimeStamp=i.publishedTimeStamp,this.updatedDateStringFormat=i.updatedDateStringFormat,this.updatedDateTimeString=i.updatedDateTimeString,this.updatedTimeStamp=i.updatedTimeStamp},this.isReadyForLoadMoreFromProvider=()=>!(!this.config.featureFlags?.enableRubyConsumptionView||!this.viewsFullPageConnector||this.contentType!==n.i.Article&&this.contentType!==n.i.Gallery),this.isFirstLoadedContent=()=>this.isMainContent()&&!this.inlineRefreshed,this.getActionTrayWrapperStyles=()=>{let t=(this.commonHeaderHeight??132)+8+this.bknewsBannerHeight;((0,c.G)(this.config.featureFlags||{},c.T.hideHeaderNavBar)||(0,c.G)(this.config.featureFlags||{},c.T.enableFixedAtTop))&&(t=119);const e=this.visibleBannerAdHeight;return`top: ${(0,ye.c)(t)}; transform: translateY(${(0,ye.c)(e)}); transition: transform 50ms ease-out;`},this.visibleBannerAdHeightChanged=()=>{this.updateActionTrayStyles()},this.commonHeaderHeightChanged=()=>{this.updateActionTrayStyles()},this.bknewsBannerHeightChanged=()=>{this.updateActionTrayStyles()},this.isMainContent=(0,Gt.L)(()=>!this.infiniteReadingContext||this.infiniteReadingContext.isMainArticle),this.removePageFromTheFeed=()=>{this.removeArticleFromTheProvider?.(this.contentProps?.header?.provider?.id||"",this.contentId)},this.onBreakpointCallback=t=>{this.columnArrangement=t,this.updateRightRailVisibility(),this.feedProps=this.getFeedData()},this.updateBannerAdStyle=()=>{this.setBannerAdStart();const t=this.commonHeaderRef?.clientHeight;t&&this.commonHeaderHeight!==t&&this.setCommonHeaderHeight()},this.setBannerAdStart=()=>{if(this.viewsHeaderRef)return U.Rb.MarketDir===Bt.O.rtl?(0,y.n)()?void(this.bannerAdStart=-Math.abs(window.innerWidth-this.viewsHeaderRef.offsetLeft-this.viewsHeaderRef.getBoundingClientRect().width)):void(this.bannerAdStart=-Math.abs(window.innerWidth-this.viewsHeaderRef.offsetLeft)):void(this.bannerAdStart=-Math.abs(this.viewsHeaderRef.offsetLeft))},this.updateLeadgen=()=>{const t=this.contentProps?.content;if(t){const{provider:e}=t.context?.articleData||t.context?.slideshowData||{};if(!e||!e.leadgen)return;this.updateLeadgenData(e)}},this.stampPagePZeroTTVR=(t,e)=>{if(!t||this.previouslyInit)return;const i=e||window.performance.now();this.isMainContent()&&!this.markTimeToVisuallyReadyCalled&&(0,_t.yi)(t,!1,i),this.trySetTTVRAndMilestone(t,i)},this.onToggleImmersiveFullscreen=()=>{this.isImmersiveFullscreenOpen=!this.isImmersiveFullscreenOpen},this.markInfiniteReadingTTVRIfNeeded=(()=>{let t=this.previouslyInit;return async()=>{if(t||this.isFirstLoadedContent()||this.config.featureFlags?.enableRubyGemReaderWidth)return;t=!0;let e=null;try{e=(0,Tt.cX)(`TTVR-${this.contentId}`,!0)}catch(t){L.YT.sendAppErrorEvent({...j.ohN,message:"Unable to mark refresh TTVR on infinite reading",pb:{...j.ohN.pb,customMessage:`Unable to mark refresh TTVR on infinite reading. ContentId: ${this.contentId} . Experience: ArticlePage . error:${t}`}})}const i=this.getInitializedPromise()||Promise.resolve();try{await i.then(()=>new Promise(t=>window.setTimeout(t)))}catch{return}if(e){const t={TTVR:e},i=a.iW[this.contentType];i&&(t[`TTVR.${i}`]=e);const r={markers:t};(0,h.gY)(this.contentId,r)}}})(),this.getTopSpanModuleContent=async t=>{if(!this.viewsFullPageConnector)return[];const e=await this.viewsFullPageConnector.getPageSectionData(this.contentId,Rt.v.TopSpan,1,this.config.localizedStrings,{shouldStampTMPL(e){return St.lq.has(e)&&!t}},this.topSpanTelemetryObject);return e?.length?e:[]},this.breakingNewsWillRender=(t=0)=>{this.bknewsBannerHeight=t},this.backToFeed=()=>{const t=(0,ae.I)();this.config.featureFlags?.enableRubyConsumptionView&&((0,Kt.op)()||t)&&(0,b.t1)(),this.redirectUrl&&!t&&window.open(this.redirectUrl,"_self")},this.loadConsumptionErrorPage=async()=>{if(this.enableConsumptionErrorPage)try{if(this.config.featureFlags?.enableRubyConsumptionView){const{RubyConsumptionErrorPageWC:t}=await i.e("web-components_ruby-consumption-error-page_dist_index_js").then(i.bind(i,73845));return t}const{MSNConsumptiponErrorPage:t}=await i.e("web-components_consumption-error-page_dist_index_js").then(i.bind(i,32307));return t}catch(t){this.enableConsumptionErrorPage=!1,(0,W.c_)(t,j.M6E,"Error importing consumption error page")}return null},this.stopEventPropagation=t=>{t.stopPropagation()},this.handleAIConversationStartersMessage=t=>{if(!(0,b.iZ)(t.origin))return;const{type:e,height:i,contentId:r}=t.data;"noCopilotAPI"!=e?"conversationStartersSize"===e&&this.contentId===r&&(this.conversationStartersIframeStyles="",0!==i?(this.contentType===n.i.Gallery&&(this.conversationStartersIframeStyles+="max-width: unset; padding: 0 24px;"),this.conversationStartersIframeStyles+=`height: ${i}px;`,this.convoStarterVisible=!0):this.conversationStartersIframeStyles="display: none;"):this.noCopilotAPI=!0},this.columnArrangement=(0,Ft.TU)().currentColumnArrangement,this.onScrollHandler=(0,ve.A)(this.onScrollHandler,500),this.updateActionTrayStyles=(0,ve.A)(this.updateActionTrayStyles,16),this.articleBannerAdBatchHook=void 0,this.articleBannerPlacementSignals=new Map,this.addArticleBannerAdPlacementSignals=(t,e)=>{this.articleBannerPlacementSignals.set(t,e)}}getRequestIdOverride(){return this.requestIdOverride||(this.requestIdOverride=(0,h.OM)(this.contentId,!this.isFirstLoadedContent())),this.requestIdOverride}async experienceConnected(){this.showNativeAdBanner=this.config.enableNativeAdBanner&&(0,ae.I)()&&this.isMainContent(),this.config.enableBigRRAdWithViewport?(this.enableBigRRAdWithViewport=!0,this.enableBigRRAd=!1,this.updateBigRRViewportValid()):this.config.featureFlags?.enableBigRRAd&&(this.enableBigRRAd=!0,this.enableBigRRAdWithViewport=!1),this.config.enableNativeAdBanner&&new URLSearchParams(location.search).get("forceNativeAdBanner")&&(this.showNativeAdBanner=!0),this.config.componentConfigs?.slideshowConfigs&&zt.vv.set(a.nR,this.config.componentConfigs.slideshowConfigs),this.rubyStickyBannerClass=this.config?.enableRubyStickyBanner&&this.isMainContent()?"ruby-sticky-banner":"",this.enableRubyStickyBanner=!!this.config?.enableRubyStickyBanner,this.stampSSRTmpl(),this.addPageBackIfNeeded(),this.isLoading=(0,c.G)(this.config.featureFlags||{},c.T.enableLoadStateOnCP),ne(this.config.slots,this.contentId),this.setExperimentalValues(),this.attachDisplayAdServiceEventListeners();const t=ee.V.getInstance().rootReducer.connector(o.xH);t&&(this.viewsFullPageConnector=t),this.viewsContentTopicId=this.isMainContent()&&new URLSearchParams(location.search).get("viewsContentTopicId")||"",this.showNativeAdBanner?this.articleBannerAdBatchHook=w.V(this.articleBannerAdBatchHook):this.setMainBannerAdProps(),this.aboveRiverBlockData=void 0;const e=this.loadContent();(0,x.D)()||await e,(0,Et.S)()&&(this.markTTVRIfSSREnabled(),this.resizeObserverCallback=(0,ve.A)(this.resizeObserverCallback,500),this.initializeContent()),this.config.componentConfigs?.viewsHeaderConfigs?.hideProviderLogoAndName&&this.expTTVRDependentList.delete(a.xP.ViewsContentProvider),this.shouldRenderAIConversationStarters&&window.addEventListener("message",this.handleAIConversationStartersMessage)}async initializeContextualFeedback(){if(this.config.slots?.contextualFeedbackWC)try{const{contextualFeedbackController:t}=await Promise.all([i.e("common-feed-libs"),i.e("libs_nurturing-internal-placement-provider_dist_InternalPlacementProvider_js-libs_wpo_dist_pr-44d366")]).then(i.bind(i,53349));t.setConfig({...this.config});const e=$.L.get("consumption-wpo-feed-contextual-feedback");let r;if(e)try{const t=JSON.parse(e);r=!!t?.showFeedCF,r&&(this.csatDwellTimeThresholdMs=t?.dwellTimeThreshold?1e3*Number(t.dwellTimeThreshold):void 0,L.YT.addOrUpdateTmplProperty("wpopromflcf","1"))}catch(t){return void(0,W.c_)(t,j.q_v,`${t}. Type: consumption-wpo-feed-contextual-feedback`)}this.displayCSAT=await t.shouldDisplayFeedLevelCSAT(r)}catch(t){(0,W.c_)(t,j.M6E,"Error importing consumption error page")}}addPageBackIfNeeded(){if(!(0,c.G)(this.config.featureFlags||{},c.T.enableAddNavHistory)||(0,b.b5)())return;const t=(0,jt.bI)(this.config.homepageUrl)??a.jb;(0,Yt.h)(t,this.enableInlineRefresh)}markTTVRIfSSREnabled(){if(window.isSSREnabled&&window.isSSRCompleted&&!window.isCSRFallback&&this.isMainContent()){const t=window.performance.now();this.expTTVRDependentList.size>0&&window.requestAnimationFrame(()=>{this.expTTVRDependentList.forEach((e,i)=>{this.stampPagePZeroTTVR(i,t)})})}}shadowDomPopulated(){(0,x.D)()||this.updateDataForKVP(),(0,Ft.TU)().subscribe(this.onBreakpointCallback),this.commonHeaderRef&&(this.commonHeaderMutationObserver=new MutationObserver(this.setCommonHeaderHeight),this.commonHeaderMutationObserver.observe(this.commonHeaderRef,{attributes:!0})),this.updateRightRailVisibility(),this.attachObserverToPageContainer(),window.addEventListener("resize",this.resizeObserverCallback),window.addEventListener("scroll",this.onScrollHandler),window.addEventListener(k.EU,this.onWPORiverFailedChanged),this._UpdateRubyBannerAdStyles(),this.config.enableRubyStickyBanner&&this.isMainContent()&&this.tt()}disconnectedCallback(){super.disconnectedCallback(),(0,Ft.TU)().unsubscribe(this.onBreakpointCallback),this.commonHeaderMutationObserver?.disconnect(),this.viewsHeaderRefIntersectionObserver?.disconnect(),this.stopRRStickyForLinearFeedTracking(),document.removeEventListener(k.Z7,this.consumptionFeedActivityChange),window.removeEventListener("resize",this.resizeObserverCallback),window.removeEventListener("scroll",this.onScrollHandler),window.removeEventListener(k.EU,this.onWPORiverFailedChanged),this.shouldRenderAIConversationStarters&&window.removeEventListener("message",this.handleAIConversationStartersMessage),this.rubyStickyBannerExitTimeoutId&&(clearTimeout(this.rubyStickyBannerExitTimeoutId),this.rubyStickyBannerExitTimeoutId=void 0),this.rubyStickyBannerTimeoutId&&(clearTimeout(this.rubyStickyBannerTimeoutId),this.rubyStickyBannerTimeoutId=void 0),window.removeEventListener("scroll",this.nt),this.style.removeProperty("--ruby-sticky-banner-exit-translate"),this.rubyStickyWindowOpen=!1,this.rubyStickyBannerVisible=!1,this.st=void 0,this.ot=void 0}setMainBannerAdProps(){if(!this.isMainContent()||this.mainBannerAdProps||!this.config?.slots?.bannerAd||!(0,Et.S)())return;const t={columnArrangement:this.columnArrangement,disableAds:this.disableAds,infiniteReadingContext:this.infiniteReadingContext,mappedPageType:this.config.nativeAdMappedPageType,useTeraForVerticalData:this.useTeraForVerticalData};this.mainBannerAdProps=(0,A.D)(this.config.featureFlags,t,this.contentId,U.Rb.ClientSettings.pagetype)}getTopBnrRszTreatment(){return this.config.featureFlags?.enableTopBnrRszT1?1:this.config.featureFlags?.enableTopBnrRszT2?2:void 0}attachObserverToPageContainer(){if(!this.consumptionPageRef||this.pageContainerModuleObserver)return;this.pageContainerModuleObserver=new IntersectionObserver(this.onPageContainerModuleObserve.bind(this),{root:null,threshold:0}),this.pageContainerModuleObserver.observe(this.consumptionPageRef)}onPageContainerModuleObserve(t){t&&t.forEach(t=>{t.intersectionRatio>.001&&(this.dwellTimeStartAllowedClassName=(0,C._)(this.contentId))})}attachDisplayAdServiceEventListeners(){this.config.slots.bannerAd&&!this.disableAds&&(X.T.addEventListener(Z.v.AdReturned,this.updateBannerAdContainerHeight),this.stabilizeBannerAdSize||(X.T.addEventListener(Z.v.AdRefreshed,this.updateBannerAdContainerHeight),X.T.addEventListener(Z.v.AdNoBid,this.updateBannerAdContainerHeight)))}get shouldRenderBannerAd(){return!(this.disableAds||this.isImmersiveFullscreenOpen||!this.config.slots.bannerAd)&&!(!this.mainBannerAdProps&&!this.contentProps?.bannerAd)}get shouldRenderBannerAdAboveHeadline(){if(!this.shouldRenderBannerAd)return!1;const t=this.config.featureFlags?.enableRubyDisplayAds;if(t){const t=this.enableGemContinuousReading||this.isMainContent(),e=this.config.enableResponsiveBannerAds;return"aboveHeadline"===this.config.bannerAdPosition&&t&&(e||this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2)}return!0}get shouldRenderBannerAdBelowHeadline(){if(!this.shouldRenderBannerAd)return!1;const t=this.config.featureFlags?.enableRubyDisplayAds;return!!t&&("belowHeadline"===this.config.bannerAdPosition&&this.isMainContent()&&this.columnArrangement!==J.j1.c1&&this.columnArrangement!==J.j1.c2)}get bannerAdConfig(){return{...this.isMainContent()?this.mainBannerAdProps:this.contentProps?.bannerAd,delayFetch:this.delayDisplayAds,contentId:this.enableNativeAdKeyValuePairs?this.contentId:void 0,enablePrefetchDisplay:this.enablePrefetchDisplay,htmlId:this.enablePrefetchDisplay?this.getDisplayAdHtmlId(this.contentId,this.config.slots?.bannerAd?.instanceId||""):void 0,enableResponsiveBannerBackground:this.config.enableResponsiveBannerAds}}get isExplodedFeedContent(){return this.infiniteReadingContext?.pageOriginOverride===a.Nh}get contentInfoForRightRailAd(){if(this.contentProps?.rail?.adProperties)return{...this.contentProps.rail.adProperties,delayFetch:this.delayDisplayAds,contentId:this.enableNativeAdKeyValuePairs?this.contentId:void 0}}get extraInfoForRightRailTopDisplayAd(){if(this.enablePrefetchDisplay)return{enablePrefetchDisplay:this.enablePrefetchDisplay,htmlId:this.enablePrefetchDisplay?this.getDisplayAdHtmlId(this.contentId,this.contentProps?.rail?.config.slots.topDisplayAd?.instanceId||""):void 0}}get rubyRightRailProps(){return{...this.contentInfoForRightRailAd,...this.extraInfoForRightRailTopDisplayAd,pageTypeOverride:this.config.nativeAdMappedPageType}}get rubyRightRailBottomAdProps(){return{...this.contentInfoForRightRailAd,pageTypeOverride:this.config.nativeAdMappedPageType}}get rubyRightRailProviderCarouselProps(){return{contentId:this.contentProps?.rail?.contentId,contentTitle:this.contentProps?.rail?.contentTitle,isMainArticle:this.infiniteReadingContext?.isMainArticle,isMoreFromCard:this.useRightRailMoreFromCard,pageType:"view",publisherProfileId:this.contentProps?.header?.provider.profileId,railBelowLoaded:this.railBelowLoaded,railRightLoaded:this.railRightLoaded}}get actionBarStrings(){const t=this.config.localizedStrings;return t&&t.actionBar&&t.viewsHeader?{...t.actionBar,justNowSimple:t.viewsHeader.justNowSimple??"",hoursAgoSimple:t.viewsHeader.hoursAgoSimple??"",minutesAgoSimple:t.viewsHeader.minutesAgoSimple??"",daysAgoSimple:t.viewsHeader.daysAgoSimple??"",weeksAgoSimple:t.viewsHeader.weeksAgoSimple??"",yearsAgoSimple:t.viewsHeader.yearsAgoSimple??"",monthsAgoSimple:t.viewsHeader.monthsAgoSimple??"",updatedAgoLabel:t.viewsHeader.updatedAgoLabel??""}:{}}get shouldRenderEocb(){return(0,Et.S)()&&!!this.contentProps?.endOfContentBlock&&(!this.config.featureFlags?.enableRubyConsumptionView||this.config.featureFlags?.enableRubyConsumptionView&&this.contentType===n.i.Article)}isKeyTakeawaysEnabled(){return!!this.config.componentConfigs?.viewsHeaderConfigs?.enableKeyTakeaways||!!this.config.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot}shouldRenderKeyTakeawaysSection(){this.renderKeyTakeawaysSection=Boolean(this.config?.componentConfigs?.viewsHeaderConfigs?.slots?.keyTakeawaysWC)&&this.enableKeyTakeaways()}get disableAllAIFeatures(){return"1"===this.contentData?.stringAttributes?.isAiGeneratedContentDisabled||this.contentProps?.header?.disableCopilotButtons||!1}enableKeyTakeaways(){return!(!(this.keyTakeawaysData&&this.keyTakeawaysData.length>0)||!(this.config?.infiniteCopilotFeats||this.isMainContent()||this.isExplodedFeedContent)||this.disableAllAIFeatures)&&this.isKeyTakeawaysEnabled()}async loadContent(){try{const t=this.getCurrentContentData();this.contentData=await t}catch(t){return void this.handleFatalError("Failed to get content view data",t)}var t;(this.config.featureFlags?.enableRubyArticleFlex&&[n.i.Article,n.i.Gallery,n.i.Video].includes(this.contentData.type)&&(this.enableRubyArticleFlex=!0),F.a.setContentViewData(this.contentId,this.contentData),(0,l.Ux)(this.contentData.locale))?this.handleFatalError("Failed to get content view data",new p.Rh):(0,l.ZE)(this.contentData.provider?.id)?this.handleFatalError("Forbidden BBC content requested in UK",new p.Rh,j.lOg):((0,Et.S)()&&((0,f.p)().resolve(!0),this.telemetryObject.contract.name="ConsumptionPage"+((t=a.kw.get(this.contentData.type))?">"+se.get(t):""),this.setupViewsTracker(this.contentData),this.topSpanTelemetryObject=(0,Qt.u)(a.zA.topSpan,{type:yt.get(this.contentData.type)}),document.addEventListener(k.Z7,this.consumptionFeedActivityChange),this.disableAds=Boolean(this.shouldDisableAds()),this.config.slots.bannerAd&&!this.disableAds&&(this.bannerAdHeight=this.useLargeBannerContainer?we.largeBannerAdContainerHeight:we.smallBannerAdContainerHeight)),await this.mapContentDataToProps(this.contentData),(0,x.D)()&&this.updateDataForKVP(),this.feedProps=this.getFeedData(),this.contentType=this.contentData.type,this.isLoading=!1,this.enableLoadingState&&this.infiniteReadingContext?.updateInitialContentLoadingState?.(1),this.updateDocumentTitle(this.contentData.title),this.config?.featureFlags?.enableRubyConsumptionView&&this.loadRubyViewsMetaInfo(),(0,Et.S)()&&(0,_t.dT)().then(()=>{this.postTTVRCallback()}),this.resizeObserverBehavior(!0,!this.shouldRenderMobileATForDesktop),this.setDataClarityRegion(),this.isKeyTakeawaysEnabled()&&this.loadKeyTakeawaysData())}loadKeyTakeawaysData(){const t=(0,b.WG)(this.contentData?.stringAttributes?.key_takeaways_latest)??[];if(!t||0===t.length)return;this.keyTakeawaysData.push(...t);const e=(0,b.PE)(this.contentProps?.header?.viewsHeaderTelemetryContentData);e&&(this.keyTakeawaysTelemetryObjects=e),this.keyTakeawaysCollapsed=!this.config?.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot&&!this.isExplodedFeedContent,this.shouldRenderKeyTakeawaysSection()}async getCurrentContentData(){if(this.contentViewData)return this.contentViewData;const t=F.a.getCurrentData(this.contentId);if(t)return t;const e=this.isMainContent()?"Main":"Scroll";return(0,R.c)(this.contentId,!0,e)}setDataClarityRegion(){this.dataClarityRegion=this.contentType+(this.infiniteReadingContext?.scrollDepth||"")}updateDataForKVP(){if(!this.enableAdKeyValuePairs||!this.contentData)return;(0,S.O)();const t=(0,_.I)(this.contentData);this.infiniteReadingContext&&this.setAdsMetadata||!t||qt.t.setMetadatas(t,this.config.featureFlags?.enableContentSpecificAdKvp?this.contentId:void 0),this.setAdsMetadata?.(this.contentId,t),T.js.getPromise(this.contentId,"display").then(()=>{this.loadDisplayAds()})}updateDocumentTitle(t){this.documentTitleCb&&"function"==typeof this.documentTitleCb&&(this.documentTitleCb=this.infiniteReadingContext?this.documentTitleCb.bind(this,t):this.documentTitleCb,this.isMainContent()&&this.documentTitleCb(t))}trackThirdParty(t){if(this.contentData?.type===n.i.Article){const e=this.config.componentConfigs?.articlePageConfig?.partnerThirdPartyTrackers;(0,I.Z)(t,this.contentId,e)}}createAdapterParams(t){const{provider:e,id:i,title:r,type:s}=t,o=(0,Jt.E)(t,this.useTeraForVerticalData);return{...o,providerData:(0,B.Y)(e),entityId:i,entitySrc:a.t3.get(s)||"",contentTitle:r,verticalKey:o.vertical,categoryKey:o.category,teraVertical:o.teraVertical,teraCategory:o.teraCategory,overridePersistPageMetadata:!(0,c.G)(this.config.featureFlags||{},c.T.discardOverridenPageMetadata,!1)}}async initializeTracker(t,e){const{id:i,type:r}=t,s=new D.$(e),o=a.kw.get(r)||"video";if(this.infiniteReadingContext){s.pageUrl=this.infiniteReadingContext.baseContentUrl,s.referralUrl=this.infiniteReadingContext.referralUrl,s.pageType=a.Xh.get(o),s.pageName=P.v.getPageName(o,void 0,void 0,!0);let t=null;this.isMainContent()?this.inlineRefreshed&&(t=a.vt):t=this.infiniteReadingContext.pageOriginOverride||a.pJ,s.pageOrigin=t,m.I.addContentEntry(i,s.getMetadataOverride());const e=this.getInitializedPromise();if(e)try{await e}catch{return null}this.isFirstLoadedContent()||(0,h.OE)(i,this.getRequestIdOverride()),null!=this.infiniteReadingContext.linearFeedCardIndex?((0,h.ut)(i,"linearFeedDepth",`${this.infiniteReadingContext.linearFeedCardIndex}`),(0,h.ut)(i,"expandedFeedDepth",`${this.infiniteReadingContext.expandedFeedDepth}`)):(0,h.ut)(i,`${a.A6}-depth`,`${this.infiniteReadingContext.scrollDepth}`)}else(0,h.ut)(i,`${a.A6}-depth`,"1");return this.sendTelemetryPromiseWidgets&&(s.pageType=a.Xh.get(o),s.pageName=P.v.getPageName(o,void 0,void 0,!0),s.pageUrl=this.telemetryExtraDataWidgets?.url,s.referralUrl=this.telemetryExtraDataWidgets?.referralUrl,await this.sendTelemetryPromiseWidgets),s}async setupViewsTracker(t){const{provider:e,id:i}=t,r=this.createAdapterParams(t),s=await this.initializeTracker(t,r);s&&(this.tracker=s,this.previouslyInit||(await this.tracker.trackPageAsync(void 0,1,void 0,!0),this.trackThirdParty(e)),this.config?.featureFlags?.enableIsMonetized&&this.tracker.setIsMonetized(),this.infiniteReadingContext&&m.I.dwellTimeStart(i))}processExperienceInitializeError(){super.processExperienceInitializeError(),(0,b.Bs)(this.getExperienceType())}getExperienceType(){return s.m$j}stampSSRTmpl(){try{const t=window.isSSREnabled?"1":"0";(0,h.ut)(this.contentId,a.T7,t);const e=window.isSSRCompleted?"1":"0";(0,h.ut)(this.contentId,a.H5,e)}catch(t){}}updateActionTrayStyles(){window.requestAnimationFrame(()=>{this.actionTrayGridAreaStyles=this.getActionTrayGridAreaStyles(),this.actionTrayWrapperStyles=this.getActionTrayWrapperStyles()})}getActionTrayGridAreaStyles(){let t="";if(window.matchMedia("(max-width: 767px)").matches&&this.consumptionPageContentHeight){t+=`height: ${(this.consumptionPageContentRef?.offsetHeight||0)+this.viewsHeaderHeight+this.bannerHeight}px`}return t}updateRightRailVisibility(){this.isRailBelow=this.shouldShowRailBelow(),this.isRailBelow?this.railBelowLoaded=!0:this.railRightLoaded=!0}shouldShowRailBelow(){return this.config.featureFlags?.enableExtendedRightRail?this.columnArrangement===J.j1.c1||window.matchMedia(`(max-width: ${(0,ye.c)(a.tK)})`).matches:this.columnArrangement===J.j1.c2||window.matchMedia(`(max-width: ${(0,ye.c)(a.kk)})`).matches}getVerticalCategory(t){return{vertical:(t&&(0,E.G)(t,this.useTeraForVerticalData).vertical)??"other",category:(t&&(0,E.G)(t,this.useTeraForVerticalData).category)??"other"}}isRiverDisabled(){const{feedWC:t}=this.config.slots,e=(0,c.G)(this.config.featureFlags||{},c.T.enableRubyConsumptionView,!1),i=!this.getMaxFeedRows()||this.isInfiniteScrollFeed();return!t||e||!i&&this.config.disableNonInfRiver}getFeedData(){if(this.isRiverDisabled())return;const{vertical:t,category:e}=this.getVerticalCategory(this.contentData),i=a.kw.get(this.contentData?.type||n.i.Article)||"article",r={contentID:this.contentId,enableNativeAdXandr:this.enableNativeAdXandr,enableInlineRefresh:this.enableInlineRefresh,isInlineRefreshed:this.inlineRefreshed,verticalKeyOverride:t,categoryKeyOverride:e,disableAds:this.disableAds,mappedPageType:this.config.nativeAdMappedPageType,partnerId:i,pageNumber:this.infiniteReadingContext?.scrollDepth||1,pageType:i};return r.maxVisibleRows=this.getMaxFeedRows(),r.isInfiniteScrollFeed=this.isInfiniteScrollFeed(),this.infiniteReadingAvailableCards&&(r.infiniteReadingCards=this.infiniteReadingAvailableCards),this.infiniteReadingContext&&this.infiniteReadingContext.infiniteReadingRiverHelper&&(r.infiniteReadingRiverHelper=this.infiniteReadingContext.infiniteReadingRiverHelper),r}getMaxFeedRows(){if(this.infiniteReadingDynamicProps?.hasInfiniteRiver)return;const t=(0,c.G)(this.config.featureFlags||{},c.T.enable2RowRiver),e=(0,c.G)(this.config.featureFlags||{},c.T.enableExtendedRiver);return t&&e&&this.columnArrangement===J.j1.c5?2:(0,b.Q4)(this.config.maxFeedRows,!this.isMainContent(),this.config.nextContentMaxFeedRows)}isMangaContent(){return this.isMainContent()?(0,b.MW)(new Xt.bb):Boolean(this.infiniteReadingContext?.baseContentUrl?.includes("/manga/"))}isInfiniteScrollFeed(){return!!this.infiniteReadingDynamicProps?.hasInfiniteRiver}composeActionTrayProps(t){if(t)return{...t,moreActions:{...t.moreActions,refreshFeedCallback:this.removePageFromTheFeed},shouldShowStartAppCoachmark:this.config.shouldShowStartAppCoachmark,shouldRenderMobileATForDesktop:this.shouldRenderMobileATForDesktop,showFullFloatingBar:!(!this.config.featureFlags?.enableFloatingSocialBarFull||!this.shouldRenderMobileATForDesktop),disableAutoHide:!(!this.config.featureFlags?.enableFloatingSocialBarT2||!this.shouldRenderMobileATForDesktop),hideOnScroll:!(!this.config.featureFlags?.enableFloatingSocialBarT3||!this.shouldRenderMobileATForDesktop),noGradientFloatingBar:!(!this.config.featureFlags?.enableFloatingSocialBarNoGrad||!this.shouldRenderMobileATForDesktop)}}updateLeadgenData(t){this.shouldRenderEoabLeadgen=!!this.shouldRenderLeadgenEoab(t),this.shouldRenderEoabLeadgen&&!this.leadGenCardProps&&(this.leadGenCardProps=this.getLeadgenProps(t))}shouldRenderLeadgenEoab(t){return t.leadgen&&!this.config.noSSOLeadgenProviders?.includes(t.id||"")}getLeadgenProps(t){const e=this.config.componentConfigs?.endOfContentBlockConfigs?.slots?.endOfContentLeadGen,i=this.getLeadgen(t.id,t.leadgen);return e&&i?{cardWidthType:this.config.componentConfigs?.endOfContentBlockConfigs?.leadGenCardWidthType,experienceConfigInfo:{...e,instanceId:`${e.instanceId}-${this.contentId}`},contentId:this.contentId,publisherProfileId:t.profileId||"",leadgen:i,providerLogoUrl:this.contentProps?.header?.provider.logo?.src,useKumoDesign:this.config.featureFlags?.enableRubyConsumptionView}:void 0}getLeadgen(t="",e){return this.config.componentConfigs?.articlePageConfig?.leadGenProviders?this.config.componentConfigs?.articlePageConfig?.leadGenProviders.find(e=>e.providerId===t)?.leadgen:e}shouldEnableNativeAdXandr(){return(0,c.G)(this.config.featureFlags||{},c.T.enableNativeAdXandr)}shouldDisableAds(){const t=this.contentData;if(!t)return;const e=(0,E.G)(t,this.useTeraForVerticalData).category||"other";return this.isFeatureDisabled()||this.isCategoryDisabled(e)||this.isSensitiveTopic(t.facets)||this.isAdsDisabledByCitemParams()}isFeatureDisabled(){return(0,c.G)(this.config?.featureFlags,c.T.forceDisableAds)}isCategoryDisabled(t){return!!(t&&this.config.disAdsForCategs&&this.config.disAdsForCategs[t])}isSensitiveTopic(t){return t&&(0,b.Um)(t)}isAdsDisabledByCitemParams(){return et.T3.IsDebug&&"true"===(0,Lt.n)(Vt.tn)}trySetTTVRAndMilestone(t,e){if(this.handleTtvrCallback&&this.handleTtvrCallback(this.contentId,t,e),this.isFirstLoadedContent()){if(this.markTimeToVisuallyReadyCalled||-1!==this.expTTVRDependentList.get(t))return}else if(this.contentType===n.i.Article&&t===a.xP.ArticleContent)return void this.markInfiniteReadingTTVRIfNeeded();this.expTTVRDependentList.set(t,e);let i=-1;for(const t of this.expTTVRDependentList.values()){if(-1===t)return;t>i&&(i=t)}super.markVisuallyReady(i),this.markGemP0TTVR?.(s.m$j,i),this.markTimeToVisuallyReadyCalled=!0,(0,z.Fy)(i)}buildSeoMetadata(){const t=this.contentProps?.content?.context,e=t?.articleData||t?.slideshowData;if(!e)return;let i="";if(e.imageResources?.length){const t=e.imageResources[0];i=t.url+`?w=${t.width}&h=${t.height}&m=4&q=${t.quality}`}return{title:e.title||"Microsoft News Article",description:e.abstract||"",image:i,publishedTime:(new Date(e.publishedDateTime).getTime()/1e3).toString(),updatedTime:(new Date(e.updatedDateTime).getTime()/1e3).toString(),originalUrl:this.infiniteReadingContext?.baseContentUrl||et.T3?.HostPage?.originalUrl,section:this.getVerticalCategory(e).vertical||"",authors:e.authors?.map(t=>t.name),tags:e.keywords,locale:e.locale,disallowIndexing:Boolean(e.seo?.disallowIndexing),canonicalAuthority:e.seo?.canonicalAuthority||"",canonicalUrl:e.seo?.canonicalUrl||"",twitterCardType:"summary_large_image",providerId:e.provider?.id}}async updateSeoTags(){if(!this.isMainContent())return;this.inlineRefreshed&&((0,N.gw)(),(0,O.mI)());const t=this.buildSeoMetadata();if(!t)return;const e=new M.W(t.providerId),i=await e.getFeatureOptionsAsync();(0,N.UE)(t),(0,O.Uh)(t.canonicalAuthority,t.canonicalUrl),(0,H.js)(t.disallowIndexing,i[M.Q.NoArchive])}async loadTopSpanModuleContent(){(0,c.G)(this.config.featureFlags,c.T.disableTopSpan)||(this.topSpanModuleContent=await this.getTopSpanModuleContent(!!this.viewsContentTopicId))}isTopSpanContentDisabled(t){if(!t)return!1;const e=this.config.componentConfigs?.topSpanConfig?.[t];return!!e&&!(!e?.disabledForVertical?.includes(this.contentProps?.topSpan?.vertical||"")&&!e?.disabledForCategory?.includes(this.contentProps?.topSpan?.category||""))}consumptionPageGridStructureStyles(t=!0){if(t){if(this.isNotEnoughSizeForDesktopAT){const t=Math.floor((document.documentElement.clientWidth-a.X7)/2);this.gridOverriddenStyle=`grid-template-columns: ${(0,ye.c)(t)} ${(0,ye.c)(a.X7)} ${(0,ye.c)(t)};`}}else this.gridOverriddenStyle=""}async loadMoreFromProvider(){(this.config.featureFlags?.enableContentLeftRail||this.config.featureFlags?.enableHeaderDigestStrip)&&!this.isMainContent()&&this.infiniteReadingContext?.initializedPromise&&await this.infiniteReadingContext.initializedPromise,this.viewsFullPageConnector.hasFetchStarted(this.contentId)||this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),void 0,!1,!1,this.isLastContent);const t=await(this.viewsFullPageConnector?.getMoreProvider(this.contentId));t?.[0]?.provider?(this.moreFromProviderData=t[0],this.moreFromProviderData&&await i.e("web-components_ruby-provider-links_dist_index_js-_1a410").then(i.bind(i,33017))):(0,W.vV)(j.$q6,"No provider data found for more from provider")}async loadTrendingNow(){if(!this.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow)return;let t=this.consumptionPageContentHeight;(0,Et.S)()&&this.consumptionPageContentRef&&(t=this.consumptionPageContentRef.getBoundingClientRect().height,this.consumptionPageContentHeight=t||this.consumptionPageContentHeight);const e=this.isRubyRightRailAds?600:0;if(t>0){if(t-e<=376)return}this.viewsFullPageConnector.hasFetchStarted(this.contentId)||this.viewsFullPageConnector.initialConnectorFetch(this.contentId,this.isMainContent(),void 0,!1,!1,this.isLastContent);const i=await(this.viewsFullPageConnector?.getTrendingNow(this.contentId));i&&0!==i.length&&i[0]?.subCards&&0!==i[0].subCards.length?this.trendingNowData=i[0]:(0,W.vV)(j.$q6,"No trending now data found")}get vfpConnectorNoScrollContentCount(){return this.viewsFullPageConnector?.config?.noScrollClickCurve||!this.isMainContent()}}we.definition={shadowOptions:null},we.smallBannerAdContainerHeight=ct+lt+1,we.largeBannerAdContainerHeight=dt+lt+1,we.RUBY_STICKY_BANNER_SIZE_DEFAULT_PX=80,(0,r.Cg)([Dt.sH],we.prototype,"cardActionRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableBigRRAd",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableBigRRAdWithViewport",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableRubyStickyBanner",void 0),(0,r.Cg)([Dt.sH],we.prototype,"bigRRViewportValid",void 0),(0,r.Cg)([Dt.sH],we.prototype,"tracker",void 0),(0,r.Cg)([Dt.sH],we.prototype,"actionTrayGridAreaStyles",void 0),(0,r.Cg)([Dt.sH],we.prototype,"actionTrayWrapperStyles",void 0),(0,r.Cg)([Dt.sH],we.prototype,"bannerAdRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"columnArrangement",void 0),(0,r.Cg)([Dt.sH],we.prototype,"commonHeaderHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageContentHeaderRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageContentHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageContentRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"trendingNowData",void 0),(0,r.Cg)([Dt.sH],we.prototype,"moreFromProviderData",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isLastContent",void 0),(0,r.Cg)([Dt.sH],we.prototype,"showOneRowContent",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageStructureRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"hasFullyScrolledMainContent",void 0),(0,r.Cg)([Dt.sH],we.prototype,"consumptionPageViewsHeaderAreaRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"contentProps",void 0),(0,r.Cg)([Dt.sH],we.prototype,"contentType",void 0),(0,r.Cg)([Dt.sH],we.prototype,"dwellTimeStartAllowedClassName",void 0),(0,r.Cg)([Dt.sH],we.prototype,"feedProps",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isImmersiveFullscreenOpen",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isRailBelow",void 0),(0,r.Cg)([Dt.sH],we.prototype,"railBelowLoaded",void 0),(0,r.Cg)([Dt.sH],we.prototype,"railRightLoaded",void 0),(0,r.Cg)([Dt.sH],we.prototype,"topSpanModuleContent",void 0),(0,r.Cg)([Dt.sH],we.prototype,"topSpanRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"viewsHeaderHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"viewsHeaderRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"dataClarityRegion",void 0),(0,r.Cg)([Dt.sH],we.prototype,"viewsHeaderVisibilityChange",void 0),(0,r.Cg)([Dt.sH],we.prototype,"bannerAdStart",void 0),(0,r.Cg)([Dt.sH],we.prototype,"leadGenCardProps",void 0),(0,r.Cg)([Dt.sH],we.prototype,"shouldRenderEoabLeadgen",void 0),(0,r.Cg)([Dt.sH],we.prototype,"disableAds",void 0),(0,r.Cg)([Dt.sH],we.prototype,"errorState",void 0),(0,r.Cg)([Dt.sH],we.prototype,"mainBannerAdProps",void 0),(0,r.Cg)([Dt.sH],we.prototype,"contentDetailInitialCall",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isOneRowContentReady",void 0),(0,r.Cg)([Dt.sH],we.prototype,"bannerAdHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"bknewsBannerHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"visibleBannerAdHeight",void 0),(0,r.Cg)([Dt.sH],we.prototype,"contentWrapperWidth",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableNativeAdXandr",void 0),(0,r.Cg)([Dt.sH],we.prototype,"zhCnNativeAdsRefresh",void 0),(0,r.Cg)([Dt.sH],we.prototype,"zhCnNativeAdsRefreshRate",void 0),(0,r.Cg)([Dt.sH],we.prototype,"tallerRightRailAdOnTop",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableDisplayAdKeyValuePairs",void 0),(0,r.Cg)([Dt.sH],we.prototype,"delayDisplayAds",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableNativeAdKeyValuePairs",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableAdKeyValuePairs",void 0),(0,r.Cg)([Dt.sH],we.prototype,"setAdsMetadata",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isLoading",void 0),(0,r.Cg)([Dt.sH],we.prototype,"usePolishedStyles",void 0),(0,r.Cg)([Dt.sH],we.prototype,"aboveRiverBlockData",void 0),(0,r.Cg)([Dt.sH],we.prototype,"publishedDateStringFormat",void 0),(0,r.Cg)([Dt.sH],we.prototype,"publishedDateTimeString",void 0),(0,r.Cg)([Dt.sH],we.prototype,"publishedTimeStamp",void 0),(0,r.Cg)([Dt.sH],we.prototype,"updatedDateStringFormat",void 0),(0,r.Cg)([Dt.sH],we.prototype,"updatedDateTimeString",void 0),(0,r.Cg)([Dt.sH],we.prototype,"updatedTimeStamp",void 0),(0,r.Cg)([(0,Pt.CF)({mode:"boolean",attribute:"enable-ruby-article-flex"})],we.prototype,"enableRubyArticleFlex",void 0),(0,r.Cg)([Dt.sH],we.prototype,"keyTakeawaysData",void 0),(0,r.Cg)([Dt.sH],we.prototype,"keyTakeawaysCollapsed",void 0),(0,r.Cg)([Dt.sH],we.prototype,"renderKeyTakeawaysSection",void 0),(0,r.Cg)([Dt.sH],we.prototype,"markTimeToVisuallyReadyCalled",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isNewlyReplacedArticle",void 0),(0,r.Cg)([Dt.sH],we.prototype,"enableConsumptionErrorPage",void 0),(0,r.Cg)([Dt.sH],we.prototype,"redirectUrl",void 0),(0,r.Cg)([Dt.sH],we.prototype,"commonHeaderRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"stabilizeBannerAdSize",void 0),(0,r.Cg)([Dt.sH],we.prototype,"useLargeBannerContainer",void 0),(0,r.Cg)([Dt.sH],we.prototype,"contentInitialized",void 0),(0,r.Cg)([Dt.sH],we.prototype,"gridOverriddenStyle",void 0),(0,r.Cg)([Dt.sH],we.prototype,"stickyBannerAdStyle",void 0),(0,r.Cg)([Dt.sH],we.prototype,"stickyBannerSizeStyle",void 0),(0,r.Cg)([Dt.sH],we.prototype,"shouldRenderMobileATForDesktop",void 0),(0,r.Cg)([Dt.sH],we.prototype,"rubyRightRailRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"rubyRailBottomAdRef",void 0),(0,r.Cg)([Dt.sH],we.prototype,"isOneRowContentHidden",void 0),(0,r.Cg)([Dt.sH],we.prototype,"markGemP0TTVR",void 0),(0,r.Cg)([Dt.sH],we.prototype,"conversationStartersIframeStyles",void 0),(0,r.Cg)([Dt.sH],we.prototype,"displayCSAT",void 0),(0,r.Cg)([Dt.sH],we.prototype,"csatDwellTimeThresholdMs",void 0),(0,r.Cg)([Dt.Jg],we.prototype,"useRightRailMoreFromCard",null),(0,r.Cg)([Dt.Jg],we.prototype,"bannerAdStyles",null),(0,r.Cg)([Dt.Jg],we.prototype,"bkNewsStyles",null),(0,r.Cg)([Dt.Jg],we.prototype,"riverHeadingClassnames",null),(0,r.Cg)([Dt.Jg],we.prototype,"contentAreaClassname",null),(0,r.Cg)([Dt.sH],we.prototype,"rubyStickyBannerClass",void 0),(0,r.Cg)([Dt.Jg],we.prototype,"errorText",null),(0,r.Cg)([Dt.Jg],we.prototype,"isRightRailReady",null),(0,r.Cg)([Dt.Jg],we.prototype,"rightRailTopPosition",null),(0,r.Cg)([Dt.Jg],we.prototype,"isRubyRightRail",null),(0,r.Cg)([Dt.Jg],we.prototype,"isRubyRightRailSticky",null),(0,r.Cg)([Dt.Jg],we.prototype,"isRRStickyForLinearFeed",null),(0,r.Cg)([Dt.Jg],we.prototype,"isRubyRightRailAds",null),(0,r.Cg)([Dt.Jg],we.prototype,"consumptionPageContentHeaderStyles",null),(0,r.Cg)([Dt.Jg],we.prototype,"bannerHeight",null),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderActionTray",null),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderMobileActionTray",null),(0,r.Cg)([Dt.Jg],we.prototype,"deferRenderingRiver",null),(0,r.Cg)([Dt.Jg],we.prototype,"hideRiver",null),(0,r.Cg)([Dt.sH],we.prototype,"isWPORiverFailed",void 0),(0,r.Cg)([Dt.sH],we.prototype,"noCopilotAPI",void 0),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderAIConversationStarters",null),(0,r.Cg)([Dt.sH],we.prototype,"showNativeAdBanner",void 0),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderBannerAd",null),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderBannerAdAboveHeadline",null),(0,r.Cg)([Dt.Jg],we.prototype,"shouldRenderBannerAdBelowHeadline",null);var xe=i(89757),$e=i(69259),ke=i(60402),Ae=i(68835),Ce=i(92011);const Fe=xe.qy`<div id=${t=>`${(0,b.N7)(t.props?.id||"")}-star-rating-observer`}></div>`,Re=xe.qy`<div class="article-content">${(0,$e.z)(t=>t.props?.context,xe.qy`<msn-article-page :articleId="${t=>t.props?.id}" :config="${t=>t.config}" :slideshowConfig=${t=>t.slideshowConfig} :localizedStrings="${t=>t.localizedStrings}" :infiniteReadingContext="${t=>(t.props?.context).infiniteReadingContext}" :infiniteReadingDynamicProps="${t=>(t.props?.context).infiniteReadingDynamicProps}" :stampPagePZeroTTVR="${t=>t.stampPagePZeroTTVR}" :handleFatalError="${t=>t.handleFatalError}" :onToggleImmersiveFullscreen="${t=>(t.props?.context).onToggleImmersiveFullscreen}" :articleData="${t=>(t.props?.context).articleData}" :rootTelemetryObject="${t=>t.rootTelemetryObject}" :disableAds="${t=>(t.props?.context).disableAds}" :shouldRenderEoabLeadgen="${t=>t.shouldRenderEoabLeadgen}" :providerLogoUrl=${t=>t.providerLogoUrl} :enableNativeAdXandr="${t=>(t.props?.context).enableNativeAdXandr}" :getNextContentCard="${t=>t.getNextContentCard}" :commonHeaderRef=${t=>t.commonHeaderRef} :trackingAdapter="${t=>t.trackingAdapter}" :rubyRightRailAdPxBottom=${t=>t.rubyRightRailAdPxBottom} :enableRubyArticleFlex=${t=>t.enableRubyArticleFlex} :unhideEocbCallback=${t=>t.unhideEocbCallback} :unhideRiverCallback=${t=>t.unhideRiverCallback} :useTeraForVerticalData=${t=>t.useTeraForVerticalData} :contentInfoForAd=${t=>t.contentInfoForAd} :skipInitialRenderingVisibilityCheckForAds=${t=>t.skipInitialRenderingVisibilityCheckForAds}></msn-article-page>`)}</div>${Fe}
`;class Se extends Ce.L{constructor(){super(...arguments),this.skipInitialRenderingVisibilityCheckForAds=!1}connectedCallback(){super.connectedCallback()}}(0,r.Cg)([Dt.sH],Se.prototype,"props",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"config",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"localizedStrings",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"rootTelemetryObject",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"stampPagePZeroTTVR",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"shouldRenderEoabLeadgen",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"providerLogoUrl",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"handleFatalError",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"slideshowConfig",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"getNextContentCard",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"commonHeaderRef",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"trackingAdapter",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"rubyRightRailAdPxBottom",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"enableRubyArticleFlex",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"unhideEocbCallback",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"unhideRiverCallback",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"useTeraForVerticalData",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"contentInfoForAd",void 0),(0,r.Cg)([Dt.sH],Se.prototype,"skipInitialRenderingVisibilityCheckForAds",void 0);let _e=class extends Se{};_e=(0,r.Cg)([(0,Ce.E)({name:"desktop-article-content",template:Re,shadowOptions:null})],_e);var Te=i(59669);const Ie=Te.A` :host(.hidden){display:none}social-lead-gen-in-article{margin-bottom:16px}`;var Be=i(94172);const De=xe.qy` ${(0,$e.z)(t=>t.leadGenCardProps,xe.qy` ${t=>(0,Be.yN)(t.leadGenCardProps?.experienceConfigInfo,{properties:t.leadGenCardProps})} `)}
`,Pe=xe.qy` ${(0,$e.z)(t=>t.eocbEntrypointProps,xe.qy` ${t=>(0,Be.yN)(t.eocbEntrypointProps?.config,{properties:t.eocbEntrypointProps?.properties})} `)}
`,Ee=xe.qy`<div slot="${t=>t.contentId}-more-from-provider"><ruby-provider-links :collapsible=${t=>t.collapsible} :cardTitleString=${t=>t.moreFromProviderTitle} :moreFromProviderData=${t=>t.moreFromProviderData} :contentId=${t=>t.contentId}></ruby-provider-links></div>`,ze=xe.qy` ${(0,$e.z)(t=>t.shouldRenderEoabLeadgen,De,Pe)} ${(0,$e.z)(t=>t.moreFromProviderData,Ee)}
`;class Ne extends Ce.L{constructor(){super(...arguments),this.loadState=0,this.shouldRenderEoabLeadgen=!1}leadGenCardPropsChanged(){this.leadGenCardProps&&(this.loadState=1)}configChanged(){this.socialEntrypointConfig||(this.socialEntrypointConfig=this.config.slots.endOfContentSocialEntrypoint),ne(this.config.slots,this.contentId),this.config?.enableSocialDataConnector&&ee.V.getInstance().rootReducer.getDataConnector(o.eX).then(t=>{this.socialDataConnector=t,t||L.YT.sendAppErrorEvent({...j.okg,message:"Social data connector not found in the root reducer",pb:{...j.okg.pb,customMessage:"Social data connector not found in the root reducer"}})}),this.loadState=1}get eocbEntrypointProps(){return this.contentId&&this.socialEntrypointConfig?{config:{...this.socialEntrypointConfig,instanceId:this.socialEntrypointConfig+"-"+this.contentId},properties:{contentId:this.contentId,topicId:this.contentId,category:this.category,isShowAsInfoSpan:!1,isShowAsEmbeddedCard:!0}}:null}}(0,r.Cg)([(0,Pt.CF)({attribute:"content-id"})],Ne.prototype,"contentId",void 0),(0,r.Cg)([Pt.CF],Ne.prototype,"vertical",void 0),(0,r.Cg)([Pt.CF],Ne.prototype,"category",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"columnView",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"loadState",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"isImmersiveFullscreenOpen",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"shouldRenderEoabLeadgen",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"leadGenCardProps",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"socialEntrypointConfig",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"moreFromProviderData",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"collapsible",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"moreFromProviderTitle",void 0),(0,r.Cg)([Dt.sH],Ne.prototype,"config",void 0),(0,r.Cg)([Dt.Jg],Ne.prototype,"eocbEntrypointProps",null);let Oe=class extends Ne{};Oe=(0,r.Cg)([(0,Ce.E)({name:"desktop-end-of-content-block",template:ze,styles:Ie})],Oe);const Me=Te.A`
`;function He(t,e){return 1===e?t:xe.qy`<div></div>`}const Le=xe.qy`<gallery-slideshow :overrideContentUrl=${t=>t.overrideContentUrl} :baseProps=${t=>t.slideshowProps} :onOpenImmersiveCallback=${t=>t.context?.onToggleImmersiveFullscreen} :enableRubyConsumptionView=${t=>t.enableRubyConsumptionView} :enableRubyProngView=${t=>t.enableRubyProngView} :enableWidgetsConsumptionView=${t=>t.enableWidgetsConsumptionView} :leadGenCardProps=${t=>t.leadGenCardProps} :shouldRenderEoabLeadgen=${t=>t.shouldRenderEoabLeadgen} :moreFromProviderData=${t=>(0,b.BZ)(t.moreFromProviderData)} :moreFromProviderTitle=${t=>t.moreFromProviderTitle}></gallery-slideshow>`,Ve=xe.qy` ${t=>(0,Be.yN)(t.config.slots.immersiveFullscreen,{properties:{slideshowProps:t.fullscreenSlideshowProps,onCloseCallback:t.context?.onToggleImmersiveFullscreen}})}
`,Ue=xe.qy`<div id=${t=>`${(0,b.N7)(t.props.id)}-star-rating-observer`}></div>`,We=xe.qy` ${Ue} ${(0,$e.z)(t=>t.isImmersiveFullscreenOpen,Ve,Le)}
`,je=xe.qy` ${t=>He(We,t.loadState)}
`;var Ge=i(74395),Ke=i(49523);class Ye extends Ce.L{constructor(){super(...arguments),this.loadState=0,this.enableRubyConsumptionView=!1,this.enableRubyProngView=!1,this.enableWidgetsConsumptionView=!1,this.shouldRenderEoabLeadgen=!1}connectedCallback(){super.connectedCallback(),ne(this.config.slots,this.props.id),this.context=this.props.context;const t={contentId:this.props.id,parentContentId:this.props.id,contentPageType:"gallery",parentPageType:"gallery",mappedPageType:this.context.mappedPageType,strings:this.localizedStrings,infiniteReadingContext:this.context.infiniteReadingContext,nextSlideshowPromise:this.context.nextSlideshowPromise,providerId:this.context.slideshowData.provider?.id,disableAds:this.context.disableAds,enableDisplayAdsSlideshowRefresh:(0,c.G)(this.config.featureFlags,c.T.enableDspAdsRefresh),enableSlidePreload:(0,c.G)(this.config.featureFlags,c.T.enableSlidePreload),relativeInterstitialIndex:(0,c.G)(this.config.featureFlags,c.T.relativeInterstitialIndex),passUnstableGalleryAdSignal:(0,c.G)(this.config.featureFlags,c.T.passUnstableGalleryAdSignal),isStableGAInterstitialAds:this.context.isStableGAInterstitialAds,adServiceConfig:this.config.adServiceConfig,passAdOcidRegSize:this.config.passAdOcidRegSize,enableAddingAdCoords:this.config.enableAddingAdCoords,adTemplateConfig:this.config.adTemplateConfig,adBeaconServiceConfig:this.config.adBeaconServiceConfig,disableImageHashDeeplink:this.config.disableImageHashDeeplink,enableAdLayoutChange:(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange),enableAdFullBleed:(0,c.G)(this.config.featureFlags,c.T.enableAdFullBleed),enableAdSponsoredText:(0,c.G)(this.config.featureFlags,c.T.enableAdSponsoredText),enableContainerBasedImgSizing:(0,c.G)(this.config.featureFlags,c.T.enableContainerBasedImgSizing),enableAdFeedback:this.config.enableAdFeedback,preventDisplayAdRefresh:this.config.preventDisplayAdRefresh,enableRubyVerticalAds:(0,c.G)(this.config.featureFlags,c.T.enableRubyVerticalAds)&&(0,Ht.l)(),enableAdNewRubyGalleryT1:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT1)&&(0,Ht.l)(),enableAdNewRubyGalleryT2:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT2)&&(0,Ht.l)(),enableAdNewRubyGalleryT3:(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT3)&&(0,Ht.l)(),isIASEnabled:(0,c.G)(this.config.featureFlags,c.T.isIASEnabled),enableDVRubyGalleryAd:(0,c.G)(this.config.featureFlags,c.T.enableDVRubyGalleryAd),enableAdChoiceInCardActions:(0,c.G)(this.config.featureFlags,c.T.enableAdChoiceInCardActions),isThumbnailStripOnTop:(0,c.G)(this.config.featureFlags,c.T.isThumbnailStripOnTop),enableClassicGAHoverEffect:(0,c.G)(this.config.featureFlags,c.T.enableClassicGAHoverEffect),enableInsideFlippers:(0,c.G)(this.config.featureFlags,c.T.enableInsideFlippers)};this.slideshowProps={...t,slideshowData:this.slideshowData,autorotateTimeInMs:this.autorotateTimeInMs,zhCnNativeAdsRefreshRate:this.config.zhCnNativeAdsRefreshRate,autorotateAdRfshRate:this.config.autorotateAdRfshRate,enableNativeAdXandr:this.context.enableNativeAdXandr,zhCnNativeAdsRefresh:this.context.zhCnNativeAdsRefresh,disableSlideClick:(0,c.G)(this.config.featureFlags,c.T.disableSlideClick),enableAutorotate:(0,c.G)(this.config.featureFlags,c.T.enableAutorotate),enableDynamicAutorotate:(0,c.G)(this.config.featureFlags,c.T.dynamicAutorotate),enableWpoDynamicAutorotate:(0,c.G)(this.config.featureFlags,c.T.wpoDynamicAutorotate),autorotateOffByDefault:(0,c.G)(this.config.featureFlags,c.T.autorotateOffByDefault),enableExtendedArrowHitbox:(0,c.G)(this.config.featureFlags,c.T.enableExtendedArrowHitbox),enableImmersiveFullscreen:(0,c.G)(this.config.featureFlags,c.T.enableImmersiveFullscreen),enableImmersiveOnClick:(0,c.G)(this.config.featureFlags,c.T.enableImmersiveOnClick),useFullSizeAdCards:(0,c.G)(this.config.featureFlags,c.T.galleryFullAdCards),useFullWidthOnFiveCol:(0,c.G)(this.config.featureFlags,c.T.useFullWidthOnFiveCol),enableRubyNextSlideshow:(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard)&&this.enableRubyConsumptionView,enableLeftRailStyleOverride:this.enableRubyConsumptionView&&((0,c.G)(this.config.featureFlags,c.T.enableContentLeftRail)||(0,c.G)(this.config.featureFlags,c.T.enableLeftRailStyleOverride)),autorotateNextSlideshow:(0,c.G)(this.config.featureFlags,c.T.autorotateNextSlideshow)},this.fullscreenSlideshowProps={...t,slideshowData:this.slideshowFullscreenData,fullScreenSlots:this.config.fullScreenSlideshowSettings.slots,zhCnNativeAdsRefresh:this.context.zhCnNativeAdsRefresh,zhCnNativeAdsRefreshRate:this.config.zhCnNativeAdsRefreshRate,telemetryOverrides:{pageName:Ge.$.ImmersiveGallery}},this.loadState=1}get slideshowData(){return(0,Ke.h)(this.config.slideshowSettings.imageSettings,this.config.slideshowSettings.thumbnailImageSettings,this.config.slideshowSettings.interstitialNativeAds,(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange)?"":this.localizedStrings?.adSlideMetadataText||"",this.localizedStrings?.adSlideMetadataTitleText||"",this.context?.slideshowData,this.props.id,this.context?.disableAds,(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard),(0,c.G)(this.config.featureFlags,c.T.enableAdThumbnail),!1,this.enableRubyConsumptionView,(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT1)&&(0,Ht.l)(),(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT2)&&(0,Ht.l)(),(0,c.G)(this.config.featureFlags,c.T.enableAdNewRubyGalleryT3)&&(0,Ht.l)(),this.useTeraForVerticalData)}get slideshowFullscreenData(){return(0,Ke.h)(this.config.fullScreenSlideshowSettings.imageSettings,this.config.fullScreenSlideshowSettings.thumbnailImageSettings,this.config.fullScreenSlideshowSettings.interstitialNativeAds,(0,c.G)(this.config.featureFlags,c.T.enableAdLayoutChange)?"":this.localizedStrings?.adSlideMetadataText||"",this.localizedStrings?.adSlideMetadataTitleText||"",this.context?.slideshowData,this.props.id,this.context?.disableAds,(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),(0,c.G)(this.config.featureFlags,c.T.enableNextSlideshowCard),(0,c.G)(this.config.featureFlags,c.T.enableAdThumbnail),!1,!1,!1,!1,!1,this.useTeraForVerticalData)}get autorotateTimeInMs(){if(!(0,c.G)(this.config.featureFlags,c.T.enableAutorotate))return;let t=this.config.autorotateTimeInMs;const e=(0,Lt.n)(Vt.k0);return e&&(t=parseInt(e,10)),t}}(0,r.Cg)([Dt.sH],Ye.prototype,"isImmersiveFullscreenOpen",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"context",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"slideshowProps",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"fullscreenSlideshowProps",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"loadState",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"enableRubyConsumptionView",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"enableRubyProngView",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"enableWidgetsConsumptionView",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"shouldRenderEoabLeadgen",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"leadGenCardProps",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"moreFromProviderData",void 0),(0,r.Cg)([Dt.sH],Ye.prototype,"moreFromProviderTitle",void 0);let qe=class extends Ye{};qe=(0,r.Cg)([(0,Ce.E)({name:"desktop-gallery-content",template:je,styles:Me,shadowOptions:null})],qe);const Xe=Te.A`
`,Ze=xe.qy`<manga-page-wc :contentId=${t=>t.props.id} :contentPageType=${t=>t.contentPageType} :localizedStrings=${t=>t.mangaPageLocalizedStrings} :infiniteReadingContext=${t=>t.context.infiniteReadingContext} :parentTelemetryObject=${t=>t.rootTelemetryObject} :slideshowData=${t=>t.slideshowData}></manga-page-wc>`,Qe=xe.qy` ${t=>He(Ze,t.loadState)}
`;class Je extends Ce.L{constructor(){super(...arguments),this.loadState=0,this.useWebPImageFormat=!1}connectedCallback(){super.connectedCallback(),ne(this.config.slots,this.props.id),this.context=this.props.context,this.contentPageType="gallery",this.parentPageType="gallery",this.useWebPImageFormat=(0,c.G)(this.config.featureFlags,c.T.useWebPImageFormat),this.prepareSlideshowSettings(),this.loadState=1}prepareSlideshowSettings(){this.slideshowData=(0,Ke.h)(this.config.slideshowSettings.imageSettings,this.config.slideshowSettings.thumbnailImageSettings,this.config.slideshowSettings.interstitialNativeAds,this.slideshowStrings?.adSlideMetadataText||"",this.slideshowStrings?.adSlideMetadataTitleText||"",this.context.slideshowData,this.props.id,this.context.disableAds,this.useWebPImageFormat,void 0,(0,c.G)(this.config.featureFlags,c.T.enableAutorotate),this.config.slideshowSettings.showMangaChapterList,!1,!1,!1,!1,this.useTeraForVerticalData)}}(0,r.Cg)([Dt.sH],Je.prototype,"rootTelemetryObject",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"stampPagePZeroTTVR",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"shouldRenderEoabLeadgen",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"isImmersiveFullscreenOpen",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"loadState",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"mangaPageLocalizedStrings",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"slideshowStrings",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"slideshowData",void 0),(0,r.Cg)([Dt.sH],Je.prototype,"slideshowFullscreenData",void 0);let ti=class extends Je{};ti=(0,r.Cg)([(0,Ce.E)({name:"manga-content",template:Qe,styles:Xe,shadowOptions:null})],ti);const ei=Te.A` .video-content{aspect-ratio:16 / 9;width:100%}.ruby-video .video-content{border-radius:48px;overflow:hidden}.video-meta{margin-top:20px;font-size:14px}.video-abstract{margin-top:20px}.ruby-video .video-meta,.ruby-video .video-abstract{margin-inline:auto}.ruby-video .byline-under-title{margin:16px 0;max-width:100%}.action-bar-under-title social-bar-wc{flex-grow:0}.ruby-video .video-abstract{font-size:18px;font-weight:400;line-height:28px;font-family:var(--body-font)}.prong-ruby-consumption-video{max-width:var(--ruby-article-flex-max-width,624px);margin:0 auto}${(0,J.H5)(J.j1.c2)}{.ruby-video:not(.gem-video){width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)});margin-inline:auto}}${(0,J.H5)(J.j1.c1)}{.ruby-video .video-meta,.ruby-video .video-abstract{max-width:min(var(--ruby-article-flex-max-width,452px),100%)}.ruby-video .byline-under-title{margin:16px auto}}`;i(21627).c;const ii=xe.qy`<ruby-views-action-bar class="eocb ${t=>t.enableMoveBylineAndActionBar?"action-bar-under-title":""}" contentId=${t=>t.actionBarData?.contentId} locale=${t=>t.actionBarData?.locale} :config=${t=>t.actionBarData?.config} :templateType=${"eocb"} :localizedStrings=${t=>t.actionBarData?.localizedStrings} :props=${t=>t.actionBarData?.actionTrayProps} :providerName=${t=>t.actionBarData?.providerName} :providerLogoUrl=${t=>t.actionBarData?.providerLogoUrl} :updatedTimeStampFormat=${t=>t.actionBarData?.updatedTimeStampFormat} :shareUrl=${t=>t.actionBarData?.shareUrl} :enableMoveBylinePosition=${t=>t.enableMoveBylineAndActionBar}></ruby-views-action-bar>`,ri=xe.qy`<div class=${t=>(0,It.x)("video-content-wrapper",["prong-ruby-consumption-video",t.enableRubyProngView],["ruby-video",t.enableRubyConsumptionView],["gem-video",t.enableRubyGemView])}>${(0,$e.z)(t=>t.enableMoveBylineAndActionBar,xe.qy`<div class="video-meta byline-under-title"><span>${t=>t.publishedDateStringFormat}</span></div>`)} ${(0,$e.z)(t=>t.enableMoveBylineAndActionBar&&t.showActionBar,ii)}<div class="video-content">${t=>(0,Be.yN)((0,b.j1)(t.config.slots.content,`${t.config.slots.content.instanceId}-${t.props.id}`),{properties:t.videoCardProps})}</div>${(0,$e.z)(t=>t.enableRubyConsumptionView&&!t.enableMoveBylineAndActionBar,xe.qy`<div class="video-meta"><span>${t=>t.publishedDateStringFormat}</span></div>`)} ${(0,$e.z)(t=>!!t.abstract,xe.qy`<div class="video-abstract"><text-inline-expander :text=${t=>t.abstract} :strings=${t=>t.getLocalizedStringsToTextInlineStrings()} :lineCountClampSeeMore=${t=>t.config.abstractLineClamp} :shouldSeeMoreBelowText=${!0}></text-inline-expander></div>`)}</div>`,si=xe.qy`${t=>He(ri,t.loadState)}`;var oi=i(54863);class ni extends Ce.L{constructor(){super(...arguments),this.loadState=0,this.enableRubyConsumptionView=!1,this.enableRubyGemView=!1,this.enableRubyProngView=!1,this.enableMoveBylineAndActionBar=!1,this.showActionBar=!1}connectedCallback(){super.connectedCallback(),ne(this.config.slots,this.props.id),this.loadState=1}getLocalizedStringsToTextInlineStrings(){return{seeLess:this.localizedStrings?.seeLessDescriptionLabel||"",seeMore:this.localizedStrings?.seeMoreDescriptionLabel||""}}get abstract(){const t=this.props.context.videoData.abstract||"";return(0,oi.wR)(t)}get videoCardProps(){const t=this.props.context?.videoData;if(t.type===n.i.Video)return this.props;if(t.type===n.i.Webcontent){const{id:e,provider:i,sourceHref:r,title:s}=t;return{...this.props,id:r,context:{...this.props.context,autoplay:!0,directEmbedMediaPlayerProps:{rid:e,provider:i.name,title:s,providerId:i.id,metadata:{category:this.props.context.category,vertical:this.props.context.vertical},playerUrl:r},isAutoPlayEnabledForWebContent:!0,startVideoPositionSec:0}}}}}(0,r.Cg)([Dt.sH],ni.prototype,"loadState",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"enableRubyConsumptionView",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"enableRubyGemView",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"enableRubyProngView",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"publishedDateStringFormat",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"enableMoveBylineAndActionBar",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"showActionBar",void 0),(0,r.Cg)([Dt.sH],ni.prototype,"actionBarData",void 0),(0,r.Cg)([Dt.Jg],ni.prototype,"abstract",null),(0,r.Cg)([Dt.Jg],ni.prototype,"videoCardProps",null);let ai=class extends ni{};ai=(0,r.Cg)([(0,Ce.E)({name:"video-content",template:si,styles:ei,shadowOptions:null})],ai);var ci=i(94462),di=i(29158),li=i(16378),hi=i(57996);ci.w,li.x,hi._,di._,(0,Et.S)()&&(0,_t.dT)().then(async()=>{const{ContentCardListicle:t}=await Promise.all([i.e("common-feed-libs"),i.e("web-components_content-card-listicle_dist_index_js-_d5552")]).then(i.bind(i,69338));return t});const ui=xe.qy`${t=>(0,Be.yN)(t.config.slots.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:"00000",surveyTemplate:"feed-level",cardType:"feed-level",displayDelayMs:t.csatDwellTimeThresholdMs,autoDismissEvent:t.config.dismissCSATOnScroll?k.Z7:void 0}})}`,pi=(t,e)=>e.componentConfigs?.videoContentConfigs&&xe.qy`<video-content :config=${e.componentConfigs.videoContentConfigs} :props=${t} :localizedStrings=${e.localizedStrings?.videoContent||{}} :enableRubyConsumptionView=${t=>t.config.featureFlags?.enableRubyConsumptionView} :enableRubyGemView=${t=>t.config.featureFlags?.enableRubyGemReaderWidth} :enableRubyProngView=${t=>t.config.featureFlags?.enableWidgetsConsumptionView&&t.config.featureFlags?.enableRubyConsumptionView} :publishedDateStringFormat=${t=>t.publishedDateStringFormat} :enableMoveBylineAndActionBar=${t=>t.config.featureFlags?.enableMoveBylineAndActionBar} :showActionBar=${t=>!!(t.config.featureFlags?.enableRubyConsumptionView&&t.config.featureFlags?.showEndOfContentSocialBar&&t.config.componentConfigs?.viewsHeaderConfigs?.slots.socialBarWC)} :actionBarData=${t=>({contentId:t.contentId,locale:t.contentData?.locale,config:t.config.componentConfigs?.viewsHeaderConfigs,localizedStrings:t.actionBarStrings,actionTrayProps:t.contentProps?.actionTray,providerName:t.contentProps?.header?.provider.name,providerLogoUrl:t.contentProps?.header?.provider.logo?.src,updatedTimeStampFormat:t.publishedTimeStamp,shareUrl:t.shareUrl})}></video-content>`,mi=(t,e,i,r,s)=>i&&xe.qy`<desktop-article-content :config=${i} :slideshowConfig=${r||{}} :rootTelemetryObject=${e} :localizedStrings=${s||{}} :props=${t} :stampPagePZeroTTVR=${t=>t.stampPagePZeroTTVR} :isImmersiveFullscreenOpen=${t=>t.isImmersiveFullscreenOpen} :shouldRenderEoabLeadgen=${t=>t.shouldRenderEoabLeadgen} :providerLogoUrl=${t=>t.contentProps?.header?.provider.logo?.src} :handleFatalError=${t=>t.handleFatalError} :commonHeaderRef=${t=>t.commonHeaderRef} :trackingAdapter=${t=>t.tracker} :useTeraForVerticalData=${t=>Boolean(t.config?.featureFlags?.useTeraForVerticalData)} :contentInfoForAd=${t=>t.contentInfoForRightRailAd}></desktop-article-content>`,gi=(t,e,i)=>e&&xe.qy`<desktop-gallery-content :config=${e} :props=${t} :localizedStrings=${i||{}} :isImmersiveFullscreenOpen=${t=>t.isImmersiveFullscreenOpen} :enableRubyConsumptionView=${t=>t.config.featureFlags?.enableRubyConsumptionView} :enableRubyProngView=${t=>t.config.featureFlags?.enableRubyProngView} :enableWidgetsConsumptionView=${t=>t.config.featureFlags?.enableWidgetsConsumptionView} :overrideContentUrl=${t=>t.telemetryExtraDataWidgets?.url} :leadGenCardProps=${t=>t.leadGenCardProps} :shouldRenderEoabLeadgen=${t=>t.shouldRenderEoabLeadgen} :moreFromProviderData=${t=>(0,b.BZ)(t.moreFromProviderData)} :moreFromProviderTitle=${t=>t.config?.localizedStrings?.articlePage.moreFromProvider} :useTeraForVerticalData=${t=>Boolean(t.config?.featureFlags?.useTeraForVerticalData)}></desktop-gallery-content>`,bi=(t,e,i,r,s)=>i?.componentConfigs?.slideshowConfigs&&xe.qy`<manga-content :config=${i.componentConfigs.slideshowConfigs} :mangaPageLocalizedStrings=${s??{}} :props=${t} :slideshowStrings=${r??{}} :stampPagePZeroTTVR=${t=>t.stampPagePZeroTTVR} :rootTelemetryObject=${e} :shouldRenderEoabLeadgen=${t=>t.shouldRenderEoabLeadgen} :useTeraForVerticalData=${t=>Boolean(t.config?.featureFlags?.useTeraForVerticalData)}></manga-content>`,fi=xe.qy`<ruby-views-trending-now slot="content" :trendingNowData=${t=>t.trendingNowData} :trendingNowRefreshIcon=${rt} :rootTelemetryObject=${t=>t.telemetryObject}></ruby-views-trending-now>`,vi=xe.qy`<div class="breaking-news-banner-wrap" style=${t=>t.bkNewsStyles}><div class="breaking-news-banner">${t=>(0,Be.yN)(t.config.slots.breakingNews,{properties:{currentContentId:t.contentId,breakingNewsWillRender:t.breakingNewsWillRender}})}</div></div>`,yi=xe.qy`${t=>(0,Be.yN)(t.config.slots.toastWC)}`,wi=xe.qy`<div class=${t=>(0,It.x)("consumption-page-banner-ad",["below-headline","belowHeadline"===t.config.bannerAdPosition],["above-headline","aboveHeadline"===t.config.bannerAdPosition],["responsive-banner-ads",!!t.config.enableResponsiveBannerAds])} id=${t=>t.mainBannerAdProps?.id??t.contentProps?.bannerAd?.id}>${(0,$e.z)(t=>t.config.slots.bannerAd&&(t.isMainContent()&&t.mainBannerAdProps||t.contentProps?.bannerAd)&&!t.disableAds&&(0,Et.S)(),t=>(0,Be.yN)(t.config.slots.bannerAd,{properties:t.bannerAdConfig,memoize:!1}))}</div>`,xi=xe.qy`<div class=${t=>(0,It.x)("consumption-page-banner-wrapper",["below-headline","belowHeadline"===t.config.bannerAdPosition],["above-headline","aboveHeadline"===t.config.bannerAdPosition],[t.rubyStickyBannerClass,!!t.config.enableRubyStickyBanner],["responsive-banner-ads",!!t.config.enableResponsiveBannerAds])} style=${t=>""+(t.config.featureFlags?.enableRubyDisplayAds?"":`${t.bannerAdStyles}background-color: var(--banner-background);`)} slot=${t=>t.config.featureFlags?.enableRubyDisplayAds&&"belowHeadline"===t.config.bannerAdPosition?"header-slot":""} ${(0,ke.K)("bannerAdRef")}>${(0,$e.z)(t=>Boolean(t.config.slots.bannerAd)&&!t.disableAds,wi)}</div>`,$i=xe.qy`<div class="native-ad-banner-wrapper"><div class="native-ad-banner intra-article-ad-full-ruby">${t=>t.config?.slots?.bannerNativeAd&&(0,Be.yN)((0,b.j1)(t.config.slots.bannerNativeAd,"winlinear-article-inline-1"),{properties:{...t.getArticleBannerAdProperties(t.config)}})}</div></div>`,ki=xe.qy` ${t=>(0,Be.yN)(t.config.slots.commentsWC,{properties:{contentId:t.contentId,topicId:t.contentId,useRubyStyles:!0,useConsumptionCopilotStyles:!0}})}
`,Ai=t=>xe.qy`<ruby-views-action-bar slot=${"head"===t?"action-bar":""} class="${e=>(0,It.x)(["no-border","head"===t&&e.contentType===n.i.Gallery],["head","head"===t],["eocb","eocb"===t],["below-byline","head"===t&&!!e.config.featureFlags?.enableMoveBylinePosition])}" contentId=${t=>t.contentId} locale=${t=>t.contentData?.locale} :config=${t=>t.config.componentConfigs?.viewsHeaderConfigs} :templateType=${e=>t} :localizedStrings=${t=>t.actionBarStrings} :props=${t=>t.contentProps?.actionTray} :providerName=${t=>t.contentProps?.header?.provider.name} :providerLogoUrl=${t=>t.contentProps?.header?.provider.logo?.src} :updatedTimeStampFormat=${t=>t.publishedTimeStamp} :shareUrl=${t=>t.shareUrl} :enableAlignLeft=${t=>t.config.featureFlags?.enableAlignLeft}></ruby-views-action-bar>`,Ci=xe.qy`<div class=${t=>t.consumptionPageContentHeaderStyles} ${(0,ke.K)("consumptionPageContentHeaderRef")}><ruby-views-header :contentId=${t=>t.contentProps?.header?.contentId} :config=${t=>t.config.componentConfigs?.viewsHeaderConfigs} :isOpinion=${t=>t.contentProps?.header?.isOpinion} :localizedStrings=${t=>t.config.localizedStrings?.viewsHeader} :visualReadinessCallback=${t=>t.stampPagePZeroTTVR} :enablePublisherFlyout=${t=>t.contentProps?.header?.enablePublisherFlyout} :providerId=${t=>t.contentProps?.header?.provider.id} :providerLogoUrl=${t=>t.contentProps?.header?.provider.logo?.src} :providerName=${t=>t.contentProps?.header?.provider.name} :providerProfileId=${t=>t.contentProps?.header?.provider.profileId} :providerUrl=${t=>t.contentProps?.header?.provider.url} :publishedDateStringFormat=${t=>t.publishedDateStringFormat} :publishedDateTimeString=${t=>t.publishedDateTimeString} :updatedDateStringFormat=${t=>t.updatedDateStringFormat} :updatedDateTimeString=${t=>t.updatedDateTimeString} :updatedTimeStamp=${t=>t.updatedTimeStamp} :removeDivider=${t=>t.contentProps?.header?.removeDivider} :viewsAuthors=${t=>t.contentProps?.header?.author} :viewsHeaderText=${t=>t.contentProps?.header?.title} :isOneColumn=${t=>t.columnArrangement===J.j1.c1} :readTimeMin=${t=>t.contentProps?.header?.readTimeMin} :rootTelemetryObject=${t=>t.telemetryObject} :viewsHeaderTelemetryContentData=${t=>t.contentProps?.header?.viewsHeaderTelemetryContentData} :abstract=${t=>t.contentData?.abstract} :hideSocialBar=${t=>!t.config.featureFlags?.showStartOfContentSocialBar||t.contentType===n.i.Video} :enableRubyProngView=${t=>t.config.featureFlags?.enableWidgetsConsumptionView&&t.config.featureFlags?.enableRubyConsumptionView} :isArticleView=${t=>t.contentType===n.i.Article} :isVideoView=${t=>t.contentType===n.i.Video} :contentType=${t=>t.contentType} :shareUrl=${t=>t.shareUrl} :enableTitleEndDivider=${t=>t.shouldRenderMobileActionTray&&!t.config.featureFlags?.showStartOfContentSocialBar&&!t.config.featureFlags?.enableFloatingSocialBarFull&&(t.config.featureFlags?.enableFloatingSocialBarT2||t.config.featureFlags?.enableFloatingSocialBarT3)&&t.contentType!==n.i.Video} :enableReducedRubyTitle=${t=>t.config.featureFlags?.enableReducedRubyTitle} :enableAttributionWithMiniAT=${t=>(t.config.featureFlags?.enableFloatingSocialBarT2||t.config.featureFlags?.enableFloatingSocialBarT3)&&!t.config.featureFlags?.enableFloatingSocialBarFull&&t.contentType!==n.i.Video} :isFloatingBarEnabled=${t=>t.config.featureFlags?.enableFloatingSocialBarT2||t.config.featureFlags?.enableFloatingSocialBarT3} :locale=${t=>t.contentData?.locale} :actionTrayProps=${t=>t.contentProps?.actionTray} :actionBarStrings=${t=>t.actionBarStrings} :updatedTimeStampFormat=${t=>t.updatedTimeStamp} :enableMoveBylinePosition=${t=>t.config.featureFlags?.enableMoveBylinePosition} :enableAlignLeft=${t=>t.config.featureFlags?.enableAlignLeft} :enableFontSizeIncreasing=${t=>t.config.featureFlags?.enableFontSizeIncreasing} :enablePublisherAboveTitle=${t=>t.config.featureFlags?.enablePublisherAboveTitle} ${(0,ke.K)("viewsHeaderRef")}>${(0,$e.z)(t=>t.shouldRenderBannerAdBelowHeadline,xi)} ${(0,$e.z)(t=>t.config.featureFlags?.showStartOfContentSocialBar&&t.contentType!==n.i.Video,Ai("head"))}</ruby-views-header></div>`,Fi=xe.qy`<div class=${t=>t.consumptionPageContentHeaderStyles} ${(0,ke.K)("consumptionPageContentHeaderRef")}><views-header-wc :contentId=${t=>t.contentProps?.header?.contentId} :config=${t=>t.config.componentConfigs?.viewsHeaderConfigs} :disableCopilotButtons=${t=>t.disableAllAIFeatures} :isMainContent=${t=>t.isMainContent()} :isOpinion=${t=>t.contentProps?.header?.isOpinion} :localizedStrings=${t=>t.config.localizedStrings?.viewsHeader} :visualReadinessCallback=${t=>t.stampPagePZeroTTVR} :enablePublisherFlyout=${t=>t.contentProps?.header?.enablePublisherFlyout} :providerId=${t=>t.contentProps?.header?.provider.id} :providerLogoUrl=${t=>t.contentProps?.header?.provider.logo?.src} :providerName=${t=>t.contentProps?.header?.provider.name} :providerProfileId=${t=>t.contentProps?.header?.provider.profileId} :providerUrl=${t=>t.contentProps?.header?.provider.url} :publishedDateString=${t=>t.contentProps?.header?.publishedDateString} :removeDivider=${t=>t.contentProps?.header?.removeDivider} :viewsAuthors=${t=>t.contentProps?.header?.author} :viewsHeaderText=${t=>t.contentProps?.header?.title} :isOneColumn=${t=>t.columnArrangement===J.j1.c1} :readTimeMin=${t=>t.contentProps?.header?.readTimeMin} :rootTelemetryObject=${t=>t.telemetryObject} :viewsHeaderTelemetryContentData=${t=>t.contentProps?.header?.viewsHeaderTelemetryContentData} :usePolishedStyles=${t=>t.usePolishedStyles} ${(0,ke.K)("viewsHeaderRef")}></views-header-wc></div>`,Ri=xe.qy`<div class=${t=>(0,It.x)(["consumption-page-eocb",!t.leadGenCardProps],["consumption-page-gridarea_eocb_leadgen",!!t.leadGenCardProps],["kumo-consumption-page-eocb",!!t.config.featureFlags?.enableRubyConsumptionView])}><desktop-end-of-content-block :category=${t=>t.contentProps?.endOfContentBlock?.category} :columnView=${t=>t.columnArrangement} :config=${t=>t.contentProps?.endOfContentBlock?.config} :contentId=${t=>t.contentProps?.endOfContentBlock?.contentId} :enableEoabNativeXandr=${t=>t.contentProps?.endOfContentBlock?.enableEoabNativeXandr} :nativeAdMappedPageType=${t=>t.contentProps?.endOfContentBlock?.nativeAdMappedPageType} :nativeAdPartnerId=${t=>t.contentProps?.endOfContentBlock?.nativeAdPartnerId} :vertical=${t=>t.contentProps?.endOfContentBlock?.vertical} :disableAds=${t=>t.contentProps?.endOfContentBlock?.disableAds} :isImmersiveFullscreenOpen=${t=>t.isImmersiveFullscreenOpen} :leadGenCardProps=${t=>t.leadGenCardProps} :shouldRenderEoabLeadgen=${t=>t.shouldRenderEoabLeadgen} :moreFromProviderData=${t=>t.useRightRailMoreFromCard?void 0:t.moreFromProviderData} :collapsible=${t=>t.config?.componentConfigs?.articlePageConfig?.collapsibleMFP} :moreFromProviderTitle=${t=>t.config?.localizedStrings?.articlePage.moreFromProvider}></desktop-end-of-content-block></div>`,Si=xe.qy`<views-right-rail :contentId=${t=>t.contentProps?.rail?.contentId} :contentTitle=${t=>t.contentProps?.rail?.contentTitle} :isAdsDisabled=${t=>t.contentProps?.rail?.disableAds||t.isImmersiveFullscreenOpen} :isHorizontalLayout=${t=>t.isRailBelow} :topPositionPx=${t=>t.rightRailTopPosition} :topDisplayAdConfig=${t=>t.contentProps?.rail?.config.slots.topDisplayAd} :bottomDisplayAdConfig=${t=>t.contentProps?.rail?.config.slots.bottomDisplayAd} :contentInfoForAd=${t=>t.contentInfoForRightRailAd} :extraInfoTopDisplayAd=${t=>t.extraInfoForRightRailTopDisplayAd} :skipInitialRenderingVisibilityCheckForAds=${t=>t.infiniteReadingContext?.isMainArticle||t.isNewlyReplacedArticle} :contentProviderCardConfig=${t=>t.config.componentConfigs?.rightRailConfigs?.topStoriesRequestConfig?null:t.contentProviderCardConfig} :publisherProfileId=${t=>t.contentProps?.header?.provider.profileId} :zhCnNativeAdsRefresh=${t=>t.zhCnNativeAdsRefresh} :tallerRightRailAdOnTop=${t=>t.tallerRightRailAdOnTop} :isMainArticle=${t=>t.infiniteReadingContext?.isMainArticle} :pageType=${t=>"view"} :railBelowLoaded=${t=>t.railBelowLoaded} :railRightLoaded=${t=>t.railRightLoaded} :topStoriesConfig=${t=>t.config.componentConfigs?.rightRailConfigs?.topStoriesRequestConfig||t.config.componentConfigs?.rightRailConfigs?.topStoriesFallbackConfig} :topStoriesHeading=${t=>(t.config.componentConfigs?.rightRailConfigs?.localizedStrings?.topStoriesHeading??"Top Stories").toUpperCase()} :topStoriesIconSvg=${`<img src="${it}"/>`}></views-right-rail>`,_i=xe.qy`<div class="consumption-page-feed-wrapper" ${(0,ke.K)("riverElementRef")}><h2 class=${t=>t.riverHeadingClassnames}>${t=>t.config.localizedStrings?.riverHeading||"More for You"}</h2>${t=>(0,Be.yN)((0,b.j1)(t.config.slots.feedWC,`${t.config.slots.feedWC.instanceId}-${t.contentId}`),{properties:t.feedProps})}</div>`,Ti=xe.qy`
${t=>t.cardProps?.experienceConfigInfo?(0,Be.yN)((0,b.j1)(t.cardProps?.experienceConfigInfo,`${t.cardProps?.experienceConfigInfo?.instanceId}-${t.cardProps?.id}-top`),{properties:t.cardProps}):null}
`,Ii=xe.qy`
${(0,$e.z)((t,e)=>t.cardProps?.experienceConfigInfo&&!e.parent.isTopSpanContentDisabled(t.card.type),Ti)}
`,Bi=xe.qy`<div class="top-span-module" ${(0,ke.K)("topSpanRef")}>${(0,Ae.ux)(t=>t.topSpanModuleContent,Ii)}</div>`,Di=xe.qy`<div class="consumption-page-gridarea_action" style=${t=>t.actionTrayGridAreaStyles} role="complementary"><div class="consumption-page-action-tray-wrapper" style=${t=>t.actionTrayWrapperStyles}>${t=>(0,Be.yN)(t.config.slots.actionTray,{properties:t.composeActionTrayProps(t.contentProps?.actionTray),includeTelemetryTag:!1,memoize:!1})}</div></div>`,Pi=xe.qy` ${t=>(0,Be.yN)({...t.config.slots.actionTray,instanceId:`action-tray-${t.contentId}`},{properties:t.composeActionTrayProps(t.contentProps?.actionTray),includeTelemetryTag:!1,memoize:!1})}
`,Ei=xe.qy`<div class="consumption-page-gridarea_rail" style=${t=>`margin-top: ${t.bannerHeight}px;`}><div class="consumption-page-rail-wrapper" role="region">${Si}</div></div>`,zi=xe.qy` ${t=>t.contentProviderCardConfig?(0,Be.yN)(t.contentProviderCardConfig,{properties:t.rubyRightRailProviderCarouselProps}):null}
`,Ni=xe.qy`<div class=${t=>(0,It.x)(["ruby-rail-sticky",!!t.isRubyRightRailSticky],["ruby-rail-sticky-banner",!!t.config.enableRubyStickyBanner],["ruby-rail-sticky-banner-exit",t?.rubyStickyBannerClass?.includes?.("ruby-sticky-banner-exit")])}>${t=>(0,Be.yN)(t.contentProps?.rail?.config?.slots?.topDisplayAd,{properties:t.rubyRightRailProps,memoize:!1})} ${(0,$e.z)(t=>t.useRightRailMoreFromCard,zi)} ${t=>t.trendingNowData&&t.isFirstLoadedContent()?fi:null}</div>`,Oi=xe.qy`<div class="ruby-right-rail-extended"><div>${t=>(0,Be.yN)(t.contentProps?.rail?.config?.slots?.topDisplayAd,{properties:t.rubyRightRailProps,memoize:!1})}</div>${(0,$e.z)(t=>t.useRightRailMoreFromCard,zi)}<div class="ruby-rail-sticky-bottom" ${(0,ke.K)("rubyRailBottomAdRef")}>${t=>(0,Be.yN)(t.contentProps?.rail?.config?.slots?.bottomDisplayAd,{properties:t.rubyRightRailBottomAdProps,memoize:!1})}</div></div>`,Mi=xe.qy`<div class=${t=>(0,It.x)("consumption-page-ruby-right-rail",["rail-with-keytakeaways-section",!!t.renderKeyTakeawaysSection],["right-rail-with-ads",!!t.isRubyRightRailAds],["ruby-rail-sticky-full-height",!!t.isRRStickyForLinearFeed])} role="region" ${(0,ke.K)("rubyRightRailRef")}>${(0,$e.z)(t=>!t.contentProps?.rail?.config?.slots?.bottomDisplayAd,Ni)} ${(0,$e.z)(t=>!!t.contentProps?.rail?.config?.slots?.bottomDisplayAd,Oi)}</div>`,Hi=xe.qy`<iframe id="consumptionAIConversationStartersIframe" class="conversationStartersCompanionIframe" sandbox="allow-scripts allow-same-origin" frameborder="0" src=${t=>(0,b.sT)(t.contentId,"aics")} scrolling="no" style="${t=>t.conversationStartersIframeStyles}"></iframe>`,Li=xe.qy` ${(0,$e.z)(t=>t.renderKeyTakeawaysSection,xe.qy`${t=>t.config?.componentConfigs?.viewsHeaderConfigs?.slots?.keyTakeawaysWC?(0,Be.yN)(t.config.componentConfigs.viewsHeaderConfigs.slots.keyTakeawaysWC,{properties:{collapsed:t.keyTakeawaysCollapsed,isPeekView:!!t.config?.componentConfigs?.viewsHeaderConfigs?.isPeekView,keyTakeaways:t.keyTakeawaysData,contentId:t.contentId,rootTelemetryObject:t.telemetryObject,disableCopilotButtons:t.contentProps?.header?.disableCopilotButtons||!t.isMainContent()&&1===t.config?.componentConfigs?.viewsHeaderConfigs.enableKTButtons,enableKTCopilot:!!t.config?.componentConfigs?.viewsHeaderConfigs?.enableKTCopilot,enableCopilotTheme:t.enableCopilotTheme,isCopilotApp:!1,enableKTButtons:t.config?.componentConfigs?.viewsHeaderConfigs?.enableKTButtons,seeMoreTelemetryTag:t.keyTakeawaysTelemetryObjects?.seeMore?.getMetadataTag(),reportTelemetryTag:t.keyTakeawaysTelemetryObjects?.reportIssue?.getMetadataTag(),enableEntAIString:t.config?.componentConfigs?.viewsHeaderConfigs?.enableEntAIString&&(0,b.dk)()},memoize:!1}):""}`)}
`,Vi=xe.qy`<consumption-mini-feed :contentId="${t=>t.contentId}" :columnArrangement="${t=>t.columnArrangement}" :sharedTimestampConfig="${t=>t.config.slots?.sharedTimestampUtil}" :contentType="${t=>t.contentType}" :noScrollContentCount="${t=>t.vfpConnectorNoScrollContentCount}" :titleString="${t=>t.config.miniRiverRelatedVideosHeading?t.config.localizedStrings?.relatedVideos:t.config.localizedStrings?.relatedStories}" :nativeAdConfig=${t=>t.config.miniRiverNativeAd} :mappedPageType="${t=>t.contentProps?.endOfContentBlock?.nativeAdMappedPageType}" :disableAds="${t=>t.disableAds}" :partnerId="${t=>t.contentProps?.endOfContentBlock?.nativeAdPartnerId}" :enableNativeAdXandr="${t=>t.contentProps?.endOfContentBlock?.enableEoabNativeXandr}" :cardActionRef="${t=>t.cardActionRef}"></consumption-mini-feed>`,Ui=xe.qy`<div class="${t=>(0,It.x)("consumption-page",t.dwellTimeStartAllowedClassName,["consumption-ruby",!!t.config.featureFlags?.enableRubyConsumptionView],["ruby-fitcontent",!!t.config.enableOneRowContent])} " id="${t=>wt(t.contentId)}" ${(0,ke.K)("consumptionPageRef")} data-clarity-region="${t=>t.dataClarityRegion}"><div class=${t=>(0,It.x)("consumption-page-structure",["consumption-page-structure-no-grid",!!t.config.featureFlags?.enableRubyConsumptionView],["consumption-page-structure-gem",!!t.config.featureFlags?.enableRubyGemReaderWidth],["consumption-page-structure-widgets",!!t.config.featureFlags?.enableWidgetsConsumptionView],["consumption-page-structure-support-padding",!t.config.featureFlags?.enableRubyConsumptionView&&!!t.config.componentConfigs?.slideshowConfigs?.featureFlags?.enableClassicGAHoverEffect],["extended-right-rail",!!t.config.featureFlags?.enableExtendedRightRail&&!t.config.featureFlags?.enableRubyConsumptionView&&t.contentType===n.i.Article],t.contentAreaClassname||"")} ${(0,ke.K)("consumptionPageStructureRef")} style=${t=>t.gridOverriddenStyle+t.stickyBannerSizeStyle+t.stickyBannerAdStyle}>${(0,$e.z)(t=>t.shouldRenderActionTray&&(0,Et.S)(),Di)}<div class=${t=>(0,It.x)("consumption-page-gridarea_content",["consumption-page-ruby-structure",!!t.config.featureFlags?.enableRubyRightRail],["action-bar-below-byline",!!t.config.featureFlags?.enableMoveBylinePosition],["responsive-banner-active",!!t.config.enableResponsiveBannerAds])}><div class=${t=>(0,It.x)("viewsHeaderWrapper",["ruby-sticky-wrapper",t.rubyStickyBannerClass?.startsWith?.("ruby-sticky-banner-visible")])} ${(0,ke.K)("consumptionPageViewsHeaderAreaRef")}>${(0,$e.z)(t=>t.showNativeAdBanner,$i)} ${(0,$e.z)(t=>!t.showNativeAdBanner&&t.shouldRenderBannerAdAboveHeadline,xi)} ${(0,$e.z)(t=>t.isMainContent()&&Boolean(t.config.slots.breakingNews)&&(0,Et.S)(),vi)} ${(0,$e.z)(t=>t.contentProps?.header,xe.qy` ${(0,$e.z)(t=>t.config.featureFlags?.enableRubyConsumptionView,Ci,Fi)} `)}</div>${(0,$e.z)(t=>(0,Et.S)()&&t.topSpanModuleContent&&t.topSpanModuleContent.length,Bi)}<div class=${t=>(0,It.x)("consumption-page-content-wrapper",t.contentAreaClassname||"",["with-keytakeaways-section",t.renderKeyTakeawaysSection])} ${(0,ke.K)("consumptionPageContentRef")} role="main">${Li} ${t=>t.contentProps?.content&&((t,e,i,r)=>{const s=e.slots.content,o=e.localizedStrings,a={...e.componentConfigs?.slideshowConfigs,slideshowSettings:{...e.componentConfigs?.slideshowConfigs?.slideshowSettings}};switch(t){case n.i.Webcontent:case n.i.Video:return pi(i,e);case n.e.Manga:return bi(i,r,e,o?.slideshow,o?.mangaPage);case n.i.Gallery:return gi(i,a,o?.slideshow);case n.i.Article:return mi(i,r,e.componentConfigs?.articlePageConfig,a,{...o?.articlePage,...o?.slideshow});default:return(0,Be.yN)(s,{properties:i})}})(t.useMangaWCPage?n.e.Manga:t.contentType,t.config,t.contentProps.content,t.telemetryObject)}</div>${(0,$e.z)(t=>t.shouldRenderEocb,Ri)} ${(0,$e.z)(t=>!t.isRailBelow&&t.isRightRailReady&&t.isRubyRightRail,Mi)} ${(0,$e.z)(t=>t.enableBigRRAd&&t.config.featureFlags?.enableRubyConsumptionView&&t.config.featureFlags?.showEndOfContentSocialBar&&t.config.componentConfigs?.viewsHeaderConfigs?.slots.socialBarWC&&!t.config.featureFlags?.enableMoveBylineAndActionBar,Ai("eocb"))} ${(0,$e.z)(t=>!t.noCopilotAPI&&t.shouldRenderAIConversationStarters&&t.contentType,Hi)}</div>${(0,$e.z)(t=>!t.isRailBelow&&t.isRightRailReady&&!t.isRubyRightRail,Ei)} ${(0,$e.z)(t=>!t.enableBigRRAd&&t.config.featureFlags?.enableRubyConsumptionView&&t.config.featureFlags?.showEndOfContentSocialBar&&t.config.componentConfigs?.viewsHeaderConfigs?.slots.socialBarWC&&!t.config.featureFlags?.enableMoveBylineAndActionBar,Ai("eocb"))}</div>${(0,$e.z)(t=>t.isRailBelow&&t.isRightRailReady&&!t.config.featureFlags?.enableRubyRightRail,xe.qy`<div class="railBelow_c2">${Si}</div>`)}<div ${(0,ke.K)("aboveRiverBlockRef")}>${t=>Wi(t)?(0,Be.yN)(t.config.slots.aboveRiverBlock,{properties:t.contentProps?.aboveRiverBlock,memoize:!1}):""}</div>${(0,$e.z)(t=>t.config.slots.feedWC&&t.feedProps&&!t.deferRenderingRiver&&!t.hideRiver&&(0,Et.S)(),_i)} ${(0,$e.z)(t=>t.config.slots.toastWC&&(0,Et.S)(),yi)} ${(0,$e.z)(t=>t.shouldRenderMobileActionTray&&(0,Et.S)(),Pi)} ${(0,$e.z)(t=>t.config.featureFlags?.enableRubyConsumptionView&&!t.config.featureFlags.enableRubyGemReaderWidth&&!t.enableRubyInfRead&&!t.enableGemContinuousReading,ki)} ${(0,$e.z)(t=>t.displayCSAT&&(0,Et.S)(),ui)}</div>${(0,$e.z)(t=>t.showOneRowContent&&!t.deferRenderingRiver&&(0,Et.S)(),Vi)}
`;function Wi(t){return!(t.disableAds||!t.config.slots.aboveRiverBlock||!t.contentProps?.aboveRiverBlock||!t.aboveRiverBlockData)&&Boolean(!t.config.disableNonInfRiver||t.feedProps)}const ji=xe.qy`<div class="consumption-error-page"><h1>${t=>t.errorText}</h1><p>${t=>t.config.localizedStrings?.redirectMessage}</p></div>`,Gi=xe.qy`<div><consumption-error-page :contentId=${t=>t.contentId} :errorPageConfig=${t=>t.config.componentConfigs?.errorPageConfig} :localizedStrings=${t=>t.config.localizedStrings?.errorPage} :feedConfig=${t=>t.config.featureFlags?.enableRubyConsumptionView?void 0:t.config.slots.feedWC} :telemetryObject=${t=>t.telemetryObject} :backToFeed=${t=>t.backToFeed}></consumption-error-page><div>`,Ki=xe.qy`<div class="ruby-consumption-error-page"><ruby-consumption-error-page :localizedStrings=${t=>t.config.localizedStrings?.rubyErrorPage} :telemetryObject=${t=>t.telemetryObject} :backToFeed=${t=>t.backToFeed}></ruby-consumption-error-page></div>`,Yi=xe.qy` ${t=>t.enableConsumptionErrorPage?t.config.featureFlags?.enableRubyConsumptionView?Ki:Gi:ji}
`,qi=xe.qy`<loading-state-article :disableMrr=${t=>t.config.featureFlags?.enableWidgetsConsumptionView}></loading-state-article>`,Xi=xe.qy` ${t=>t.errorState&&!t.config.featureFlags?.enableWidgetsConsumptionView?Yi:t.isLoading?qi:(t.config.componentConfigs?.rightRailConfigs?.enableRubyTrendingNow&&(0,Et.S)()&&(0,_t.dT)().then(async()=>{const{RubyViewsTrendingNow:t}=await i.e("web-components_ruby-views-trending-now-wc_dist_index_js").then(i.bind(i,29706));return t}),Ui)}
`;var Zi=i(88638),Qi=i(82905),Ji=i(25975),tr=i(33544),er=i(25987);const ir="calc(100vw - 65px)",rr=Te.A`
consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:${ir}}${(0,J._D)(J.j1.c2,null)}{consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:clamp(${(0,ye.c)(Zi.vT)},${ir},${(0,ye.c)(Zi.sX)})}consumption-page[enable-ruby-article-flex] .consumption-page-content-header{width:${ir}}}${(0,J._D)(J.j1.c3,null)}{consumption-page[enable-ruby-article-flex]{--ruby-article-flex-max-width:${(0,ye.c)(Zi.Nm)}}}`;var sr=i(4126),or=i(47810);const nr=Te.A`.consumption-page-ruby-structure{grid-template-columns:${(0,ye.c)(a.l$)} ${(0,ye.c)(a.D7)} 1fr ${(0,ye.c)(a.D7)} ${(0,ye.c)(a.zj)}}ruby-views-action-bar.eocb{grid-column:3 / 4;width:100%}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(a.D7+a.zj-a.l$-a.D7).toString()}px}@media (max-width:${(0,ye.c)(a.gk)}){.consumption-page-ruby-structure{grid-template-columns:${(0,ye.c)(a.l0)} ${(0,ye.c)(a.TO)} 1fr ${(0,ye.c)(a.TO)} ${(0,ye.c)(a.zj)}}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(a.TO+a.zj-a.l0-a.TO).toString()}px}}${(0,J.H5)(J.j1.c3)}{.consumption-page-ruby-structure{grid-template-columns:0px ${(0,ye.c)(a.Cv)} 1fr ${(0,ye.c)(a.Cv)} ${(0,ye.c)(a.zj)}}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:${(a.Cv+a.zj-a.Cv).toString()}px}}@media (max-width:1199px){.consumption-page-structure-no-grid .consumption-page-content-header{max-width:calc(100vw - ${(a.Cv+a.zj-a.Cv).toString()}px)}}@media (max-width:${(0,ye.c)(a.CD)}){.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}ruby-views-action-bar.eocb{grid-column:unset;width:100%}.consumption-page-ruby-right-rail{display:none}.consumption-page-structure-no-grid .consumption-page-content-header{padding-inline-end:0;max-width:948px}}`,ar=Te.A` .consumption-page-ruby-right-rail.ruby-rail-sticky-full-height,.consumption-page-ruby-right-rail.ruby-rail-sticky-full-height .ruby-rail-sticky,.ruby-rail-sticky-bottom{z-index:0}.viewsHeaderWrapper.ruby-sticky-wrapper ~ .consumption-page-ruby-right-rail .ruby-rail-sticky-banner:not(.ruby-rail-sticky-banner-exit){top:94px}`,cr=Te.A`@media (min-width:${(0,ye.c)(a.DF)}) and (min-height:${(0,ye.c)(a.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-columns:${(0,ye.c)(a.zj)} ${(0,ye.c)(a.Kv)} 1fr ${(0,ye.c)(a.Kv)} ${(0,ye.c)(a.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{grid-column:3 / 4;width:100%}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:unset}}@media (min-width:${(0,ye.c)(a.HN)}) and (max-width:${(0,ye.c)(a.DF-1)}) and (min-height:${(0,ye.c)(a.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header header header header header" "left-rail . content . right-rail" "eocb eocb eocb . .";grid-template-columns:0px 0px 1fr ${(0,ye.c)(a.Kv)} ${(0,ye.c)(a.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:unset}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:420px}}@media (min-width:${(0,ye.c)(a.SU)}) and (max-width:${(0,ye.c)(a.HN-1)}) and (min-height:${(0,ye.c)(a.t6)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header header header header header" "left-rail . content . right-rail" "eocb eocb eocb . .";grid-template-columns:0px 0px 1fr ${(0,ye.c)(a._$)} ${(0,ye.c)(a.zj)}}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:unset}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:330px}consumption-page[enable-ruby-article-flex]{--article-content-width:592px;--ruby-article-flex-max-width:592px}.consumption-page-structure-no-grid.article_content .consumption-page-content-header.align-left{max-width:592px}}@media (max-width:${(0,ye.c)(a.SU-1)}),(max-height:${(0,ye.c)(a.t6-1)}){.consumption-page-structure-no-grid.article_content .consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{grid-column:unset;width:100%;margin:0px auto}.consumption-page-structure-no-grid.article_content .consumption-page-ruby-right-rail{display:none}.consumption-page-structure-no-grid.article_content .consumption-page-content-header{padding-inline-end:0}}@media (max-width:663px){consumption-page[enable-ruby-article-flex]{--article-content-width:unset}.consumption-page-structure-no-grid.article_content ruby-views-action-bar.eocb{margin:0px auto}}`,dr=Te.A`consumption-page{--video-content-width:864px;--article-content-width:688px;--gallery-header-width:1216px;--gallery-header-title-width:864px;${(0,J.H5)(J.j1.c3)}{--video-content-width:864px;--article-content-width:688px;--gallery-header-width:min(1040px,calc(100vw - calc(2 * 58px)))}${(0,J.H5)(J.j1.c2)}{--video-content-width:min(688px,calc(100vw - calc(2 * ${Ji.iIh})));--article-content-width:min(688px,calc(100vw - calc(2 * ${Ji.iIh})));--gallery-header-width:min(688px,calc(100vw - calc(2 * ${Ji.iIh})));--gallery-header-title-width:min(688px,calc(100vw - calc(2 * ${Ji.iIh})))}${(0,J.H5)(J.j1.c1)}{--video-content-width:min(360px,calc(100vw - calc(2 * ${Ji.iIh})));--article-content-width:min(360px,calc(100vw - calc(2 * ${Ji.iIh})));--gallery-header-width:min(360px,calc(100vw - calc(2 * ${Ji.iIh})));--gallery-header-title-width:min(360px,calc(100vw - calc(2 * ${Ji.iIh})));--ruby-view-header-title-width:var(--article-content-width);--intra-article-margin:0 auto}}consumption-page{--article-content-padding:0}.consumption-page-structure:is(.video_content){max-width:min(var(--video-content-width),100%);--ruby-article-flex-max-width:var(--video-content-width)}.consumption-page-structure:is(.article_content){--ruby-article-flex-max-width:var(--article-content-width)}.consumption-page-structure:is(.article_content) .consumption-page-content-header{max-width:var(--article-content-width);margin:0 auto}.consumption-page-structure:is(.video_content) .consumption-page-content-header{max-width:var(--video-content-width);margin:0 auto}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:unset}.consumption-page-structure:is(.gallery_content) .consumption-page-content-header{width:var(--gallery-header-width);max-width:unset;--ruby-view-header-title-width:var(--gallery-header-title-width)}${(0,J._D)(J.j1.c2,null)}{.consumption-page-structure:is(.article_content) .consumption-page-ruby-structure{grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:1fr minmax(${Ji.iIh},104px) minmax(616px,var(--ruby-article-flex-max-width,auto)) minmax(${Ji.iIh},104px) 1fr}}${(0,J.H5)(J.j1.c1)}{.consumption-page-structure-no-grid .consumption-page-gridarea_content{max-width:var(--article-content-width);margin:0 auto}ruby-views-action-bar.eocb{max-width:var(--article-content-width)}.consumption-eoab{max-width:var(--article-content-width);margin:0 auto;overflow:hidden}.consumption-eoab .eoab-ad-full.adaptive,.consumption-eoab [class*="eoab-ad-full"].adaptive,.consumption-eoab.no-background .eoab-ad-full.adaptive,.consumption-eoab.no-background [class*="eoab-ad-full"].adaptive{margin-inline:0;width:100%}.content-consumption-container{padding:0}}`,lr=Te.A` .consumption-page{--banner-background:#ffffff}@media (prefers-color-scheme:dark){.consumption-page{--banner-background:#242424}}.consumption-page-banner-ad{min-height:${(0,ye.c)(nt)};padding-top:${(0,ye.c)(lt)}}.consumption-ruby .consumption-page-banner-ad.above-headline,.consumption-ruby .consumption-page-banner-ad.below-headline{min-height:${(0,ye.c)(at)};padding-top:0}.consumption-page-banner-ad.above-headline.responsive-banner-ads{min-height:0;padding-top:0}.railBelow_c2{display:flex}.railBelow_c2 *{margin:auto;margin-bottom:40px}.consumption-page-banner-wrapper{position:sticky;width:100vw;z-index:300;align-items:center;display:flex;flex-direction:column;justify-content:center;background-color:var(--banner-background);margin-bottom:4px}.consumption-ruby .consumption-page-banner-wrapper{position:relative;width:100%}.consumption-ruby .consumption-page-banner-wrapper.above-headline{background-color:transparent;margin-bottom:${(0,ye.c)(ut)}}.ruby-consumption-page:has(.consumption-page-banner-wrapper.above-headline.responsive-banner-ads){padding-top:0}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner{background-color:var(--container-background-color-override,${Ji.Le$});top:var(--headerHeight,93px);position:sticky}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible .consumption-page-banner-ad{padding-bottom:var(--bannerPaddingBottom,0px)}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible{background-color:var(--container-background-color-override,${Ji.Le$});position:fixed;width:100%;left:0px;top:0px;padding-top:var(--headerHeight,93px);z-index:${er.P.Over.toString()};transition:transform 0.3s ease;transform:translateY(0);margin-bottom:0px}.consumption-ruby .consumption-page-banner-wrapper.above-headline.ruby-sticky-banner-visible.ruby-sticky-banner-exit{transform:translateY(var(--ruby-sticky-banner-exit-translate,-100%))}.consumption-ruby .viewsHeaderWrapper.ruby-sticky-wrapper .consumption-page-content-header{margin-top:var(--ruby-sticky-banner-margin,146px)}.consumption-ruby .consumption-page-banner-wrapper.below-headline{background-color:transparent;margin-bottom:16px}.consumption-page-structure{display:grid;grid-template-areas:"actions . content . rail"". . eocb . .";grid-template-columns:${(0,ye.c)(a.zM)} ${(0,ye.c)(a.Lw)} ${(0,ye.c)(a.Ii)} ${(0,ye.c)(a.Lw)} ${(0,ye.c)(a.c_)};justify-content:center;position:relative}.consumption-page-structure.consumption-page-structure-support-padding{--ga-hover-support-padding:${(0,ye.c)(vt)}}.consumption-page-ruby-structure{display:grid;grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:${(0,ye.c)(160)} ${(0,ye.c)(92)} 1fr ${(0,ye.c)(92)} ${(0,ye.c)(160)};justify-content:center;position:relative}.consumption-page-ruby-structure > .viewsHeaderWrapper{grid-area:header}.consumption-page-ruby-structure > .consumption-page-content-wrapper{grid-area:content}.consumption-page-ruby-structure > .consumption-page-eocb{grid-area:eocb;width:100%}.consumption-page-ruby-structure > .conversationStartersCompanionIframe{grid-column:2 / -2}.consumption-page-structure.insight{grid-template-columns:${(0,ye.c)(a.zM)} ${(0,ye.c)(a.Lw)} ${(0,ye.c)(a.fA)} ${(0,ye.c)(a.Lw)} ${(0,ye.c)(a.zM)}}.consumption-page-structure.insight .breaking-news-banner-wrap{justify-content:flex-start;width:100%}.consumption-page-header_gradient{position:absolute;width:100%}.consumption-page-gridarea_action{grid-area:actions;z-index:${(er.P.Over+1).toString()};// Needs to be above banner ad container z-index}.consumption-page-action-tray-wrapper{margin-inline-end:auto;background:transparent;position:sticky;width:fit-content;z-index:2;display:flex;flex-direction:column;align-items:center}.consumption-page-gridarea_content{grid-area:content}.consumption-page-content-wrapper{position:relative}.consumption-page-content-header{margin:32px 0px;border-bottom:1px solid rgba(0,0,0,0.1)}.consumption-page-content-header-no-border{border-bottom:none !important}.consumption-page-content-header-no-topmargin{margin-top:0}.consumption-page-gridarea_rail{grid-area:rail;background-color:transparent;position:relative;width:max-content;border-inline-start:1px solid rgba(0,0,0,0.06)}.consumption-page-ruby-right-rail{grid-area:right-rail;margin-top:${(0,ye.c)(a.M5)}}.right-rail-with-ads.consumption-page-ruby-right-rail{margin-top:32px}.right-rail-with-ads ruby-views-trending-now{margin-top:32px}.ruby-rail-sticky{position:sticky;top:80px}.ruby-rail-sticky right-rail-provider-carousel{margin-block-start:22px;display:block}.ruby-right-rail-extended{display:flex;flex-direction:column;gap:32px;height:100%}.ruby-rail-sticky-bottom{position:sticky;top:80px}.ruby-rail-sticky-bottom.is-fixed{position:fixed;top:80px}.consumption-page-rail-wrapper{position:sticky;height:100%}.ruby-rail-sticky-full-height .ruby-rail-sticky{position:fixed;z-index:${er.P.Over.toString()};top:88px}.ruby-rail-sticky-banner{top:var(--ruby-sticky-banner-size,80px)}.ruby-rail-sticky-banner-exit{transition:top 0.3s ease}.consumption-page-gridarea_eocb_leadgen{grid-area:eocb;width:100%}.consumption-page-eocb{margin:32px auto 0px}.consumption-page-feed-wrapper{background-color:var(--banner-background);padding-bottom:${(0,ye.c)(a.NR)}}.consumption-page-river-heading{margin:0 auto;color:${or.l};font-size:20px;font-weight:bold;width:1236px;padding:20px 0}.consumption-page-river-heading-centralized{margin:0 auto;color:${or.l};text-align:center;font-size:28px;text-transform:uppercase;font-weight:bold;padding:25px 0}.more-for-you-button-container{width:1236px;margin:0 auto;position:relative;padding:16px 0;display:flex;justify-content:end}.more-for-you-button-content{display:flex;justify-content:center;align-items:center;gap:8px}.more-for-you-button{border-radius:20px;padding:4px}.more-for-you-click-area{position:absolute;inset-inline-start:calc(50% - 100px);top:-30px;padding:10px;cursor:pointer}.more-for-you-button-content img{filter:invert(1)}.arb-style-header{font-weight:600}.top-span-module{width:100%;max-height:60px;margin-bottom:32px}.breaking-news-banner-wrap{width:100vw;display:flex;justify-content:center}.breaking-news-banner{width:1311px;--feed-width:1311px}.conversationStartersCompanionIframe{width:100%;display:block;margin:0px auto;height:0px;box-sizing:border-box}.consumption-error-page{margin:100px 150px;font-size:20px;color:${or.l}}.consumption-error-page h1{font-size:25px}.gallery_content{min-height:${(0,ye.c)(680)}}.social-bar-wrapper{min-height:32px}.social-bar-wrapper social-bar-wc::part(social-bar-buttons-tooltip){bottom:9px;left:calc(100% + 10px);background:#3B3B3B;border-radius:2px;color:#fff;content:attr(data-content);font-size:14px;padding:4px 10px;white-space:nowrap;box-shadow:0 6.4px 14.4px rgba(0,0,0,0.13),0 0 5.6px rgba(0,0,0,0.11);outline:auto;outline-color:#3B3B3B;max-width:150px;transform:none}.star-rating-container{position:fixed;inset-block-end:140px;inset-inline-end:0;z-index:${er.P.Banner.toString()}}.consumption-page-structure-widgets{display:block}.consumption-page-structure-no-grid{display:block;width:100%}.consumption-ruby{display:flex;justify-content:center;flex-direction:column}.consumption-ruby .gallery_content{min-height:unset}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.article_content),.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.gallery_content){margin-top:32px}.consumption-page-structure-no-grid .action-bar-below-byline .consumption-page-content-wrapper:is(.article_content,.gallery_content){margin-top:16px}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.with-keytakeaways-section){align-items:center;justify-content:center;display:flex;flex-direction:column;margin-top:16px}key-takeaways-wc{margin-bottom:32px}.rail-with-keytakeaways-section{margin-top:${(0,ye.c)(-1*a.M5)}}.consumption-page-structure-no-grid.consumption-page-structure-gem,.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.OH)};margin:32px auto;margin-bottom:16px}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.consumption-page-structure-no-grid .consumption-page-content-header{max-width:948px;margin:0 auto}.gallery_content .align-left ruby-views-header::part(ruby-views-header){align-items:start}.gallery_content .consumption-page-content-header.align-left{max-width:1392px}ruby-views-action-bar{padding-bottom:16px}ruby-views-action-bar.eocb{display:block;max-width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)});margin:0 auto}.video_content .consumption-page-content-header.align-left{width:100%}ruby-views-action-bar.action-bar-under-title{max-width:100%;margin-bottom:16px;margin-inline-start:8px}ruby-views-action-bar.head{width:100%;border-bottom:1px solid var(--stroke-divider);max-width:var(--ruby-article-flex-max-width,${a.Rq.toString()}px)}ruby-views-action-bar.below-byline{border-bottom:none}ruby-views-action-bar.head.no-border{border:none;padding-bottom:0}.conversationStartersCompanionIframe{display:block;max-width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)});margin:0 auto}.kumo-consumption-page-eocb{max-width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)});margin:0 auto 16px auto}.consumption-page-structure-no-grid.insight{width:unset;max-width:1272px}.consumption-page-structure-no-grid > .consumption-page-gridarea_rail{display:none}.consumption-page-structure-no-grid .consumption-page-content-header{border:none !important}.consumption-page-content-header-ss{width:${(0,ye.c)(750)}}.social-bar-wrapper-clp{border-width:1px 0px 1px 0px;border-style:solid;border-color:var(--neutral-stroke-active);margin:16px 0px 24px 0px;padding:8px 0px}.social-bar-wrapper-clp social-bar-wc::part(share-button){position:absolute;right:0}.more-for-you-peek{position:sticky;bottom:var(--mfy-peek-bottom-offset) !important;z-index:${(er.P.Over+1).toString()};transition:bottom 300ms ease-in-out;background:#FAFAFA}.more-for-you-peek-close{background:transparent;border:none;cursor:pointer;padding-inline-end:0}.more-for-you-peek-close img{width:20px;height:20px}.native-ad-banner-wrapper{display:grid;justify-content:center;min-height:192px}.native-ad-banner{margin-bottom:32px;margin-top:0px;width:${(0,ye.c)(Zi.Nm)}}.ruby-consumption-error-page{position:fixed;top:0;left:0;width:100vw;height:100vh;display:flex;justify-content:center;align-items:center}${(0,J.H5)(J.j1.c5)}{.consumption-page-river-heading,.more-for-you-button-container{width:${(0,ye.c)(mt)}}.consumption-page-content-header-ss{width:${(0,ye.c)(800)}}}${(0,J.H5)(J.j1.c4)}{.consumption-page-river-heading-centralized,.consumption-page-river-heading,.more-for-you-button-container{width:${(0,ye.c)(gt)}}.consumption-page-structure{grid-template-columns:${(0,ye.c)(a.zM)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.BE)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.c_)}}.consumption-page-structure.insight{grid-template-columns:${(0,ye.c)(a.zM)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.sj)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.zM)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,ye.c)(a.zM)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.BE+vt)} ${(0,ye.c)(a.xZ)} ${(0,ye.c)(a.c_)}}.gallery_content .align-left ruby-views-header::part(ruby-views-header){display:grid;grid-template-columns:repeat(16,minmax(63px,72px));gap:16px;align-items:start}ruby-views-action-bar.head.no-border{grid-column:1 / 13;width:calc(100% - 8px)}.above-river-heading{width:${(0,ye.c)(1236)}}.article_content .consumption-page-content-header.align-left{max-width:688px}}@media (max-width:${(0,ye.c)(a.gk)}){.consumption-page-structure{grid-template-areas:"actions . content . rail";grid-template-columns:${(0,ye.c)(48)} ${(0,ye.c)(36)} ${(0,ye.c)(b.e5)} ${(0,ye.c)(36)} ${(0,ye.c)(a.u9)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,ye.c)(48)} ${(0,ye.c)(36)} ${(0,ye.c)(b.e5+vt)} ${(0,ye.c)(36)} ${(0,ye.c)(a.u9)}}}${(0,J.H5)(J.j1.c3)}{.consumption-page-structure{grid-template-areas:"actions . content . rail";grid-template-columns:${(0,ye.c)(26)} ${(0,ye.c)(24)} ${(0,ye.c)(a.eq)} ${(0,ye.c)(a.ef)} ${(0,ye.c)(a.c_)}}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:${(0,ye.c)(26)} ${(0,ye.c)(24)} ${(0,ye.c)(a.eq+vt)} ${(0,ye.c)(a.ef)} ${(0,ye.c)(a.c_)}}.consumption-page-ruby-structure{grid-template-areas:"header header header header header""left-rail . content . right-rail"" . eocb eocb eocb .";grid-template-columns:${(0,ye.c)(160)} ${(0,ye.c)(24)} 1fr ${(0,ye.c)(24)} ${(0,ye.c)(160)}}.consumption-page-structure.insight{grid-template-columns:${(0,ye.c)(26)} ${(0,ye.c)(24)} ${(0,ye.c)(a.N4)} ${(0,ye.c)(26)} ${(0,ye.c)(24)}}.consumption-page-river-heading,.more-for-you-button-container{width:924px}.consumption-page-river-heading-centralized{width:toPx(CONSUMPTION_PAGE_WIDTH_3_COL)}.consumption-page-structure > .consumption-page-gridarea_action{grid-area:none;margin-inline-start:16px;position:absolute}.consumption-page-gridarea_action{grid-area:none;position:absolute;margin-inline-start:16px;height:100%}.above-river-heading{width:${(0,ye.c)(924)}}.breaking-news-banner{width:999px;--feed-width:999px}.consumption-page-content-header-ss{width:${(0,ye.c)(534)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.article_content .consumption-page-content-header.align-left{max-width:688px}.gallery_content .consumption-page-content-header.align-left{max-width:1040px}}.above-river-block{padding-bottom:${(0,ye.c)(20)};min-height:${(0,ye.c)(353)};display:block}.above-river-block.river-bg{background:#F7F7F7;padding-bottom:${(0,ye.c)(0)}}.above-river-heading{margin:0 auto;color:${or.l};font-size:${(0,ye.c)(20)};font-weight:${600..toString()};width:${(0,ye.c)(1548)};line-height:${(0,ye.c)(27)};padding-bottom:${(0,ye.c)(20)}}.above-river-block.river-bg .above-river-heading{padding-top:${(0,ye.c)(20)}}@media (max-width:${(0,ye.c)(a.kk)}){.consumption-page-structure,.consumption-page-structure.insight{grid-template-areas:"actions . content .";grid-template-columns:1fr 24px ${(0,ye.c)(a.T6)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr 24px ${(0,ye.c)(a.T6+vt)} 1fr}.consumption-page-structure > .consumption-page-gridarea_rail{display:none}.consumption-page-structure > .consumption-page-gridarea_action{grid-area:actions;position:static;margin-inline-start:16px;height:100%}.consumption-page-content-header-ss{width:${(0,ye.c)(612)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,ye.c)(a.uj)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.uj)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Nq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}}${(0,J.H5)(J.j1.c2)}{.consumption-page-structure{grid-template-areas:"actions . content .";grid-template-columns:1fr 24px ${(0,ye.c)(a.T6)} 1fr}.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-structure.insight{grid-template-columns:1fr 0px ${(0,ye.c)(a.k2)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr 24px ${(0,ye.c)(a.T6+vt)} 1fr}.consumption-page-river-heading,.more-for-you-button-container{width:612px}.consumption-page-river-heading-centralized{width:toPx(CONSUMPTION_PAGE_WIDTH_2_COL)}.above-river-heading{width:${(0,ye.c)(612)}}.breaking-news-banner{width:687px;--feed-width:687px}.consumption-page-structure-no-grid .consumption-page-content-header{width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem{width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content){width:${(0,ye.c)(a.Rq)}}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:calc(100vw - ${(0,ye.c)(a.C)})}.consumption-ruby .consumption-page-structure-no-grid:not(.consumption-page-structure-gem):is(.video_content) ruby-views-action-bar{width:${(0,ye.c)(a.Rq)}}.conversationStartersCompanionIframe{max-width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)});grid-column:1 / -1}.kumo-consumption-page-eocb{max-width:var(--ruby-article-flex-max-width,${(0,ye.c)(a.Rq)})}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem).consumption-page-structure-widgets .consumption-page-content-wrapper:is(.video_content){width:auto}.gallery_content .consumption-page-content-header.align-left{max-width:736px}}@media (max-width:${(0,ye.c)(a.KB)}){.consumption-page-structure,.consumption-page-structure.insight{gap:24px;grid-template-areas:"actions content .";grid-template-columns:1fr ${(0,ye.c)(a.X7)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr ${(0,ye.c)(a.X7+vt)} 1fr}}@media (max-width:${(0,ye.c)(a.RA)}){.consumption-page-structure,.consumption-page-structure.insight{gap:0;grid-template-areas:"actions content .";grid-template-columns:1fr ${(0,ye.c)(a.X7)} 1fr}.consumption-page-structure.consumption-page-structure-support-padding{grid-template-columns:1fr ${(0,ye.c)(a.X7+vt)} 1fr}}@media (max-width:${(0,ye.c)(a.HQ)}){.consumption-page-content-header-ss{width:100%}}${(0,J.H5)(J.j1.c1)}{.consumption-page-structure,.consumption-page-structure.insight{grid-template-areas:"content content content";grid-template-columns:1fr 1fr 1fr}.consumption-page-ruby-structure{grid-template-areas:"header""content""eocb";grid-template-columns:auto}.consumption-page-gridarea_content{margin-top:8px;padding:0 8px}.consumption-page-gridarea_content.responsive-banner-active{margin-top:0}.consumption-page-structure-no-grid .consumption-page-gridarea_content{padding:0}.consumption-page-river-heading,.more-for-you-button-container{width:300px;text-align:center}.consumption-page-river-heading-centralized{max-width:440px;padding:0 24px}.breaking-news-banner{padding:0px 6px;width:93%}.consumption-page-gridarea_action,.consumption-page-gridarea_rail{display:none}.consumption-error-page{margin:10px}.consumption-page-structure-no-grid .consumption-page-content-header{max-width:100%;padding:0}ruby-views-action-bar.eocb{max-width:min(452px,100%);margin:0 auto}ruby-views-action-bar.action-bar-under-title{max-width:var(--ruby-article-flex-max-width,none);padding-inline-start:8px}.conversationStartersCompanionIframe{max-width:100%;padding:0 24px;grid-column:1 / -1}.kumo-consumption-page-eocb{max-width:452px;margin:0 auto 16px auto}.consumption-page-structure-no-grid:not(.consumption-page-structure-gem) .consumption-page-content-wrapper:is(.video_content){width:calc(100vw - ${(0,ye.c)(a.C)})}.consumption-page-structure-no-grid.consumption-page-structure-gem .consumption-page-content-wrapper:is(.video_content),.consumption-page-structure-no-grid.consumption-page-structure-gem{width:100%}.gallery_content .consumption-page-content-header.align-left{max-width:360px}@media (min-width:360px) and (max-width:663px){.align-left ruby-views-header::part(ruby-views-header){padding:0}}}@media (max-height:350px){.consumption-page-banner-wrapper{position:unset}}@media (prefers-color-scheme:dark){.consumption-page-gridarea_rail{border-inline-start:1px solid rgba(255,255,255,0.06)}.consumption-page-gridarea_rail .ad-container,.consumption-page-gridarea_rail .mfp-container{background-color:${Qi.py}}.consumption-page-content-header{border-bottom:1px solid rgba(255,255,255,0.1)}.consumption-page-feed-wrapper{background-color:#2B2B2B;padding-bottom:${(0,ye.c)(a.NR)}}.above-river-block.river-bg{background:#2B2B2B;padding-bottom:${(0).toString()}}consumption-page-content-header{border-bottom:1px solid rgba(255,255,255,0.1)}.more-for-you-peek{background:#1F1F1F}.more-for-you-peek-close img{filter:invert(1)}}.ruby-fitcontent{width:fit-content;margin:0 auto}${rr}@media (max-width:${(0,ye.c)(a.kk)}){.consumption-page-structure.extended-right-rail{grid-template-areas:". content . rail .";grid-template-columns:12px minmax(0,1fr) 24px 300px 24px;gap:0}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_rail{display:block;width:300px}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_action{display:none}}@media (max-width:${(0,ye.c)(a.tK)}){.consumption-page-structure.extended-right-rail{grid-template-areas:". content .";grid-template-columns:1fr minmax(0,${(0,ye.c)(a.T6)}) 1fr;gap:0}.consumption-page-structure.extended-right-rail > .consumption-page-gridarea_rail{display:none}}`.withBehaviors(new tr.P("prg-rbylyt-t3",dr),new sr.o("enableBigRRAd",!0,nr),new sr.o("enableBigRRAdWithViewport",!0,cr),new sr.o("enableRubyStickyBanner",!0,ar)),hr={experienceConfigSchema:void 0}},25987(t,e,i){var r;i.d(e,{P(){return r}}),function(t){t[t.Banner=999999]="Banner",t[t.CookieWall=1100]="CookieWall",t[t.Dialog=900]="Dialog",t[t.PersistentNav=800]="PersistentNav",t[t.Flyout=700]="Flyout",t[t.Overlay=600]="Overlay",t[t.Nav=500]="Nav",t[t.Over=300]="Over",t[t.Above=100]="Above",t[t.Default=0]="Default",t[t.Below=-1]="Below",t[t.Buried=-2]="Buried"}(r||(r={}))},37630(t,e,i){i.d(e,{n(){return s}});var r=i(72627);function s(t=(0,r.$t)()){return/Version\/[\d.]+.*Safari/.test(t)}},72203(t,e,i){i.d(e,{$(){return s}});var r=i(92011);class s extends r.L{}},57996(t,e,i){i.d(e,{_(){return y}});var r=i(56911),s=i(60815),o=i(92011),n=i(89757),a=i(69259);const c=n.qy`<div class="flex-row" style="gap: 12px; align-items: center"><div class="skeleton" style="width: 32px; height: 32px; border-radius: 12px"></div><div class="skeleton" style="width: 108px; height: 14px"></div></div><div class="flex-col" style="gap: 12px; margin-top: 16px"><div class="skeleton" style="width: 100%; height: 24px"></div><div class="skeleton" style="width: 50%; height: 24px"></div></div><div class="flex-row" style="gap: 12px; margin-top: 20px; align-items: center"><div class="skeleton" style="width: 156px; height: 16px"></div><div class="skeleton" style="width: 1px; height: 16px"></div><div class="skeleton" style="width: 72px; height: 16px"></div><div class="skeleton" style="width: 72px; height: 16px"></div></div>`,d=n.qy`<div class="flex-row" style="justify-content: space-between"><div class="content-section"><div class="flex-col" style="gap: 12px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div><div class="skeleton image-placeholder" style="width: 100%; margin: 32px 0; border-radius: 6px"></div><div class="flex-col" style="gap: 12px; margin-bottom: 32px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div><div class="flex-col" style="gap: 12px; margin-bottom: 32px"><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 93%; height: 16px"></div><div class="skeleton" style="width: 100%; height: 16px"></div><div class="skeleton" style="width: 50%; height: 16px"></div></div></div></div>`,l=n.qy`<div class="mrr-section skeleton" style="width: 350px;"></div>`,h=n.qy`<div class="content-container"><div className="placeholder"></div><div class="content-wrapper" style="overflow: initial">${c}<div class="skeleton" style="width: 100%; height: 1px; margin: 32px 0"></div>${d}</div>${(0,a.z)(t=>!t.disableMrr,l)}</div>`;var u=i(59669),p=i(34241),m=i(47300),g=i(13267),b=i(73686);const f=u.A` ${p.w} .content-container{position:relative;display:grid;max-width:1600px;margin:0 auto;grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${g.e5.toString()}px minmax(1px,1fr) 348px"}.content-wrapper{max-width:100%;margin:38px auto;grid-area:article;position:relative;width:${b.I7.VIEWS_CONTENT_WIDTH_4_COL.toString()}px}.skeleton{border-radius:100px}.mrr-section{grid-area:rail;margin-top:232px;border-radius:0px}.content-section{width:100%}.image-placeholder{height:448px}${(0,m.H5)(m.j1.c1)}{.content-wrapper{width:100%;margin:16px auto}.mrr-section{display:none}.content-container{position:relative;display:block;margin:0 16px}.image-placeholder{height:250px}}${(0,m.H5)(m.j1.c2)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_2_COL.toString()}px}.mrr-section{display:none}.content-container{grid-template-areas:"article article article";grid-template-columns:"1fr 1fr 1fr"}}${(0,m.H5)(m.j1.c3)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_3_COL.toString()}px}.content-container{grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${g.Xo.toString()}px minmax(1px,1fr) 348px"}}${(0,m.H5)(m.j1.c4)}{.content-wrapper{width:${b.I7.VIEWS_CONTENT_WIDTH_4_COL.toString()}px}.content-container{grid-template-areas:"article article article rail";grid-template-columns:"minmax(1px,1fr) ${g.e5.toString()}px minmax(1px,1fr) 348px"}}`;var v=i(72203);let y=class extends v.${};(0,r.Cg)([s.sH],y.prototype,"disableMrr",void 0),y=(0,r.Cg)([(0,o.E)({name:"loading-state-article",template:h,styles:f})],y)},21627(t,e,i){i.d(e,{c(){return B}});var r=i(56911),s=i(92011),o=i(23429),n=i(38493),a=i(60815),c=i(98378),d=i(66591),l=i(82281),h=i(44704);class u extends s.L{constructor(){super(...arguments),this.lineCountClampSeeMore=1,this.lineCountClampExpanded=null,this.isExpanded=!1,this.shouldShowExpanded=!0,this.shouldSeeMoreBelowText=!1,this.shouldImmediatelySeeMore=!1,this.useVideoDetailsStyle=!1,this.useEpisodeStyle=!1,this.telemetry=(()=>{const t=(0,h.N)("SeeMoreDescription",c.MS.More,c.EG.Click),e=(0,h.N)("SeeLessDescription",c.MS.Hide,c.EG.Click);return{externalLinkTelemetryObject:(0,h.N)("ExternalLink",c.MS.Navigate),seeMoreTelemetryObject:t,seeLessTelemetryObject:e}})()}connectedCallback(){super.connectedCallback(),this.setShowExpanded(),this.setupResizeObserver(),this.updateHostExpandedClass()}setShowExpanded(){this.abstractEl&&(this.shouldShowExpanded=this.abstractEl.offsetHeight<this.abstractEl.scrollHeight)}setupResizeObserver(){this.resizeObserver=new ResizeObserver(this.setShowExpanded.bind(this)),this.resizeObserver.observe(this.abstractEl)}updateHostExpandedClass(){this.isExpanded?this.classList.add("expanded"):this.classList.remove("expanded")}onClickToggleDescription(t){this.isExpanded=t,this.updateHostExpandedClass(),window.setTimeout(()=>{this.isExpanded?this.seeLessButton?.focus():this.seeMoreButton?.focus()},100)}onClickSeeMoreButton(){this.shouldImmediatelySeeMore?this.onClickToggleDescription(!0):window.setTimeout(()=>{this.onClickToggleDescription(!0)},100)}textChanged(){o.L.next().then(()=>{this.setShowExpanded(),this.isExpanded=!1,this.updateHostExpandedClass()})}get computedStyles(){return(0,d.x)("see-more",["see-more-bottom",this.shouldSeeMoreBelowText])}get shouldShowSeeMore(){return Boolean(!this.isExpanded&&this.shouldShowExpanded)}get enableFormattedText(){return(0,l.R)("prg-rich-desc")}disconnectedCallback(){super.disconnectedCallback(),this.resizeObserver&&this.resizeObserver.disconnect()}}(0,r.Cg)([n.CF],u.prototype,"text",void 0),(0,r.Cg)([(0,n.CF)({attribute:"line-count-clamp-see-more"})],u.prototype,"lineCountClampSeeMore",void 0),(0,r.Cg)([(0,n.CF)({attribute:"line-count-clamp-expanded"})],u.prototype,"lineCountClampExpanded",void 0),(0,r.Cg)([a.sH],u.prototype,"isExpanded",void 0),(0,r.Cg)([a.sH],u.prototype,"shouldShowExpanded",void 0),(0,r.Cg)([a.sH],u.prototype,"shouldSeeMoreBelowText",void 0),(0,r.Cg)([a.sH],u.prototype,"shouldImmediatelySeeMore",void 0),(0,r.Cg)([a.sH],u.prototype,"useVideoDetailsStyle",void 0),(0,r.Cg)([a.sH],u.prototype,"useEpisodeStyle",void 0),(0,r.Cg)([a.sH],u.prototype,"strings",void 0),(0,r.Cg)([a.sH],u.prototype,"abstractEl",void 0),(0,r.Cg)([a.Jg],u.prototype,"computedStyles",null),(0,r.Cg)([a.Jg],u.prototype,"shouldShowSeeMore",null);var p=i(47810),m=i(41123),g=i(24496),b=i(59669),f=i(50882),v=i(47300),y=i(13267);const w=b.A` :focus-visible{outline:solid var(--focus-stroke-outer)}.text-inline-expander-wrapper{display:flex;align-items:baseline;justify-content:space-between}.text-inline-expander-wrapper.see-more-bottom{display:block}.see-more{display:-webkit-box;-webkit-box-orient:vertical;margin-top:0;overflow:hidden;margin-bottom:var(--see-more-margin-bottom,24px);color:var(--expander-color);font-family:var(--expander-font-family);font-size:var(--expander-font-size);font-weight:var(--expander-font-weight);line-height:var(--expander-line-height)}.see-more-btn-container{overflow:initial}.see-more.see-more-bottom{margin-bottom:0}.see-more-btn.see-more-bottom{padding:0px}.text-inline-expander-wrapper .see-more-btn:focus-visible{outline-offset:-3px}${(0,v.H5)(v.j1.c1)}{.see-more{padding:0px;text-overflow:ellipsis}}.clamped-see-more{flex:7}.see-more-btn{background:none;border:none;color:${(0,y.DK)()?"#5CB6FF":"#0066CC"};cursor:pointer;flex:1;-webkit-user-select:none;letter-spacing:inherit;line-height:inherit;word-spacing:inherit;font-family:inherit}@media (forced-colors:active){.see-more-btn{color:${f.A.LinkText}}}.see-more-btn-new-styles{padding:0;margin:0;overflow:hidden;color:var(--expander-button-color,${p.l});font-family:var(--expander-button-font-family);font-size:var(--expander-button-font-size,${m.K});font-weight:var(--expander-button-font-weight,600);line-height:var(--expander-button-line-height,${m.Z})}.see-more-btn.see-more-bottom.see-more-btn-new-styles{padding-top:4px}.see-more-btn-episode{font-family:'Segoe UI';font-style:normal;font-weight:600;font-size:12px;line-height:16px;color:rgba(255,255,255,0.7)}.content a{text-decoration:none;color:${g.W_};pointer:cursor;overflow-wrap:break-word}.content a:hover,.content a:focus{text-decoration:underline}`;var x=i(89757),$=i(60402),k=i(69259),A=i(93809),C=i(7686),F=i(42277);const R=i(68244).F.create({trustedType:{createHTML:t=>C.A.sanitize(t,{RETURN_TRUSTED_TYPE:!0,ALLOWED_TAGS:["a","b","i","strong","em","ul","ol","li","p","span","br"],ALLOWED_ATTR:["href","target"]})},guards:{aspects:{[F.D.property]:{innerHTML:(t,e,i,r)=>(t,e,i,...s)=>{const o=C.A.sanitize(i,{RETURN_TRUSTED_TYPE:!0,ALLOWED_TAGS:["a","b","i","strong","em","ul","ol","li","p","span","br"],ALLOWED_ATTR:["href","target"]});r(t,e,o,...s)}}}}}),S=x.qy`<button ${(0,$.K)("seeLessButton")} tabindex="0" class=${t=>(0,d.x)("see-more-btn",["see-more-btn-new-styles",t.useVideoDetailsStyle],["see-more-btn-episode",t.useEpisodeStyle])} @click=${(t,e)=>t.onClickToggleDescription(!1)} data-t="${t=>t.telemetry.seeLessTelemetryObject.getMetadataTag()}">${t=>t.strings?.seeLess}</button>`,_=x.qy` ${(0,k.z)(t=>t.useVideoDetailsStyle,x.qy`<div class=${t=>(0,d.x)(t.computedStyles)}>${S}</div>`)}
`,T=x.qy` ${(0,k.z)(t=>!t.enableFormattedText,t=>x.qy`${t.text}`,x.qy`<div class="content" :innerHTML="${(0,A.U)(t=>((t,e)=>{const i=document.createElement("div");return i.innerHTML=t,i.querySelectorAll("a").forEach(t=>{t.setAttribute("data-t",e),t.setAttribute("target","_blank")}),i.innerHTML})(t.text,t.telemetry.externalLinkTelemetryObject.getMetadataTag()),R)}"></div>`)}
`,I=x.qy`<div class=${t=>(0,d.x)("text-inline-expander-wrapper",["see-more-bottom",t.shouldSeeMoreBelowText])}><span ${(0,$.K)("abstractEl")} class=${t=>(0,d.x)(t.computedStyles,["clamped-see-more",!t.isExpanded])} tabIndex="0" title=${t=>t.text} style="-webkit-line-clamp:${t=>t.isExpanded?t.lineCountClampExpanded||"initial":t.lineCountClampSeeMore}">${T} ${(0,k.z)(t=>t.isExpanded,x.qy` ${t=>t.useVideoDetailsStyle?_:S} `)}</span>${(0,k.z)(t=>t.shouldShowSeeMore,x.qy`<div class=${t=>(0,d.x)(t.computedStyles,"see-more-btn-container")}><button ${(0,$.K)("seeMoreButton")} class=${t=>(0,d.x)("see-more-btn",["see-more-btn-new-styles",t.useVideoDetailsStyle],["see-more-bottom",t.shouldSeeMoreBelowText],["see-more-btn-episode",t.useEpisodeStyle])} @click=${t=>t.onClickSeeMoreButton()} data-t="${t=>t.telemetry.seeMoreTelemetryObject.getMetadataTag()}">${t=>t.strings?.seeMore}</button></div>`)}</div>`;let B=class extends u{};B=(0,r.Cg)([(0,s.E)({name:"text-inline-expander",template:I,styles:w})],B)},53791(t,e,i){i.d(e,{x7(){return qt},VM(){return Yt},On(){return Xt}});var r=i(59669),s=i(22131),o=i(87944),n=i(33544);const a=r.A`
    :host {
        --width-card-1u: ${(0,o.c)(336)};
        --max-height-adaptive: ${(0,o.c)(368)};
        --max-width-card-adaptive-2c: ${(0,o.c)(360)};
        --max-width-card-adaptive-1u: ${(0,o.c)(360)};
    }
`,c=r.A`
    :host {
        --min-width-card-adaptive: ${(0,o.c)(300)};
        --max-width-card-adaptive-1u: ${(0,o.c)(368)};
        --min-width-card-adaptive-1u: ${(0,o.c)(272)};
        --min-width-card-adaptive-2c: ${(0,o.c)(300)};
        --max-width-card-adaptive-2c: ${(0,o.c)(368)};
        --max-height-adaptive: ${(0,o.c)(368)};
        --min-height-adaptive: ${(0,o.c)(308)};
        --gutter-size-adaptive: ${(0,o.c)(24)};
    }
`.withBehaviors(new n.P("prg-lg-flex-rev",a)),d=r.A`
    :host {
        --gap-between-cards-on-feed: ${String(16)};
        --gap-between-cards-on-feed-px: calc(var(--gap-between-cards-on-feed) * 1px);
        --width-card-1u: ${(0,o.c)(368)};
        --width-card-2c: calc(var(--width-card-1u) * 2 + var(--gap-between-cards-on-feed-px));
        --width-card-3c: calc(var(--width-card-1u) * 3 + (var(--gap-between-cards-on-feed-px) * 2));
        --width-card-4c: calc(var(--width-card-1u) * 4 + (var(--gap-between-cards-on-feed-px) * 3));
        --height-card-1u: ${String(344)};
        --height-card-1u-px: calc(var(--height-card-1u) * 1px);
        --height-card-15u: ${String(368)};
        --height-card-15u-px: calc(var(--height-card-15u) * 1px);
    }
    ${c}
`;var l=i(34625),h=i(75117);class u{constructor(t,e){this.market=t,this.dt=e}connectedCallback(t){const{source:e}=t;h.T3.CurrentMarket===this.market?e.$fastController.addStyles(this.dt):e.$fastController.removeStyles(this.dt)}}var p=i(26779);const m="500",g=r.A`
    :host {
        --smtc-text-style-default-header-weight: ${"400"};
    }
`,b=r.A`
    :host {
        --smtc-text-style-default-regular-font-family: ${p.F6};
        --smtc-style-default-regular-font-family: ${p.F6};
        --smtc-style-default-header-font-family: ${p.F6};
    }
`,f=r.A`
    :host {
        --smtc-text-style-default-header-weight: ${m};
        --smtc-text-style-default-regular-font-family: ${p.YP};
        --smtc-style-default-regular-font-family: ${p.YP};
        --smtc-style-default-header-font-family: ${p.YP};
    }
`,v=r.A`
    :host {
        --smtc-text-style-default-header-weight: ${m};
        --smtc-text-style-default-regular-font-family: ${p.uQ};
        --smtc-style-default-regular-font-family: ${p.uQ};
        --smtc-style-default-header-font-family: ${p.uQ};
    }
`,y=r.A`
    :host {
        --smtc-text-style-default-header-weight: ${m};
        --smtc-text-style-default-regular-font-family: ${p.XK};
        --smtc-style-default-regular-font-family: ${p.XK};
        --smtc-style-default-header-font-family: ${p.XK};
    }
`,w=r.A`
    :host {
        --min-width-card-adaptive: ${(0,o.c)(300)};
        --max-width-card-adaptive-1u: ${(0,o.c)(320)};
        --min-width-card-adaptive-1u: ${(0,o.c)(272)};
        --min-width-card-adaptive-2c: ${(0,o.c)(300)};
        --max-width-card-adaptive-2c: ${(0,o.c)(320)};
        --max-height-adaptive: ${(0,o.c)(368)};
        --min-height-adaptive: ${(0,o.c)(308)};
    }
`,x=r.A`
    :host {
        --gap-between-cards-on-feed: ${String(16)};
        --gap-between-cards-on-feed-px: calc(var(--gap-between-cards-on-feed) * 1px);
        --width-card-1u: ${(0,o.c)(300)};
        --width-card-2c: calc(var(--width-card-1u) * 2 + var(--gap-between-cards-on-feed-px));
        --width-card-3c: calc(var(--width-card-1u) * 3 + (var(--gap-between-cards-on-feed-px) * 2));
        --width-card-4c: calc(var(--width-card-1u) * 4 + (var(--gap-between-cards-on-feed-px) * 3));
        --height-card-1u: ${String(308)};
        --height-card-1u-px: calc(var(--height-card-1u) * 1px);
        --height-card-15u: ${String(368)};
        --height-card-15u-px: calc(var(--height-card-15u) * 1px);
        --height-card-2c: ${String(308)};
        --height-card-2c-px: calc(var(--height-card-2c) * 1px);
    }
    ${w}
`,$=r.A`
    :host {
        --smtc-mai-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.24);
        --smtc-mai-shadow-ctrl-neutral-key-color: rgba(0, 0, 0, 0.24);
        --smtc-theme-color-effect-inner-shine-strong: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-effect-shadow-medium: rgba(0, 0, 0, 0.18);
        --smtc-theme-color-overlay-white-45: rgba(0, 0, 0, 0.45);
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 1px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-color: rgba(255, 255, 255, 0.12);
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        --smtc-shadow-ctrl-button-neutral-rest-key-color: rgba(0, 0, 0, 0.40);
        --smtc-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.40);
        --smtc-shadow-ctrl-fab-rest-key-color: hsla(0, 0.00%, 100.00%, 0.00);
        --smtc-shadow-ctrl-fab-rest-ambient-color: rgba(0, 0, 0, 0.12);
        --smtc-shadow-ctrl-fab-disabled-key-color: hsla(0, 0.00%, 100.00%, 0.00);
        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
        --smtc-shadow-ctrl-fab-hover-key-color: rgba(0, 0, 0, 0.25);
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
        --smtc-theme-color-shadow-sm-key: rgba(0, 0, 0, 0.25);
        --smtc-theme-color-shadow-sm-ambient: rgba(0, 0, 0, 0.00);
        --smtc-theme-color-shadow-sm-contour: rgba(0, 0, 0, 0.08);
        --smtc-effect-shadow-sm-key-x-offset: 0px;
        --smtc-effect-shadow-sm-key-y-offset: 1px;
        --smtc-effect-shadow-sm-key-blur-radius: 3px;
        --smtc-effect-shadow-sm-key-spread: 0px;
        --smtc-effect-shadow-sm-ambient-x-offset: 0px;
        --smtc-effect-shadow-sm-ambient-y-offset: 0px;
        --smtc-effect-shadow-sm-ambient-blur-radius: 0px;
        --smtc-effect-shadow-sm-ambient-spread: 0px;
        --smtc-effect-shadow-sm-contour-x-offset: 0px;
        --smtc-effect-shadow-sm-contour-y-offset: 0px;
        --smtc-effect-shadow-sm-contour-blur-radius: 1px;
        --smtc-effect-shadow-sm-contour-spread: 0px;
    }
`,k=r.A`
    :host {
        --smtc-mai-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.12);
        --smtc-mai-shadow-ctrl-neutral-key-color: rgba(0, 0, 0, 0.12);
        --smtc-theme-color-effect-shadow-medium: rgba(0, 0, 0, 0.08);
        --smtc-theme-color-effect-inner-shine-strong: #FFFFFF;
        --smtc-theme-color-overlay-white-45: rgba(255, 255, 255, 0.45);
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-color: #FFFFFF;
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        --smtc-shadow-ctrl-button-neutral-rest-key-color: rgba(0, 0, 0, 0.20);
        --smtc-shadow-ctrl-brand-key-x: 0px;
        --smtc-shadow-ctrl-brand-key-y: 0.5px;
        --smtc-shadow-ctrl-brand-key-blur: 3px;
        --smtc-shadow-ctrl-brand-key-color: rgba(0, 0, 0, 0.20);
        --smtc-shadow-ctrl-fab-rest-key-x: 0px;
        --smtc-shadow-ctrl-fab-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-key-blur: 3px;
        --smtc-shadow-ctrl-fab-rest-key-color: rgba(27, 53, 86, 0.08);
        --smtc-shadow-ctrl-fab-rest-ambient-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-blur: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-color: rgba(27, 53, 86, 0.04);
        --smtc-shadow-ctrl-fab-disabled-key-y: 4px;
        --smtc-shadow-ctrl-fab-disabled-key-blur: 6px;
        --smtc-shadow-ctrl-fab-disabled-key-color: rgba(0, 0, 0, 0.15);
        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
        --smtc-shadow-ctrl-fab-hover-key-color: rgba(0, 0, 0, 0.15);
        --smtc-shadow-flyout-ambient-blur: 0px;
        --smtc-shadow-flyout-ambient-color: rgba(255, 255, 255, 0);
        --smtc-shadow-flyout-ambient-x: 0px;
        --smtc-shadow-flyout-ambient-y: 0px;
        --smtc-shadow-flyout-key-blur: 12px;
        --smtc-shadow-flyout-key-color: rgba(0, 0, 0, 0.08);
        --smtc-shadow-flyout-key-x: 0px;
        --smtc-shadow-flyout-key-y: 6px;
        --smtc-effect-drop-shadow-medium-x-offset: 0px;
        --smtc-effect-drop-shadow-medium-y-offset: 6px;
        --smtc-effect-drop-shadow-medium-blur-radius: 12px;
        --smtc-effect-drop-shadow-medium-spread: 0px;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
        --smtc-theme-color-shadow-sm-key: rgba(0, 0, 0, 0.15);
        --smtc-theme-color-shadow-sm-ambient: rgba(0, 0, 0, 0.00);
        --smtc-theme-color-shadow-sm-contour: rgba(0, 0, 0, 0.15);
        --smtc-effect-shadow-sm-key-x-offset: 0px;
        --smtc-effect-shadow-sm-key-y-offset: 1px;
        --smtc-effect-shadow-sm-key-blur-radius: 3px;
        --smtc-effect-shadow-sm-key-spread: 0px;
        --smtc-effect-shadow-sm-ambient-x-offset: 0px;
        --smtc-effect-shadow-sm-ambient-y-offset: 0px;
        --smtc-effect-shadow-sm-ambient-blur-radius: 0px;
        --smtc-effect-shadow-sm-ambient-spread: 0px;
        --smtc-effect-shadow-sm-contour-x-offset: 0px;
        --smtc-effect-shadow-sm-contour-y-offset: 0px;
        --smtc-effect-shadow-sm-contour-blur-radius: 1px;
        --smtc-effect-shadow-sm-contour-spread: 0px;
    }
        
`,A=r.A`
    :host {
        --smtc-status-brand-tint-background: #586ba84d;
        --smtc-status-brand-tint-foreground: #97abea;
        --smtc-status-brand-tint-stroke: #9AACE1;
        --smtc-status-informative-tint-foreground: #e5ebfa;
        --smtc-status-informative-tint-background: #1f2431;
        --smtc-status-informative-tint-background-ad: #0F1119;
        --smtc-status-informative-background: #e5ebfa;
        --smtc-edge-ctrl-workspace-background-blue-rest: #69A1FA;
        --smtc-status-success-background: #6CC57B;
        --smtc-status-warning-background: #F3C357;
        --smtc-status-warning-foreground: #000000;
        --smtc-status-danger-background: #f98981;
        --smtc-status-danger-foreground: #000000;
        --smtc-status-danger-tint-foreground: #F98981;
        --smtc-status-danger-tint-background: rgba(157, 25, 32, 0.2);
        --smtc-status-danger-tint-stroke: #F98981;
        --smtc-status-success-tint-foreground: #6CC57B;
        --smtc-status-success-tint-background: rgba(9, 102, 32, 0.20);
        --smtc-status-success-tint-stroke: #6CC57B;
        --smtc-foreground-highlight-accent: #97ABEA;
    }
`,C=r.A`
    :host {
        --smtc-status-brand-tint-background: #e09e664d;
        --smtc-status-brand-tint-foreground: #6b3900;
        --smtc-status-brand-tint-stroke: #6B3900;
        --smtc-status-informative-foreground: #ffffff;
        --smtc-status-informative-tint-foreground: #272320;
        --smtc-status-informative-tint-background: #efeae7;
        --smtc-status-informative-tint-background-ad: #FFFBF8;
        --smtc-status-informative-background: #272320;
        --smtc-edge-ctrl-workspace-background-blue-rest: #2169EB;
        --smtc-status-success-background: #01712B;
        --smtc-status-warning-background: #A25A02;
        --smtc-status-warning-foreground: #ffffff;
        --smtc-status-danger-background: #ac1922;
        --smtc-status-danger-foreground: #ffffff;
        --smtc-status-danger-tint-foreground: #AC1922;
        --smtc-status-danger-tint-background: rgba(255, 181, 174, 0.2);
        --smtc-status-danger-tint-stroke: #AC1922;
        --smtc-status-success-tint-foreground: #01712B;
        --smtc-status-success-tint-background: rgba(148, 220, 127, 0.20);
        --smtc-status-success-tint-stroke: #01712B;
        --smtc-foreground-highlight-accent: #A25A02;
    }
`,F=r.A`
    :host {
        --smtc-background-ctrl-onBrand-hover: #525C7B;
        --smtc-background-ctrl-onBrand-pressed: #3E4760;
        --smtc-background-ctrl-neutral-pressed: #1f2330a6;
        --smtc-background-ctrl-subtle-selected-rest: #ffffff14;
        --smtc-background-ctrl-subtle-hover: #ffffff14;
        --smtc-background-flyout-color-blend: #ffffff00;
        --smtc-background-flyout-lum-blend: #ffffff00;
        --smtc-background-flyout-solid: #1b233ae8;
        --smtc-background-layer-primary-solid: #9da8d91a;
        --smtc-theme-color-accent-300: #5A2D1A;
        --smtc-theme-color-accent-450: #4458A0;
        --smtc-theme-color-background-200: #1f2431;
        --smtc-theme-color-background-250: #282d3e;
        --smtc-theme-color-background-300: #333A4E;
        --smtc-theme-color-background-700: #C2CADF;
        --smtc-theme-color-background-acrylic-thin-luminosity: rgba(27, 35, 58, 0.60);
        --smtc-theme-color-background-acrylic-thin-saturation: rgba(255, 255, 0, 0.05);
        --smtc-theme-color-background-acrylic-thin-tint: rgba(27, 35, 58, 0.50);
        --smtc-theme-color-background-page-chat-fade: #1F2431;
        --smtc-theme-color-background-page-chat-flat: #151a28;
        --smtc-theme-color-background-page-home-web-stop-0: #0C101C;
        --smtc-theme-color-background-page-home-web-stop-1: #171E32;
        --smtc-theme-color-background-page-home-web-stop-2: #242F50;
        --smtc-theme-color-background-acrylic-default-tint: rgba(27, 35, 58, 0.91);
        --smtc-theme-color-background-acrylic-default-saturation: rgba(255, 255, 0, 0.10);
        --smtc-background-web-page-primary: #111524;
        --smtc-background-ctrl-on-image-lum-blend: rgba(23, 30, 50, 0.60);
        --smtc-background-ctrl-on-image-rest: #455172;
        --smtc-background-ctrl-on-image-saturation-blend: rgba(255, 255, 255, 0.00);
        --smtc-background-card-on-primary-alt-hover: #9da8d91a;
        --smtc-background-card-on-primary-alt-pressed: #9da8d91a;
        --smtc-background-card-on-primary-alt-rest: #9da8d91a;
        --smtc-background-card-on-primary-default-rest: #9da8d91a;
        --smtc-background-card-on-secondary-default-rest: rgba(157, 168, 217, 0.05);
        --smtc-background-ctrl-active-brand-hover: #eef1f6ff;
        --smtc-background-ctrl-active-brand-pressed: #dce0e5ff;
        --smtc-background-ctrl-active-brand-rest: #f6fafeff;
        --smtc-background-ctrl-brand-hover: #525c7b;
        --smtc-background-ctrl-brand-rest: #4a5471;
        --smtc-background-ctrl-brand-pressed: #3e4760;
        --smtc-background-ctrl-brand-disabled: #ffffff0d;
        --smtc-background-ctrl-neutral-hover: #313a52a6;
        --smtc-background-ctrl-neutral-rest: #323f60a6;
        --smtc-background-ctrl-neutral-disabled: #ffffff0d;
        --smtc-background-ctrl-outline-rest: #ffffff00;
        --smtc-background-ctrl-outline-hover: #ffffff14;
        --smtc-background-ctrl-outline-pressed: #ffffff0d;
        --smtc-background-ctrl-outline-disabled: #ffffff00;
        --smtc-background-ctrl-subtle-rest: #ffffff00;
        --smtc-background-ctrl-subtle-pressed: #ffffff0d;
        --smtc-background-tint-neutral: #171E32;
        --smtc-background-webPage-primary: #1C2024;
        --smtc-ctrl-fab-background-rest: #151a28;
        --smtc-ctrl-fab-background-hover: #171a25;
        --smtc-ctrl-fab-background-pressed: #0f1119;
        --smtc-ctrl-input-background-rest: #47599740;
        --smtc-ctrl-choice-base-background-rest: #00000000;
        --smtc-ctrl-choice-switch-background-selected-rest: #4ba849ff;
        --smtc-ctrl-choice-switch-background-rest: rgba(255, 255, 255, 0.20);
        --smtc-ctrl-choice-switch-thumb-background-rest: rgba(255, 255, 255, 0.90);
        --smtc-ctrl-choice-switch-thumb-background-selected-rest: #ffffff;
        --smtc-ctrl-list-background-selected-rest: rgba(255, 255, 255, 0.08);
        --smtc-ctrl-list-background-selected-hover: rgba(255, 255, 255, 0.05);
        --smtc-ctrl-lite-filter-background-selected: #E5EBFA;
        --smtc-ctrl-progress-background-empty: #ffffff26;
        --smtc-ctrl-tooltip-background: #0f1119;
        --smtc-ctrl-tooltip-shadow-ambient-color: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-tooltip-shadow-key-color: rgba(0, 0, 0, 0.15);
        --smtc-edge-ctrl-workspace-background-blue-rest: #69A1FA;
        --mai-background-ctrl-onImage-rest: #1F2431;
        --mai-background-ctrl-onImage-hover: #282D3E;
        --mai-background-ctrl-onImage-pressed: #171A25;
        --smtc-background-window-tab-band-solid: #0e111b;
        --smtc-background-card-on-flyout-default-rest: #FFFFFF0D;
        --smtc-theme-color-shadow-highlight: rgba(255, 255, 255, 0.012);
        --smtc-status-warning-tint-background: rgba(162, 90, 2, 0.20);
    }
`,R=r.A`
    :host {
        --smtc-theme-color-background-acrylic-thin-tint: rgba(250, 244, 239, 0.60);
        --smtc-theme-color-background-page-chat-flat: #f8f4f1;
        --smtc-theme-color-background-page-home-web-stop-0: #F8F4F2;
        --smtc-theme-color-background-acrylic-default-tint: rgba(255, 255, 255, 0.94);
        --smtc-theme-color-background-acrylic-default-saturation: rgba(255, 255, 0, 0.10);
        --smtc-background-ctrl-onBrand-hover: #000000;
        --smtc-background-ctrl-onBrand-pressed: #322D29;
        --smtc-background-ctrl-neutral-pressed: #ffffff99;
        --smtc-background-ctrl-subtle-selected-rest: #00000014;
        --smtc-background-ctrl-subtle-hover: #0000000d;
        --smtc-background-flyout-color-blend: #ffffff00;
        --smtc-background-flyout-lum-blend: #ffffff00;
        --smtc-background-flyout-solid: #fffffff0;
        --smtc-background-layer-primary-solid: #ffffff73;
        --smtc-theme-color-accent-300: #F8BC8C;
        --smtc-theme-color-accent-450: #AD6446;
        --smtc-theme-color-background-200: #f0eae5;
        --smtc-theme-color-background-250: #e3ddd8;
        --smtc-theme-color-background-300: #CCC6C2;
        --smtc-theme-color-background-700: #3F3935;
        --smtc-theme-color-background-acrylic-thin-luminosity: rgba(240, 234, 229, 0.80);
        --smtc-theme-color-background-acrylic-thin-saturation: rgba(255, 255, 0, 0.10);
        --smtc-theme-color-background-page-chat-fade: #F0EAE5;
        --smtc-theme-color-background-page-home-web-stop-1: #FCF3EA;
        --smtc-theme-color-background-page-home-web-stop-2: #FDEDDE;
        --smtc-background-web-page-primary: #F8F4F1;
        --smtc-background-card-on-primary-default-rest: #ffffffcc;
        --smtc-background-card-on-primary-alt-hover: #ffffff73;
        --smtc-background-card-on-primary-alt-pressed: #ffffff73;
        --smtc-background-card-on-primary-alt-rest: #ffffff73;
        --smtc-background-card-on-secondary-default-rest: rgba(204, 196, 192, 0.20);
        --smtc-background-ctrl-active-brand-hover: #2b2e35ff;
        --smtc-background-ctrl-active-brand-pressed: #383b43ff;
        --smtc-background-ctrl-active-brand-rest: #24282fff;
        --smtc-background-ctrl-brand-hover: #000000;
        --smtc-background-ctrl-brand-rest: #272320;
        --smtc-background-ctrl-brand-pressed: #322d29;
        --smtc-background-ctrl-brand-disabled: #0000000d;
        --smtc-background-ctrl-neutral-hover: #ffffff;
        --smtc-background-ctrl-neutral-rest: #ffffffb3;
        --smtc-background-ctrl-neutral-disabled: #ffffff2e;
        --smtc-background-ctrl-outline-rest: #00000000;
        --smtc-background-ctrl-outline-hover: #0000000d;
        --smtc-background-ctrl-outline-pressed: #00000008;
        --smtc-background-ctrl-outline-disabled: #00000000;
        --smtc-background-ctrl-subtle-rest: #00000000;
        --smtc-background-ctrl-subtle-pressed: #00000008;
        --smtc-background-tint-neutral: #F4EFED;
        --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 0.10);
        --smtc-background-ctrl-on-image-lum-blend: rgba(228, 230, 241, 0.80);
        --smtc-background-ctrl-on-image-rest: #282523;
        --smtc-background-ctrl-on-image-saturation-blend: rgba(255, 255, 0, 0.10);
        --smtc-background-webPage-primary: #FFFFFF;
        --smtc-ctrl-fab-background-rest: #ffffff;
        --smtc-ctrl-fab-background-hover: #f8f4f1;
        --smtc-ctrl-fab-background-pressed: #fffbf8;
        --smtc-ctrl-input-background-rest: #0000000d;
        --smtc-ctrl-choice-base-background-rest: #ffffff00;
        --smtc-ctrl-choice-switch-background-selected-rest: #4ba849ff;
        --smtc-ctrl-choice-switch-background-rest: rgba(0, 0, 0, 0.20);
        --smtc-ctrl-choice-switch-thumb-background-rest: rgba(255, 255, 255, 0.90);
        --smtc-ctrl-choice-switch-thumb-background-selected-rest: #ffffff;
        --smtc-ctrl-list-background-selected-rest: rgba(0, 0, 0, 0.08);
        --smtc-ctrl-list-background-selected-hover: rgba(0, 0, 0, 0.05);
        --smtc-ctrl-lite-filter-background-selected: #272320;
        --smtc-ctrl-progress-background-empty: #00000026;
        --smtc-ctrl-tooltip-background: #FFFBF8;
        --smtc-ctrl-tooltip-shadow-ambient-color: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-tooltip-shadow-key-color: rgba(0, 0, 0, 0.08);
        --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 0.10);
        --mai-background-ctrl-onImage-rest: #272320;
        --mai-background-ctrl-onImage-hover: #000000;
        --mai-background-ctrl-onImage-pressed: #322D29;
        --smtc-background-window-tab-band-solid: #efeae7;
        --smtc-background-card-on-flyout-default-rest: #0000000D;
        --smtc-theme-color-shadow-highlight: rgba(255, 255, 255, 0.90);
        --smtc-status-warning-tint-background: rgba(243, 195, 87, 0.20);
    }
`,S=r.A`
    :host {
        --smtc-foreground-control-neutral-primary-rest: #FFFFFF;
        --smtc-foreground-ctrl-neutral-primary-rest: #e5ebfa;
        --smtc-theme-color-foreground-primary-100: #0f1119;
        --smtc-theme-color-foreground-primary-450: #525C7B;
        --smtc-theme-color-foreground-primary-550: #626D8F;
        --smtc-theme-color-foreground-primary-700: #a4adc8;
        --smtc-theme-color-foreground-primary-750: #c2cadf;
        --smtc-theme-color-foreground-primary-800: #d7deef;
        --smtc-theme-color-foreground-primary-850: #e5ebfa;
        --smtc-theme-color-foreground-primary-900: #f1f5ff;
        --smtc-theme-color-foreground-secondary-400: #626d8f;
        --smtc-theme-color-foreground-secondary-450: #8791b0;
        --smtc-theme-color-foreground-secondary-550: #8791b0;
        --smtc-theme-color-foreground-secondary-600: #a4adc8;
        --smtc-theme-color-foreground-secondary-650: #c2cadf;
        --smtc-theme-color-foreground-secondary-700: #d7deef;
        --smtc-theme-color-foreground-secondary-750: #e5ebfa;
        --smtc-theme-color-foreground-secondary-800: #f1f5ff;
        --smtc-theme-color-component-button-foreground-rest: #E5EBFA;
        --smtc-theme-color-component-button-foreground-pressed: #A4ADC8;
        --smtc-theme-color-component-button-strong-foreground-rest: #392D2E;
        --smtc-foreground-tint-neutral: #F2DDCC;
        --smtc-foreground-ctrl-neutral-primary-disabled: #ffffff4d;
        --smtc-foreground-ctrl-neutral-primary-pressed: #a4adc8;
        --smtc-foreground-ctrl-neutral-secondary-rest: #a4adc8;
        --smtc-foreground-ctrl-neutral-secondary-hover: #828BAC;
        --smtc-foreground-ctrl-active-brand-hover: #F1F5FF;
        --smtc-foreground-ctrl-active-brand-pressed: #D7DEEF;
        --smtc-foreground-ctrl-active-brand-rest: #E5EBFA;
        --smtc-foreground-ctrl-hint-default: #333A4E;
        --smtc-foreground-ctrl-on-brand-rest: #d7deef;
        --smtc-foreground-ctrl-on-brand-hover: #392D2E;
        --smtc-foreground-ctrl-on-brand-pressed: #a4adc8;
        --smtc-foreground-ctrl-on-brand-disabled: #ffffff4d;
        --smtc-foreground-ctrl-on-image-rest: #E3CBBC;
        --smtc-foreground-ctrl-on-outline-disabled: #5b5f64ff;
        --smtc-foreground-ctrl-on-outline-rest: #E5EBFA;
        --smtc-foreground-ctrl-on-outline-hover: #E5EBFA;
        --smtc-foreground-ctrl-on-outline-pressed: #a4adc8;
        --smtc-foreground-ctrl-on-subtle-hover: #D7DEEF;
        --smtc-foreground-ctrl-on-subtle-rest: #D7DEEF;
        --smtc-foreground-ctrl-on-subtle-pressed: #8791B0;
        --smtc-foreground-ctrl-on-transparent-rest: #E5EBFA;
        --smtc-foreground-ctrl-on-transparent-hover: #E5EBFA;
        --smtc-foreground-ctrl-on-transparent-pressed: #A4ADC8;
        --smtc-foreground-neutral-primary: #FFFFFF;
        --smtc-foreground-neutral-secondary: #C3C8CE;
        --smtc-foreground-link-rest: #3792FD;
        --smtc-ctrl-link-foreground-brand-rest: #5369b6;
        --smtc-ctrl-link-foreground-brand-hover: #5369b6;
        --smtc-ctrl-link-foreground-brand-pressed: #5369b6;
        --smtc-ctrl-link-foreground-neutral-rest: #E5EBFA;
        --smtc-ctrl-lite-filter-foreground-selected: #282D3E;
        --smtc-ctrl-tooltip-foreground: #D7DEEF;
        --smtc-status-warning-tint-foreground: #A25A02;
    }
`,_=r.A`
    :host {
        --smtc-foreground-control-neutral-primary-rest: #23272B;
        --smtc-foreground-ctrl-neutral-primary-rest: #272320;
        --smtc-theme-color-foreground-primary-100: #E5EBFA;
        --smtc-theme-color-foreground-primary-450: #746D68;
        --smtc-theme-color-foreground-primary-550: #635C57;
        --smtc-theme-color-foreground-primary-700: #3f3935;
        --smtc-theme-color-foreground-primary-750: #322d29;
        --smtc-theme-color-foreground-primary-800: #272320;
        --smtc-theme-color-foreground-primary-850: #191513;
        --smtc-theme-color-foreground-primary-900: #14110e;
        --smtc-theme-color-foreground-secondary-400: #98918b;
        --smtc-theme-color-foreground-secondary-450: #746d68;
        --smtc-theme-color-foreground-secondary-550: #635c57;
        --smtc-theme-color-foreground-secondary-600: #5a544f;
        --smtc-theme-color-foreground-secondary-650: #4c4642;
        --smtc-theme-color-foreground-secondary-700: #3f3935;
        --smtc-theme-color-foreground-secondary-750: #322d29;
        --smtc-theme-color-foreground-secondary-800: #272320;
        --smtc-theme-color-component-button-foreground-rest: #282523;
        --smtc-theme-color-component-button-foreground-pressed: #57514F;
        --smtc-theme-color-component-button-strong-foreground-rest: #F4EFED;
        --smtc-foreground-ctrl-neutral-primary-disabled: #0000004d;
        --smtc-foreground-ctrl-neutral-primary-pressed: #5a544f;
        --smtc-foreground-ctrl-neutral-secondary-rest: #4c4642;
        --smtc-foreground-ctrl-neutral-secondary-hover: #635D5A;
        --smtc-foreground-ctrl-active-brand-pressed: #322D29;
        --smtc-foreground-ctrl-active-brand-hover: #000;
        --smtc-foreground-ctrl-active-brand-rest: #272320ff;
        --smtc-foreground-ctrl-hint-default: #CCC6C2;
        --smtc-foreground-ctrl-on-brand-rest: #e2ddd9;
        --smtc-foreground-ctrl-on-brand-hover: #F4EFED;
        --smtc-foreground-ctrl-on-brand-pressed: #b3ada8;
        --smtc-foreground-ctrl-on-brand-disabled: #0000004d;
        --smtc-foreground-ctrl-on-image-rest: #ffffff;
        --smtc-foreground-ctrl-on-outline-disabled: #a4a9b0ff;
        --smtc-foreground-ctrl-on-outline-rest: #272320;
        --smtc-foreground-ctrl-on-outline-hover: #282523;
        --smtc-foreground-ctrl-on-outline-pressed: #5a544f;
        --smtc-foreground-ctrl-on-subtle-rest: #272320;
        --smtc-foreground-ctrl-on-subtle-hover: #272320;
        --smtc-foreground-ctrl-on-subtle-pressed: #5A544F;
        --smtc-foreground-ctrl-on-transparent-rest: #272320;
        --smtc-foreground-ctrl-on-transparent-hover: #272320;
        --smtc-foreground-ctrl-on-transparent-pressed: #5A544F;
        --smtc-foreground-neutral-primary: #23272B;
        --smtc-foreground-neutral-secondary: #474B50;
        --smtc-foreground-link-rest: #026FD7;
        --smtc-foreground-tint-blue: #4193ff;
        --smtc-foreground-tint-neutral: #282523;
        --smtc-ctrl-link-foreground-brand-rest: #8a4b01;
        --smtc-ctrl-link-foreground-brand-hover: #8a4b01;
        --smtc-ctrl-link-foreground-brand-pressed: #8a4b01;
        --smtc-ctrl-link-foreground-neutral-rest: #272320;
        --smtc-ctrl-lite-filter-foreground-selected: #E2DDD9;
        --smtc-ctrl-tooltip-foreground: #322D29;
        --smtc-status-warning-tint-foreground: #A25A02;
    }
`,T=r.A`
    :host {
        --smtc-stroke-divider-default: #354479;
        --smtc-theme-color-stroke-default-250: #282F42;
        --smtc-theme-color-stroke-default-300: #313A52;
        --smtc-theme-color-stroke-default-350: #455172;
        --smtc-theme-color-stroke-default-450: #6B7597;
        --smtc-theme-color-stroke-default-550: #3E5091;
        --smtc-theme-color-accent-350: #354479;
        --smtc-theme-color-accent-300: #2C3860;
        --smtc-theme-color-stroke-muted-200: #1F2330;
        --smtc-theme-color-stroke-muted-250:  #333A4E;
        --smtc-theme-color-stroke-muted-300: #3E4760;
        --smtc-stroke-ctrl-on-outline-disabled: #ffffff14;
        --smtc-stroke-ctrl-on-outline-hover: #ffffff14;
        --smtc-stroke-ctrl-on-outline-pressed: #ffffff14;
        --smtc-stroke-ctrl-on-outline-rest: #ffffff14;
        --smtc-stroke-card-on-primary-rest: #ffffff26;
        --smtc-stroke-divider-subtle: #ffffff1a;
        --smtc-stroke-flyout: #FFFFFF1F;
        --smtc-ctrl-input-stroke-rest: #ffffff0d;
        --smtc-ctrl-input-stroke-selected: #c2cadf;
        --smtc-ctrl-choice-base-stroke-rest: #9DA8D9;
        --smtc-ctrl-choice-base-stroke-disabled: rgba(255, 255, 255, 0.3);
        --smtc-ctrl-choice-switch-stroke-rest: rgba(255, 255, 255, 0);
        --smtc-ctrl-source-icon-border: #0F1119;
        --smtc-edge-ctrl-omnibox-stroke-focused: #ffffff;
        --smtc-status-informative-tint-stroke: #333A4E;
        --smtc-mai-ctrl-tooltip-stroke: rgba(0, 0, 0, 0.20);
    }
`,I=r.A`
    :host {
        --smtc-stroke-divider-default: #dac6b7;
        --smtc-theme-color-stroke-default-250: #F2DDCC;
        --smtc-theme-color-stroke-default-300: #E3CBBC;
        --smtc-theme-color-stroke-default-350: #BBA5A0;
        --smtc-theme-color-stroke-default-450: #867073;
        --smtc-theme-color-stroke-default-550: #CA7D36;
        --smtc-theme-color-accent-350: #E29C61;
        --smtc-theme-color-accent-300: #F8BC8C;
        --smtc-theme-color-stroke-muted-200: #F4EFED;
        --smtc-theme-color-stroke-muted-250: #E2DDD9;
        --smtc-theme-color-stroke-muted-300: #D0C9C4;
        --smtc-stroke-ctrl-on-outline-disabled: #00000014;
        --smtc-stroke-ctrl-on-outline-hover: #00000014;
        --smtc-stroke-ctrl-on-outline-pressed: #00000014;
        --smtc-stroke-ctrl-on-outline-rest: #00000014;
        --smtc-stroke-card-on-primary-rest: #0000001f;
        --smtc-stroke-divider-subtle: #0000001a;
        --smtc-stroke-flyout: #FFFFFFE5;
        --smtc-ctrl-input-stroke-rest: #0000000d;
        --smtc-ctrl-input-stroke-selected: #3f3935;
        --smtc-ctrl-choice-base-stroke-rest: #4A4543;
        --smtc-ctrl-choice-base-stroke-disabled: rgba(0, 0, 0, 0.3);
        --smtc-ctrl-choice-switch-stroke-rest: rgba(0, 0, 0, 0);
        --smtc-ctrl-badge-stroke: rgba(255, 255, 255, 0.00);
        --smtc-ctrl-source-icon-border: #FFFBF8;
        --smtc-edge-ctrl-omnibox-stroke-focused: #000000;
        --smtc-status-informative-tint-stroke: #E2DDD9;
        --smtc-mai-ctrl-tooltip-stroke: rgba(255, 255, 255, 0.20);
    }
`,B=r.A`
   ${$}
   ${F}
   ${S}
   ${T}
   ${A}
`,D=r.A`
   ${k}
   ${R}
   ${_}
   ${I}
   ${C}
`.withBehaviors((0,s.G2)(B)),P=r.A`
    :host {
        --smtc-material-acrylic-blur: 60px;        
        --smtc-mai-shadow-ctrl-brand-key-blur: 3px;
        --smtc-mai-shadow-ctrl-brand-key-x: 0;
        --smtc-mai-shadow-ctrl-brand-key-y: 1px;
    }
`,E=r.A`
    :host {
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-blur: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-inner-shine-spread: 0.5px;
        
        --smtc-shadow-ctrl-button-neutral-rest-key-x: 0px;
        --smtc-shadow-ctrl-button-neutral-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-button-neutral-rest-key-blur: 3px;
        
        --smtc-shadow-ctrl-brand-key-x: 0px;
        --smtc-shadow-ctrl-brand-key-y: 0.5px;
        --smtc-shadow-ctrl-brand-key-blur: 3px;
    }
`,z=r.A`
    :host {
        --smtc-shadow-ctrl-fab-rest-key-x: 0px;
        --smtc-shadow-ctrl-fab-rest-key-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-key-blur: 3px;
        
        --smtc-shadow-ctrl-fab-rest-ambient-y: 0.5px;
        --smtc-shadow-ctrl-fab-rest-ambient-blur: 0.5px;

        --smtc-shadow-ctrl-fab-disabled-key-y: 4px;
        --smtc-shadow-ctrl-fab-disabled-key-blur: 6px;

        --smtc-shadow-ctrl-fab-hover-key-y: 1px;
        --smtc-shadow-ctrl-fab-hover-key-blur: 3px;
    }
`,N=r.A`
    :host {
        --smtc-shadow-flyout-ambient-x: 0px;
        --smtc-shadow-flyout-ambient-y: 0px;
        --smtc-shadow-flyout-ambient-blur: 0px;
        
        --smtc-shadow-flyout-key-x: 0px;
        --smtc-shadow-flyout-key-y: 6px;
        --smtc-shadow-flyout-key-blur: 12px;
    }
`,O=r.A`
    :host {
        --smtc-effect-drop-shadow-medium-x-offset: 0px;
        --smtc-effect-drop-shadow-medium-y-offset: 6px;
        --smtc-effect-drop-shadow-medium-blur-radius: 12px;
        --smtc-effect-drop-shadow-medium-spread: 0px;
    }
`,M=r.A`
    ${E}
`;var H=i(25975);const L=r.A`
    :host {
        --cstm-corner-media-in-card: calc(28px * ${H.MU6});
    }
`,V=(r.A`${L}`,r.A`${L}`,r.A`${L}`),U=r.A`${L}`,W=r.A`
    :host {
        --smtc-corner-card-small-rest: 48px;
        --smtc-corner-card-rest: 24px;
        --smtc-corner-card-nested-small-outside: 36px;
        --smtc-corner-card-nested-small-inside: 36px;
        --smtc-corner-card-discover-nested-outside: 48px;
        --smtc-corner-card-discover-nested-inside: 32px;
        --smtc-corner-card-alternate-small-rest: 24px;
        --mai-smtc-corner-card-default: 60px;
        --mai-smtc-corner-card-nested-small-outside: 36px;
        --mai-smtc-corner-card-nested-default-inside: 32px;
        --mai-smtc-corner-card-nested-default-outside: 48px;
        --mai-smtc-corner-card-nested-large-inside: 32px;
        --mai-smtc-corner-card-nested-large-outside: 48px;
    }
`,j=r.A`
    :host {
        --smtc-corner-ctrl-fab-rest: 24px;
        --smtc-corner-ctrl-sm-rest: 12px;
        --smtc-corner-ctrl-lg-rest: 20px;
        --smtc-corner-ctrl-hover: 12px;
        --smtc-corner-ctrl-rest: 12px;
        --smtc-corner-ctrl-sm-hover: 14px;
        --smtc-ctrl-badge-corner: 8px;
        --smtc-ctrl-badge-sm-corner: 8px;
        --smtc-ctrl-choice-checkbox-corner: 9999px;
    }
`,G=r.A`
    :host {
        --smtc-corner-layer-default: 16px;
        --smtc-corner-favicon: 6px;
        --smtc-corner-flyout-rest: 20px;
        --smtc-corner-rounded-5-rem: 20px;
        --smtc-static-corner-rounded-5-base: 20px;
        --smtc-static-corner-rounded-3-5-rem: 14px;
        --smtc-static-corner-rounded-5-rem: 20px;
        --smtc-static-corner-rounded-6-rem: 24px;
    }
`,K=r.A`
    :host {
        --squircle-modifier: 1;
    }

    @supports (corner-shape: squircle) {
        :host {
            --squircle-modifier: 1.8;
        }
    }
`,Y=r.A`
    :host {
        --mai-smtc-corner-card-default: 24px;
        --mai-smtc-corner-card-nested-default-outside: 16px;
        --cstm-corner-media-in-card: 24px;
        --smtc-corner-card-small-rest: 24px;
        --smtc-corner-card-discover-nested-outside: 24px;
        --smtc-corner-card-nested-small-inside: 24px;
        --smtc-corner-card-nested-small-outside: 24px;
    }
`.withBehaviors(new n.P("prg-cpad-t2",V),new n.P("prg-pr2-cpad-t2",U)),q=r.A`
    ${j}
    ${W}
    ${G}
`,X=r.A`
    :host {
        --smtc-padding-content-none: 0px;
        --smtc-padding-content-xxSmall: 4px;
        --smtc-padding-content-xSmall: 8px;
        --smtc-padding-content-xSmallNudge: 7px;
        --smtc-padding-content-small: 12px;
        --smtc-padding-content-medium: 16px;
        --smtc-padding-content-large: 20px;
        --smtc-padding-content-xLarge: 24px;
        --smtc-padding-content-xxLarge: 32px;
        --smtc-padding-content-xxxLarge: 40px;
    }
`,Z=r.A`
    :host {
        --smtc-gap-between-content-xx-small: 4px;
        --smtc-gap-between-content-x-small: 8px;
        --smtc-gap-between-content-small: 12px;
        --smtc-gap-between-content-medium: 16px;
        --smtc-gap-between-content-large: 20px;
        --smtc-gap-between-content-x-large: 22px;
        --smtc-gap-between-content-xxlarge: 32px;
        --smtc-gap-between-content-xx-large: 32px;
        --smtc-gap-between-content-xxx-large: 40px;
    }
`,Q=r.A`
    :host {
        --smtc-padding-ctrl-horizontal-default: 10px;
        --smtc-padding-ctrl-sm-horizontal-default: 8px;
        --smtc-padding-ctrl-sm-horizontal-icon-only: 6px;
        --smtc-padding-ctrl-lg-horizontal-default: 16px;
        --smtc-padding-ctrl-lg-button-default: 14px;
        --smtc-padding-ctrl-text-bottom: 10px;
        --smtc-padding-ctrl-text-side: 2px;
        --smtc-padding-ctrl-text-top: 10px;
        --smtc-padding-ctrl-lg-text-bottom: 11px;
        --smtc-padding-ctrl-lg-text-side: 2px;
        --smtc-padding-ctrl-lg-text-top: 11px;
    }
`,J=r.A`
    :host {
        --smtc-gap-inside-ctrl-default: 2px;
        --smtc-gap-inside-ctrl-to-label: 8px;
        --smtc-gap-inside-ctrl-to-secondary-icon: 4px;
        --smtc-gap-inside-ctrl-lg-to-secondary-icon: 6px;
        --smtc-gap-between-ctrl-default: 8px;
        --smtc-gap-between-ctrl-lg-default: 12px;
        --smtc-gap-between-text-large: 6px;
    }
`,tt=r.A`
    :host {
        --smtc-padding-card-default: 12px;
        --smtc-padding-card-body-default-horizontal-start: 20px;
    }
`,et=r.A`
    :host {
        --smtc-padding-flyout-default: 8px;
    }
`,it=r.A`
    :host {
        --smtc-ctrl-badge-gap: 2px;
        --smtc-ctrl-badge-padding: 6px;
        --smtc-ctrl-badge-sm-padding: 4px;
        --smtc-ctrl-badge-text-padding-top: 4px;
        --smtc-ctrl-badge-sm-text-padding-top: 2px;
    }
`,rt=r.A`
    :host {
        --smtc-static-spacing-base: 4px;
        --smtc-static-spacing-0-5-base: 2px;
        --smtc-static-spacing-1-5-base: 6px;
        --smtc-static-spacing-3-5-base: 14px;
        --smtc-static-spacing-4-base: 16px;
        --smtc-static-spacing-8-base: 32px;
        --smtc-static-spacing-9-base: 36px;
        --smtc-static-spacing-2-rem: 8px;
        --smtc-static-spacing-2-5-rem: 10px;
    }
`,st=r.A`
    :host {
        --smtc-ctrl-choice-padding-horizontal: 4px;
    }
`,ot=r.A`
    ${X}
    ${Z}
    ${J}
`;var nt=i(99563);const at=r.A`
    :host {
        --smtc-text-ctrl-weight-default: 410;
        --smtc-text-style-default-header-weight: 650;
        --smtc-text-style-default-display-weight: 480;
        --smtc-text-style-default-regular-weight: 410;
        --smtc-text-style-default-display-letterSpacing: 0;
        --smtc-text-style-default-regular-letterSpacing: 0;
    }
`,ct=r.A`
    :host {
        --smtc-text-global-body1-font-size: 18px;
        --smtc-text-global-body1-line-height: 26px;
        --smtc-text-global-body1-font-weight: 400;
        --smtc-text-global-body2-font-size: 16px;
        --smtc-text-global-body2-line-height: 22px;
        --smtc-text-global-body3-font-size: 14px;
        --smtc-text-global-body3-line-height: 20px;
        --smtc-text-global-body3-font-weight: 400;
        --smtc-text-global-body3-font-weight-strong: 550;
        --smtc-text-global-body4-font-size: 16px;
        --smtc-text-global-body4-line-height: 24px;
        --smtc-text-global-body5-font-size: 16px;
        --smtc-text-global-body5-line-height: 26px;
        --smtc-text-global-body5-font-weight: 410;
    }
`,dt=r.A`
    :host {
        --smtc-text-global-caption1-font-size: 12px;
        --smtc-text-global-caption1-line-height: 16px;
        --smtc-text-global-caption1-font-weight: 500;
        --smtc-text-global-caption2-font-size: 10px;
        --smtc-text-global-caption2-line-height: 14px;
    }
`,lt=r.A`
    :host {
        --smtc-text-global-display1-font-size: 38px;
        --smtc-text-global-display1-line-height: 40px;
        --smtc-text-global-display2-font-size: 28px;
        --smtc-text-global-display2-line-height: 32px;
        --smtc-text-global-display2-font-weight: 620;
    }
`,ht=r.A`
    :host {
        --smtc-text-global-title1-font-size: 24px;
        --smtc-text-global-title1-line-height: 32px;
        --smtc-text-global-title2-font-size: 20px;
        --smtc-text-global-title2-line-height: 26px;
        --smtc-text-global-title2-font-weight: 500;
        --smtc-text-global-title3-font-size: 20px;
        --smtc-text-global-title3-line-height: 26px;
        --smtc-text-global-title3-font-weight: 500;
    }
`,ut=r.A`
    :host {
        --smtc-text-global-subtitle1-font-size: 20px;
        --smtc-text-global-subtitle1-line-height: 26px;
    }
`,pt=r.A`
    :host {
        --smtc-text-ramp-item-body-font-size: 14px;
        --smtc-text-ramp-item-body-line-height: 20px;
        --smtc-text-ramp-lg-item-body-font-size: 16px;
        --smtc-text-ramp-lg-item-body-line-height: 26px;
        --smtc-text-ramp-legal-font-size: 12px;
        --smtc-text-ramp-legal-line-height: 16px;
        --smtc-text-ramp-metadata-font-size: 14px;
        --smtc-text-ramp-metadata-line-height: 20px;
    }
`,mt=r.A`
    :host {
        --smtc-text-style-default-regular-font-family: ${p.er};
        --smtc-style-default-regular-font-family: ${p.er};
        --smtc-style-default-header-font-family: ${p.er};
    }
`,gt=r.A`
    :host {
        --smtc-typography-font-size-700: 24px;
        --smtc-typography-line-height-700: 31px;
        --smtc-typography-font-weight-700: 650;
        --smtc-typography-font-size-110: 39px;
        --smtc-typography-line-height-110: 40px;
        --smtc-typography-font-weight-110: 480;
    }
`,bt=r.A`
    :host {
        --smtc-text-global-body1-font-size: 17px;
    }
`,ft=r.A`${bt}`,vt=r.A`
    :host {
        --smtc-text-style-default-regular-font-family: ${p.Yn};
        --smtc-style-default-regular-font-family: ${p.Yn};
        --smtc-style-default-header-font-family: ${p.Yn};
    }
`,yt=r.A`
    :host {
        --smtc-text-style-default-regular-font-family: ${p.Hx};
        --smtc-style-default-regular-font-family: ${p.Hx};
        --smtc-style-default-header-font-family: ${p.Hx};
        --smtc-text-style-default-header-weight: 620;
    }
`,wt=r.A`${yt}`,xt=r.A`${yt}`,$t=r.A`
    ${at}
    ${ct}
    ${dt}
    ${lt}
    ${ht}
    ${ut}
    ${pt}
    ${mt}
    ${gt}
`.withBehaviors(new n.P("prg-ntp-sysfnt",vt),new n.P("prg-ruby-segoe",wt),new n.P("prg-pr2-ruby-segoe",xt),new nt.y(g,b,"prg-cnr-font-yh"),new nt.y(g,f,"prg-cnr-font-nts"),new u("ja-jp",v),new u("ko-kr",y),new n.P("prg-lg-flex-rev",ft)),kt=r.A`
    @media (forced-colors: active) {
        :host {
            --smtc-background-flyout-saturation-blend: rgba(255, 255, 0, 1);
        }
    }
`,At=r.A`
    :host {
        --smtc-static-color-overlay-black-8: rgba(0, 0, 0, 0.08);
        --smtc-static-color-overlay-black-10: rgba(0, 0, 0, 0.1);
        --smtc-static-color-alpha-white-80: #FFFFFFCC;
        --smtc-static-color-alpha-black-70: #000000B2;
        --smtc-static-color-blue-350: #78b0ff;
        --smtc-static-color-blue-550: #0159ba;
        --smtc-static-color-caramel-400: #CA7D36;
        --smtc-static-color-caramel-450: #A25A02;
        --smtc-static-color-green-400: #32AD52;
        --smtc-static-color-green-450: #008633;
        --smtc-static-color-green-550: #01712B;
        --smtc-static-color-green-600: #016826;
        --smtc-static-color-green-700: #014818;
        --smtc-static-color-green-800: #0D2B13;
        --smtc-static-color-lime-450: #667901;
        --smtc-static-color-midnight-450: #586BA8;
        --smtc-static-color-orange-450: #A25A02;
        --smtc-static-color-red-400: #E7615B;
        --smtc-static-color-red-550: #AC1922;
        --smtc-static-color-yellow-450: #8C6801;
    }
    
    ${kt}
`,Ct=r.A`
    ${F}
    ${S}
    ${T}
`,Ft=r.A`
    ${At}
    ${R}
    ${_}
    ${I}
`.withBehaviors((0,s.G2)(Ct)),Rt=r.A`
    :host {
        --smtc-padding-card-default: 8px;
    }
`,St=r.A`
    ${Rt}
`,_t=r.A`
    ${Rt}
`,Tt=r.A`
    ${X}
    ${Z}
    ${Q}
    ${J}
    ${tt}
    ${et}
    ${it}
    ${st}
    ${rt}
`.withBehaviors(new n.P("prg-cpad-t2",St),new n.P("prg-pr2-cpad-t2",_t)),It=r.A`
    ${K}
    ${W}
    ${j}
    ${G}
    ${l.VE}
    ${Y}
`,Bt=r.A`
    :host {
        --smtc-theme-color-component-attribution-item-background-hover: #FFF;
        --smtc-theme-color-component-attribution-item-background-rest: #FEFCFB;
        --smtc-theme-color-component-button-strong-background-rest: #282523;
        --smtc-theme-color-component-button-subtle-bright-background-pressed: rgba(255, 255, 255, 0.35);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-background-hover: rgba(0, 0, 0, 0.05);
        --smtc-theme-color-component-button-subtle-dimmed-background-pressed: rgba(0, 0, 0, 0.03);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-hover: rgba(0, 0, 0, 0.05);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-pressed: rgba(0, 0, 0, 0.03);
        --smtc-theme-color-component-button-outline-dimmed-inverted-stroke-pressed: rgba(177, 170, 166, 1);
        --smtc-theme-color-component-card-answer-background-inner: rgba(204, 196, 192, 0.2);
        --smtc-theme-color-component-card-answer-background-outer: rgba(255, 255, 255, 0.45);
        --smtc-theme-color-component-card-background-neutral: rgba(255, 255, 255, 0.80);
        --smtc-theme-color-component-citation-background-hover: #E3DDD8;
        --smtc-theme-color-component-citation-background-rest: #F0EAE5;
        --smtc-theme-color-component-composer-stop-button-background-hover: #E3B388;
        --smtc-theme-color-component-table-background-cell: rgba(255, 255, 255, 0.25);
        --smtc-theme-color-component-table-background-header: #FFEDDE;
        --smtc-theme-color-component-textbox-background-active: #0000000D;
        --smtc-theme-color-component-chip-background-rest: rgba(255, 255, 255, 0.3);
    }
`,Dt=r.A`
    :host {
        --smtc-theme-color-component-attribution-item-background-hover: #1D2439;
        --smtc-theme-color-component-attribution-item-background-rest: #171E32;
        --smtc-theme-color-component-button-strong-background-rest: #E4E6F1;
        --smtc-theme-color-component-button-subtle-bright-background-pressed: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-bright-inverted-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-background-hover: rgba(0, 0, 0, 0.3);
        --smtc-theme-color-component-button-subtle-dimmed-background-pressed: rgba(0, 0, 0, 0.2);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-hover: rgba(255, 255, 255, 0.08);
        --smtc-theme-color-component-button-subtle-dimmed-inverted-background-pressed: rgba(255, 255, 255, 0.05);
        --smtc-theme-color-component-button-outline-dimmed-inverted-stroke-pressed: rgba(69, 81, 114, 1);
        --smtc-theme-color-component-card-answer-background-inner: rgba(157, 168, 217, 0.05);
        --smtc-theme-color-component-card-answer-background-outer: rgba(157, 168, 217, 0.10);
        --smtc-theme-color-component-card-background-neutral: rgba(157, 168, 217, 0.10);
        --smtc-theme-color-component-citation-background-hover: #282D3E;
        --smtc-theme-color-component-citation-background-rest: #1F2431;
        --smtc-theme-color-component-composer-stop-button-background-hover: #6777AF;
        --smtc-theme-color-component-table-background-cell: rgba(0, 0, 0, 0.25);
        --smtc-theme-color-component-table-background-header: #171E32;
        --smtc-theme-color-component-textbox-background-active: #4B5C9240;
        --smtc-theme-color-component-chip-background-rest: rgba(0, 0, 0, 0.03);
    }
`,Pt=r.A`
    :host {
        --smtc-ctrl-coachmark-foreground: #FFFBF8;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
    }
`,Et=r.A`
    :host {
        --smtc-ctrl-coachmark-foreground: #0F1119;
        --smtc-icon-color-primary-filter: invert(92%) sepia(10%) saturate(500%) hue-rotate(200deg) brightness(98%) contrast(95%);
    }
`,zt=r.A`
    :host {
        --smtc-ctrl-focus-inner-stroke: #00000000;
        --smtc-ctrl-focus-outer-stroke: #322d29;
    }
`,Nt=r.A`
    :host {
        --smtc-ctrl-focus-inner-stroke: #00000000;
        --smtc-ctrl-focus-outer-stroke: #d7deef;
    }
`,Ot=r.A`
    ${R}
    ${Bt}
    ${_}
    ${Pt}
    ${I}
    ${zt}
    ${k}
    ${C}
    ${"\n    :host {\n        --smtc-theme-color-overlay-black-30: rgba(255, 255, 255, 0.30);\n        --smtc-theme-color-overlay-black-5: #0000000D;\n    }\n"}
`,Mt=r.A`
    ${F}
    ${Dt}
    ${S}
    ${Et}
    ${T}
    ${Nt}
    ${$}
    ${A}
    ${"\n    :host {\n        --smtc-theme-color-overlay-black-30: rgba(255, 255, 255, 0.30);\n        --smtc-theme-color-overlay-black-5: #FFFFFF0D;\n        \n    }\n"}
`,Ht=r.A`
    ${P}
    ${E}
    ${z}
    ${N}
    ${O}
`,Lt=r.A`
    :host {
        --smtc-ctrl-badge-size: 19px;
        --smtc-ctrl-badge-sm-size: 19px;
        --smtc-size-ctrl-choice-base: 20px;
        --smtc-size-ctrl-default: 40px;
        --smtc-size-ctrl-lg-default: 48px;
        --smtc-size-ctrl-sm-default: 36px;
    }
`,Vt=r.A`
    :host {
        --smtc-ctrl-badge-icon-size: 16px;
        --smtc-ctrl-citation-icon-size: 16px;
        --smtc-ctrl-source-icon-size: 16px;
        --smtc-size-ctrl-xl-icon: 28px;
        --smtc-size-ctrl-lg-icon: 24px;
        --smtc-size-ctrl-sm-icon: 24px;
    }
`,Ut=r.A`
    ${Lt}
    ${Vt}
`,Wt=r.A`
    :host {
        --smtc-ctrl-input-stroke-width-rest: 1px;
        --smtc-stroke-width-ctrl-choice-rest: 2px;
        --smtc-stroke-width-ctrl-outline: 2px;
        --smtc-stroke-width-ctrl-outline-rest: 1px;
        --smtc-stroke-width-default: 1px;
        --mai-smtc-stroke-width-card-default: 0.5px;
    }
`,jt=r.A`
    ${Wt}
`;var Gt=i(46026);r.A` ${D} ${M} ${q} ${ot} ${$t} ${l.bX}
`,r.A` ${Ft} ${$t} ${Tt} ${It}
`;const Kt=r.A` :host{--smtc-corner-flyout-rest:20px}${At}
`,Yt=r.A` ${l._8} ${Mt}
`,qt=r.A` ${Ot} ${Tt} ${$t} ${Ht} ${It} ${Ut} ${jt}
`,Xt=r.A` ${qt} ${"winWidgets"===h.T3.AppType?x:d} ${l.bX} ${Kt} ${"edgeChromium"===h.T3.AppType||"views"===h.T3.AppType||"winWidgets"===h.T3.AppType?Gt.H:r.A``} ${"bingHomepage"===h.T3.AppType&&"dark"===window.__theme?Yt:r.A``}
`.withBehaviors((0,s.G2)("bingHomepage"!==h.T3.AppType?Yt:r.A``),new u("ja-jp",v),new u("ko-kr",y))},34241(t,e,i){i.d(e,{w(){return a}});var r=i(59669),s=i(22131);const o=r.A` .skeleton{background:rgba(0,0,0)}@keyframes pulse{0%{opacity:0.06}50%{opacity:0.1}100%{opacity:0.06}}`,n=r.A` .skeleton{background:rgba(255,255,255)}@keyframes pulse{0%{opacity:0.1}50%{opacity:0.15}100%{opacity:0.1}}`,a=r.A`.flex-row{display:flex;flex-direction:row}.flex-col{display:flex;flex-direction:column}.skeleton{animation:pulse 1.5s alternate infinite;animation-timing-function:linear}`.withBehaviors((0,s.C7)(o),(0,s.G2)(n))},82281(t,e,i){i.d(e,{R(){return s}});var r=i(75117);function s(t){const e=(0,r.rA)().CurrentRequestTargetScope?.pageExperiments||[];return e&&e.includes(t)}},54863(t,e,i){function r(t){if(!t)return t;return t.replace(new RegExp(`(${["ftp","http","https","rtp","rtmp","sftp"].join("|")})\\s*/{2}(?=[^\\s/])`,"g"),"$1://")}function s(t,e=!0){if(!t)return t;const i=r(t);if(e){const t=i.replace(/<a\b[^>]*>.*?<\/a>/gi,"");return t.replace(/https?:\/\/[^\s]+|www\.[^\s]+/gi,"")}return i}i.d(e,{r3(){return r},wR(){return s}})}}]);