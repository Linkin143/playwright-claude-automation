"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-spotlight"],{70512:function(e,t,i){i.d(t,{O:function(){return o}});var a=i(67072),r=i(23305);class o extends r.Bc{constructor(){super(...arguments),this.getCardTitle=(e,t)=>t?this.transformerProvider.strings.teamStats:e?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(e){return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){let{cardSize:t,isFullCard:i,sportsGameStats:r,isSpotlight2Card:o,participants:s,isSeasonStats:l,isCopilotTheme:n,isMitUX:p}=e,d=0;switch(t){case a.uE._1x_2y:d=i?5:3;break;case a.uE._1x_3y:d=7;break;case a.uE._2x_2y:d=4;break;case a.uE._15u:d=3}return{sportsGameStats:r.slice(0,d).map(e=>{let t=e.key;return{...e,leftText:this.getStatText(e.leftText,t),rightText:this.getStatText(e.rightText,t),left:this.getBarPercentage(e.left,e.right,t),right:this.getBarPercentage(e.right,e.left,t),key:this.transformerProvider.strings[t]||t}}),cardSize:t,isSpotlight2Card:o,isFullCard:i,participants:s,cardTitle:this.getCardTitle(l,n),isCopilotTheme:n,isMitUX:p,telemetryTag:""}}isPercentStats(e){return e?.includes("%")}getBarPercentage(e,t,i){let a=this.isPercentStats(i);return 0===e&&0===t?0:(a?e:e/(e+t))*100}getStatText(e,t){return e&&t?this.isPercentStats(t)?`${(100*parseFloat(e)).toFixed(1)}`:e:""}}},43207:function(e,t,i){i.d(t,{$:function(){return o}});var a=i(23305),r=i(18633);class o extends a.Bc{async transform(e){return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){let{poll:t,telemetryConstants:i,parentTelemetryObject:o,match:s,isSpotlight2Card:l,pollOptionIds:n}=e||{},{participantOne:p,participantTwo:d,gameState:c,gameId:g}=s||{},{strings:m,telemetryBuilder:h}=this.transformerProvider,y=[p,d],u=0;Array.isArray(t.options)||(t.options=[]);let v=t.options.find(e=>n?.has(e.id))?.id;return t.options?.forEach(e=>{(e.id===y[0].id||e.id===y[1].id)&&(u+=parseInt(e.count))}),u+=+!!v,{strings:{...m},isSpotlight2Card:l,isEntrypoint:!0,isCopilotTheme:e.isCopilotTheme,cardSize:e.cardSize,teamsVoteData:y.map(e=>{let i=parseInt(t.options?.find(t=>t.id===e.id)?.count)||0;return i+=+(v===e.id),{id:e.id,imageUrl:e.imageUrl,shortName:e.shortName||e.name,hasWon:e.isWinner,voteCount:i,votePercentage:Math.round(i/u*100)||0}}),gameState:"string"==typeof c?c:c.state,userVote:t.userVote,disableVoting:c!==a.Xp.preGame,telemetryContext:{rootTag:o.getMetadataTag(),voteButtonTag:h.createBehaviorTelemetryTag(o,{...i,name:a.BP.SportsPickWinner},r.YJ.Click)},recordUserVote:async e=>{this.transformerProvider.recordUserVote(g,a.t9.PickWinner,e)},telemetryTag:o.getMetadataTag()}}}},34959:function(e,t,i){i.d(t,{V:function(){return d}});var a=i(79811),r=i(23305),o=i(67072),s=i(33744),l=i(89757),n=i(87906),p=i(40450);class d extends r.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0},timeOfPossession:{isTime:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"totalYards",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame",timeOfPossession:"timeOfPossession"}}async transform(e){this.isCopilotTheme=e.isCopilotTheme||!1;let t={...e,spotlightData:this.transformSportsSpotlightData(e.spotlightData,e.tabClickThroughUrl,e.isSpotlightFRE)},i=await this.getCurrentViewModel(t);return{viewTemplate:(0,l.qy)`
                <sports-spotlight
                    :viewModel="${i}"
                ></sports-spotlight>`}}async getCurrentViewModel(e){let t,i,l,d,c;if(!e||0===Object.keys(e).length)return void(0,n.vV)(p.K0b,"Spotlight metadata missing",`market=${s.T3.CurrentMarket}`,e);let{cardSize:g,tabClickThroughUrl:m}=e,h=g===o.uE._1x_1y||g===o.uE._05u,y=this.getPlayerEventCard(e);y||h||!this.transformerProvider.config.enablePickWinner||(t=await this.getPolls(e));let u=t||y&&g===o.uE._1x_3y,v=await this.getMatches(e,!!u);y||!e.isSpotlightFRE&&h||null!=t||(i=this.getVideoInfo(e),l=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsSpotlightVideo}));let b=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsInfoSpotlight});y||h||null!=i||null!=t||(d=await this.getGameStatsInfo(e)),v.length||((c=e.spotlightData.headerData).clickThroughUrl=e.tabClickThroughUrl);let f=await this.getGameLeadersInfo(e),x=e.spotlightData?.sportsGcNav,w=m;return x&&(w=(0,a.EZ)((0,a.Ot)(m),{sportsGcNav:x}),i&&(i.msnVideoEmbedLink=(0,a.EZ)(i.msnVideoEmbedLink,{sportsGcNav:x}))),{cardSize:g,tabClickThroughUrl:w,matches:v,sportsGameStatsCard:d,sportsPickWinnerCard:t,sportsVideo:i,headerData:c,spotsVideoTelemetry:l,telemetryTag:b,sportsGameLeadersCard:f,sportsPlayerEventCard:y,isCopilotTheme:this.isCopilotTheme,isMitUX:e.isMitUX}}async getPolls(e){let{pollOptionIds:t,isSpotlight2Card:i,spotlightData:{poll:a,matchlist:o}={},cardSize:s}=e;if(!(a?.pollId||a?.type===r.t9.PickWinner)||!o?.length||!o[0].sportsMatchData)return null;let{participantOne:l,participantTwo:n}=o[0].sportsMatchData||{};if(!o||!l||!n)return null;if(t?.size){let e=a.options?.find(e=>t.has(e.id));a.userVote=e?.id}let p={poll:a,pollOptionIds:t,match:o[0].sportsMatchData,isSpotlight2Card:i,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,isCopilotTheme:this.isCopilotTheme,cardSize:s};return await this.transformerProvider.generateView(p,r.hi.SportsPickWinner)}getVideoInfo(e){let{video:t}=e.spotlightData||{};if(!t)return null;let i="LiveStream"===t.videoType,a=e.isSpotlightFRE?null:e.primaryEntityName||this.transformerProvider.strings.gameHighlights;return{...t,isStream:i,videoTagTitle:i?void 0:a,tabTitle:i?a:void 0,sourceIconUrl:t.sourceIconUrl||void 0}}async getGameStatsInfo(e){let{spotlightData:t,isSpotlight2Card:i}=e||{},{sportsGameStats:a,isSeasonStats:o=!1,matchlist:s,isGameStatsFull:l}=t||{};if(!a)return null;let{cardSize:n}=e,{participantOne:p,participantTwo:d}=s[0].sportsMatchData||{},c={cardSize:n,sportsGameStats:a,isSeasonStats:o,isSpotlight2Card:i,isFullCard:l,participants:[p,d],isCopilotTheme:this.isCopilotTheme,isMitUX:e.isMitUX};return await this.transformerProvider.generateView(c,r.hi.SportsGameStats)}async getGameLeadersInfo(e){let{gameLeaders:t,matchlist:i}=e.spotlightData||{},{sportsMatchData:o}=i.length?i[0]:{sportsMatchData:void 0},s={};if(o?.participantOne?.id&&(s[o.participantOne.id]=(0,a.gS)(o.participantOne.primaryColorHex)),o?.participantTwo?.id&&(s[o.participantTwo.id]=(0,a.gS)(o.participantTwo.primaryColorHex)),!t)return null;let{cardSize:l}=e,n={cardSize:l,sportsGameLeaders:t,teamColors:s,parentTelemetryObject:e.telemetryObject};return await this.transformerProvider.generateView(n,r.hi.SportsGameLeaders)}getPlayerEventCard(e){let{playerEvent:t}=e.spotlightData||{};if(!t)return null;let i=(0,a.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoBig),r=(0,a.iK)(t.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo),o=(t.shortName||"").split(" ").map(e=>e[0]).join("").toUpperCase().slice(0,2);return{playerEvent:t,imageUrl:i,teamImageUrl:r,fallbackIconText:o,cardSize:e.cardSize,isCopilotTheme:this.isCopilotTheme,telemetryTag:""}}async getMatches(e,t){let{spotlightData:i,telemetryObject:o,telemetryConstants:s,isHeroCard:l,isSpotlight2Card:n,followedSports:p=new Map}=e,{matchlist:d}=i||{};if(!d)return[];let c=(0,a.Yo)(d),g=d.map(async i=>{let d=i.sportsMatchData,g=(0,a.gK)(d.participantOne,p),m=(0,a.gK)(d.participantTwo,p),h={experienceName:e.experienceName,matchData:i,parentTelemetryObject:o,telemetryConstants:s,participantOneFollowed:g,participantTwoFollowed:m,isContainLiveMatch:c,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:l,isSpotlight2Card:n,isCopilotTheme:this.isCopilotTheme,useLargeTeamIcon:t,isMitUX:e.isMitUX};return this.transformerProvider.generateView(h,r.hi.SportsMatch)});return(await Promise.all(g)).filter(a.z2)}transformSportsSpotlightData(e,t,i=!1){let o,{statistics:l,video:d,match:c,poll:g,headerData:m,gameLeaders:h,playerEvent:y,sportsGcNav:u}=e,v=a.Zi,b=a.ZL,f=[];if(c){let e=(0,a.yn)(c.gameStartDateTime);c.gameDate=(0,a.AL)(e,s.T3.CurrentMarket),c.gameStartTime=(c.gameStartDateTimeIsToBeAnnounced?null:(0,a.ry)(e,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,c.gameStateCatetory="string"!=typeof c.gameState?(0,a.m5)(c.gameState.state):c.gameStateCatetory,"string"!=typeof c.gameState&&(c.gamePeriodAndClock=(0,a.PH)(c.gameState)),c.participantOne&&(c.participantOne.scheduleUrl=(0,a.Ot)(c.participantOne.gameCenterUrl)),c.participantTwo&&(c.participantTwo.scheduleUrl=(0,a.Ot)(c.participantTwo.gameCenterUrl)),c.gameCenterUrl&&(c.matchClickthroughUrl=(0,a.Ot)(c.gameCenterUrl)),c.participantOne.imageUrl=(0,a.iK)(c.participantOne.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),c.participantTwo.imageUrl=(0,a.iK)(c.participantTwo.imageId,!c.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),"string"==typeof c.gameState||c.gamePeriod||(c.gamePeriod=c.gameState.gamePeriod||c.gamePeriod),c.gameState=c.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:c.gameStateCatetory,this.adjustParticipantColors(c);let t=c.participantOne?.primaryColorHex===c.participantTwo?.primaryColorHex&&c.participantOne?.primaryColorHex?.toLowerCase()==="ffffff";!t&&c.participantOne?.primaryColorHex&&(v=(0,a.gS)(c.participantOne.primaryColorHex)),!t&&c.participantTwo?.primaryColorHex&&(b=(0,a.gS)(c.participantTwo.primaryColorHex)),c.matchClickthroughUrl?o=c.matchClickthroughUrl:c.gameCenterUrl&&(o=(0,a.Ot)(c.gameCenterUrl),c.matchClickthroughUrl=o),f.push({sportsMatchData:c})}let x=this.transformGameState(l,[v,b]),w=(!h||0===Object.keys(h).length)&&(!x||0===x.length)&&!d&&!g&&!y;if(!i&&(0===f.length||w||!o))return void(0,n.vV)(p.K0b,"Spotlight metadata missing",`market=${s.T3.CurrentMarket}`,e);if(d){let e=o??"";i&&(e=(0,a.Ot)(t)),d.msnVideoEmbedLink=(0,a._S)(d,e)}return{gameLeaders:h,matchlist:f,sportsGameStats:x,video:d,poll:g,matchClickthroughUrl:o||"",isSeasonStats:l&&l.season&&2===l.season.length,isGameStatsFull:!!l?.isFullCard,headerData:m,playerEvent:y,sportsGcNav:u}}transformGameState(e,t){if(!e||0===Object.keys(e).length)return;let i=[];e.season&&2===e.season.length?i=e.season:e.game&&2===e.game.length&&(i=e.game);let a=[];if(i[0]&&i[1]){let r=i[0],o=i[1];for(let i of e.statsKeyOrder||Object.keys(r)){let e=Number(r[i]),s=Number(o[i]),l=this.gameStatsFormatMap[i],n=this.formatGameStatsNumber(e,l),p=this.formatGameStatsNumber(s,l),d=this.calculatePercentNumbers(e,s),c={key:this.gameStatsLocKeyMap[i]||i,left:e,right:s,leftText:n,rightText:p,leftColor:t[0],rightColor:t[1],...d};a.push(c)}}return a}formatGameStatsNumber(e,t){if(!t)return e.toString();let i="";return(t.isPercent&&(i="%"),void 0!==t.toFix)?`${e.toFixed(t.toFix)}${i}`:t.isTime?this.secondsToMinutes(e):`${e}${i}`}secondsToMinutes(e){let t=Math.floor(e/60),i=Math.floor(e%60).toString().padStart(2,"0");return`${t}:${i}`}calculatePercentNumbers(e,t){let i=0,a=0,r=0;return 0!==e&&0!==t?(r=.7,i=e/(e+t)*99.3,a=t/(e+t)*99.3):0===e&&0===t?(i=0,a=0,r=0):0===e?(i=2.3,a=97,r=.7):0===t&&(i=97,a=2.3,r=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(a.toFixed(1)),gap:r}}adjustParticipantColors(e){if(!this.isCopilotTheme)return;let t=e.participantOne?.primaryColorHex.toLowerCase(),i=e.participantTwo?.primaryColorHex.toLowerCase(),r=this.isClashingColor(t),o=this.isClashingColor(i);r&&(e.participantOne.primaryColorHex=a.Zi),o&&(e.participantTwo.primaryColorHex=a.ZL)}isClashingColor(e){let t=(0,a.jJ)(),i=e.startsWith("#")?e.slice(1):e,r=parseInt(i.slice(0,2),16),o=parseInt(i.slice(2,4),16),s=parseInt(i.slice(4,6),16),l=r>200&&o>200&&s>200;return t?l||r<50&&o<50&&s<50:l}}},59682:function(e,t,i){i.d(t,{SportsGameStatsTransformer:function(){return a.O},SportsMatchTransformer:function(){return r.SportsMatchTransformer},SportsPickWinnerTransformer:function(){return o.$},SportsSpotlightTransformer:function(){return s.V}});var a=i(70512),r=i(82724),o=i(43207),s=i(34959);Promise.resolve().then(i.bind(i,94138)),Promise.resolve().then(i.bind(i,9038)),Promise.resolve().then(i.bind(i,4708)),Promise.resolve().then(i.bind(i,70846)),Promise.resolve().then(i.bind(i,811))},83546:function(e,t,i){i.d(t,{h:function(){return r}});var a=i(53128);function r(){return(0,a.oh)()}},46187:function(e,t,i){i.d(t,{WB:function(){return r},zv:function(){return a}});let a=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",bowling:"Bowling",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia",biathlon:"Biathlon",bobsledding:"Bobsledding",curling:"Curling",luge:"Luge",skating:"Skating",skiing:"Skiing",breaking:"Breaking"}),r=Object.freeze([a.football,a.basketball,a.baseball,a.cricket,a.soccer,a.icehockey])},57744:function(e,t,i){i.d(t,{UU:function(){return g},C9:function(){return v},OY:function(){return y},eU:function(){return u},Bk:function(){return h}});var a=i(54694),r=i(33744),o=i(25066),s=i(46187);let l=Object.freeze({sport:"sport",league:"league",team:"team",player:"player",flag:"flag",venue:"venue",background:"background",teaser:"teaser"});Object.freeze({[s.zv.baseball]:"OSB.26BE_Baseball.png",[s.zv.football]:"OSB.1F3C8_AmericanFootball.png",[s.zv.volleyballbeach]:"OSB.1F3D0_Volleyball.png",[s.zv.volleyballteam]:"OSB.1F3D0_Volleyball.png",[s.zv.tennis]:"OSB.Tennis.png",[s.zv.tabletennis]:"OSB.1F3DG_TableTennis.png",[s.zv.soccer]:"OSB.1F3D1_Soccer.png",[s.zv.rugbyleague]:"OSB.1F3C9_RugbyFootball.png",[s.zv.rugbyunion]:"OSB.1F3C9_RugbyFootball.png",[s.zv.golf]:"OSB.26F3_Golf.png",[s.zv.cricket]:"OSB.1F3CF_CricketGame.png",[s.zv.boxing]:"OSB.1F94A_Boxing.png",[s.zv.bowling]:"OSB.1F3B3_Bowling.png",[s.zv.basketball]:"OSB.1F3C0_Basketball.png",[s.zv.badminton]:"OSB.1F3F8_Badminton.png",[s.zv.icehockey]:"OSB.1F3D2_IceHockey.png"}),i(48566);var n=i(72627),p=i(50180),d=i(59010);let c="OSB.team_logo_placeholder.png",g=`${(0,r.rA)().StaticsUrl}/latest/sports/img/IPL/DefaultPlayerImage.svg`,m=`${(0,r.rA)().StaticsUrl}/latest/sports/img/flags/generic.svg`,h={width:28,height:28,enableDpiScaling:!0,devicePixelRatio:2,format:a.f5.PNG};function y(e,t,i,r=!0){var o,s;let n=e;if((0,p.oT)(n)){if(!r)return"";switch(i){case l.player:n=g;break;case l.team:n=c;break;case l.flag:n=m;break;default:n=c}}return(t.crop||(t.crop=0),t.padding||0===t.padding||(t.padding=1),n.indexOf(".")>0&&!n.startsWith("http"))?(0,a.oQ)(`${a.Ro}?id=${n}&pid=MSports`,t):(o=n,s=t,o.startsWith("http")?(0,a.oQ)(o,s):(0,a.XP)(o,s))}function u(e,t){let i;if(e||(e="sports/"),e.startsWith("/")||(e=`/${e}`),t)for(let i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e=e.replace(`{${i}}`,t[i]));let a=`${r.T3.NavTargetUrlWithLocale}${e}`;if(a=(0,o.wY)(a),"1"===(i=new d.m((0,n.iA)())).get("vptest")||"vp"===i.get("reqsrc")||0)return a;let s=new URL(a),l=new URLSearchParams((0,n.iA)()),p=l.getAll("item");p?.length&&p.forEach(e=>{e&&s.searchParams.append("item",e)});let c=l.getAll("src");c?.length&&c.forEach(e=>{e&&s.searchParams.append("src",e)});let g=l.get("uxmode");return g&&s.searchParams.append("uxmode",g),s.href}function v(e,t=[]){if(!e)return null;if(!t.length){if(!(0,p.oT)(e.name?.localizedName))return e.name.localizedName;if(!(0,p.oT)(e.name?.rawName))return e.name.rawName}for(let i of t)switch(i){case"FullName":if(!(0,p.oT)(e.name?.localizedName)||!(0,p.oT)(e.name?.rawName))return e.name.localizedName??e.name.rawName;break;case"ShortName":if(!(0,p.oT)(e.shortName?.localizedName))return e.shortName.localizedName;if(!(0,p.oT)(e.name?.localizedName))return e.name.localizedName;if(!(0,p.oT)(e.shortName?.rawName))return e.shortName.rawName;if(!(0,p.oT)(e.name?.rawName))return e.name.rawName;break;case"SchoolName":if(!(0,p.oT)(e.schoolName?.localizedName))return e.schoolName.localizedName;if(!(0,p.oT)(e.schoolName))return e.schoolName;break;case"Alias":if(!(0,p.oT)(e.alias?.localizedName))return e.alias.localizedName;if(!(0,p.oT)(e.alias))return e.alias;break;case"Abbreviation":if(!(0,p.oT)(e.abbreviation?.localizedName))return e.abbreviation.localizedName;if(!(0,p.oT)(e.abbreviation))return e.abbreviation}return null}},46763:function(e,t,i){let a;i.d(t,{Nx:function(){return a}})},14948:function(e,t,i){i.r(t),i.d(t,{SportsGameStatsTransformer:function(){return c.O},SportsPickWinnerTransformer:function(){return m.$},SportsSpotlightTransformer:function(){return h.V},SportsMatchTransformer:function(){return g.SportsMatchTransformer},SportsGameLeadersTransformer:function(){return d}});var a=i(67072),r=i(23305),o=i(79811),s=i(87906),l=i(40450);let n=Object.freeze({points:"PTSAbbr",goals:"GAbbr",assists:"AAbbr",saves:"SVAbbr",hits:"HAbbr",atBats:"ABAbbr",strikeOuts:"KAbbr",yards:"YDSAbbr",receptions:"RECAbbr",rebounds:"REBAbbr",attempts:"FGAAbbr",redCards:"RCAbbr",yellowCards:"YCAbbr",powerPlayGoals:"PPGAbbr",powerPlayAssists:"PPAAbbr",fieldGoalsPercentage:"FGPerAbbr",freeThrowsPercentage:"FTPerAbbr",turnovers:"TOAbbr",defensiveRebounds:"DREBAbbr",offensiveRebounds:"OREBAbbr",runsBattedIn:"RBIAbbr",cmpPercValue:"CMPAbbr",touchdowns:"TDAbbr",interceptions:"INTAbbr",rating:"RTGAbbr",longest:"LGAbbr"}),p=Object.freeze({points:"points",rebounds:"rebounds",assists:"assists",passingYards:"passing",rushingYards:"rushing",receivingYards:"receiving",hits:"hits",rbi:"RBI",strikeOuts:"strikeouts",goals:"goals",saves:"saves",cards:"cards"});class d extends r.Bc{async transform(e){try{return{viewModel:await this.getCurrentViewModel(e)}}catch(t){(0,s.vV)(l.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(e)}`,void 0)}}async getCurrentViewModel(e){if(!e)return(0,s.vV)(l.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(e)}`,void 0),null;let t=0;switch(e.cardSize){case a.uE._1x_1y:t=1;break;case a.uE._1x_2y:t=3;break;case a.uE._1x_3y:t=5;break;case a.uE._2x_2y:t=4}let i=this.transformSportsGameLeadersToVM(e.sportsGameLeaders,e.teamColors).slice(0,t),r=e.parentTelemetryObject.getMetadataTag();return{sportsGameLeaders:{categories:i},cardSize:e.cardSize,cardTitle:this.transformerProvider.strings.gameLeaders,telemetryTag:r}}transformSportsGameLeadersToVM(e,t){return e?.categoryKeyOrder&&e?.categories?e.categoryKeyOrder.map(i=>{let a=e.categories[i];if(!a)return(0,s.vV)(l.EfP,"GameLeaders category data is missing",`jsonData:${JSON.stringify(e)}`,void 0),null;let r=a.players.map(e=>{let i=a.statsKeyOrder.map(t=>({abbreviation:this.transformerProvider.strings[n[t]]||t.slice(0,3).toLocaleUpperCase(),title:t,value:Number(e.playerStats[t]).toFixed(0)||0}));return t[e.teamId]||(0,s.vV)(l.khl,"GameLeaders player team color is missing",`jsonData:${JSON.stringify(e)}`,void 0),{playerImage:(0,o.iK)(e.playerImage||o.UU,!e.playerImage,this.transformerProvider.config.teamImageInfoEnhanced),playerName:e.playerName,playerNumber:e.playerNumber,teamColor:t[e.teamId],playerStats:i}});return{categoryTitle:this.transformerProvider.strings[p[i]]||i.toLocaleUpperCase(),players:r}}).filter(e=>e):((0,s.vV)(l.EfP,"GameLeaders object is not valid",`jsonData:${JSON.stringify(e)}`,void 0),[])}}var c=i(70512),g=i(82724),m=i(43207),h=i(34959);Promise.resolve().then(i.bind(i,94138)),Promise.resolve().then(i.bind(i,9038)),Promise.resolve().then(i.bind(i,4708)),Promise.resolve().then(i.bind(i,70846)),Promise.resolve().then(i.bind(i,38584)),Promise.resolve().then(i.bind(i,811))},20517:function(e,t,i){i.d(t,{z:function(){return s}});var a=i(56911),r=i(92011),o=i(60815);class s extends r.L{}(0,a.Cg)([o.sH],s.prototype,"viewModel",void 0)},38584:function(e,t,i){i.r(t),i.d(t,{SportsGameLeaders:function(){return eq}});var a=i(56911),r=i(20517);class o extends r.z{}var s=i(92011),l=i(61138),n=i(63033),p=i(59669);let d=(0,p.A)` :host{--secondary-font-color:#999999}`,c=(0,p.A)` :host{--secondary-font-color:#707070}`,g=(0,p.A)` :host{display:inline-block;width:100%}.game-leaders{display:grid;gap:12px}.category-row{display:grid;justify-items:center;gap:4px}.category-title{font-size:${l.k};line-height:${l.F};font-weight:400;color:var(--secondary-font-color)}.player-cards{width:100%;display:grid;grid-template-columns:1fr 1fr}`.withBehaviors(new n.N(c,d));var m=i(89757),h=i(68835),y=i(69259),u=i(60815),v=i(9960);let b=Object.freeze({default:"default",lite:"lite"}),f=Object.freeze({Stack:"stack",SideBySide:"side-by-side"});class x extends s.L{constructor(){super(),this.type=b.default,this.name="",this.fullName="",this.nameDetail="",this.description="",this.image="",this.isDarkMode=(0,v.ud)(),this.playerInfoRenderMode=f.Stack,this.isRuby=!1,this.isCopilot=!1,this.isMai=!1,this.imageClickHandler=()=>{this.redirectLink&&open(this.redirectLink,"_blank")},this.colorSchemeChangeHandler=this.colorSchemeChangeHandler.bind(this)}connectedCallback(){super.connectedCallback();let e=window.matchMedia("(prefers-color-scheme: dark)");e.addEventListener&&e.addEventListener("change",this.colorSchemeChangeHandler)}disconnectedCallback(){super.disconnectedCallback(),window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change",this.colorSchemeChangeHandler)}colorSchemeChangeHandler(){this.isDarkMode=(0,v.ud)()}get playerNameInitials(){if(!this.name||!this.name.trim())return"";let e=this.name.trim().split(/\s+/);if(e.length<2)return this.name.charAt(0);let t=e[0],i=e[1];return`${t.charAt(0)}${i.charAt(0)}`}get playerNameAndNameDetailsCombined(){return[this.name,this.nameDetail].filter(Boolean).join(" ")}}(0,a.Cg)([u.sH],x.prototype,"type",void 0),(0,a.Cg)([u.sH],x.prototype,"name",void 0),(0,a.Cg)([u.sH],x.prototype,"fullName",void 0),(0,a.Cg)([u.sH],x.prototype,"nameDetail",void 0),(0,a.Cg)([u.sH],x.prototype,"playerNumber",void 0),(0,a.Cg)([u.sH],x.prototype,"description",void 0),(0,a.Cg)([u.sH],x.prototype,"image",void 0),(0,a.Cg)([u.sH],x.prototype,"teamColor",void 0),(0,a.Cg)([u.sH],x.prototype,"teamImage",void 0),(0,a.Cg)([u.sH],x.prototype,"injuryInfo",void 0),(0,a.Cg)([u.sH],x.prototype,"statistics",void 0),(0,a.Cg)([u.sH],x.prototype,"statisticsLabel",void 0),(0,a.Cg)([u.sH],x.prototype,"isDarkMode",void 0),(0,a.Cg)([u.sH],x.prototype,"playerInfoRenderMode",void 0),(0,a.Cg)([u.sH],x.prototype,"redirectLink",void 0),(0,a.Cg)([u.sH],x.prototype,"isPlayerImageAvailable",void 0),(0,a.Cg)([u.sH],x.prototype,"columnLayout",void 0),(0,a.Cg)([u.sH],x.prototype,"isRuby",void 0),(0,a.Cg)([u.sH],x.prototype,"isCopilot",void 0),(0,a.Cg)([u.sH],x.prototype,"isMai",void 0);var w=i(49417),$=i(41123),k=i(63129),C=i(62047),z=i(83252),M=i(69809),T=i(89580),S=i(6032),F=i(22131),P=i(97747);P.G.create("cricket-win-color"),P.G.create("copilot-header-color"),P.G.create("ruby-border-radius"),P.G.create("copilot-container-fill-color"),P.G.create("sp-container-1-col-width"),P.G.create("sp-container-mobile-width"),P.G.create("sp-container-flyout-width"),P.G.create("sp-container-2-col-width"),P.G.create("sp-container-3-col-width"),P.G.create("sp-container-4-col-width"),P.G.create("sp-page-min-width"),P.G.create("sp-container-padding"),P.G.create("sp-container-one-col-padding"),P.G.create("sp-container-mobile-padding"),P.G.create("sp-container-margin"),P.G.create("sp-container-one-col-margin"),P.G.create("sp-container-mobile-margin"),P.G.create("sp-container-corner-radius"),P.G.create("sp-container-one-col-corner-radius"),P.G.create("sp-content-row-gap"),P.G.create("sp-content-row-gap-one-col"),P.G.create("sp-content-row-gap-mobile"),P.G.create("sp-content-column-gap"),P.G.create("sp-content-column-gap-one-col"),P.G.create("sp-content-column-gap-mobile"),P.G.create("sp-vertical-container-margin-bottom"),P.G.create("sp-vertical-container-margin-bottom-one-col"),P.G.create("sp-vertical-container-margin-bottom-mobile"),P.G.create("sp-container-title-margin"),P.G.create("sp-container-title-one-col-margin"),P.G.create("sp-container-title-mobile-margin"),P.G.create("sp-scroll-proxy-container-margin"),P.G.create("sp-scroll-proxy-container-one-col-margin"),P.G.create("sp-scores-schedule-container-padding"),P.G.create("sp-scores-schedule-container-one-col-padding"),P.G.create("sp-scores-schedule-container-mobile-padding"),P.G.create("sp-game-summary-container-padding"),P.G.create("sp-game-summary-container-one-col-padding"),P.G.create("sp-game-summary-container-mobile-padding"),P.G.create("sp-cricket-rankings-container-header-padding"),P.G.create("sp-cricket-rankings-container-header-one-col-padding"),P.G.create("sp-cricket-rankings-container-header-mobile-padding");let G=P.G.create("sp-text-base-font-size");P.G.create("sp-text-minus-1-font-size"),P.G.create("sp-text-minus-2-font-size"),P.G.create("sp-text-minus-3-font-size");let A=P.G.create("sp-text-plus-1-font-size");P.G.create("sp-text-plus-2-font-size"),P.G.create("sp-text-plus-3-font-size"),P.G.create("sp-text-plus-4-font-size"),P.G.create("sp-text-plus-5-font-size"),P.G.create("sp-text-minus-1-line-height"),P.G.create("sp-text-minus-2-line-height"),P.G.create("sp-text-minus-3-line-height");let N=P.G.create("sp-text-base-line-height");P.G.create("sp-text-plus-1-line-height"),P.G.create("sp-text-plus-2-line-height");let V=P.G.create("sp-font-color"),E=P.G.create("sp-font-color-sub");P.G.create("sp-cr-font-color-sub"),P.G.create("sp-mai-background-color"),P.G.create("section-header-color"),P.G.create("sp-cr-top-border-color"),P.G.create("sp-cr-live-color-lll"),P.G.create("sp-cr-live-color-ll"),P.G.create("sp-cr-live-color-l"),P.G.create("sp-cr-live-color"),P.G.create("sp-cr-delayed-color"),P.G.create("sp-copilot-divider-color"),P.G.create("sp-copilot-divider-border"),P.G.create("sp-tab-hover-background-color"),P.G.create("sp-tab-pressed-background-color"),P.G.create("sp-tab-pressed-font-color"),P.G.create("sp-button-hover-background-color"),P.G.create("sp-button-pressed-background-color"),P.G.create("sp-button-pressed-font-color"),P.G.create("sp-button-second-hover-background-color"),P.G.create("sp-button-second-pressed-background-color"),P.G.create("sp-button-second-pressed-font-color");let q=(0,p.A)`
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        white-space: nowrap;
        border-width: 0;
        clip-path: inset(100%);
    }

    .ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @supports (-webkit-line-clamp: 2) {
        .ellipsis.with-2-lines {
            white-space: normal;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    }
`,_=(0,p.A)` :host{--ruby-player-round-bg:rgba(255,255,255,5%);--ruby-player-team-shadow:#000000;--ruby-player-team-bg:#F6F9FC;--ruby-player-name-color:#FFFFFF;--ruby-stat-val-color:#FFFFFF;--ruby-player-desc-color:${E};--ruby-lite-round-bg:rgba(255,255,255,0.05);--ruby-copilot-lite-round-bg:rgba(157,168,217,0.05);--player-initials-bg:#6D585B;--player-initials-color:#F2DDCC}`,B=(0,p.A)` :host{--ruby-player-round-bg:rgba(0,0,0,5%);--ruby-player-team-shadow:#FFFFFF;--ruby-player-team-bg:#23272B;--ruby-player-name-color:#23272B;--ruby-stat-val-color:#23272B;--ruby-player-desc-color:${E};--ruby-lite-round-bg:rgba(0,0,0,0.05);--ruby-copilot-lite-round-bg:rgba(204,196,192,0.2);--player-initials-bg:#FFD79C;--player-initials-color:#33302E}`,D=(0,p.A)` .ruby .player-desc-wrapper .player-desc,.sports-player-card.lite.ruby.copilot .player-info .player-name{forced-color-adjust:auto}`,I=(0,p.A)` ${q} :host{display:inline-block;width:100%;border-bottom:1px solid ${w.hb}}.sports-player-card{object-fit:cover;width:100%;height:100%}.ruby.sports-player-card{column-gap:16px}.ruby.copilot.sports-player-card{column-gap:12px}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-info,.injury-info,.player-stat{flex-direction:column}.sports-player-card{display:flex;align-items:flex-start}.sports-player-card.lite{display:flex;align-items:center}.sports-player-card.lite .player-image{align-items:center}.sports-player-card .player-image{display:flex;flex-direction:row;height:100%}.sports-player-card .player-image .player-image-info{display:flex;flex-direction:column;justify-content:space-between;align-items:center}.player-image .player-image-info .player-info-team{height:${$.Z};width:${$.Z}}.player-image .player-image-info .player-info-number{font-size:${l.k};line-height:${l.F};color:${k.ls}}.player-image .player-image-info .player-info-number-small{font-size:${C.t};line-height:${C.e}}.sports-player-card .player-image .player-round-image{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${z.X4};overflow:hidden}.sports-player-card .player-image .player-round-image-clickable{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${z.X4};overflow:hidden;cursor:pointer}.sports-player-card .player-image .player-round-image,.sports-player-card .player-image .player-round-image-clickable{width:65px;height:65px}.sports-player-card.lite .player-image .player-round-image,.sports-player-card.lite .player-image .player-round-image-clickable{width:36px;height:36px}.sports-player-card .player-image .player-icon{height:100%;width:100%}.sports-player-card .player-image .player-image-link{width:100%;position:absolute;bottom:0;display:flex;justify-content:center;align-items:center;background:rgba(0,0,0,0.44);backdrop-filter:blur(1px)}.player-image-link image{fill:${M.m_}}.player-info{width:60%;flex-direction:column;padding:5px 15px 0 15px}.sports-player-card.lite .player-info{padding:5px}.player-info .player-name{font-size:${$.K};line-height:${$.Z};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.ruby .player-info .player-name{font-size:${T.Y};line-height:24px;font-weight:550;color:var(--ruby-player-name-color)}.sports-player-card.lite.ruby .player-info .player-name{font-size:${$.K}}.sports-player-card.lite.ruby.copilot .player-info .player-name{font-size:${G};line-height:${N};font-weight:410;color:${V};direction:ltr}.player-info .player-name .name-detail{font-weight:400;color:${S.c}}.sports-player-card .player-info{width:100%;min-width:0;flex-direction:column;display:flex;align-items:flex-start;padding:0 12px}.ruby.sports-player-card .player-info{width:unset;flex-grow:1;padding:0}.ruby.copilot.sports-player-card .player-info{width:calc(100% - 48px);align-items:unset;gap:2px}.sports-player-card .player-info .player-stats{width:100%;display:flex;justify-content:space-between;text-align:center}.sports-player-card .player-info .player-stats .player-stat{display:flex;flex-direction:column;align-items:flex-start}.sports-player-card.lite .player-info .player-name{font-size:${$.K}}.player-info .player-desc{font-size:${C.t};line-height:${C.e};color:${k.ls};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.injury-info,.player-stats{line-height:${$.Z};font-size:${$.K}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${T.Y};height:${T.Y};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-between;text-align:center}.stat-val,.injury-status{font-weight:600;font-size:${$.K};line-height:${$.Z}}.stat-title{font-size:${l.k};line-height:${l.F};color:${k.ls}}.ruby.sports-player-card{align-items:center}.ruby-player-image{position:relative;width:80px;height:80px}.layout-1 .ruby-player-image{width:60px;height:60px}.ruby-player-image.only-team-image,.layout-1 .ruby-player-image.only-team-image{align-self:flex-start;width:24px;height:24px}.ruby-player-round-image{width:100%;height:100%;background-color:var(--ruby-player-round-bg);border-radius:50%}.ruby-player-team-image{position:absolute;right:2px;bottom:2px;width:24px;height:24px;box-shadow:0 0 0 2px var(--ruby-player-team-shadow);background-color:var(--ruby-player-team-bg);border-radius:50%}.layout-1 .ruby-player-team-image{width:20px;height:20px}.player-desc-wrapper{display:flex;max-width:100%}.ruby .player-desc-wrapper{gap:8px}.ruby .player-desc-wrapper .player-info-number{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z};color:var(--ruby-player-desc-color)}.ruby.lite.copilot .player-desc-wrapper .player-desc{font-size:${$.K};line-height:${$.Z}}.ruby .player-stats{margin-top:8px}.layout-1.ruby .player-stats{margin-top:4px}.ruby .player-stat{flex:1 1 0}.ruby .player-stat:last-child{flex:0 1 42px}.ruby.layout-2 .player-stat:last-child{flex:1 1 0}.ruby .stat-val{font-size:${T.Y};line-height:24px;font-weight:550;color:var(--ruby-stat-val-color)}.ruby .stat-title{font-weight:550;color:var(--ruby-player-desc-color)}.layout-4.ruby .stat-title{font-size:${$.K};line-height:${$.Z}}.ruby.lite.layout-4 .player-info .player-name{font-size:${T.Y};line-height:${T.v}}.ruby.lite.layout-4 .player-info .player-desc-wrapper{font-size:${$.K};line-height:${$.Z}}.ruby.lite .player-image .player-round-image,.ruby.lite .player-image .player-round-image-clickable{background:var(--ruby-lite-round-bg)}.ruby.copilot.lite .player-image .player-round-image,.ruby.copilot.lite .player-image .player-round-image-clickable{background:var(--ruby-copilot-lite-round-bg)}.ruby.lite.layout-4 .player-image .player-round-image,.ruby.lite.layout-4 .player-image .player-round-image-clickable{height:40px;width:40px}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--background-color,--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${A};line-height:${N};font-weight:400;letter-spacing:-0.01em;color:var(--font-color,--player-initials-color)}.layout-1 .player-initials > span{font-size:${G}}`.withBehaviors(new n.N(B,_),(0,F.mr)(D)),j=(0,m.qy)`
    <div class="injury-info">
        <span class="injury-status">
            ${(0,y.z)(e=>e.injuryInfo?.statusIconColor,(0,m.qy)`
                <i class="status-icon" style="background: ${e=>e.isDarkMode?e.injuryInfo?.statusIconColor?.dark:e.injuryInfo?.statusIconColor?.primary}"></i>
            `)}
            <span class="status-text" title="${e=>e.injuryInfo?.status}">
                ${e=>e.injuryInfo?.status}
            </span>
        </span>
        ${(0,y.z)(e=>e.injuryInfo?.injuryArea,(0,m.qy)`
            <span class="injury-area">${e=>e.injuryInfo?.injuryArea}</span>
        `)}
    </div>
`;var O=i(33744),U=i(57744);let L=`${(0,O.rA)().StaticsUrl}/latest/sports/icons/SportsImageExplorer.svg`,H=(0,m.qy)`
    <div class="player-stats">
        ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
            <div class="player-stat">
                <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                ${(0,y.z)(e=>!!e.abbreviation,(0,m.qy)`
                    <span class="stat-title" title="${e=>e.title}">${e=>e.abbreviation}</span>
                `)}
            </div>
        `)}
    </div>
`,R=(0,m.qy)`
    <div class="player-image">
        ${(0,y.z)(e=>e.type===b.default,(0,m.qy)`
            <div class="player-image-info">
                ${(0,y.z)(e=>e.teamImage,(0,m.qy)`
                    <img class="player-info-team" loading="lazy" role="presentation" src="${e=>e.teamImage||" "}" />
                `)}
                ${(0,y.z)(e=>e.playerNumber,(0,m.qy)`
                    <span class="${e=>e.isPlayerImageAvailable?"player-info-number":"player-info-number-small"}">
                        #${e=>e.playerNumber}
                    </span>
                `)}
            </div>
        `)}
        ${(0,y.z)(e=>e.isPlayerImageAvailable,(0,m.qy)`
            <div 
                class="${e=>e.redirectLink?"player-round-image-clickable":"player-round-image"}" 
                @click=${e=>e.imageClickHandler()}
            >
                ${(0,y.z)(e=>e.image&&""!==e.image,(0,m.qy)`
                    <img class="player-icon" loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}" />
                `,(0,m.qy)`
                    <span class="sr-only">${e=>e.fullName||e.name}</span>
                    <div
                        class="player-initials"
                        title=${e=>e.fullName||e.name}
                        aria-hidden="true"
                    >
                        <span>${e=>e.playerNameInitials}</span>
                    </div>
                `)}
                ${(0,y.z)(e=>e.redirectLink,(0,m.qy)`
                    <div class="player-image-link">
                        <img src=${L} alt="sportsImageExplorerIcon" loading="lazy" aria-hidden="true" />
                    </div>
                `)}
            </div>
        `)}
    </div>
`,K=(0,m.qy)`
    <img class="ruby-player-round-image" loading="lazy" src=${e=>(0,U.OY)(U.UU,U.Bk)} alt=${e=>e.fullName||e.name} />
`,W=(0,m.qy)`
    ${(0,y.z)(e=>e.isPlayerImageAvailable,(0,m.qy)`
        <div class="ruby-player-image" @click=${e=>e.imageClickHandler()}>
            <img class="ruby-player-round-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
            ${(0,y.z)(e=>e.teamImage,(0,m.qy)`
                <img class="ruby-player-team-image" loading="lazy" role="presentation" src=${e=>e.teamImage} />
            `)}
        </div>
    `,(0,m.qy)`
        ${(0,y.z)(e=>e.teamImage,(0,m.qy)`
            <div class="ruby-player-image only-team-image" @click=${e=>e.imageClickHandler()}>
                <img class="ruby-player-round-image" loading="lazy" src=${e=>e.teamImage} alt=${e=>e.fullName||e.name} />
            </div>
        `,K)}
    `)}
`,Y=(0,m.qy)`
    <div class="sports-player-card ${e=>e.type} ${e=>e.columnLayout?`layout-${e.columnLayout}`:""} ${e=>e.isRuby?"ruby":""} ${e=>e.isCopilot?"copilot":""}">
        ${(0,y.z)(e=>e.isRuby&&e.type!==b.lite,W,R)}
        <div class="player-info">
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <span
                class="player-name"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                ${e=>e.name}
                <span class="name-detail"> ${e=>e.nameDetail}</span>
            </span>
            <div class="player-desc-wrapper">
                ${(0,y.z)(e=>e.playerNumber&&e.isRuby,(0,m.qy)`<span class="player-info-number">#${e=>e.playerNumber}</span>`)}
                <span class="player-desc">${e=>e.description}</span>
            </div>
            ${(0,y.z)(e=>e.injuryInfo,j)}
            ${(0,y.z)(e=>e.statistics?.length,H)}
        </div>
    </div>
`;var Z=i(33113);let X=(0,p.A)` ${q} :host{display:inline-block;width:100%}.sports-player-card{object-fit:cover;width:100%;height:100%;flex-direction:column;align-items:center}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-stats{flex-direction:row}.player-info,.injury-info,.player-stat{flex-direction:column}.player-stat{margin-inline-start:6px}.player-image{padding-bottom:5px;position:relative}.sports-player-card.grid-card .player-image{padding-bottom:0;align-items:center}.player-image img{width:40px;height:40px;border-radius:50px;border:1px solid ${Z.I2}}.sports-player-card.grid-card .player-image img{width:36px;height:36px;border-radius:50%;background:unset;border:1px solid ${z.X4}}.player-image{bottom:5px;border-end-start-radius:5px;padding:2px 0}.player-info{width:60%;flex-direction:column;align-items:center}.player-info-text-content{flex-direction:column;align-items:center;display:flex}.sports-player-card.grid-card .player-info{padding:5px}.player-info .player-name{font-size:${l.k};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center}.player-desc{overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center;white-space:nowrap}.player-info .player-desc{font-size:${C.t};line-height:${C.e}}.injury-info,.player-stats{line-height:${C.e};font-size:${C.t}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${C.t};height:${C.e};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-around;text-align:center;width:100px}.stat-val,.injury-status{font-weight:600;font-size:${l.k}}.stat-title,.player-desc{color:${k.ls}}.sports-player-card.side-by-side{flex-direction:row}.sports-player-card.side-by-side .player-info{flex-direction:row;width:100%}.sports-player-card.side-by-side .player-info .player-info-text-content{margin-inline-start:10px}.sports-player-card.side-by-side .player-info .player-name{text-align:unset}.sports-player-card.side-by-side .player-image{bottom:unset}.sports-player-card.side-by-side .player-info .player-name{text-align:unset;width:150px}.sports-player-card.side-by-side .player-desc{text-align:unset;width:150px}.sports-player-card.side-by-side .injury-status .status-icon{height:7px;width:7px}.sports-player-card.side-by-side .injury-status .injury-info{padding-inline-start:10px}`.withBehaviors(),J=(0,m.qy)`
    <div class="player-stats">
        ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
            ${(0,y.z)(e=>!!e.abbreviation,(0,m.qy)`
                <div class="player-stat">
                    <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                    <span class="stat-title" title="${e=>e.title??e.abbreviation}">${e=>e.abbreviation}</span>
                </div>
            `)}
        `)}
    </div>
`,Q=(0,m.qy)`
    <div class="sports-player-card ${e=>e.type} ${e=>e.playerInfoRenderMode==f.SideBySide?"side-by-side":""}">
        <div class="player-image">
            <img loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}">
        </div>
        <div class="player-info">
            <div class="player-info-text-content">
                <span class="sr-only">${e=>e.fullName||e.name}</span>
                <span class="player-name" title="${e=>e.fullName||e.name}" aria-hidden="true">${e=>e.name}</span>
                <span class="player-desc">${e=>e.description+" "}
                    <span> ${e=>void 0==e.playerNumber?"":"#"+e.playerNumber}</span>
                </span>
            </div>
            ${(0,y.z)(e=>e.injuryInfo,j)}
            ${(0,y.z)(e=>e.statistics?.length,J)}
        </div>
    </div>
`,ee=(0,p.A)` :host{--secondary-font-color:#999999;--image-border-color:#666666}`,et=(0,p.A)` :host{--secondary-font-color:#707070;--image-border-color:#D1D1D1}`,ei=(0,p.A)` ${q} :host{display:inline-block;width:100%;min-width:0}.sports-player-card{display:grid;grid-template-columns:max-content auto;align-items:center;gap:6px}.player-round-image{object-fit:cover;border-radius:50%;overflow:hidden}.image-border{border:1px solid var(--image-border-color)}.player-icon{width:36px;height:36px;display:block}.player-info{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-width:0}.player-name{font-weight:600;text-align:left;max-width:96px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:20px;font-size:${$.K};line-height:${$.Z};max-width:100%}.player-stats{display:flex;flex-wrap:nowrap;font-size:12px;height:20px;gap:2px;display:flex;align-items:center}.player-stats-vals{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.player-stats-titles{display:flex;flex-wrap:nowrap;font-size:${$.K};line-height:${$.Z}}.stat-val{font-weight:600}.stat-title{font-weight:400;color:var(--secondary-font-color)}`.withBehaviors(new n.N(et,ee)),ea=(0,m.qy)`
    <div class="player-stats">
        <div class="player-stats-vals">
            ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
                <span class="stat-val">${e=>void 0===e.value?"-":e.value}</span>
                ${(0,y.z)((e,t)=>!t.isLast,(0,m.qy)`-`)}
            `,{positioning:!0})}
        </div>
        <div class="player-stats-titles">
            ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
                ${(0,y.z)(e=>!!e.abbreviation,(0,m.qy)`
                    <span class="stat-title" title="${e=>e.title}">${e=>e.abbreviation}</span>
                `)}
                ${(0,y.z)((e,t)=>!t.isLast,(0,m.qy)`<span class="stat-title">-</span>`)}        
            `,{positioning:!0})}
        </div>
    </div>
`,er=(0,m.qy)`
<div class="sports-player-card ${e=>e.type}">
    ${(0,y.z)(e=>e.isPlayerImageAvailable,(0,m.qy)`
        <div class="player-round-image ${e=>e.teamColor?"image-border":""}" style="background-color:${e=>e.teamColor};">
            <img class="player-icon" loading="lazy" src=${e=>e.image} alt="${e=>e.fullName||e.name}">
        </div>
    `)}
    <div class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span class="player-name" title="${e=>e.fullName||e.name}" aria-hidden="true">
            ${e=>e.name}
        </span>
        ${(0,y.z)(e=>e.statistics?.length,ea)}
    </div>
</div>
`;var eo=i(37079),es=i(62198),el=i(32257);let en=(0,p.A)` .player-image,.player-stats{background-color:#9DA8D90D}.player-initials{background-color:#6D585B}.team-logo{box-shadow:0 0 0 2px #282F42;background-color:#282F42}`,ep=(0,p.A)` .player-image,.player-stats{background-color:#CCC4C033}.player-initials{background-color:#FFD79C}.team-logo{box-shadow:0 0 0 2px #F4EFED;background-color:#F4EFED}`,ed=(0,p.A)` ${q} .sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;flex-direction:column;align-items:center;width:100%;row-gap:12px;text-align:center}.layout-1.sports-player-card{row-gap:8px}.player-image-container{position:relative;width:90px;height:90px}.player-image{width:100%;height:100%;border-radius:50%}.mai .player-image{background-color:${el.GEK}}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:50%}.player-initials > span{font-size:${eo.F};line-height:${es.b};font-weight:400;letter-spacing:-0.01em;color:${V}}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;border-radius:50%}.mai .team-logo{box-shadow:0 0 0 2px ${el.GEK};background-color:${el.GEK}}.player-info{display:flex;flex-direction:column;align-items:center;width:100%;padding-inline:4px}.player-name{width:100%;font-size:15px;line-height:${$.Z};font-weight:700;color:${V};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{width:100%;font-size:${l.k};line-height:${l.F};font-weight:650;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px}.mai .player-stats{border-radius:${el.g6L};background-color:${el.GEK}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${V};white-space:nowrap}.stat-title{display:block;font-size:${C.t};line-height:${C.e};font-weight:700;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new n.N(ep,en));var ec=i(46763),eg=i(46187);let em=(0,m.qy)`
    <div class="player-image-container">
        ${(0,y.z)(e=>e.isPlayerImageAvailable&&e.image&&!e.redirectLink,(0,m.qy)`
            <img class="player-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
        `,(0,m.qy)`
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <div
                class="player-initials"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                <span>${e=>e.playerNameInitials}</span>
            </div>
        `)}
        ${(0,y.z)(e=>e.teamImage,(0,m.qy)`
            <img class="team-logo" loading="lazy" role="presentation" src=${e=>e.teamImage} alt="" />
        `)}
    </div>
`,eh=(0,m.qy)`
    <header class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span
            id=${e=>`header-${e.id}`}
            class="player-name"
            title=${e=>e.fullName||e.name}
            aria-hidden="true"
        >
            ${e=>e.name}
        </span>
        <span class="player-description">
            ${e=>e.playerNumber?`#${e.playerNumber} ${e.description}`:`${e.description}`}
        </span>
    </header>
`,ey=(0,m.qy)`
    ${(0,y.z)(e=>e.abbreviation&&e.abbreviation.trim(),(0,m.qy)`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${e=>`${e.value} ${e.title}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${e=>e.value}
            </span>
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        </div>
    `)}
`,eu=(0,m.qy)`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${e=>`${e.value} ${e.title}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${e=>e.value}
        </span>
        ${(0,y.z)(e=>e.abbreviation,(0,m.qy)`
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        `)}
    </div>
`,ev=(0,m.qy)`
    <div class="sports-player-card ${e=>e.isMai?"mai":""} layout-${e=>e.columnLayout}" role="article" aria-labelledby=${e=>e.id?`header-${e.id}`:""}>
        ${em}
        ${eh}
        <div class="player-stats" role="list" aria-label=${e=>e.statisticsLabel||""}>
            ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
                ${(0,y.z)(e=>ec.Nx?.Sport===eg.zv.soccer,ey,eu)}
            `)}
        </div>
    </div>
`;var eb=i(25975);let ef=(0,p.A)` :host{--player-initials-bg:#6D585B}`,ex=(0,p.A)` :host{--player-initials-bg:#FFD79C}`,ew=(0,p.A)` ${q} :host{--player-image-bg:${el.GEK};--player-stats-bg:${el.GEK};--player-initials-color:${V};--team-logo-shadow:${el.GEK};--team-logo-bg:${el.GEK}}.sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;align-items:flex-start;width:100%;gap:12px}.layout-1.sports-player-card{gap:8px}.player-content{flex:1;min-width:0;display:flex;flex-direction:column;gap:12px}.layout-1 .player-content{gap:8px}.player-image-container{position:relative;flex:0 0 80px;width:80px;height:80px}.player-image{width:100%;height:100%;background-color:var(--player-image-bg);border-radius:50%}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${eo.F};line-height:${es.b};font-weight:400;letter-spacing:-0.01em;color:var(--player-initials-color)}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;box-shadow:0 0 0 2px var(--team-logo-shadow);background-color:var(--team-logo-bg);border-radius:50%}.player-info{display:flex;flex-direction:row;align-items:center;justify-content:space-between;width:100%;gap:4px}.player-name{flex:0 0 auto;min-width:0;max-width:75%;font-size:15px;line-height:${$.Z};font-weight:700;color:${V};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr}.player-description{flex:1 1 auto;min-width:0;font-size:${l.k};line-height:${l.F};font-weight:650;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px;background-color:var(--player-stats-bg)}@supports (corner-shape:squircle){.player-stats{border-radius:calc(12px * ${eb.MU6});corner-shape:squircle}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};line-height:${$.Z};font-weight:650;color:${V};white-space:nowrap}.stat-title{display:block;font-size:${C.t};line-height:${C.e};font-weight:700;color:${E};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new n.N(ex,ef)),e$=(0,m.qy)`
    <div class="player-image-container">
        ${(0,y.z)(e=>e.isPlayerImageAvailable&&e.image&&!e.redirectLink,(0,m.qy)`
            <img class="player-image" loading="lazy" src=${e=>e.image} alt=${e=>e.fullName||e.name} />
        `,(0,m.qy)`
            <span class="sr-only">${e=>e.fullName||e.name}</span>
            <div
                class="player-initials"
                title=${e=>e.fullName||e.name}
                aria-hidden="true"
            >
                <span>${e=>e.playerNameInitials}</span>
            </div>
        `)}
        ${(0,y.z)(e=>e.teamImage,(0,m.qy)`
            <img class="team-logo" loading="lazy" role="presentation" src=${e=>e.teamImage} alt="" />
        `)}
    </div>
`,ek=(0,m.qy)`
    <header class="player-info">
        <span class="sr-only">${e=>e.fullName||e.name}</span>
        <span
            id=${e=>`header-${e.id}`}
            class="player-name"
            title=${e=>e.fullName||e.name}
            aria-hidden="true"
        >
            ${e=>e.name}
        </span>
        <span class="player-description">
            ${e=>e.playerNumber?`#${e.playerNumber} ${e.description}`:`${e.description}`}
        </span>
    </header>
`,eC=(0,m.qy)`
    ${(0,y.z)(e=>e.abbreviation&&e.abbreviation.trim(),(0,m.qy)`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${e=>e.title?`${e.value} ${e.title}`:`${e.value}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${e=>e.value}
            </span>
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        </div>
    `)}
`,ez=(0,m.qy)`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${e=>e.title?`${e.value} ${e.title}`:`${e.value}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${e=>e.value}
        </span>
        ${(0,y.z)(e=>e.abbreviation,(0,m.qy)`
            <span class="stat-title" title=${e=>e.title} aria-hidden="true">
                ${e=>e.abbreviation}
            </span>
        `)}
    </div>
`,eM=(0,m.qy)`
    <div class="sports-player-card layout-${e=>e.columnLayout}" role="article" aria-labelledby=${e=>e.id?`header-${e.id}`:""}>
        ${e$}
        <div class="player-content">
            ${ek}
            <div class="player-stats" role="list" aria-label=${e=>e.statisticsLabel||""}>
                ${(0,h.ux)(e=>e.statistics,(0,m.qy)`
                    ${(0,y.z)(e=>ec.Nx?.Sport===eg.zv.soccer,eC,ez)}
                `)}
            </div>
        </div>
    </div>
`,eT=class extends x{};eT=(0,a.Cg)([(0,s.E)({name:"sports-player-card",template:Y,styles:I})],eT);let eS=class extends x{};eS=(0,a.Cg)([(0,s.E)({name:"sports-player-card-v2",template:Q,styles:X})],eS);let eF=class extends x{};eF=(0,a.Cg)([(0,s.E)({name:"sports-player-card-v3",template:er,styles:ei})],eF);let eP=class extends x{};eP=(0,a.Cg)([(0,s.E)({name:"sports-player-card-copilot",template:ev,styles:ed})],eP);let eG=class extends x{};eG=(0,a.Cg)([(0,s.E)({name:"sports-player-card-mai",template:eM,styles:ew})],eG);let eA=(0,m.qy)`
    <sports-player-card-v3
        class="player-card"
        :type=${e=>b.default}
        :name=${e=>e.playerName}
        :playerNumber=${e=>e.playerNumber}
        :image=${e=>e.playerImage}
        :teamColor=${e=>e.teamColor}
        :teamImage=${e=>e.playerImage}
        :isPlayerImageAvailable=${e=>e.playerImage}
        :statistics=${e=>e.playerStats}>
    </sports-player-card-v3>
`,eN=(0,m.qy)`
    <div class="category-row">
        <div class="category-title">
            ${e=>e.categoryTitle}
        </div>
        <div class="player-cards">
            ${(0,h.ux)(e=>e.players,eA)}
        </div>
    </div>
`,eV=(0,m.qy)`
    <div class="game-leaders">
        ${(0,h.ux)(e=>e.viewModel.sportsGameLeaders.categories,eN,{positioning:!0})}
    </div>
`,eE=(0,m.qy)`
    ${(0,y.z)(e=>void 0!=e.viewModel,eV)}
`,eq=class extends o{};eq=(0,a.Cg)([(0,s.E)({name:"sports-game-leaders",template:eE,styles:g,shadowOptions:{delegatesFocus:!0}})],eq)},9038:function(e,t,i){i.r(t),i.d(t,{SportsGameStats:function(){return G}});var a=i(56911),r=i(20517),o=i(83546),s=i(60815);class l extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,o.h)()}viewModelChanged(){this.isMitUx=this.viewModel?.isMitUX===!0}}(0,a.Cg)([s.sH],l.prototype,"isMitUx",void 0);var n=i(92011),p=i(86856),d=i(63033),c=i(59669),g=i(4126),m=i(22131);let h=(0,c.A)` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,y=(0,c.A)` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,u=(0,c.A)` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,v=(0,c.A)` .game-stats-item-content{transform:scaleX(-1)}`,b=(0,c.A)` .game-stats-list{background:var(--button-light-rest)}.game-stats-item-header > span:nth-child(2){font-weight:550}@media (prefers-color-scheme:dark){.game-stats-list{background-color:#00000040}.game-stats-item{color:#fff}.game-stats-title{color:#fff}}`,f=(0,c.A)` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new p.t(null,v),new d.N(u,y),new g.o("isAdaptiveThemeEnabled",!0,h),new g.o("isMitUx",!0,b),(0,m.mr)((0,c.A)` :host{forced-color-adjust:auto}`));var x=i(89757),w=i(69259),$=i(68835);let k=(0,x.qy)`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${e=>e.leftText}
            </span>
            <span>
                ${e=>e.key}
            </span>
            <span>
                ${e=>e.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${e=>0!==e.gap?`background: linear-gradient(to right, ${e.leftColor} 0%, ${e.leftColor} ${e.leftPercent}%, #FFFFFF ${e.leftPercent}%, #FFFFFF ${e.leftPercent+e.gap}%, ${e.rightColor} ${e.leftPercent+e.gap}%, ${e.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,C=(0,x.qy)`
    <div class="team-container">
        ${(0,w.z)((e,t)=>0!==t.index,(0,x.qy)`<div class="team-name">${e=>e.name}</div>`)}
        <img class="team-icon" src="${e=>e.imageUrl}" alt="${e=>e.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,w.z)((e,t)=>0===t.index,(0,x.qy)`<div class="team-name">${e=>e.name}</div>`)}
    </div>
`,z=(0,x.qy)`
    <div class="game-team-icons">
        ${(0,$.ux)(e=>e.viewModel.participants,C,{positioning:!0})}
    </div>
`,M=(0,x.qy)`
<div class="game-stats-title">${e=>e.viewModel.cardTitle}</div>
`,T=(0,x.qy)`
    <div class="${e=>e.viewModel.isFullCard?"full-card":""} ${e=>e.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,w.z)(e=>e.viewModel.isFullCard&&e.viewModel.participants,z)}
        ${(0,w.z)(e=>!e.viewModel.isFullCard&&"_2x_2y"!==e.viewModel.cardSize,M)}
        <div class="game-stats-list ${e=>"1.5u"===e.viewModel.cardSize?"_15u":e.viewModel.cardSize}">
            ${(0,$.ux)(e=>e.viewModel.sportsGameStats,k)}
        </div>
    </div>
`,S=(0,x.qy)`
    <div class="s-dvrg">
        <div class="dtitle">${e=>e.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,$.ux)(e=>e.viewModel.sportsGameStats,(0,x.qy)`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${e=>e.leftText}
                </span>
                <span>
                    ${e=>e.key}
                </span>
                <span class="right">
                    ${e=>e.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${e=>e.leftColor||"#A71930"};
                                width: ${e=>e.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${e=>e.rightColor||"#036779"};
                                width: ${e=>e.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,F=(0,x.qy)`${e=>e.viewModel?.isCopilotTheme?S:T}`,P=(0,x.qy)`
    ${(0,w.z)(e=>void 0!=e.viewModel,F)}
`,G=class extends l{};G=(0,a.Cg)([(0,n.E)({name:"sports-game-stats",template:P,styles:f,shadowOptions:{delegatesFocus:!0}})],G)},70846:function(e,t,i){i.r(t),i.d(t,{SportsPickWinnerWC:function(){return O}});var a=i(56911),r=i(23305),o=i(60815),s=i(66591),l=i(71372),n=i(48566),p=i(50180);class d extends l.a{constructor(){super(...arguments),this.handleCommentsButtonClick=e=>{let t=e.target;t?.closest(".comments-button")&&this.viewModel.handleCommentsClick?.(e)},this.handlePollOptionOnClick=e=>{this.viewModel.userVote||(this.viewModel.recordUserVote(e),this.viewModel.userVote=e,this.handleVoteDataBuffer(e),o.cP.notify(this,"viewModel"))},this.handleVoteDataBuffer=e=>{if(""!==e){this.viewModel.teamsVoteData.forEach((t,i)=>this.viewModel.teamsVoteData[i]=t.id===e?{...t,voteCount:(t.voteCount||0)+1}:t);let t=(this.viewModel.teamsVoteData[0].voteCount||0)+(this.viewModel.teamsVoteData[1].voteCount||0);this.viewModel.teamsVoteData.forEach((e,i)=>this.viewModel.teamsVoteData[i].votePercentage=this.getTeamPercent(e.voteCount||0,t))}}}connected(){super.connected(),this.viewModel.userVote&&this.handleVoteDataBuffer(this.viewModel.userVote),this.shadowRoot?.addEventListener?.("click",this.handleCommentsButtonClick)}get isEntrypoint(){return!!this.viewModel?.isEntrypoint}disconnected(){this.shadowRoot?.removeEventListener?.("click",this.handleCommentsButtonClick)}getPollResultText(e){return this.viewModel.gameState===r.T0.Final?e?.hasWon?this.viewModel.strings.winnerText:"":(this.viewModel.disableVoting||this.viewModel.userVote)&&void 0!==e.votePercentage?`${e.votePercentage}%`:""}getTotalVotesString(){let e=this.totalVotes,t=1===e?this.viewModel.strings.voteSingular:this.viewModel.strings.votesNumber;return e?(0,p.GP)(t||"",`${e}`):""}getComponentString(e){let{gameState:t,strings:i,isEntrypoint:a}=this.viewModel;if(a)return e?i.pickWinner:this.getTotalVotesString();let o="";this.viewModel.userVote?t===r.T0.PreGame||t===r.Xp.preGame?o=e?i.postselPrimary:i.postselSecondaryPre:t===r.T0.InProgress||t===r.Xp.inprogressGame?o=e?i.postselPrimary:i.postselSecondaryLive:t===r.T0.Final&&(o=this.viewModel.teamsVoteData.find(e=>e.id===this.viewModel.userVote)?.hasWon?e?i.postselPrimaryWon:i.postselSecondaryPost:e?i.postselPrimaryLost:i.postselSecondaryPost):t===r.T0.PreGame||t===r.Xp.preGame?o=e?i.preselPrimary:i.preselSecondary:t===r.T0.InProgress||t===r.Xp.inprogressGame?o=e?i.preselPrimaryLive:i.preselSecondaryLive:t===r.T0.Final&&(o=e?i.preselPrimaryLive:i.postselSecondaryPost);let s=this.viewModel.teamsVoteData.find(e=>e.id===this.viewModel.userVote)?.shortName;return o?.includes("{teamName}")&&(o=s?n.Qf.Format(o,{teamName:s}):""),o}getTeamPercent(e,t){return Math.round(e/t*100)||0}getCanUserVote(){return!this.viewModel.userVote&&!this.viewModel.disableVoting}getTeamName(e){return this.viewModel.isRuby&&e.name&&(3===this.viewModel.columnLayout||4===this.viewModel.columnLayout)?e.name:e.shortName||""}get teamButtonClassNames(){return(0,s.x)("pick-winner-option",["voted",!!this.viewModel.userVote],["disabled",!!this.viewModel.disableVoting],["entrypoint",!!this.viewModel.isEntrypoint])}getTeamButtonStyles(e){return!this.getCanUserVote()&&this.viewModel.isRuby&&e.teamColor?`background: ${e.teamColor}0D;`:""}getTeamButtonAriaLabel(e){let t=this.getTeamName(e),i=t&&this.viewModel.userVote===e.id?this.viewModel.strings.selectedText.replace("{0}",t||""):t;return this.getCanUserVote()||void 0===e.votePercentage?i:`${i} ${e.votePercentage}%`}get totalVotes(){return this.viewModel.teamsVoteData.reduce((e,t)=>e+(t.voteCount||0),0)}isTeamWinningPoll(e,t){return t.reduce((e,t)=>e.votePercentage&&t.votePercentage&&e.votePercentage>t.votePercentage?e:t).id===e}getTeamButtonPercentageBarClassNames(e){return(0,s.x)("option-item-bar",["selected",!!this.viewModel.userVote&&this.viewModel.userVote===e||!!this.viewModel.disableVoting&&this.isTeamWinningPoll(e,this.viewModel.teamsVoteData)])}getTeamButtonPercentageBarStyles(e){if(!this.getCanUserVote()&&void 0!==e.votePercentage){let t=`width: ${e.votePercentage}%;`;return this.viewModel.isRuby&&e.teamColor&&(t+=` background: ${e.teamColor}33`),t}return"width: 0%;"}getOptionItemContentClassNames(e){return(0,s.x)("option-item-content",["entrypoint",!!this.viewModel.isEntrypoint],["selected",this.viewModel.userVote===e])}}var c=i(92011),g=i(49417),m=i(95403),h=i(83252),y=i(61138),u=i(71157),v=i(6032),b=i(24496),f=i(59669),x=i(22131),w=i(4126),$=i(70289),k=i(32257);let C=(0,f.A)` .pick-winner-option.entrypoint{background:#1F1F1F;border-color:#6D6D6D}.option-item-bar{background:#FFFFFF1A}.option-item-bar.selected{background:#243966}.cplt .pick-winner-option.entrypoint{background:#323F60A6;border:1px solid #FFFFFF1A}.cplt .pick-winner-option.entrypoint:has(.selected){border-color:#242C46}.cplt .option-item-bar,.cplt .option-item-bar.selected{background:#01682633}.pick-winner-secondary-text{color:#999999}.cplt .pick-winner-secondary-text{color:#E5EBFA}.option-item-result{color:#FFFFFF}.cplt .option-item-result{color:#E5EBFA}.pick-winner-option:not(.voted):not(.disabled):hover{background-color:#FFFFFF49}`,z=(0,f.A)` .pick-winner-container.cplt{border-top:0px;color:${k.C6c}}.pick-winner-primary-text{font-size:14px;line-height:20px;font-weight:550}.pick-winner-secondary-text{color:#707070;;font-size:${y.k};white-space:nowrap}.cplt .pick-winner-secondary-text{color:inherit}.cplt .option-item-image{height:24px;width:24px}.pick-winner-option.entrypoint{box-sizing:border-box;border-radius:100px;height:36px;background:#FAFAFA;border-color:#D1D1D1;padding:0px 2px}.cplt .pick-winner-option.entrypoint{border-radius:12px;height:40px;background:transparent;border-color:#0000001A}.pick-winner-options{gap:8px}.cplt .pick-winner-options{gap:6px}.pick-winner-text-container{flex-direction:row;justify-content:space-between;align-items:center;position:relative}.option-item-content{font-weight:450}.option-item-text{font-size:14px;line-height:20px;font-weight:600}.cplt .option-item-text{}.option-item-text-container{align-items:center;gap:8px}.option-item-bar{background:#EEEEEE}.option-item-bar.selected{background:#E0EDFF}.cplt .option-item-bar.selected{background:#97DFA133}.cplt .option-item-bar,.cplt .option-item-bar.selected{background:#97DFA133}.option-item-result{align-self:center;font-size:14px;line-height:20px;font-weight:600}.cplt .option-item-result{color:#4C4642;font-weight:450}.pick-winner-container{padding-top:20px}.cplt.pick-winner-container{padding-top:36px}._1x_3y.pick-winner-container{padding-top:86px}`.withBehaviors((0,x.G2)(C)),M=(0,f.A)` .option-item-bar{background:var(--color-neutral-stroke-2,#EEEEEE)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#E0EDFF)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#D1D1D1)}`,T=(0,f.A)` .option-item-bar{background:var(--color-neutral-stroke-2,#3D3D3D)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#243966)}.like-icon{filter:invert(1)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#666666)}`,S=(0,f.A)` .pick-winner-container{border-top:1px solid ${g.hb};padding:8px 0;gap:8px;display:grid}.pick-winner-container.ruby{border:none;gap:16px;padding:0}.pick-winner-options{padding:unset;display:grid;gap:6px;margin-top:unset;margin-bottom:4px}.ruby .pick-winner-options{margin:unset;gap:16px}.pick-winner-option{all:unset;${$.f} display:flex;height:36px;align-items:center;border-radius:100px;overflow:hidden;background:${m.Wl}}.pick-winner-option:focus-visible{outline:-webkit-focus-ring-color auto 1px;outline-offset:2px}.ruby .pick-winner-option{height:56px;border:none}.pick-winner-option:not(.voted):not(.disabled):hover{cursor:pointer;background-color:${h.Xt}}.pick-winner-option.entrypoint{height:30px}.option-item-content{display:flex;justify-content:space-between;width:100%;position:relative;font-weight:600;padding:0 10px;font-size:14px}.ruby .option-item-content{padding:0 16px;align-items:center}.option-item-bar{position:absolute;height:100%;left:0;width:0%;transition:width 0.5s ease-in-out}.option-item-text-container{display:flex;gap:6px}.ruby .option-item-text-container{gap:12px;align-items:center}.option-item-text{-webkit-line-clamp:1;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all}.option-item-content.entrypoint:not(.selected){font-weight:400}.option-item-image{width:auto;height:24px}.ruby .option-item-image{height:40px}.like-button-container{align-items:center;display:flex}.pick-winner-text-container{display:flex;flex-direction:column;gap:2px}.pick-winner-primary-text{font-size:${y.k};font-weight:600}.ruby .pick-winner-primary-text,.ruby .option-item-text,.ruby .option-item-result{font-weight:550;font-size:18px;line-height:${u.O}}.ruby .option-item-result{display:flex;gap:4px}.pick-winner-secondary-text{font-size:${y.k};color:${v.c}}.comments-button{all:unset;font-size:inherit;${$.f} color:${b.W_};text-decoration:underline;cursor:pointer}.comments-button:hover{color:${b.YL}}.comments-button:focus-visible{outline:-webkit-focus-ring-color auto 1px}.ruby .like-icon{height:24px}`.withBehaviors((0,x.C7)(M),(0,x.G2)(T),new w.o("isEntrypoint",!0,z));var F=i(89757),P=i(69259),G=i(93809),A=i(68835),N=i(33744),V=i(30876);let E=`${(0,N.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_regular.svg`,q=`${(0,N.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_filled.svg`,_=e=>(0,F.qy)`
    <div class="like-button-container">
        <img class="like-icon" src="${t=>e?q:E}" alt="" />
    </div>
`,B=(0,F.qy)`
    <div class="option-item-result">
        ${(e,t)=>t.parent.getPollResultText(e)}
        ${(0,P.z)((e,t)=>t.parent.viewModel.isRuby&&!t.parent.viewModel.isEntrypoint&&t.parent.viewModel.gameState!==r.T0.Final,(0,F.qy)`
            ${(e,t)=>_(t.parent.viewModel.userVote===e.id)}
        `)}
    </div>
`,D=(0,F.qy)`
    <button
        type="button"
        id=${e=>e.id}
        class=${(e,t)=>t.parent.teamButtonClassNames}
        @click=${(e,t)=>t.parent.getCanUserVote()&&t.parent.handlePollOptionOnClick?.(e.id)}
        data-t=${(e,t)=>t.parent.getCanUserVote()?t.parent.viewModel.telemetryContext?.voteButtonTag:null}
        style=${(e,t)=>t.parent.getTeamButtonStyles(e)}
        aria-label=${(e,t)=>t.parent.getTeamButtonAriaLabel(e)}
    >
        <div
            class=${(e,t)=>t.parent.getTeamButtonPercentageBarClassNames(e.id)}
            style=${(e,t)=>t.parent.getTeamButtonPercentageBarStyles(e)}
        ></div>
        <div class=${(e,t)=>t.parent.getOptionItemContentClassNames(e.id)}>
            <div class="option-item-text-container">
                ${(0,P.z)(e=>!!e.imageUrl,(0,F.qy)`
                    <img class="option-item-image" alt="" src=${e=>e.imageUrl} />
                `)}
                <span class="option-item-text" aria-hidden="true">${(e,t)=>t.parent.getTeamName(e)}</span>
                ${(0,P.z)((e,t)=>!t.parent.viewModel.isRuby&&!t.parent.viewModel.disableVoting&&!t.parent.viewModel.isEntrypoint&&t.parent.viewModel.userVote===e.id,(0,F.qy)`
                    ${(e,t)=>_(t.parent.viewModel.userVote===e.id)}
                `)}
            </div>
            ${(0,P.z)((e,t)=>!t.parent.getCanUserVote(),B,(0,F.qy)`
                ${(0,P.z)((e,t)=>!t.parent.viewModel.isRuby&&!t.parent.viewModel.isEntrypoint,(0,F.qy)`
                    ${(e,t)=>_(t.parent.viewModel.userVote===e.id)}
                `)}
            `)}
        </div>
    </button>
`,I=(0,F.qy)`
    <div
        class="pick-winner-container ${e=>e.viewModel.isRuby?"ruby":""} ${e=>e.viewModel.cardSize||""} ${e=>e.viewModel.isCopilotTheme?"cplt":""}"
        data-t=${e=>e.viewModel.telemetryContext?.rootTag}
    >
        <div class="pick-winner-text-container">
            ${(0,P.z)(e=>!!e.getComponentString(!0),(0,F.qy)`
                <div class="pick-winner-primary-text">
                    ${e=>e.getComponentString(!0)}
                </div>
            `)}
            ${(0,P.z)(e=>!!e.getComponentString(!1),(0,F.qy)`
                <div
                    class="pick-winner-secondary-text"
                    role="status"
                    :innerHTML=${(0,G.U)(e=>e.getComponentString(!1),V.r)}
                ></div>
            `)}
        </div>
        <div class="pick-winner-options">
            ${(0,A.ux)(e=>e.viewModel.teamsVoteData,(0,F.qy)`
                ${D}
            `,{positioning:!0})}
        </div>
    </div>
`,j=(0,F.qy)`
    ${(0,P.z)(e=>!!e.viewModel,I)}
`,O=class extends d{};O=(0,a.Cg)([(0,c.E)({name:"sports-pick-winner-wc",template:j,styles:S,shadowOptions:{delegatesFocus:!0}})],O)},811:function(e,t,i){i.r(t),i.d(t,{SportsPlayerEvent:function(){return f}});var a=i(56911),r=i(92011),o=i(32257),s=i(25975),l=i(59669),n=i(63033);let p=(0,l.A)` :host{--player-bg:#0000004D;--fallback-bg:#292929;--cplit-img-bg:#9DA8D91A;--cplt-player-bg:#9DA8D90D}.cplt .role,.cplt .time-label{color:${o.C6c}}`,d=(0,l.A)` :host{--player-bg:#FFFFFFB2;--cplt-player-bg:#CCC4C033;--cplit-img-bg:#FFFFFFCC;--fallback-bg:#EBEBEB;--player-icon-size:80px;container-type:inline-size}.trunc{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.wrap{position:relative}.title{font-size:${o.e1r};line-height:${o.HoW};text-align:center;margin:10px;font-weight:600}.content{display:flex;flex-direction:row;align-items:center;gap:16px;padding:10px;background:var(--player-bg);border-radius:6px;height:100px;box-sizing:border-box}.player-image-wrap{flex-shrink:0;width:var(--player-icon-size);height:var(--player-icon-size);border-radius:50%;overflow:hidden;display:flex;align-items:center;justify-content:center;border:1px solid #0000000F;box-shadow:0px 2px 4px 0px #0000000A}.player-image-wrap.fallback{background:var(--fallback-bg);border:none;font-size:${o.bPr};line-height:${o.cZi};font-weight:600}.fallback-text{height:35px}.player-img{width:var(--player-icon-size);height:var(--player-icon-size);object-fit:cover}.fallback-wrap,.fallback-icon{width:40px;height:40px}.player-info{display:flex;flex-direction:column;gap:2px;overflow:hidden}.player-name{font-size:14px;font-weight:600;line-height:20px}.player-meta{display:flex;align-items:center;gap:4px;margin-bottom:8px}.team-flag{width:16px;height:16px;flex-shrink:0}.role{font-size:${o.CuR};line-height:${o.$LU}}.time-row{display:flex;align-items:center;gap:8px;font-size:${o.e1r};line-height:${o.HoW}}.time-value{font-weight:600}._1x_3y{.content{height:250px;flex-direction:column;gap:12px;justify-content:center}.player-info{align-items:center;max-width:100%}.player-name{max-width:100%}}.cplt{.title{text-align:unset;margin:14px 0px 12px;font-weight:${s.IH6}}.content{height:104px;background:var(--cplt-player-bg);border-radius:12px;padding:12px}.player-image-wrap{border:none;box-shadow:none;background:var(--cplit-img-bg);font-weight:450}}.cplt .role,.cplt .time-label{color:${s.Adh}}@container (width < 240px){.cplt{--player-icon-size:60px}}`.withBehaviors(new n.N(null,p));var c=i(89757),g=i(69259);let m=(0,c.qy)`
    <div class="player-image-wrap">
        <img
            class="player-img"
            src="${e=>e.viewModel.imageUrl}"
            alt="${e=>e.event.shortName}"
        />
    </div>
`,h=(0,c.qy)`
    <div class="player-image-wrap fallback">
        <div class="fallback-text">
            ${e=>e.viewModel.fallbackIconText}
        </div>
    </div>
`,y=(0,c.qy)`
    <div class="wrap ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isCopilotTheme?"cplt":""}">
        <div class="title trunc" title="${e=>e.event.title}">
            ${e=>e.event.title}
        </div>
        <div class="content">
            ${(0,g.z)(e=>!!e.viewModel.imageUrl,m,h)}
            <div class="player-info">
                <div class="player-name trunc" title="${e=>e.event.shortName}">
                    ${e=>e.event.shortName}
                </div>
                <div class="player-meta">
                    ${(0,g.z)(e=>!!e.viewModel.teamImageUrl,(0,c.qy)`
                        <img
                            class="team-flag"
                            src="${e=>e.viewModel.teamImageUrl}"
                            alt=""
                            role=""
                        />
                    `)}
                    <span class="role trunc">
                        ${e=>e.event.role.title} #${e=>e.event.role.number}
                    </span>
                </div>
                <div class="time-row trunc">
                    <span class="time-label">${e=>e.event.eventTimeLabel}</span>
                    <span class="time-value">${e=>e.event.eventTime}</span>
                </div>
            </div>
        </div>
    </div>
`,u=(0,c.qy)`
    ${(0,g.z)(e=>void 0!=e.viewModel,y)}
`;var v=i(71372);class b extends v.a{get event(){return this.viewModel.playerEvent}}let f=class extends b{};f=(0,a.Cg)([(0,r.E)({name:"sports-player-event",template:u,styles:d})],f)},94138:function(e,t,i){i.r(t),i.d(t,{SportsSpotlight:function(){return U}});var a=i(56911),r=i(20517),o=i(83546),s=i(60815);class l extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,o.h)()}viewModelChanged(){this.isMitUx=this.viewModel?.isMitUX===!0}}(0,a.Cg)([s.sH],l.prototype,"isMitUx",void 0);var n=i(92011),p=i(86856),d=i(59669),c=i(4126),g=i(22131),m=i(47810),h=i(63033),y=i(70289);let u=(0,d.A)` @container (min-width:180px) and (max-width:273px){.cop-video{.match-wrap{padding:40px 0 0px}}}`,v=(0,d.A)` .spotlight-video-tagtitle{right:16px}._1x_3y.spotlight-video-img{margin-right:-50%}`,b=(0,d.A)` .cop-video{.spotlight-video-tagtitle{background:var(--status-informative-tint-background,#1F2431);color:#FFFFFF}}.stream-icon{border-color:#FFFFFF1A}`,f=(0,d.A)` ._1x_3y.spotlight-video{margin-top:12px}._1x_2y.spotlight-video{height:150px}._1x_3y.spotlight-video{height:296px}._1x_2y.spotlight-video .spotlight-video-tagtitle,._1x_3y.spotlight-video .spotlight-video-tagtitle{inset-inline-start:8px;top:8px;backdrop-filter:blur(25px);padding:1px 8px 3px}._1x_2y.spotlight-video .spotlight-video-title,._1x_3y.spotlight-video .spotlight-video-title{inset-inline-start:8px;bottom:4px;height:52px;font-weight:550;line-height:26px;max-width:252px}._1x_2y.spotlight-video .spotlight-video-icon{top:48px;transform:translateX(-50%)}._1x_2y.spotlight-video .spotlight-video-icon img{width:32px;height:32px}.stream .cop-video-overlay,.stream .spotlight-video-overlay,.stream .cop-video-overlay:hover,.stream .spotlight-video-overlay:hover{background:linear-gradient(180deg,rgba(0,0,0,0.00) 0,rgba(0,0,0,0.50) 48px,rgba(0,0,0,0.50) 100%)}.stream{.spotlight-video-icon{display:none}.play-icon{display:none}}.stream ._1x_2y .spotlight-video-title{bottom:12px;inset-inline-start:12px}.stream._1x_3y.spotlight-video{max-height:150px}.stream._1x_3y .spotlight-video-img{max-height:150px;margin-left:0px}.cop-title{padding:16px 20px;font-size:14px;line-height:20px}.stream .match-wrap{padding-top:0px}.stream-block{position:absolute;bottom:6px;inset-inline-start:6px;display:flex;gap:8px;max-width:calc(100% - 12px)}.stream-info{color:#FFFFFF;justify-content:center;display:flex;flex-direction:column;gap:4px;max-width:100%;min-width:0px}.stream-title{font-size:14px;line-height:20px;font-weight:550;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stream-caption{font-size:12px;line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stream-icon{width:40px;height:40px;border-radius:6px;border:1px solid #0000001A;object-fit:cover;box-sizing:border-box}.vidv3{.stream-block{align-items:center;bottom:12px;inset-inline-start:20px;max-width:calc(100% - 20px)}.stream-info{gap:0px}.stream-title{font-size:16px;line-height:26px;font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stream-caption{font-size:14px;line-height:20px;font-weight:450;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px}.stream-icon{border-radius:16px}}`,x=(0,d.A)` .spotlight-video{display:block;position:relative;margin-top:8px;border-radius:8px;overflow:hidden;z-index:1}._1x_1y.spotlight-video{height:56px;width:56px;margin-top:0px}._1x_3y.spotlight-video{height:308px}.spotlight-video-img{max-width:100%;object-fit:scale-down;overflow:hidden;border-radius:8px;display:block}._1x_1y.spotlight-video-img{width:100%;height:100%;object-fit:cover}._1x_3y.spotlight-video-img{max-height:100%;max-width:none;margin-left:-50%}.spotlight-video-tagtitle{position:absolute;left:16px;top:9px;width:fit-content;height:16px;line-height:16px;border-radius:6px;border:1px solid rgba(255,255,255,0.20);background:rgba(255,255,255,0.10);backdrop-filter:blur(12.5px);padding:0 8px;font-weight:400;font-size:12px;color:#FFFFFF}.spotlight-video-title{position:absolute;left:16px;bottom:16px;height:44px;line-height:22px;font-weight:600;font-size:16px;color:#FFFFFF;display:-webkit-box;max-width:236px;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;white-space:normal}.spotlight-video-icon{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}._1x_1y.spotlight-video-icon > img{width:24px;height:24px}.spotlight-video-overlay,.cop-video-overlay{position:absolute;width:100%;height:100%;left:0;bottom:0;transition:background 0.1s;background-image:linear-gradient(180deg,rgba(0,0,0,0.00) 0,rgba(0,0,0,0.50) 59px,rgba(0,0,0,0.50) 100%)}.spotlight-fre-container{position:relative;z-index:var(--click-z-index);margin-bottom:16px;display:flex;flex-direction:row;align-items:start;max-width:fit-content}.spotlight-video-overlay:hover{background:rgba(0,0,0,0.25)}.cop-video-overlay,.cop-video-overlay:hover{background:none}.spotlight-fre-text{overflow:hidden;white-space:nowrap;color:${m.l};text-decoration:none;padding-right:6px}._1x_1y.spotlight-fre-text{width:206px}.fre-header{font-weight:600;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-header{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);margin-bottom:4px}.fre-content{font-weight:400;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-content{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);white-space:normal;max-height:32px;-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}.wrap{width:100%;height:266px;display:flex;flex-direction:column;gap:16px;margin-top:12px;sports-game-stats{margin-top:5px}}.cop-video{container-type:inline-size;.vidv3{height:196px;width:100%;display:block;position:relative;overflow:hidden;border-radius:var(--cstm-corner-media-in-card);corner-shape:squircle}.vidv3:focus-visible{outline-offset:-1px}.thumbnail{height:196px;width:100%;object-fit:cover;transition:transform 0.4s ease-out}.vidv3:hover .thumbnail{transform:scale(1.05)}.play-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px}.match-wrap{padding:40px 20px 0px}.spotlight-video-tagtitle{height:var(--ctrl-badge-size,24px);line-height:var(--ctrl-badge-size,24px);border-radius:var(--ctrl-badge-corner,8px);padding:0 var(--ctrl-badge-padding,6px);left:20px;top:20px;background:var(--status-informative-tint-background,#EFEAE7);color:#1F2431;border:none;backdrop-filter:none}.spotlight-video-overlay{background:none}.spotlight-video-overlay:hover{background:none}}.spotlight-detail-link{display:block;text-decoration:none;color:inherit;${y.f}}.wrap .spotlight-detail-link{display:flex;flex-direction:column;gap:16px}.wrap:has(sports-pick-winner-wc),.wrap:has(sports-player-event){margin-top:30px}`.withBehaviors(new p.t(null,v),new h.N(null,b),new c.o("isAdaptiveThemeEnabled",!0,u),new c.o("isMitUx",!0,f),(0,g.mr)((0,d.A)` :host{forced-color-adjust:auto}`));var w=i(89757),$=i(68835),k=i(69259),C=i(33744);let z=`${(0,C.rA)().StaticsUrl}latest/icons-wc/icons/PlayIconLarge.svg`,M=`${(0,C.rA)().StaticsUrl}latest/sports/icons/PlayIconCopilot.svg`,T=(0,w.qy)`
    <div>
        ${(0,$.ux)(e=>e.viewModel.matches,(0,w.qy)`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,S=(0,w.qy)`
    ${(0,k.z)(e=>null!=e.viewModel.headerData,(0,w.qy)`
        <div class="spotlight-fre-container">
            <a class="spotlight-fre-text ${e=>e.viewModel.cardSize}"
                data-t="${e=>e.viewModel.spotsVideoTelemetry}"
                href="${e=>e.viewModel.headerData?.clickThroughUrl}"
                target="_blank"
            >
                <div class="fre-header" title="${e=>e.viewModel.headerData?.headerTextLine1}">
                    ${e=>e.viewModel.headerData?.headerTextLine1}
                </div>
                <div class="fre-content" title="${e=>e.viewModel.headerData?.headerTextLine2}">
                    ${e=>e.viewModel.headerData?.headerTextLine2}
                </div>
            </a>
            ${(0,k.z)(e=>"_1x_1y"===e.viewModel.cardSize&&e.viewModel.sportsVideo?.msnVideoEmbedLink,(0,w.qy)`
                <a
                    class="spotlight-video ${e=>e.viewModel.cardSize}"
                    data-t="${e=>e.viewModel.spotsVideoTelemetry}"
                    href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
                    target="_blank"
                >
                    <img
                        class="spotlight-video-img ${e=>e.viewModel.cardSize}"
                        role="presentation"
                        src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
                    />
                    <div class="spotlight-video-overlay">
                        <div class="spotlight-video-icon ${e=>e.viewModel.cardSize}">
                            <img role="presentation" src=${z} alt="" />
                        </div>
                    </div>
                </a>
            `)}
        </div>
    `)}
`,F=(0,w.qy)`
    <sports-game-stats
        :viewModel="${e=>e.viewModel.sportsGameStatsCard?.viewModel}"
    >
    </sports-game-stats>
`,P=(0,w.qy)`
    <sports-game-leaders
        :viewModel="${e=>e.viewModel.sportsGameLeadersCard?.viewModel}"
    >
    </sports-game-leaders>
`,G=(0,w.qy)`
    <sports-player-event
        :viewModel="${e=>e.viewModel.sportsPlayerEventCard}"
    ></sports-player-event>
`,A=(0,w.qy)`
    <sports-pick-winner-wc
        :viewModel="${e=>e.viewModel.sportsPickWinnerCard?.viewModel}"
    >
    </sports-pick-winner-wc>
`,N=(0,w.qy)`
    <div class="spotlight-video-tagtitle">
        ${e=>e.viewModel.sportsVideo?.videoTagTitle}
    </div>
`,V=(0,w.qy)`
    <div class="stream-block" title="${e=>e.viewModel.sportsVideo?.videoTitle||""}">
        ${(0,k.z)(e=>e.viewModel.sportsVideo?.sourceIconUrl,(0,w.qy)`<img role="presentation" src=${e=>e.viewModel.sportsVideo?.sourceIconUrl} alt="" class="stream-icon"/>`)}
        <div class="stream-info">
            <div class="stream-title">
                ${e=>e.viewModel.sportsVideo?.videoTitle||""}
            </div>
            <div class="stream-caption">
                ${e=>e.viewModel.sportsVideo?.videoCaption||""}
            </div>
        </div>
    </div>
`,E=(0,w.qy)`
    ${(0,k.z)(e=>"_1x_1y"!==e.viewModel.cardSize,(0,w.qy)`
        <a
            class="spotlight-video ${e=>e.viewModel.cardSize} ${e=>e.viewModel.sportsVideo?.isStream?"stream":""}"
            data-t="${e=>e.viewModel.spotsVideoTelemetry}"
            href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
            target="_blank"
        >
            <img
                class="spotlight-video-img ${e=>e.viewModel.cardSize}"
                role="presentation"
                src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
            />
            <div class="spotlight-video-overlay">
                ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.videoTagTitle,N)}
                ${(0,k.z)(e=>!e.viewModel.sportsVideo?.isStream,(0,w.qy)`
                    <div class="spotlight-video-title" title="${e=>e.viewModel.sportsVideo?.videoTitle||""}">
                        ${e=>e.viewModel.sportsVideo?.videoTitle||""}
                    </div>
                `)}
                <div class="spotlight-video-icon">
                    <img role="presentation" src=${z} alt="" />
                </div>
                ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.isStream,V)}
            </div>
        </a>
    `)}
`,q=(0,w.qy)`
    ${(0,k.z)(e=>void 0!=e.viewModel.sportsPlayerEventCard,G)}
    ${(0,k.z)(e=>void 0!=e.viewModel.sportsPickWinnerCard,A)}
    ${(0,k.z)(e=>void 0!=e.viewModel.sportsGameStatsCard,F)}
`,_=(0,w.qy)`
    ${(0,k.z)(e=>e.viewModel.sportsGameStatsCard?.viewModel?.isFullCard,F,(0,w.qy)`
        ${(0,k.z)(e=>e.viewModel.matches.length,T,S)}
        <a
            class="spotlight-detail-link"
            data-t="${e=>e.viewModel.telemetryTag}"
            href="${e=>e.viewModel.tabClickThroughUrl}"
            target="_blank"
        >${q}</a>
        ${(0,k.z)(e=>void 0!=e.viewModel.sportsVideo,E)}
    `)}
`,B=(0,w.qy)`
    <div class="wrap">
        ${(0,k.z)(e=>e.viewModel.matches.length,T,S)}
        <a
            class="spotlight-detail-link"
            data-t="${e=>e.viewModel.telemetryTag}"
            href="${e=>e.viewModel.tabClickThroughUrl}"
            target="_blank"
        >${q}</a>
    </div>
`,D=(0,w.qy)`
    <a
        class="vidv3"
        data-t="${e=>e.viewModel.spotsVideoTelemetry}"
        href="${e=>e.viewModel.sportsVideo?.msnVideoEmbedLink}"
        target="_blank"
    >
        <img
            class="thumbnail"
            role="presentation"
            src="${e=>e.viewModel.sportsVideo?.videoThumbnailUrl}"
        />
        <div class="cop-video-overlay">
            ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.videoTagTitle,N)}
            ${(0,k.z)(e=>!!e.viewModel.sportsVideo?.isStream,V)}
            <img role="presentation" src=${M} alt="" class="play-icon"/>
        </div>
    </a>
`,I=(0,w.qy)`
    <div class="cop-title" title="${e=>e.viewModel.sportsVideo?.tabTitle||""}">
        ${e=>e.viewModel.sportsVideo?.tabTitle||""}
    </div>
`,j=(0,w.qy)`
    <div class="cop-video ${e=>e.viewModel.sportsVideo?.isStream?"stream":""}">
        ${D}
        ${(0,k.z)(e=>e.viewModel.sportsVideo?.tabTitle,I)}
        <div class="match-wrap">
            ${T}
        </div>
    </div>
`,O=(0,w.qy)`
    ${(0,k.z)(e=>void 0!=e.viewModel,(0,w.qy)`${e=>{var t;return(t=e.viewModel).sportsGameLeadersCard?P:t.isCopilotTheme&&t.sportsVideo?j:t.isCopilotTheme?B:_}}`)}
`,U=class extends l{};U=(0,a.Cg)([(0,n.E)({name:"sports-spotlight",template:O,styles:x,shadowOptions:{delegatesFocus:!0}})],U)},63129:function(e,t,i){i.d(t,{ls:function(){return u},p4:function(){return y},vA:function(){return h},nF:function(){return m}});var a=i(97747),r=i(68009),o=i(95239);let{create:s}=a.G,l=s("neutral-stroke-strong-hover-delta",40),n=s("neutral-stroke-strong-active-delta",16),p=s("neutral-stroke-strong-focus-delta",25);var d=i(31023);let{create:c}=a.G,g=c({name:"neutral-stroke-strong-recipe"},{evaluate(e){var t,i,a,s,c;let g,m,h;return t=e(d.r),i=e(o.p),a=e(l),s=e(n),c=e(p),g=(0,r.F)(i),m=t.colorContrast(i,3),h=t.closestIndexOf(m),{rest:m,hover:t.get(h+g*a),active:t.get(h+g*s),focus:t.get(h+g*c)}}}),m=c("neutral-stroke-strong-rest",e=>e(g).evaluate(e).rest),h=c("neutral-stroke-strong-hover",e=>e(g).evaluate(e).hover),y=c("neutral-stroke-strong-active",e=>e(g).evaluate(e).active),u=c("neutral-stroke-strong-focus",e=>e(g).evaluate(e).focus)},30876:function(e,t,i){i.d(t,{r:function(){return o}});var a=i(7686),r=i(42277);let o=i(68244).F.create({trustedType:{createHTML:e=>a.A.sanitize(e,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[r.D.property]:{innerHTML:(e,t,i,r)=>(e,t,i,...o)=>{r(e,t,a.A.sanitize(i,{RETURN_TRUSTED_TYPE:!0}),...o)}}}}})}}]);