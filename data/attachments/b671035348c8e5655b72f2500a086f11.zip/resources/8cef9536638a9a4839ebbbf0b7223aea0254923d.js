"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["libs_feed-layout_dist_card-templates_hide-story-card_templates_HideStoryAdFeedbackConfirmatio-f9a062"],{47264(e,t,a){a.d(t,{A:()=>i});let i='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6 10a1.25 1.25 0 1 1-2.5 0A1.25 1.25 0 0 1 6 10zM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM15.25 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5z"/></svg>'},33307(e,t,a){a.d(t,{A:()=>i});let i='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM15 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z"/></svg>'},19173(e,t,a){a.d(t,{A:()=>i});let i='<svg width="11" height="3" viewBox="0 0 11 3" fill="none"><path d="M2.5 1.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM6.5 1.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM9.25 2.5a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z"/></svg>'},2881(e,t,a){a.d(t,{$:()=>p});var i,o,n,r,d,s,l,c,p,g=a(33744);(i=p||(p={})).ImageSize={TopicCardImageStandardDimensions:{height:80,width:80},ContentCardImageStandardDimensions:{height:68,width:68},ContentCardProviderImgStandardDimensions:{height:16,width:16},SuggestionCardImgStandardDimensions:{height:42,width:42}},i.topicCardBackupImageUrl="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAtCmK3.img",i.informationCardAutosMarketplaceToggle="autosMarketplaceToggle",i.informationCardBoostToggle="boostToggle",i.informationCardBingShoppingToggle="bingShoppingToggle",i.informationCardCommunityToggle="communityToggle",i.informationCardDonationToggle="donationToggle",i.informationCardMoneyToggle="moneyToggle",i.informationCardCryptoToggle="cryptoToggle",i.informationCardDailyBriefToggle="dailyBriefToggle",i.informationCardDailyWonderToggle="dailyWonderToggle",i.informationCardMarketBriefToggle="marketBriefToggle",i.informationCardSportsToggle="sportsToggle",i.informationCardEsportsToggle="esportsToggle",i.informationCardWeatherToggle="weatherToggle",i.informationCardPrismFeedToggle="prismFeedToggle",i.informationCardRecipeToggle="recipeToggle",i.informationCardRewardsToggle="rewardsToggle",i.informationCardTravelToggle="travelToggle",i.informationCardTrafficToggle="trafficToggle",i.informationCardHoroscopeToggle="horoscopeToggle",i.informationCardOnThisDayToggle="onThisDayToggle",i.informationCardElectionsToggle="electionsToggle",i.informationCardRealEstateToggle="realEstateToggle",i.informationCardEntertainmentToggle="EntertainmentToggle",i.informationCardTrendingSearchToggle="trendingSearchToggle",i.informationCardMangaToggle="mangaToggle",i.informationCardSavingsToggle="savingsToggle",i.informationCardRichCalendarToggle="richCalendarToggle",i.informationCardCopilotToggle="copilotToggle",i.feedSettingReactionsToggle="reactionsToggle",i.feedSettingCommentsToggle="commentsToggle",i.productivitySettingIndustryNewsCardToggle="industryNewsCardToggle",i.productivitySettingMicrosoftFeedCardToggle="microsoftFeedCardToggle",i.productivitySettingCompanyNewsCardToggle="companyNewsCardToggle",i.gamingSettingConnectToXboxToggle="connectToXboxToggle",i.gamingSettingGamingCardsToggle="gamingCardsToggle",i.gamingSettingCasualGamesCardToggle="casualGamesCardToggle",i.informationCardCasualGamesToggle="casualGamesToggle",i.linkedInCardToggle="linkedInCardToggle",i.informationCardHealthToggle="healthCardToggle",i.personalizedOffersCardToggle="personalizedOffersCardToggle",i.informationCardTopStoriesToggle="topStoriesToggle",i.trendingNewsToggle="trendingNewsToggle",i.hotListToggle="hotListToggle",i.groceryCardToggle="groceryToggle",i.marketPlaceCardToggle="marketPlaceToggle",i.contentRecommendationsToggle="contentRecommendationsToggle",i.localDayToggle="localDayToggle",i.momentInTimeToggle="momentInTimeToggle",i.cegrowthToggle="cegrowthToggle",i.pollsToggle="pollsToggle",i.videoCarouselToggle="videoCarouselToggle",i.webNewsCarouselToggle="webNewsCarouselToggle",i.videoShoppingToggle="videoShoppingToggle",i.recommendedSearchToggle="recommendedSearchToggle",i.topCommentsToggle="topCommentsToggle",i.localNewsToggle="localNewsToggle",i.defaultToastNotificationTimeoutMs=3e3,i.sectionVisibilityBufferPx=25,i.sidePaneLayoutResponsiveWidth=611,i.stickySearchHeights={c1:66,c2:82,default:100},i.searchBoxHalfHeight=70,i.defaultStickyHeaderHeightPx=158,i.oneColumnStickyHeaderHeightPx=50,i.sectionIds={followedInterests:"followed-interests",followedPublishers:"followed-publishers",recommendedTopics:"recommended-topics",discoverInterests:"discover-interests",savedStories:"saved-stories",mutedPublishers:"muted-publishers",readStories:"read-stories",tuneFeed:"tune-feed",notification:"notification",settings:"settings-root",feedSettings:"feed-settings-root",refreshPage:"refresh-page",hiddenTopics:"hidden-topics",followedList:"followed-list",blockedList:"blocked-list"},i.sdSettingsSectionIds={root:"settings-root",Sports:"sports-settings",Esports:"esports-settings",Weather:"weather-settings",CasualGamesCard:"casualGames-settings",Finance:"finance-settings",Crypto:"crypto-settings",DailyBrief:"dailyBrief-settings",DailyWonder:"dailyWonder-settings",MarketBrief:"marketBrief-settings",Shopping:"shopping-settings",Traffic:"traffic-settings",Market:"market-settings",Horoscope:"horoscope-settings",HotList:"hot-list-settings",Travel:"travel-settings",Recipe:"recipe-settings",Rewards:"rewards-settings",PrismFeed:"prismFeed-settings",OnThisDay:"on-this-day",AutosMarketplace:"autos-marketplace-settings",GenericElection:"elections-settings",Health:"health-settings",TopStories:"top-stories-settings",TrendingNews:"trending-news-settings",Grocery:"grocery-settings",PersonalizedOffers:"personalized-offers-settings",MarketPlace:"marketPlace-settings",LinkedInCard:"linkedin-settings",ContentRecommendations:"content-recommendations-settings",LocalDay:"localDay-settings",MomentInTime:"moment-in-time-settings",Polls:"polls-settings",RealEstate:"real-estate-settings",cegrowth:"cegrowth-settings",VideoCarousel:"video-carousel-settings",WebNewsCarousel:"web-news-carousel-settings",VideoShopping:"video-shopping-settings",RecommendedSearch:"recommended-search-settings",TrendingSearch:"trending-search-settings",Manga:"manga-settings",Boost:"boost-settings",Savings:"savings-settings",Community:"community-settings",Entertainment:"entertainment-premier-settings",LocalNews:"local-news-settings",RichCalendar:"rich-calendar-settings",Donation:"donation-settings",TopComments:"topcomments-settings",Copilot:"copilot-settings"},i.productivitySettingsSectionIds={root:"productivity-settings-root",MicrosoftFeedCard:"recommended-documents-settings",IndustryNewsCard:"industry-news-settings",CompanyNewsCard:"company-news-settings"},i.feedSettingsSectionIds={root:"feed-settings-root",Reactions:"reactions-settings",Comments:"comments-settings"},i.gamingSettingsSectionIds={root:"gaming-settings-root",ConnectToXbox:"connect-to-xbox-settings",GamingCards:"gaming-cards-settings"},i.gamingInlineSettingsSectionIds={CasualGamesCard:"casual-games-settings"},i.accountLinkingSettingsSectionIds={root:"account-linking-settings-root",PersonalAccount:"personal-account-settings"},i.privacySettingsSectionIds={privacy:"privacy"},(o=i.PageType||(i.PageType={})).MyInterests="MyInterests",o.MySaves="MySaves",o.History="History",o.Setting="Setting",o.AADSetting="AADSetting",o.Personalize="Personalize",o.Notification="Notification",i.defaultSelectedSection={Personalize:i.sectionIds.discoverInterests,MyInterests:i.sectionIds.discoverInterests,AADSetting:i.accountLinkingSettingsSectionIds.root,Setting:(0,g.rA)().IsChinaCompliance?i.sdSettingsSectionIds.root:i.sdSettingsSectionIds.Market},(n=i.SdSettingCardType||(i.SdSettingCardType={})).Weather="Weather",n.CasualGamesCard="CasualGamesCard",n.Sports="Sports",n.Esports="Esports",n.Finance="Finance",n.Crypto="Crypto",n.DailyBrief="DailyBrief",n.DailyWonder="DailyWonder",n.MarketBrief="MarketBrief",n.Shopping="Shopping",n.Traffic="Traffic",n.Horoscope="Horoscope",n.HotList="HotList",n.Travel="Travel",n.Recipe="Recipe",n.Rewards="Rewards",n.PrismFeed="PrismFeed",n.OnThisDay="OnThisDay",n.AutosMarketplace="AutosMarketplace",n.EventSDCardElection="EventSDCardElection",n.Health="Health",n.TopStories="TopStories",n.TrendingNews="TrendingNews",n.Grocery="Grocery",n.PersonalizedOffers="PersonalizedOffers",n.MarketPlace="MarketPlace",n.LinkedInCard="LinkedInCard",n.ContentRecommendations="ContentRecommendations",n.LocalDay="LocalDay",n.MomentInTime="MomentInTime",n.Polls="Polls",n.RealEstate="RealEstate",n.cegrowth="cegrowth",n.VideoCarousel="VideoCarousel",n.WebNewsCarousel="WebNewsCarousel",n.VideoShopping="VideoShopping",n.RecommendedSearch="RecommendedSearch",n.TrendingSearch="TrendingSearch",n.Manga="Manga",n.Boost="Boost",n.Savings="Savings",n.Community="Community",n.Entertainment="Entertainment",n.LocalNews="LocalNews",n.RichCalendar="RichCalendar",n.Donation="Donation",n.TopComments="TopComments",n.Copilot="Copilot",(r=i.ProductivitySettingCardType||(i.ProductivitySettingCardType={})).MicrosoftFeedCard="MicrosoftFeedCard",r.IndustryNewsCard="IndustryNewsCard",r.CompanyNewsCard="CompanyNewsCard",(d=i.FeedSettingCardType||(i.FeedSettingCardType={})).Reactions="Reactions",d.Comments="Comments",(s=i.GamingSettingCardType||(i.GamingSettingCardType={})).ConnectToXbox="ConnectToXbox",s.GamingCards="GamingCards",(i.GamingInlineSettingCardType||(i.GamingInlineSettingCardType={})).CasualGamesCard="CasualGamesCard",(i.AccountLinkingCardType||(i.AccountLinkingCardType={})).PersonalAccount="PersonalAccount",(i.PrivacySettingCardType||(i.PrivacySettingCardType={})).Privacy="privacy",i.SdSettingsOrder=["LinkedInCard","Weather","CasualGamesCard","Finance","Crypto","MarketBrief","Sports","Esports","Traffic","Shopping","VideoShopping","Horoscope","HotList","Travel","Recipe","Rewards","PrismFeed","OnThisDay","EventSDCardElection","Health","AutosMarketplace","RealEstate","Grocery","PersonalizedOffers","MarketPlace","ContentRecommendations","LocalDay","MomentInTime","Polls","cegrowth","TopStories","TrendingNews","LocalNews","DailyWonder","VideoCarousel","WebNewsCarousel","RecommendedSearch","TrendingSearch","Manga","Boost","Savings","Community","Entertainment","RichCalendar","Donation","DailyBrief","TopComments","Copilot"],i.ProductivitySettingsOrder=["MicrosoftFeedCard","IndustryNewsCard","CompanyNewsCard"],i.FeedSettingsOrder=["Reactions","Comments"],i.GamingSettingsOrder=["ConnectToXbox","GamingCards"],i.GamingInlineSettingsOrder=["CasualGamesCard"],i.PrivacySettingsOrder=["privacy"],i.SettingCardTelemetryMapping={Weather:i.informationCardWeatherToggle,Sports:i.informationCardSportsToggle,Esports:i.informationCardEsportsToggle,Finance:i.informationCardMoneyToggle,Crypto:i.informationCardCryptoToggle,DailyBrief:i.informationCardDailyBriefToggle,DailyWonder:i.informationCardDailyWonderToggle,MarketBrief:i.informationCardMarketBriefToggle,Shopping:i.informationCardBingShoppingToggle,VideoShopping:i.videoShoppingToggle,Travel:i.informationCardTravelToggle,Traffic:i.informationCardTrafficToggle,Recipe:i.informationCardRecipeToggle,Rewards:i.informationCardRewardsToggle,PrismFeed:i.informationCardPrismFeedToggle,Horoscope:i.informationCardHoroscopeToggle,OnThisDay:i.informationCardOnThisDayToggle,EventSDCardElection:i.informationCardElectionsToggle,Health:i.informationCardHealthToggle,AutosMarketplace:i.informationCardAutosMarketplaceToggle,RealEstate:i.informationCardRealEstateToggle,TopStories:i.informationCardTopStoriesToggle,TrendingNews:i.trendingNewsToggle,HotList:i.hotListToggle,Grocery:i.groceryCardToggle,PersonalizedOffers:i.personalizedOffersCardToggle,MarketPlace:i.marketPlaceCardToggle,LinkedInCard:i.linkedInCardToggle,ContentRecommendations:i.contentRecommendationsToggle,LocalDay:i.localDayToggle,MomentInTime:i.momentInTimeToggle,Polls:i.pollsToggle,VideoCarousel:i.videoCarouselToggle,WebNewsCarousel:i.webNewsCarouselToggle,RecommendedSearch:i.recommendedSearchToggle,TrendingSearch:i.informationCardTrendingSearchToggle,Manga:i.informationCardMangaToggle,Boost:i.informationCardBoostToggle,Savings:i.informationCardSavingsToggle,Community:i.informationCardCommunityToggle,Entertainment:i.informationCardEntertainmentToggle,LocalNews:i.localNewsToggle,Donation:i.informationCardDonationToggle,RichCalendar:i.informationCardRichCalendarToggle,cegrowth:i.cegrowthToggle,CasualGamesCard:i.informationCardCasualGamesToggle,TopComments:i.topCommentsToggle,Copilot:i.informationCardCopilotToggle},i.FeedSettingCardTelemetryMapping={Reactions:i.feedSettingReactionsToggle,Comments:i.feedSettingCommentsToggle},i.ProductivitySettingCardTelemetryMapping={MicrosoftFeedCard:i.productivitySettingMicrosoftFeedCardToggle,IndustryNewsCard:i.productivitySettingIndustryNewsCardToggle,CompanyNewsCard:i.productivitySettingCompanyNewsCardToggle},i.GamingSettingCardTelemetryMapping={ConnectToXbox:i.gamingSettingConnectToXboxToggle,GamingCards:i.gamingSettingGamingCardsToggle},i.GamingInlineSettingCardTelemetryMapping={CasualGamesCard:i.gamingSettingCasualGamesCardToggle},i.PrivacyCardTelemetryMapping={privacy:"privacy"},i.treeItemTag="FLUENT-TREE-ITEM",i.savesHash="#saves",i.publishersHash="#mutedPublishers",i.followedInterestsHash="#followed-interests",i.discoveryInterestsMenuId="menuItem-discover-interests",i.notificationMenuId="menuItem-notification",i.sourceNameTag="source",i.settingsRootMenuId="menuItem-settings-root",i.maxNumberOfResults=6,i.FluentTreeItemTagName="fluent-item-tree",i.MutedPublishersId="mutedpublishers",i.MsftPublishersCardTagName="msft-publishers-card",i.MutedPublishersMenuItemId="menuItem-muted-publishers",i.TopStoriesEnabledId="IsTopStoriesEnabled",(l=i.InlineSettingsType||(i.InlineSettingsType={})).Sports="Sports",l.AccountLinking="AccountLinking",l.GamingCards="GamingCards",l.None="None",i.ActionBasedSettingCardTargetMap={ContentRecommendations:{targetId:"localperspective",targetType:"beaconpromo"},MomentInTime:{definitionName:"eventcontentcardmit1",targetId:"eventcontentcardmit1",targetType:"TopicFeed"},LinkedInCard:{definitionName:"linkedinnews",targetType:"TopicFeed"},VideoCarousel:{definitionName:"watch-video",targetType:"TopicFeed"},WebNewsCarousel:{definitionName:"webnlnews",targetType:"TopicFeed"},Crypto:{definitionName:"Segment_Finance_CryptoCard",targetType:"StructuredCard"},MarketBrief:{definitionName:"Segment_Finance_MarketBrief",targetType:"StructuredCard"},TopStories:{definitionName:"topstories",targetId:"topstories",targetType:"TopicFeed"},TrendingNews:{definitionName:"trending now",targetId:"trending now",targetType:"TopicFeed"},HotList:{definitionName:"hotlist",targetId:"hotlist",targetType:"TopicFeed"},LocalNews:{targetId:"localnews",targetType:"LocalNewsFeed"},DailyBrief:{definitionName:"DailyBrief",targetId:"DailyBrief",targetType:"DailyBriefing"},TopComments:{definitionName:"topcomments",targetId:"topcomments",targetType:"TopicFeed"}},(c=i.PrivacySettingState||(i.PrivacySettingState={}))[c.InitialScreen=0]="InitialScreen",c[c.ConfirmationScreen=1]="ConfirmationScreen",c[c.ConfirmationSuccess=2]="ConfirmationSuccess",c[c.ConfirmationFailure=3]="ConfirmationFailure",i.widgetsRegionCards=new Set(["Weather","Finance","Sports","Traffic","TopStories"]),i.widgetRegionCardWithDB=new Set(["Weather","Finance","DailyBrief","Traffic","TopStories"])},95288(e,t,a){a.d(t,{f:()=>n});let i={Tenorite:"https://assets.msn.com/staticsb/statics/latest/fonts/tenorite/tenorite.woff2",Lora:"https://assets.msn.com/staticsb/statics/latest/fonts/lora/lora-regular.woff2"},o=new Set,n=e=>{let t=i[e];if(!t||o.has(e))return;let a=document.createElement("style");a.setAttribute("type","text/css"),a.appendChild(document.createTextNode(`@font-face {font-family:${e};src:url("${t}") format('woff2');}`)),document.head.appendChild(a),o.add(e)}},98728(e,t,a){a.d(t,{L:()=>r});var i=a(99659),o=a(89757),n=a(69259);i.k;let r=(0,o.qy)`<style>msn-hide-story-card.ad-feedback-confirmation { background: var(--hide-story-background); } msn-hide-story-card.ad-feedback-confirmation fluent-button { width: 150px; text-align: center; display: block; margin: 54px auto 8px; } msn-hide-story-card.ad-feedback-confirmation fluent-button::part(control) { width: 100%; letter-spacing: inherit; line-height: inherit; word-spacing: inherit; } msn-hide-story-card.ad-feedback-confirmation fluent-button:hover { background: var(--button-hover-color); } msn-hide-story-card.ad-feedback-confirmation::part(content-region) { margin: 0 auto; text-align: center; padding: 110px 16px 0px 16px; } msn-hide-story-card.ad-feedback-confirmation::part(action-region) { display: block; position: static; margin: 0; padding: 0px 16px 16px; }</style><msn-hide-story-card hideStoryTitle=${e=>e.adFeedbackProps.localizedStrings.confirmationText} class="ad-feedback-confirmation">${(0,n.z)(e=>!e.adFeedbackProps?.configOptions?.enableAdFeedbackV1UpdatePhase1,(0,o.qy)`<fluent-button slot="actions" autofocus appearance="neutral" aria-label=${e=>e.adFeedbackProps.localizedStrings.undoText} title=${e=>e.adFeedbackProps.localizedStrings.undoText} id="Undo" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()}>${e=>e.adFeedbackProps.localizedStrings.undoText}</fluent-button>`)}</msn-hide-story-card>`},82521(e,t,a){a.d(t,{u:()=>n});var i=a(99659),o=a(89757);i.k;let n=(0,o.qy)`<style>.hide-story-card fluent-button::part(control) { width: 100%; } msn-hide-story-card.hide-story-card fluent-button::part(content) { text-overflow: ellipsis; overflow: hidden; } msn-hide-story-card.hide-story-card fluent-button { width: 48%; margin: 0 0 8px 0; display: flex; } msn-hide-story-card.hide-story-card::part(content-region) { display: inline-flex; align-items: center; padding: 16px 16px 0px; cursor: default; } msn-hide-story-card.hide-story-card::part(action-region) { display: flex; position: absolute; padding: 0px 16px 16px; justify-content: space-around; bottom: 0px; width: 100%; box-sizing: border-box; align-items: center; margin: 0; }</style><msn-hide-story-card class="hide-story-card" hideStoryTitle="${e=>e.hideStoryTitleData.text}" data-t="${e=>e.telemetryContext?.hideStoryCard?.getMetadataTag()}"><fluent-button autofocus aria-label=${e=>e.personalizeButtonTextData.text} title=${e=>e.personalizeButtonTextData.text} @click=${e=>e.personalizeButtonCallback&&e.personalizeButtonCallback()} slot="actions" appearance="accent" data-t="${e=>e.telemetryContext?.confirmButton?.getMetadataTag()}">${e=>e.personalizeButtonTextData.text}</fluent-button><fluent-button aria-label=${e=>e.undoHideButtonText} title=${e=>e.undoHideButtonText} @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()} slot="actions" appearance="neutral" data-t="${e=>e.telemetryContext?.cancelButton?.getMetadataTag()}">${e=>e.undoHideButtonText}</fluent-button></msn-hide-story-card>`},54084(e,t,a){a.d(t,{F:()=>l});var i=a(89757),o=a(69259),n=a(44978),r=a(69828);a(99659).k;let d=(0,i.qy)` ${(0,o.z)(e=>e.dislikeButtonText||e.useUpdatedHideStoryStrings,(0,i.qy)`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText} menu item`} title=${e=>e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText} id="DislikeTopic" @change=${e=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&n.J.showFewer?e.cardActionStatus^n.J.hidden:e.cardActionStatus^n.J.showFewer^n.J.hidden,"ShowFewer",!0,e.cardActionClickHandler,null,!1,void 0,void 0,e.entryPoint)} slot="actions" data-t="${e=>e.telemetryContext?.dislikeButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText}</div></fluent-menu-item>`)} ${(0,o.z)(e=>e.useUpdatedHideStoryStrings,(0,i.qy)`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.clickbaitButtonText} menu item`} title=${e=>e.clickbaitButtonText} id="DislikeTopic" @change=${e=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&n.J.showFewer?e.cardActionStatus^n.J.hidden:e.cardActionStatus^n.J.showFewer^n.J.hidden,"ShowFewer",!0,e.cardActionClickHandler,null,!1,void 0,void 0,e.entryPoint)} slot="actions" data-t="${e=>e.telemetryContext?.dislikeButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.clickbaitButtonText}</div></fluent-menu-item>`)}<fluent-menu-item tabindex="0" aria-label=${e=>`${e.mutePublisherButtonText} menu item`} title=${e=>e.mutePublisherButtonText} id="MutePublisher" @change=${(e,t)=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&e.cardActionStatus^n.J.mute^n.J.hidden,"Mute",!0,e.cardActionClickHandler,e.providerId,!1,t.event,void 0,e.entryPoint)} slot="actions" data-t="${e=>e.telemetryContext?.mutePublisherButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.mutePublisherButtonText}</div></fluent-menu-item>${(0,o.z)(e=>!e.useUpdatedHideStoryStrings,(0,i.qy)`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.reportButtonText} menu item`} title=${e=>e.reportButtonText} id="Report" @change=${e=>e.openReportDialog&&e.openReportDialog(e.currentCardData)} slot="actions" data-t="${e=>e.telemetryContext?.reportButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.reportButtonText}</div></fluent-menu-item>`)}
`,s=(0,i.qy)`<fluent-menu-item tabindex="0" aria-label=${e=>e.goodRecommendationButtonText} title=${e=>e.goodRecommendationButtonText} id="GoodRecommendation" @change=${e=>e.onGoodRecommendationButtonClick()} slot="actions" data-t="${e=>e.telemetryContext?.goodRecommendationButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.goodRecommendationButtonText}</div></fluent-menu-item>${(0,o.z)(e=>!e.isFollowingPublisher,(0,i.qy)`<fluent-menu-item tabindex="0" aria-label=${e=>e.followPublisherButtonText} title=${e=>e.followPublisherButtonText} id="FollowPublisher" @change=${e=>e.onFollowPublisherButtonClick()} slot="actions" data-t="${e=>e.telemetryContext?.followPublisherButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.followPublisherButtonText}</div></fluent-menu-item>`)}<fluent-menu-item tabindex="0" aria-label=${e=>e.manageInterestsButtonText} title=${e=>e.manageInterestsButtonText} id="ManageInterests" @change=${e=>e.personalizeButtonCallback&&e.personalizeButtonCallback()} slot="actions" data-t="${e=>e.telemetryContext?.manageInterestsButton?.getMetadataTag()}"><div class="menu-item-text">${e=>e.manageInterestsButtonText}</div></fluent-menu-item>`,l=(0,i.qy)`<style>msn-hide-story-card { container-type: inline-size; } msn-hide-story-card.hide-feedback { --heading-line-height: var(--type-ramp-plus-1-line-height); --heading-font-size: var(--type-ramp-plus-1-font-size); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback, msn-hide-story-card[card-size="_2x_1y"].hide-feedback, msn-hide-story-card[card-size="0.5u"].hide-feedback { --heading-line-height: var(--type-ramp-base-line-height, 20px); --heading-font-size: var(--type-ramp-base-font-size, 14px); } msn-hide-story-card[card-size="_1x_1y"] fluent-menu-item#Report, msn-hide-story-card[card-size="0.5u"] fluent-menu-item#Report { display: none; } msn-hide-story-card.hide-feedback fluent-menu-item { width: 78.6%; max-width: 240px; text-align: center; display: block; border-radius: 20px; margin: 0 auto 8px; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback:not(.hide-confirm)::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback:not(.hide-confirm)::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback:not(.hide-confirm)::part(content-region) { padding-top: 20px; padding-inline: 20px; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo { width: 18px; margin-inline-end: 10px; margin-top: 11px; color: var(--neutral-foreground-rest); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo:hover>svg>path, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo:hover>svg>path, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo:hover>svg>path { transition: all 0.5s ease 0s; d: path(var(--undo-filled-path)); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo svg, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo svg, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo svg { transform: translate(3px, 3px); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo:focus, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo:focus, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo:focus { background: transparent; } msn-hide-story-card[card-size="_1x_1y"] .menu-item-text, msn-hide-story-card[card-size="_2x_1y"] .menu-item-text, msn-hide-story-card[card-size="0.5u"] .menu-item-text { margin-top: 1px; } msn-hide-story-card fluent-menu-item::part(control) { width: 236px; } msn-hide-story-card[card-size="_2x_1y"].hide-feedback::part(content-region) { width: 500px; } msn-hide-story-card.hide-feedback::part(content-region) { width: 78.67%; margin: 0 auto; text-align: center; justify-content: center; --content-region-padding-top: 38px; } msn-hide-story-card[card-size="0.75u"].hide-feedback::part(content-region) { --content-region-padding-top: 24px; } msn-hide-story-card.hide-feedback.has-subtitle::part(content-region) { --content-region-padding-top: 24px; } msn-hide-story-card::part(heading) { -webkit-line-clamp: var(--heading-max-lines, 3) } msn-hide-story-card::part(action-region) { display: block; position: static; margin: auto; } .menu-item-text { margin-top: 5px; padding: 0 8px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }</style><msn-hide-story-card class="hide-feedback ${e=>e.enableInstantHide?"instant-hide":""}" hideStoryTitle=${e=>e.hideStoryTitleData.text} data-text=${e=>e.hideStoryTitleData.dataTag} card-size=${e=>e.cardSize} data-t="${e=>e.telemetryContext?.hideStoryCard?.getMetadataTag()}" role="group" aria-labelledby="heading"><span class="heading" part="heading" slot="heading" id="heading" role="heading" aria-level="2">${e=>e.hideStoryTitleData.text}</span>${(0,o.z)(e=>"like-button"===e.entryPoint,s)} ${(0,o.z)(e=>"like-button"!==e.entryPoint,d)}<fluent-menu-item tabindex="0" class="stealth-button" aria-label=${e=>`${e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText} menu item`} title=${e=>e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText} id="Undo" @keydown=${(e,t)=>{if(t.event?.key!=="Enter"&&t.event?.key!==" ")return!0;e.undoHideButtonCallback&&e.undoHideButtonCallback(t.parent)}} @change=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()} slot="actions" data-t="${e=>e.telemetryContext?.cancelButton?.getMetadataTag()}" style="--undo-filled-path:'M-0.000976562 0.75C-0.000976562 0.335786 0.334809 0 0.749023 0C1.16324 0 1.49902 0.335786 1.49902 0.75V3.84461L4.17206 1.17157C5.73416 -0.390524 8.26682 -0.390524 9.82891 1.17157C11.391 2.73367 11.391 5.26633 9.82891 6.82843L4.87896 11.7784C4.58607 12.0713 4.1112 12.0713 3.8183 11.7784C3.52541 11.4855 3.52541 11.0106 3.8183 10.7177L8.76825 5.76777C9.74456 4.79146 9.74456 3.20854 8.76825 2.23223C7.79194 1.25592 6.20903 1.25592 5.23272 2.23223L2.96495 4.5H5.24902C5.66324 4.5 5.99902 4.83579 5.99902 5.25C5.99902 5.66421 5.66324 6 5.24902 6H0.849023C0.379581 6 -0.000976562 5.61944 -0.000976562 5.15V0.75Z'";>${(0,o.z)(e=>e.cardSize!=r.uE._1x_1y&&e.cardSize!=r.uE._2x_1y&&e.cardSize!=r.uE._05u,(0,i.qy)`<div class="menu-item-text">${e=>e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText}</div>`)} ${(0,o.z)(e=>e.cardSize==r.uE._1x_1y||e.cardSize==r.uE._2x_1y||e.cardSize==r.uE._05u,(0,i.qy)`<svg width="11" height="12" viewBox="0 0 15 16" xmlns="http://www.w3.org/2000/svg"><path d="M0.000976562 0.5C0.000976562 0.223858 0.224834 0 0.500977 0C0.77712 0 1.00098 0.223858 1.00098 0.5V4.34262L4.17202 1.17157C5.73412 -0.390524 8.26678 -0.390524 9.82888 1.17157C11.391 2.73367 11.391 5.26633 9.82888 6.82843L4.80375 11.8536C4.60849 12.0488 4.2919 12.0488 4.09664 11.8536C3.90138 11.6583 3.90138 11.3417 4.09664 11.1464L9.12177 6.12132C10.2933 4.94975 10.2933 3.05025 9.12177 1.87868C7.9502 0.707107 6.0507 0.707107 4.87913 1.87868L1.75781 5H5.50098C5.77712 5 6.00098 5.22386 6.00098 5.5C6.00098 5.77614 5.77712 6 5.50098 6H0.600977C0.269607 6 0.000976562 5.73137 0.000976562 5.4V0.5Z"/></svg>`)}</fluent-menu-item></msn-hide-story-card>`},58623(e,t,a){a.d(t,{X:()=>l});var i=a(89757),o=a(69259),n=a(44978),r=a(69828),d=a(2881),s=a(73195);a(99659).k,s.F;let l=(0,i.qy)`<style>${(0,o.z)(e=>e.enableInstantHide,(0,i.qy)` msn-animated-done-spinner[card-size="_1x_1y"].check-icon, msn-animated-done-spinner[card-size="_2x_1y"].check-icon, msn-animated-done-spinner[card-size="0.5u"].check-icon { padding-top: 0; padding-bottom: 16px; } msn-hide-story-card[card-size="_1x_1y"].instant-hide fluent-button:first-of-type, msn-hide-story-card[card-size="_2x_1y"].instant-hide fluent-button:first-of-type, msn-hide-story-card[card-size="0.5u"].instant-hide fluent-button:first-of-type { margin-inline-end: 8px; } msn-hide-story-card[card-size="_1x_1y"].instant-hide fluent-button, msn-hide-story-card[card-size="_2x_1y"].instant-hide fluent-button, msn-hide-story-card[card-size="0.5u"].instant-hide fluent-button { width: 130px; display: inline-flex; margin: 0; box-sizing: border-box; -webkit-box-sizing: border-box; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback.instant-hide::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback.instant-hide::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback.instant-hide::part(content-region) { padding-top: 12px; } msn-hide-story-card.instant-hide::part(content-region) { padding-top: 46px; } msn-hide-story-card .check-icon.instant-hide { padding-bottom: 32px; align-items: center; flex-direction: column; } msn-hide-story-card .personalize-text { font-size: var(--type-ramp-base-font-size, 14px); line-height: var(--type-ramp-base-line-height, 20px); margin-top: 20px; text-align: center; padding: 0 20px; } msn-hide-story-card .personalize { color: var(--stealth-button-text-color) } `)} msn-hide-story-card { container-type: inline-size; } msn-hide-story-card[card-size="1u"] { --animated-spinner-size: 18%; } msn-hide-story-card[card-size="_2x_2y"] { --animated-spinner-size: 8.25%; } @container (width<290px) { msn-animated-done-spinner.check-icon { padding: 7% 0px !important; } } @container (width<270px) { msn-animated-done-spinner.check-icon { padding: 5% 0px !important; } } msn-hide-story-card[card-size="_1x_1y"].hide-confirm, msn-hide-story-card[card-size="_2x_1y"].hide-confirm, msn-hide-story-card[card-size="0.5u"].hide-confirm { --heading-line-height: var(--type-ramp-base-line-height, 20px); --heading-font-size: var(--type-ramp-base-font-size, 14px); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback.hide-confirm::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback.hide-confirm::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback.hide-confirm::part(content-region) { padding-top: 16px; } msn-hide-story-card.hide-confirm { --heading-line-height: var(--type-ramp-plus-1-line-height); --heading-font-size: var(--type-ramp-plus-1-font-size); } msn-hide-story-card.hide-confirm fluent-button { width: 100%; max-width: 236px; text-align: center; display: block; border-radius: 20px; margin: 0 auto 8px; } msn-hide-story-card.hide-confirm fluent-button::part(control):focus-visible { border: none; box-shadow: none; } msn-hide-story-card fluent-button::part(control) { width: inherit; display: -webkit-box; overflow: hidden; -webkit-box-orient: vertical; text-overflow: ellipsis; } msn-hide-story-card.hide-confirm::part(content-region) { width: 78.67%; margin: 0 auto; text-align: center; padding-top: 38px; } msn-hide-story-card[card-size="0.75u"].hide-confirm::part(content-region) { padding-top: 16px; } msn-hide-story-card::part(heading) { -webkit-line-clamp: var(--heading-max-lines, 3) } msn-hide-story-card::part(action-region) { display: block; position: static; margin: auto; text-align: center; } .check-icon { display: flex; justify-content: center; fill: var(--neutral-foreground-rest); padding-bottom: 36px; } msn-animated-done-spinner.check-icon { padding-top: 20px; padding-bottom: 26px; } msn-animated-done-spinner[card-size="0.75u"].check-icon { padding-top: 8px; padding-bottom: 12px; }</style><msn-hide-story-card class="hide-feedback hide-confirm ${e=>e.enableInstantHide?"instant-hide":""}" hideStoryTitle=${e=>e.hideStoryTitleData.text} data-text=${e=>e.hideStoryTitleData.dataTag} card-size=${e=>e.cardSize} data-t="${e=>e.telemetryContext?.hideStoryCard?.getMetadataTag()}" role="group" aria-labelledby="heading">${(0,o.z)(e=>!e.enableInstantHide&&e.cardSize!=r.uE._1x_1y&&e.cardSize!=r.uE._2x_1y,(0,i.qy)`<div slot="actions" class="check-icon">${(0,i.qy)`<svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><path d="M19.9999 0C31.0456 0 39.9999 8.9543 39.9999 20C39.9999 31.0457 31.0456 40 19.9999 40C8.95424 40 -6.10352e-05 31.0457 -6.10352e-05 20C-6.10352e-05 8.9543 8.95424 0 19.9999 0ZM28.6338 13.6161C28.1782 13.1605 27.4584 13.1301 26.9676 13.525L26.8661 13.6161L16.7499 23.7322L13.1338 20.1161C12.6457 19.628 11.8542 19.628 11.3661 20.1161C10.9104 20.5717 10.8801 21.2915 11.2749 21.7824L11.3661 21.8839L15.8661 26.3839C16.3217 26.8395 17.0415 26.8699 17.5323 26.475L17.6338 26.3839L28.6338 15.3839C29.122 14.8957 29.122 14.1043 28.6338 13.6161Z"/></svg>`}</div>`)} ${(0,o.z)(e=>e.enableInstantHide,(0,i.qy)`<msn-animated-done-spinner slot="actions" class="check-icon" pre-text="${e=>e.blockedAdvertiser?e.feedbackHideAdvertiser:e.hideConfirmationUpdatingFeedText}" post-text="${e=>e.hideConfirmationDoneText}" card-size=${e=>e.cardSize} enable-two-line="${e=>e.showAdFeedback&&e.enableReportAdDialog&&e.blockedAdvertiser}" :spinnerCompletedCallback="${e=>"like-button"===e.entryPoint?e.likeEntryPointSpinnerCompleteCallback:e.cardActionDismissCallback}"></msn-animated-done-spinner>`)} ${(0,o.z)(e=>!e.enableInstantHide,(0,i.qy)`<fluent-button slot="actions" aria-label=${e=>e.refreshFeedButtonText} title=${e=>e.refreshFeedButtonText} id="Refresh" @click=${e=>e.refreshFeedCallback&&e.refreshFeedCallback()} data-t="${e=>e.telemetryContext?.refreshFeedButton?.getMetadataTag()}">${e=>e.refreshFeedButtonText}</fluent-button><fluent-button slot="actions" class="stealth-button" aria-label=${e=>e.personalizeButtonTextData.text} title=${e=>e.personalizeButtonTextData.text} data-text=${e=>e.personalizeButtonTextData.dataTag} id="Personalize" @click=${(e,t)=>e.personalizeButtonCallback&&e.personalizeButtonCallback(p(e.cardActionStatus),t.event)} data-t="${e=>e.telemetryContext?.confirmButton?.getMetadataTag()}" data-customhandled="true">${e=>e.personalizeButtonTextData.text}</fluent-button>`)} ${(0,o.z)(e=>e.enableInstantHide,(0,i.qy)` ${(0,o.z)(e=>!e.showAdFeedback||!e.enableReportAdDialog,(0,i.qy)`<fluent-button slot="actions" class="instant-hide" aria-label=${e=>e.personalizeButtonTextData.text} title=${e=>e.personalizeButtonTextData.text} data-text=${e=>e.personalizeButtonTextData.dataTag} id="Personalize" @click=${function(e,t){let a=e.cardActionStatus;return!e.useAlternativeStrings&&e.undoHideButtonCallback&&c(a)?e.undoHideButtonCallback():e.personalizeButtonCallback&&e.personalizeButtonCallback(p(e.cardActionStatus),t.event)}} data-t="${e=>e.telemetryContext?.confirmButton?.getMetadataTag()}" data-customhandled="true">${e=>e.personalizeButtonTextData.text}</fluent-button>`)}<fluent-button slot="actions" class="stealth-button instant-hide" aria-label=${e=>e.undoHideButtonText} title=${e=>e.undoHideButtonText} tabindex="0" id="Undo" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback(void 0,c(e.cardActionStatus,e.enableReportAdDialog))} data-t="${e=>e.telemetryContext?.confirmationUndoButton?.getMetadataTag()}">${e=>e.undoHideButtonText}</fluent-button>`)}</msn-hide-story-card>`;function c(e,t){if(t)return!!(e&(n.J.hidden^n.J.hideAds^n.J.adFeedbackSubmitted));let a=n.J.hide|n.J.hidden,i=n.J.mute|n.J.report|n.J.showFewer|n.J.showMore|n.J.dismiss|n.J.hideAds;return!!(e&a)&&!(e&i)}let p=e=>e&n.J.mute?d.$.sectionIds.mutedPublishers:d.$.sectionIds.discoverInterests},89228(e,t,a){a.d(t,{j:()=>r});var i=a(89757),o=a(69259),n=a(68835);a(99659).k;let r=(0,i.qy)`<style>msn-hide-story-card { container-type: inline-size; } @container (width<290px) or ((width>400px) and (width<592px)) { msn-hide-story-card.report-ad fluent-radio-group { height: fit-content !important; overflow: visible !important; } msn-hide-story-card.report-ad::part(action-region) { margin: 15px 0px 0px 0px !important; } msn-hide-story-card.report-ad .ad-actions-button-container { height: 30% !important; } } @container (width<275px) or ((width>400px) and (width<562px)) { msn-hide-story-card.report-ad::part(action-region) { margin: 10px 0px 0px 0px !important; padding: 0px 14px 14px 21px !important; } msn-hide-story-card.report-ad .ad-actions-button-container { height: 26% !important; } } msn-hide-story-card.report-ad { background: var(--hide-story-background); z-index: 3; } msn-hide-story-card.report-ad::part(content-region) { flex-direction: row; margin: 0; text-align: left; padding: 16px 16px 0px 24px; } msn-hide-story-card.report-ad.block-adv::part(content-region) { text-align: start; padding-block: 17px 2px; padding-inline: 50px 50px; --heading-max-lines: 1; } msn-hide-story-card.report-ad::part(action-region) { display: block; height: 100%; position: static; margin: 26px 0px 0px 0px; padding: 0px 16px 16px 24px; } msn-hide-story-card.report-ad.block-adv::part(action-region) { margin: 0px 0px 0px 0px; } msn-hide-story-card.report-ad fluent-radio-group { padding: 0 4px; height: 144px; overflow-y: auto; } msn-hide-story-card.report-ad.block-adv fluent-radio-group { padding: 0 0px; overflow-y: unset; height: 152px; padding-bottom: 11px; } msn-hide-story-card.report-ad fluent-button { width: 45%; display: inline-block; margin: auto 5px 8px; text-align: center; } msn-hide-story-card.report-ad fluent-radio { padding: 8px 0px 8px 0px; margin: 0; display: flex; } msn-hide-story-card.report-ad.block-adv fluent-radio { padding: 8px 0px 4px 0px; margin: 0; display: inline-flex; align-items: center; gap: 2px; } msn-hide-story-card.report-ad.block-adv fluent-radio::part(label) { display: inline-block; max-width: 211px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } msn-hide-story-card.report-ad fluent-button::part(content) { text-overflow: ellipsis; overflow: hidden; } msn-hide-story-card.report-ad fluent-button::part(control) { width: 100%; letter-spacing: inherit; line-height: inherit; word-spacing: inherit; } msn-hide-story-card.report-ad .ad-actions-button-container { display: flex; height: 33%; } msn-hide-story-card.report-ad .ad-actions-checkbox-container { display: none; } msn-hide-story-card.report-ad.block-adv .ad-actions-checkbox-container.block-adv { border-top: 0.5px solid rgba(0, 0, 0, 0.08); display: block; padding-top: 6px; padding-bottom: 4px; } msn-hide-story-card.report-ad.block-adv .ad-actions-checkbox-container.block-adv fluent-checkbox::part(label) { display: inline-block; max-width: 211px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } .svg-row { width: 20px; height: 20px; background-image: url("${e=>e.adFeedbackProps?.icons.titleIcon}"); background-size: contain; background-repeat: no-repeat; position: absolute; inset-inline-start: 23px; top: 18px; z-index: 4; } msn-hide-story-card.report-ad.block-adv .ad-actions-button-container { display: flex; position: absolute; bottom: 12px; left: 16px; justify-content: center; align-items: center; height: 32px; margin-top: auto; width: 90%; margin-top: 5px; } msn-hide-story-card.report-ad.block-adv fluent-button.submit, msn-hide-story-card.report-ad.block-adv fluent-button.cancel { flex-basis: 50%; min-width: 0; border-radius: 4px; margin: 0 5px; /* Add margin to create space between buttons */ } msn-hide-story-card.report-ad.block-adv fluent-button.cancel { font-weight: 600; box-shadow: inset 0 0 0 2px var(--neutral-fill-hover); background: var(--neutral-fill-rest); } msn-hide-story-card.report-ad.block-adv fluent-radio.checked::part(control) { border-color: #0078d4; } msn-hide-story-card.report-ad.block-adv fluent-radio.checked::part(checked-indicator) { inset: 2px; background: #0078d4; left: 3px; bottom: 3px; }</style>${(0,o.z)(e=>e.adFeedbackProps.configOptions?.enableAdBlockAdvertiser,(0,i.qy)`<div class="svg-row"></div>`)}<msn-hide-story-card hideStoryTitle=${e=>{let{configOptions:t,localizedStrings:a}=e.adFeedbackProps;return t?.enableAdBlockAdvertiser?a?.feedbackReportAdTitle??a.reportIssueTitleText:a.reportIssueTitleText}} title=${e=>{let{configOptions:t,localizedStrings:a}=e.adFeedbackProps;return t?.enableAdBlockAdvertiser?a?.feedbackReportAdTitle??a.reportIssueTitleText:a.reportIssueTitleText}} class="report-ad${e=>e.adFeedbackProps.configOptions?.enableAdBlockAdvertiser?" block-adv":""}"><fluent-radio-group slot="actions" value="${e=>e.adFeedbackProps.selectedFeedbackType}" @change=${(e,t)=>e.adFeedbackProps.chooseFeedbackOption(t.event)} orientation="vertical">${(0,n.ux)(e=>e.adFeedbackProps.feedbackTypes,(0,i.qy)`<fluent-radio value=${e=>e.value} id=${e=>e.value} aria-label=${e=>e.text} title=${e=>e.text} class=${(e,t)=>t.parent.adFeedbackProps.selectedFeedbackType===e.value?"checked":""}>${e=>e.text}</fluent-radio>`)}</fluent-radio-group><div class="ad-actions-checkbox-container${e=>e.adFeedbackProps.disableSubmitButton||!0!=e.adFeedbackProps.showBlockAdvertiser?"":" block-adv"}" slot="actions"><fluent-checkbox id="blockAdvertiser" aria-label=${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck} title=${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck} data-t="${e=>e.adFeedbackProps.generateTelemetryData("adFeedbackBlockAdvertiser")?.getMetadataTag?.()}" @change=${(e,t)=>e.adFeedbackProps.toggleBlockAdvertiser(t.event)}>${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck}</fluent-checkbox></div><div class="ad-actions-button-container" slot="actions"><fluent-button appearance="accent" class="submit" ?disabled=${e=>e.adFeedbackProps.disableSubmitButton} aria-label=${e=>e.adFeedbackProps.localizedStrings.saveButtonText} title=${e=>e.adFeedbackProps.localizedStrings.saveButtonText} data-t="${e=>e.adFeedbackProps.generateTelemetryData("adFeedbackSubmit")?.getMetadataTag?.()}" @click=${e=>e.adFeedbackProps.submitFeedback()}>${e=>e.adFeedbackProps.localizedStrings.saveButtonText}</fluent-button><fluent-button appearance="neutral" class="cancel" aria-label=${e=>e.adFeedbackProps.localizedStrings.cancelText} title=${e=>e.adFeedbackProps.localizedStrings.cancelText} data-t="${e=>e.adFeedbackProps.generateTelemetryData("Cancel")?.getMetadataTag?.()}" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()}>${e=>e.adFeedbackProps.localizedStrings.cancelText}</fluent-button></div></msn-hide-story-card>`},71733(e,t,a){a.d(t,{pK:()=>eC,Bq:()=>eS,DO:()=>eR});var i,o,n=a(89757),r=a(69259),d=a(25786),s=a(33533),l=a(87906),c=a(40450),p=a(69828),g=a(26330),h=a(46659),m=a(27314),u=a(56911),f=a(92011),y=a(60815);class v extends f.L{}(0,u.Cg)([y.sH],v.prototype,"data",void 0);var x=a(68835),b=a(53715),C=a(693),$=a(48566),w=a(63456),k=a(2188);let T=(0,n.qy)`
    <style>
        :host {
            grid-area:${e=>e.gridArea};
        }
        .card-button {
            border-radius: 100%;
        }
    </style>
    <fluent-card
        id="native_ad_${e=>e.id}"
        style="grid-area:${e=>e.gridArea};height: ${e=>e.ContentCardImageSizes._300x304.height}px;"
        class="${e=>e.cardSize}"
    >
        <msn-pattern-overlay-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
            layout=${e=>(0,w.A)(e,"template.landscapeOverlay",!1)?"landscape":"default"}
            shopNowText=${e=>(0,w.A)(e.localizedStrings,"nativeAdShopNowText")}
            price=${e=>(0,w.A)(e,"assets.salePrice")||(0,w.A)(e,"assets.price")}
        >
            ${(0,n.qy)`<span>${e=>e.title}</span>`}
            ${e=>(0,w.A)(e,"template.landscapeOverlay",!1)?e.renderImage("media",e.ContentCardImageSizes._300x174,e.ContentCardImageSizes._300x174):e.renderImage("media",e.ContentCardImageSizes._300x225,e.ContentCardImageSizes._300x225)}
            ${(0,n.qy)`
    ${(0,r.z)(e=>e.template.landscapeOverlay,(0,n.qy)`
        <msft-attribution slot="${e=>e.hasAnyInlineDecoration?"call-to-action-two-lines":"call-to-action-one-line"}">
            <!-- price, when salePrice is present, use salePrice as the actual price -->
            ${(0,r.z)(e=>(0,w.A)(e,"assets.salePrice")||(0,w.A)(e,"assets.price"),(0,n.qy)`
                <decoration-price data=${e=>e.assets.salePrice||e.assets.price} largeFont="false"></decoration-price>
            `)}
            ${(0,r.z)(e=>e.hasAnyInlineDecoration,(0,n.qy)`
                <div>
                    ${e=>{var t;return t=e,(0,w.A)(t,"assets.installmentPrice")&&(0,w.A)(t,"assets.price")?(0,n.qy)`
            <decoration-installment-price
                data="${e=>e.assets.installmentPrice}"
                price-format-now="${e=>(0,w.A)(e.localizedStrings,"nativeAdInstallmentPriceFormatNow")}"
                price-format-plan="${e=>(0,w.A)(e.localizedStrings,"nativeAdInstallmentPriceFormatPlan")}"
            ></decoration-installment-price>
        `:(0,w.A)(t,"assets.rating")?(0,n.qy)`<decoration-rating rating="${t.assets.rating}" count="${t.assets.likes}" />`:(0,w.A)(t,"assets.curbsidePickup")?(0,n.qy)`<decoration-curbside-pickup data="${t.localizedStrings.nativeAdCurbsidePickupText}" />`:(0,w.A)(t,"assets.freeShipping")?(0,n.qy)`<decoration-free-shipping data="${t.localizedStrings.nativeAdFreeShippingText}" />`:(0,w.A)(t,"assets.salePrice")&&(0,w.A)(t,"assets.price")?(0,n.qy)`
            <div>
                <div style="display: inline-block;"><decoration-price-strike-through data="${t.assets.price}"/></div>
                <div style="display: inline-block;"><decoration-price-off data=" &bull; ${$.Qf.Format(t.localizedStrings.nativeAdOnSaleText,t.assets.discount)}" /></div>
            </div>
        `:(0,n.qy)`<div />`}}
                </div>
            `)}
        </msft-attribution>
    `)}
    ${(0,r.z)(e=>!e.template.landscapeOverlay,(0,n.qy)`
        <!-- when it's not landscape layout, only show price on left bottom if price or sale price is available, otherwise show "Shop now" -->
        <msft-attribution slot="call-to-action-two-lines">
            <decoration-price data=${e=>(0,w.A)(e,"assets.salePrice")||(0,w.A)(e,"assets.price")||e.localizedStrings.nativeAdShopNowText} largeFont="false"/>
        </msft-attribution>
    `)}
`}
            ${e=>e.renderStartSection("start-actions",e.destinationUrl)}
            ${e=>e.renderEndSection("end-actions")}
        </msn-pattern-overlay-card>
    </fluent-card>
`;var S=a(30337),F=a(30383),z=a(53690);function A(e){let t=Number(e.template&&e.template.desiredWidth||e.imageData.imageWidth),a=Number(e.template&&e.template.desiredHeight||e.imageData.imageHeight),i=Math.floor(142*t/a),o=Math.floor(252*a/t);if(e.template&&"msn-river-z-index-9-by-16"===e.template.templateType)return{w:113,h:202};if(e.template&&"msn-river-z-index-3-by-4"===e.template.templateType)return{w:113,h:150};if(e.template?.templateType==="msn-river-animated-imagery-9-by-16")return{w:141,h:250};if(e.template&&e.template.desiredRatio){if("1.91x1"===e.template.desiredRatio)return{w:252,h:o};else if("1x1"===e.template.desiredRatio||"4x3"===e.template.desiredRatio||"16x9"===e.template.desiredRatio)return{w:i,h:142}}return i>252?{w:252,h:o}:{w:i,h:142}}var L=a(73888);F._t,F.aM,z.MsnZIndexCard;let M=(0,n.qy)`
    <div slot="image-with-badge">
        <img
            src="${e=>e.imageData.source}"
            alt="${e=>e.imageData.altText}"
            style="
                background: white;
                border-top-right-radius: ${e=>e.template?.templateType==="msn-river-animated-imagery-9-by-16"?"calc(var(--layer-corner-radius) * 1px)":"unset"};
                border: ${e=>e.template?.templateType==="msn-river-animated-imagery-9-by-16"?"unset":"10px solid #FFFFFF"};
                filter: ${e=>e.template?.templateType==="msn-river-animated-imagery-9-by-16"?"unset":"drop-shadow(0px 0px 4px rgba(0, 0, 0, 0.25))"};
                width: ${e=>A(e).w}px;
                min-width: ${e=>A(e).w}px;
                height: ${e=>A(e).h}px;
                min-height: ${e=>A(e).h}px;
                object-fit: cover;
            "
        />
    </div>
`,_=(0,n.qy)`
    <fluent-card
        id="native_ad_${e=>e.id}"
        style="
            background: unset;
            border-radius: unset;
            box-shadow: unset;
            grid-area:${e=>e.gridArea};
            height: ${e=>e.ContentCardImageSizes._300x304.height+16}px;
            left: -8px;
            position: relative;
            top: -8px;
            width: ${e=>e.ContentCardImageSizes._300x304.width+16}px;
        "
        class="${e=>e.cardSize}"
    >
        <msn-z-index-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            ?image-priority=${e=>e.imagePriority}
            layout=${e=>(0,b.gJ)(e)}
            heading-max-lines=${e=>(0,b.Rw)(e)}
            document-direction=${e=>(0,b.NL)(document.dir,e)} 
            data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e=>e.renderTitle()}
            <!--
                For now z-index only supports 1x_2y and with image data, here the assumption is that's the only configuration will be sent to z-index.
            -->
            <div slot="media">
                <style>
                    :host {
                        --z-index-image-width: ${e=>A(e).w}px;
                        --z-index-image-height: ${e=>A(e).h}px;
                        --heading-max-lines: ${e=>e.hasAnyInlineDecoration?2:3};
                    }
                </style>
                ${(0,r.z)(e=>e.badge,(0,n.qy)`
                    <msn-z-index-image-badge-decorator
                        badgeType=${e=>e.badge.type}
                        text=${e=>e.badge.text}
                        layout=${e=>(0,b.gJ)(e)}
                    >
                        <div slot="image-with-badge" part="image-with-badge">
                            ${M}
                        </div>
                    </msn-z-index-top-image-badge-decorator>
                `)}
                ${(0,r.z)(e=>!e.badge,(0,n.qy)`
                    ${M}
                `)}
            </div>
            ${e=>(0,b.JF)(L.T)(e)}
            ${e=>e.renderStartSection("start-actions",e.destinationUrl)}
            ${e=>e.renderEndSection("end-actions")}
        </msn-z-index-card>
    </fluent-card>
`,B=(0,n.qy)`
    <msn-ad-carousel-slide>
        <img slot="carousel-slide-content" class="carousel-item" src= ${e=>e.imageUrl} />
    </msn-ad-carousel-slide>
`,I=(0,n.qy)`
    .carousel-item {
        width: 100%;
        height: 100%;
        object-fit: cover; 
    }
    :host {
        border-radius: unset;
        box-shadow: unset;
        grid-area:${e=>e.gridArea};
        height: ${e=>e.ContentCardImageSizes._300x304.height+4}px;
        position: relative;
        width: ${e=>e.ContentCardImageSizes._300x304.width+4}px
    }
`,q=(0,n.qy)`
    <style>
        ${I}
    </style>
    <fluent-card 
        id="native_ad_${e=>e.id}"
        style="
            border-radius: unset;
            box-shadow: unset;
            grid-area:${e=>e.gridArea};
            height: ${e=>e.ContentCardImageSizes._300x304.height+4}px;
            position: relative;
            width: ${e=>e.ContentCardImageSizes._300x304.width+4}px
        "
        class="${e=>e.cardSize}"
    >
        <msn-ad-carousel-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            ?image-priority=${e=>e.imagePriority}
            data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e=>e.renderTitle()}
            ${(0,n.qy)`
    <div slot="${"media"}" style="width: 300px;height: 180px;">
        <msn-ad-carousel 
            cardId=${e=>e.id} 
            visibleSlideCount = "3" 
            :updateActiveIndex=${e=>e.activeItemChangedHandler}
        >
            ${(0,x.ux)(e=>e.carouselData,B)}
        </msn-ad-carousel>
    </div>
`}
            ${e=>e.renderStartSection("start-actions",e.destinationUrl)}
            ${e=>e.renderEndSection("end-actions")}
        </msn-ad-carousel-card>
    </fluent-card>
`,D=(e={})=>(0,n.qy)`
    <style>
        msn-animation-decorator img.crop {
            position: relative;
            left: -44px;
        }
    </style>
    <msn-animation-decorator
        effectId=${e=>e.id}
        showMultiTimes
        animationType=${e=>e.template?.animatedImage}
        :animationConfig=${e=>e.template?.animatedConfig}
        intersectionRootMargin="-160px 0px 0px 0px"
    >
        ${t=>t.renderImageTag("anim-content",e)}
    </msn-animation-decorator>
`,E=(0,n.qy)`
    <style>
        :host {
            height: ${e=>e.ContentCardImageSizes._300x304.height}px;
            grid-area: ${e=>e.gridArea};
        }
        .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.nativeAdVideo-river::part(media) {
            z-index: 2;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.wideIconMargin msft-ad-label {
            margin-right: 8px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        /* override default call-to-action style from msft-content-card */
        msft-attribution.native-ad-river-card {
            z-index: unset;
            bottom: 42px;
            position: absolute;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.native-ad-content-card::part(heading-container) {
            background: var(--fill-color);
        }
        msft-content-card.native-ad-content-card::part(media-wrapper) {
            height: 156px;
            transition: height  0.3s;
            overflow: hidden;
        }
        msft-content-card.two-lines-heading::part(heading) {
            --heading-max-lines: 2;
        }
    </style>
    <fluent-card
        id="native_ad_${e=>e.id}"
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        <msft-content-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            ?image-priority=${e=>e.imagePriority}
            class="two-lines-heading ${e=>e.getContentCardClassnames(e)}"
            data-t="${e=>e.adTelemetryContext.nativeAdCard.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e=>e.renderTitle()}
            ${e=>e.videoProps?e.renderVideo("media",e.ContentCardImageSizes._300x156):((e,t,a={})=>(0,n.qy)`
    <!--
        Only use placeholder when the card size is 1x_2y
    -->
    ${(0,r.z)(e=>e.cardSize===e.FeedLayoutCardSize._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;">
            ${D(a)}
        <div>
    `)}
    ${(0,r.z)(e=>e.cardSize===e.FeedLayoutCardSize._1x_2y&&!e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;"></div>
    `)}
    ${(0,r.z)(e=>e.cardSize!==e.FeedLayoutCardSize._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}">
            ${D(a)}
        </div>
    `)}
`)("media",e.ContentCardImageSizes._300x156)}
            ${e=>e.renderStartSection(e.isProviderInHeader?"attribution":"start-actions",e.destinationUrl)}
            ${e=>e.renderEndSection("end-actions")}
        </msft-content-card>
    </fluent-card>
`,H=(0,n.qy)`
    <style>
        :host {
            grid-area:${e=>e.gridArea};
        }
    </style>
    <fluent-card
        id="native_ad_${e=>e.id}"
        style="
            height: ${e=>e.ContentCardImageSizes._300x304.height}px;
        "
        class="${e=>e.cardSize}"
    >
        <msn-slideshow
            :images="${e=>e.images}"
            :imageData="${e=>e.imageData}"
            :autoScroll="${e=>e.slideshowProps.autoScroll}"
            :autoScrollIntervalMs="${e=>e.slideshowProps.autoScrollIntervalMs}"
            :enableMediaControls="${e=>e.slideshowProps.enableSlideshowMediaControls}"
            :destinationUrl=${e=>e.destinationUrl}
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            :badge=${e=>e.badge}
            data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            ${(0,k.Ib)(!0,!0,!0)}
            title=${e=>e.title}
        >
            ${e=>e.renderTitle()}
            ${e=>e.renderStartSection("start-actions",e.destinationUrl)}
            ${e=>e.renderEndSection("end-actions")}
        </msn-slideshow>
    </fluent-card>
`,P=(0,n.qy)`
    <template>
        <style>
            msft-content-card.native-ad-content-card:hover::part(media-wrapper) {
                transition: height  0.3s;
                overflow: hidden;
                height: ${e=>e.data.hoverState?.isDecorationLinesExpanded?"116px":""}
            }
        </style>
        ${(0,x.ux)(e=>[e.data],(0,n.qy)`
            ${e=>(e=>{let t="msn-z-index-card"===(0,b.zT)(e),a="msn-river-animated-imagery-9-by-16"===(0,b.zT)(e),i="msn-river-z-index-9-by-16"===(0,b.zT)(e),o="msn-river-z-index-3-by-4"===(0,b.zT)(e),n="msn-slideshow-card"===(0,b.zT)(e),r="msn-pseudo-video-card"===(0,b.zT)(e),d="msn-pattern-overlay-card"===(0,b.zT)(e),s="msn-ad-carousel"===(0,b.zT)(e),l=!!e.assets&&!(0,C.A)(e.assets),c="msft-content-card"===(0,b.zT)(e)&&e.template?.animatedImage&&e.template?.animatedConfig,p="msn-call-to-action-v3"===(0,b.zT)(e),g=e.template?.immersiveThemeColor;if(d)return T;if(l||g||p)return S.cC;if(t||a||i||o)return _;if(s)return q;if(c)return E;else if(n||r)return H})(e)}
        `)}
    </template>
`;var R=a(95239),U=a(59669);let N=(0,U.A)` msft-content-card fluent-button::part(control){padding:0}msft-content-card.nativeAdVideo-river::part(media){z-index:2}msft-content-card::part(footer){padding:0 16px 4px;margin-bottom:0;height:40px}msft-content-card.wideIconMargin msft-ad-label{margin-inline-end:8px}msft-attribution{position:relative;overflow:hidden}msft-attribution.native-ad-river-card{bottom:42px;position:absolute;z-index:unset}msft-content-card span.title_1x_2y,msft-content-card span.title_1x_3y{font-size:20px}msft-content-card.native-ad-content-card::part(heading-container){background:${R.p}}msft-content-card.native-ad-content-card::part(media-wrapper){height:156px;transition:height 0.3s;overflow:hidden}msft-content-card.two-lines-heading::part(heading){--heading-max-lines:2}msft-content-card.three-lines-heading::part(heading){--heading-max-lines:3}msft-article msft-attribution[slot="attribution"].margin-5-decoration{margin-bottom:5px}`.withBehaviors(new class{constructor(e,t,a){this.propertyPath=e,this.value=t,this.styles=a}connectedCallback(e){let{source:t}=e;y.cP.getNotifier(t).subscribe(this,this.propertyPath),this.handleChange(t,this.propertyPath)}disconnectedCallback(e){let{source:t}=e;y.cP.getNotifier(t).unsubscribe(this,this.propertyPath),t.$fastController.removeStyles(this.styles)}handleChange(e,t){(0,w.A)(e,t)===this.value?e.$fastController.addStyles(this.styles):e.$fastController.removeStyles(this.styles)}}("data.template.nativeAdMode","adult",(0,U.A)` .card-button:not(:hover){background:transparent}`));class O extends v{}let V=(0,m.A)(()=>{(0,f.E)({name:"msn-native-ad-card-template-facade",template:P,styles:N})(O)});class G extends f.L{}(0,u.Cg)([y.sH],G.prototype,"nativeAdHpStripeData",void 0);let Z=(0,n.qy)`
    ${(0,x.ux)(e=>[e.nativeAdHpStripeData],(0,n.qy)`
        <msft-content-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            ?image-priority=${e=>e.imagePriority}
            data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e=>e.title}
            ${e=>e.renderImageTag("media",h.L._300x200)}
            <msft-attribution slot="start-actions">
                ${e=>e.providerData.name}
            </msft-attribution>
            <div slot="end-actions"></div>
        </msft-content-card>
    `)}
`,W=(0,U.A)` msft-content-card{--heading-max-lines:3}msft-content-card msft-attribution{margin-inline-start:-13px}msft-content-card img[slot="media"]{width:306px;height:200px;object-fit:cover}`;class j extends G{}let J=(0,m.A)(()=>{(0,f.E)({name:"msn-native-ad-hp-stripe-card",template:Z,styles:W})(j)});class X extends f.L{}(0,u.Cg)([y.sH],X.prototype,"nativeAdArticleData",void 0);let Y=(0,n.qy)`
    ${(0,x.ux)(e=>[e.nativeAdArticleData],(0,n.qy)`
        <msft-article-card
            size="${e=>e.cardSize}"
            card-fill-color=${e=>e.adBackgroundColor}
        >
            <msft-article
                id="native_ad_${e=>e.id}"
                href=${e=>e.destinationUrl}
                target="_blank"
                title=${e=>e.title}
                ?image-priority=${e=>e.imagePriority}
                class="${e=>e.getArticleCardClassnames(e)}"
                data-t="${e=>e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
                :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
                ${(0,k.Ib)()}
            >
                ${e=>e.createNativeAdFaviconWithProviderName}
                ${e=>e.renderTitle()}
                ${e=>e.videoProps?e.renderVideo("image",h.L._300x169,!0):e.renderImage("image",h.L._300x225)}
                ${e=>e.invertSlugPosition?e.renderStartSection("start-action",e.destinationUrl):e.renderStartSection("attribution",e.destinationUrl)}
                ${e=>e.renderEndSection("end-action")}
            </msft-article>
        </msft-article-card>
    `)}
`;var K=a(22062),Q=a(91277),ee=a(60124);let et=(0,U.A)` msft-article-card{height:100%;width:100%}msft-ad-label{margin-inline-end:8px}msft-article.native-ad,msft-article.${(0,Q.nP)("native-ad")}{--article-native-ad-heading-margin-bottom:40px;--heading-max-lines:3}msft-article.nativeAdVideo-river::part(image){z-index:2}msft-article.native-ad.gradient,msft-article.${(0,Q.nP)("native-ad")}.gradient{--article-native-ad-actions-height:33px;--article-native-ad-heading-margin-bottom:6px}msft-article.native-ad::part(heading),msft-article.${(0,Q.nP)("native-ad")}::part(heading){margin-bottom:var(--article-native-ad-heading-margin-bottom);color:var(--msft-card-font-color)}msft-article.native-ad.long-gradient::part(gradient),msft-article.${(0,Q.nP)("native-ad")}.long-gradient::part(gradient){top:-55px}msft-attribution{max-width:100%}msft-article.native-ad::part(actions),msft-article.${(0,Q.nP)("native-ad")}::part(actions){height:var(--article-native-ad-actions-height);align-items:center}msft-article-card[size="_1x_2y"] msft-article.native-ad[class*="zoom-ratio"]:not(.no-image)::part(gradient):after,msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}[class*="zoom-ratio"]:not(.no-image)::part(gradient):after{content:"";height:10px;width:100%;bottom:-5px;position:absolute;background:var(--gradient-mid-color)}@media (prefers-color-scheme:light){.white-gradient::part(article){background:#f7f7f7;--gradient-mid-color:#f7f7f7;--gradient-color:#f7f7f7;--msft-card-font-color:black}}@media (prefers-color-scheme:dark){.white-gradient::part(article){background:#242424;--gradient-mid-color:#242424;--gradient-color:#242424;--msft-card-font-color:white}}msft-article span.title_1x_2y,msft-article span.title_2x_2y{font-size:20px}msft-article.long-gradient::part(gradient){top:-55px}msft-article-card[size="_1x_2y"] msft-article[class*="zoom-ratio"]:not(.no-image)::part(gradient):after{content:"";height:10px;width:100%;bottom:-5px;position:absolute;background:var(--gradient-mid-color)}msft-attribution{position:relative;overflow:hidden}${ee.Y.getArticleCardHoverGradientStyle()} `.withBehaviors(new K.X(["nativeAdArticleData"],e=>{if(!e||!e.nativeAdArticleData)return(0,U.A)``;let t=e.nativeAdArticleData,a="";return t.isAdSlugV4NonDr&&(a+=`msft-article.native-ad::part(heading), msft-article.${(0,Q.nP)("native-ad")}::part(heading){--heading-max-lines:2}`),t.layoutGap&&(a+=`msft-article-card[size="_1x_2y"] msft-article::part(gradient){bottom:${67+t.layoutGap}px}msft-article-card[size="_2x_2y"] msft-article::part(gradient){bottom:0px}`),t.useTitleFontSize&&(a+=`msft-article-card msft-article.native-ad, msft-article-card msft-article.${(0,Q.nP)("native-ad")}{--msft-article-heading-font-size:${t.useTitleFontSize}px;
                    --msft-article-heading-line-height: 24px;
                }
            
                msft-article-card msft-article.native-ad::part(attribution), msft-article-card msft-article.${(0,Q.nP)("native-ad")}::part(attribution){height:28px}msft-article-card[size="_1x_2y"] msft-article.native-ad:not(.no-image)::part(heading),msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}:not(.no-image)::part(heading){margin-bottom:11px}msft-article-card[size="_1x_2y"] msft-article.native-ad:not(.no-image)::part(gradient),msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}:not(.no-image)::part(gradient){background:linear-gradient(180deg,transparent 0%,var(--gradient-mid-color) 46%,var(--gradient-color) 100%);top:5px}`),t.alignFooters&&(a+=`msft-article-card msft-article::part(heading):after{top:calc(100% - ${t.fixedCardHeight?304:292+(t.layoutGap||12)}px - 8px) !important}msft-article::part(text){margin-bottom:-8px}msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient){top:-29px;bottom:calc(${t.fixedCardHeight?79:67+(t.layoutGap||12)}px + 8px)}msft-article.no-image::part(actions){bottom:calc(var(--msft-article-padding) * 1px - 8px)}`),t.region===s.Tp.rightRail&&t.renderFlattenedDesign&&(a+="msft-article-card{box-shadow:none}"),"Bierstadt"===t.fontFamilyOnCardContent&&(a+='msft-article-card msft-article::part(heading){font-family:Bierstadt,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--msft-article-heading-line-height:24px;--heading-max-lines:3}msft-article-card msft-article p[slot="abstract"]{font-family:Bierstadt,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--abstract-font-size:15px}msft-article-card msft-article msft-attribution::part(content){font-family:Bierstadt,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;font-size:calc(var(--type-ramp-minus-1-font-size) + 1px)}'),"Grandview"===t.fontFamilyOnCardContent&&(a+='msft-article-card msft-article::part(heading){font-family:Grandview,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--msft-article-heading-line-height:24px;--heading-max-lines:3}msft-article-card msft-article p[slot="abstract"]{font-family:Grandview,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif}msft-article-card msft-article msft-attribution::part(content){font-family:Grandview,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif}'),"Seaford"===t.fontFamilyOnCardContent&&(a+='msft-article-card msft-article::part(heading){font-family:Seaford,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--msft-article-heading-line-height:24px;--heading-max-lines:3}msft-article-card msft-article p[slot="abstract"]{font-family:Seaford,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--abstract-font-size:15px}msft-article-card msft-article msft-attribution::part(content){font-family:Seaford,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;font-size:calc(var(--type-ramp-minus-1-font-size) + 1px)}'),"Tenorite"===t.fontFamilyOnCardContent&&(a+='msft-article-card msft-article::part(heading){font-family:Tenorite,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--msft-article-heading-line-height:24px;--heading-max-lines:3}msft-article-card msft-article p[slot="abstract"]{font-family:Tenorite,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;--abstract-font-size:16px}msft-article-card msft-article msft-attribution::part(content){font-family:Tenorite,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;font-size:calc(var(--type-ramp-minus-1-font-size) + 2px)}'),(0,U.A)` :host{grid-area:${t.gridArea}}msft-article-card msft-article::part(heading):after{top:calc(100% - ${t.fixedCardHeight?304:292+(t.layoutGap||12)}px)}msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient){bottom:${t.fixedCardHeight?77:65+(t.layoutGap||12)}px}${a} `}));class ea extends X{}let ei=(0,m.A)(()=>{(0,f.E)({name:"msn-native-ad-article-card",template:Y,styles:et})(ea)});var eo=a(77387),en=a(94164),er=a(47264),ed=a(38493),es=a(66864),el=a(45183);let ec=class extends es.t{constructor(){super(...arguments),this.faviconText="",this.landingPage=""}};(0,u.Cg)([(0,ed.CF)({attribute:"favicon-text"})],ec.prototype,"faviconText",void 0),(0,u.Cg)([(0,ed.CF)({attribute:"landing-page"})],ec.prototype,"landingPage",void 0),(0,u.Cg)([(0,ed.CF)({attribute:"tel-metadata"})],ec.prototype,"telemetryMetadata",void 0),ec=(0,u.Cg)([(0,el.TA)(c.PDj,"msn-native-ad-favicon")],ec);var ep=a(16559);let eg=(0,U.A)` .native-ad-favicon-wrapper{width:16px;height:16px;background:#F2F2F2;border-radius:4px;align-items:center;text-align:center;justify-content:center;display:flex}.native-ad-favicon-text{color:#4D1C3A;font-size:12px;width:100%;height:100%;text-decoration:none}`.withBehaviors(new ep.e("layoutStyle")),eh=(0,n.qy)`<div class="native-ad-favicon-wrapper"><a class="native-ad-favicon-text" href=${e=>e.landingPage} data-t="${e=>e.telemetryMetadata}">${e=>e.faviconText}</a></div>`;class em extends ec{}let eu=(0,m.A)(()=>{(0,f.E)({name:"msn-native-ad-favicon",template:eh,styles:eg,shadowOptions:{delegatesFocus:!0}})(em)});var ef=a(66459);let ey=(0,el.sx)(c.SuG,"getFaviconLetter")(e=>{if(!e)return"M";let t=e.trim();if(!t)return"M";let a=t.split(" ");if(a.length>1){let e=a[0].toLowerCase();return"the"===e||"a"===e||"an"===e?a[1][0].toUpperCase():e[0].toUpperCase()}return t[0].toUpperCase()});var ev=a(82988),ex=a(4670);ef.j,(i=o||(o={})).Long="long",i.Short="short";let eb=(0,n.qy)`
${(0,r.z)(e=>e.providerData&&e.destinationUrl&&e.isAdSlugV4NonDr,(0,n.qy)`
    <msft-attribution slot="attribution">
        <msn-native-ad-favicon
            favicon-text="${e=>ey((0,d.d7)(e.providerData.name))}"
            slot="image"
            landing-page=${e=>e.destinationUrl}
            tel-metadata=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
        >
        </msn-native-ad-favicon>
        ${(0,r.z)(e=>e.providerData,(0,n.qy)`
            ${e=>eS(e.destinationUrl)}
        `)}
    </msft-attribution>
`)}
`,eC=e=>(0,n.qy)`
    ${(0,r.z)(e=>e.isGreyAdsLabelEnabled,(0,n.qy)`
        <msn-native-ad-ad-label
            privacy-url=${e=>e.privacyUrl}
            destination-url=${e=>e.destinationUrl}
            type="greyLabel"
            slot="${e=>e.providerAboveHeader?"start-actions":"image"}"
            should-adjust-gap=${t=>!e&&[...s.mL,...s.Yw,s.Tp.riverdb,s.Tp.rightRail].includes(t.region)}
            ad-label-text=${e=>e.adLabelText}
            tel-metadata=${e=>(0,ex.j1)(e.adTelemetryContext)}
            id="${e=>e.id}-ad-label"
            enable-safe-ads=${e=>e.enableSafeAds}
            hide-ad-label-and-ad-choice=${e=>e.hideAdLabelAndAdChoice}
            enable-ad-sponsored-text=${e=>e.enableAdSponsoredText}
        >
        </msn-native-ad-ad-label>
    `)}
    ${(0,r.z)(e=>!e.isGreyAdsLabelEnabled,(0,n.qy)`
        <msn-native-ad-ad-label
            privacy-url=${e=>e.privacyUrl}
            destination-url=${e=>e.destinationUrl}
            type=${e=>e.adSlugGA||e.region===s.Tp.rightRail?"defaultLabel":"greenLabel"}
            slot="${e=>e.providerAboveHeader?"start-actions":"image"}"
            should-adjust-gap=${t=>!e&&s.vx.includes(t.region)||t.unifyMode&&s.EF.includes(t.region)}
            ad-label-text=${e=>e.adLabelText}
            tel-metadata=${e=>(0,ex.j1)(e.adTelemetryContext)}
            ad-label-text-opacity=${e=>e.adLabelTextOpacity??"0.7"}
            ad-label-font-size=${e=>e.adLabelFontSize}
            id="${e=>e.id}-ad-label"
            is-msn-hp-ad-slug=${e=>e.isMsnHPAdSlug}
            enable-safe-ads=${e=>e.enableSafeAds}
            hide-ad-label-and-ad-choice=${e=>e.hideAdLabelAndAdChoice}
            enable-ad-sponsored-text=${e=>e.enableAdSponsoredText}
            ${!(0,ex.jj)()?(0,k.Ib)(!0,!1):""}
        >
        </msn-native-ad-ad-label>
    `)}
`,e$=()=>(0,n.qy)`
    ${(0,r.z)(e=>!e.isAnaheimDesign,(0,n.qy)`${e=>e.title}`)}
    ${(0,r.z)(e=>e.isAnaheimDesign&&e.feedFontSize,(0,n.qy)`
        <span style="font-size: ${e=>e.feedFontSize}px;
            ${e=>e.headingLineHeight?`line-height: ${e.headingLineHeight}px;`:""}
        ">
            ${e=>e.title}
        </span>`)}
    ${(0,r.z)(e=>e.isAnaheimDesign&&!e.feedFontSize,(0,n.qy)`
        ${(0,r.z)(e=>!e.useSmallFontSize,(0,n.qy)`<span class="title${e=>e.cardSize}">${e=>e.title}</span>`)}
        ${(0,r.z)(e=>e.useSmallFontSize,(0,n.qy)`${e=>e.title}`)}
    `)}
`,ew=(e=null,t={})=>(0,n.qy)`
    <style>
        img.ltr.native-ad-crop {
            position: relative;
            left: -44px;
        }
        img.rtl.native-ad-crop {
            position: relative;
            right: -44px;
        }
        img[slot="anim-content"]{
            object-fit: cover;
            object-position: top;
        }
        img[id="nativead-1-img"], img[id="nativead-3-img"]{
            max-width: 100%;
            max-height: 100%;
        }
        img.boost-ad {
            top: 48px;
            left: 16px;
            width: 268px;
            height: 140px;
            position:absolute;
            border-radius: 8px;
            transition: unset;
            object-position: center;
        }
    </style>
    <img
        slot=${t=>e}
        id="${e=>e.id+"-img"}"
        src="${e=>e.imageData.source}"
        alt="${e=>e.imageData.altText}"
        width="${e=>(0,w.A)(t,"width",e.imageData.imageWidth)}"
        height="${e=>(0,w.A)(t,"height",e.imageData.imageHeight)}"
        @load=${(e,t)=>{(0,eo.mQ)(e,t,"NativeAdCardTemplate"),e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback()}}
        @error=${(e,t)=>{(0,eo.mQ)(e,t,"NativeAdCardTemplate"),e.imageData.visualReadinessCallback&&e.imageData.visualReadinessCallback(t.event),(0,en.T)({id:e.id+"-img",rLink:e.destinationUrl,imgLink:e.imageData.source,isBoost:eP(e)})}}
        class="${e=>document.dir} ${e=>e.useProng2AmplifyCardTemplate?"boost-ad":""} ${e=>e.isAnaheimDesign&&e.useArticleCardTemplate&&Number(e.imageData.imageWidth)>300?"native-ad-crop":""}"
    />
`,ek=(e,t,a={})=>(0,n.qy)`
    <!--
        Only use placeholder when the card size is 1x_2y
    -->
    ${(0,r.z)(e=>e.cardSize===p.uE._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;">
            ${ew("anim-content",a)}
        </div>
    `)}
    ${(0,r.z)(e=>e.cardSize===p.uE._1x_2y&&!e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;">
        </div>
    `)}
    ${(0,r.z)(e=>e.cardSize!==p.uE._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}">
            ${ew("anim-content",a)}
        </div>
    `)}
`,eT=(e,t,a)=>(0,n.qy)`
    ${(0,r.z)(e=>e.cardSize===p.uE._1x_2y,(0,n.qy)`
        <div slot="${e}"  
            class="ad-video-player ${e=>e.responsiveWidth?"responsive-width":""}"
            style="--ad-video-width: ${t.width}px;--ad-video-height: ${t.height}px;"
        >
            <native-ad-video-controls
                region="river"
                width=${t.width}
                height=${t.height}
                :destinationUrl=${e=>e.destinationUrl}
                :localizedStrings=${e=>e.localizedStrings}
            ></native-ad-video-controls>
            <native-ad-video-player
                :videoProps=${e=>e.videoProps}
                :backgroundImg=${e=>e.imageData}
                region="river"
                immersive=${a}
                width=${t.width}
                height=${t.height},
                :visualReadinessCallback=${e=>e.visualReadinessCallback}
            ></native-ad-video-player>
        </div>
    `)}
`,eS=e=>(0,n.qy)`
        <msn-native-ad-provider-name 
            ${(0,k.Ib)(!0,!1)}
            url="${e}"
            provider-name="${e=>e.adSlugGA&&e.providerData?(0,d.d7)(e.providerData.name):e.providerData.name}" 
            white-provider-name="${e=>{var t;return e.template&&(!!(t=e.template.templateType)&&"msn-slideshow-card"===t||!!t&&"msn-pseudo-video-card"===t)}}"
            keep-opacity=${e=>s.mL.includes(e.region)}
            ad-slug-ga=${e=>e.adSlugGA||e.region===s.Tp.rightRail}
            tel-metadata=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            has-elite-badge=${e=>!!e.assets?.eliteBadge}
            ad-label-text-opacity=${e=>e.adLabelTextOpacity??.7}
            :localizedStrings=${e=>e.localizedStrings}
            is-msn-hp-ad-slug=${e=>e.isMsnHPAdSlug}
        >
        </msn-native-ad-provider-name>
`,eF=(e,t,a)=>(0,n.qy)`
    ${(0,r.z)(e=>e.providerData,(0,n.qy)`
        <msft-attribution class="${e=>e.hideAdLabelAndAdChoice?"ad-label-and-choice-hidden":""}" slot="${e}" style="--design-unit: 0; overflow: hidden; ${e=>e.invertSlugPosition?"display: flex":""}">
            ${(0,r.z)(e=>!e.providerAboveHeader,eC(a))}
            ${eS(t)}
        </msft-attribution>
        ${(0,r.z)(e=>e.providerAboveHeader,eC(a))}
   `)}
`,ez=e=>(0,n.qy)`
    ${(0,r.z)(e=>e.adChoiceIconUrl,(0,n.qy)`
        <a
            href="${e=>e.adChoiceIconUrl}"
            target="_blank"
            class="${e=>e.hideAdLabelAndAdChoice?"ad-choice-hidden":""} ${e}"
            aria-label="${e=>e.localizedStrings&&e.localizedStrings.nativeAdAdChoiceText}"
            data-t="${e=>e.adTelemetryContext?.adChoice?.getMetadataTag()}"
            id="${e=>e.id}-ad-choice"
        >
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="filter:invert(71%) sepia(0%) saturate(0%) hue-rotate(332deg) brightness(95%) contrast(97%);">
                <path d="M4.52344 5.69531C4.70573 5.69531 4.86198 5.63542 4.99219 5.51562C5.1224 5.39062 5.1875 5.24219 5.1875 5.07031C5.1875 4.89844 5.1224 4.7526 4.99219 4.63281C4.86198 4.50781 4.70573 4.44531 4.52344 4.44531C4.33594 4.44531 4.17708 4.50781 4.04688 4.63281C3.91667 4.7526 3.85156 4.89844 3.85156 5.07031C3.85156 5.24219 3.91667 5.39062 4.04688 5.51562C4.17708 5.63542 4.33594 5.69531 4.52344 5.69531ZM1.44531 0.921875V0.929688C1.33594 0.861979 1.21875 0.828125 1.09375 0.828125C0.90625 0.828125 0.747396 0.890625 0.617188 1.01562C0.486979 1.13542 0.421875 1.28125 0.421875 1.45312V11.375C0.421875 11.5469 0.486979 11.6953 0.617188 11.8203C0.747396 11.9401 0.90625 12 1.09375 12C1.19271 12 1.28906 11.9792 1.38281 11.9375H1.39062L1.40625 11.9219L3.20312 11.0625C3.48958 10.9635 3.63281 10.7708 3.63281 10.4844C3.63281 10.3073 3.56771 10.1589 3.4375 10.0391C3.30729 9.91406 3.15104 9.85156 2.96875 9.85156C2.85417 9.85156 2.74479 9.8776 2.64062 9.92969C2.63542 9.9401 2.61979 9.95052 2.59375 9.96094C2.51042 10.0026 2.42188 10.0234 2.32812 10.0234C2.17188 10.0234 2.03906 9.97396 1.92969 9.875C1.82031 9.77083 1.76302 9.64844 1.75781 9.50781V3.375C1.76302 3.22917 1.82031 3.10677 1.92969 3.00781C2.03906 2.90365 2.17188 2.85156 2.32812 2.85156C2.41667 2.85156 2.5 2.8724 2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L8.53906 5.92188L8.64844 5.97656C8.8099 6.08594 8.89062 6.23177 8.89062 6.41406C8.89062 6.60677 8.80469 6.75521 8.63281 6.85938L8.5625 6.89844L5.1875 8.60938V6.67969C5.1875 6.5026 5.1224 6.35417 4.99219 6.23438C4.86198 6.11458 4.70573 6.05469 4.52344 6.05469C4.33594 6.05469 4.17708 6.11458 4.04688 6.23438C3.91667 6.35417 3.85156 6.5026 3.85156 6.67969V9.65625C3.85156 9.83333 3.91667 9.98177 4.04688 10.1016C4.17708 10.2214 4.33594 10.2812 4.52344 10.2812C4.65885 10.2812 4.78385 10.2448 4.89844 10.1719L11.125 7.00781C11.4271 6.90885 11.5781 6.71094 11.5781 6.41406C11.5781 6.14844 11.4453 5.95833 11.1797 5.84375L1.44531 0.921875ZM2.59375 9.96094C2.61979 9.95052 2.63542 9.9401 2.64062 9.92969L2.59375 9.96094ZM2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L2.57812 2.91406Z" fill="#00aecd"/>
            </svg>
        </a>
    `)}
`,eA=e=>(0,n.qy)`
    <style>
        .has-right-bottom-ads-bing-icon {
            position: absolute; right: 16px;
        }

        .has-preview-card-template-icon {
            position: absolute; right: 10px; bottom: 5px;
        }
        .has-preview-card-template-icon.image-end {
            right: 122px;
        }

        .native-ad .end-actions, .${(0,Q.nP)("native-ad")} .end-actions {
            display: flex; align-items: center;
        }

        .native-ad a.ad-choice-icon, .${(0,Q.nP)("native-ad")} a.ad-choice-icon {
            display: inline-flex; min-width: calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px);
        }

        .native-ad a.ad-choice-icon svg, .${(0,Q.nP)("native-ad")} a.ad-choice-icon svg {
            display: block; margin: auto;
        }

        a.ad-choice-icon.ad-choice-hidden, a.ad-choice-icon.ad-choice-hidden {
            max-width: 0px;
            min-width: 0px;
            visibility: hidden;
            width: 0;
            padding: 0;
            margin: 0;
            border: 0;
        }
    </style>
    <div slot="${e}" class="${e=>e.isRightBottomAdsBingIcon?"has-right-bottom-ads-bing-icon":""} ${e=>e.usePreviewCardTemplate?"has-preview-card-template-icon":""} end-actions ${e=>"end"===e.imagePosition?"image-end":""}">
        ${(0,ev.UN)()}
        ${(0,r.z)(e=>!e.template?.enableAdChoiceInCardActions,ez("ad-choice-icon"))}
        ${(0,r.z)(e=>e.isAdFeedbackV1Enabled&&!!e.feedbackUrl,(0,n.qy)`
            <div
                class="see-more-telemetry-wrapper"
                style="display: contents;"
                data-t="${e=>e.adTelemetryContext?.seeMore?.getMetadataTag()}"
            >
                ${g.L}
            </div>
        `)}
    </div>
`,eL=(0,n.qy)`
    <style>
        .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.nativeAdVideo-river::part(media) {
            z-index: 2;
        }
        msft-content-card::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.wideIconMargin msft-ad-label {
            margin-right: 8px;
        }
        msft-attribution {
            position: relative;
            overflow: hidden;
        }
        /* override default call-to-action style from msft-content-card */
        msft-attribution.native-ad-river-card {
            z-index: unset;
            bottom: 42px;
            position: absolute;
        }
        msft-content-card span.title_1x_2y,
        msft-content-card span.title_1x_3y {
            font-size: 20px;
        }
        msft-content-card.native-ad-content-card::part(heading-container) {
            background: var(--fill-color);
        }
        msft-content-card.native-ad-content-card::part(media-wrapper) {
            height: 156px;
            transition: height  0.3s;
            overflow: hidden;
        }
        fluent-card[id^="native_ad_nativead-river"] msft-content-card.two-lines-heading::part(media-wrapper),
        fluent-card[id^="native_ad_nativead-resriver"] msft-content-card.two-lines-heading::part(media-wrapper) {
            overflow: hidden;
        }
        msft-content-card.two-lines-heading::part(heading) {
            --heading-max-lines: 2;
        }
        msft-content-card.three-lines-heading::part(heading) {
            --heading-max-lines: 3;
        }
    </style>
    <fluent-card
        id="native_ad_${e=>e.id}"
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        <msft-content-card
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            ?image-priority=${e=>e.imagePriority}
            class="two-lines-heading ${e=>eO(e)}"
            data-t="${e=>e.id&&e.adTelemetryContext?.nativeAdCard?.getMetadataTag()}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e$()}
            ${e=>e.videoProps?eT("media",h.L._300x156,!1):ek("media",h.L._300x156)}
            ${e=>eF(e.isProviderInHeader?"attribution":"start-actions",e.destinationUrl,!0)}
            ${eA("end-actions")}
        </msft-content-card>
    </fluent-card>
`,eM=(0,n.qy)`
    <style>
        .ad-video-player {
            height: var(--ad-video-height);
            width: var(--ad-video-width);
        }

        .ad-video-player.responsive-width {
            height: 100%;
            width: 100%;
        }
        
        msft-ad-label {
            margin-inline-end: 8px;
        }

        msft-article.native-ad, msft-article.${(0,Q.nP)("native-ad")} {
            --article-native-ad-heading-margin-bottom: 40px;
            --heading-max-lines: 2;
        }

        msft-article.nativeAdVideo-river::part(image) {
            z-index: 2;
        }

        msft-article.nativeAdVideo-river.responsive-width::part(image) {
            aspect-ratio: 300 / 169;
            height: auto;
            width: 100%;
        }

        msft-article.native-ad.gradient, msft-article.${(0,Q.nP)("native-ad")}.gradient {
            --article-native-ad-actions-height: 33px;
            --article-native-ad-heading-margin-bottom: 6px;
        }

        msft-article.native-ad::part(heading), msft-article.${(0,Q.nP)("native-ad")}::part(heading) {
            margin-bottom: var(--article-native-ad-heading-margin-bottom);
            color: var(--msft-card-font-color);
        }

        msft-article.native-ad.long-gradient::part(gradient), msft-article.${(0,Q.nP)("native-ad")}.long-gradient::part(gradient) {
            top: -55px;
        }

        ${(0,r.z)(e=>e.layoutGap,(0,n.qy)`
            msft-article-card[size="_1x_2y"] msft-article::part(gradient) {
                bottom: ${e=>67+e.layoutGap}px;
            }

            msft-article-card[size="_2x_2y"] msft-article::part(gradient) {
                bottom: 0px;
            }
        
            msft-article-card[size="_1x_2y"] {
                --card-height: ${e=>292+e.layoutGap}px;
                --card-width: 300px;
            }

            msft-article-card[size="_2x_2y"] {
                --card-height: ${e=>292+e.layoutGap}px;
                --card-width: ${e=>600+e.layoutGap}px;
            }
        `)}

        msft-article.native-ad msft-attribution, msft-article.${(0,Q.nP)("native-ad")} msft-attribution {
            max-width: 100%;
        }

        msft-article.native-ad::part(actions), msft-article.${(0,Q.nP)("native-ad")}::part(actions) {
            height: var(--article-native-ad-actions-height);
            align-items: center;
        }

        msft-article-card[size="_1x_2y"] msft-article.native-ad[class*="zoom-ratio"]:not(.no-image)::part(gradient):after,
        msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}[class*="zoom-ratio"]:not(.no-image)::part(gradient):after {
            content: "";
            height: 10px;
            width: 100%;
            bottom: -5px;
            position: absolute;
            background: var(--gradient-mid-color);
        }

        msft-article-card[size$="x_2y"] msft-article::part(heading):after {
          top: calc(100% - ${e=>e.fixedCardHeight?304:292+(e.layoutGap||12)}px);
        }

        ${(0,r.z)(e=>e.useTitleFontSize,(0,n.qy)`
            msft-article-card msft-article.native-ad, msft-article-card msft-article.${(0,Q.nP)("native-ad")} {
                --msft-article-heading-font-size: ${e=>e.useTitleFontSize}px;
                --msft-article-heading-line-height: 24px;
            }

            msft-article-card msft-article.native-ad::part(attribution), msft-article-card msft-article.${(0,Q.nP)("native-ad")}::part(attribution) {
                height: 28px;
            }

            msft-article-card[size="_1x_2y"] msft-article.native-ad:not(.no-image)::part(heading), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}:not(.no-image)::part(heading) {
                margin-bottom: 11px;
            }

            msft-article-card[size="_1x_2y"] msft-article.native-ad:not(.no-image)::part(gradient), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}:not(.no-image)::part(gradient) {
                background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 46%, var(--gradient-color) 100%);
                top: 5px;
            }
        `)}

        msft-article-card[size="_1x_2y"] msft-article.native-ad.gradient::part(gradient), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}.gradient::part(gradient) {
            top: 11px;
            background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 56%, var(--gradient-color) 100%);
        }

        msft-article-card[size="_1x_2y"] msft-article[id="native_ad_${e=>e.id}"]::part(gradient), msft-article-card[size="_1x_2y"] msft-article[id="${e=>(0,Q.nP)(`native_ad_${e.id}`)}"]::part(gradient) {
            top: 11px;
            background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 56%, var(--gradient-color) 100%);
        }

        ${(0,r.z)(e=>e.isNotNtpRiver,(0,n.qy)`
            msft-article-card[size="_1x_2y"] msft-article.native-ad:not(.no-image)::part(gradient), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("native-ad")}:not(.no-image)::part(gradient) {
                top: 18px;
                background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 56%, var(--gradient-color) 100%);
            } 
        `)}

        /** 
         * TODO Cleanup these two styles after the Linear feed right rail transparent-background ad flight is completed 
         * Or clean this up once this the right rail native ads card gets migrated to the NativeAdWC experience
         * Work item tracking the migration - https://msasg.visualstudio.com/Bing_Ads/_workitems/edit/3905327
        **/
        @media (prefers-color-scheme: light) {
            .white-gradient::part(article) {
                background: #f7f7f7;
                --gradient-mid-color: #f7f7f7;
                --gradient-color: #f7f7f7;
                --msft-card-font-color: black;
                --neutral-foreground-rest: #2E2E2E;
            }
        }
        @media (prefers-color-scheme: dark) {
            .white-gradient::part(article) {
                background: #242424;
                --gradient-mid-color: #242424;
                --gradient-color: #242424;
                --msft-card-font-color: white;
                --neutral-foreground-rest: #ffffff;
            }
        }
        
        /**
         *  To support high contrast mode for accessibility
        **/
        @media (forced-colors: active) {
            msft-article.native-ad::part(heading), msft-article.${(0,Q.nP)("native-ad")}::part(heading) {
                color: linktext;
            }
        }

    </style>
    <msft-article-card
        style="grid-area:${e=>e.gridArea};"
        size="${e=>e.cardSize}"
        card-fill-color=${e=>e.adBackgroundColor}
        class=""
    >
        <msft-article
            id="${e=>(0,Q.s4)(e.enableSafeAds,`native_ad_${e.id}`)}"
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            ?image-priority=${e=>e.imagePriority}
            class="${e=>eN(e)}"
            data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${eb}
            ${e$()}
            ${e=>e.videoProps?eT("image",h.L._300x169,!0):ek("image",h.L._300x225)}
            ${e=>e.invertSlugPosition?eF("start-action",e.destinationUrl):eF("attribution",e.destinationUrl)}
            ${eA("end-action")}
        </msft-article>
        ${(0,r.z)(e=>e.template?.enableAdChoiceInCardActions&&!!e.feedbackUrl,(0,n.qy)`
            <style>
                .see-more-telemetry-wrapper-card {
                    border-radius: 38px;
                    position: absolute;
                    top: 8px;
                    inset-inline-end: 8px;
                    z-index: 1;
                    opacity: 0;                    
                    pointer-events: none;
                    transition: opacity 0.15s ease;
                }
                msft-article-card:hover .see-more-telemetry-wrapper-card,
                .see-more-telemetry-wrapper-card:focus-within {
                    opacity: 1;
                    pointer-events: auto;
                }
            </style>
            <div
                class="see-more-telemetry-wrapper see-more-telemetry-wrapper-card"
                data-t="${e=>e.adTelemetryContext?.seeMore?.getMetadataTag()}"
            >
                ${g.L}
            </div>
        `)}
    </msft-article-card>
`;(0,n.qy)`
    <msn-native-ad-article-card :nativeAdArticleData=${e=>({...e,getArticleCardClassnames:eN,createNativeAdFaviconWithProviderName:eb,renderTitle:e$,renderVideo:eT,renderImage:ek,renderStartSection:eF,renderEndSection:eA})}
    >
    </msn-native-ad-article-card>
`;let e_=(0,n.qy)`
    <style>
        msft-article-card.msft-homepage-native-ad-card {
            height: 100%;
        }

        msft-article-card.msft-homepage-native-ad-card msft-ad-label {
            margin-inline-end: 8px;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad {
            --article-native-ad-heading-margin-bottom: 40px;
            --heading-max-lines: 3;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad.gradient {
            --article-native-ad-actions-height: 33px;
            --article-native-ad-heading-margin-bottom: 8px;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad::part(text) {
            display: flex;
            flex-flow: column-reverse;
            padding-bottom: 8px;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad::part(heading) {
            font-size: var(--msft-article-heading-font-size, 20px);
            margin-bottom: 15px;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad::part(gradient) {
            bottom: 0;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad::part(attribution) {
            max-width: 100%;
        }

        msft-article-card.msft-homepage-native-ad-card msft-article.native-ad::part(actions) {
            height: var(--article-native-ad-actions-height);
            align-items: center;
        }
    </style>
    <msft-article-card
        style="grid-area:${e=>e.gridArea}"
        size="${e=>e.cardSize}"
        class="msft-homepage-native-ad-card"
    >
        <msft-article
            id="native_ad_${e=>e.id}"
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            ?image-priority=${e=>e.imagePriority}
            class="${e=>eN(e)}"
            data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,k.Ib)()}
        >
            ${e$()}
            ${ek("image",h.L._300x225)}
            ${e=>eF("attribution",e.destinationUrl)}
            ${(0,r.z)(e=>e.gradientType,(0,n.qy)`
                <div slot="start-action"></div>
            `)}
            ${eA("end-action")}
        </msft-article>
    </msft-article-card>
`,eB=(0,n.qy)`
    <style>
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} {
            height: 100px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(body) {
            height: 100%;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution {
            position: relative;
            overflow: hidden;
            margin-top: 5px;
            margin-bottom: 0;
            max-height: 18px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(heading-container) {
            padding: 8px;
            padding-bottom: 0;
            display: flex;
            flex-flow: column-reverse;
            height: 100%;
            box-sizing: border-box;
            justify-content: space-between;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}.provider-top::part(heading-container) {
            flex-flow: column;
            height: 80px;
            justify-content: flex-start;
            gap: 4px;
        }

        ${e=>"end"===e.imagePosition?`
        msft-content-card.${(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(media-wrapper) {
            float: right;
            margin-top: unset;
            margin: 8px 8px 0px 0px;
            border-radius: calc(var(--content-card-corner-radius, 2) * 2px);
            overflow: hidden;
            max-height: 84px;
        }
        :host([direction="rtl"]) msft-content-card.${(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(media-wrapper) {
            float: left;
            margin: 8px 0px 0px 8px;
        }
            `:`
        msft-content-card.${(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(media-wrapper) {
            float: left;
            margin-top: unset;
            margin: 8px 0 0px 8px;
            border-radius: calc(var(--content-card-corner-radius, 2) * 2px);
            overflow: hidden;
            max-height: 84px;
        }
        :host([direction="rtl"]) msft-content-card.${(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(media-wrapper) {
            float: right;
            margin: 8px 8px 8px 0;
        }
            `}
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}::part(heading) {
            font-size: 14px;
            line-height: 20px;
        }  
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution {
            position: relative;
            overflow: hidden;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}.provider-top msft-attribution {
            margin-top: 0px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}.provider-top msn-native-ad-ad-label {
            position: absolute;
            left: 122px;
            bottom: 8px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}.provider-top.image-end msn-native-ad-ad-label {
            left: 10px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution msft-ad-label {
            margin-inline-end: 6px;
        }
        msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution msn-inline-group::part(inline-item) {
            margin-top: 3px;
            padding-left: 3px;
        }
        /* Set the max-width of attribution when ad choice is displayed */
        ${(0,r.z)(e=>e.adChoiceIconUrl,(0,n.qy)`
            msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution {
                /* attribution's width = parent'width - ad choice's width. Because the value of the CSS variable that ad choice's width depends on is different from the value in msft-attribution, we hardcode the ad choice's width here */
                max-width: calc(100% - 32px);
            }
        `)}
        ${(0,r.z)(e=>e.adChoiceIconUrl,(0,n.qy)`
            msft-content-card.${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} msft-attribution.ad-label-and-choice-hidden {
                max-width: 100%;
            }
        `)}
    </style>
    <fluent-card
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize} ${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")}-wrapper"
    >
    <msft-content-card
        id="contentcard_${e=>(0,Q.s4)(e.enableSafeAds,e.id)}"
        href=${e=>e.destinationUrl}
        target="_blank"
        title=${e=>e.disableCardTitleTooltip?"":e.title}
        style="--heading-max-lines: ${e=>e.headerMaxLines||3}"
        class="${e=>(0,Q.s4)(e.enableSafeAds,"msft-content-native-ad-preview")} ${e=>eO(e)}"
        style="--heading-max-lines: ${e=>e.hasAnyInlineDecoration?2:3}"
        data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
        :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
        ${(0,k.Ib)()}
    >
        ${e$()}
        ${ek("media",h.L._104x84)}
        ${e=>eF("attribution",e.privacyUrl)}
        ${eA("end-actions")}
        </msft-content-card>
    </fluent-card>
`,eI=(0,n.qy)`
    <fluent-card
        id="${e=>(0,Q.s4)(e.enableSafeAds,`native_ad_${e.id}`)}"
        style="grid-area:${e=>e.gridArea}"
        class="${e=>e.cardSize}"
    >
        <msn-native-ad-hp-stripe-card 
            :nativeAdHpStripeData=${e=>({...e,renderImageTag:ew})}
        >
        </msn-native-ad-hp-stripe-card>
    </fluent-card>
`,eq=(0,n.qy)`
    <msn-native-ad-card-template-facade
        :data=${e=>({...e,renderStartSection:eF,renderEndSection:eA,renderTitle:e$,renderImage:ek,renderImageTag:ew,nativeAdBeacons:k.Ib,getContentCardClassnames:eO,seeMoreButtonTemplate:g.L,ContentCardImageSizes:h.L,FeedLayoutCardSize:p.uE})}>
    </msn-native-ad-card-template-facade>
`,eD=(0,n.qy)`
    <style>
        .amplify-ad .end-actions {
            z-index: unset;
        }

        .amplify-ad a.ad-choice {
            display: inline-flex; min-width: calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px);
            bottom:23px;
            left:264px;
            position:absolute;
            z-index: 2;
        }

        .amplify-ad a.ad-choice.ad-choice-hidden{
            max-width: 0px;
            min-width: 0px;
            visibility: hidden;
            width: 0;
            padding: 0;
            margin: 0;
            border: 0;
        }

        .amplify-ad a.ad-choice svg {
            display: block; margin: auto;
        }

        div.ad-label-bottom {
            bottom:22px;
            color:rgba(255,255,255,0.7);
            font-size:12px;
            left:138px;
            pointer-events: none;
            position:absolute;
            width:123px;
        }

        fluent-button.join-now {
            backdrop-filter:blur(3px);
            background:rgba(255,255,255,0.09);
            border-radius:16px;
            bottom:16px;
            height:28px;
            width:105px;
        }

        ${(0,r.z)(e=>e.useProng2AmplifyCardTemplate,(0,n.qy)`
            fluent-button.boost-cta {
                bottom:5px;
                height:28px;
                width:105px;
                margin-inline-start: 85px;
                background-color: unset;
                width: 71px;
                height: 16px;
                font-weight: 400;
                font-size: 14px;
                line-height: 20px;
                position: relative;
                color: #003E92;
            }

            div.boost-attribution {
                position: absolute;
                width: 300px;
                height: 48px;
                left: 0px;
                bottom: 256px;
            }

            span.boost-logo {
                position: absolute;
                left: 5.33%;
                right: 89.33%;
                top: 28.33%;
                bottom: 33.33%;
            }

            span.boost-business {
                position: absolute;
                left: 13.33%;
                right: 24.33%;
                top: 33.33%;
                bottom: 33.33%;
                width: 200px;
                height: 16px;
                overflow: hidden;
                font-style: normal;
                font-weight: 400;
                font-size: 12px;
                line-height: 16px;
                opacity: 0.8956;
            }

            .boost-attribution .moreActionButton {
                position: absolute;
                left: 86.33%;
                top: 25.33%;
                bottom: 33.33%;
                z-index: 2;
                width: 24px;
                height: 24px;
                min-width: 24px;
                border-radius: 6px;
                --control-corner-radius: var(--more-actions-corner-radius);
            }

            .boost-attribution .moreActionButton:hover {
                background-color: var(--neutral-fill-hover);
            }

            .boost-attribution .moreActionButton:not(:hover) {
                background-color: transparent;
            }

            span.boost-title {
                width: 268px;
                height: 48px;   
                font-style: normal;
                font-weight: 600;
                font-size: 18px;
                line-height: 24px;
                position: relative;
                overflow: hidden;
                display: -webkit-box;    
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                margin-bottom: 6px;
            }

            msft-article-card[size="_1x_2y"] msft-article.amplify-ad:not(.no-image)::part(gradient), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("amplify-ad")}:not(.no-image)::part(gradient) {
                left: unset;
            } 

            msft-article-card[size="_1x_2y"] msft-article.amplify-ad:not(.no-image), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("amplify-ad")}:not(.no-image) {
                box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
                border-radius: 8px;
            }

            @media (prefers-color-scheme: light) {
                msft-article-card[size="_1x_2y"] msft-article.amplify-ad:not(.no-image), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("amplify-ad")}:not(.no-image) {
                    background: linear-gradient(124.33deg, rgba(255, 255, 255, 0) -20.01%, #E1FAFF 96.49%), #FFFFFF;
                    --neutral-foreground-rest: #1A1A1A;
                    --neutral-fill-hover: #e5e5e5;
        
                }
            }
    
            @media (prefers-color-scheme: dark) {
                msft-article-card[size="_1x_2y"] msft-article.amplify-ad:not(.no-image), msft-article-card[size="_1x_2y"] msft-article.${(0,Q.nP)("amplify-ad")}:not(.no-image) {
                    background: linear-gradient(122.8deg, rgba(0, 0, 0, 0.5) -40.78%, #0B282E 74.4%), linear-gradient(124.33deg, rgba(255, 255, 255, 0) -20.01%, #E1FAFF 96.49%), #FFFFFF;
                    --neutral-fill-hover: #484848;
                }
                
                fluent-button.boost-cta {
                    color: #60CDFF;
                }
            }
        `)}
    </style>
    <msft-article-card
        style="grid-area:${e=>e.gridArea};"
        size="${e=>e.cardSize}"
        card-fill-color=${e=>e.adBackgroundColor}
    >
        <msft-article
            id="native_ad_${e=>e.id}"
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.disableCardTitleTooltip?"":e.title}
            ?image-priority=${e=>e.imagePriority}
            class="amplify-ad ${e=>eN(e)}"
            data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
            :anchorTelemetryTag="${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}"
            ${(0,k.Ib)(!0,!0,!1)}
        >
            ${(0,n.qy)`
    ${(0,r.z)(e=>e.useProng2AmplifyCardTemplate,(0,n.qy)`
        <div class=${"boost-attribution"}>
            <span class="boost-logo">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <rect x="1.59998" y="1.6" width="5.6" height="5.6" fill="#F25022"/>
                    <rect x="8.79999" y="1.6" width="5.6" height="5.6" fill="#80BA01"/>
                    <rect x="8.79999" y="8.8" width="5.6" height="5.6" fill="#FFB902"/>
                    <rect x="1.59998" y="8.8" width="5.6" height="5.6" fill="#02A4EF"/>
                </svg>
            </span>
            <span class="boost-business">
                ${e=>e.prong2AmplifyBusinessName}
            </span>
            ${(0,n.qy)`
    <fluent-button
        class="moreActionButton"
        slot="more-actions"
        @click="${(e,t)=>e.toggleBoostActionMenu(t.event)}"
        data-t="${e=>e.adTelemetryContext?.moreOptionsClick?.getMetadataTag()}"
        role="button"
    >
        ${n.qy.partial(er.A)}
    </fluent-button>
`}
        </div>
    `)}
`}
            <span class=${e=>e.useProng2AmplifyCardTemplate?"boost-title":""} style="font-size:18px;">${e=>e.title}</span>
            ${ek("image",h.L._300x225)}
            <div slot="end-action" class="end-actions">
                <fluent-button aria-label=${e=>e.localizedStrings&&e.localizedStrings.nativeAdLearnMoreText} role="button" class=${e=>e.useProng2AmplifyCardTemplate?"boost-cta":"join-now"}>
                    ${e=>e.localizedStrings&&e.localizedStrings.nativeAdLearnMoreText}
                </fluent-button>
                <div class="ad-label-bottom">${e=>e.useProng2AmplifyCardTemplate?"":e.localizedStrings&&e.localizedStrings.nativeAdPromotedByText}</div>
                ${ez("ad-choice")}
            </div>
        </msft-article>
    </msft-article-card>
`,eE=(0,n.qy)`
    <msn-native-ad-wc
        id="native_ad_${e=>e.id}"
        class="native-ad-wce-wrapper"
        style="grid-area:${e=>e.gridArea};background: rgb(46, 46, 46);border-radius: 6px;"
        data-t="${e=>e.id?e.adTelemetryContext?.nativeAdCard?.getMetadataTag():""}"
        ${(0,k.Ib)(!1,!0)}
        :configRef=${e=>e.nativeAdWC?.configRef}
        :localizedStrings=${e=>e.localizedStrings}
        :adData=${e=>e}
    ></msn-native-ad-wc>
`,eH=(0,n.qy)`
    <cs-native-ad-card
        class="card-container"
        config-instance-src="${e=>e.configInstanceSrc||"default"}"
        :displaySettings=${e=>e.displaySettings}
        :data=${e=>e}
        style="grid-area:${e=>e.gridArea}"
        size="${e=>e.cardSize}"
        tabIndex="${e=>e.customTabIndex??0}"
    >
    </cs-native-ad-card>
`,eP=e=>e&&e.useProng2AmplifyCardTemplate,eR=(0,n.qy)`
    ${e=>eU(e)}
`,eU=e=>{let t="msft-content-card"===(0,w.A)(e,"template.templateType","msft-content-card"),a=e.useHomepageCardTemplate,i=e.usePreviewCardTemplate,o=e.useArticleCardTemplate,n=e.useArticleCardTemplate&&e.useSuperAdCard,r=e.nativeAdWC&&!e.disableAdsUXExperiment;if(r||(V(),J(),ei(),eu()),e.imageData||e.videoProps||!e.visualReadinessCallback||e.visualReadinessCallback(),e&&e.useAmplifyCardTemplate&&e.id&&e.id.indexOf("amplifyad")>=0||eP(e))return eD;if(e.videoProps)return eM;if(r)return eE;if((0,b.RB)(e)&&!e.disableAdsUXExperiment)return eq;if(t||(0,b.EW)(e)||e.disableAdsUXExperiment){let t;return"partners-stripe"==(t=e.region)||"promotion-stripe"==t||"recommended-stripe"==t||"shopping-stripe"==t?eI:a?e_:i?eB:o?n?eH:eM:eL}return(0,l.c_)(void 0,c.Ikd,"renderNativeAdCardTemplate failed to find a template for display and fell back to nativeAdArticleCardTemplate",JSON.stringify(e)),eM},eN=e=>{let t=(0,Q.s4)(e.enableSafeAds,"native-ad");return e.gradientType&&(t+=" gradient",e.gradientType===o.Long&&(t+=" long-gradient")),e.videoProps&&(t+=" nativeAdVideo-river"),e.useWhiteGradient&&(t+=" white-gradient"),e.responsiveWidth&&(t+=" responsive-width"),t},eO=e=>{let t=[];return(e.isProviderInHeader||e.isProviderInFooter)&&t.push("wideIconMargin"),e.providerAboveHeader&&t.push("provider-top"),"end"===e.imagePosition&&t.push("image-end"),e.videoProps&&t.push("nativeAdVideo-river"),e.isThreeLineHeading&&t.push("three-lines-heading"),t.join(" ")}},64186(e,t,a){a.d(t,{Wl:()=>s});var i=a(6711),o=a(24642),n=a(67860);let r=(0,o.el)(i.DE,i.l2,i.L6,i.tN,i.q,i.oj,i.Ws,i.Mc);function d(e){return t=>{let a=(0,n.xL)(t),o=r(t);return(0,n.FD)(a+(a>=o?-1:1)*e(t),(0,i.ro)(t))}}let s=(0,o.kT)(d(i.q)),l=(0,o.kT)(d(i.oj)),c=(0,o.kT)(d(i.Ws)),p=(0,o.kT)(d(i.Mc)),g=(0,o.kT)(d(i.pW));(0,o.kT)(e=>({rest:s(e),hover:l(e),active:c(e),focus:p(e),selected:g(e)}))},34768(e,t,a){a.d(t,{F7:()=>s,Xt:()=>l});var i=a(6711),o=a(24642),n=a(67860);let r=(0,o.el)(i.DE,i.l2,i.L6,i.tN);function d(e){return t=>{let a=(0,n.xL)(t),o=r(t);return(0,n.FD)(a+(a>=o?-1:1)*e(t),(0,i.ro)(t))}}let s=(0,o.kT)(d(i.DE)),l=(0,o.kT)(d(i.l2)),c=(0,o.kT)(d(i.L6)),p=(0,o.kT)(d(i.tN)),g=(0,o.kT)(d(i.SL));(0,o.kT)(e=>({rest:s(e),hover:l(e),active:c(e),focus:p(e),selected:g(e)}))},48421(e,t,a){a.d(t,{c:()=>s});var i=a(6711),o=a(24642),n=a(12051),r=a(67860);function d(e){var t;return t=i.ro,a=>{let o,d,s,l,c=(0,n.OB)(t,a),p=(0,r.ud)(a)?-1:1,g=(0,r.A2)(i.oR)(c)(r.HE)(()=>p)((0,r.EC)((0,n.OB)(e,a)))(a),h=(0,r.yB)(t,g)(a),m=(0,n.OB)(0,a),u=(0,n.OB)(0,a),f=(0,n.OB)(0,a),y=(0,n.OB)(0,a);return o=h+p*Math.abs(m-u),s=(d=1===p?m<u:p*m>p*u)?h:o,l=d?o:h,{rest:(0,r.FD)(s,c),hover:(0,r.FD)(l,c),active:(0,r.FD)(s+p*f,c),focus:(0,r.FD)(s+p*y,c)}}}let s=(0,o.sP)(o.TF.rest,(0,o.kT)(d(4.5)));(0,o.sP)(o.TF.rest,(0,o.kT)(d(3)))},52780(e,t,a){a.d(t,{J:()=>m});var i=a(56911),o=a(92011),n=a(38493),r=a(60815);class d extends o.L{toggleSelected(){this.internalToggle&&(this.selected=!this.selected),this.$emit("selected-state-changed")}connectedCallback(){super.connectedCallback(),this.button&&(this.button.control.title=this.selectTitle||"")}}(0,i.Cg)([(0,n.CF)({attribute:"data-icon"})],d.prototype,"dataIcon",void 0),(0,i.Cg)([(0,n.CF)({attribute:"layout"})],d.prototype,"layout",void 0),(0,i.Cg)([(0,n.CF)({attribute:"fill-color-selected"})],d.prototype,"fillColorSelected",void 0),(0,i.Cg)([(0,n.CF)({attribute:"filled-icon-path"})],d.prototype,"filledIconPath",void 0),(0,i.Cg)([(0,n.CF)({attribute:"select-icon"})],d.prototype,"selectIcon",void 0),(0,i.Cg)([(0,n.CF)({attribute:"unselect-icon"})],d.prototype,"unselectIcon",void 0),(0,i.Cg)([(0,n.CF)({attribute:"select-title"})],d.prototype,"selectTitle",void 0),(0,i.Cg)([(0,n.CF)({attribute:"unselect-title"})],d.prototype,"unselectTitle",void 0),(0,i.Cg)([(0,n.CF)({attribute:"animation-text"})],d.prototype,"animationText",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean"})],d.prototype,"selected",void 0),(0,i.Cg)([(0,n.CF)({attribute:"select-telemetry-tag"})],d.prototype,"selectTelemetryTag",void 0),(0,i.Cg)([(0,n.CF)({attribute:"unselect-telemetry-tag"})],d.prototype,"unselectTelemetryTag",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean"})],d.prototype,"internalToggle",void 0),(0,i.Cg)([r.sH],d.prototype,"template",void 0);var s=a(59669);let l=(0,s.A)` fluent-button{border-radius:100px}fluent-button.fill-color-selected svg{fill:var(--fill-color-selected)}fluent-button.filled-icon-hover{background:transparent;min-width:20px;height:20px}fluent-button.filled-icon-hover::part(control){width:20px}fluent-button.filled-icon-hover svg{width:20px;height:20px}fluent-button.filled-icon-hover:hover > svg > path{transition:all 0.5s;d:path(var(--filled-path))}fluent-button.filled-icon-hover,fluent-button.no-backplate:not(:hover){background:transparent}fluent-button.expand::part(control){padding:0}fluent-button.light-background{background-color:#F5F5F5;--neutral-foreground-rest:#2B2B2B}.button-content{display:flex;flex-direction:row;align-items:center;padding-inline-start:8px;animation:padding-icon 0.3s linear 2s 1 forwards}.button-content > span{font-size:var(--type-ramp-minus-1-font-size);padding-inline-start:6px;padding-inline-end:10px;display:inline-block;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.button-content > svg{max-height:16px}.disappear{animation:disappear 0.3s ease-out 2s forwards;max-width:165px}.expand{border-radius:100px;max-width:210px}@keyframes disappear{to{width:0;padding-inline:0;overflow:hidden;opacity:0;display:none}}@keyframes padding-icon{to{padding-inline-start:0}}`;var c=a(89757),p=a(60402),g=a(69259);let h=(0,c.qy)`<fluent-button class=${e=>`${"fillediconhover"===e.layout?"filled-icon-hover":""} ${"nobackplate"===e.layout?"no-backplate":""} ${e.fillColorSelected&&e.selected?" fill-color-selected":""} ${e.template?.enableAdChoiceInCardActions?"light-background":""}`} data-icon=${e=>e.dataIcon} appearance="neutral" style="--filled-path: '${e=>e.filledIconPath}'; --fill-color-selected: ${e=>e.fillColorSelected};" aria-label=${e=>e.selectTitle} aria-pressed=${e=>e.selected} title=${e=>e.selected?e.unselectTitle:e.selectTitle} @click=${e=>e.toggleSelected&&e.toggleSelected()} data-t="${e=>e.selected?e.unselectTelemetryTag:e.selectTelemetryTag}" ${(0,p.K)("button")}>${(0,g.z)(e=>e.selected,(0,c.qy)` ${(0,g.z)(e=>"animated"!==e.layout,(0,c.qy)` ${e=>(0,c.qy)`${c.qy.partial(e.selectIcon||"")}`} `)} ${(0,g.z)(e=>"animated"===e.layout,(0,c.qy)`<span class="button-content">${e=>(0,c.qy)`${c.qy.partial(e.selectIcon||"")}`}<span class="disappear">${e=>e.animationText}</span></span>`)} `)} ${(0,g.z)(e=>!e.selected,(0,c.qy)`${e=>(0,c.qy)`${c.qy.partial(e.unselectIcon||"")}`}`)}</fluent-button>`,m=class extends d{};m=(0,i.Cg)([(0,o.E)({name:"msn-card-button",template:h,styles:l,shadowOptions:{delegatesFocus:!0}})],m)},37903(e,t,a){a.d(t,{t:()=>d});var i,o=a(46277);class n{constructor({id:e,checkNewEffectInstance:t}){this.register=(e,t,a,i)=>{let o=`${this.effectItems.length}`,n={id:o,effectContainer:e,updateEffectStatus:t,showMultiTimes:i,isIntersecting:!1,isEffectShown:!1,observer:this.initIntersectionObserver(o,e,a)};this.effectItems.push(n)},this.unregister=()=>{this.effectItems.forEach(e=>{e.observer&&e.effectContainer&&e.observer.unobserve(e.effectContainer)}),this.effectItems=[]},this.initIntersectionObserver=(e,t,a)=>{if("function"!=typeof IntersectionObserver||!t)return null;let i=new IntersectionObserver(t=>{t.forEach(t=>{this.handleIntersectingChange(e,t.isIntersecting)})},{root:a&&a.root?document.getElementById(a.root):null,rootMargin:a&&a.rootMargin||"0px 0px 0px 0px"});return i.observe(t),i},this.handleIntersectingChange=(e,t)=>{let a=(0,o.A)(this.effectItems,t=>t.id===e);-1!==a&&(this.effectItems[a].isIntersecting=t,t&&this.isAllEffectItemsIntersecting()?this.checkNewEffectInstance(!0):!t&&this.isAllEffectItemsNonIntersecting()&&this.updateEffectSeriesStatus(!1))},this.isAllEffectItemsIntersecting=()=>{let e=!0;return this.effectItems.forEach(t=>{if(!t.isIntersecting){e=!1;return}}),e},this.isAllEffectItemsNonIntersecting=()=>{let e=!0;return this.effectItems.forEach(t=>{if(t.isIntersecting){e=!1;return}}),e},this.isEffectValid=()=>{let e=!0;return this.effectItems.forEach(t=>{if(!t.isIntersecting||t.isEffectShown){e=!1;return}}),e},this.updateEffectSeriesStatus=(e,t)=>{this.effectItems.forEach(a=>{(a.showMultiTimes||e)&&(a.isEffectShown=e),a.updateEffectStatus(e,t)})},this.id=e,this.effectItems=[],this.checkNewEffectInstance=t}}class r{constructor({id:e}){this.register=(e,t,a,i,r,d)=>{let s=(0,o.A)(this.effectSequence,t=>t.id===e);if(this.delayTimeMs=void 0===d?this.delayTimeMs:d,-1!==s)this.effectSequence[s].register(t,a,i,r);else{let o=new n({id:e,checkNewEffectInstance:this.checkNewEffectInstance});o.register(t,a,i,r),this.effectSequence.push(o)}},this.unregister=e=>{let t=(0,o.A)(this.effectSequence,t=>t.id===e);-1!==t&&(this.effectSequence[t].unregister(),this.effectSequence.splice(t,1))},this.notifyEffectCompleted=()=>{this.isPageShowingeffect=!1},this.checkNewEffectInstance=(e=!1)=>{(!e||this.isInitialState)&&setTimeout(()=>{let e=this.findFirstValidEffect();this.isPageScrolling||this.isPageShowingeffect||!e||(this.isPageShowingeffect=!0,e.updateEffectSeriesStatus(!0,this.notifyEffectCompleted))},this.delayTimeMs)},this.handlePageScroll=()=>{this.isInitialState=!1,this.isPageScrolling||(this.isPageScrolling=!0),this.pageScrollingTimer&&window.clearTimeout(this.pageScrollingTimer),this.pageScrollingTimer=window.setTimeout(()=>{this.isPageScrolling=!1,this.checkNewEffectInstance()},500)},this.findFirstValidEffect=()=>{let e=(0,o.A)(this.effectSequence,e=>e.isEffectValid());return -1!==e?this.effectSequence[e]:null},this.id=e,this.effectSequence=[],this.pageScrollingTimer=-1,this.isPageScrolling=!1,this.isPageShowingeffect=!1,this.delayTimeMs=1e3,document.addEventListener("scroll",this.handlePageScroll),this.isInitialState=!0}}(i||(i={})).default="default";let d=new class{constructor(){this.getEffectGroup=e=>{let t=e||i.default,a=(0,o.A)(this.effectGroups,e=>e.id===t);if(-1!==a)return this.effectGroups[a];{let e=new r({id:t});return this.effectGroups.push(e),e}},this.effectGroups=[]}}},99659(e,t,a){a.d(t,{k:()=>V});var i=a(56911),o=a(4731),n=a(37180),r=a(53621),d=a(56050),s=a(86262),l=a(92011),c=a(38493),p=a(60815);class g extends l.L{constructor(){super(...arguments),this.actionAlignment="horizontal",this.isHeadingLoaded=!1}actionsSlottedNodesChanged(){let e=this.actionsSlottedNodes[0]?.children[0];e&&window.setTimeout(()=>{e.focus()},0),this.actionsSlottedNodes[0]?.focus()}headingSlottedNodesChanged(){this.isHeadingLoaded||window.setTimeout(()=>{this.isHeadingLoaded=!0},0)}}(0,i.Cg)([(0,c.CF)({attribute:"align-actions"})],g.prototype,"actionAlignment",void 0),(0,i.Cg)([c.CF],g.prototype,"hideStoryTitle",void 0),(0,i.Cg)([p.sH],g.prototype,"actionsSlottedNodes",void 0),(0,i.Cg)([p.sH],g.prototype,"headingSlottedNodes",void 0),(0,i.Cg)([p.sH],g.prototype,"isHeadingLoaded",void 0);var h=a(7040),m=a(12051),u=a(34768),f=a(64186),y=a(48421),v=a(47810),x=a(89580),b=a(86856),C=a(82905),$=a(59669),w=a(64187),k=a(22131),T=a(63033),S=a(50882),F=a(33744),z=a(57860),A=a(15189);let L=()=>(0,z.zJ)(F.T3.CurrentMarket)?"--hide-story-background: linear-gradient(-90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);":"--hide-story-background: linear-gradient(90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);",M=(0,$.A)` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){right:0}`,_=(0,$.A)` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){left:0}`,B=(0,$.A)` :host{--hide-story-background:${(0,h.dR)(()=>C.go)(m.Ay)};--button-color:${(0,u.F7)((0,h.dR)(()=>C.go))(m.Ay)};--button-hover-color:${(0,u.Xt)((0,h.dR)(()=>C.go))(m.Ay)};--stealth-button-color:${(0,f.Wl)((0,h.dR)(()=>C.go))(m.Ay)};--stealth-button-text-color:${(0,y.c)((0,h.k6)(()=>C.go))(m.Ay)};--neutral-fill-rest:${(0,u.F7)((0,h.dR)(()=>C.go))(m.Ay)};--neutral-fill-hover:${(0,u.Xt)((0,h.dR)(()=>C.go))(m.Ay)}}:host(.hide-feedback.instant-hide){${L()}}`,I=(0,$.A)` :host{--hide-story-background:${(0,h.pq)(()=>C.kJ)(m.Ay)};--button-color:${(0,u.F7)((0,h.pq)(()=>C.kJ))(m.Ay)};--button-hover-color:${(0,u.Xt)((0,h.pq)(()=>C.kJ))(m.Ay)};--stealth-button-color:${(0,f.Wl)((0,h.pq)(()=>C.kJ))(m.Ay)};--stealth-button-text-color:${(0,y.c)((0,h.k6)(()=>C.kJ))(m.Ay)};--neutral-fill-rest:${(0,u.F7)((0,h.pq)(()=>C.kJ))(m.Ay)};--neutral-fill-hover:${(0,u.Xt)((0,h.pq)(()=>C.kJ))(m.Ay)}}`,q=(0,$.A)` :host{--hide-story-background:${(0,h.pq)(()=>C.kJ)(m.Ay)};--button-color:${(0,u.F7)((0,h.pq)(()=>C.kJ))(m.Ay)};--button-hover-color:${(0,u.Xt)((0,h.pq)(()=>C.kJ))(m.Ay)};--stealth-button-color:${(0,f.Wl)((0,h.pq)(()=>C.kJ))(m.Ay)};--stealth-button-text-color:${(0,y.c)((0,h.k6)(()=>C.kJ))(m.Ay)};--neutral-fill-rest:${(0,u.F7)((0,h.pq)(()=>C.kJ))(m.Ay)};--neutral-fill-hover:${(0,u.Xt)((0,h.pq)(()=>C.kJ))(m.Ay)}}`,D=(0,$.A)` :host{--hide-story-background:${(0,h.dR)(()=>C.go)(m.Ay)};--button-color:${(0,u.F7)((0,h.dR)(()=>C.go))(m.Ay)};--button-hover-color:${(0,u.Xt)((0,h.dR)(()=>C.go))(m.Ay)};--stealth-button-color:${(0,f.Wl)((0,h.dR)(()=>C.go))(m.Ay)};--stealth-button-text-color:${(0,y.c)((0,h.k6)(()=>C.go))(m.Ay)};--neutral-fill-rest:${(0,u.F7)((0,h.dR)(()=>C.go))(m.Ay)};--neutral-fill-hover:${(0,u.Xt)((0,h.dR)(()=>C.go))(m.Ay)}}:host(.hide-feedback.instant-hide){${L()}}`,E=(0,$.A)` :host{forced-color-adjust:auto}:host(.hide-feedback) ::slotted(fluent-menu-item){border-color:${S.A.ButtonText}}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-feedback) ::slotted(fluent-menu-item:focus){background-color:${S.A.Highlight};color:${S.A.HighlightText}}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border-color:${S.A.ButtonText};box-shadow:0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) ${S.A.ButtonText}}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){color:var(--stealth-button-text-color)}`,H=(0,$.A)` ${(0,w.V)("flex")} :host{--action-region-padding-top:0;--content-region-padding-top:16px;--content-region-width:236px;box-sizing:border-box;flex-direction:column;height:100%;position:relative;width:100%}:host(.hide-confirm[card-size="_1x_1y"]) .content-region,:host(.hide-confirm[card-size="_2x_1y"]) .content-region,:host(.hide-confirm[card-size="0.5u"]) .content-region{margin-inline:28px}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="0.5u"]) ::slotted(fluent-button.stealth-button){height:24px;font-size:var(--type-ramp-minus-1-font-size,12px);color:var(--neutral-foreground-rest);background:var(--button-color)}:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){position:absolute;height:18px;width:18px;top:0;margin-inline-end:8px;margin-top:8px;min-width:18px}:host([card-size="_1x_1y"]) .content-region,:host([card-size="_2x_1y"]) .content-region,:host([card-size="0.5u"]) .content-region{padding-top:20px;height:40px;width:232px}:host([card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host([card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host([card-size="0.5u"]) ::slotted(fluent-menu-item){height:24px}:host([card-size="_1x_1y"]) .action-region,:host([card-size="_2x_1y"]) .action-region,:host([card-size="0.5u"]) .action-region{padding-top:10px;padding-bottom:14px}.action-region{display:flex;position:absolute;padding:0 16px 16px;padding-top:var(--action-region-padding-top);justify-content:space-around;bottom:0;width:100%;box-sizing:border-box;align-items:center}:host([align-actions="vertical"]) .action-region{display:block;margin:auto;position:static}.content-region{display:inline-flex;flex-direction:column;align-items:center;padding:16px 16px 0 16px;padding-top:var(--content-region-padding-top);cursor:default}:host([align-actions="vertical"]) .content-region{display:block;margin:auto;text-align:center;width:var(--content-region-width)}.heading,::slotted(.heading){text-decoration:none;color:${v.l};font-size:var(--heading-font-size,${x.Y});line-height:var(--heading-line-height,${x.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,2)}::slotted(fluent-button){margin-bottom:8px;width:48%}:host(.hide-feedback){background:var(--hide-story-background)}:host(.hide-feedback) ::slotted(fluent-menu-item),:host(.hide-confirm) ::slotted(fluent-button){background:var(--button-color);border:calc(var(--stroke-width) * 1px) solid transparent}:host(.hide-feedback) ::slotted(.stealth-button){background:var(--stealth-button-color);color:var(--stealth-button-text-color)}:host(.hide-feedback.instant-hide) ::slotted(.stealth-button){background:transparent}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-confirm) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm) ::slotted(.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border:calc(var(--stroke-width) * 1px) solid var(--focus-stroke-outer);box-shadow:0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) var(--focus-stroke-outer)}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){background:var(--stealth-button-color)}`.withBehaviors(new b.t(M,_),(0,k.mr)(E),new T.N(B,I),new A.l(q,D));var P=a(89757),R=a(82774),U=a(69259),N=a(10108);let O=(0,P.qy)`<div class="content-region" part="content-region" aria-live="assertive"><slot name="heading" ${(0,R.e)({property:"headingSlottedNodes"})}>${(0,U.z)(e=>e.isHeadingLoaded,(0,P.qy)`<span class="heading" part="heading" aria-level="2" role="heading">${e=>e.hideStoryTitle}</span>`)}</slot></div><div class="action-region" part="action-region"><slot name="actions" ${(0,R.e)({property:"actionsSlottedNodes",filter:(0,N.Y)("fluent-radio-group, fluent-radio, fluent-button, fluent-anchor, fluent-menu-item")})}></slot></div>`,V=class extends g{};V=(0,i.Cg)([(0,l.E)({name:"msn-hide-story-card",template:O,styles:H,shadowOptions:{delegatesFocus:!0}})],V),o.m.define(n.c.registry),r.m.define(n.c.registry),d.m.define(n.c.registry),s.m.define(n.c.registry)},30383(e,t,a){a.d(t,{_t:()=>w,aM:()=>k});var i=a(56911),o=a(92011),n=a(38493);class r extends o.L{constructor(){super(...arguments),this.enabled=!1,this.isInfoPane=!1}}(0,i.Cg)([n.CF],r.prototype,"icon",void 0),(0,i.Cg)([n.CF],r.prototype,"text",void 0),(0,i.Cg)([n.CF],r.prototype,"extraBadgeStyle",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean"})],r.prototype,"enabled",void 0),(0,i.Cg)([n.CF],r.prototype,"layout",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"is-info-pane"})],r.prototype,"isInfoPane",void 0);var d=a(89757);let s=(0,d.qy)`<svg width="12" height="10" viewBox="0 0 12 10" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0.5 4H1V7.5C1 7.776 1.224 8 1.5 8H2.5C2.776 8 3 7.776 3 7.5V7H7V7.5C7 7.776 7.224 8 7.5 8H8.5C8.776 8 9 7.776 9 7.5V4H9.5C9.776 4 10 3.776 10 3.5C10 3.224 9.776 3 9.5 3H8.75L8.284 1.136C8.117 0.468 7.517 0 6.829 0H3.171C2.483 0 1.883 0.468 1.716 1.136L1.25 3H0.5C0.224 3 0 3.224 0 3.5C0 3.776 0.224 4 0.5 4ZM6 6H4C3.724 6 3.5 5.776 3.5 5.5C3.5 5.224 3.724 5 4 5H6C6.276 5 6.5 5.224 6.5 5.5C6.5 5.776 6.276 6 6 6ZM8.25 4.5C8.25 4.914 7.914 5.25 7.5 5.25C7.086 5.25 6.75 4.914 6.75 4.5C6.75 4.086 7.086 3.75 7.5 3.75C7.914 3.75 8.25 4.086 8.25 4.5ZM2.687 1.379C2.742 1.157 2.942 1 3.171 1H6.829C7.058 1 7.258 1.157 7.313 1.379L7.719 3H2.281L2.687 1.379ZM2.5 3.75C2.914 3.75 3.25 4.086 3.25 4.5C3.25 4.914 2.914 5.25 2.5 5.25C2.086 5.25 1.75 4.914 1.75 4.5C1.75 4.086 2.086 3.75 2.5 3.75ZM11.5 6H10.5C10.224 6 10 6.224 10 6.5V9H0.5C0.224 9 0 9.224 0 9.5C0 9.776 0.224 10 0.5 10H11.5C11.776 10 12 9.776 12 9.5V6.5C12 6.224 11.776 6 11.5 6Z" fill="black" fill-opacity="0.83"/>
</svg>
`,l=(0,d.qy)`<svg width="11" height="17" viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9.38909 11.6701L8.63932 12.4338C8.08675 12.9924 7.36969 13.7106 6.48803 14.5885C5.93704 15.1372 5.06295 15.1371 4.51208 14.5884L2.30692 12.3792C2.02977 12.0989 1.79778 11.8626 1.61091 11.6701C-0.536971 9.45796 -0.536971 5.87129 1.61091 3.65913C3.7588 1.44696 7.24121 1.44696 9.38909 3.65913C11.537 5.87129 11.537 9.45796 9.38909 11.6701ZM7.07926 7.84334C7.07926 6.94501 6.37218 6.21679 5.49999 6.21679C4.6278 6.21679 3.92074 6.94501 3.92074 7.84334C3.92074 8.74163 4.6278 9.46986 5.49999 9.46986C6.37218 9.46986 7.07926 8.74163 7.07926 7.84334Z" fill="#717171"/>
</svg>
`,c=(0,d.qy)`<svg width="10" height="11" viewBox="0 0 10 11" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5.06591 0.163636L0.156818 5.07273C-0.0522727 5.28182 -0.0522727 5.62727 0.156818 5.84545L4.15682 9.84545C4.36591 10.0545 4.71136 10.0545 4.92955 9.84545L9.83864 4.93636C9.93864 4.82727 9.99318 4.69091 9.99318 4.54545V0.545455C9.99318 0.245455 9.74773 0 9.44773 0H5.44773C5.30227 0 5.16591 0.0545455 5.06591 0.163636ZM8.52955 2.77273C8.475 2.89091 8.40227 3 8.31136 3.09091C8.22046 3.18182 8.12045 3.25455 7.99318 3.3C7.86591 3.34545 7.74773 3.38182 7.61136 3.38182C7.475 3.38182 7.33864 3.35455 7.22045 3.3C7.10227 3.25455 6.99318 3.18182 6.90227 3.09091C6.81136 3 6.73864 2.89091 6.69318 2.77273C6.63864 2.65455 6.61136 2.52727 6.61136 2.38182C6.61136 2.23636 6.63864 2.10909 6.69318 1.99091C6.73864 1.88182 6.81136 1.77273 6.90227 1.69091C6.99318 1.6 7.10227 1.52727 7.22045 1.47273C7.33864 1.41818 7.46591 1.39091 7.61136 1.39091C7.75682 1.39091 7.88409 1.41818 8.00227 1.47273C8.12046 1.52727 8.22955 1.6 8.31136 1.69091C8.40227 1.78182 8.475 1.88182 8.52955 2C8.58409 2.11818 8.61136 2.24545 8.61136 2.39091C8.61136 2.53636 8.575 2.65455 8.52955 2.77273Z" fill="white"/>
</svg>
`,p=(0,d.qy)`<svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M7.60838 0.745943L0.244749 8.10958C-0.0688876 8.42322 -0.0688876 8.9414 0.244749 9.26867L6.24475 15.2687C6.55838 15.5823 7.07657 15.5823 7.40384 15.2687L14.7675 7.90503C14.9175 7.7414 14.9993 7.53685 14.9993 7.31867V1.31867C14.9993 0.86867 14.6311 0.500488 14.1811 0.500488H8.18111C7.96293 0.500488 7.75838 0.582306 7.60838 0.745943ZM12.8038 4.65958C12.722 4.83685 12.6129 5.00049 12.4766 5.13685C12.3402 5.27322 12.1902 5.38231 11.9993 5.45049C11.8084 5.51867 11.6311 5.57322 11.4266 5.57322C11.222 5.57322 11.0175 5.53231 10.8402 5.45049C10.6629 5.38231 10.4993 5.27322 10.3629 5.13685C10.2266 5.00049 10.1175 4.83685 10.0493 4.65958C9.96748 4.48231 9.92657 4.2914 9.92657 4.07322C9.92657 3.85503 9.96748 3.66412 10.0493 3.48685C10.1175 3.32322 10.2266 3.15958 10.3629 3.03685C10.4993 2.90049 10.6629 2.7914 10.8402 2.70958C11.0175 2.62776 11.2084 2.58685 11.4266 2.58685C11.6447 2.58685 11.8357 2.62776 12.0129 2.70958C12.1902 2.7914 12.3538 2.90049 12.4766 3.03685C12.6129 3.17322 12.722 3.32322 12.8038 3.50049C12.8857 3.67776 12.9266 3.86867 12.9266 4.08685C12.9266 4.30503 12.872 4.48231 12.8038 4.65958Z" fill="#717171"/>
</svg>
`,g=(0,d.qy)`<svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M5.27351 0.971551C5.57068 0.342816 6.4293 0.342816 6.72646 0.971551L8.14149 3.96535L11.3055 4.44543C11.97 4.54625 12.2353 5.39895 11.7545 5.88833L9.46494 8.21866L10.0054 11.5092C10.1189 12.2002 9.42431 12.7272 8.82998 12.4009L5.99999 10.8474L3.17001 12.4009C2.57569 12.7272 1.88105 12.2002 1.99456 11.5092L2.53504 8.21866L0.245535 5.88833C-0.235291 5.39895 0.030035 4.54625 0.69452 4.44543L3.85854 3.96535L5.27351 0.971551Z" fill="#717171"/>
</svg>
`;class h extends r{constructor(){super()}badgeTypeChanged(){"CurbsidePickup"===this.badgeType?(this.icon=s,this.enabled=!0):"OnSale"===this.badgeType?(this.icon=c,this.enabled=!0):"PriceDrop"===this.badgeType?(this.icon=p,this.enabled=!0):"LocalInventory"===this.badgeType?(this.icon=l,this.enabled=!0):"NewProduct"===this.badgeType&&(this.icon=g,this.enabled=!0)}}(0,i.Cg)([n.CF],h.prototype,"badgeType",void 0),(0,i.Cg)([n.CF],h.prototype,"badgeStyle",void 0),(0,i.Cg)([n.CF],h.prototype,"text",void 0);var m=a(59669),u=a(4126);let f=(0,m.A)` .info-pane .image-badge,.river .image-badge{background:#0078D4}.info-pane .image-badge .badge-text,.river .image-badge .badge-text{position:static;width:auto;height:16px;left:22px;top:2px;font-style:normal;font-weight:500;font-size:12px;line-height:16px;text-transform:uppercase;color:#FFFFFF}.info-pane .badge-icon path,.river .badge-icon path{fill:#FFFFFF}`,y=(0,m.A)`.river .image-badge{background:rgba(0,0,0,0.54)}.river .image-badge .badge-text{position:static;width:auto;height:16px;left:22px;top:2px;font-style:normal;font-weight:500;font-size:12px;line-height:16px;text-transform:uppercase;color:#FFFFFF}.river .image-background-gradient{position:absolute;background:linear-gradient(to left top,rgba(180,180,180,0) 3.99%,rgba(180,180,180,0.05) 57.8%,rgba(180,180,180,0.15) 75.35%,rgba(180,180,180,0.3) 100%);width:100%;height:50px;z-index:1}.river .badge-icon path{fill:#FFFFFF}`,v=(0,m.A)` .image-badge-decorator{overflow:hidden;width:100%;height:100%}.image-badge{display:flex;flex-direction:row;align-items:center;padding:2px 8px 2px 4px;position:absolute;width:auto;height:20px;left:8px;top:8px;background:rgba(255,255,255,0.8);border-radius:4px;z-index:1}.badge-icon{line-height:14px;margin-left:4px}.badge-text{position:static;height:16px;right:12px;top:8.5px;font-size:12px;font-weight:600;line-height:14px;display:flex;align-items:center;text-align:right;flex:none;order:5;flex-grow:0;margin-left:8px;text-transform:uppercase}.image-badge-wrapper{z-index:1}.image-badge{background:rgba(43,43,43,0.7)}.badge-text{color:white}.badge-icon path{fill:white}${y}
`.withBehaviors(new u.o("_badgeStyle","standingOut",(0,m.A)` ${f} `),new u.o("_badgeStyle","blendedIn",(0,m.A)` ${y} `));var x=a(69259);let b=(0,d.qy)`<div class="image-badge-decorator" layout=${e=>e.layout}>${(0,x.z)(e=>e.enabled,(0,d.qy)`<div class="image-badge-wrapper ${e=>e.isInfoPane?"info-pane":"river"}" style=${e=>e.extraBadgeStyle}><div class="image-background-gradient"></div><div class="image-badge"><div class="badge-icon">${e=>e.icon}</div><div class="badge-text">${e=>e.text}</div></div></div><span part="image-with-badge"><slot name="image-with-badge"></slot></span>`)} ${(0,x.z)(e=>!e.enabled,(0,d.qy)`<slot name="image-with-badge"></slot>`)}</div>`,C=(0,m.A)` .image-badge-decorator{position:relative;filter:drop-shadow(rgba(0,0,0,0.25) 0px 0px 4px)}.image-badge-wrapper{height:var(--z-index-image-height);width:var(--z-index-image-width);position:absolute;margin:12px}@media (prefers-color-scheme:light){.image-badge-decorator[layout="imageAtBottom"]{.image-background-gradient{background:linear-gradient(120.95deg,rgba(34,34,34,0) 3.99%,rgba(34,34,34,0.05) 57.8%,rgba(34,34,34,0.15) 75.35%,rgba(34,34,34,0.35) 100%);transform:unset}}.river .image-background-gradient{height:100%}}.image-badge-decorator[layout="imageAtBottom"] .image-badge{display:flex;flex-direction:row;align-items:center;position:absolute;inset:auto 0 0 auto;border-radius:20px 0px 0px 0px}`,$=class extends r{};$=(0,i.Cg)([(0,o.E)({name:"msn-raw-image-badge-decorator",template:b,styles:v})],$);let w=class extends h{};w=(0,i.Cg)([(0,o.E)({name:"msn-image-badge-decorator",template:b,styles:v})],w);let k=class extends h{};k=(0,i.Cg)([(0,o.E)({name:"msn-z-index-image-badge-decorator",template:b,styles:[v,C]})],k)},60274(e,t,a){a.d(t,{w:()=>b});var i=a(56911),o=a(38493),n=a(60815),r=a(66864),d=a(40450),s=a(45183);let l=class extends r.t{themeChangeListener(e){this.darkMode=!!e?.matches}constructor(){super(),this.text="",this.forInfopane=!0,this.backgroundColor="",this.defaultBackgroundColor="#FFFFFF",this.color="#2065C1",this.isHovered=!1,this.ctaMode="default",this.destinationUrl="",this.telemetryMetadata=void 0,this.darkModeQuery=window.matchMedia("(prefers-color-scheme:dark)"),this.darkMode=!!this.darkModeQuery.matches}connectedCallback(){super.connectedCallback(),this.darkModeQuery.addEventListener("change",this.themeChangeListener.bind(this))}disconnectedCallback(){super.disconnectedCallback(),this.darkModeQuery.removeEventListener("change",this.themeChangeListener.bind(this))}};(0,i.Cg)([o.CF],l.prototype,"text",void 0),(0,i.Cg)([(0,o.CF)({mode:"boolean",attribute:"for-infopane"})],l.prototype,"forInfopane",void 0),(0,i.Cg)([(0,o.CF)({attribute:"background-color"})],l.prototype,"backgroundColor",void 0),(0,i.Cg)([(0,o.CF)({attribute:"default-background-color"})],l.prototype,"defaultBackgroundColor",void 0),(0,i.Cg)([o.CF],l.prototype,"color",void 0),(0,i.Cg)([(0,o.CF)({mode:"boolean",attribute:"is-hovered"})],l.prototype,"isHovered",void 0),(0,i.Cg)([(0,o.CF)({attribute:"cta-mode"})],l.prototype,"ctaMode",void 0),(0,i.Cg)([(0,o.CF)({attribute:"destination-url"})],l.prototype,"destinationUrl",void 0),(0,i.Cg)([(0,o.CF)({attribute:"tel-metadata"})],l.prototype,"telemetryMetadata",void 0),(0,i.Cg)([n.sH],l.prototype,"darkMode",void 0),l=(0,i.Cg)([(0,s.TA)(d.PDj,"msn-native-ad-call-to-action")],l);var c=a(92011),p=a(59669),g=a(16559),h=a(22062);let m=(0,p.A)`
.call-to-action{background-color:#FFFFFF;color:#2065C1;font-size:14px;font-weight:600;height:32px;line-height:32px;display:inline-block;border-radius:20px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;position:relative}.call-to-action-bg{position:absolute;width:100%;height:100%;border-radius:20px;opacity:0.3}.call-to-action-txt{position:relative;border-radius:20px;padding-left:12px;padding-right:12px}.call-to-action-icon-container{background-color:#C6C0BA;width:32px;height:32px;border-radius:50%;position:relative}.call-to-action-icon-bg{position:absolute;width:100%;height:100%;border-radius:50%;opacity:0.3}.call-to-action-icon{width:9px;height:15px;left:12px;top:8px;position:absolute;display:flex}.call-to-action-mask-container{background:linear-gradient(180deg,rgba(43,43,43,0.9) 0%,rgba(43,43,43,0.35) 100%);position:absolute;width:100%;height:304px;bottom:0;left:0;animation:fadeIn 0.1s forwards}@keyframes fadeIn{from{opacity:0}to{opacity:1}}.call-to-action-mask-wrapper{width:fit-content;position:absolute;top:113px;left:50%;transform:translate(-50%,0);display:flex;align-items:center}.call-to-action-mask-text{font-size:19px;font-weight:600;display:inline-block}.call-to-action-mask-icon{display:inline-block;width:16px;height:14px;margin-inline:5px}.txt-button-wrapper{display:inline-block;position:relative;padding:4px 12px;line-height:16px;font-size:12px;border-radius:100px;font-weight:400;text-decoration:none}.txt-button-wrapper::before{content:"";position:absolute;inset:0px;border-radius:50px;padding:1px;-webkit-mask:linear-gradient(rgb(255,255,255) 0px,rgb(255,255,255) 0px) content-box content-box,linear-gradient(rgb(255,255,255) 0px,rgb(255,255,255) 0px);-webkit-mask-composite:xor;pointer-events:none}`.withBehaviors(new g.e("layoutStyle"),new h.X(["defaultBackgroundColor","backgroundColor","color","forInfopane","darkMode"],e=>{let t=`
                .call-to-action.dynamic-styles {
                    background: ${e.defaultBackgroundColor};
                }
                .call-to-action-txt.dynamic-styles {
                    color: ${e.color};
                }
                .call-to-action-bg.dynamic-styles {
                    background: ${e.backgroundColor};
                }
                .call-to-action-icon-bg.dynamic-styles {
                    background: ${e.backgroundColor};
                }
            `;return e.forInfopane||(t+=`
                    .txt-button-wrapper::before {
                        background: linear-gradient(180deg, #EFEFEF 90%, #D6D6D6 100%);
                    }
                `),e.darkMode?t+=`
                    .txt-button-wrapper {
                        background: linear-gradient(0deg, rgba(255, 255, 255, 0.0605), rgba(255, 255, 255, 0.0605));
                        color: #FFFFFF;
                    }
                    .txt-button-wrapper::before {
                        background: linear-gradient(180deg, rgba(255, 255, 255, 0.093) 0%, rgba(255, 255, 255, 0.0698) 9.57%);
                    }
                `:t+=`
                    .txt-button-wrapper {
                        color: #1a1a1a;
                        background: linear-gradient(0deg, #FFFFFF, #FFFFFF);
                    }
                    .txt-button-wrapper::before {
                        background: linear-gradient(rgba(239, 239, 239, 0.7) 90%, rgba(214, 214, 214, 0.7) 100%);
                    }
                `,(0,p.A)`${t}`}));var u=a(89757),f=a(69259);let y=(0,u.qy)`
<svg width="11" height="17" viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2.09854 16.6761L10.6426 9.25004C10.8715 9.05109 11 8.78131 11 8.5C11 8.2187 10.8715 7.94891 10.6426 7.74997L2.09854 0.323871C1.98594 0.222547 1.85126 0.141728 1.70234 0.0861287C1.55342 0.0305295 1.39326 0.0012641 1.23119 4.0055e-05C1.06912 -0.00118399 0.908396 0.0256578 0.758391 0.0789993C0.608386 0.132341 0.472105 0.211114 0.357501 0.310722C0.242897 0.41033 0.152265 0.528778 0.0908924 0.659155C0.0295204 0.789532 -0.00136224 0.929227 4.60857e-05 1.07009C0.00145442 1.21095 0.0351258 1.35016 0.0990954 1.47959C0.163065 1.60902 0.256052 1.72608 0.37263 1.82394L8.05377 8.5L0.37263 15.1761C0.256052 15.2739 0.163065 15.391 0.0990954 15.5204C0.0351258 15.6498 0.00145442 15.7891 4.60857e-05 15.9299C-0.00136224 16.0708 0.0295204 16.2105 0.0908924 16.3408C0.152265 16.4712 0.242897 16.5897 0.357501 16.6893C0.472105 16.7889 0.608386 16.8677 0.758391 16.921C0.908396 16.9743 1.06912 17.0012 1.23119 17C1.39326 16.9987 1.55342 16.9695 1.70234 16.9139C1.85126 16.8583 1.98594 16.7775 2.09854 16.6761Z" fill="black"/>
</svg>
`,v=(0,u.qy)`
<svg width="16" height="14" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.5 14C6.22386 14 6 13.7761 6 13.5C6 13.2239 6.22386 13 6.5 13H13C14.1046 13 15 12.1046 15 11V3C15 1.89543 14.1046 1 13 1H6.5C6.22386 1 6 0.776142 6 0.5C6 0.223858 6.22386 0 6.5 0H13C14.6569 0 16 1.34315 16 3V11C16 12.6569 14.6569 14 13 14H6.5ZM6.64645 3.14645C6.84171 2.95118 7.15829 2.95118 7.35355 3.14645L10.8536 6.64645C11.0488 6.84171 11.0488 7.15829 10.8536 7.35355L7.35355 10.8536C7.15829 11.0488 6.84171 11.0488 6.64645 10.8536C6.45118 10.6583 6.45118 10.3417 6.64645 10.1464L9.29289 7.5H0.5C0.223858 7.5 0 7.27614 0 7C0 6.72386 0.223858 6.5 0.5 6.5H9.29289L6.64645 3.85355C6.45118 3.65829 6.45118 3.34171 6.64645 3.14645Z" fill="white"/>
</svg>
`,x=(0,u.qy)` ${(0,f.z)(e=>"arrow"===e.ctaMode,(0,u.qy)`<a class="call-to-action-click-wrapper" target = "_blank" href = ${e=>e.destinationUrl} data-t="${e=>e.telemetryMetadata}" aria-label=${e=>e.text}><div class="call-to-action-icon-container" title="${e=>e.text}"><div class="call-to-action-icon-bg dynamic-styles"></div><div class="call-to-action-icon dynamic-styles">${y}</div></div></a>`)} ${(0,f.z)(e=>"mask"===e.ctaMode,(0,u.qy)` ${(0,f.z)(e=>e.isHovered,(0,u.qy)`<div class="call-to-action-mask-container"><div class="call-to-action-mask-wrapper"><div class="call-to-action-mask-text">${e=>e.text}</div><div class="call-to-action-mask-icon">${v}</div></div></div>`)} `)} ${(0,f.z)(e=>"default"===e.ctaMode||"button"===e.ctaMode,(0,u.qy)`<a class="txt-button-wrapper" target = "_blank" href = ${e=>e.destinationUrl} data-t="${e=>e.telemetryMetadata}">${e=>e.text}</a>`)} ${(0,f.z)(e=>"text"===e.ctaMode,(0,u.qy)` ${e=>e.text} `)} `,b=class extends l{};b=(0,i.Cg)([(0,c.E)({name:"msn-native-ad-call-to-action",template:x,styles:m})],b)},53715(e,t,a){a.d(t,{EW:()=>C,G:()=>y,Ij:()=>f,JF:()=>h,NL:()=>g,Ni:()=>v,RB:()=>b,Rw:()=>p,eC:()=>x,gJ:()=>m,zT:()=>u});var i,o,n,r,d=a(53537),s=a(78518),l=a(693),c=a(56547);(i=n||(n={})).LTR="leftToRight",i.RTL="rightToLeft";let p=e=>{if(e.hasAnyInlineDecoration)switch(e.template?.templateType){case"msn-river-animated-imagery-9-by-16":case"msn-river-z-index-3-by-4":case"msn-river-z-index-9-by-16":return"five-lines-heading";default:return"two-lines-heading"}switch(e.template?.templateType){case"msn-river-animated-imagery-9-by-16":case"msn-river-z-index-3-by-4":case"msn-river-z-index-9-by-16":return"eight-lines-heading";default:return"three-lines-heading"}},g=(e,t)=>{if(["msn-river-z-index-3-by-4","msn-river-z-index-9-by-16","msn-river-animated-imagery-9-by-16"].includes(t.template?.templateType)){if("rtl"===e)return n.RTL;else if("ltr"===e)return n.LTR}return""},h=e=>t=>{let a=t?.hoverState?.isHovered,i=t?.template?.progressiveDisplay,o="call-to-action";switch(t.template?.templateType){case"msn-river-animated-imagery-9-by-16":case"msn-river-z-index-3-by-4":case"msn-river-z-index-9-by-16":return e(o,!1,i,65,a,!0,0,e=>(0,d.IH)(t,e));default:return e(o,!1,i,a?65:25,a,!1,(0,d.$q)(t),e=>(0,d.IH)(t,e))}};(o=r||(r={})).ImageAtTop="imageAtTop",o.ImageAtBottom="imageAtBottom",o.AnimatedImagery9by16="animatedImagery9by16",o.ImageAtRight9By16="imageAtRight9By16",o.ImageAtRight3By4="imageAtRight3By4";let m=e=>{switch(e.template.templateType){case"msn-river-animated-imagery-9-by-16":return r.AnimatedImagery9by16;case"msn-river-z-index-9-by-16":return r.ImageAtRight9By16;case"msn-river-z-index-3-by-4":return r.ImageAtRight3By4;case"msn-z-index-card":if(e.template.flipZIndex)return r.ImageAtTop;return r.ImageAtBottom}},u=e=>e.template?.templateType||"msft-content-card",f=e=>["msn-special-offer-nondr","msn-special-offer-nondr-with-exp","msn-combo-special-offer-nondr"].includes(u(e)),y=e=>"msn-special-offer-nondr-with-exp"===u(e),v=e=>["msn-call-to-action-v3","msn-call-to-action-v3-pa"].includes(u(e)),x=e=>"msn-combo-sale-highlight-nondr"===u(e),b=e=>{e.disableRenderDecoration&&"msft-content-card"==u(e)&&(e=>{if(e.assets&&!(0,l.A)(e.assets)){let t=(0,c.A)(e.assets,(e,t,a)=>(s.rQ.includes(s.eO[a])&&(e[a]=t),e),{});e.assets=t}})(e);let t=e.template?.immersiveThemeColor,a=e.badge,i=e.videoProps,o=!!e.assets&&!(0,l.A)(e.assets),n=e.template?.animatedImage&&e.template?.animatedConfig,r=["msn-pseudo-video-card","msn-slideshow-card","msn-pattern-overlay-card","msn-ad-carousel","msn-z-index-card","msn-river-animated-imagery-9-by-16","msn-river-z-index-9-by-16","msn-river-z-index-3-by-4","msn-call-to-action-v3"].includes(u(e));return!!e.isTransparentAdSlugWithBorder||!!e.enableAdsColorBleed||!i&&(!!a||!!o||!!n||!!r||!!t)},C=e=>{let t=!!e.assets&&!(0,l.A)(e.assets),a=["msn-special-offer-nondr","msn-special-offer-nondr-with-exp","msn-highlight-rating-nondr-red","msn-highlight-rating-nondr-yellow","msn-default-rating-nondr-yellow-static","msn-highlight-rating-nondr-yellow-static","msn-freeshipping-plain-text-nondr","msn-freeshipping-inline-nondr","msn-freeshipping-top-left-nondr","msn-freeshipping-top-right-nondr","msn-condition-nondr","msn-return-policy-nondr","msn-sold-nondr","msn-combo-freeshipping-nondr","msn-combo-rating-nondr","msn-combo-special-offer-nondr","msn-combo-sold-nondr","msn-combo-return-policy-nondr","msn-combo-condition-nondr"].includes(u(e));return!t&&!!a}},73888(e,t,a){a.d(t,{T:()=>U});var i,o,n=a(89757),r=a(69259),d=a(63456),s=a(48566),l=a(56911),c=a(92011),p=a(23429),g=a(60815),h=a(38493),m=a(10405),u=a(17517),f=a(43873),y=a(31844),v=a(45186),x=a(56988),b=(0,v.A)(function(e,t){if(null==e)return[];var a=t.length;return a>1&&(0,x.A)(e,t[0],t[1])?t=[]:a>2&&(0,x.A)(t[0],t[1],t[2])&&(t=[t[0]]),(0,y.A)(e,(0,f.A)(t,1),[])}),C=a(62966),$=a(46277),w=a(4670);class k{constructor(e,t,a,i,o){this.childElements=this.getChildren(e,!1),this.visibleChildElements=this.getChildren(e,!0),this.containerElement=this.getContainerElement(e),this.parentElement=this.getParentElement(e),this.maxCount=t?(0,m.A)(t):-1,this.maxHeight=a?(0,m.A)(a):0,this.originalHeight=i?(0,m.A)(i):0,this.onDecorationLinesExpanded=o}run(e){(0,u.A)(e,e=>{e(this)})}getChildren(e,t){let a=t?e.querySelectorAll('div[name="inline-wrapper"]:not(.hidden)>*'):e.querySelectorAll('div[name="inline-wrapper"]>*'),i=[];a.forEach(e=>{let t=(0,m.A)(e.getAttribute("priority"));i.push({item:e,priority:t})});let o=b(i,["priority"]);return(0,C.A)(o,e=>e.item)}getParentElement(e){return e.querySelector(".group-wrapper")}getContainerElement(e){return e.querySelector(".group-container")}hideElement(e){e.parentElement.className="hidden"}hideChildElements(e){for(;this.visibleChildElements.length>e;){let e=this.visibleChildElements.pop();if(e)if((0,m.A)(e.getAttribute("priority"))>0)this.hideElement(e);else{this.childElements.push(e);break}}}showChildElementByIndex(e){this.childElements[e]&&this.childElements[e].parentElement.classList.remove("hidden")}hideChildElementByIndex(e){this.childElements[e]&&this.childElements[e].parentElement.classList.add("hidden")}}let T=e=>{let t=e.parentElement.getBoundingClientRect().width;if(e.visibleChildElements.length>0){let a=(0,$.A)(e.visibleChildElements,e=>{let a=e.getBoundingClientRect();return t-=(0,d.A)(a,"width",0),0>(0,m.A)(t)});if(a>-1){let t=e.visibleChildElements.length;e.hideChildElements(a),t>0&&(0,w.uz)(e.containerElement,"inlineGroup",`w,${t},${e.visibleChildElements.length}`,0)}}},S=e=>{if(e.maxCount>=0){let t=e.visibleChildElements.length;e.hideChildElements(e.maxCount),t>0&&(0,w.uz)(e.containerElement,"inlineGroup",`c,${t},${e.visibleChildElements.length}`,0)}},F=e=>{let t=e.parentElement.getBoundingClientRect().height;if(e.originalHeight&&e.containerElement.setAttribute("style",`height: ${e.originalHeight}px;`),e.childElements.length>0){if(t<=e.maxHeight){let a=0;for(;t<=e.maxHeight&&a<=e.childElements.length-1;)e.showChildElementByIndex(a++),t=e.parentElement.getBoundingClientRect().height}if(t>e.maxHeight){let a=e.childElements.length,i=a,o=e.childElements.length-1;for(;t>e.maxHeight&&o>=0;)e.hideChildElementByIndex(o--),i-=1,t=e.parentElement.getBoundingClientRect().height;a>0&&(0,w.uz)(e.containerElement,"inlineGroup",`h,${a},${i}`,0)}}e.originalHeight&&e.originalHeight!==z(t)&&e.containerElement.setAttribute("style",`height: ${z(t)}px; transition: height 0.3s;`),e.onDecorationLinesExpanded&&A(t)&&e.onDecorationLinesExpanded(!0)},z=e=>e<25?25:e,A=e=>Math.ceil(e/25)>1;class L extends c.L{constructor(){super(...arguments),this.verticalMode=!1,this.onUpdate=()=>{var e,t,a,i;let o,n;e=this.shadowRoot,t=this.maxCount,a=this.verticalMode,i=this.maxHeight,o=new k(e,t,i,this.originalHeight,this.onDecorationLinesExpanded),n=[],a?n.push(F):(n.push(S),n.push(T)),o.run(n)}}connectedCallback(){super.connectedCallback(),p.L.enqueue(this.onUpdate)}}(0,l.Cg)([g.sH],L.prototype,"childElements",void 0),(0,l.Cg)([h.CF],L.prototype,"maxCount",void 0),(0,l.Cg)([(0,h.CF)({mode:"boolean"})],L.prototype,"verticalMode",void 0),(0,l.Cg)([h.CF],L.prototype,"originalHeight",void 0),(0,l.Cg)([h.CF],L.prototype,"maxHeight",void 0),(0,l.Cg)([h.CF],L.prototype,"onDecorationLinesExpanded",void 0);var M=a(416),_=a(10108),B=a(60402),I=a(68835);let q=(0,n.qy)`<template ${(0,M.Y)({property:"childElements",filter:(0,_.Y)()})}><div class="group-container" ${(0,B.K)("groupContainer")} part="group-container"><div class="group-wrapper" part="group-wrapper">${(0,I.ux)(e=>e.childElements,(0,n.qy)`<div name="inline-wrapper">${e=>(0,n.qy)`${e.outerHTML}`}</div>`)}</div></div></template>`;var D=a(59669);let E=(0,D.A)` div[name="inline-wrapper"]{display:inline;white-space:normal}.group-container .group-wrapper div[name="inline-wrapper"].hidden{display:none}:host(:not(:defined)){display:none}`,H=class extends L{};H=(0,l.Cg)([(0,c.E)({name:"msn-inline-group",template:q,styles:E})],H);let P=(0,n.qy)`
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14.1505 0C15.1719 0 16 0.828052 16 1.84951V6.33925C16 7.04766 15.7186 7.72707 15.2178 8.22806L8.22989 15.2176C7.1864 16.259 5.49656 16.2598 4.45167 15.2188L0.784137 11.5567C-0.260191 10.5144 -0.261529 8.82286 0.781032 7.77874L7.76778 0.783644C8.26888 0.281919 8.94889 0 9.65799 0H14.1505ZM14.1505 1.233H9.65799C9.27617 1.233 8.91001 1.38481 8.64018 1.65497L1.64315 8.66047C1.09223 9.22345 1.09641 10.1264 1.65525 10.6841L5.32239 14.3458C5.88535 14.9066 6.79643 14.9062 7.35842 14.3454L14.3458 7.3563C14.6155 7.08654 14.767 6.7207 14.767 6.33925V1.84951C14.767 1.50902 14.491 1.233 14.1505 1.233ZM11.89 2.8788C12.5709 2.8788 13.1229 3.43083 13.1229 4.11178C13.1229 4.79274 12.5709 5.34477 11.89 5.34477C11.209 5.34477 10.657 4.79274 10.657 4.11178C10.657 3.43083 11.209 2.8788 11.89 2.8788Z" fill="white" fill-opacity="0.8"/>
    </svg>`,R=(0,n.qy)`
    ${(0,r.z)(e=>e.localizedStrings&&e.localizedStrings.nativeAdShopNowText,(0,n.qy)`
        <style>
            .shop-now {
                position: relative;
            }
            .shop-now-icon {
                width: 16px;
                height: 16px;
                left: 12px;
                top: 4px;
                position: absolute;
            }
            .shop-now-text {
                position: absolute;
                left: 36px;
            }
        </style>
        <div class="shop-now" part="shop-now">
            <span class="shop-now-icon">
            ${P}
            </span>
            <span class="shop-now-text">
                ${e=>e.localizedStrings.nativeAdShopNowText}
            </span>
        </div>
    `)}
`;(i=o||(o={})).installmentPrice="1",i.price="1",i.priceStrikeThrough="1",i.priceOff="1",i.localInventory="1",i.priceDrop="2",i.freeShipping="2",i.productRating="2",i.topViewed="2",i.sold="2",i.specialOffer="2",i.curbsidePickup="2",i.eliteBadge="3",i.condition="3";let U=(e,t=!1,a=!1,i=50,l=!1,c=!1,p=0,g=null)=>(0,n.qy)`
    ${(0,r.z)(e=>e.hasAnyInlineDecoration||c,(0,n.qy)`
        <!-- TODO: set blank classname to be filled for article card -->
        <msft-attribution slot="${e}" class="${""}">
            ${(0,r.z)(e=>e.hasAnyInlineDecoration,(0,n.qy)`    
                <msn-inline-group 
                    maxCount="2" 
                    verticalMode=${a||c} 
                    maxHeight=${i} 
                    originalHeight=${p} 
                    :onDecorationLinesExpanded=${e=>g}
                >
                    <!-- price -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.price")&&!(0,d.A)(e,"assets.salePrice"),(0,n.qy)`
                        <decoration-price data=${e=>e.assets.price}
                            part="inline-item"
                            priority=${o.price}
                            is-info-pane=${t}
                        ></decoration-price>
                    `)}
                    <!-- price strike through -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.price")&&(0,d.A)(e,"assets.salePrice"),(0,n.qy)`
                        <decoration-price data=${e=>e.assets.salePrice}
                            part="inline-item"
                            priority=${o.price}
                            is-info-pane=${t}
                            ></decoration-price>
                        <decoration-price-strike-through data=${e=>e.assets.price}
                            part="inline-item"
                            priority=${o.priceStrikeThrough}
                            is-info-pane=${t}
                        ></decoration-price-strike-through>
                    `)}
                    <!-- installment price -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.installmentPrice"),(0,n.qy)`
                        <decoration-installment-price price=${e=>e.assets.price}
                            data=${e=>e.assets.installmentPrice}
                            price-format-now=${e=>(0,d.A)(e.localizedStrings,"nativeAdInstallmentPriceFormatNow")}
                            price-format-plan=${e=>(0,d.A)(e.localizedStrings,"nativeAdInstallmentPriceFormatPlan")}
                            part="inline-item"
                            priority=${o.installmentPrice}
                            is-info-pane=${t}
                        ></decoration-installment-price>
                    `)}
                    <!-- rating -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.rating"),(0,n.qy)`
                        <decoration-rating
                            rating=${e=>e.assets.rating}
                            review-data=${e=>e.assets.review}
                            part="inline-item"
                            priority=${o.productRating}
                            is-info-pane=${t}
                        ></decoration-rating>
                    `)}
                    <!-- free shipping -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.freeShipping"),(0,n.qy)`
                        <decoration-free-shipping
                            data=${e=>(0,d.A)(e.localizedStrings,"nativeAdFreeShippingText")}
                            part="inline-item"
                            priority=${o.freeShipping}
                            is-info-pane=${t}
                        ></decoration-free-shipping>
                    `)}
                    <!-- price-drop -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.priceDrop"),(0,n.qy)`
                        <decoration-price-drop
                            data=${e=>e.assets.priceDrop}
                            price-drop-format-short=${e=>(0,d.A)(e.localizedStrings,"nativeAdPriceDropShortText")}
                            price-drop-format-long=${e=>(0,d.A)(e.localizedStrings,"nativeAdPriceDropLongText")}
                            part="inline-item"
                            priority=${o.priceDrop}
                            is-info-pane=${t}
                            is-expanded=${l}
                        ></decoration-price-drop>
                    `)}
                    <!-- top-viewed -->
                    ${(0,r.z)(e=>!(0,d.A)(e,"assets.priceDrop")&&(0,d.A)(e,"assets.viewed"),(0,n.qy)`
                        <decoration-top-viewed
                            data=${e=>e.assets.viewed}
                            top-viewed-format-short=${e=>(0,d.A)(e.localizedStrings,"nativeAdTopViewedShortText")}
                            top-viewed-format-long=${e=>(0,d.A)(e.localizedStrings,"nativeAdTopViewedLongText")}
                            part="inline-item"
                            priority=${o.topViewed}
                            is-info-pane=${t}
                            is-expanded=${l}
                        ></decoration-top-viewed>
                    `)}
                    <!-- curbside-pickup -->
                    ${(0,r.z)(e=>(0,d.A)(e,"assets.curbsidePickup")&&c,(0,n.qy)`
                        <decoration-curbside-pickup 
                            data="${e=>e.localizedStrings.nativeAdCurbsidePickupText}"
                            priority=${o.curbsidePickup}
                            is-info-pane=${t}
                        ></decoration-curbside-pickup>
                    `)}
                    <!-- price-off -->
                    ${(0,r.z)(e=>e.assets.discount&&c,(0,n.qy)`
                        <decoration-price-off 
                            is-info-pane=${t}
                            priority=${o.priceOff}
                            data=" &bull; ${e=>e.localizedStrings&&s.Qf.Format(e.localizedStrings.nativeAdOnSaleText,e.assets.discount)}" 
                        />
                    `)}
                </msn-inline-group>
            `)}
            ${(0,r.z)(e=>c&&t,(0,n.qy)`
                ${R}
            `)}
        </msft-attribution>
    `)}
`},30337(e,t,a){a.d(t,{zN:()=>W,cC:()=>j});var i=a(53715),o=a(53537),n=a(89757),r=a(69259),d=a(56911),s=a(37903),l=a(38493),c=a(60815),p=a(66864),g=a(40450),h=a(45183);let m=class extends p.t{constructor(){super(...arguments),this.effectId="",this.intersectionRootMargin="-350px 0px -200px 0px",this.isAnimationValid=!1,this.starType="",this.isStaticMode=!1,this.updateAnimStatus=(e,t)=>{this.isAnimationValid!==e&&(this.isAnimationValid=e,e&&t&&setTimeout(()=>{t()},0))}}connectedCallback(){if(super.connectedCallback(),!this.isStaticMode){this.effectGroup=s.t.getEffectGroup();let e={root:this.intersectionRoot,rootMargin:this.intersectionRootMargin};this.effectGroup.register(this.effectId,this.highlightingRatingContainer,this.updateAnimStatus,e,!0,0)}}disconnectedCallback(){super.disconnectedCallback(),this.effectGroup&&this.effectGroup.unregister(this.effectId)}};(0,d.Cg)([(0,l.CF)({attribute:"rating"})],m.prototype,"rating",void 0),(0,d.Cg)([l.CF],m.prototype,"effectId",void 0),(0,d.Cg)([l.CF],m.prototype,"intersectionRoot",void 0),(0,d.Cg)([l.CF],m.prototype,"intersectionRootMargin",void 0),(0,d.Cg)([c.sH],m.prototype,"isAnimationValid",void 0),(0,d.Cg)([l.CF],m.prototype,"starType",void 0),(0,d.Cg)([(0,l.CF)({mode:"boolean",attribute:"isStaticMode"})],m.prototype,"isStaticMode",void 0),m=(0,d.Cg)([(0,h.TA)(g.PDj,"msn-native-ad-highlight-rating")],m);var u=a(92011),f=a(59669),y=a(22062),v=a(16559);let x=(0,f.A)` .stars-container{display:flex;justify-content:center;gap:8px}.animated-star1{animation:fadeIn 300ms}.animated-star2{animation:fadeIn 360ms}.animated-star3{animation:fadeIn 420ms}.animated-star4{animation:fadeIn 480ms}.animated-star5{animation:fadeIn 540ms}.star1,.star2,.star3,.star4,.star5{opacity:1}@keyframes fadeIn{0%{opacity:0;-webkit-transform:translate(0,30px);transform:translate(0,30px)}80%{opacity:1;-webkit-transform:translate(0,-10px);transform:translate(0,-10px)}100%{opacity:1;-webkit-transform:translate(0,0px);transform:translate(0,0px)}}`.withBehaviors(new v.e("layoutStyle"),new y.X(["isStaticMode"],e=>{let t="";return e.isStaticMode&&(t+=`.star1, .star2, .star3, .star4, .star5{
                    opacity: 1;
                 }`),(0,f.A)`${t}`}));var b=a(60402);let C=(0,n.qy)`
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M14.0627 1.25747C14.8552 -0.419156 17.1448 -0.419156 17.9372 1.25747L21.7106 9.24093L30.148 10.5211C31.9199 10.79 32.6274 13.0639 31.3453 14.3689L25.2398 20.5831L26.6812 29.3579C26.9838 31.2006 25.1315 32.6059 23.5466 31.7359L16 27.593L8.45337 31.7359C6.8685 32.6059 5.01614 31.2006 5.31883 29.3579L6.76011 20.5831L0.65476 14.3689C-0.627443 13.0639 0.0800934 10.79 1.85205 10.5211L10.2894 9.24093L14.0627 1.25747Z" fill="url(#paint0_linear)"/>
        <defs>
            <linearGradient id="paint0_linear" x1="0" y1="16" x2="32" y2="16" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF512F"/>
                <stop offset="1" stop-color="#DD2476"/>
            </linearGradient>
        </defs>
</svg>  
`,$=(0,n.qy)`
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.0014 4.79517e-07C15.2304 -0.000517523 14.4592 0.418646 14.0627 1.25746L10.2894 9.24092L1.85205 10.5211C0.0800935 10.79 -0.627443 13.0638 0.65476 14.3689L6.76011 20.5831L5.31883 29.3577C5.07924 30.8164 6.18983 32.0008 7.44924 32C7.78192 32.0002 8.12506 31.9178 8.45651 31.7358L16.0016 27.5938L23.5466 31.7358C25.1315 32.6059 26.9838 31.2006 26.6812 29.3577L25.2398 20.5831L31.3453 14.3689C32.6274 13.0638 31.9199 10.79 30.148 10.5211L21.7106 9.24092L17.9372 1.25746C17.5415 0.420067 16.7711 0.000919515 16.0014 4.79517e-07C16.0011 4.79517e-07 16.0017 4.79517e-07 16.0014 4.79517e-07ZM16.0025 25.0539V2.82752L19.614 10.4684C19.9286 11.1341 20.5368 11.5956 21.2405 11.7024L29.3214 12.9285L23.474 18.8802C22.9649 19.3985 22.7326 20.1451 22.8527 20.877L24.2331 29.281L17.0053 25.3131C16.6914 25.1408 16.3471 25.0544 16.0025 25.0539Z" fill="url(#paint0_linear)"/>
        <defs>
            <linearGradient id="paint0_linear" x1="0" y1="16" x2="32" y2="16" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF512F"/>
                <stop offset="1" stop-color="#DD2476"/>
            </linearGradient>
        </defs>
</svg>
`,w=(0,n.qy)`
<svg width=32 height=32 viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M30.15,10.52,21.71,9.24l-3.77-8a2.12,2.12,0,0,0-3.88,0l-3.77,8L1.85,10.52a2.29,2.29,0,0,0-1.2,3.85l6.11,6.21L5.32,29.36A2.23,2.23,0,0,0,7.45,32a2.11,2.11,0,0,0,1-.26L16,27.59l7.55,4.15a2.18,2.18,0,0,0,3.13-2.38l-1.44-8.78,6.11-6.21A2.29,2.29,0,0,0,30.15,10.52Zm-6.68,8.36a2.33,2.33,0,0,0-.62,2l1.38,8.4-7.22-4a2.14,2.14,0,0,0-1-.26,2.1,2.1,0,0,0-1,.26l-7.23,4,1.38-8.4a2.33,2.33,0,0,0-.62-2L2.68,12.93l8.08-1.23a2.15,2.15,0,0,0,1.63-1.23L16,2.83l3.61,7.64a2.18,2.18,0,0,0,1.63,1.23l8.08,1.23Z" fill="url(#paint0_linear)"/>
            <linearGradient id="paint0_linear" x1="0" y1="16" x2="32" y2="16" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF512F"/>
                <stop offset="1" stop-color="#DD2476"/>
            </linearGradient>
        </defs>
</svg>
`,k=(0,n.qy)`
<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12.3049 1.10028C12.9983 -0.366762 15.0017 -0.366762 15.6951 1.10028L18.9968 8.08581L26.3795 9.206C27.9299 9.44126 28.549 11.4309 27.4271 12.5728L22.0849 18.0102L23.346 25.6882C23.6108 27.3006 21.9901 28.5302 20.6033 27.7689L14 24.1439L7.3967 27.7689C6.00993 28.5302 4.38912 27.3006 4.65397 25.6882L5.9151 18.0102L0.572915 12.5728C-0.549012 11.4309 0.0700817 9.44126 1.62055 9.206L9.00326 8.08581L12.3049 1.10028Z" fill="url(#paint0_linear_75_17843)"/>
    <defs>
        <linearGradient id="paint0_linear_75_17843" x1="14" y1="0" x2="14" y2="28" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEF4D"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
    </defs>
</svg>
`,T=(0,n.qy)`
<svg width="27" height="27" viewBox="0 0 27 27" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13.5012 4.04593e-07C12.8507 -0.00043666 12.2 0.353233 11.8654 1.06098L8.68171 7.79703L1.56267 8.8772C0.0675789 9.10405 -0.529405 11.0226 0.552454 12.1237L5.70384 17.367L4.48776 24.7705C4.28561 26.0014 5.22267 27.0007 6.2853 27C6.56599 27.0001 6.85552 26.9306 7.13518 26.7771L13.5013 23.2823L19.8674 26.7771C21.2047 27.5112 22.7676 26.3255 22.5122 24.7705L21.2961 17.367L26.4476 12.1237C27.5294 11.0226 26.9324 9.10405 25.4374 8.8772L18.3183 7.79703L15.1345 1.06098C14.8006 0.354431 14.1506 0.000775841 13.5012 4.04593e-07C13.5009 4.04593e-07 13.5015 4.04593e-07 13.5012 4.04593e-07ZM13.5021 21.1392V2.38572L16.5493 8.83267C16.8148 9.39443 17.328 9.7838 17.9217 9.87389L24.74 10.9084L19.8061 15.9301C19.3766 16.3675 19.1806 16.9974 19.282 17.615L20.4467 24.7058L14.3482 21.3579C14.0834 21.2126 13.7928 21.1397 13.5021 21.1392Z" fill="url(#paint0_linear_75_17845)"/>
    <defs>
        <linearGradient id="paint0_linear_75_17845" x1="13.5" y1="0" x2="13.5" y2="27" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEC4A"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
    </defs>
</svg>
`,S=(0,n.qy)`
<svg width="27" height="27" viewBox="0 0 27 27" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 0C13.5004 0 13.5008 -2.66365e-07 13.5012 0C14.1506 0.00077608 14.8006 0.354431 15.1345 1.06098L18.3183 7.79703L25.4373 8.8772C26.9324 9.10405 27.5294 11.0226 26.4476 12.1237L21.2961 17.367L22.5122 24.7705C22.7676 26.3255 21.2047 27.5112 19.8674 26.7771L13.5013 23.2823L13.5 23.283V0ZM13.5021 2.38572V21.1392C13.7928 21.1397 14.0834 21.2126 14.3482 21.3579L20.4467 24.7058L19.282 17.615C19.1806 16.9974 19.3766 16.3675 19.8061 15.9301L24.74 10.9084L17.9217 9.87389C17.328 9.78379 16.8147 9.39443 16.5493 8.83267L13.5021 2.38572Z" fill="url(#paint0_linear_75_17858)"/>
    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 0C13.4996 0 13.4992 -2.66298e-07 13.4988 0C12.8494 0.000775841 12.1994 0.354431 11.8655 1.06098L8.68165 7.79703L1.56265 8.8772C0.0675583 9.10405 -0.529369 11.0226 0.552422 12.1237L5.70389 17.367L4.48775 24.7705C4.23243 26.3255 5.7953 27.5112 7.13255 26.7771L13.4987 23.2823L13.5 23.283V0ZM13.5 0C13.5004 0 13.5008 -2.72162e-07 13.5012 0ZM13.4979 2.38572V21.1392C13.2072 21.1397 12.9166 21.2126 12.6518 21.3579L6.55331 24.7058L7.718 17.615C7.8194 16.9974 7.62335 16.3675 7.19385 15.9301L2.26004 10.9084L9.07834 9.87389C9.67203 9.78379 10.1852 9.39443 10.4507 8.83267L13.4979 2.38572Z" fill="url(#paint1_linear_75_17858)"/>
    <g clip-path="url(#clip0_75_17858)">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 1.18459e-07C13.5004 1.18459e-07 13.5008 -1.48073e-07 13.5012 1.18459e-07C14.1506 0.00077608 14.8006 0.354431 15.1345 1.06098L18.3183 7.79703L25.4373 8.8772C26.9324 9.10405 27.5294 11.0226 26.4476 12.1237L21.2961 17.367L22.5122 24.7705C22.7676 26.3255 21.2047 27.5112 19.8674 26.7771L13.5013 23.2823L13.5 23.283V1.18459e-07ZM13.5021 2.38572V21.1392C13.7928 21.1397 14.0834 21.2126 14.3482 21.3579L20.4467 24.7058L19.282 17.615C19.1806 16.9974 19.3766 16.3675 19.8061 15.9301L24.74 10.9084L17.9217 9.87389C17.328 9.7838 16.8147 9.39443 16.5493 8.83267L13.5021 2.38572Z" fill="url(#paint2_linear_75_17858)"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 1.20919e-07C13.4996 1.20919e-07 13.4992 -1.45474e-07 13.4988 1.20919e-07C12.8494 0.000775962 12.1994 0.354431 11.8655 1.06098L8.68165 7.79703L1.56265 8.8772C0.0675581 9.10405 -0.529371 11.0226 0.55242 12.1237L5.70389 17.367L4.48775 24.7705C4.23243 26.3255 5.7953 27.5112 7.13255 26.7771L13.4987 23.2823L13.5 23.283V1.20919e-07ZM13.5 1.20919e-07C13.5004 1.20919e-07 13.5008 -1.51148e-07 13.5012 1.20919e-07H13.5ZM13.4979 2.38572V21.1392C13.2072 21.1397 12.9166 21.2126 12.6518 21.3579L6.55331 24.7058L7.718 17.615C7.8194 16.9974 7.62335 16.3675 7.19385 15.9301L2.26003 10.9084L9.07834 9.87389C9.67203 9.78379 10.1853 9.39443 10.4507 8.83267L13.4979 2.38572Z" fill="url(#paint3_linear_75_17858)"/>
    </g>
    <defs>
        <linearGradient id="paint0_linear_75_17858" x1="13.5" y1="0" x2="13.5" y2="27" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEC4A"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
        <linearGradient id="paint1_linear_75_17858" x1="13.5012" y1="0" x2="13.5012" y2="27" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEC4A"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
            <linearGradient id="paint2_linear_75_17858" x1="13.5" y1="0" x2="13.5" y2="27" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEC4A"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
        <linearGradient id="paint3_linear_75_17858" x1="13.5012" y1="0" x2="13.5012" y2="27" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FFEC4A"/>
            <stop offset="1" stop-color="#EC9E06"/>
        </linearGradient>
            <clipPath id="clip0_75_17858">
            <rect width="27" height="27" fill="white"/>
        </clipPath>
    </defs>
</svg>
`,F="yellow",z=(0,n.qy)`<div class="stars-container" ${(0,b.K)("highlightingRatingContainer")}><div class="${e=>e.isAnimationValid?"animated-star1":"star1"}" style="${e=>"rtl"===document.dir?"transform:rotateY(180deg)":""}">${e=>A(e.rating,e.starType)}</div><div class="${e=>e.isAnimationValid?"animated-star2":"star2"}" style="${e=>"rtl"===document.dir?"transform:rotateY(180deg)":""}">${e=>A(e.rating-2,e.starType)}</div><div class="${e=>e.isAnimationValid?"animated-star3":"star3"}" style="${e=>"rtl"===document.dir?"transform:rotateY(180deg)":""}">${e=>A(e.rating-4,e.starType)}</div><div class="${e=>e.isAnimationValid?"animated-star4":"star4"}" style="${e=>"rtl"===document.dir?"transform:rotateY(180deg)":""}">${e=>A(e.rating-6,e.starType)}</div><div class="${e=>e.isAnimationValid?"animated-star5":"star5"}" style="${e=>"rtl"===document.dir?"transform:rotateY(180deg)":""}">${e=>A(e.rating-8,e.starType)}</div><div>`,A=(e,t)=>(0,n.qy)` ${(0,r.z)(t=>e-2>=0,(e=>{switch(e){case"red":return C;case F:return k;default:return C}})(t))} ${(0,r.z)(t=>e-2<0,(0,n.qy)` ${(0,r.z)(t=>e-1>=0,(e=>{switch(e){case"red":return $;case F:return T;default:return $}})(t))} ${(0,r.z)(t=>e-1<0,(0,n.qy)` ${(0,r.z)(t=>e-1<0,(e=>{switch(e){case"red":return w;case F:return S;default:return w}})(t))} `)} `)} `,L=class extends m{};L=(0,d.Cg)([(0,u.E)({name:"msn-native-ad-highlight-rating",template:z,styles:x,shadowOptions:{delegatesFocus:!0}})],L);var M=a(63456);let _=e=>"msn-highlight-rating-nondr-red"===(0,i.zT)(e)||"msn-highlight-rating-nondr-yellow"===(0,i.zT)(e)||"msn-highlight-rating-nondr-yellow-static"===(0,i.zT)(e);a(60592).O;let B=class extends p.t{constructor(){super(...arguments),this.badgeText="",this.badgeTextColor="#FFFFFF",this.badgeBackgroundColor="#0078D4",this.badgeTextSize="12",this.badgeTextLineHeight="16",this.badgeTextFontWeight="600",this.badgeBorderRadius="4",this.paddingTop="",this.paddingBottom="",this.paddingLeft="",this.paddingRight=""}};(0,d.Cg)([(0,l.CF)({attribute:"badge-text"})],B.prototype,"badgeText",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-text-color"})],B.prototype,"badgeTextColor",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-background-color"})],B.prototype,"badgeBackgroundColor",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-text-size"})],B.prototype,"badgeTextSize",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-text-line-height"})],B.prototype,"badgeTextLineHeight",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-text-font-weight"})],B.prototype,"badgeTextFontWeight",void 0),(0,d.Cg)([(0,l.CF)({attribute:"badge-border-radius"})],B.prototype,"badgeBorderRadius",void 0),(0,d.Cg)([(0,l.CF)({attribute:"padding-top"})],B.prototype,"paddingTop",void 0),(0,d.Cg)([(0,l.CF)({attribute:"padding-bottom"})],B.prototype,"paddingBottom",void 0),(0,d.Cg)([(0,l.CF)({attribute:"padding-left"})],B.prototype,"paddingLeft",void 0),(0,d.Cg)([(0,l.CF)({attribute:"padding-right"})],B.prototype,"paddingRight",void 0),B=(0,d.Cg)([(0,h.TA)(g.PDj,"msn-native-ad-badge")],B);let I=(0,f.A)` `.withBehaviors(new v.e("layoutStyle"),new y.X(["badgeTextSize","badgeTextLineHeight","badgeBackgroundColor","badgeBorderRadius","paddingTop","paddingBottom","paddingLeft","paddingRight","badgeTextColor","badgeTextFontWeight"],e=>{let t=` .native-ad-badge{line-height:${e.badgeTextLineHeight}px;
                font-size: ${e.badgeTextSize}px;
                background-color: ${e.badgeBackgroundColor};
                border-radius: ${e.badgeBorderRadius}px;
                padding-top:${e.paddingTop}px;
                padding-bottom:${e.paddingBottom}px;
                padding-left:${e.paddingLeft}px;
                padding-right:${e.paddingRight}px;
                color:${e.badgeTextColor};
                font-weight:${e.badgeTextFontWeight};
            }
        `;return(0,f.A)`${t}`})),q=(0,n.qy)`<span class="native-ad-badge">${e=>e.badgeText}</span>`,D=class extends B{};D=(0,d.Cg)([(0,u.E)({name:"msn-native-ad-badge",template:q,styles:I})],D);var E=a(60274),H=a(98080),P=a(64984),R=a(48566),U=a(91277),N=a(589),O=a(64987);N.r,O.DecorationFreeShippingButton;var V=a(2188),G=a(73888);P.e,E.w,H.j;let Z=(e,t)=>{e.template?.progressiveDisplay&&e.hoverState&&e.hoverState.isHovered!==t&&(e.hoverState.isHovered=t)},W=(e,t)=>{let a;if((0,i.Ni)(e))return(0,n.qy)`
        <div class="heading" part="heading" style="display: flex; align-items: center;">
            ${(0,r.z)(e=>t,(0,n.qy)`
                <h3 class="info-pane-slide-title" style="pointer-events: none; flex: 1;" part="info-pane-slide-title">
                    ${e=>e.title}
                </h3>
            `)}
            ${(0,r.z)(e=>!t,(0,n.qy)`
                <div class="cta-title" style="flex:1; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient: vertical;">
                    <span style = "font-size: ${e=>e.feedFontSize}px; 
                        line-height: "28px";
                        "${e=>e.fontFamilyOnCardContent?`font-family:${e.fontFamilyOnCardContent}, Segoe UI, Segoe UI Midlevel, Arial, Sans-Serif;`:""}"
                    ">
                        ${e=>e.title}
                    </span>
                </div>
            `)}
            <div class="cta-button" style="margin-inline-start: 4px; z-index: 2;">
                <msn-native-ad-call-to-action 
                    text=${e=>e.localizedStrings.nativeAdLearnMoreText||"learn more"}
                    default-background-color="#C6C0BA"
                    background-color="${e=>e.layoutColor}"
                    color="#000000"
                    is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
                    cta-mode="arrow"
                    destination-url=${e=>e.destinationUrl}
                    tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
                    ${(0,V.Ib)(!0,!1)}
                >
                </msn-native-ad-call-to-action>
        </div>`;if((0,i.eC)(e))return(0,n.qy)`
            <div class="sale-highlight-badge" style="position: absolute; bottom: 268px;">
                <msn-native-ad-sale-highlight-badge
		            component-name="sale-highlight-badge"
                    discount-text="${e=>R.Qf.Format(e.localizedStrings?.nativeAdOnSaleTextCapital||"{0}% OFF",e.assets?.discount)}"
                >
                </msn-native-ad-sale-highlight-badge>
            </div>
        `;if((0,i.Ij)(e)){let{displayedText:a="",promotionalText:o="",redemptionCode:d="",daysFromExpiration:s="",destinationURL:l=""}=e.assets.specialOffer;return(0,n.qy)`
            <style>
                ${(0,r.z)(e=>e.show&&t,(0,n.qy)`
                    msft-info-pane-slide msft-attribution[slot="attribution"] {
                        bottom: 159px;
                        position: absolute;
                        z-index: 2;
                    }
                `)}
                ${(0,r.z)(e=>!e.show&&t,(0,n.qy)`
                msft-info-pane-slide msft-attribution[slot="attribution"] {
                    bottom: 261px;
                    position: absolute;
                    z-index: 2;
                }
            `)}
            </style>
            <msft-attribution 
                slot="attribution"
                @click=${()=>e.destinationUrl&&window.open(e.destinationUrl)}
                ${(0,V.Ib)(!0,!1)}
            >
                <msn-native-ad-special-offer
                    ${(0,V.Ib)(!0,!1)}
                    :localizedStrings=${e=>e.localizedStrings}
                    displayed-text="${a}"
                    promotional-text="${o}"
                    redemption-code="${d}"
                    days-from-expiration="${s}"
                    destination-url="${l}"
                    margin-left="-6"
                    ${t?"underneath-pop-up":""}
                    display-expiration-date=${e=>(0,i.G)(e)}
                ></msn-native-ad-special-offer>
            </msft-attribution>
        `}if(_(e)||["msn-default-rating-nondr-yellow-static","msn-combo-rating-nondr"].includes((0,i.zT)(e)))return(0,n.qy)`
            ${(0,r.z)(e=>!t,(0,n.qy)`
                <style>
                    ${(0,r.z)(e=>"msn-highlight-rating-nondr-red"===(0,i.zT)(e),(0,n.qy)`
                        msft-attribution::part(content) {
                            width: 100%;
                        }
                    `)}
                    ${(0,r.z)(e=>_(e),(0,n.qy)`
                        msft-attribution[slot="attribution"] {
                            height: 64px;
                        }
                        msn-native-ad-highlight-rating {
                            position: absolute;
                            bottom: 0;
                        }
                    `)}
                </style>
                <msft-attribution slot="attribution">
                    ${(0,n.qy)`
    ${(0,r.z)(e=>_(e)&&(0,M.A)(e,"assets.rating"),(0,n.qy)`
        <msn-native-ad-highlight-rating
            effectId=${e=>e.id}
            rating=${e=>e.assets&&e.assets.rating}
            starType=${e=>"msn-highlight-rating-nondr-red"===(0,i.zT)(e)?"red":F}
            :isStaticMode=${e=>"msn-highlight-rating-nondr-yellow-static"===(0,i.zT)(e)}
        >
        </msn-native-ad-highlight-rating>
    `)}
    ${(0,r.z)(e=>!_(e)&&(0,M.A)(e,"assets.rating"),(0,n.qy)`
        <decoration-rating
            rating=${e=>e.assets.rating}
            is-show-review=${!1}
        >
        </decoration-rating>
    `)}
`}
                </msft-attribution>
            `)}
            ${(0,r.z)(e=>t,(0,n.qy)`
            <msft-attribution slot="attribution">
                <decoration-rating
                    rating=${e=>e.assets.rating}
                    review-data=${e=>e.assets.review}
                    is-info-pane=${t}
                ></decoration-rating>
                </msft-attribution>
            `)}
        `;return(a=e,"msn-freeshipping-inline-nondr"===(0,i.zT)(a)||"msn-freeshipping-top-left-nondr"===(0,i.zT)(a)||"msn-freeshipping-top-right-nondr"===(0,i.zT)(a)||"msn-combo-freeshipping-nondr"===(0,i.zT)(a)||"msn-freeshipping-plain-text-nondr"===(0,i.zT)(e))?(0,n.qy)`
            <div class="native-ad-free-shipping-badge" style="position: absolute; bottom: 268px;">
                <msn-native-ad-badge badge-text="${e=>(0,M.A)(e.localizedStrings,"nativeAdFreeShippingText")}" padding-top="1" padding-bottom="3" padding-left="8" padding-right="8">
                </msn-native-ad-badge>
            </div>
        `:"msn-combo-sold-nondr"===(0,i.zT)(e)||"msn-combo-return-policy-nondr"===(0,i.zT)(e)||"msn-combo-condition-nondr"===(0,i.zT)(e)?(0,n.qy)`
            <msft-attribution slot="attribution" class="margin-5-decoration">
                ${(0,n.qy)`
        <decoration-plain-text
            data=${e=>{let t;return"msn-combo-sold-nondr"===(t=(0,i.zT)(e))&&(0,M.A)(e,"assets.sold")?e.assets.sold:"msn-combo-return-policy-nondr"===t&&(0,M.A)(e,"assets.returnPolicy")?e.assets.returnPolicy:"msn-combo-condition-nondr"===t&&(0,M.A)(e,"assets.condition")?e.assets.condition:void 0}}
        ></decoration-plain-text>
    `}
            </msft-attribution>
        `:(0,n.qy)`${e=>(0,G.T)("attribution",!1,e.template?.progressiveDisplay,e.hoverState?.isHovered?65:25,e.hoverState?.isHovered,!1,(0,o.$q)(e),t=>(0,o.IH)(e,t))}`},j=(0,n.qy)`
    <style>
        :host {
            --article-native-ad-heading-margin-bottom: -12px;
        }
        msft-ad-label {
            margin-inline-end: 8px;
        }

        ${(0,r.z)(e=>!e.assets?.specialOffer,(0,n.qy)`
        msft-article msft-attribution[slot="attribution"] {
            display: flex;
            align-self: end;
        }
        `)}

        ${(0,r.z)(e=>e.assets?.specialOffer,(0,n.qy)`
            msft-article msft-attribution[slot="attribution"] {
                cursor: pointer;
                display: flex;
                align-self: end;
                overflow: visible;
                max-width: 300px;
                z-index: 2;
                margin-bottom: 5px;
            }
            
            msft-article msft-attribution[slot="attribution"]::part(content) {
                overflow: visible;
            }
        `)}

        ${(0,r.z)(e=>e.assets?.rating,(0,n.qy)`
            msft-article msft-attribution[slot="attribution"] {
                margin-bottom: 1px;
            }
        `)}

        msft-article span.title_1x_2y,
        msft-article span.title_2x_2y {
            font-size: 20px;
        }
        
        ${(0,r.z)(e=>e.template?.nativeAdMode==="adult",(0,n.qy)`
            msft-article div[slot="end-action"] {
                --neutral-foreground-rest: white;
            }
        `)}
        msft-article div[slot="end-action"] {
            display: flex;
            align-items: center;
            --control-corner-radius: 100;
            position: relative;
            bottom: -8px;
        }

        msft-attribution[slot="start-action"] {
            margin-top: 15px;
        }
        

        msft-article a.ad-choice-icon {
            display: inline-flex;
            justify-content: center;
            min-width: calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px); 
        }

        msft-article.native-ad, msft-article.${(0,U.nP)("native-ad")} {
            --article-native-ad-heading-margin-bottom: -1px;
            --heading-max-lines: 2;
        }

        msft-article.nativeAdVideo-river::part(image) {
            z-index: 2;
        }

        msft-article.native-ad.gradient, msft-article.${(0,U.nP)("native-ad")}.gradient {
            --article-native-ad-actions-height: 33px;
            --article-native-ad-heading-margin-bottom: 6px;
        }

        msft-article.native-ad::part(heading), msft-article.${(0,U.nP)("native-ad")}::part(heading) {
            margin-bottom: var(--article-native-ad-heading-margin-bottom);
            color: var(--msft-card-font-color);
        }

        msft-article.native-ad.long-gradient::part(gradient), msft-article.${(0,U.nP)("native-ad")}.long-gradient::part(gradient) {
            top: -55px;
        }

        ${(0,r.z)(e=>e.template?.immersiveThemeColor,(0,n.qy)`
            @media (prefers-color-scheme: light) {
                msft-article::part(gradient) {
                    background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.8) 45.83%, #FFFFFF 100%);
                }

                msft-article::part(article) {
                    background: #FFFFFF;
                }
                msft-article::part(heading) {
                    color: #000000;
                }
            }

            @media (prefers-color-scheme: dark) {
                msft-article::part(gradient) {
                    background: linear-gradient(180deg, transparent 0%, rgba(43, 43, 43, 0.8) 62.5%, #2E2E2E 100% );
                }

                msft-article::part(article) {
                    background: #2B2B2B;
                }
                msft-article::part(heading) {
                    color: #FFFFFF;
                }
            }
        `)}

        ${(0,r.z)(e=>e.layoutGap,(0,n.qy)`
            msft-article-card[size="_1x_2y"] msft-article::part(gradient) {
                bottom: ${e=>67+e.layoutGap}px;
            }

            msft-article-card[size="_2x_2y"] msft-article::part(gradient) {
                bottom: 0px;
            }
        `)}

        ${(0,r.z)(e=>"rtl"===document.dir,(0,n.qy)`
            msft-article-card msft-article msn-inline-group::part(inline-item) {
                padding-left: 12px;
                padding-right: unset;
            }
        `)}

        ${(0,r.z)(e=>["ltr",""].includes(document.dir),(0,n.qy)`
            msft-article-card msft-article msn-inline-group::part(inline-item) {
                padding-right: 12px;
            }
        `)}

        :host {
            grid-area:${e=>e.gridArea};
        }

        msft-article-card[size="_1x_2y"],
        msft-article-card[size="_2x_2y"] {
            --card-width: auto;
            --card-height: auto;
        }

        ${(0,r.z)(e=>!e.assets?.specialOffer,(0,n.qy)`
        msft-attribution {
            max-width: 100%;
        }
    `)}

        msft-article.native-ad::part(actions), msft-article.${(0,U.nP)("native-ad")}::part(actions) {
            height: var(--article-native-ad-actions-height);
            align-items: center;
        }
        
        msft-article.two-lines-heading::part(heading) {
            -webkit-line-clamp: 2;
        }

        msft-article.special-offer::part(heading),
        msft-article.deco-rating::part(heading),
        msft-article.deco-free-shipping::part(heading) {
            margin-bottom: -1px;
        }

        msft-article.three-lines-heading::part(heading) {
            -webkit-line-clamp: 3;
        }
        msft-article-card msft-article::part(heading):after {
            top: calc(100% - 304px - 8px);
        }

        ${(0,r.z)(e=>e.useTitleFontSize,(0,n.qy)`
            msft-article-card msft-article {
                --msft-article-heading-font-size: ${e=>e.useTitleFontSize}px;
                --msft-article-heading-line-height: 24px;
            }

            msft-article-card msft-article::part(attribution) {
                height: 28px;
            }

            msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(heading) {
                margin-bottom: -4px;
            }

            msft-article-card[size="_1x_2y"] msft-article:not(.no-image)::part(gradient) {
                background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 46%, var(--gradient-color) 100%);
                top: 5px;
            }
        `)}

        msft-article-card[size="_1x_2y"] msft-article[id="native_ad_${e=>e.id}"]::part(gradient) {
            top: 11px;
            bottom: 79px;
            background: linear-gradient(180deg, transparent 0%, var(--gradient-mid-color) 56%, var(--gradient-color) 100%);
        }

    </style>
    <msft-article-card
        style="
            grid-area:${e=>e.gridArea};
            height: ${e=>e.ContentCardImageSizes._300x304.height}px;
        "
        size="${e=>e.cardSize}"
        card-fill-color=${e=>e.template?.nativeAdMode==="adult"?"#2E2E2E":e.adBackgroundColor}
    >
        <msft-article
            id="native_ad_${e=>e.id}"
            href=${e=>e.destinationUrl}
            target="_blank"
            title=${e=>e.title}
            ?image-priority=${e=>e.imagePriority}
            class=${e=>{let t;return(t=[e.template?.progressiveDisplay&&e.hasAnyInlineDecoration?"native-ad-content-card":""]).push("native-ad"),e.hasAnyInlineDecoration||e.adSlugGA?t.push("two-lines-heading"):t.push("three-lines-heading"),e.assets?.specialOffer&&t.push("special-offer"),e.assets?.rating&&t.push("deco-rating"),e.assets?.freeShipping&&t.push("deco-free-shipping"),t.filter(e=>e).join(" ")}}
            data-t="${e=>e.id?e.adTelemetryContext.nativeAdCard.getMetadataTag():""}"
            :anchorTelemetryTag=${e=>e.adTelemetryContext&&e.adTelemetryContext.destination&&e.adTelemetryContext.destination.getMetadataTag()}
            ${(0,V.Ib)()}
            @mouseenter=${e=>Z(e,!0)}
            @mouseleave=${e=>Z(e,!1)}
        >
            ${e=>(0,i.Ni)(e)?"":e.renderTitle()}
            ${e=>((e,t,a={})=>(0,n.qy)`
    <!--
        Only use placeholder when the card size is 1x_2y
    -->
    ${(0,r.z)(e=>e.cardSize===e.FeedLayoutCardSize._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;">
            ${e=>e.renderImageTag("anim-content",a)}
        <div>
    `)}
    ${(0,r.z)(e=>e.cardSize===e.FeedLayoutCardSize._1x_2y&&!e.imageData,(0,n.qy)`
        <div slot="${e}" style="width: ${t.width}px;height: ${t.height}px;"></div>
    `)}
    ${(0,r.z)(e=>e.cardSize!==e.FeedLayoutCardSize._1x_2y&&e.imageData,(0,n.qy)`
        <div slot="${e}">
            ${e=>e.renderImageTag("anim-content",a)}
        </div>
    `)}
`)("image",e.ContentCardImageSizes._300x225)}
            ${e=>W(e)}
            ${e=>e.renderStartSection("start-action",e.destinationUrl)}
            ${e=>e.renderEndSection("end-action")}
        </msft-article>
    </msft-article-card>
`},82988(e,t,a){a.d(t,{UN:()=>k});var i=a(56911),o=a(38493),n=a(60815),r=a(40450),d=a(45183),s=a(66864);let l=class extends s.t{constructor(){super(...arguments),this.disclaimer="",this.disclaimerTooltip="Disclaimer",this.popupMargin=0,this.url="",this.isHovered=!1}updateDisclaimerHoverState(e){this.isHovered=e}connectedCallback(){super.connectedCallback()}};(0,i.Cg)([(0,o.CF)({attribute:"disclaimer"})],l.prototype,"disclaimer",void 0),(0,i.Cg)([(0,o.CF)({attribute:"disclaimer-tooltip"})],l.prototype,"disclaimerTooltip",void 0),(0,i.Cg)([(0,o.CF)({attribute:"popup-margin"})],l.prototype,"popupMargin",void 0),(0,i.Cg)([(0,o.CF)({attribute:"url"})],l.prototype,"url",void 0),(0,i.Cg)([(0,o.CF)({attribute:"tel-metadata"})],l.prototype,"telemetryMetadata",void 0),(0,i.Cg)([n.sH],l.prototype,"isHovered",void 0),l=(0,i.Cg)([(0,d.TA)(r.PDj,"msn-native-ad-disclaimer")],l);var c=a(92011),p=a(59669),g=a(22062),h=a(16559);let m=(0,p.A)`
.native-ad-disclaimer-container{width:32px;height:32px;cursor:pointer}.native-ad-disclaimer-container svg{position:absolute;margin-inline:9px;margin-top:9px}.disclaimer-popup-container{position:absolute;bottom:100%;width:32px;margin-inline:9px}.disclaimer-popup-container svg{margin-inline:0px;margin-top:0px}.disclaimer-popup{position:relative;color:var(--fill-color);background:var(--neutral-foreground-rest);padding:8px;font-size:12px;width:152px;max-width:152px;max-height:48px;bottom:7px;border-radius:2px;z-index:1}.disclaimer-popup-text{-webkit-line-clamp:2;text-overflow:ellipsis;overflow:hidden;white-space:normal;display:-webkit-box;-webkit-box-orient:vertical;text-align:center;font-size:12px}.disclaimer-popup-arrow{height:15px;width:15px;position:absolute;bottom:0px}.disclaimer-popup-arrow svg rect{fill:var(--neutral-foreground-rest)}.native-ad-disclaimer-container svg path{fill:var(--neutral-foreground-rest)}@media (forced-colors:active){.disclaimer-popup{color:buttonface;background:buttontext}.disclaimer-popup-arrow svg rect{fill:buttontext}.native-ad-disclaimer-container svg path{fill:buttontext}}`.withBehaviors(new h.e("layoutStyle"),new g.X(["popupMargin"],e=>{let t=`${e.popupMargin?e.popupMargin-168-5:5}px`;return(0,p.A)` .disclaimer-popup.disclaimer-popup-dynamic-style{margin-inline:${t}}`}));var u=a(89757),f=a(69259);let y=(0,u.qy)`
<svg width="15" height="15" viewBox="0 0 23 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<rect y="12" width="16" height="16" transform="rotate(-45 0 12)" fill="white"/>
</svg>
`,v=(0,u.qy)`
<svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M7.5 15C6.80729 15 6.14323 14.9115 5.50781 14.7344C4.8724 14.5573 4.27344 14.3073 3.71094 13.9844C3.14844 13.6615 2.64323 13.2708 2.19531 12.8125C1.7474 12.3542 1.35677 11.8464 1.02344 11.2891C0.690104 10.7318 0.4375 10.1354 0.265625 9.5C0.09375 8.86458 0.00520833 8.19792 0 7.5C0 6.80729 0.0885417 6.14323 0.265625 5.50781C0.442708 4.8724 0.692708 4.27344 1.01562 3.71094C1.33854 3.14844 1.72917 2.64323 2.1875 2.19531C2.64583 1.7474 3.15365 1.35677 3.71094 1.02344C4.26823 0.690104 4.86458 0.4375 5.5 0.265625C6.13542 0.09375 6.80208 0.00520833 7.5 0C8.19271 0 8.85677 0.0885417 9.49219 0.265625C10.1276 0.442708 10.7266 0.692708 11.2891 1.01562C11.8516 1.33854 12.3568 1.72917 12.8047 2.1875C13.2526 2.64583 13.6432 3.15365 13.9766 3.71094C14.3099 4.26823 14.5625 4.86458 14.7344 5.5C14.9062 6.13542 14.9948 6.80208 15 7.5C15 8.19271 14.9115 8.85677 14.7344 9.49219C14.5573 10.1276 14.3073 10.7266 13.9844 11.2891C13.6615 11.8516 13.2708 12.3568 12.8125 12.8047C12.3542 13.2526 11.8464 13.6432 11.2891 13.9766C10.7318 14.3099 10.1354 14.5625 9.5 14.7344C8.86458 14.9062 8.19792 14.9948 7.5 15ZM7.5 1C6.90104 1 6.32552 1.07812 5.77344 1.23438C5.22135 1.39062 4.70573 1.60938 4.22656 1.89062C3.7474 2.17188 3.30729 2.51042 2.90625 2.90625C2.50521 3.30208 2.16667 3.73958 1.89062 4.21875C1.61458 4.69792 1.39583 5.21615 1.23438 5.77344C1.07292 6.33073 0.994792 6.90625 1 7.5C1 8.09375 1.07812 8.66667 1.23438 9.21875C1.39062 9.77083 1.60938 10.2891 1.89062 10.7734C2.17188 11.2578 2.51042 11.6979 2.90625 12.0938C3.30208 12.4896 3.73958 12.8281 4.21875 13.1094C4.69792 13.3906 5.21615 13.6094 5.77344 13.7656C6.33073 13.9219 6.90625 14 7.5 14C8.09375 14 8.66667 13.9219 9.21875 13.7656C9.77083 13.6094 10.2891 13.3906 10.7734 13.1094C11.2578 12.8281 11.6979 12.4896 12.0938 12.0938C12.4896 11.6979 12.8281 11.2604 13.1094 10.7812C13.3906 10.3021 13.6094 9.78385 13.7656 9.22656C13.9219 8.66927 14 8.09375 14 7.5C14 6.90625 13.9219 6.33333 13.7656 5.78125C13.6094 5.22917 13.3906 4.71094 13.1094 4.22656C12.8281 3.74219 12.4896 3.30208 12.0938 2.90625C11.6979 2.51042 11.2604 2.17188 10.7812 1.89062C10.3021 1.60938 9.78385 1.39062 9.22656 1.23438C8.66927 1.07812 8.09375 1 7.5 1ZM7 6H8V11H7V6ZM7 4H8V5H7V4Z" fill="white"/>
</svg>
`,x=(0,u.qy)`
${(0,f.z)(e=>e.disclaimer,(0,u.qy)`<a href=${e=>e.url} target="_blank" data-t="${e=>e.telemetryMetadata}"><div class="native-ad-disclaimer-container native-ad-disclaimer-container-dynamic-style">${(0,f.z)(e=>e.isHovered,(0,u.qy)`<div class="disclaimer-popup-container"><div class="disclaimer-popup disclaimer-popup-offset disclaimer-popup-dynamic-style"><span class="disclaimer-popup-text">${e=>e.disclaimer}</span></div><div class="disclaimer-popup-arrow">${y}</div></div>`)}<div title="${e=>e.disclaimerTooltip}" @mouseenter=${e=>e.updateDisclaimerHoverState(!0)} @mouseleave=${e=>e.updateDisclaimerHoverState(!1)}>${v}</div></div></a>`)}
`,b=class extends l{};b=(0,i.Cg)([(0,c.E)({name:"msn-native-ad-disclaimer",template:x,styles:m})],b);var C=a(63456),$=a(2188);let w=e=>{let t=e?.adChoiceIconUrl,a=e?.isAdFeedbackV1Enabled&&e?.feedbackUrl;return t||a?t&&a?2:1:0},k=e=>(0,u.qy)`
    <msn-native-ad-disclaimer 
        ${(0,$.Ib)(!0,!1)}
        disclaimer=${e=>e.assets&&e.assets.disclaimer}
        disclaimer-tooltip=${e=>(0,C.A)(e.localizedStrings,"nativeAdDisclaimerText")}
        popup-margin=${e=>2===w(e)?103:1===w(e)?70:35}
        :layoutConfig=${t=>e?.layout}
        url=${e=>e.destinationUrl}
        tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
		component-name="${t=>e?.name}"
    >
    </msn-native-ad-disclaimer>
`},98224(e,t,a){a.d(t,{o:()=>r});var i=a(56911),o=a(38493),n=a(66864);class r extends n.t{constructor(){super(...arguments),this.customStyle=""}}(0,i.Cg)([o.CF],r.prototype,"data",void 0),(0,i.Cg)([(0,o.CF)({mode:"boolean",attribute:"is-info-pane"})],r.prototype,"isInfoPane",void 0),(0,i.Cg)([o.CF],r.prototype,"isExpanded",void 0),(0,i.Cg)([(0,o.CF)({attribute:"custom-style"})],r.prototype,"customStyle",void 0)},88971(e,t,a){a.d(t,{TK:()=>n,Xn:()=>o,fT:()=>i});let i={defaultDarkThemeColor:"var(--neutral-foreground-rest)",defaultLightThemeColor:"var(--neutral-foreground-rest)",defaultInfoPaneColor:"var(--neutral-foreground-rest)"},o=e=>e?i.defaultInfoPaneColor:i.defaultDarkThemeColor,n=e=>e?i.defaultInfoPaneColor:i.defaultLightThemeColor},64987(e,t,a){a.r(t),a.d(t,{DecorationFreeShippingButton:()=>C});var i=a(56911),o=a(92011),n=a(38493),r=a(40450),d=a(66864),s=a(45183);let l=class extends d.t{constructor(){super(...arguments),this.color="#036AC4",this.fontFamily="inherit"}};(0,i.Cg)([n.CF],l.prototype,"color",void 0),(0,i.Cg)([(0,n.CF)({attribute:"font-family"})],l.prototype,"fontFamily",void 0),(0,i.Cg)([n.CF],l.prototype,"icon",void 0),(0,i.Cg)([n.CF],l.prototype,"data",void 0),l=(0,i.Cg)([(0,s.TA)(r.PDj,"decoration-free-shipping-button")],l);var c=a(89757),p=a(69259);let g=class extends o.L{constructor(){super(...arguments),this.color="#036AC4",this.paddingVertical="0px",this.paddingHorizontal="9px",this.borderRadius="4px"}};(0,i.Cg)([n.CF],g.prototype,"color",void 0),(0,i.Cg)([n.CF],g.prototype,"height",void 0),(0,i.Cg)([(0,n.CF)({attribute:"padding-vertical"})],g.prototype,"paddingVertical",void 0),(0,i.Cg)([(0,n.CF)({attribute:"padding-horizontal"})],g.prototype,"paddingHorizontal",void 0),(0,i.Cg)([(0,n.CF)({attribute:"border-radius"})],g.prototype,"borderRadius",void 0),g=(0,i.Cg)([(0,s.TA)(r.PDj,"color-button")],g);var h=a(59669),m=a(22062);let u=(0,h.A)` .color-button-container{border-radius:4px;text-align:center;display:inline-block}`.withBehaviors(new m.X(["color","paddingVertical","paddingHorizontal","borderRadius","height"],e=>(0,h.A)` .color-button-container{background:${e.color};padding:${e.paddingVertical} ${e.paddingHorizontal} ${e.paddingVertical} ${e.paddingHorizontal};border-radius:${e.borderRadius};height:${e.height}}`)),f=(0,c.qy)`<div class="color-button-container"><slot name="icon-section"></slot><slot name="text-section"></slot></div>`,y=class extends g{};y=(0,i.Cg)([(0,o.E)({name:"color-button",template:f,styles:u})],y);let v=(0,c.qy)`<color-button color="${e=>e.color}" height="22px">${(0,p.z)(e=>e.icon,(0,c.qy)`<span slot="icon-section" class="freeshipping-icon"><pure-icon icon-name="${e=>e.icon}" icon-width="16" icon-height="12" /></span>`)}<span slot="text-section"><pure-text content="${e=>e.data}" custom-style="height: 28px; line-height: 20px; font-weight: 600; font-size: 16px" font-family="${e=>e.fontFamily}" /></span></color-button>`;var x=a(16559);let b=(0,h.A)` .freeshipping-icon{margin-right:3px}`.withBehaviors(new x.e("layoutStyle")),C=class extends l{};C=(0,i.Cg)([(0,o.E)({name:"decoration-free-shipping-button",template:v,styles:b})],C)},589(e,t,a){a.d(t,{r:()=>c});var i=a(56911),o=a(98224),n=a(92011),r=a(89757),d=a(11937),s=a(88971);d.M;let l=(0,r.qy)`<pure-text content="${e=>e.data}" custom-style="font-size: 16px" light-theme-color=${e=>(0,s.TK)(e.isInfoPane)} dark-theme-color=${e=>(0,s.Xn)(e.isInfoPane)} />`,c=class extends o.o{};c=(0,i.Cg)([(0,n.E)({name:"decoration-free-shipping",template:l})],c)},60592(e,t,a){a.d(t,{O:()=>h});var i=a(56911),o=a(40450),n=a(45183),r=a(98224);let d=class extends r.o{dataChanged(){this.plainText=JSON.parse(this.data)}};d=(0,i.Cg)([(0,n.TA)(o.PDj,"decoration-plain-text")],d);var s=a(92011),l=a(89757),c=a(11937),p=a(88971);c.M;let g=(0,l.qy)`<pure-text content="${e=>e.plainText.displayedText}" font-size="16" font-weight="400" light-theme-color=${e=>(0,p.TK)(e.isInfoPane)} dark-theme-color=${e=>(0,p.Xn)(e.isInfoPane)} />`,h=class extends d{};h=(0,i.Cg)([(0,s.E)({name:"decoration-plain-text",template:g})],h)},65281(e,t,a){a.d(t,{a:()=>u});var i=a(56911),o=a(98224),n=a(38493),r=a(92011),d=a(89757),s=a(69259),l=a(11937),c=a(88971),p=a(58888);l.M,p.g;let g=(0,d.qy)`<div class="special-offer-btn-container"><pure-text content="${e=>e.data}" custom-style="font-size: 12px; font-weight: 600; line-height: 16px; height: 16px;" light-theme-color=${e=>(0,c.TK)(e.isInfoPane)} dark-theme-color=${e=>(0,c.Xn)(e.isInfoPane)}></pure-text><pure-icon icon-name="rightArrow" icon-width="4.5" icon-height="8"></pure-icon></div>${(0,s.z)(e=>e.displayExpirationDate,(0,d.qy)`<pure-text content="${e=>e.expirationDate}" custom-style="font-size: 16px; font-weight: 600; margin-left: 2px;" light-theme-color=${e=>(0,c.TK)(e.isInfoPane)} dark-theme-color=${e=>(0,c.Xn)(e.isInfoPane)}></pure-text>`)}
`;var h=a(59669);let m=(0,h.A)` :host{cursor:pointer}.special-offer-btn-container{font-size:12px;background:#0078D4;padding:0 8px 2px;height:16px;line-height:16px;border-radius:4px;display:inline-block;text-align:center}pure-icon{margin-left:0px}`,u=class extends o.o{constructor(){super(...arguments),this.expirationDate="",this.displayExpirationDate=!1}};(0,i.Cg)([(0,n.CF)({attribute:"expiration-date"})],u.prototype,"expirationDate",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"display-expiration-date"})],u.prototype,"displayExpirationDate",void 0),u=(0,i.Cg)([(0,r.E)({name:"decoration-special-offer",template:g,styles:m})],u)},58888(e,t,a){a.d(t,{g:()=>g});var i=a(56911),o=a(92011),n=a(38493);class r extends o.L{constructor(){super(...arguments),this.iconName="",this.iconColor=""}}(0,i.Cg)([n.CF],r.prototype,"data",void 0),(0,i.Cg)([(0,n.CF)({attribute:"icon-name"})],r.prototype,"iconName",void 0),(0,i.Cg)([(0,n.CF)({attribute:"icon-width"})],r.prototype,"iconWidth",void 0),(0,i.Cg)([(0,n.CF)({attribute:"icon-height"})],r.prototype,"iconHeight",void 0),(0,i.Cg)([(0,n.CF)({attribute:"icon-color"})],r.prototype,"iconColor",void 0);var d=a(59669);let s=(0,d.A)`
`;var l=a(89757),c=a(69259);let p=(0,l.qy)`<template id="pure-icon">${e=>{let t,{iconWidth:a,iconHeight:i,iconColor:o}=e;return(0,l.qy)` ${(0,c.z)(e=>"check"===e.iconName,(0,l.qy)`
    <svg fill=${o} width=${a} height=${i} version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 12 12" enable-background="new 0 0 12 12" xml:space="preserve">
        <path d="M6,0C2.686,0,0,2.686,0,6s2.686,6,6,6s6-2.686,6-6S9.314,0,6,0z M9.207,5.207l-3.5,3.5&#xA; c-0.39,0.39-1.023,0.39-1.414,0l-1.5-1.5C2.785,7.199,2.776,7.191,2.768,7.182c-0.384-0.397-0.373-1.03,0.025-1.414&#xA; c0.397-0.384,1.03-0.373,1.414,0.025L5,6.586l2.793-2.793c0.008-0.008,0.016-0.017,0.025-0.025c0.397-0.384,1.03-0.373,1.414,0.025&#xA; C9.615,4.19,9.604,4.823,9.207,5.207z" />
    </svg>
`)} ${(0,c.z)(e=>"fullStar"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5.52351 0.471551C5.82068 -0.157184 6.6793 -0.157184 6.97646 0.471551L8.39149 3.46535L11.5555 3.94543C12.22 4.04625 12.4853 4.89895 12.0045 5.38833L9.71494 7.71866L10.2554 11.0092C10.3689 11.7002 9.67431 12.2272 9.07998 11.9009L6.24999 10.3474L3.42001 11.9009C2.82569 12.2272 2.13105 11.7002 2.24456 11.0092L2.78504 7.71866L0.495535 5.38833C0.014709 4.89895 0.280035 4.04625 0.94452 3.94543L4.10854 3.46535L5.52351 0.471551Z" fill="url(#paint0_linear)"></path>
        <defs>
            <linearGradient id="paint0_linear" x1="1.9375" y1="1.6875" x2="12.2493" y2="10.9867" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900"></stop>
                <stop offset="0.291667" stop-color="#FFB729"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
            </linearGradient>
        </defs>
    </svg>
`)} ${(0,c.z)(e=>"emptyStar"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 4 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5.27351 4.47155C5.57068 3.84282 6.4293 3.84281 6.72646 4.47155L8.14149 7.46535L11.3055 7.94543C11.97 8.04625 12.2353 8.89895 11.7545 9.38834L9.46494 11.7187L10.0054 15.0091C10.1189 15.7002 9.42431 16.2272 8.82998 15.9009L5.99999 14.3474L3.17001 15.9009C2.57569 16.2272 1.88105 15.7002 1.99456 15.0091L2.53504 11.7187L0.245535 9.38834C-0.235291 8.89895 0.030035 8.04625 0.69452 7.94543L3.85854 7.46535L5.27351 4.47155ZM5.99999 5.05831L4.64478 7.92564C4.52678 8.17531 4.29867 8.34836 4.0348 8.3884L1.00445 8.84819L3.19723 11.0801C3.38817 11.2745 3.4753 11.5544 3.43023 11.8289L2.91258 14.9804L5.62301 13.4924C5.85903 13.3628 6.14095 13.3628 6.37697 13.4924L9.08742 14.9804L8.56978 11.8289C8.52471 11.5544 8.61184 11.2745 8.80273 11.0801L10.9955 8.84819L7.96518 8.3884C7.70132 8.34836 7.47322 8.17531 7.35524 7.92564L5.99999 5.05831Z" fill="url(#paint0_linear)"></path>
        <defs>
            <linearGradient id="paint0_linear" x1="1.6875" y1="5.6875" x2="11.9993" y2="14.9867" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900"></stop>
                <stop offset="0.291667" stop-color="#FFB729"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
            </linearGradient>
        </defs>
    </svg>
`)} ${(0,c.z)(e=>"halfStar"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
            d="M5.27351 0.471548C5.57068 -0.15718 6.4293 -0.157186 6.72646 0.471548L8.14149 3.46535L11.3055 3.94543C11.97 4.04625 12.2353 4.89895 11.7545 5.38834L9.46494 7.71866L10.0054 11.0091C10.1189 11.7002 9.42431 12.2272 8.82998 11.9009L5.99999 10.3474L3.17001 11.9009C2.57569 12.2272 1.88105 11.7002 1.99456 11.0091L2.53504 7.71866L0.245535 5.38834C-0.235291 4.89895 0.030035 4.04625 0.69452 3.94543L3.85854 3.46535L5.27351 0.471548ZM5.99999 1.05831L4.64478 3.92564C4.52678 4.17531 4.29867 4.34836 4.0348 4.3884L1.00445 4.84819L3.19723 7.08007C3.38817 7.27445 3.4753 7.55442 3.43023 7.82888L2.91258 10.9804L5.62301 9.49242C5.85903 9.36284 6.14095 9.36284 6.37697 9.49242L9.08742 10.9804L8.56978 7.82888C8.52471 7.55442 8.61184 7.27445 8.80273 7.08007L10.9955 4.84819L7.96518 4.3884C7.70132 4.34836 7.47322 4.17531 7.35524 3.92564L5.99999 1.05831Z"
            fill="url(#paint0_linear)"></path>
        <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="6" height="12">
            <rect width="6" height="12" fill="#C4C4C4"></rect>
        </mask>
        <g mask="url(#mask0)">
            <path
                d="M5.27351 0.471551C5.4221 0.157183 5.71104 -8.64667e-08 5.99999 0C6.28893 8.6463e-08 6.57788 0.157184 6.72646 0.471551L8.14149 3.46535L11.3055 3.94543C11.97 4.04625 12.2353 4.89895 11.7545 5.38833L9.46494 7.71866L10.0054 11.0092C10.1189 11.7002 9.42431 12.2272 8.82998 11.9009L5.99999 10.3474L3.17001 11.9009C2.57569 12.2272 1.88105 11.7002 1.99456 11.0092L2.53504 7.71866L0.245535 5.38833C-0.235291 4.89895 0.0300351 4.04625 0.69452 3.94543L3.85854 3.46535L5.27351 0.471551Z"
                fill="url(#paint1_linear)"></path>
        </g>
        <defs>
            <linearGradient id="paint0_linear" x1="1.6875" y1="1.6875" x2="11.9993" y2="10.9867"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900"></stop>
                <stop offset="0.291667" stop-color="#FFB729"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="1.6875" y1="1.6875" x2="11.9993" y2="10.9867"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900"></stop>
                <stop offset="0.291667" stop-color="#FFB729"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
                <stop offset="1" stop-color="#FFE975"></stop>
            </linearGradient>
        </defs>
    </svg>
`)} ${(0,c.z)(e=>"halfStarRight"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M6 0C5.71105 -3.2871e-06 5.4221 0.15718 5.27351 0.471548L3.85854 3.46535L0.69452 3.94543C0.030035 4.04625 -0.235291 4.89895 0.245535 5.38834L2.53504 7.71866L1.99456 11.0091C1.88105 11.7002 2.57569 12.2272 3.17001 11.9009L5.99999 10.3474L6 10.3474V9.39523C5.87051 9.39523 5.74102 9.42763 5.62301 9.49242L2.91258 10.9804L3.43023 7.82888C3.4753 7.55442 3.38817 7.27445 3.19723 7.08007L1.00445 4.84819L4.0348 4.3884C4.29867 4.34836 4.52678 4.17531 4.64478 3.92564L5.99999 1.05831L6 1.05833V0Z"
            fill="url(#paint0_linear)" />
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M6 10.3474L8.82998 11.9009C9.42431 12.2272 10.1189 11.7002 10.0054 11.0092L9.46494 7.71866L11.7545 5.38833C12.2353 4.89895 11.97 4.04625 11.3055 3.94543L8.14149 3.46535L6.72646 0.471551C6.57788 0.157188 6.28894 4.04894e-06 6 0V10.3474Z"
            fill="url(#paint1_linear)" />
        <defs>
            <linearGradient id="paint0_linear" x1="1.6875" y1="1.6875" x2="11.9993" y2="10.9867"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900" />
                <stop offset="0.291667" stop-color="#FFB729" />
                <stop offset="1" stop-color="#FFE975" />
                <stop offset="1" stop-color="#FFE975" />
            </linearGradient>
            <linearGradient id="paint1_linear" x1="1.6875" y1="1.68756" x2="11.9996" y2="10.9867"
                gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF9900" />
                <stop offset="0.291667" stop-color="#FFB729" />
                <stop offset="1" stop-color="#FFE975" />
                <stop offset="1" stop-color="#FFE975" />
            </linearGradient>
        </defs>
    </svg>
`)} ${(0,c.z)(e=>"fullStarDR"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill=${o} d="M5.52351 0.471551C5.82068 -0.157184 6.6793 -0.157184 6.97646 0.471551L8.39149 3.46535L11.5555 3.94543C12.22 4.04625 12.4853 4.89895 12.0045 5.38833L9.71494 7.71866L10.2554 11.0092C10.3689 11.7002 9.67431 12.2272 9.07998 11.9009L6.24999 10.3474L3.42001 11.9009C2.82569 12.2272 2.13105 11.7002 2.24456 11.0092L2.78504 7.71866L0.495535 5.38833C0.014709 4.89895 0.280035 4.04625 0.94452 3.94543L4.10854 3.46535L5.52351 0.471551Z"></path>
    </svg>
`)} ${(0,c.z)(e=>"emptyStarDR"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 4 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill=${o} d="M5.27351 4.47155C5.57068 3.84282 6.4293 3.84281 6.72646 4.47155L8.14149 7.46535L11.3055 7.94543C11.97 8.04625 12.2353 8.89895 11.7545 9.38834L9.46494 11.7187L10.0054 15.0091C10.1189 15.7002 9.42431 16.2272 8.82998 15.9009L5.99999 14.3474L3.17001 15.9009C2.57569 16.2272 1.88105 15.7002 1.99456 15.0091L2.53504 11.7187L0.245535 9.38834C-0.235291 8.89895 0.030035 8.04625 0.69452 7.94543L3.85854 7.46535L5.27351 4.47155ZM5.99999 5.05831L4.64478 7.92564C4.52678 8.17531 4.29867 8.34836 4.0348 8.3884L1.00445 8.84819L3.19723 11.0801C3.38817 11.2745 3.4753 11.5544 3.43023 11.8289L2.91258 14.9804L5.62301 13.4924C5.85903 13.3628 6.14095 13.3628 6.37697 13.4924L9.08742 14.9804L8.56978 11.8289C8.52471 11.5544 8.61184 11.2745 8.80273 11.0801L10.9955 8.84819L7.96518 8.3884C7.70132 8.34836 7.47322 8.17531 7.35524 7.92564L5.99999 5.05831Z"></path>
    </svg>
`)} ${(0,c.z)(e=>"halfStarDR"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
            d="M5.27351 0.471548C5.57068 -0.15718 6.4293 -0.157186 6.72646 0.471548L8.14149 3.46535L11.3055 3.94543C11.97 4.04625 12.2353 4.89895 11.7545 5.38834L9.46494 7.71866L10.0054 11.0091C10.1189 11.7002 9.42431 12.2272 8.82998 11.9009L5.99999 10.3474L3.17001 11.9009C2.57569 12.2272 1.88105 11.7002 1.99456 11.0091L2.53504 7.71866L0.245535 5.38834C-0.235291 4.89895 0.030035 4.04625 0.69452 3.94543L3.85854 3.46535L5.27351 0.471548ZM5.99999 1.05831L4.64478 3.92564C4.52678 4.17531 4.29867 4.34836 4.0348 4.3884L1.00445 4.84819L3.19723 7.08007C3.38817 7.27445 3.4753 7.55442 3.43023 7.82888L2.91258 10.9804L5.62301 9.49242C5.85903 9.36284 6.14095 9.36284 6.37697 9.49242L9.08742 10.9804L8.56978 7.82888C8.52471 7.55442 8.61184 7.27445 8.80273 7.08007L10.9955 4.84819L7.96518 4.3884C7.70132 4.34836 7.47322 4.17531 7.35524 3.92564L5.99999 1.05831Z"
            fill=${o}></path>
        <mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="6" height="12">
            <rect width="6" height="12" fill="#C4C4C4"></rect>
        </mask>
        <g mask="url(#mask0)">
            <path
                d="M5.27351 0.471551C5.4221 0.157183 5.71104 -8.64667e-08 5.99999 0C6.28893 8.6463e-08 6.57788 0.157184 6.72646 0.471551L8.14149 3.46535L11.3055 3.94543C11.97 4.04625 12.2353 4.89895 11.7545 5.38833L9.46494 7.71866L10.0054 11.0092C10.1189 11.7002 9.42431 12.2272 8.82998 11.9009L5.99999 10.3474L3.17001 11.9009C2.57569 12.2272 1.88105 11.7002 1.99456 11.0092L2.53504 7.71866L0.245535 5.38833C-0.235291 4.89895 0.0300351 4.04625 0.69452 3.94543L3.85854 3.46535L5.27351 0.471551Z"
                fill=${o}></path>
        </g>
    </svg>
`)} ${(0,c.z)(e=>"halfStarRightDR"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M6 0C5.71105 -3.2871e-06 5.4221 0.15718 5.27351 0.471548L3.85854 3.46535L0.69452 3.94543C0.030035 4.04625 -0.235291 4.89895 0.245535 5.38834L2.53504 7.71866L1.99456 11.0091C1.88105 11.7002 2.57569 12.2272 3.17001 11.9009L5.99999 10.3474L6 10.3474V9.39523C5.87051 9.39523 5.74102 9.42763 5.62301 9.49242L2.91258 10.9804L3.43023 7.82888C3.4753 7.55442 3.38817 7.27445 3.19723 7.08007L1.00445 4.84819L4.0348 4.3884C4.29867 4.34836 4.52678 4.17531 4.64478 3.92564L5.99999 1.05831L6 1.05833V0Z"
            fill=${o} />
        <path fill-rule="evenodd" clip-rule="evenodd"
            d="M6 10.3474L8.82998 11.9009C9.42431 12.2272 10.1189 11.7002 10.0054 11.0092L9.46494 7.71866L11.7545 5.38833C12.2353 4.89895 11.97 4.04625 11.3055 3.94543L8.14149 3.46535L6.72646 0.471551C6.57788 0.157188 6.28894 4.04894e-06 6 0V10.3474Z"
            fill=${o} />
    </svg>
`)} ${(0,c.z)(e=>"shadowStar"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill=${o} d="M16 1L12.459 12.459H0.999998L10.2705 19.541L6.72949 31L16 23.918L25.2493 31L21.7295 19.541L31 12.459H19.541L16 1Z" />
        <g opacity="0.25">
            <path d="M15.9639 17.5773V1L12.4611 12.4507L15.9639 17.5773L0.999998 12.4507L10.2493 19.5493L15.9639 17.5773L6.71045 31L16 23.9014L15.9639 17.5773L25.2493 31L21.7105 19.5493L15.9639 17.5773L31 12.4507H19.4987L15.9639 17.5773Z" fill="black"/>
            <path d="M15.9639 17.5773V1L12.4611 12.4507L15.9639 17.5773ZM15.9639 17.5773L6.71045 31L16 23.9014L15.9639 17.5773ZM15.9639 17.5773L0.999999 12.4507L10.2493 19.5493L15.9639 17.5773ZM15.9639 17.5773L25.2493 31L21.7105 19.5493L15.9639 17.5773ZM15.9639 17.5773L31 12.4507H19.4987L15.9639 17.5773Z" stroke="black" stroke-width="0.0841596"/>
        </g>
    </svg>
`)} ${(0,c.z)(e=>"location"===e.iconName,(0,l.qy)`
    <style>
        @media (prefers-color-scheme: dark) {
            path {
                fill: ${"white"};
            }
        }
        @media (prefers-color-scheme: light) {
            path {
                fill: ${"#717171"};
            }
        }
    </style>
    <svg width=${a} height=${i} viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill=${o} d="M9.38909 11.6701L8.63932 12.4338C8.08675 12.9924 7.36969 13.7106 6.48803 14.5885C5.93704 15.1372 5.06295 15.1371 4.51208 14.5884L2.30692 12.3792C2.02977 12.0989 1.79778 11.8626 1.61091 11.6701C-0.536971 9.45796 -0.536971 5.87129 1.61091 3.65913C3.7588 1.44696 7.24121 1.44696 9.38909 3.65913C11.537 5.87129 11.537 9.45796 9.38909 11.6701ZM7.07926 7.84334C7.07926 6.94501 6.37218 6.21679 5.49999 6.21679C4.6278 6.21679 3.92074 6.94501 3.92074 7.84334C3.92074 8.74163 4.6278 9.46986 5.49999 9.46986C6.37218 9.46986 7.07926 8.74163 7.07926 7.84334Z" fill="white"></path>
    </svg>
`)} ${(0,c.z)(e=>"rightArrow"===e.iconName,(0,l.qy)`
    <svg width=${a} height=${i} viewBox="0 0 7 12" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5.35179 6L1.10623 1.63651C0.961802 1.48807 0.965054 1.25065 1.11349 1.10623C1.26193 0.961801 1.49935 0.965053 1.64377 1.11349L6.14377 5.73849C6.28541 5.88406 6.28541 6.11594 6.14377 6.26151L1.64377 10.8865C1.49935 11.0349 1.26193 11.0382 1.11349 10.8938C0.965054 10.7493 0.961802 10.5119 1.10623 10.3635L5.35179 6Z" fill="white" stroke="white" stroke-width="0.4"/>
    </svg>
`)} ${(0,c.z)(e=>"cube"===e.iconName,(0,l.qy)`
<svg width=${a} height=${i} viewBox="0 0 58 55" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill=${"#FFFFFF"} fill-rule="evenodd" clip-rule="evenodd" d="M36.2122 0.827427L56.9267 12.2204C57.2516 12.3991 57.5225 12.6618 57.7113 12.981C57.9 13.3001 57.9996 13.6641 57.9997 14.035V40.9637C57.9996 41.3345 57.9 41.6985 57.7113 42.0177C57.5225 42.3369 57.2516 42.5996 56.9267 42.7783L36.2122 54.1712C35.9065 54.3399 35.563 54.4283 35.2138 54.4283C34.8646 54.4283 34.5211 54.3399 34.2154 54.1712L24.8566 49.0237L26.8535 45.3966L33.1424 48.8559V26.6521L13.5009 15.8495C13.1762 15.6707 12.9053 15.408 12.7167 15.0888C12.5281 14.7697 12.4286 14.4057 12.4286 14.035C12.4286 13.6642 12.5281 13.3002 12.7167 12.9811C12.9053 12.6619 13.1762 12.3992 13.5009 12.2204L34.2154 0.827427C34.5212 0.659157 34.8647 0.570923 35.2138 0.570923C35.5629 0.570923 35.9064 0.659157 36.2122 0.827427ZM51.63 14.035L35.2138 5.0076L18.7976 14.035L35.2138 23.0623L51.63 14.035ZM37.2852 48.8538L53.8568 39.7395V17.5357L37.2852 26.65V48.8538ZM0 27.4995H16.5715V23.3566H0V27.4995ZM20.7144 44.071H4.14286V39.9281H20.7144V44.071ZM8.28571 35.7852H24.8573V31.6424H8.28571V35.7852Z"/>
</svg>
`)} ${(0,c.z)(e=>"box"===e.iconName,(t="#FFFFFF",(0,l.qy)`
<svg width=${a} height=${i} viewBox="0 0 59 63" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M26.6526 3.74097C27.5277 3.25501 28.5121 3 29.5131 3C30.514 3 31.4985 3.25501 32.3736 3.74097L54.512 16.0372C54.971 16.2924 55.3534 16.6657 55.6196 17.1184C55.8858 17.5711 56.0262 18.0867 56.0262 18.6119V42.8714C56.0259 43.922 55.7447 44.9535 55.2118 45.8589C54.6788 46.7643 53.9134 47.5107 52.9949 48.0208L32.3736 59.4803C31.4985 59.9663 30.514 60.2213 29.5131 60.2213C28.5121 60.2213 27.5277 59.9663 26.6526 59.4803L6.03133 48.0208C5.11326 47.5109 4.34814 46.765 3.81517 45.8601C3.28221 44.9553 3.00077 43.9244 3 42.8743V18.6119C2.99998 18.0867 3.14035 17.5711 3.40658 17.1184C3.67281 16.6657 4.05521 16.2924 4.51419 16.0372L26.6556 3.74097H26.6526Z" stroke=${t} stroke-width="4.08717" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16.2549 9.5144L42.768 24.2439V34.5545" stroke=${t} stroke-width="4.08717" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11.8369 32.5757L20.6746 37.5012" stroke=${t}" stroke-width="4.08717" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M29.5131 31.6089V59.5949M3 16.8794L29.5131 31.6089L3 16.8794ZM29.5131 31.6089L56.0262 16.8794L29.5131 31.6089Z" stroke=${t} stroke-width="4.08717" stroke-linejoin="round"/>
</svg>
`))} ${(0,c.z)(e=>"truck"===e.iconName,(0,l.qy)`
<svg width=${a} height=${i} viewBox="0 0 62 46" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill=${"#FFFFFF"} d="M49.0667 9.2H42.9333V6.13333C42.9333 4.50667 42.2871 2.94663 41.1369 1.79641C39.9867 0.646188 38.4267 0 36.8 0H6.13333C4.50667 0 2.94663 0.646188 1.79641 1.79641C0.646188 2.94663 0 4.50667 0 6.13333V36.8H6.13333C6.13333 38.0082 6.3713 39.2045 6.83364 40.3207C7.29599 41.4369 7.97365 42.4511 8.82795 43.3054C9.68225 44.1597 10.6965 44.8373 11.8126 45.2997C12.9288 45.762 14.1252 46 15.3333 46C16.5415 46 17.7378 45.762 18.854 45.2997C19.9702 44.8373 20.9844 44.1597 21.8387 43.3054C22.693 42.4511 23.3707 41.4369 23.833 40.3207C24.2954 39.2045 24.5333 38.0082 24.5333 36.8H36.8C36.8 39.24 37.7693 41.58 39.4946 43.3054C41.22 45.0307 43.56 46 46 46C48.44 46 50.7801 45.0307 52.5054 43.3054C54.2307 41.58 55.2 39.24 55.2 36.8H61.3333V21.4667L49.0667 9.2ZM15.3333 41.4C14.7291 41.3998 14.1307 41.2806 13.5725 41.0491C13.0143 40.8177 12.5072 40.4786 12.08 40.0512C11.6529 39.6237 11.3141 39.1163 11.083 38.558C10.852 37.9996 10.7331 37.4012 10.7333 36.7969C10.7335 36.1927 10.8528 35.5943 11.0842 35.0361C11.3156 34.4779 11.6547 33.9708 12.0822 33.5436C12.5096 33.1165 13.017 32.7777 13.5754 32.5466C14.1337 32.3156 14.7321 32.1967 15.3364 32.1969C16.5568 32.1973 17.7271 32.6825 18.5897 33.5458C19.4524 34.409 19.9368 35.5796 19.9364 36.8C19.936 38.0204 19.4508 39.1907 18.5876 40.0533C17.7243 40.916 16.5537 41.4004 15.3333 41.4ZM6.13333 27.6V6.13333H36.8V27.6H6.13333ZM46 41.4C45.3957 41.3998 44.7974 41.2806 44.2392 41.0491C43.681 40.8177 43.1738 40.4786 42.7467 40.0512C42.3195 39.6237 41.9807 39.1163 41.7497 38.558C41.5186 37.9996 41.3998 37.4012 41.4 36.7969C41.4002 36.1927 41.5194 35.5943 41.7509 35.0361C41.9823 34.4779 42.3214 33.9708 42.7488 33.5436C43.1763 33.1165 43.6837 32.7777 44.242 32.5466C44.8004 32.3156 45.3988 32.1967 46.0031 32.1969C47.2235 32.1973 48.3937 32.6825 49.2564 33.5458C50.1191 34.409 50.6035 35.5796 50.6031 36.8C50.6027 38.0204 50.1175 39.1907 49.2542 40.0533C48.391 40.916 47.2204 41.4004 46 41.4Z"/>
</svg>
`)} `}}</template>`,g=class extends r{};g=(0,i.Cg)([(0,o.E)({name:"pure-icon",template:p,styles:s})],g)},11937(e,t,a){a.d(t,{M:()=>f});var i=a(56911),o=a(92011),n=a(38493),r=a(40450),d=a(88971),s=a(45183);let l=class extends o.L{constructor(){super(...arguments),this.content="",this.customStyle="",this.fontFamily="inherit",this.fontSize="14",this.fontWeight="600",this.textColor="#FFFFFF",this.darkThemeColor=d.fT.defaultDarkThemeColor,this.lightThemeColor=d.fT.defaultLightThemeColor}};(0,i.Cg)([n.CF],l.prototype,"content",void 0),(0,i.Cg)([(0,n.CF)({attribute:"custom-style"})],l.prototype,"customStyle",void 0),(0,i.Cg)([(0,n.CF)({attribute:"font-family"})],l.prototype,"fontFamily",void 0),(0,i.Cg)([(0,n.CF)({attribute:"font-size"})],l.prototype,"fontSize",void 0),(0,i.Cg)([(0,n.CF)({attribute:"font-weight"})],l.prototype,"fontWeight",void 0),(0,i.Cg)([(0,n.CF)({attribute:"text-color"})],l.prototype,"textColor",void 0),(0,i.Cg)([(0,n.CF)({attribute:"dark-theme-color"})],l.prototype,"darkThemeColor",void 0),(0,i.Cg)([(0,n.CF)({attribute:"light-theme-color"})],l.prototype,"lightThemeColor",void 0),l=(0,i.Cg)([(0,s.TA)(r.PDj,"pure-text")],l);var c=a(59669),p=a(22062);let g=(0,c.A)` .pure-text-container{display:inline-block;height:20px;line-height:20px}`.withBehaviors(new p.X(["fontFamily","fontSize","fontWeight","textColor"],e=>(0,c.A)` .pure-text-container{font-family:${e.fontFamily};font-size:${e.fontSize}px;font-weight:${e.fontWeight};color:${e.textColor}}`));var h=a(89757),m=a(69259);let u=(0,h.qy)` ${(0,m.z)(e=>e.darkThemeColor,(0,h.qy)`<style>@media (prefers-color-scheme: dark) { .pure-text-container { color: ${e=>e.darkThemeColor}; } }</style>`)} ${(0,m.z)(e=>e.lightThemeColor,(0,h.qy)`<style>@media (prefers-color-scheme: light) { .pure-text-container { color: ${e=>e.lightThemeColor}; } }</style>`)}<div class="pure-text-container" style=${e=>e.customStyle}>${e=>e.content}</div>`,f=class extends l{};f=(0,i.Cg)([(0,o.E)({name:"pure-text",template:u,styles:g})],f)},98080(e,t,a){a.d(t,{j:()=>f});var i=a(56911),o=a(38493),n=a(40450),r=a(45183),d=a(66864);let s=class extends d.t{constructor(){super(...arguments),this.discountText=""}};(0,i.Cg)([(0,o.CF)({attribute:"discount-text"})],s.prototype,"discountText",void 0),s=(0,i.Cg)([(0,r.TA)(n.PDj,"msn-native-ad-sale-highlight-badge")],s);var l=a(92011),c=a(89757);let p=(0,c.qy)`<svg width="12" height="12" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.06591 0.163636L0.156818 5.07273C-0.0522727 5.28182 -0.0522727 5.62727 0.156818 5.84545L4.15682 9.84545C4.36591 10.0545 4.71136 10.0545 4.92955 9.84545L9.83864 4.93636C9.93864 4.82727 9.99318 4.69091 9.99318 4.54545V0.545455C9.99318 0.245455 9.74773 0 9.44773 0H5.44773C5.30227 0 5.16591 0.0545455 5.06591 0.163636ZM8.52955 2.77273C8.475 2.89091 8.40227 3 8.31136 3.09091C8.22046 3.18182 8.12045 3.25455 7.99318 3.3C7.86591 3.34545 7.74773 3.38182 7.61136 3.38182C7.475 3.38182 7.33864 3.35455 7.22045 3.3C7.10227 3.25455 6.99318 3.18182 6.90227 3.09091C6.81136 3 6.73864 2.89091 6.69318 2.77273C6.63864 2.65455 6.61136 2.52727 6.61136 2.38182C6.61136 2.23636 6.63864 2.10909 6.69318 1.99091C6.73864 1.88182 6.81136 1.77273 6.90227 1.69091C6.99318 1.6 7.10227 1.52727 7.22045 1.47273C7.33864 1.41818 7.46591 1.39091 7.61136 1.39091C7.75682 1.39091 7.88409 1.41818 8.00227 1.47273C8.12046 1.52727 8.22955 1.6 8.31136 1.69091C8.40227 1.78182 8.475 1.88182 8.52955 2C8.58409 2.11818 8.61136 2.24545 8.61136 2.39091C8.61136 2.53636 8.575 2.65455 8.52955 2.77273Z" fill="white"/></svg>`,g=(0,c.qy)`<a class="sale-highlight-badge" href="javascript:void 0;">${p}<span class="sale-highlight-badge-text">${e=>e.discountText}</span></a>`;var h=a(59669),m=a(16559);let u=(0,h.A)`
.sale-highlight-badge{background:#0078D4;border-radius:4px;display:flex;font-size:12px;color:#FFF;align-items:center;padding:2px 8px;line-height:16px;font-family:Segoe UI;box-sizing:border-box;text-decoration:none}.sale-highlight-badge .sale-highlight-badge-text{margin-left:5px;white-space:nowrap}`.withBehaviors(new m.e("layoutStyle")),f=class extends s{};f=(0,i.Cg)([(0,l.E)({name:"msn-native-ad-sale-highlight-badge",template:g,styles:u})],f)},64984(e,t,a){a.d(t,{e:()=>L});var i=a(56911),o=a(60815),n=a(38493),r=a(40450),d=a(45183),s=a(33744);function l(e,t="",a="",i=""){if(0===e||1===e)return t;if(e>1&&e<=30)return a.replace("{0}",String(e));if(e>30){let t=s.T3?.CurrentMarket||"en-us",a=new Date(Date.now());a.setDate(a.getDate()+e);let o=a.toLocaleDateString(t);return i.replace("{0}",o)}return""}var c=a(66864);let p=class extends c.t{constructor(){super(...arguments),this.show=!1,this.disableTimeout=!1,this.showToast=!1,this.arrowOffset="",this.duration=1e3,this.marginLeft="0",this.isDrConfig=!1,this.displayedText="",this.promotionalText="",this.redemptionCode="",this.daysFromExpiration="",this.destinationURL="",this.underneathPopUp=!1,this.displayExpirationDate=!1,this.timer=Date.now(),this.handleOnCopyClick=e=>()=>{this.showToast=!0,setTimeout(()=>this.showToast=!1,1e3)}}connectedCallback(){super.connectedCallback();let{nativeAdExpiresToday:e="",nativeAdExpiresInDays:t="",nativeAdExpiresOnCertainDay:a="",nativeAdExpiresTodayPopupWithCode:i="",nativeAdExpiresInDaysPopupWithCode:o="",nativeAdExpiresOnCertainDayPopupWithCode:n="",nativeAdExpiresTodayPopupWithoutCode:r="",nativeAdExpiresInDaysPopupWithoutCode:d="",nativeAdExpiresOnCertainDayPopupWithoutCode:s=""}=this.localizedStrings;this.expirationDate=l(Number(this.daysFromExpiration),e,t,a),this.expirationDatePopup=l(Number(this.daysFromExpiration),this.redemptionCode?i:r,this.redemptionCode?o:d,this.redemptionCode?n:s)}handlePopupWindowClick(e,t){"shop-btn"!==t.event.target.id&&t.event.stopPropagation()}onMouseEnter(e){let t=e.shadowRoot?.querySelector("decoration-special-offer")?.shadowRoot?.querySelector(".special-offer-btn-container"),a=t?.offsetWidth/2,i=e.offsetLeft;this.arrowOffset=this.arrowOffset||`${a+i-8}px`,clearTimeout(this.timer),this.show=!0}onMouseLeave(){this.handleHide()}onPopupWindowMouseEnter(){clearTimeout(this.timer),this.disableTimeout=!0}onPopupWindowMouseLeave(){this.disableTimeout=!1,this.handleHide()}handleHide(){this.disableTimeout||(this.timer=window.setTimeout(()=>{this.show=!1},this.duration))}};(0,i.Cg)([o.sH],p.prototype,"show",void 0),(0,i.Cg)([o.sH],p.prototype,"disableTimeout",void 0),(0,i.Cg)([o.sH],p.prototype,"showToast",void 0),(0,i.Cg)([o.sH],p.prototype,"arrowOffset",void 0),(0,i.Cg)([n.CF],p.prototype,"duration",void 0),(0,i.Cg)([(0,n.CF)({attribute:"margin-left"})],p.prototype,"marginLeft",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"is-dr-config"})],p.prototype,"isDrConfig",void 0),(0,i.Cg)([(0,n.CF)({attribute:"displayed-text"})],p.prototype,"displayedText",void 0),(0,i.Cg)([(0,n.CF)({attribute:"promotional-text"})],p.prototype,"promotionalText",void 0),(0,i.Cg)([(0,n.CF)({attribute:"redemption-code"})],p.prototype,"redemptionCode",void 0),(0,i.Cg)([(0,n.CF)({attribute:"days-from-expiration"})],p.prototype,"daysFromExpiration",void 0),(0,i.Cg)([(0,n.CF)({attribute:"destination-url"})],p.prototype,"destinationURL",void 0),(0,i.Cg)([(0,n.CF)({attribute:"underneath-pop-up",mode:"boolean"})],p.prototype,"underneathPopUp",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"display-expiration-date"})],p.prototype,"displayExpirationDate",void 0),(0,i.Cg)([o.sH],p.prototype,"localizedStrings",void 0),(0,i.Cg)([o.sH],p.prototype,"expirationDate",void 0),(0,i.Cg)([o.sH],p.prototype,"expirationDatePopup",void 0),p=(0,i.Cg)([(0,d.TA)(r.PDj,"msn-native-ad-special-offer")],p);var g=a(92011),h=a(59669),m=a(16559),u=a(22062);let f=(0,h.A)` :host{--accent-fill-rest:#0078D4;--accent-fill-hover:#006CBE;--accent-fill-active:#1683D8;--accent-fill-focus:#888888}.container{display:flex;flex-direction:column}.description{white-space:initial;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden}.text-section{display:flex;padding:12px 12px 0px 12px;flex-direction:column;font-size:12px}.action-section{display:flex;padding:12px;justify-content:space-between}.title{font-weight:bold;white-space:initial;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden}.shop-btn{background:var(--accent-fill-rest);color:#FFFFFF;width:68px;height:32px;border-radius:20px;font-size:12px;text-align:center;line-height:32px;cursor:pointer}.shop-btn:hover{background:var(--accent-fill-hover)}.shop-btn:active{background:var(--accent-fill-active)}.shop-btn:focus{background:var(--accent-fill-focus)}`.withBehaviors(new m.e("layoutStyle"),new u.X(["arrowOffset","marginLeft","isDrConfig"],e=>(0,h.A)` .popup-window{margin-left:${e.marginLeft}px;color:#000000;cursor:default;z-index:1;background-color:#FFFFFF;border-radius:4px;margin-bottom:11px;width:276px;min-height:102px;max-height:140px;box-shadow:0px 0.6px 1.8px rgb(0 0 0 / 10%),0px 3.2px 7.2px rgb(0 0 0 / 13%)}.underneathPopUp{position:fixed;margin-top:32px}.popup-window::after{content:"";width:0;height:0;border-left:8px solid transparent;border-right:8px solid transparent;${e.underneathPopUp?"border-bottom":"border-top"}:8px solid #FFFFFF;position:absolute;margin-inline-start:${e.arrowOffset};bottom:${e.isDrConfig?"":e.underneathPopUp?"101":"26"}px}`));var y=a(89757),v=a(69259);let x=class extends g.L{constructor(){super(...arguments),this.code="",this.copyText=""}};(0,i.Cg)([n.CF],x.prototype,"code",void 0),(0,i.Cg)([o.sH],x.prototype,"onCopyClick",void 0),(0,i.Cg)([(0,n.CF)({attribute:"copy-text"})],x.prototype,"copyText",void 0),x=(0,i.Cg)([(0,d.TA)(r.PDj,"msn-native-ad-copy-input")],x);let b=(0,h.A)` .input-container{display:flex;height:32px;width:172px;justify-content:space-between;background:#EDEDED;border-radius:4px;align-items:center;font-size:14px;cursor:initial}.promotion-code{margin-left:12px}.copy-icon{margin-right:12px;cursor:pointer}`,C=(0,y.qy)`
    <svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 5.50293V14H3.42857V11.375H0V0H5.75223L8.32366 2.625H9.1808L12 5.50293ZM9.42857 5.25H10.5335L9.42857 4.12207V5.25ZM3.42857 2.625H7.10491L5.39062 0.875H0.857143V10.5H3.42857V2.625ZM11.1429 6.125H8.57143V3.5H4.28571V13.125H11.1429V6.125Z" fill="#0078D4"/>
    </svg>
`,$=(0,y.qy)`<div class="input-container"><div class="promotion-code">${e=>e.code}</div><div class="copy-icon" title=${e=>e.copyText} aria-label=${e=>e.copyText} @click=${e=>(navigator.clipboard.writeText(e.code),e.onCopyClick(),!0)}>${C}</div></div>`,w=class extends x{};w=(0,i.Cg)([(0,g.E)({name:"msn-native-ad-copy-input",template:$,styles:b})],w);var k=a(65281);let T=class extends g.L{constructor(){super(...arguments),this.duration=1e3,this.show=!1,this.message="Copied!"}};(0,i.Cg)([n.CF],T.prototype,"duration",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean"})],T.prototype,"show",void 0),(0,i.Cg)([n.CF],T.prototype,"message",void 0),(0,i.Cg)([n.CF],T.prototype,"position",void 0),(0,i.Cg)([n.CF],T.prototype,"top",void 0),(0,i.Cg)([n.CF],T.prototype,"left",void 0),T=(0,i.Cg)([(0,d.TA)(r.PDj,"msn-native-ad-toast")],T);let S=(0,h.A)` .toast{display:flex;width:81px;height:38px;background:#3B3B3B;border-radius:6px;justify-content:center;align-items:center;color:white;font-size:14px;font-weight:normal;box-shadow:0px 12.8px 28.8px rgba(0,0,0,0.13),0px 0px 9.2px rgba(0,0,0,0.11)}`.withBehaviors(new u.X(["position","top","left"],e=>(0,h.A)` :host{position:${e.position};top:${e.top}px;left:${e.left}px}`)),F=(0,y.qy)` ${(0,v.z)(e=>e.show,(0,y.qy)`<div class="toast">${e=>e.message}</div>`)}
`,z=class extends T{};z=(0,i.Cg)([(0,g.E)({name:"msn-native-ad-toast",template:F,styles:S})],z),k.a;let A=(0,y.qy)` ${(0,v.z)(e=>e.show,(0,y.qy)`<msn-native-ad-toast show=${e=>e.showToast} position="fixed" top="7" left="110"></msn-native-ad-toast><div class="popup-window ${e=>e.underneathPopUp?"underneathPopUp":""}" @click=${(e,t)=>e.handlePopupWindowClick(e,t)} @mouseenter=${e=>e.onPopupWindowMouseEnter()} @mouseleave=${e=>e.onPopupWindowMouseLeave()}><div class="container"><div class="text-section"><div class="title">${e=>e.promotionalText}</div><div class="description">${e=>e.expirationDatePopup}${e=>e.redemptionCode?e.localizedStrings?.nativeAdSpecialOfferEnterCode:""}</div></div><div class="action-section">${(0,v.z)(e=>e.redemptionCode,(0,y.qy)`<msn-native-ad-copy-input copy-text=${e=>e.localizedStrings?.nativeAdSpecialOfferCopy} :onCopyClick=${e=>e.handleOnCopyClick(e)} code=${e=>e.redemptionCode}></msn-native-ad-copy-input>`)}<div id="shop-btn" class="shop-btn" title=${e=>e.localizedStrings?.nativeAdSpecialOfferShop} aria-label=${e=>e.localizedStrings?.nativeAdSpecialOfferShop}>${e=>e.localizedStrings?.nativeAdSpecialOfferShop}</div></div></div></div>`)}<decoration-special-offer @mouseenter=${(e,t)=>e.onMouseEnter(e)} @mouseleave=${e=>e.onMouseLeave()} data=${e=>e.displayedText} expiration-date=${e=>e.expirationDate} display-expiration-date=${e=>e.displayExpirationDate}></decoration-special-offer>`,L=class extends p{};L=(0,i.Cg)([(0,g.E)({name:"msn-native-ad-special-offer",template:A,styles:f})],L)},53690(e,t,a){a.r(t),a.d(t,{MsnZIndexCard:()=>U});var i,o,n=a(56911),r=a(22131),d=a(64187),s=a(73477),l=a(7896),c=a(61138),p=a(6032),g=a(47810),h=a(89580),m=a(57416),u=a(50882),f=a(92011),y=a(38493),v=a(60815);(i=o||(o={})).imageAtBottom="imageAtBottom",i.imageAtTop="imageAtTop",i.imageAtRight9By16="imageAtRight9By16",i.imageAtRight3By4="imageAtRight3By4",i.animatedImagery9by16="animatedImagery9by16";class x extends f.L{constructor(){super(...arguments),this.layout=o.imageAtTop,this.headingMaxLines=5,this.documentDirection="ltr",this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0),this.hasFooter=this.endActions.assignedNodes().length>0}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0),this.hasFooter=this.endActions.assignedNodes().length>0}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleBackgroundImageContentChange(){this.backgroundImageContainer.classList.toggle("background-image",this.backgroundImage.assignedNodes().length>0)}handleZIndexCardLinkClick(e){return this.$emit("link-invoked",e),!0}}(0,n.Cg)([y.CF],x.prototype,"layout",void 0),(0,n.Cg)([(0,y.CF)({attribute:"heading-max-lines"})],x.prototype,"headingMaxLines",void 0),(0,n.Cg)([(0,y.CF)({attribute:"document-direction"})],x.prototype,"documentDirection",void 0),(0,n.Cg)([(0,y.CF)({attribute:"heading-level",mode:"fromView",converter:y.R$})],x.prototype,"headinglevel",void 0),(0,n.Cg)([(0,y.CF)({mode:"fromView"})],x.prototype,"href",void 0),(0,n.Cg)([v.sH],x.prototype,"anchorTelemetryTag",void 0),(0,n.Cg)([v.sH],x.prototype,"mediaNodes",void 0),(0,n.Cg)([v.sH],x.prototype,"hasAbstract",void 0),(0,n.Cg)([v.sH],x.prototype,"hasFooter",void 0),(0,n.Cg)([v.sH],x.prototype,"abstract",void 0),(0,n.Cg)([v.sH],x.prototype,"iconSlottedNodes",void 0),(0,n.Cg)([(0,y.CF)({attribute:"image-priority",mode:"boolean"})],x.prototype,"imagePriority",void 0),(0,n.Cg)([y.CF],x.prototype,"target",void 0),(0,n.Cg)([v.sH],x.prototype,"hoverActionsSlottedNodes",void 0);var b=a(59669);let{imageAtBottom:C,imageAtTop:$,imageAtRight9By16:w,imageAtRight3By4:k,animatedImagery9by16:T}=o,S="#373737",F="white",z=e=>e.withBehaviors((0,r.mr)((0,b.A)` .heading{color:${u.A.LinkText};background:${u.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${u.A.ButtonFace};color:${u.A.ButtonText};fill:currentcolor}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${u.A.ButtonFace}}`)),A=z((0,b.A)` :host span.title_1x_2y,:host span.title_1x_3y{font-size:20px}${(0,d.V)("flex")} :host{position:relative;width:auto;box-sizing:border-box;font-family:${l.O};flex-direction:column;outline:none;overflow:hidden;height:100%;width:100%}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}:host(:hover) .media{filter:brightness(0.98)}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:16px;font-size:var(--footer-font-size,${c.k});line-height:var(--footer-line-height,${c.F})}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${p.c};fill:${p.c}}:host([layout=${$}]) .footer{position:absolute;bottom:24px;padding:0 24px;margin-top:unset;width:268px;padding-inline-start:24px;padding-inline-end:24px}.footer__hidden{display:none}.heading-wrapper{grid-row:1;display:flex;flex-direction:column}.heading-wrapper a:after{content:"";height:304px;position:absolute;width:300px;z-index:1}:host([layout=${$}]) .heading-wrapper a:after{top:-52px}:host([layout=${C}]) .heading-wrapper a:after{top:-38px}.media{display:flex;flex-direction:row;position:absolute}:host([layout=${C}]) .media{bottom:4px}:host([layout=${$}]) .media{top:8px}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0;display:flex;justify-content:center}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px)}:host([layout=${C}]) .heading-container{top:39px;position:absolute}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}:host([layout=${$}]) ::slotted([slot="call-to-action"]){top:230px}:host([layout=${C}]) ::slotted([slot="call-to-action"]){top:-40px}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;grid-column:1 / span 2;margin:0 24px}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${p.c};fill:${p.c}}.heading{-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,2);color:${g.l};display:-webkit-box;font-size:var(--heading-font-size,${h.Y});font-weight:600;line-height:var(--heading-line-height,${h.v});outline:none;overflow:hidden;text-decoration:none;white-space:initial}.mask{display:none}.heading:hover,.heading:${s.N}{text-decoration:underline}@media (prefers-color-scheme:dark){.heading-gradient-background{background:${S}}}@media (prefers-color-scheme:light){.heading-gradient-background{background:${F}}}.heading-gradient-background{border-radius:calc(${m.JU} * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))));height:252px;left:8px;position:absolute;width:300px}:host([layout=${C}]) .heading-gradient-background{top:8px}:host([layout=${$}]) .heading-gradient-background{bottom:8px}:host([layout=${$}]) .heading-gradient-background .heading{padding-top:137px;padding-right:16px}.heading::after{bottom:0;content:"";left:0;position:absolute;right:0;top:0}`),L=z((0,b.A)`
:host([layout=${k}]) span.title_1x_2y,:host([layout=${k}]) span.title_1x_3y{font-size:20px}:host([layout=${k}]) .heading-wrapper{grid-row:1;display:flex;flex-direction:column}:host([layout=${k}]) .heading-wrapper a:after{content:"";height:304px;position:absolute;width:300px;z-index:1}:host([layout=${k}]) .heading{overflow:hidden;text-decoration:none;font-size:20px;line-height:28px;width:121px;margin-top:14px;overflow-wrap:break-word}:host([layout=${k}][document-direction="rightToLeft"]) .heading-wrapper a:after{left:0px}:host([layout=${k}][document-direction="rightToLeft"]) .heading{margin-right:179px}:host([layout=${k}][heading-max-lines="eight-lines-heading"]) .heading{--heading-max-lines:8}:host([layout=${k}][heading-max-lines="five-lines-heading"]) .heading{--heading-max-lines:5}:host([layout=${k}]) ::slotted([slot="call-to-action"]){width:102px;top:175px;position:absolute}:host([layout=${k}][document-direction="rightToLeft"]) ::slotted([slot="call-to-action"]){left:16px}:host([layout=${k}]) .media-wrapper{top:57px;left:162px;position:absolute;width:113px;height:202px}:host([layout=${k}][document-direction="rightToLeft"]) .media-wrapper{left:178px}:host([layout=${k}]) .heading:hover,:host([layout=${k}]) .heading:${s.N}{text-decoration:underline}@media (prefers-color-scheme:dark){:host([layout=${k}]) .heading-gradient-background{background:${S}}:host([layout=${k}]) ::slotted([slot="call-to-action"]),:host([layout=${k}]) ::slotted([slot="start-actions"]),:host([layout=${k}]) .heading{color:#ffffff}}@media (prefers-color-scheme:light){:host([layout=${k}]) .heading-gradient-background{background:${F}}:host([layout=${k}]) ::slotted([slot="call-to-action"]),:host([layout=${k}]) ::slotted([slot="start-actions"]),:host([layout=${k}]) .heading{color:#222222}}:host([layout=${k}]) .heading-gradient-background{border-radius:calc(${m.JU} * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))));height:304px;left:8px;position:absolute;width:241px;top:8px}:host([layout=${k}][document-direction="rightToLeft"]) .heading-gradient-background{margin-left:16px}:host([layout=${k}]) .footer{display:flex;position:absolute;bottom:16px;width:209px;left:4px}:host([layout=${k}][document-direction="rightToLeft"]) .footer{right:55px}:host([layout=${k}]) ::slotted([slot="start-actions"]){position:unset;z-index:2;gap:8px;align-items:center;grid-auto-flow:column}:host([layout=${k}]) .start-actions{width:127px}`),M=z((0,b.A)` :host([layout=${w}]) span.title_1x_2y,:host([layout=${w}]) span.title_1x_3y{font-size:20px}:host([layout=${w}]) .heading-wrapper{content:"";height:304px;position:absolute;width:300px;z-index:1}:host([layout=${w}][document-direction="rightToLeft"]) .heading-wrapper{left:0px}:host([layout=${w}][document-direction="rightToLeft"]) .heading{margin-right:179px}:host([layout=${w}]) .heading{overflow:hidden;text-decoration:none;font-size:20px;line-height:28px;width:121px;margin-top:14px;overflow-wrap:break-word}:host([layout=${w}][heading-max-lines="eight-lines-heading"]) .heading{--heading-max-lines:8}:host([layout=${w}][heading-max-lines="five-lines-heading"]) .heading{--heading-max-lines:5}:host([layout=${w}]) ::slotted([slot="call-to-action"]){width:102px;top:175px;left:0px}:host([layout=${w}][document-direction="rightToLeft"]) ::slotted([slot="call-to-action"]){left:16px}:host([layout=${w}]) .media-wrapper{top:31px;left:162px;position:absolute;width:113px;height:202px}:host([layout=${w}][document-direction="rightToLeft"]) .media-wrapper{left:178px}:host([layout=${w}]) .heading:hover,:host([layout=${w}]) .heading:${s.N}{text-decoration:underline}@media (prefers-color-scheme:dark){:host([layout=${w}]) .heading-gradient-background{background:${S}}:host([layout=${w}]) ::slotted([slot="call-to-action"]),:host([layout=${w}]) ::slotted([slot="start-actions"]),:host([layout=${w}]) .heading{color:#ffffff}}@media (prefers-color-scheme:light){:host([layout=${w}]) .heading-gradient-background{background:${F}}:host([layout=${w}]) ::slotted([slot="call-to-action"]),:host([layout=${w}]) ::slotted([slot="start-actions"]),:host([layout=${w}]) .heading{color:#222222}}:host([layout=${w}]) .heading-gradient-background{border-radius:calc(${m.JU} * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))));height:304px;left:8px;position:absolute;width:241px;top:8px}:host([layout=${w}][document-direction="rightToLeft"]) .heading-gradient-background{margin-left:16px}:host([layout=${w}]) .footer{display:flex;position:absolute;bottom:16px;left:8px;width:209px}:host([layout=${w}][document-direction="rightToLeft"]) .footer{right:55px}:host([layout=${w}]) ::slotted([slot="start-actions"]){position:unset;z-index:2;gap:8px;align-items:center;grid-auto-flow:column}:host([layout=${w}]) .start-actions{width:127px}`),_=z((0,b.A)` :host([layout=${T}]) span.title_1x_2y,:host([layout=${T}]) span.title_1x_3y{font-size:20px}:host([layout=${T}]) .heading-wrapper{content:"";height:304px;position:absolute;width:300px;z-index:1}:host([layout=${T}][document-direction="rightToLeft"]) .heading-wrapper{left:0px}:host([layout=${T}][document-direction="rightToLeft"]) .heading{margin-right:179px}:host([layout=${T}]) .heading{overflow:hidden;text-decoration:none;font-size:20px;line-height:28px;width:121px;margin-top:14px;overflow-wrap:break-word}:host([layout=${T}][heading-max-lines="eight-lines-heading"]) .heading{--heading-max-lines:8}:host([layout=${T}][heading-max-lines="five-lines-heading"]) .heading{--heading-max-lines:5}:host([layout=${T}]) ::slotted([slot="call-to-action"]){width:102px;top:175px;left:0px}:host([layout=${T}][document-direction="rightToLeft"]) ::slotted([slot="call-to-action"]){left:16px}:host([layout=${T}]) .media-wrapper{position:absolute;width:141px;height:250px;right:8px;top:8px}:host([layout=${T}][document-direction="rightToLeft"]) .media-wrapper{left:178px}:host([layout=${T}]) .heading:hover,:host([layout=${T}]) .heading:${s.N}{text-decoration:underline}@media (prefers-color-scheme:dark){:host([layout=${T}]) .heading-gradient-background{background:${S}}:host([layout=${T}]) ::slotted([slot="call-to-action"]),:host([layout=${T}]) ::slotted([slot="start-actions"]),:host([layout=${T}]) .heading{color:#ffffff}}@media (prefers-color-scheme:light){:host([layout=${T}]) .heading-gradient-background{background:${F}}:host([layout=${T}]) ::slotted([slot="call-to-action"]),:host([layout=${T}]) ::slotted([slot="start-actions"]),:host([layout=${T}]) .heading{color:#222222}}:host([layout=${T}]) .heading-gradient-background{border-radius:calc(${m.JU} * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))));height:304px;left:8px;position:absolute;width:300px;top:8px}:host([layout=${T}][document-direction="rightToLeft"]) .heading-gradient-background{margin-left:16px}:host([layout=${T}]) .footer{display:flex;position:absolute;bottom:16px;left:8px;width:268px}:host([layout=${T}][document-direction="rightToLeft"]) .footer{right:0px}:host([layout=${T}][document-direction="rightToLeft"]) ::slotted([slot="end-actions"]){margin-left:8px}:host([layout=${T}]) ::slotted([slot="start-actions"]){position:unset;z-index:2;gap:8px;align-items:center;grid-auto-flow:column}`);var B=a(89757),I=a(60402),q=a(416),D=a(10108),E=a(69259),H=a(82774);let P=(0,B.qy)`<div class="footer ${e=>e.hasAbstract?"has-abstract-footer":""} ${e=>e.hasFooter?"":"footer__hidden"}" part="footer"><span part="start-actions" ${(0,I.K)("startActionsContainer")}><slot name="start-actions" ${(0,I.K)("startActions")} @slotchange=${e=>e.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,I.K)("endActionsContainer")}><slot name="end-actions" ${(0,I.K)("endActions")} @slotchange=${e=>e.handleEndActionsContentChange()}></slot></span></div>`,R=(0,B.qy)`<template ${(0,q.Y)({property:"mediaNodes",filter:(0,D.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" ${(0,I.K)("backgroundImageContainer")}><slot name="background-image" ${(0,I.K)("backgroundImage")} @slotchange=${e=>e.handleBackgroundImageContentChange()}></slot></span><div class="mask" part="mask"></div><div class="heading-gradient-background">${(0,E.z)(e=>e.layout===o.imageAtBottom,P)}<div class="heading-container" part="heading-container"><slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${e=>e.headinglevel}><a class="heading" part="heading" href=${e=>e.href?e.href:void 0} target=${e=>e.target?e.target:void 0} @click=${(e,t)=>e.handleZIndexCardLinkClick(t.event)} data-t="${e=>e.anchorTelemetryTag}"><slot></slot></a></span></div></div><div class="body ${e=>e.hasAbstract?"has-abstract":""}" part="body">${(0,E.z)(e=>e.mediaNodes?.length>0,(0,B.qy)`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,I.K)("mediaContainer")}><slot name="media" ${(0,I.K)("media")} @slotchange=${e=>e.handleMediaContentChange()}></slot><span part="icon" ${(0,I.K)("iconContainer")} class="${e=>e.iconSlottedNodes&&e.iconSlottedNodes.length?"icon":"icon_hidden"}"><slot name="icon" ${(0,I.K)("icon")} ${(0,H.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="abstract"><slot name="abstract" ${(0,H.e)("abstract")}></slot></div><slot name="call-to-action"></slot>${(0,E.z)(e=>e.layout!==o.imageAtBottom,P)}</div><span part="hover-actions" class="${e=>e.hoverActionsSlottedNodes&&e.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions_hidden"}"><slot name="hover-actions" ${(0,H.e)("hoverActionsSlottedNodes")}></slot></span></template>`,U=class extends x{};U=(0,n.Cg)([(0,f.E)({name:"msn-z-index-card",template:R,styles:[A,M,L,_],shadowOptions:{delegatesFocus:!0}})],U)},56050(e,t,a){a.d(t,{m:()=>h});var i=a(37180),o=a(56911),n=a(7511),r=a(38493);class d extends n._{appearanceChanged(e,t){e!==t&&(this.classList.add(t),this.classList.remove(e))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){let e=this.defaultSlottedContent.filter(e=>e.nodeType===Node.ELEMENT_NODE);1===e.length&&e[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,o.Cg)([r.CF,(0,o.Sn)("design:type",String)],d.prototype,"appearance",void 0);var s=a(59669),l=a(43117),c=a(17767);let p=(0,s.A)` ${l._9}
`.withBehaviors((0,c.f)("accent",l.Vw),(0,c.f)("hypertext",l.aY),(0,c.f)("lightweight",l.ZI),(0,c.f)("outline",l.LA),(0,c.f)("stealth",l.ss)),g=(0,a(29995).M)(),h=d.compose({name:`${i.c.prefix}-anchor`,template:g,styles:p,shadowOptions:{delegatesFocus:!0}})},29995(e,t,a){a.d(t,{M:()=>d});var i=a(89757),o=a(60402),n=a(82774),r=a(35106);function d(e={}){return(0,i.qy)`
        <a
            class="control"
            part="control"
            download="${e=>e.download}"
            href="${e=>e.href}"
            hreflang="${e=>e.hreflang}"
            ping="${e=>e.ping}"
            referrerpolicy="${e=>e.referrerpolicy}"
            rel="${e=>e.rel}"
            target="${e=>e.target}"
            type="${e=>e.type}"
            aria-atomic="${e=>e.ariaAtomic}"
            aria-busy="${e=>e.ariaBusy}"
            aria-controls="${e=>e.ariaControls}"
            aria-current="${e=>e.ariaCurrent}"
            aria-describedby="${e=>e.ariaDescribedby}"
            aria-details="${e=>e.ariaDetails}"
            aria-disabled="${e=>e.ariaDisabled}"
            aria-errormessage="${e=>e.ariaErrormessage}"
            aria-expanded="${e=>e.ariaExpanded}"
            aria-flowto="${e=>e.ariaFlowto}"
            aria-haspopup="${e=>e.ariaHaspopup}"
            aria-hidden="${e=>e.ariaHidden}"
            aria-invalid="${e=>e.ariaInvalid}"
            aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
            aria-label="${e=>e.ariaLabel}"
            aria-labelledby="${e=>e.ariaLabelledby}"
            aria-live="${e=>e.ariaLive}"
            aria-owns="${e=>e.ariaOwns}"
            aria-relevant="${e=>e.ariaRelevant}"
            aria-roledescription="${e=>e.ariaRoledescription}"
            ${(0,o.K)("control")}
        >
            ${(0,r.LT)(e)}
            <span class="content" part="content">
                <slot ${(0,n.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,r.aO)(e)}
        </a>
    `}},46277(e,t,a){a.d(t,{A:()=>d});var i=a(89279),o=a(56018),n=a(10405),r=Math.max;let d=function(e,t,a){var d=null==e?0:e.length;if(!d)return -1;var s=null==a?0:(0,n.A)(a);return s<0&&(s=r(d+s,0)),(0,i.A)(e,(0,o.A)(t,3),s)}},27314(e,t,a){a.d(t,{A:()=>n});var i=a(10405);let o=function(e,t){var a;if("function"!=typeof t)throw TypeError("Expected a function");return e=(0,i.A)(e),function(){return--e>0&&(a=t.apply(this,arguments)),e<=1&&(t=void 0),a}},n=function(e){return o(2,e)}},66459(e,t,a){let i,o;a.d(t,{j:()=>tc});var n,r,d,s,l=a(56911),c=a(67064);let p=c.DI.createContext();var g=a(18284);let h=(0,g.A)((e,t,a)=>({...e,config:t,strings:a}));var m=a(38493),u=a(40450),f=a(45183),y=a(66864);let v=class extends y.t{constructor(){super(...arguments),this.destinationUrl="",this.title="",this.telemetryMetadata=void 0}connectedCallback(){super.connectedCallback()}};(0,l.Cg)([(0,m.CF)({attribute:"destination-url"})],v.prototype,"destinationUrl",void 0),(0,l.Cg)([(0,m.CF)({attribute:"title"})],v.prototype,"title",void 0),(0,l.Cg)([m.CF],v.prototype,"id",void 0),(0,l.Cg)([(0,m.CF)({attribute:"tel-metadata"})],v.prototype,"telemetryMetadata",void 0),v=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-title-mask")],v);var x=a(92011),b=a(59669),C=a(16559);let $=(0,b.A)` .native-ad-title-mask a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%}`.withBehaviors(new C.e("layoutStyle"));var w=a(89757);let k=(0,w.qy)`<div class="native-ad-title-mask" title = ${e=>e.title}><a target = "_blank" href = ${e=>e.destinationUrl} title=${e=>e.title} class="heading" id="heading" data-t="${e=>e.telemetryMetadata}"></a></div>`,T=class extends v{};T=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-title-mask",template:k,styles:$})],T);var S=a(2188),F=a(69259),z=a(60815);let A=class extends y.t{constructor(){super(...arguments),this.src="",this.rlink="",this.id="",this.altText="",this.width="300px",this.height="225px",this.isHovered=!1,this.imageMaskOn="off",this.imageMaskOpacity="0.5",this.trimBottom=!1,this.objectFit="",this.useDropShadow=!1,this.useTransparentBackground=!1,this.imageMaskLeft="",this.imageMaskTop="",this.imageMaskWidth="",this.imageMaskHeight="",this.patternMode="",this.darkThemeMediaQuery=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)"),this.isDarkMode=this.darkThemeMediaQuery.matches,this.themeModeSwitchHandler=()=>{this.isDarkMode=!this.isDarkMode}}disconnectedCallback(){super.disconnectedCallback(),this.patternMode&&this.darkThemeMediaQuery.removeEventListener("change",this.themeModeSwitchHandler)}connectedCallback(){super.connectedCallback(),this.patternMode&&this.darkThemeMediaQuery.addEventListener("change",this.themeModeSwitchHandler)}};(0,l.Cg)([m.CF],A.prototype,"src",void 0),(0,l.Cg)([m.CF],A.prototype,"rlink",void 0),(0,l.Cg)([m.CF],A.prototype,"id",void 0),(0,l.Cg)([(0,m.CF)({attribute:"alt-text"})],A.prototype,"altText",void 0),(0,l.Cg)([m.CF],A.prototype,"width",void 0),(0,l.Cg)([m.CF],A.prototype,"height",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-hovered"})],A.prototype,"isHovered",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-on"})],A.prototype,"imageMaskOn",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-opacity"})],A.prototype,"imageMaskOpacity",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"trim-bottom"})],A.prototype,"trimBottom",void 0),(0,l.Cg)([(0,m.CF)({attribute:"object-fit"})],A.prototype,"objectFit",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"use-drop-shadow"})],A.prototype,"useDropShadow",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"use-transparent-background"})],A.prototype,"useTransparentBackground",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-left"})],A.prototype,"imageMaskLeft",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-top"})],A.prototype,"imageMaskTop",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-width"})],A.prototype,"imageMaskWidth",void 0),(0,l.Cg)([(0,m.CF)({attribute:"image-mask-height"})],A.prototype,"imageMaskHeight",void 0),(0,l.Cg)([(0,m.CF)({attribute:"pattern-mode"})],A.prototype,"patternMode",void 0),(0,l.Cg)([z.sH],A.prototype,"isDarkMode",void 0),A=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-product-image")],A);var L=a(22062),M=a(22131);let _=a.p+"PESeasonalPattern1.7b7c0587832a31c1.png",B=a.p+"PESeasonalPattern2.35494d4f15dfbe33.png",I=a.p+"PESeasonalPattern1_dark.992ba327a5f23a74.png",q=a.p+"PESeasonalPattern2_dark.6aa4c4cbcfa5ac55.png",D=(0,b.A)`
.native-ad-product-image{display:block;width:100%;height:100%;object-fit:cover}.native-ad-product-image-trim-bottom{width:100%;height:100%;object-fit:cover;object-position:top}.off{display:none}.drop-shadow{filter:drop-shadow(0px 4.8px 14.4px rgba(0,0,0,0.18)) drop-shadow(0px 4px 18px rgba(0,0,0,0.15))}`.withBehaviors(new C.e("layoutStyle"),new L.X(["objectFit","isHovered","imageMaskLeft","imageMaskTop","imageMaskOpacity","useTransparentBackground"],e=>{let t="undefined"===e.imageMaskOpacity||null==e.imageMaskOpacity?"0.5":e.imageMaskOpacity,a="";if("on"===e.imageMaskOn&&e.isHovered){let i=e.imageMaskLeft?`${e.imageMaskLeft}px`:0,o=e.imageMaskTop?`${e.imageMaskTop}px`:0,n=e.imageMaskWidth?`${e.imageMaskWidth}px`:"100%",r=e.imageMaskHeight?`${e.imageMaskHeight}px`:"100%";a=` :host::before{content:"";position:fixed;left:${i};
                        top: ${o};
                        width: ${n};
                        height: ${r};
                        opacity: ${t};
                        background: var(--ad-background-color);
                        animation: fadeIn 0.1s linear;
                        transition: opacity 0.1s linear;
                        z-index: 1;
                    }
                `}"off"!==e.imageMaskOn&&e.isHovered||(a=" :host::before{opacity:0}");let i="";return e.patternMode&&("patternMode1"===e.patternMode?i=` :host{background-image:url(${e.isDarkMode?I:_});
                            background-position: 0 0;
                            background-size: 100% 100%;
                        }
                    `:"patternMode2"===e.patternMode&&(i=` :host{background-image:url(${e.isDarkMode?q:B});
                            background-position: 0 0;
                            background-size: 100% 100%;
                        }
                    `)),(0,b.A)` :host img{background:${e.useTransparentBackground?"unset":"#2E2E2E"}}${a} ${i} .object-fit{object-fit:${e.objectFit}}@keyframes fadeIn{from{opacity:0}to{opacity:${t}}}`}),(0,M.mr)((0,b.A)` :host::after{background:buttonface}`)),E=(0,w.qy)` ${(0,F.z)(e=>!e.patternMode,(0,w.qy)`<img src="${e=>e.src}" alt="${e=>e.altText}" class="object-fit ${e=>{let t;return t=[],e.useDropShadow&&t.push("drop-shadow"),e.trimBottom?t.push("native-ad-product-image-trim-bottom"):t.push("native-ad-product-image"),t.join(" ")}}" @load=${e=>e.visualReadinessCallback&&e.visualReadinessCallback()} @error=${(e,t)=>{e.visualReadinessCallback&&e.visualReadinessCallback(t.event)}} />`)}
`,H=class extends A{};H=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-product-image",template:E,styles:D,shadowOptions:{delegatesFocus:!0}})],H);let P=class extends y.t{constructor(){super(...arguments),this.color="",this.paddingTop="78",this.paddingBottom="53",this.isRadialMask="false",this.isFullGradient="false",this.height="",this.useDynamicStyle="",this.background="",this.peSeasonalColorMode=""}connectedCallback(){super.connectedCallback()}};(0,l.Cg)([m.CF],P.prototype,"color",void 0),(0,l.Cg)([m.CF],P.prototype,"paddingTop",void 0),(0,l.Cg)([m.CF],P.prototype,"paddingBottom",void 0),(0,l.Cg)([(0,m.CF)({attribute:"is-radial-mask"})],P.prototype,"isRadialMask",void 0),(0,l.Cg)([(0,m.CF)({attribute:"is-full-gradient"})],P.prototype,"isFullGradient",void 0),(0,l.Cg)([m.CF],P.prototype,"height",void 0),(0,l.Cg)([(0,m.CF)({attribute:"use-dynamic-style"})],P.prototype,"useDynamicStyle",void 0),(0,l.Cg)([m.CF],P.prototype,"background",void 0),(0,l.Cg)([(0,m.CF)({attribute:"pe-seasonal-color-mode"})],P.prototype,"peSeasonalColorMode",void 0),P=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-gradient-mask")],P);let R=(0,b.A)` .native-ad-mask{cursor:pointer;padding-bottom:45px;padding-top:78px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 40%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.use-short-gradient{cursor:pointer;padding-bottom:45px;padding-top:45px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 23%,var(--ad-background-color) 34%,var(--ad-background-color) 100%)}.padding-top-30{padding-top:30px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 40%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.padding-top-10{padding-top:10px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 40%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.padding-top-90{padding-top:90px;padding-bottom:50px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 50%,var(--ad-background-color) 60%,var(--ad-background-color) 100%)}.padding-top-120{padding-top:120px;padding-bottom:70px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 30%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.padding-top-100{padding-top:100px;padding-bottom:70px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 30%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.padding-bottom-0{padding-bottom:0px;padding-top:60px;background:linear-gradient(var(--gradient-end-color) 0%,var(--gradient-mid-color) 40%,var(--ad-background-color) 50%,var(--ad-background-color) 100%)}.native-ad-radial-mask{background:radial-gradient(500px 150px ellipse at 50% 0%,var(--gradient-end-color) 0%,var(--gradient-end-color) 30%,var(--gradient-mid-color) 70%,var(--ad-background-color) 100%)}.native-ad-full-gradient{height:100%;background:linear-gradient(var(--gradient-end-color) 0%,var(--ad-background-color) 100%)}@media (prefers-color-scheme:light){.peSeasonalColorMode1{background:linear-gradient(180deg,rgba(255,255,255,0) 0%,rgba(255,255,255,0) 23%,rgba(255,255,255,0.8) 34%,#FFFFFF 100%)}.peSeasonalColorMode2{background:linear-gradient(180deg,rgba(107,193,210,0) 0%,rgba(177,224,233,0.8) 23%,#B1E0E9 34%,#FFFFFF 70%,#EEDEBF 100%)}.peSeasonalColorMode3{background:linear-gradient(180deg,rgba(255,233,176,0) 0%,rgba(255,233,176,0.8) 23%,#FFE9B0 34%,#FFE9B0 100%)}.peSeasonalColorMode4{background:linear-gradient(180deg,rgba(206,159,166,0) 0%,rgba(227,202,206,0.8) 23%,#E3CACE 34%,#FFE9E8 100%)}}@media (prefers-color-scheme:dark){.peSeasonalColorMode1{background:linear-gradient(180deg,rgba(43,43,43,0) 0%,rgba(43,43,43,0.8) 23%,#2B2B2B 34%,#2B2B2B 100%)}.peSeasonalColorMode2{background:linear-gradient(180deg,rgba(11,35,63,0) 0%,rgba(11,35,63,0.8) 23%,#0B233F 34%,#040D17 100%)}.peSeasonalColorMode3{background:linear-gradient(180deg,rgba(58,35,0,0) 0%,rgba(58,35,0,0.8) 23%,#3A2300 34%,#1F1200 100%)}.peSeasonalColorMode4{background:linear-gradient(180deg,rgba(56,0,31,0) 0%,rgba(56,0,31,0.8) 23%,#38001F 34%,#2F0007 100%)}}`.withBehaviors(new C.e("layoutStyle"),new L.X(["height","paddingTop","paddingBottom","background"],e=>{let t=e?.background&&e?.background!=="undefined"?e.background:"linear-gradient(var(--gradient-end-color) 0%, var(--ad-background-color) 100%)";return(0,b.A)` .native-ad-dynamic-style{height:${e.height}px;padding-top:${e.paddingTop}px;padding-bottom:${e.paddingBottom}px;background:${t}}`}),(0,M.mr)((0,b.A)` .native-ad-mask,.padding-top-30,.padding-top-10,.padding-top-90,.padding-top-120,.padding-top-100,.padding-bottom-0{background:linear-gradient(transparent 0%,buttonface 50%,buttonface 100%)}.native-ad-dynamic-style{display:none}`)),U=(0,w.qy)`<div class=" native-ad-mask ${e=>"true"===e.useDynamicStyle?"native-ad-dynamic-style":""} ${e=>"undefined"!==e.paddingTop?`padding-top-${e.paddingTop}`:""} ${e=>"undefined"!==e.paddingBottom?`padding-bottom-${e.paddingBottom}`:""} ${e=>"true"===e.isRadialMask?"native-ad-radial-mask":""} ${e=>"true"===e.isFullGradient?"native-ad-full-gradient":""} use-short-gradient ${e=>e.peSeasonalColorMode} "><slot></slot></div>`,N=class extends P{};N=(0,l.Cg)([(0,x.E)({name:"msn-native-gradient-mask",template:U,styles:R,shadowOptions:{delegatesFocus:!0}})],N);var O=a(95288);let V=class extends y.t{constructor(){super(...arguments),this.title="",this.destinationUrl="",this.isHovered=!1,this.enableTitleClickableOnly=!1,this.isAnaheimDesign=!1,this.useSmallFontSize=!0,this.animationOn=!1,this.fontSize="",this.fontColor="black",this.customStyle="",this.customStyleHovered="",this.lineHeight="",this.fontWeight="",this.fontFamily="inherit",this.isFeedV2=!1,this.isRiverRegion=!1,this.telemetryMetadata=void 0}connectedCallback(){super.connectedCallback(),(0,O.f)(this.fontFamily)}};(0,l.Cg)([m.CF],V.prototype,"title",void 0),(0,l.Cg)([(0,m.CF)({attribute:"destination-url"})],V.prototype,"destinationUrl",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-hovered"})],V.prototype,"isHovered",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"enable-title-clickable-only"})],V.prototype,"enableTitleClickableOnly",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-anaheim-design"})],V.prototype,"isAnaheimDesign",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"use-small-font-size"})],V.prototype,"useSmallFontSize",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"animation-on"})],V.prototype,"animationOn",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-size"})],V.prototype,"fontSize",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-color"})],V.prototype,"fontColor",void 0),(0,l.Cg)([(0,m.CF)({attribute:"custom-style"})],V.prototype,"customStyle",void 0),(0,l.Cg)([(0,m.CF)({attribute:"custom-style-hovered"})],V.prototype,"customStyleHovered",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"two-lines-title"})],V.prototype,"twoLinesTitle",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"one-line-title"})],V.prototype,"oneLineTitle",void 0),(0,l.Cg)([(0,m.CF)({attribute:"line-height"})],V.prototype,"lineHeight",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-weight"})],V.prototype,"fontWeight",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-family"})],V.prototype,"fontFamily",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-feed-v2"})],V.prototype,"isFeedV2",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-river-region"})],V.prototype,"isRiverRegion",void 0),(0,l.Cg)([(0,m.CF)({attribute:"tel-metadata"})],V.prototype,"telemetryMetadata",void 0),V=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-title")],V);let G=(0,b.A)`
a{padding:0 16px;font-size:20px;font-weight:600}a:focus{outline:0}a::after{content:"";text-overflow:ellipsis;position:fixed;width:100%;height:100%;left:0;right:0;top:0;bottom:0;z-index:4}.native-ad-title{color:var(--neutral-foreground-rest);text-decoration:none;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;word-break:break-word}.is-river-region{margin-bottom:2px}.native-ad-title-hovered{color:var(--neutral-foreground-rest);overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;text-decoration:underline;word-break:break-word}.animation-on{transition:max-height .365s;-webkit-line-clamp:3}.two-lines-title{-webkit-line-clamp:2}.one-line-title{-webkit-line-clamp:1}.is-feed-v2{color:#1A1A1A;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;text-decoration:none;word-break:break-word;line-height:24px}@media (prefers-color-scheme:dark){.is-feed-v2{color:#FFFFFF}}@media (forced-colors:active){.native-ad-title,.native-ad-title-hovered{color:linktext;background:buttonface}}`.withBehaviors(new C.e("layoutStyle"),new L.X(["lineHeight","fontSize","fontWeight","fontFamily"],e=>{let t=` .ad-title{line-height:${e.lineHeight}px;
                    font-size: ${e.fontSize}px;
                    font-weight: ${e.fontWeight};
                    font-family: ${e.fontFamily}}a{font-size:${e.fontSize}px; }
            `;return(0,b.A)`${t}`})),Z=(0,w.qy)`<a class="${e=>{let t;return t="ad-title",e.isFeedV2?t="is-feed-v2":(e.isHovered?t+=" native-ad-title-hovered":t+=" native-ad-title",e.animationOn&&(t+=" animation-on"),e.twoLinesTitle&&(t+=" two-lines-title"),e.oneLineTitle&&(t+=" one-line-title"),e.isRiverRegion&&(t+=" is-river-region"),t)}}" style="${e=>e.isHovered?e.customStyleHovered:e.customStyle}" href=${e=>e.destinationUrl} target="_blank" data-t="${e=>e.telemetryMetadata}">${(0,F.z)(e=>!e.isAnaheimDesign,(0,w.qy)`${e=>e.title}`)} ${(0,F.z)(e=>e.isAnaheimDesign&&e.fontSize,(0,w.qy)`${e=>e.title}`)} ${(0,F.z)(e=>e.isAnaheimDesign&&!e.fontSize,(0,w.qy)` ${(0,F.z)(e=>!e.useSmallFontSize,(0,w.qy)`<span class="title">${e=>e.title}</span>`)} ${(0,F.z)(e=>e.useSmallFontSize,(0,w.qy)`${e=>e.title}`)} `)}</a>`,W=class extends V{};W=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-title",template:Z,styles:G})],W);var j=a(57662),J=a(4670);j.MZ;let X=class extends y.t{constructor(){super(...arguments),this.url="",this.providerName="",this.whiteProviderName="",this.isNewAdSlugV2=!1,this.isNewAdSlugV2NonDr=!1,this.fontFamily="inherit",this.adSlugGA=!1,this.hasEliteBadge=!1,this.adLabelTextOpacity="0.7",this.fontSize="",this.lineHeight="",this.isFeedV2=!1,this.isMsnHPAdSlug=!1,this.color="var(--neutral-foreground-rest)",this.fontWeight="normal",this.isSeasonal=!1,this.eliteBadgeTitle=""}connectedCallback(){super.connectedCallback(),(0,O.f)(this.fontFamily),this.eliteBadgeTitle=this.localizedStrings?.eliteBadgeTitle}};(0,l.Cg)([m.CF],X.prototype,"url",void 0),(0,l.Cg)([(0,m.CF)({attribute:"provider-name"})],X.prototype,"providerName",void 0),(0,l.Cg)([(0,m.CF)({attribute:"white-provider-name"})],X.prototype,"whiteProviderName",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-new-ad-slug-v2"})],X.prototype,"isNewAdSlugV2",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-new-ad-slug-v2-non-dr"})],X.prototype,"isNewAdSlugV2NonDr",void 0),(0,l.Cg)([(0,m.CF)({attribute:"custom-style-class"})],X.prototype,"customStyleClass",void 0),(0,l.Cg)([(0,m.CF)({attribute:"tel-metadata"})],X.prototype,"telemetryMetadata",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-family"})],X.prototype,"fontFamily",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"ad-slug-ga"})],X.prototype,"adSlugGA",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"has-elite-badge"})],X.prototype,"hasEliteBadge",void 0),(0,l.Cg)([(0,m.CF)({attribute:"ad-label-text-opacity"})],X.prototype,"adLabelTextOpacity",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-size"})],X.prototype,"fontSize",void 0),(0,l.Cg)([(0,m.CF)({attribute:"line-height"})],X.prototype,"lineHeight",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-feed-v2"})],X.prototype,"isFeedV2",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-msn-hp-ad-slug"})],X.prototype,"isMsnHPAdSlug",void 0),(0,l.Cg)([m.CF],X.prototype,"color",void 0),(0,l.Cg)([(0,m.CF)({attribute:"font-weight"})],X.prototype,"fontWeight",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-seasonal"})],X.prototype,"isSeasonal",void 0),(0,l.Cg)([z.sH],X.prototype,"eliteBadgeTitle",void 0),(0,l.Cg)([z.sH],X.prototype,"localizedStrings",void 0),X=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-provider-name")],X);var Y=a(63033);let K=(0,b.A)`
.provider-name-with-elite-badge-wrapper{display:flex;flex-direction:row;align-items:center}.provider-name-with-elite-badge-wrapper .elite-badge-icon{margin-inline-end:4px;display:flex}.white{color:white;text-decoration:inherit}.white-12-flex-layout{color:var(--neutral-foreground-rest);width:100%;font-size:12px;text-overflow:ellipsis;height:24px;line-height:24px}.with-opacity-70{opacity:0.7}.with-opacity-70-non-dr{color:unset;opacity:1}.font-tenorite{font-family:Tenorite,Segoe UI,Segoe UI Midlevel,Arial,Sans-Serif;font-size:14px;position:relative;top:2px}.provider-name-hyper-link:focus-visible{outline-offset:-.1px;outline:auto}`.withBehaviors(new C.e("layoutStyle"),new L.X(["adLabelTextOpacity","lineHight","fontSize"],e=>(0,b.A)` .provider-name-hyper-link,.provider-name{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:bottom;opacity:${e.adLabelTextOpacity};font-size:${e.fontSize}px;line-height:${e.lineHeight}px;text-decoration:inherit;color:${e.color&&"undefined"!==e.color?e.color:"var(--neutral-foreground-rest)"};font-weight:${e.fontWeight&&"undefined"!==e.fontWeight?e.fontWeight:"normal"}}@media (forced-colors:active){.provider-name-hyper-link,.provider-name{color:buttontext !important;opacity:1;background:buttonface}}.is-feed-v2{color:#292929}.is-seasonal-style{color:#000000}.is-msn-hp-style{color:#2b2b2b}@media (prefers-color-scheme:dark){.is-feed-v2{color:#FFFFFF}.is-seasonal-style{color:#FFFFFF}}`),new Y.N(null,(0,b.A)` .is-msn-hp-style{color:var(--neutral-foreground-rest)}`)),Q=(0,w.qy)`<a href="${e=>e.url}" target="_blank" title="${e=>e.eliteBadgeTitle}" class="elite-badge-icon"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="12" viewBox="0 0 13 12" fill="none"><path d="M6.5 0C7.05078 0 7.58203 0.0703125 8.09375 0.210938C8.60547 0.351562 9.08203 0.554688 9.52344 0.820312C9.96484 1.08594 10.3691 1.39844 10.7363 1.75781C11.1035 2.11719 11.418 2.52148 11.6797 2.9707C11.9414 3.41992 12.1426 3.89844 12.2832 4.40625C12.4238 4.91406 12.4961 5.44531 12.5 6C12.5 6.55078 12.4297 7.08203 12.2891 7.59375C12.1484 8.10547 11.9453 8.58203 11.6797 9.02344C11.4141 9.46484 11.1016 9.86914 10.7422 10.2363C10.3828 10.6035 9.97852 10.918 9.5293 11.1797C9.08008 11.4414 8.60156 11.6426 8.09375 11.7832C7.58594 11.9238 7.05469 11.9961 6.5 12C5.94922 12 5.41797 11.9297 4.90625 11.7891C4.39453 11.6484 3.91797 11.4453 3.47656 11.1797C3.03516 10.9141 2.63086 10.6016 2.26367 10.2422C1.89648 9.88281 1.58203 9.47852 1.32031 9.0293C1.05859 8.58008 0.857422 8.10156 0.716797 7.59375C0.576172 7.08594 0.503906 6.55469 0.5 6C0.5 5.44922 0.570312 4.91797 0.710938 4.40625C0.851562 3.89453 1.05469 3.41797 1.32031 2.97656C1.58594 2.53516 1.89844 2.13086 2.25781 1.76367C2.61719 1.39648 3.02148 1.08203 3.4707 0.820312C3.91992 0.558594 4.39844 0.357422 4.90625 0.216797C5.41406 0.0761719 5.94531 0.00390625 6.5 0ZM5.81445 7.89258C5.90039 7.89258 5.98242 7.87695 6.06055 7.8457C6.13867 7.81445 6.20703 7.76758 6.26562 7.70508L8.7793 5.19141C8.83789 5.13281 8.88281 5.06445 8.91406 4.98633C8.94531 4.9082 8.96094 4.82812 8.96094 4.74609C8.96094 4.66016 8.94531 4.57812 8.91406 4.5C8.88281 4.42188 8.83789 4.35547 8.7793 4.30078C8.7207 4.24609 8.65234 4.20117 8.57422 4.16602C8.49609 4.13086 8.41406 4.11328 8.32812 4.11328C8.24609 4.11328 8.16602 4.12891 8.08789 4.16016C8.00977 4.19141 7.93945 4.23633 7.87695 4.29492L5.81445 6.35742L5.12305 5.66602C4.99805 5.54102 4.84766 5.47852 4.67188 5.47852C4.58594 5.47852 4.50391 5.49414 4.42578 5.52539C4.34766 5.55664 4.2793 5.60352 4.2207 5.66602C4.16211 5.72852 4.11719 5.79492 4.08594 5.86523C4.05469 5.93555 4.03711 6.01758 4.0332 6.11133C4.0332 6.19336 4.04883 6.27344 4.08008 6.35156C4.11133 6.42969 4.1582 6.5 4.2207 6.5625L5.36328 7.70508C5.42188 7.76367 5.49023 7.80859 5.56836 7.83984C5.64648 7.87109 5.72852 7.88867 5.81445 7.89258Z" fill="white"/></svg></a>`,ee=(0,w.qy)`<a href="${e=>e.url}" class="${e=>"Tenorite"===e.fontFamily?"font-tenorite":""} ${e=>"true"===e.whiteProviderName?"white":`provider-name-hyper-link ${e.customStyleClass||""} ${e.isNewAdSlugV2&&!e.keepOpacity?"with-opacity-70":""} ${e.isNewAdSlugV2NonDr||!e.adSlugGA?"with-opacity-70-non-dr":""}`} ${e=>e.isFeedV2?"is-feed-v2":""} ${e=>e.isMsnHPAdSlug?"is-msn-hp-style":""} ${e=>e.isSeasonal?"is-seasonal-style":""}" target="_blank" title=" ${e=>e.providerName}" data-t="${e=>e.telemetryMetadata}">${e=>e.providerName}</a>`,et=(0,w.qy)` ${(0,F.z)(e=>e.hasEliteBadge,(0,w.qy)`<span class="provider-name-with-elite-badge-wrapper">${Q} ${ee}</span>`)} ${(0,F.z)(e=>!e.hasEliteBadge,ee)}
`,ea=class extends X{};ea=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-provider-name",template:et,styles:K})],ea);var ei=a(82988),eo=a(95102);let en=class extends y.t{constructor(){super(...arguments),this.adChoiceIconUrl="",this.nativeAdAdChoiceText="",this.telemetryMetadata="",this.isFeedV2=!1}connectedCallback(){super.connectedCallback();let{iconStyles:e}=this,t=[];e&&Object.keys(e).forEach(a=>{t.push((0,eo.MD)(a,e[a]))}),this.iconStyleStr=(0,b.A)`:host .native-ad-ad-choice {${t.length?t.join(";"):""}}`}};(0,l.Cg)([(0,m.CF)({attribute:"ad-choice-icon-url"})],en.prototype,"adChoiceIconUrl",void 0),(0,l.Cg)([(0,m.CF)({attribute:"native-ad-ad-choice-text"})],en.prototype,"nativeAdAdChoiceText",void 0),(0,l.Cg)([(0,m.CF)({attribute:"tel-metadata"})],en.prototype,"telemetryMetadata",void 0),(0,l.Cg)([(0,m.CF)({mode:"boolean",attribute:"is-feed-v2"})],en.prototype,"isFeedV2",void 0),(0,l.Cg)([z.sH],en.prototype,"iconStyles",void 0),(0,l.Cg)([z.sH],en.prototype,"iconStyleStr",void 0),en=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-ad-choice")],en);let er=(0,b.A)`
@media (forced-colors:active){.native-ad-ad-choice{background:buttonface}}.native-ad-ad-choice{width:32px;height:32px;display:inline-flex}.native-ad-ad-choice svg{margin:auto}`.withBehaviors(new C.e("layoutStyle"),new C.e("iconStyleStr")),ed=(0,w.qy)`
<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M1.3845 -1.21037e-07C2.22828 -1.94803e-07 2.819 0.40029 3.40971 0.719747C3.91584 0.959663 4.42266 1.27977 5.01337 1.51968C7.71388 2.87964 10.4144 4.31978 13.1142 5.75992C13.958 6.16021 15.0548 6.55986 15.6455 7.28025C15.814 7.52017 16.0678 7.84027 15.9832 8.24056C15.7301 9.12068 14.5487 9.44079 13.7895 9.84043C11.9328 10.8007 9.99215 11.8406 8.13543 12.8003C7.46013 13.2005 6.44787 13.9203 5.60409 13.3603C5.26644 13.2005 5.09795 13.0402 5.01337 12.8003C4.92879 12.4802 5.01337 12.0805 5.01337 11.7604L5.01337 9.20023C5.01337 8.48048 4.92879 7.92046 5.4356 7.60035C5.60409 7.52017 5.94173 7.44063 6.1948 7.52017C7.03858 7.84027 6.78552 9.28041 6.78552 10.4005L6.78552 11.2799C8.22001 10.5602 9.6545 9.83979 11.089 9.20022C11.5951 8.96031 12.4389 8.72039 12.6081 8.08019C12.7766 7.36044 11.1736 6.80042 10.6675 6.55986L4.84489 3.43966C4.42266 3.19974 3.32581 2.3998 2.6512 2.63972C2.39813 2.71991 2.22897 2.95982 2.22897 3.11955C2.14438 3.43966 2.14438 3.91949 2.14438 4.31978L2.14438 6.87996L2.14438 11.1997C2.14438 11.8399 2.0598 12.6399 2.31287 13.0395C2.90358 13.8395 4.25349 12.3993 4.67572 13.6797C4.76031 13.9998 4.59114 14.3199 4.42266 14.4797C4.08501 14.9601 2.56593 15.6799 1.97522 15.8403C1.80674 15.9198 1.3845 16 1.13144 16C-0.303057 15.7601 0.0345918 13.6002 0.0345916 11.9997L0.0345909 4.07986C0.0345908 2.87964 -0.133892 1.27977 0.372239 0.560019C0.625305 0.159727 0.878371 0.159728 1.3845 -1.21037e-07ZM5.77257 5.1999C7.03858 5.1999 7.12248 6.72023 5.94105 6.96015C5.26576 7.04034 4.75962 6.40013 4.92811 5.84011C5.09727 5.43982 5.35034 5.35963 5.77257 5.1999Z" fill="#00AECD"/>
</svg>
`,es=(0,w.qy)`
<svg width="20" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.52344 5.69531C4.70573 5.69531 4.86198 5.63542 4.99219 5.51562C5.1224 5.39062 5.1875 5.24219 5.1875 5.07031C5.1875 4.89844 5.1224 4.7526 4.99219 4.63281C4.86198 4.50781 4.70573 4.44531 4.52344 4.44531C4.33594 4.44531 4.17708 4.50781 4.04688 4.63281C3.91667 4.7526 3.85156 4.89844 3.85156 5.07031C3.85156 5.24219 3.91667 5.39062 4.04688 5.51562C4.17708 5.63542 4.33594 5.69531 4.52344 5.69531ZM1.44531 0.921875V0.929688C1.33594 0.861979 1.21875 0.828125 1.09375 0.828125C0.90625 0.828125 0.747396 0.890625 0.617188 1.01562C0.486979 1.13542 0.421875 1.28125 0.421875 1.45312V11.375C0.421875 11.5469 0.486979 11.6953 0.617188 11.8203C0.747396 11.9401 0.90625 12 1.09375 12C1.19271 12 1.28906 11.9792 1.38281 11.9375H1.39062L1.40625 11.9219L3.20312 11.0625C3.48958 10.9635 3.63281 10.7708 3.63281 10.4844C3.63281 10.3073 3.56771 10.1589 3.4375 10.0391C3.30729 9.91406 3.15104 9.85156 2.96875 9.85156C2.85417 9.85156 2.74479 9.8776 2.64062 9.92969C2.63542 9.9401 2.61979 9.95052 2.59375 9.96094C2.51042 10.0026 2.42188 10.0234 2.32812 10.0234C2.17188 10.0234 2.03906 9.97396 1.92969 9.875C1.82031 9.77083 1.76302 9.64844 1.75781 9.50781V3.375C1.76302 3.22917 1.82031 3.10677 1.92969 3.00781C2.03906 2.90365 2.17188 2.85156 2.32812 2.85156C2.41667 2.85156 2.5 2.8724 2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L8.53906 5.92188L8.64844 5.97656C8.8099 6.08594 8.89062 6.23177 8.89062 6.41406C8.89062 6.60677 8.80469 6.75521 8.63281 6.85938L8.5625 6.89844L5.1875 8.60938V6.67969C5.1875 6.5026 5.1224 6.35417 4.99219 6.23438C4.86198 6.11458 4.70573 6.05469 4.52344 6.05469C4.33594 6.05469 4.17708 6.11458 4.04688 6.23438C3.91667 6.35417 3.85156 6.5026 3.85156 6.67969V9.65625C3.85156 9.83333 3.91667 9.98177 4.04688 10.1016C4.17708 10.2214 4.33594 10.2812 4.52344 10.2812C4.65885 10.2812 4.78385 10.2448 4.89844 10.1719L11.125 7.00781C11.4271 6.90885 11.5781 6.71094 11.5781 6.41406C11.5781 6.14844 11.4453 5.95833 11.1797 5.84375L1.44531 0.921875ZM2.59375 9.96094C2.61979 9.95052 2.63542 9.9401 2.64062 9.92969L2.59375 9.96094ZM2.57812 2.91406C2.58333 2.91406 2.58854 2.91667 2.59375 2.92188C2.59896 2.92188 2.60417 2.92448 2.60938 2.92969L2.57812 2.91406Z" fill="#00aecd"/>
</svg>
`,el=(0,w.qy)`
${(0,F.z)(e=>e.adChoiceIconUrl,(0,w.qy)`<a class="native-ad-ad-choice" href="${e=>e.adChoiceIconUrl}" target="_blank" title="${e=>e.nativeAdAdChoiceText}" data-t="${e=>e.telemetryMetadata}" aria-label="${e=>e.nativeAdAdChoiceText}">${(0,F.z)(e=>!e.isFeedV2,(0,w.qy)`${es}`)} ${(0,F.z)(e=>e.isFeedV2,(0,w.qy)` ${ed} `)}</a>`)}
`,ec=class extends en{};ec=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-ad-choice",template:el,styles:er})],ec);let ep=class extends y.t{constructor(){super(...arguments),this.cardActionsTooltips=""}connectedCallback(){super.connectedCallback()}};(0,l.Cg)([(0,m.CF)({attribute:"card-actions-tooltips"})],ep.prototype,"cardActionsTooltips",void 0),(0,l.Cg)([(0,m.CF)({attribute:"data"})],ep.prototype,"data",void 0),ep=(0,l.Cg)([(0,f.TA)(u.PDj,"msn-native-ad-see-more")],ep);let eg=(0,b.A)` .card-button{border-radius:100%}.card-button:not(:hover){background:transparent}.card-see-more{align-items:center;background-color:rgb(255,255,255);border-radius:100%;border:1px solid rgb(229,229,229);cursor:pointer;display:flex;height:32px;justify-content:center;outline:none;margin-right:2px;width:32px}.card-see-more svg{fill:inherit}`.withBehaviors(new C.e("layoutStyle"),new L.X(["data"],e=>{let t="";return!e.data||e.data.isInfopane||e.data.enableFilledIconOnHover&&(!e.data.enableFilledIconOnHover||e.data.optedOutOfReactions)||(t+="dynamic-styles{display:inline-flex}"),(0,b.A)`${t}`}));var eh=a(16215),em=a(95402),eu=a(68835),ef=a(33307),ey=a(19173);a(52780).J;let ev=(0,w.qy)`<button class="card-see-more" title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.seeMore} @click=${(e,t)=>e.toggleCardActionMenu&&e.toggleCardActionMenu(e,t.event)} data-t="${e=>e.telemetryContext?.seeMore?.getMetadataTag()}">${w.qy.partial(ey.A)}</button>`,ex=(0,w.qy)` ${(0,eu.ux)(e=>[e.data],(0,w.qy)` ${(0,F.z)(e=>e.isAdFeedbackV1Enabled&&!!e.feedbackUrl,(0,w.qy)` ${(0,F.z)(e=>!e.isFeedV2,(0,w.qy)`<msn-card-button class="card-button dynamic-styles" select-title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.seeMore} unselect-icon=${ef.A} filled-icon-path=${eh.i_} layout=${e=>(0,em.V1)(e)} @selected-state-changed=${(e,t)=>e.toggleCardActionMenu&&e.toggleCardActionMenu(e,t.event)} select-telemetry-tag=${e=>e.telemetryContext?.seeMore?.getMetadataTag()}></msn-card-button>`)} ${(0,F.z)(e=>e.isFeedV2&&e.isHovered,(0,w.qy)`${ev}`)} `)} `)}
`,eb=class extends ep{};eb=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-see-more",template:ex,styles:eg})],eb);var eC=a(48566),e$=a(63456);let ew=e=>{let t=e.localizedStrings?.nativeAdTrendingTitleText||"More than {0} people have viewed this product",a=(0,e$.A)(ek((0,e$.A)(e,"assets.viewed","")),"viewed","");return eC.Qf.Format(t,a)},ek=(0,f.sx)(u._0l,"parseViewedStringToJSON")(e=>{if(!e)return"";let t={};try{t=JSON.parse(e)}catch{return""}return t&&t.viewed&&t.comparisonDays?t:""}),eT=e=>{let t=e.localizedStrings?.nativeAdSaleHighlightTitleText||"SALE {0}% OFF";return eC.Qf.Format(t,e.assets?.discount)},eS=e=>{let t=e.localizedStrings?.nativeAdSaleHighlightTitleText||"SALE {0}% OFF",a=t.split("{0}%"),i=eC.Qf.Format(t,e.assets?.discount),[o,n]=a,r=i.slice(o.length,i.length-n.length);return{prefix:o.trim(),suffix:n.trim(),highlightText:r.trim()}};class eF{chain(e){this.nextBuilder=e}build(e,t){let a=this.doBuild(e,t);return this.nextBuilder?this.nextBuilder.build(e,a):a}}(0,l.Cg)([(0,f.sx)(u.WLY,"BaseBuilder.Chain")],eF.prototype,"chain",null),(0,l.Cg)([(0,f.sx)(u.WLY,"BaseBuilder.Build")],eF.prototype,"build",null);class ez extends eF{constructor(){super(),this.creatorMap=new Map}registerCreator(e,t){this.creatorMap.set(e,t)}doBuild(e,t){return this.creatorMap.has(e.name)?this.creatorMap.get(e.name)(e,t):t?(0,w.qy)`${t}`:(0,w.qy)`<div></div>`}}(0,l.Cg)([(0,f.sx)(u.WLY,"ComponentBuilder.RegisterCreator")],ez.prototype,"registerCreator",null),(0,l.Cg)([(0,f.sx)(u.WLY,"ComponentBuilder.DoBuild")],ez.prototype,"doBuild",null);class eA extends eF{doBuild(e,t){if(Array.isArray(e.children)&&e.children.length>0){let t=e.children.map(e=>this.build(e,null)),a=Array(t.length+1).fill("");return a.raw=a,(0,w.qy)`
                ${(0,eu.ux)(t=>e.children,(0,w.qy)`
                    ${e=>this.build(e,null)}
                `)}
            `,w.kc.create(a,t)}return null}}(0,l.Cg)([(0,f.sx)(u.WLY,"ChildrenBuilder.DoBuild")],eA.prototype,"doBuild",null);class eL extends y.t{constructor(){super(...arguments),this._displayName="MsnBlockLayout"}connectedCallback(){super.connectedCallback()}}(0,l.Cg)([z.sH],eL.prototype,"layoutConfig",void 0);let eM=(0,w.qy)`<slot></slot>`,e_=(0,b.A)` :host{display:block}`.withBehaviors(new C.e("layoutStyle"));class eB extends y.t{constructor(){super(...arguments),this._displayName="MsnFlexLayout"}connectedCallback(){super.connectedCallback()}}(0,l.Cg)([z.sH],eB.prototype,"layoutConfig",void 0),(0,l.Cg)([z.sH],eB.prototype,"layoutStyle",void 0);let eI=(0,w.qy)`<slot></slot>`,eq=(0,b.A)` :host{display:flex}`.withBehaviors(new C.e("layoutStyle"));class eD extends y.t{constructor(){super(...arguments),this._displayName="MsnPixelLayout"}connectedCallback(){super.connectedCallback()}}(0,l.Cg)([z.sH],eD.prototype,"layoutConfig",void 0);let eE=(0,w.qy)`<slot></slot>`,eH=(0,b.A)` :host{position:absolute}`.withBehaviors(new C.e("layoutStyle")),eP=(0,w.qy)`<slot></slot>`,eR=(0,b.A)``.withBehaviors(new C.e("layoutStyle")),eU=class extends eD{};eU=(0,l.Cg)([(0,x.E)({name:"msn-pixel-layout",template:eE,styles:eH})],eU);let eN=class extends eB{};eN=(0,l.Cg)([(0,x.E)({name:"msn-flex-layout",template:eI,styles:eq})],eN);let eO=class extends eL{};eO=(0,l.Cg)([(0,x.E)({name:"msn-block-layout",template:eM,styles:e_})],eO);let eV=class extends y.t{};eV=(0,l.Cg)([(0,x.E)({name:"msn-uber-layout",template:eP,styles:eR})],eV);class eG extends eF{doBuild(e,t){if(!e.layout)return t;let a=e.layout;if(!a.mode)return t;switch(a.mode){case"pixel":return(0,w.qy)`
        <msn-pixel-layout 
            :layoutConfig=${e=>a}
        >
            ${t}
        </msn-pixel-layout>
    `;case"flex":return(0,w.qy)`
        <msn-flex-layout 
            :layoutConfig=${e=>a}
        >
            ${t}
        </msn-flex-layout>
    `;case"block":return(0,w.qy)`
        <msn-block-layout
            :layoutConfig=${()=>a}
        >
            ${t}
        </msn-block-layout>
    `;default:return t}}}(0,l.Cg)([(0,f.sx)(u.WLY,"LayoutBuilder.DoBuild")],eG.prototype,"doBuild",null);var eZ=a(65782),eW=a(20999);let ej={impressionLog(e,t,a){let i=t?.parent?.shadowRoot?.querySelector("msn-native-ad-title")?.shadowRoot?.querySelector(".native-ad-title-wrapper")?.children?.[0],o=i?.scrollHeight,n=i?.clientHeight;o&&n&&(0,J.mh)(e.id,"nativeAdCardImpression",`${o},${n}`,0,a)},clickLog(e,t,a){let i=t?.parent?.shadowRoot?.querySelector("msn-native-ad-title")?.shadowRoot?.querySelector(".native-ad-title-wrapper")?.children?.[0],o=i?.scrollHeight,n=i?.clientHeight;o&&n&&(0,J.mh)(e.id,"nativeAdCardClick",`${o},${n}`,0,a?.target)}},eJ={PrgTitle2:ej,PrgTitle2C:ej};eZ.CR,(n=d||(d={}))[n.adChoice=0]="adChoice",n[n.destination=1]="destination",n[n.nativeAdCard=2]="nativeAdCard";class eX extends eF{doBuild(e,t){if(e.userActionLogger){let{impressionLog:t,clickLog:a}=eJ[e.userActionLogger]||{};!eW.Yg.clickLog&&a&&(eW.Yg.clickLog=a),!eW.Yg.impressionLog&&t&&(eW.Yg.impressionLog=t)}if(!e.telemetry)return t;let a=e.telemetry,i=!!a.metadata;return(0,w.qy)`
            <msn-native-ad-telemetry
                data-t="${e=>i?((e,t)=>{if(e&&e.adTelemetryContext&&t in d)return e.adTelemetryContext[t].getMetadataTag()})(e,a.metadata):""}"
                ${(0,S.Ib)(!!a.clickedBeacon||!!a.clickedTelemetry||!!a.clickedUserAction,!!a.viewedBeacon,!!a.customEvent)}
                clickedBeacon=${!!a.clickedBeacon}
                clickedUserAction=${!!a.clickedUserAction}
                clickedTelemetry=${!!a.clickedTelemetry}
                telemetryMetadata=${a.metadata}
            >
                ${t}
            </msn-native-ad-telemetry>`}}(0,l.Cg)([(0,f.sx)(u.WLY,"TelemetryBuilder.doBuild")],eX.prototype,"doBuild",null);let eY=new class{constructor(){this.create=(0,g.A)(this.createInternal),this.layoutBuilder=new eG,this.telemetryBuilder=new eX,this.telemetryBuilder.chain(this.layoutBuilder),this.componentBuilder=new ez,this.componentBuilder.chain(this.telemetryBuilder),this.rootBuilder=new eA,this.rootBuilder.chain(this.componentBuilder)}registerCreator(e,t){this.componentBuilder.registerCreator(e,t)}createInternal(e){return this.rootBuilder.build(e,null)}};eY.registerCreator("ad-title-mask",e=>(0,w.qy)`
    <msn-native-ad-title-mask
        :layoutConfig=${t=>e?.layout}
        id="${e=>e.id}${e=>null==e.index?"":`_${e.index}`}-mask"
        destination-url=${e=>e.destinationUrl}
        title=${e=>e.title}
        tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
        ${(0,S.Ib)(!0,!1)}
		component-name="${e?.name}"
    >
    </msn-native-ad-title-mask>
`),eY.registerCreator("product-image",e=>(0,w.qy)`
    ${(0,F.z)(e=>e.imageData,(0,w.qy)`
        <msn-native-ad-product-image 
            :layoutConfig=${()=>e?.layout}
            src=${t=>{var a;return a=e?.useTransparentImage,a&&t.assets?.transparentImage?.url?t.assets.transparentImage.url:t.imageData&&t.imageData.source}}
            alt-text=${e=>e.imageData&&e.imageData.altText}
            is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
            image-mask-on=${()=>e?.imageMaskOn?"on":"off"}
            image-mask-opacity=${()=>e?.imageMaskOpacity}
            trim-bottom=${()=>e?.trimBottom}
            object-fit=${()=>e?.useTransparentImage?"contain":"cover"}
            use-drop-shadow=${()=>e?.useTransparentImage&&!e?.noDropShadow}
            use-transparent-background=${()=>e?.useTransparentImage}
            image-mask-left=${()=>e?.imageMaskLeft}
            image-mask-top=${()=>e?.imageMaskTop}
            image-mask-width=${()=>e?.imageMaskWidth}
            image-mask-height=${()=>e?.imageMaskHeight}
            id="${e=>e.id}-product-image"
            rlink=${e=>e.destionationUrl}
			component-name=${e?.name}
            :visualReadinessCallback=${e=>e.visualReadinessCallback}
            pattern-mode=${()=>e?.patternMode}
        >
        </msn-native-ad-product-image>
    `)}
`),eY.registerCreator("gradient-mask",(e,t)=>(0,w.qy)`
    ${(0,F.z)(e=>e.destinationUrl,(0,w.qy)`
        <msn-native-gradient-mask
            :layoutConfig=${t=>e?.layout}
            paddingTop=${e&&e.paddingTop}
            paddingBottom=${e&&e.paddingBottom}
            is-radial-mask=${e&&e.isRadialMask}
            is-full-gradient=${e&&e.isFullGradient}
            use-dynamic-style=${e&&e.useDynamicStyle}
            height=${e&&e.height}
            background="${e&&e.background}"
            @click=${e=>e.destinationUrl&&window.open(e.destinationUrl)}
            ${e&&e.setClickBeacon?(0,S.Ib)(!0,!1):""}
			component-name="${e?.name}"
            pe-seasonal-color-mode=${e&&e.peSeasonalColorMode}
        >
            ${(0,F.z)(()=>t,t)}
        </msn-native-gradient-mask>
    `)}
`),eY.registerCreator("ad-title",e=>(0,w.qy)`
    <msn-native-ad-title
        :layoutConfig=${t=>e?.layout}
        is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
        id="${e=>e.id}${e=>null==e.index?"":`_${e.index}`}-ad-title"
        title=${e=>(e.template?.templateType==="msn-native-ad-short-title"||e.template?.templateType==="msn-ad-cta-short-title")&&e.assets?.shortTitle||e.title}
        destination-url=${e=>e.destinationUrl}
        custom-style=${e&&e.customStyle}
        custom-style-hovered=${e?.customStyleHovered}
        animation-on=${e=>e.template&&"msn-content-reveal"===e.template.templateType}
        line-height=${t=>t&&("infopane"===t.region||"resinfopane"===t.region)&&t.items&&t.items.length>1?28:e&&e.lineHeight}
        font-weight=${t=>t&&("infopane"===t.region||"resinfopane"===t.region)&&t.items&&t.items.length>1?400:e&&e.fontWeight}
        two-lines-title=${t=>e?.twoLine||t.hasAnyInlineDecoration&&!e?.oneLineTitle||t.template?.templateType==="msn-title-max-line-2"||t.adSlugGA}
        one-line-title=${t=>e?.oneLineTitle}
        font-family=${t=>{var a;return(a=e?.fontFamily)?a.includes(" ")?`"${a}"`:a:t.fontFamilyOnCardContent||"inherit"}}
        font-size=${t=>(t&&("infopane"===t.region||"resinfopane"===t.region)&&t.items&&t.items.length>1?20:e&&e.titleFontSize)||t.feedFontSize}
        is-anaheim-design=${e=>e.isAnaheimDesign}
        is-river-region=${e=>"river"===e.region||"resriver"===e.region||"rightRail"===e.region||"rightrail"===e.region}
        tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
        ${(0,S.Ib)(!0,!1)}
        ${e?.isFeedV2?"is-feed-v2":""}
		component-name="${e?.name}"
    >
    </msn-native-ad-title>
`),eY.registerCreator("ad-label",e=>(0,w.qy)`
    ${(0,F.z)(t=>t.privacyUrl||e.useAdLink,(0,w.qy)`
        <msn-native-ad-ad-label
            :layoutConfig=${t=>e?.layout}
            privacy-url="${t=>e.useAdLink?t.destinationUrl:t.privacyUrl}"
            ad-label-text-opacity="${e?.adLabelTextOpacity??"0.7"}"
            ad-label-text="${e=>e.adLabelText}"
            type="${t=>{let a,i;return a=t,(i=e)&&null!=i.adLabelType?i.adLabelType:a.isGreyAdsLabelEnabled?"greyLabel":a.adSlugGA?"defaultLabel":"greenLabel"}}"
            native-ad-ad-label-text="${e=>e.strings&&e.strings.nativeAdAdLabelText}"
            tel-metadata="${e=>(0,J.j1)(e?.adTelemetryContext)}"
            id="${e=>e.id}-ad-label"
            ${e?.isFeedV2?"is-feed-v2":""}
            ${e?.isSeasonal?"is-seasonal":""}
			component-name="${e?.name}"
        >
        </msn-native-ad-ad-label>
    `)}
`),eY.registerCreator("provider-name",e=>(0,w.qy)`
<msn-native-ad-provider-name
    ${(0,S.Ib)(!0,!1)}
    id="${e=>e.id}${e=>null==e.index?"":`_${e.index}`}-ad-provider-name"
    url=${e=>e.destinationUrl}
    provider-name=${e=>e.providerData&&e.providerData.name}
    custom-style-class=${e&&e.customStyleClass}
    ad-slug-ga=${e=>e.adSlugGA}
    tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
    font-family=${t=>{var a;return(a=e?.fontFamily)?a.includes(" ")?`"${a}"`:a:t.fontFamilyOnCardContent||"inherit"}}
    has-elite-badge=${e=>!!e.assets?.eliteBadge}
    ad-label-text-opacity="${e?.adLabelTextOpacity??"0.7"}"
    ${e?.isFeedV2?"is-feed-v2":""}
    font-size=${e?.fontSize}
    line-height=${e?.lineHeight}
    :layoutConfig=${t=>e?.layout}
    :localizedStrings=${e=>e.localizedStrings}
    color="${e?.color}"
    font-weight="${e?.fontWeight}"
	component-name="${e?.name}"
    ${e?.isSeasonal?"is-seasonal":""}
>
</msn-native-ad-provider-name>
`),eY.registerCreator("disclaimer",ei.UN),eY.registerCreator("ad-choice",e=>(0,w.qy)`
    <msn-native-ad-ad-choice 
        :layoutConfig=${t=>e?.layout}
        id="${e=>e.id}${e=>null==e.index?"":`_${e.index}`}-ad-choice"
        ad-choice-icon-url=${e=>e.adChoiceIconUrl}
        native-ad-ad-choice-text=${e=>e.strings&&e.strings.nativeAdAdChoiceText}
        ${e.isFeedV2?"is-feed-v2":""}
        tel-metadata=${e=>e?.adTelemetryContext?.adChoice?.getMetadataTag()}
		:iconStyles=${()=>e.iconStyles}
		component-name="${e?.name}"
        id="${e=>e.id}-ad-choice"
    >
    </msn-native-ad-ad-choice>
`),eY.registerCreator("see-more",e=>(0,w.qy)`
    <msn-native-ad-see-more
        :layoutConfig=${t=>e?.layout}
        :data=${t=>({...t,isFeedV2:e&&e.isFeedV2,isHovered:t.hoverState&&t.hoverState.isHovered})}
        data-t="${e=>e?.adTelemetryContext?.seeMore?.getMetadataTag()}"
		component-name="${e?.name}"
    >
    </msn-native-ad-see-more>
`),eY.registerCreator("like-button",e=>(0,w.qy)`
    <msn-native-ad-like-button
        :layoutConfig=${t=>e?.layout}
        native-ad-like-text=${e=>e.strings&&e.strings.nativeAdLikeText}
        native-ad-unlike-text=${e=>e.strings&&e.strings.nativeAdUnLikeText}
        beaconsJson=${e=>e.beaconsJson}
		component-name="${e?.name}"
    >
    </msn-native-ad-like-button>
`),eY.registerCreator("call-to-action",e=>(0,w.qy)`
    <msn-native-ad-call-to-action 
        text="${e=>e.template&&e.strings?"prg-ad-cta"===e.template.configType?e.strings.nativeAdBuyNowText:e.strings.nativeAdLearnMoreText:""}"
        default-background-color="${e&&e.backgroundColor}"
        background-color="${e=>e.template&&e.layoutColor&&"prg-ad-cta"!==e.template.configType&&"prg-ad-cta-lm"!==e.template.configType?e.layoutColor:""}"
        color="${e&&e.color}"
        is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
        cta-mode=${e&&e.ctaMode||"default"}
        destination-url=${e=>e.destinationUrl}
        tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
        ${e&&"arrow"===e.ctaMode&&(0,S.Ib)(!0,!1)}
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    >
    
    </msn-native-ad-call-to-action>
    `),eY.registerCreator("trending",e=>(0,w.qy)`
    <msn-native-ad-trending
        :layoutConfig=${t=>e?.layout}
        destination-url="${e=>e.destinationUrl}" 
        title="${e=>e.title}"
        trending-title-text=${ew}
        trending-text="${e=>(0,e$.A)(e,"localizedStrings.nativeAdTrendingText","Trending")}"
        is-hovered=${e=>e.hoverState&&e.hoverState.isHovered}
        tel-metadata=${e=>e?.adTelemetryContext?.destination?.getMetadataTag()}
        ${(0,S.Ib)(!0,!1)}
		component-name="${e?.name}"
    >
    </msn-native-ad-trending>
`),eY.registerCreator("color-mask",e=>(0,w.qy)`
<msn-native-ad-color-mask
    opacity=${e&&e.opacity}
    color=${t=>e.feedV2?t.dynamicBackground:t.layoutColor}
    is-show=${t=>e&&e.alwaysPresent||t.hoverState&&t.hoverState.isHovered}
    ${e?.feedV2?"feed-v2":""}
	component-name="${e?.name}"
    :layoutConfig=${t=>e?.layout}
>
</msn-native-ad-color-mask>
`),eY.registerCreator("sale-highlight-badge",e=>(0,w.qy)`
    <msn-native-ad-sale-highlight-badge
        :layoutConfig=${t=>e?.layout}
		component-name="${e?.name}"
        discount-text="${e=>{let t=e.localizedStrings?.nativeAdOnSaleTextCapital||"{0}% OFF";return eC.Qf.Format(t,e.assets?.discount)}}"
    >
    </msn-native-ad-sale-highlight-badge>
`),eY.registerCreator("sale-highlight-title",e=>(0,w.qy)`
    <msn-native-ad-text
        font-size="60px"
        letter-spacing="-0.015em"
        line-height="100.5%"
        font-family="Segoe UI"
        font-weight="200"
        text="${eT}"
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    />
`),eY.registerCreator("sale-highlight-horizontal-title",e=>(0,w.qy)`
    <msn-native-ad-text
        font-size="18px"
        letter-spacing="0.5em"
        line-height="100.5%"
        font-family="Segoe UI"
        font-weight="600"
        has-highlight-text="true"
        highlight-text="${e=>eS(e).highlightText}"
        highlight-text-prefix="${e=>eS(e).prefix}"
        highlight-text-suffix="${e=>eS(e).suffix}"
        highlight-text-style="font-size: 48px; letter-spacing: 0.05em; margin-inline-start: 9px; margin-inline-end: 14px;"
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    />
`),eY.registerCreator("div-wrapper",(e,t)=>(0,w.qy)`
    <msn-native-ad-div-wrapper
        marginLeft=${e&&e.marginLeft}
        marginRight=${e&&e.marginRight}
        marginTop=${e&&e.marginTop}
        marginBottom=${e&&e.marginBottom}
        width=${e&&e.width}
        marginInline=${e&&e.marginInline}
        ${e&&e.setClickBeacon?(0,S.Ib)(!0,!1):""}
		component-name="${e?.name}"
    >
        ${t}
    </msn-native-ad-div-wrapper>
`),eY.registerCreator("free-shipping",e=>(0,w.qy)`
    <decoration-free-shipping-button
        font-family=${t=>{var a;return(a=e?.fontFamily)?a.includes(" ")?`"${a}"`:a:t.fontFamilyOnCardContent||"inherit"}}
        color=${e.color}
        icon=${e.icon}
        data=${e=>(0,e$.A)(e.localizedStrings,"nativeAdFreeShippingText")}
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    >
    </decoration-free-shipping-button>
`),eY.registerCreator("rating",e=>(0,w.qy)`
    <decoration-rating
        color=${e.color}
        elementStyle=${()=>e.elementStyle}
        elementSize=${e.elementSize}
        rating=${e=>e.assets&&e.assets.rating}
        review-data=${e=>e.assets.review}
        is-show-review=${e.displayReviewCount}
        font-family=${t=>{var a;return(a=e?.fontFamily)?a.includes(" ")?`"${a}"`:a:t.fontFamilyOnCardContent||"inherit"}}
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    >
    </decoration-rating>
`),eY.registerCreator("special-offer",e=>(0,w.qy)`
    <msn-native-ad-special-offer
        :localizedStrings=${e=>e.localizedStrings}
        displayed-text="${e=>e.assets.specialOffer.displayedText}"
        promotional-text="${e=>e.assets.specialOffer.promotionalText}"
        redemption-code="${e=>e.assets.specialOffer.redemptionCode}"
        days-from-expiration="${e=>e.assets.specialOffer.daysFromExpiration}"
        destination-url="${e=>e.assets.specialOffer.destinationURL}"
        margin-left="-6"
        is-dr-config=${e&&e.isDrConfig}
        ${(0,S.Ib)(!0,!1)}
		component-name="${e?.name}"
        :layoutConfig=${t=>e?.layout}
    >
    </msn-native-ad-special-offer>
`);var eK=a(29871),eQ=a(33744),e0=a(5944);let e1=c.DI.getOrCreateDOMContainer(),e2=window.matchMedia("(prefers-color-scheme: dark)");function e5(){e1.register(c.cH.instance(p,{...this.strings,...i})),this.adBackgroundColor=e2?.matches?"#2E2E2E":"#FFFFFF",e2?.addEventListener("change",this.themeModeSwitchHandler)}class e3 extends x.L{constructor(){super(),this.adBackgroundColor="",this.hoverState={isHovered:!1,isDecorationLinesExpanded:!1},(0,z.sH)(this.hoverState,"isHovered"),(0,z.sH)(this.hoverState,"isDecorationLinesExpanded")}get componentFactory(){return eY}themeModeSwitchHandler(){this.adBackgroundColor=e2?.matches?"#2E2E2E":"#FFFFFF"}connectedCallback(){if(this.configRef&&!i){let e=eK.L.getInstance()?.getConfigResolver(),t=e?.tryGetConfigSync?.(this.configRef);eQ.T3.ConfigOrigins.feature===e0.t.Local&&eK.L.getConfig(this.configRef).then(e=>{o=e?.properties,i=o?.localizedStrings}),o=t?.properties,i=o?.localizedStrings}super.connectedCallback(),e5.call(this)}get wcData(){if(this.adData&&this.adData.adLabelText){let e={...this.config,...o},t={...this.localizedStrings,...this.strings,...i};return h(this.adData,e,t)}return null}disconnectedCallback(){e2?.removeEventListener("change",this.themeModeSwitchHandler)}}(0,l.Cg)([z.sH],e3.prototype,"adData",void 0),(0,l.Cg)([z.sH],e3.prototype,"isInfopane",void 0),(0,l.Cg)([z.sH],e3.prototype,"adBackgroundColor",void 0),(0,l.Cg)([z.sH],e3.prototype,"localizedStrings",void 0),(0,l.Cg)([z.sH],e3.prototype,"configRef",void 0);var e4=a(41066),e9=a(10037);let e8=e=>e?.template?.dynamicRenderingConfig||e4.w,e6=(e,t)=>{let a=parseInt((t??"#2E2E2E").slice(1),16);return`rgba(${a>>16&255},${a>>8&255},${255&a},${e})`},e7=(0,g.A)(e=>e6(.8,e)),te=(0,g.A)(e=>e6(0,e)),tt=e=>e8(e.wcData).cardStyles||{};var ta=a(57416);(r=s||(s={})).defaultRiverGradient="#2E2E2E",r.defaultRiverBackground="#FFFFFF",r.defaultInfopaneGradient="#000000",r.defaultInfopaneBackground="#FFFFFF",r.zIndexV2OriginalBackground="transparent";let ti=e=>e.adData?.enableAdsColorBleed?e.adData.adBackgroundColor:to(e),to=e=>{let t=e8(e.wcData);if(t.layoutColor)return t.layoutColor;let a=e.adData?.template?.templateType;return("msn-ad-zindex-v2-polygon"===a||"msn-ad-zindex-v2-original"===a||"msn-sale-highlight-v3"===a||"msn-sale-highlight-v4"===a)&&e.adData?.layoutColor&&e.adData?.assets?.transparentImage?e.adData.layoutColor:["msn-pe-seasonal","msn-pe-seasonal-v1","msn-pe-seasonal-v1p"].includes(a)?e.adBackgroundColor:""},tn=(0,w.qy)`<style>:host { height: 304px; width: 100%; position: relative; overflow: hidden; border-radius: calc(${ta.JU} * 1px); box-shadow: 0 0 3px lightgrey; } :host(msn-native-ad-dr), :host(native-ad-wc) { ${e=>{let t,a,i;return t=tt(e),a=[],(null!=t.borderColor||null!=t.borderWidth)&&a.push("border-style:solid"),i=["backgroundColor","borderColor","borderWidth","height","boxShadow","borderRadius","fontFamily"],Object.keys(t).forEach(e=>{null!=t[e]&&i.includes(e)&&a.push((0,eo.MD)(e,t[e]))}),a.length?`${a.join(";")};`:""}} } @media (prefers-color-scheme: dark) { :host{ box-shadow: 0 0 3px black; } }</style><fluent-card @mouseenter=${e=>e.hoverState.isHovered=!0} @mouseleave=${e=>e.hoverState.isHovered=!1} style=" background-color: ${e=>"msn-ad-zindex-v2-original"===e.adData?.template?.templateType?s.zIndexV2OriginalBackground:s.defaultRiverBackground}; grid-area:${e=>e.adData?.gridArea}; --ad-background-color: ${e=>ti(e)||s.defaultRiverGradient}; --gradient-mid-color: ${e=>e7(ti(e)||s.defaultRiverGradient)}; --gradient-end-color: ${e=>te(ti(e)||s.defaultRiverGradient)}; ${e=>{let t,a;return t=tt(e),a="",(null!=t.borderRadius||null!=t.borderWidth)&&(a+="border-radius: 0;"),null!=t.backgroundColor&&(a+=`background-color: ${t.backgroundColor};`),a}} " class="${e=>e.adData?.cardSize}" card-fill-color="${e=>to(e)||e.adData?.adBackgroundColor}">${(0,eu.ux)(e=>[{...e.wcData,visualReadinessCallback:e.adData?.visualReadinessCallback,hoverState:e.hoverState,componentFactory:e.componentFactory}],(0,w.qy)` ${e=>e.componentFactory.create(e8(e))} `)}</fluent-card>`,tr=(0,w.qy)`<div @mouseenter=${e=>e.hoverState.isHovered=!0} @mouseleave=${e=>e.hoverState.isHovered=!1} style=" contain: content; height: 100%; background-color: ${e=>s.defaultInfopaneBackground}; grid-area:${e=>e.adData?.gridArea}; --ad-background-color: ${e=>s.defaultInfopaneGradient}; --gradient-mid-color: ${e=>e7(s.defaultInfopaneGradient)}; --gradient-end-color: ${e=>te(s.defaultInfopaneGradient)}; --neutral-foreground-rest: ${e=>s.defaultInfopaneBackground}; " class="${e=>e.adData?.cardSize}" card-fill-color="${e=>e.adData?.adBackgroundColor}">${(0,eu.ux)(e=>[{...e.wcData,hoverState:e.hoverState,componentFactory:e.componentFactory}],(0,w.qy)` ${e=>e.componentFactory.create(e?.template?.dynamicRenderingConfig||e9.q)} `)}</div>`,td=(0,w.qy)`<style>:host { grid-area:${e=>e.adData?.gridArea}; border-radius: 6px; box-shadow: 0 0 3px lightgrey; background-color: ${s.defaultRiverGradient}; } @media (prefers-color-scheme: dark) { :host{ box-shadow: 0 0 3px black; } }</style><div></div>`,ts=(0,w.qy)` ${(0,F.z)(e=>e.wcData,e=>e.isInfopane?tr:tn)} ${(0,F.z)(e=>!e.wcData,td)}
`,tl=(0,b.A)`
`,tc=class extends e3{};tc=(0,l.Cg)([(0,x.E)({name:"msn-native-ad-wc",template:ts,styles:tl}),(0,f.TA)(u.PDj,"msn-native-ad-wc")],tc)}}]);