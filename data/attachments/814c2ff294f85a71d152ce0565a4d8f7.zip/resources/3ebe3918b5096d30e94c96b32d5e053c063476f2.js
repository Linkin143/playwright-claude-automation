"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-2c"],{70512(t,e,s){s.d(e,{O(){return r}});var i=s(67072),a=s(23305);class r extends a.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{cardSize:e,isFullCard:s,sportsGameStats:a,isSpotlight2Card:r,participants:n,isSeasonStats:o,isCopilotTheme:l,isMitUX:c}=t;let d=0;switch(e){case i.uE._1x_2y:d=s?5:3;break;case i.uE._1x_3y:d=7;break;case i.uE._2x_2y:d=4;break;case i.uE._15u:d=3}return{sportsGameStats:a.slice(0,d).map(t=>{const e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:r,isFullCard:s,participants:n,cardTitle:this.getCardTitle(o,l),isCopilotTheme:l,isMitUX:c,telemetryTag:""}}isPercentStats(t){return t?.includes("%")}getBarPercentage(t,e,s){const i=this.isPercentStats(s);return 0===t&&0===e?0:100*(i?t:t/(t+e))}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},83546(t,e,s){s.d(e,{h(){return a}});var i=s(53128);function a(){return(0,i.oh)()}},35044(t,e,s){s.r(e),s.d(e,{SportsGameStatsTransformer(){return i.O},SportsMatchWithScoresTransformer(){return c},SportsMatchTransformer(){return a.SportsMatchTransformer},SportsSpotlight2cTransformer(){return p}});var i=s(70512),a=s(82724),r=s(23305),n=s(87906),o=s(40450),l=s(33744);class c extends r.Bc{async transform(t){return{viewModel:await this.getViewModel(t)}}async getViewModel(t){const e=t.matchMetadata,s=await this.transformerProvider.generateView(e,r.hi.SportsMatch),i=e.matchData.sportsMatchData,a=this.getTableViewModel(t),n={...e.telemetryConstants,name:r.BP.SportsSpotlightMatchCard2c},o=i?.gameInfo,l=this.getGameInfoStrings(i);return{match:s.viewModel,gameInfo:o,tableView:a,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,n),gameInfoStrings:l}}getTableViewModel(t){try{const e=t.matchMetadata,s=e.matchData.sportsMatchData,i=s.detailedScore;if(!i)return;if(!i.game||i.game?.length<2)return void(0,n.vV)(o.BfS,"Sports scores table detailedScored game data missing",`market=${l.T3.CurrentMarket}`,t);const a=i.game,c=i.scoreKeyOrder,d=12;if(c.length>d)return;const h=[];s.participantOne&&(s.participantOne?.shortName&&h.push(s.participantOne.shortName),s.participantTwo?.shortName&&h.push(s.participantTwo.shortName));const p=h.map((t,e)=>({gameScore:Object.values(a[e]).slice(0,c.length),participantName:t}));if(0===p.length)return;const g={...e.telemetryConstants,name:r.BP.SportsSpotlightScores2c},m=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,g),v=this.getTableStyle(c,d),u=c.length>=5;return{headerRow:c,participants:p,maxElements:d,tableStyle:v,isLarge:u,telemetryTag:m}}catch(e){return void(0,n.vV)(o.BfS,`Error generating sports scores table view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}getGameInfoStrings(t){const e=t?.gameInfo,s={venueTitle:"",venueValue:"",streamTitle:"",streamValue:"",leagueTitle:"",leagueValue:""};return e&&(s.venueTitle=this.transformerProvider.strings.venue,s.venueValue=t.gameInfo.venueInfo,s.streamTitle=this.transformerProvider.strings.liveStream,s.streamValue=t.gameInfo.streamInfo,s.leagueTitle=this.transformerProvider.strings.league,s.leagueValue=t.gameInfo.league),s}getGap(t,e){const s=t,i=e;return`gap: ${Math.round(3*(i-s))}px;`}getTableStyle(t,e){const s=t.length;return s<5?`grid-template-columns: repeat(auto-fit, minmax(16px, max-content)); ${this.getGap(s,e)}`:"grid-template-columns: repeat(auto-fit, minmax(16px, 1fr));"}}var d=s(79811),h=s(89757);class p extends r.Bc{constructor(){super(...arguments),this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"yardsPerGame",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame"}}async transform(t){const e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.upcomingMatches)},s=await this.getCurrentViewModel(e);return{viewTemplate:h.qy`
                <sports-spotlight-2c
                    :viewModel="${s}"
                ></sports-spotlight-2c>`}}async getCurrentViewModel(t){if((0,d.nD)(t))(0,n.vV)(o.BfS,"2c spotlight metadata missing",`market=${l.T3.CurrentMarket}`,t);else try{const e=t.spotlightData?.matchlist,s=this.getMatchesMetadata(t,e),i=await this.getMatchWithScoresViews(s);0===i.length&&(0,n.vV)(o.BfS,"2c spotlight match data missing",`market=${l.T3.CurrentMarket}`,t);const{cardSize:a}=t;let r,c,d,h;if(t.spotlightData?.sportsGameStats?.length>0)r=await this.getGameStatsInfo(t),d=t.spotlightData?.isSeasonStats?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.matchStatistics;else{const e=t.spotlightData?.upcomingMatchList,s=this.getMatchesMetadata(t,e).map(t=>({...t,hasVerticalLine:!0}));c=await this.getMatchViews(s),h=this.transformerProvider.strings.upcomingGames}return{matchesWithScores:i,upcomingMatches:c,cardSize:a,sportsGameStatsCard:r,sportsGameStatsTitle:d,sportsUpcomingMatchesTitle:h,telemetryTag:""}}catch(e){(0,n.vV)(o.BfS,`Error generating sports spotlight 2c view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}async getGameStatsInfo(t){const{sportsGameStats:e,isSeasonStats:s=!1}=t.spotlightData||{},{cardSize:i}=t,a={cardSize:i,sportsGameStats:e,isSeasonStats:s};return await this.transformerProvider.generateView(a,r.hi.SportsGameStats)}getMatchesMetadata(t,e){if(!e)return[];const s=(0,d.nD)(t.followedSports)?new Map:t.followedSports,i=(0,d.Yo)(e);return e.map(e=>{const a=e.sportsMatchData,r=s.get(a.participantOne?.satoriId||"")||s.get(a.participantOne?.yId||"")||!1,n=s.get(a.participantTwo?.satoriId||"")||s.get(a.participantTwo?.yId||"")||!1;return{matchData:e,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,participantOneFollowed:r,participantTwoFollowed:n,isContainLiveMatch:i,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:t.isHeroCard,isVertical:!0}})}async getMatchViews(t){const e=t.map(t=>this.transformerProvider.generateView(t,r.hi.SportsMatch));return(await Promise.all(e)).filter(d.z2)}async getMatchWithScoresViews(t){const e=t.map(t=>this.transformerProvider.generateView({matchMetadata:t},r.hi.SportsMatchWithScores));return(await Promise.all(e)).filter(d.z2)}transformSportsSpotlightData(t,e){const{statistics:s}=t,i=t.match&&this.transformMatchData(t.match);let a,r=d.Zi,c=d.ZL;const h=[];if(i){const t=i.participantOne?.primaryColorHex===i.participantTwo?.primaryColorHex&&"ffffff"===i.participantOne?.primaryColorHex?.toLowerCase();!t&&i.participantOne?.primaryColorHex&&(r=(0,d.gS)(i.participantOne.primaryColorHex)),!t&&i.participantTwo?.primaryColorHex&&(c=(0,d.gS)(i.participantTwo.primaryColorHex)),i.matchClickthroughUrl?a=i.matchClickthroughUrl:i.gameCenterUrl&&(a=(0,d.Ot)(i.gameCenterUrl),i.matchClickthroughUrl=a),h.push({sportsMatchData:i})}let p=[];e&&(p=e.map(t=>(!(t=this.transformMatchData(t)).matchClickthroughUrl&&t.gameCenterUrl&&(t.matchClickthroughUrl=(0,d.Ot)(t.gameCenterUrl)),{sportsMatchData:t})));const g=this.transformGameState(s,[r,c]);if(g||0!==p.length)return{matchlist:h,upcomingMatchList:p,sportsGameStats:g,matchClickthroughUrl:a||"",isSeasonStats:s&&s.season&&2===s.season.length};(0,n.vV)(o.BfS,"Missing both game stats and upcoming match data",`market=${l.T3.CurrentMarket}`,t)}transformMatchData(t){const e=(0,d.yn)(t.gameStartDateTime);return t.gameDate=(0,d.AL)(e,l.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,d.ry)(e,l.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,t.gameStateCatetory="string"!=typeof t.gameState?(0,d.m5)(t.gameState.state):t.gameStateCatetory,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,d.PH)(t.gameState)),t.participantOne&&(t.participantOne.scheduleUrl=(0,d.Ot)(t.participantOne.gameCenterUrl)),t.participantTwo&&(t.participantTwo.scheduleUrl=(0,d.Ot)(t.participantTwo.gameCenterUrl)),t.gameCenterUrl&&(t.matchClickthroughUrl=(0,d.Ot)(t.gameCenterUrl)),t.participantOne.imageUrl=(0,d.iK)(t.participantOne.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.participantTwo.imageUrl=(0,d.iK)(t.participantTwo.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.gameState=t.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:t.gameStateCatetory,t}transformGameState(t,e){if((0,d.nD)(t))return;let s=[];t.season&&2===t.season.length?s=t.season:t.game&&2===t.game.length&&(s=t.game);const i=[];if(s[0]&&s[1]){const a=s[0],r=s[1],n=t.statsKeyOrder||Object.keys(a);for(const t of n){const s=Number(a[t]),n=Number(r[t]),o=this.gameStatsFormatMap[t],l=this.formatGameStatsNumber(s,o),c=this.formatGameStatsNumber(n,o),d=this.calculatePercentNumbers(s,n),h={key:this.gameStatsLocKeyMap[t]||t,left:s,right:n,leftText:l,rightText:c,leftColor:e[0],rightColor:e[1],...d};i.push(h)}}return i}formatGameStatsNumber(t,e){if(!e)return t.toString();let s="";return e.isPercent&&(s="%"),void 0!==e.toFix?`${t.toFixed(e.toFix)}${s}`:`${t}${s}`}calculatePercentNumbers(t,e){let s=0,i=0,a=0;return 0!==t&&0!==e?(a=.7,s=t/(t+e)*99.3,i=e/(t+e)*99.3):0===t&&0===e?(s=0,i=0,a=0):0===t?(s=2.3,i=97,a=.7):0===e&&(s=97,i=2.3,a=.7),{leftPercent:Number(s.toFixed(1)),rightPercent:Number(i.toFixed(1)),gap:a}}}Promise.resolve().then(s.bind(s,71817)),Promise.resolve().then(s.bind(s,9038)),Promise.resolve().then(s.bind(s,4708)),Promise.resolve().then(s.bind(s,88502)),Promise.resolve().then(s.bind(s,58669))},71372(t,e,s){s.d(e,{a(){return n}});var i=s(56911),a=s(92011),r=s(95144);let n=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,i.Cg)([r.x],n)},9038(t,e,s){s.r(e),s.d(e,{SportsGameStats(){return j}});var i=s(56911),a=s(20517),r=s(83546),n=s(60815);class o extends a.z{constructor(){super(...arguments),this.isMitUx=!1,this.isAdaptiveThemeEnabled=(0,r.h)()}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}}(0,i.Cg)([n.sH],o.prototype,"isMitUx",void 0);var l=s(92011),c=s(86856),d=s(63033),h=s(59669),p=s(4126),g=s(22131);const m=h.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,v=h.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,u=h.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,x=h.A` .game-stats-item-content{transform:scaleX(-1)}`,f=h.A` .game-stats-list{background:var(--button-light-rest)}.game-stats-item-header > span:nth-child(2){font-weight:550}@media (prefers-color-scheme:dark){.game-stats-list{background-color:#00000040}.game-stats-item{color:#fff}.game-stats-title{color:#fff}}`,b=h.A` :host{width:100%;position:relative;--button-light-rest:rgba(255,255,255,0.70)}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new c.t(null,x),new d.N(u,v),new p.o("isAdaptiveThemeEnabled",!0,m),new p.o("isMitUx",!0,f),(0,g.mr)(h.A` :host{forced-color-adjust:auto}`));var w=s(89757),$=s(69259),y=s(68835);const S=w.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,k=w.qy`
    <div class="team-container">
        ${(0,$.z)((t,e)=>0!==e.index,w.qy`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,$.z)((t,e)=>0===e.index,w.qy`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,F=w.qy`
    <div class="game-team-icons">
        ${(0,y.ux)(t=>t.viewModel.participants,k,{positioning:!0})}
    </div>
`,M=w.qy`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,T=w.qy`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,$.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,F)}
        ${(0,$.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,M)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,y.ux)(t=>t.viewModel.sportsGameStats,S)}
        </div>
    </div>
`,P=w.qy`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,y.ux)(t=>t.viewModel.sportsGameStats,w.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,z=w.qy`${t=>t.viewModel?.isCopilotTheme?P:T}`,G=w.qy`
    ${(0,$.z)(t=>null!=t.viewModel,z)}
`;let j=class extends o{};j=(0,i.Cg)([(0,l.E)({name:"sports-game-stats",template:G,styles:b,shadowOptions:{delegatesFocus:!0}})],j)},88502(t,e,s){s.r(e),s.d(e,{SportsMatchWithScores(){return S}});var i=s(56911),a=s(20517);class r extends a.z{shouldShowTable(){return void 0!==this.viewModel.tableView}}var n=s(92011),o=s(47810),l=s(86856),c=s(63033),d=s(59669),h=s(22131);const p=d.A` :host{--line-style:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,g=d.A`
`,m=d.A`
`,v=d.A` :host{--line-style:#F2F2F2;--background-color:#FAFAFA}.vert-match{display:flex;height:216px;padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:12px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.match-cntnr,.game-info,.line,.scores-table{width:100%}.game-info{display:flex;flex-direction:column;align-items:flex-start;padding:4px 0px;gap:6px;border-radius:8px}.game-item{display:flex;justify-content:space-between;align-items:flex-start;align-self:stretch;gap:20px}.game-title,.game-value{line-height:var(--type-ramp-minus-1-line-height,16px);font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;white-space:nowrap;color:${o.l}}.game-value{text-align:right;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.line{height:1px;background:var(--line-style)}.scores-table{min-height:1px}`.withBehaviors(new l.t(g,m),new c.N(null,p),(0,h.mr)(d.A` :host{forced-color-adjust:auto}`));var u=s(89757);const x=u.qy`
    <sports-match class="match-cntnr"
        :viewModel="${t=>t.viewModel.match}"
    ></sports-match>
`,f=u.qy`
    <div class="game-info">
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.leagueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.leagueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                 ${t=>t.viewModel.gameInfoStrings.venueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.venueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.streamTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.streamValue}
            </div>
        </div>
    </div>
`,b=u.qy`
    <sports-scores-table class="scores-table"
        :viewModel="${t=>t.viewModel.tableView}"
    ></sports-scores-table>
`,w=u.qy`
<div class="vert-match">
    ${x}
    <div class="line"></div>
    ${b}
</div>
`,$=u.qy`
    <div class="vert-match">
        ${x}
        <div class="line"></div>
        ${f}
    </div>
`,y=u.qy`
    ${t=>t.shouldShowTable()?w:$}
`;let S=class extends r{};S=(0,i.Cg)([(0,n.E)({name:"sports-match-with-scores",template:y,styles:v,shadowOptions:{delegatesFocus:!0}})],S)},58669(t,e,s){s.r(e),s.d(e,{SportsScoresTable(){return $}});var i=s(56911),a=s(71372);class r extends a.a{}var n=s(92011),o=s(47810),l=s(86856),c=s(59669),d=s(22131),h=s(63033);const p=c.A`
`,g=c.A`
`,m=c.A`
.table-cntnr{display:flex;gap:6px;align-self:stretch;justify-content:space-between}.part-row,.header-row{display:grid;align-self:stretch;justify-content:end}.header-row:last-child{gap:0}.item-cntnr{align-items:center;justify-content:end}.score-item,.header-item{text-align:center;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:16px;max-width:16px;color:${o.l}}.header-item{font-weight:400}.title-item{display:grid;text-align:left;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:24px;height:16px;color:${o.l};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bold-items{font-weight:600}.title-cntnr,.item-cntnr{display:flex;flex-direction:column;gap:6px}`.withBehaviors(new l.t(null,g),new h.N(null,p),(0,d.mr)(c.A` :host{forced-color-adjust:auto}`));var v=s(89757),u=s(68835),x=s(69259);const f=v.qy`
    ${t=>{const e=t.viewModel?.tableStyle;return(t=>v.qy`
        ${(0,u.ux)(t=>t.viewModel.participants??[],v.qy`<div class="part-row" style=${t}>
                ${(0,u.ux)(t=>t.gameScore??[],v.qy`<div class="score-item">
                    ${t=>t}
                </div>`)}
        </div>`)}
    `)(e)}}
`,b=v.qy`
    <div class="table-cntnr">
            <div class ="title-cntnr">
                <div class="title-item"></div>
                ${(0,u.ux)(t=>t.viewModel.participants??[],v.qy`<div class="title-item">
                    ${t=>t.participantName}
                </div>
                `)}
            </div>
            <div class="item-cntnr" style="${t=>t.viewModel?.isLarge?"width: 100%;":"width: 70%;"}">
                <div class="header-row" style="${t=>t.viewModel?.tableStyle}">
                    ${(0,u.ux)(t=>t.viewModel.headerRow??[],v.qy`<div class="header-item">
                        ${t=>t}
                    </div>`)}
                </div>
                    ${f}
            </div>
    </div>
`,w=v.qy`
    ${(0,x.z)(t=>void 0!==t.viewModel,b)}
`;let $=class extends r{};$=(0,i.Cg)([(0,n.E)({name:"sports-scores-table",template:w,styles:m,shadowOptions:{delegatesFocus:!0}})],$)},71817(t,e,s){s.r(e),s.d(e,{SportsSpotlight2c(){return P}});var i=s(56911),a=s(20517);class r extends a.z{constructor(){super(...arguments),this.shouldShowGameStats=()=>!!this.viewModel.sportsGameStatsCard}}var n=s(92011),o=s(47810),l=s(86856),c=s(59669),d=s(22131),h=s(63033);const p=c.A`
`,g=c.A` :host{--line-color:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,m=c.A` :host{--line-color:#F2F2F2;--background-color:#FAFAFA;--width-1c:278px;--card-height:216px}.game-stats2c,.game-stats-teams-container,.upcmng-matches2c{display:flex;justify-content:space-between}.title,.name{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal;font-weight:600;color:${o.l}}.game-stats2c{width:580px;align-items:center}.game-stats{display:flex;width:var(--width-1c);height:var(--card-height);padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:10px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.line{width:254px;height:0px;border:1px solid var(--line-color)}.game-stats-teams-container{align-items:center;align-self:stretch}.game-stats-teams-container > div{display:flex;align-items:center;gap:6px}.icon{width:16px;height:16px}.name{max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.icon img{max-width:100%;max-height:100%;width:auto;height:auto}.upcmng-matches2c{flex-direction:row;align-items:center;padding:0px;gap:24px}.upcmng-matches{display:flex;flex-direction:column;align-items:flex-start;padding:8px 12px 12px;gap:12px;width:var(--width-1c);height:var(--card-height);background:var(--background-color);border-radius:8px;box-sizing:border-box}.1c{display:flex;justify-content:center;align-items:center;width:268px}.upcmng-matches2c > div:first-of-type{width:var(--width-1c)}.game-stats2c > div:first-of-type{width:var(--width-1c)}`.withBehaviors(new l.t(null,p),new h.N(null,g),(0,d.mr)(c.A` :host{forced-color-adjust:auto}`));var v=s(89757),u=s(68835),x=s(69259);const f=v.qy`
    ${(0,u.ux)(t=>t.viewModel.matchesWithScores??[],v.qy`<sports-match-with-scores style="width: 100%;"
        :viewModel="${t=>t.viewModel}"
    ></sports-match-with-scores>`,{positioning:!0})}
`,b=v.qy`
    ${t=>{const e=t?.viewModel?.matchesWithScores?.[0]?.viewModel?.match;return e?(t=>v.qy`
    <div class="title">
        ${t=>t.viewModel.sportsGameStatsTitle||""}
    </div>
    <div class="line">
    </div>
    <div class="game-stats-teams-container">
        <div>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantOneImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
            <span class="name" title="${t.matchData.sportsMatchData.participantOne?.name||""}">
                    ${t.matchData.sportsMatchData.participantOne?.name||""}
            </span>
        </div>
        <div>
            <span class="name" title="${t.matchData.sportsMatchData.participantTwo?.name||""}">
                    ${t.matchData.sportsMatchData.participantTwo?.name||""}
            </span>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantTwoImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
        </div>
    </div>
`)(e):""}}
`,w=v.qy`
    <div class="game-stats">
        ${b}
        <sports-game-stats :viewModel="${t=>t.viewModel.sportsGameStatsCard?.viewModel}">
        </sports-game-stats>
    </div>
`,$=v.qy`
    <div class=upcmng-matches>
        <div class="title">${t=>t.viewModel.sportsUpcomingMatchesTitle}</div>
        ${(0,u.ux)(t=>t.viewModel.upcomingMatches??[],v.qy`
            <div class="line"></div>
            <sports-match
                :viewModel="${t=>t.viewModel}"
            ></sports-match>`,{positioning:!0})}
    </div>
`,y=v.qy`
    <div class="game-stats2c">
        <div>
            ${f}
        </div>
        ${w}
    </div>
`,S=v.qy`
    <div class="upcmng-matches2c">
        <div>
            ${f}
        </div>
        ${$}
    </div>
`,k=v.qy`
    <div class="1c">
        ${f}
    </div>
`,F=v.qy`
    ${t=>t.shouldShowGameStats()?y:S}
`,M=v.qy`
    ${t=>"_2x_2y"===t.viewModel.cardSize?F:k}
`,T=v.qy`
    ${(0,x.z)(t=>null!=t.viewModel,M)}
`;let P=class extends r{};P=(0,i.Cg)([(0,n.E)({name:"sports-spotlight-2c",template:T,styles:m,shadowOptions:{delegatesFocus:!0}})],P)}}]);