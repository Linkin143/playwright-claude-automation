"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["na-trending"],{60665:function(t,e,i){i.r(e),i.d(e,{MsnNativeAdTrending:function(){return f}});var n=i(56911),r=i(92011),o=i(38493),a=i(45183),s=i(40450),d=i(66864);let l=class extends d.t{constructor(){super(...arguments),this.destinationUrl="",this.show=!1,this.trendingText="",this.trendingTitleText="",this.title="",this.isHovered=!1,this.telemetryMetadata=void 0}};(0,n.Cg)([(0,o.CF)({attribute:"destination-url"})],l.prototype,"destinationUrl",void 0),(0,n.Cg)([(0,o.CF)({mode:"boolean"})],l.prototype,"show",void 0),(0,n.Cg)([(0,o.CF)({attribute:"trending-text"})],l.prototype,"trendingText",void 0),(0,n.Cg)([(0,o.CF)({attribute:"trending-title-text"})],l.prototype,"trendingTitleText",void 0),(0,n.Cg)([(0,o.CF)({attribute:"title"})],l.prototype,"title",void 0),(0,n.Cg)([(0,o.CF)({mode:"boolean",attribute:"is-hovered"})],l.prototype,"isHovered",void 0),(0,n.Cg)([(0,o.CF)({attribute:"tel-metadata"})],l.prototype,"telemetryMetadata",void 0),l=(0,n.Cg)([(0,a.TA)(s.PDj,"msn-native-ad-trending")],l);var p=i(59669),g=i(16559);let h=(0,p.A)` .trending{display:flex;align-items:center;width:fit-content;z-index:4;position:relative;margin-bottom:6px;margin-inline-start:16px}.trending-icon{margin-inline-end:8px;height:20px}.trending-text{font-size:16px;line-height:22px;color:var(--neutral-foreground-rest)}.trending-text{font-size:16px;line-height:22px;color:var(--neutral-foreground-rest)}`.withBehaviors(new g.e("layoutStyle"));var C=i(89757);let v=(0,C.qy)`
<svg width="10" height="15" viewBox="0 0 10 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.14402 0.5C13.832 8.2259 0.853628 11.7276 4.78378 15.5C-0.506663 14.9421 -0.933888 10.3758 1.20549 7.9611C3.34487 5.54636 5.85618 3.43211 4.14402 0.5Z" fill="white"/>
    <path d="M4.14402 0.5C13.832 8.2259 0.853628 11.7276 4.78378 15.5C-0.506663 14.9421 -0.933888 10.3758 1.20549 7.9611C3.34487 5.54636 5.85618 3.43211 4.14402 0.5Z" fill="url(#paint0_linear_27423_100350)"/>
    <path d="M8.5662 7.773C8.75445 8.02976 9.20139 8.65285 9.35239 8.94521C10.529 11.2234 10.4074 14.3857 6.38367 15.3647C4.10828 13.5202 7.25937 11.2291 8.10536 9.55795C8.71225 8.35911 8.48139 7.82733 8.5662 7.773Z" fill="white"/>
    <path d="M8.5662 7.773C8.75445 8.02976 9.20139 8.65285 9.35239 8.94521C10.529 11.2234 10.4074 14.3857 6.38367 15.3647C4.10828 13.5202 7.25937 11.2291 8.10536 9.55795C8.71225 8.35911 8.48139 7.82733 8.5662 7.773Z" fill="url(#paint1_linear_27423_100350)"/>
    <defs>
        <linearGradient id="paint0_linear_27423_100350" x1="7.38188" y1="16.794" x2="4.11768" y2="-0.862736" gradientUnits="userSpaceOnUse">
            <stop offset="0.033147" stop-color="#F4322A"/>
            <stop offset="1" stop-color="#FFB400"/>
        </linearGradient>
        <linearGradient id="paint1_linear_27423_100350" x1="7.38188" y1="16.794" x2="4.11768" y2="-0.862736" gradientUnits="userSpaceOnUse">
            <stop offset="0.033147" stop-color="#F4322A"/>
            <stop offset="1" stop-color="#FFB400"/>
        </linearGradient>
    </defs>
</svg>
`,x=(0,C.qy)`<div class="trending" title="${t=>t.trendingTitleText}"><div class="trending-icon">${v}</div><a class="trending-text">${t=>t.trendingText}</a></div>`,f=class extends l{};f=(0,n.Cg)([(0,r.E)({name:"msn-native-ad-trending",template:x,styles:h})],f)}}]);