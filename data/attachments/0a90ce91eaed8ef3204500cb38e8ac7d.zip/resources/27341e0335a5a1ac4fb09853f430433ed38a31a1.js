"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-marchmadness"],{82724(e,t,i){i.r(t),i.d(t,{SportsMatchTransformer(){return c}});var a=i(11796),n=i(79811),o=i(31157),r=i(50180),s=i(32150),l=i(83991);class c extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.preGame?e.preGameNotificationMessage:null,this.getPostGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.postGame?e.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=e=>this.isNotificationEnabledAndAvailable(e)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=e=>null!=this.getPreGameNotificationMessage(e)||null!=this.getPostGameNotificationMessage(e),this.getTeamColor=(e,t="")=>e?.primaryColor?(0,n.gS)(e.primaryColor):e?.primaryColorHex?(0,n.gS)(e.primaryColorHex):t,this.getTeamImageUrl=e=>{if(e?.imageUrl)return(0,n.Hv)(e?.imageUrl);const t=(0,n.iK)(e?.imageId,!e?.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return(0,n.Hv)(t)},this.getBackgroundGradient=e=>{if(!e)return"";const t=this.getTeamColor(e.participantOne),i=this.getTeamColor(e.participantTwo);if(!t||!i||t===i&&"#ffffff"===t.toLowerCase())return"";const a=this.hexToRgba(t,1),n=this.hexToRgba(t,.35),o=this.hexToRgba(i,1),r=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${n} 11%,\n                        ${n} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${r} 85.25%,\n                        ${r} 89%,\n                        ${o} 89.25%,\n                        ${o} 100%)`},this.isRTLDirection=()=>document.dir===o.O.rtl,this.getGameDate=e=>{const{gameStartDateTime:t,gameStateCatetory:i}=e||{};if(this.isCopilotTheme){const e=(0,n.yn)(t),o=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return e.toLocaleDateString(s.T3.CurrentMarket,o)}{const e=(0,n.yn)(t);return(0,n.AL)(e,s.T3.CurrentMarket)}}}async transform(e){return{viewModel:await this.getViewModel(e)}}updateAdditionalInfo(e){const{sportsMatchData:t}=e;if(t&&t.additionalInfo){if(!t.additionalInfo.round&&t.additionalInfo.roundLocKey){let e=this.transformerProvider.strings[t.additionalInfo.roundLocKey];t.additionalInfo.roundParams?.forEach((t,i)=>{e=e?.replace(`{${i}}`,t)}),t.additionalInfo.round=e}if(!t.additionalInfo.roundSummary&&t.additionalInfo.roundLocKey){let e=this.transformerProvider.strings[t.additionalInfo.roundSummaryLocKey];t.additionalInfo.roundSummaryParams?.forEach((t,i)=>{e=e?.replace(`{${i}}`,t)}),t.additionalInfo.roundSummary=e}}}getGroupInfo(e){const t=e.matchData.sportsMatchData;if(!e.isMitUX||t.gameStateCatetory!==a.Xp.inprogressGame){if(e.isMitUX&&t.phaseId){if("Group"===t.phaseId)return this.formatGroupText(t.group);const e=this.getPhaseLabel(t.phaseId);if(e)return e}return t.groupInfo?this.formatGroupText(t.groupInfo):e.topDetailText||void 0}}formatGroupText(e){const t=this.transformerProvider.strings.groupTextStr||this.transformerProvider.strings.groupText;if(!t)return;const i=t.split("${0}").join("{0}");return(0,r.GP)(i,e??"")}getPhaseLabel(e){const t=this.transformerProvider.strings;return{RoundOf32:t.bracketPhaseNameRoundOf32,RoundOf16:t.bracketPhaseNameRoundOf16,QuarterFinal:t.bracketPhaseNameQuarterfinal,SemiFinal:t.bracketPhaseNameSemifinal,Final:t.bracketPhaseNameFinal}[e]}hexToRgba(e,t=1){const i=e.match(/\w\w/g);if(!i)return"";const[a,n,o]=i.map(e=>parseInt(e,16));return`rgba(${a},${n},${o},${t})`}hasLongScore(e){const t=e.participantOne?.score||"",i=e.participantTwo?.score||"";return t.length+i.length>6}getHeaderText(e){if(!e||0===Object.keys(e).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:t,gameDate:i,gamePeriodAndClock:n,gameStateCatetory:o}=e,r=e.participantOne?.score,s=e.participantTwo?.score,l=e.participantOne?.standings,c=e.participantTwo?.standings,d=new Date(t).getFullYear(),p=e.gameStartTime?e.gameStartTime.toLocaleLowerCase():"";let h,g,m,x,f;switch(o){case a.Xp.preGame:h=p,g=this.isCopilotTheme?i:`${i}, ${d}`,m=l,x=c;break;case a.Xp.inprogressGame:h=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),g=n,m=r,x=s;break;case a.Xp.postGame:h=this.transformerProvider.strings.sportsStateFinal,g=`${i}, ${d}`,m=r,x=s;break;default:h=p,g=i,m=l,x=c}switch(!0){case!!h&&!!g:f=`${h} • ${g}`;break;case!!h:f=h;break;case!!g:f=g;break;default:f=""}return{header:f,topScoreText:m,bottomScoreText:x,leftHeaderText:h,rightHeaderText:g}}async getViewModel(e){const{matchData:t,isVertical:i,telemetryConstants:o,showMatchUXV2:r,noBackgrounds:c,participantOneFollowed:d,participantTwoFollowed:p,reason:h,isContainLiveMatch:g,parentTelemetryObject:m,useLargeTeamIcon:x,hasVerticalLine:f,isSpotlight2Card:v,isSpotlightCard:u}=e||{},$=t.sportsMatchData;this.isCopilotTheme=e.isCopilotTheme||!1,this.updateAdditionalInfo(t),"string"!=typeof $.gameState&&($.gameStateCatetory=(0,n.m5)($.gameState.state));const w=(0,n.yn)($.gameStartDateTime);$.gameDate=this.getGameDate($),$.gameStartTime=($.gameStartDateTimeIsToBeAnnounced?null:(0,n.ry)(w,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof $.gameState&&($.gamePeriodAndClock=(0,n.PH)($.gameState)),"string"!=typeof $.gameState&&($.gamePeriod=$.gameState.gamePeriod),$.participantOne&&($.participantOne.scheduleUrl=(0,n.Ot)($.participantOne.gameCenterUrl)),$.participantTwo&&($.participantTwo.scheduleUrl=(0,n.Ot)($.participantTwo.gameCenterUrl)),$.gameCenterUrl&&($.matchClickthroughUrl=(0,n.Ot)($.gameCenterUrl)),$.participantOne.imageUrl=(0,n.iK)($.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),$.participantTwo.imageUrl=(0,n.iK)($.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),$.gameState=$.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:$.gameStateCatetory,e.isMitUX&&$.gameStateCatetory===a.Xp.inprogressGame&&($.tvChannel=void 0);const b={...o,name:a.BP.Game},y=i||e.isCopilotTheme,k=this.transformerProvider.config.enableLiveScores,z=r&&!c&&!k,F=(0,n.jJ)()?`${s.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${s.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:k||r?"":this.getBackgroundGradient($),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(m,{...b,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore($),gameNumber:"number",linkTarget:"_blank",matchData:t,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary($),overrideStyleForMatch:"",participantOneColor:z?this.getTeamColor($.participantOne):"",participantOneFollowed:d,participantOneImgIcon:this.getTeamImageUrl($.participantOne),participantTwoColor:z?this.getTeamColor($.participantTwo):"",participantTwoFollowed:p,participantTwoImgIcon:this.getTeamImageUrl($.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage($),preGameNotificationMessage:this.getPreGameNotificationMessage($),reason:h,shouldDisplayT4:!g,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(m,b),cardSize:e.cardSize,topDetailText:this.getGroupInfo(e),useLargeTeamIcon:k||x,enableLiveScores:!e.isMitUX&&(k||r),showMatchUXV2:k||r,noBackgrounds:c,isVertical:i,headerText:y?this.getHeaderText($):void 0,needsVerticalLine:f,liveIconUrl:F,isSpotlight2Card:v,isSpotlightCard:u,isCopilotTheme:this.isCopilotTheme,isWindows:s.T3.AppType===l.u.WindowsNewsWidgets,isMitUX:e.isMitUX}}}},36516(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},10500(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},65617(e,t,i){i.r(t),i.d(t,{SportsMarchmadnessTransformer(){return m},SportsMatchTransformer(){return x.SportsMatchTransformer}});var a=i(41432),n=i(11796),o=i(50180);const r="Match",s="Quarterfinal",l="SemiFinal",c="Championship",d="Champion",p=e=>{const t=e?"AA1dH5oj":"AA1dH0n8";return(0,o.GP)("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w={1}&h={2}&q=60&m=6&f=png&u=t",t,"28","30")};var h=i(79811),g=i(96950);class m extends n.Bc{constructor(){super(...arguments),this.getMediumCardMatchCount=()=>{switch(this.uxType){case c:case d:return 1;case l:case s:return 2;default:return 3}},this.getBigCardMatchCount=()=>{switch(this.uxType){case c:case d:return 1;case l:return 2;case s:return 4;default:return 5}},this.getShowMatchCount=()=>{switch(this.cardSize){case a.uE._1x_2y:return this.getMediumCardMatchCount();case a.uE._1x_3y:return this.getBigCardMatchCount();default:return 1}}}async transform(e){const t=await this.getViewModel(e);return{viewTemplate:g.qy`
                <sports-marchmadness
                    :viewModel="${t}"
                ></sports-marchmadness>`}}async getViewModel(e){this.cardSize=e.cardSize;const t=e.matchData[0].sportsMatchData;"string"!=typeof t.gameState&&(t.gameStateCatetory=(0,h.m5)(t.gameState.state));const i=t.gameStateCatetory,a=i===n.Xp.postGame,{bracketPhase:o,league:g}=e.tabContent||{};this.uxType=((e,t)=>{const{league:i}=t||{};return i&&i.contentHeaderLine1&&i.shouldShowContentHeaderImage?i.headerImage?l:s:i&&i.contentHeaderLine1?e===n.Xp.postGame?d:c:r})(i,e.tabContent);const m=(0,h.jJ)(),x=this.getHeaderImage(g.headerImage,a),f=await this.getMatchViews(e);return{bracketIconUrl:p(m),bracketPhase:o,cardSize:this.cardSize,headerImage:x,isPostGame:a,matchClickthroughUrl:this.getMatchClickthroughUrl(t,g),headerLine1:g.contentHeaderLine1,headerLine2:g.contentHeaderLine2,matchViews:f,uxType:this.uxType,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:n.BP.MarchMadnessCard})}}async getMatchViews(e){if(!e.matchData)return;const t=e.followedSports||new Map,i=this.getShowMatchCount(),a=e.matchData.slice(0,i),o=(0,h.Yo)(a),r=this.uxType===c||this.uxType===d,s=e.tabContent?.league?.clickThroughUrl,l=a.map(async i=>{const a=i.sportsMatchData;r&&s&&(a.gameCenterUrl=s);const l=(0,h.gK)(a.participantOne,t),c=(0,h.gK)(a.participantTwo,t),d={matchData:i,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:l,participantTwoFollowed:c,topDetailText:a.matchHeader,isContainLiveMatch:o,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores};return this.transformerProvider.generateView(d,n.hi.SportsMatch)});return(await Promise.all(l)).filter(h.z2)}getIconInfo(e){const t=this.cardSize===a.uE._1x_3y;return e?{width:t?108:70,height:t?108:70}:t?{height:108,width:153}:{height:80,width:114}}getHeaderImage(e,t){if(!e)return"";const i=this.getIconInfo(t);return(0,h.iK)(e,!1,i)}getMatchClickthroughUrl(e,t){return(this.uxType===c||this.uxType===d)&&t?.clickThroughUrl?(0,h.Ot)(t.clickThroughUrl):e.matchClickthroughUrl||""}}var x=i(82724);Promise.resolve().then(i.bind(i,9236)),Promise.resolve().then(i.bind(i,80195))},20517(e,t,i){i.d(t,{z(){return r}});var a=i(56911),n=i(60815),o=i(92011);class r extends o.L{}(0,a.Cg)([n.sH],r.prototype,"viewModel",void 0)},9236(e,t,i){i.r(t),i.d(t,{SportsMarchmadness(){return T}});var a=i(56911),n=i(20517);class o extends n.z{}var r=i(92011),s=i(48751),l=i(41123),c=i(61138),d=i(70289),p=i(63033),h=i(74849),g=i(22131);const m=h.A` .semifinal-name{color:#FFFFFF}`,x=h.A` .match-data{text-decoration:none;${d.f};display:flex;flex-direction:column;justify-content:space-around}._1x_3y .match-data{justify-content:normal}.match-list{display:flex;flex-direction:column;row-gap:12px}.content{display:grid;gap:12px;height:100%;position:relative}.tournament{display:flex;flex-direction:column;row-gap:40px;justify-content:center}._1x_2y .tournament{row-gap:20px}.header,.semifinal-top-icon,.champ-head{display:flex;align-items:center;justify-content:center;color:${s.l}}._1x_2y .semifinal-top-icon{display:none}.semifinal-top-icon img{height:82px}._1x_2y .header-image{display:none}._1x_3y .header-image{display:flex;justify-content:center}._1x_3y .header-image img{height:82px}.tournament-name{font-size:${l.K};line-height:${l.Z};font-weight:700}.tournament-icon{width:22px;height:18px}.tournament-phase{font-size:${c.k};line-height:${c.F}}.semifinal-icon,.quarterfinal-icon{height:24px}.semifinal-icon img,.quarterfinal-icon img{height:24px}.semifinal-name,.quarterfinal-name{font-size:16px;font-weight:900;line-height:24px;letter-spacing:0px;text-align:center;text-transform:uppercase;margin:0 2px}.icon-right{transform:scale(-1)}.final-header{height:36px}.champ-head{flex-direction:column;text-align:center;row-gap:6px}._1x_3y .champ-head{row-gap:16px;margin-bottom:28px;margin-top:24px}.desc{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);color:${s.l};overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:268px}.top-text{text-align:center;font-size:24px;text-transform:uppercase;font-weight:900;line-height:24px;max-width:268px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.top-text.one-line{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.champ-head.post-game{row-gap:0px}.post-game .desc{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);text-transform:uppercase;font-weight:600}`.withBehaviors(new p.N(null,m),(0,g.mr)(h.A` :host{forced-color-adjust:auto}`));var f=i(96950),v=i(39957),u=i(69259);const $=f.qy`
    <div class="match-list">
        ${(0,v.ux)(e=>e.viewModel.matchViews,f.qy`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,w=f.qy`
    ${(0,u.z)(e=>e.viewModel.headerImage,f.qy`
        <div class="header-image">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />
        </div>`)}
`,b=f.qy`
    <div class="tournament">
        <div>
            ${w}
            <div class="header final-header">
                <div class="quarterfinal-icon">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
                <div class="quarterfinal-name">
                    ${e=>e.viewModel.headerLine1?.toLowerCase()}
                </div>
                <div class="quarterfinal-icon icon-right">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
            </div>
        </div>
        ${$}
    </div>
`,y=f.qy`
    <div class="desc" title="${e=>e.viewModel.headerLine2}">${e=>e.viewModel.headerLine2}</div>
`,k=f.qy`
    <a class="match-data"
        href="${e=>e.viewModel.matchClickthroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}"
        target="_blank"
    >
        <div class="champ-head${e=>e.viewModel.isPostGame?" post-game":""}">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />

            <div>
                <div class="top-text${e=>e.viewModel.headerLine2?" one-line":""}" title="${e=>e.viewModel.headerLine1}">${e=>e.viewModel.headerLine1}</div>
                ${(0,u.z)(e=>e.viewModel.headerLine2,y)}
            </div>
        </div>
        ${$}
    </a>
`,z=f.qy`
    <div class="content ${e=>e.viewModel.cardSize}">
        ${e=>((e,t)=>{if("_1x_1y"===t)return $;switch(e){case"Match":default:return $;case"SemiFinal":case"Quarterfinal":return b;case"Champion":case"Championship":return k}})(e.viewModel.uxType,e.viewModel.cardSize)}
    </div>
`,F=f.qy`
    ${(0,u.z)(e=>null!=e.viewModel,z)}
`;let T=class extends o{};T=(0,a.Cg)([(0,r.E)({name:"sports-marchmadness",template:F,styles:x,shadowOptions:{delegatesFocus:!0}})],T)},80195(e,t,i){i.r(t),i.d(t,{SportsMatch(){return le}});var a=i(56911),n=i(52921),o=i(60815),r=i(20517);class s extends r.z{constructor(){super(...arguments),this.isMitUx=!1,this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}viewModelChanged(){this.isMitUx=!0===this.viewModel?.isMitUX}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(e,t,i,a){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();const o="keydown"===e.type||"keypress"===e.type||"keyup"===e.type;(0,n.LE)(e.currentTarget,o,t),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,t,a)}}}(0,a.Cg)([o.sH],s.prototype,"isMitUx",void 0);var l=i(92011),c=i(48751),d=i(62047),p=i(61138),h=i(41123),g=i(71157),m=i(62198),x=i(4283),f=i(70289),v=i(63033),u=i(50882),$=i(74849),w=i(4126),b=i(22131);const y="#CD3800",k="#E98F6D",z=$.A` .date,.nodate{width:auto}`,F=$.A` .sports-match{background-color:rgba(255,255,255,0.7);border-radius:8px;padding:7px 5px;gap:23px;justify-content:center;height:66px;box-sizing:border-box}.side-by-side-matchup-content{width:242px}.side-by-side-gradient-container{background-image:none !important}.participant-container{height:52px;justify-content:center;align-items:center;width:74px}.participant-icon,.participant-icon.logo-backplate{width:45px;height:45px}.participant-container .logo-backplate.participant-icon-large img{width:45px;height:45px}.game-in-progress-text{color:#1A1A1A}@media (prefers-color-scheme:dark){.sports-match{background-color:#00000040}}`,T=$.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${k}}.game-in-progress-text{color:${k}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${k};background-color:${k}}.standings-style{color:${c.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,C=$.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${f.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${c.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${c.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${c.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${c.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${c.l}}.foreground-rest-text-color{color:${c.l}}.top-game-detail{color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${c.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${c.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${p.k};line-height:${p.F};color:${c.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${h.K};line-height:${h.Z};font-weight:600;color:${c.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${c.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${y};font-size:${p.k};line-height:${p.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${y};font-size:${d.t}}.participant-name-style{font-size:${p.k};line-height:${p.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${g.T};line-height:${g.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${p.k};line-height:${p.F};max-width:100px}.game-score-notification-text-style{font-size:${g.T};line-height:${g.O}}.game-score-text-style{color:${c.l};line-height:${g.O};font-size:${m.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${y};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${c.l};font-size:${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${d.t};line-height:${d.e};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${c.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${h.K};line-height:${h.Z};font-weight:900;color:${c.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${p.k};line-height:${p.F};font-weight:600;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;color:${x.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${y};width:16px;height:0;left:126px;top:20px;position:absolute;background-color:${y}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${c.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${c.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${c.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${f.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new v.N(null,T),(0,b.mr)($.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${u.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${u.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${u.A.LinkText}}.click-for-detail{border:1px solid;background-color:${u.A.LinkText}}.detail-live-animation{background-color:${u.A.LinkText}}.scores-line{overflow:hidden}}`),new w.o("isWindowsCopilot",!0,z),new w.o("isMitUx",!0,F));var M=i(11796),_=i(50180),S=i(96950),I=i(69259),j=i(36516),A=i(10500),D='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const L=(e,t)=>S.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,_.GP)(t?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",e.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:M.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:M.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||""):null}"
        data-t="${e=>e.viewModel?.followTelemetryTag}"
    >
        <div class="${e=>t?"icon-add":"icon-selected"}"> ${S.qy.partial(t?j.A:A.A)}</div>
    </div>
`,V=S.qy`
    <div class="game-details">
        ${S.qy`<div class="top-game-detail">${e=>e.viewModel.topDetailText}</div>`}
        ${e=>((e,t,i=null,a=null)=>{switch(e.getMatchData().gameStateCatetory){case M.Xp.preGame:return null==i?Y():ee(i);case M.Xp.inprogressGame:return oe();case M.Xp.postGame:return t?ne():(0,_.oT)(e.viewModel.topDetailText)?ie(a||""):ae();default:return Y()}})(e,e.viewModel.shouldShowChampionPostGame,e.viewModel.preGameNotificationMessage,e.viewModel.postGameNotificationMessage)}
    </div>
`,O=S.qy`
    <div class="${e=>e.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${V}
        ${e=>P(e.getMatchData().additionalInfo)}
    </div>
`,U=()=>S.qy`
    <div class="g-dtl ${e=>e.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${e=>e.getMatchData().gameStateCatetory===M.Xp.inprogressGame?B:""}
            ${e=>e.getMatchData().gameStateCatetory===M.Xp.postGame?N:""}
            <div class="kscr-cntr">
                <span class="kscr ${e=>e.getMatchData().participantOne?.isWinner?"winner-team":""} part-left">
                    ${(0,I.z)(e=>e.getMatchData().participantOne?.isWinner,S.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${S.qy.partial(D)}</span>`)}
                    ${e=>e.getMatchData().participantOne?.score??""}
                </span>
                ${e=>(0,_.oT)(e.getMatchData().participantOne?.score||"")||(0,_.oT)(e.getMatchData().participantTwo?.score||"")?"":q}
                <span class="kscr ${e=>e.getMatchData().participantTwo?.isWinner?"winner-team":""}">
                    ${e=>e.getMatchData().participantTwo?.score??""}
                    ${(0,I.z)(e=>e.getMatchData().participantTwo?.isWinner,S.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${S.qy.partial(D)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,H=()=>S.qy`
    <div class="date">
        <div class="prehdr">${e=>e.viewModel.headerText?.rightHeaderText}</div>
        <div class="ktime">${e=>e.getMatchData().gameStartTime}</div>
    </div>
`,P=e=>e?S.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${e.round||""}
                </div>
                <div class="round-summary-info">
                    ${e.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${e.scores}
                </div>
            </div>
        `:null,q=S.qy`
    <span class="scores-line">${S.qy.partial(M.Z5)}</span>
`,G=S.qy`
    <span>${S.qy.partial("·")}</span>
`,B=S.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${e=>e.viewModel.liveIconUrl}" />
        <span class="r-live-text">${M.T0.Live}</span>
    </div>
`,N=S.qy`
    <div class="pghdr">
        <span>${M.T0.Final}</span>
        ${e=>e.getMatchData().gameDate?G:""}
        <span>${e=>e.getMatchData().gameDate}</span>
    </div>
`,X=S.qy`
    <div class="vert-noline">
        <div class="vert-header ${e=>e.getMatchData().gameStateCatetory===M.Xp.inprogressGame?"in-prog-vert":""}">
            ${e=>e.viewModel.headerText?.header}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>e.getMatchData().participantOne?.name}">
                        ${e=>e.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===M.Xp.preGame?"standings-style":""}">${e=>e.viewModel.headerText?.topScoreText}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>e.getMatchData().participantTwo?.name}">
                        ${e=>e.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===M.Xp.preGame?"standings-style":""}">${e=>e.viewModel.headerText?.bottomScoreText}</div>
            </div>
        </div>
    </div>
`,E=S.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>e.getMatchData().participantOne?.name||""}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>e.getMatchData().participantTwo?.name||""}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${e=>e.viewModel.headerText?.leftHeaderText}</div>
            <div>${e=>e.viewModel.headerText?.rightHeaderText}</div>
        </div>
    </div>
`,R=S.qy`
    ${e=>e.viewModel.isSpotlightCard?W:Q}
`,Z=S.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>e.getMatchData().participantOne?.name||""}"
                />
            </div>
            <div class="kname ${e=>!e.getMatchData().participantOne?.shortName&&e.getMatchData().participantOne?.name?"long-name":""}" title="${e=>e.getMatchData().participantOne?.name||""}">
                ${e=>e.getMatchData().participantOne?.shortName||e.getMatchData().participantOne?.name||""}
            </div>
        </div>
        ${e=>(e=>e.getMatchData().gameStateCatetory===M.Xp.inprogressGame||e.getMatchData().gameStateCatetory===M.Xp.postGame?U():H())(e)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>e.getMatchData().participantTwo?.name||""}"
                />
            </div>
            <div class="kname ${e=>!e.getMatchData().participantTwo?.shortName&&e.getMatchData().participantTwo?.name?"long-name":""}" title="${e=>e.getMatchData().participantTwo?.name||""}">
                ${e=>e.getMatchData().participantTwo?.shortName||e.getMatchData().participantTwo?.name||""}
            </div>
        </div>
    </div>
`,Q=S.qy`
    <a class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}"
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${Z}
    </a>
`,W=S.qy`
    <div class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}">
        ${Z}
    </div>
`,J=S.qy`
    ${e=>e.viewModel.needsVerticalLine?E:X}
`,K=S.qy`
    <a class="
        sports-match matchup-neutral-background
        ${e=>e.viewModel.noBackgrounds?"no-bg":""}
        ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>e.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${e=>`background-image: ${e.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${e=>e.viewModel.overrideStyleForMatch} ${e=>e.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${e=>e.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${e=>L(e.getMatchData().participantOne||{},!e.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${e=>e.getMatchData().participantOne?.name}">
                    ${e=>e.isMitUx?e.getMatchData().participantOne?.shortName||e.getMatchData().participantOne?.name||"":e.getMatchData().participantOne?.name||""}
                </div>
            </div>
            ${O}
            <div class="participant-container right-participant ${e=>e.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantTwoColor};`}">
                    ${(0,I.z)(e=>e.viewModel.isSpotlight2Card,S.qy`${e=>L(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,I.z)(e=>!e.viewModel.isSpotlight2Card,S.qy`${e=>L(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${e=>e.getMatchData().participantTwo?.name}">
                    ${e=>e.isMitUx?e.getMatchData().participantTwo?.shortName||e.getMatchData().participantTwo?.name||"":e.getMatchData().participantTwo?.name||""}
                </div>
            </div>
        </div>
    </a>
`,Y=()=>S.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${e=>e.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gameDate} - ${e.getMatchData().tvChannel}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameDate||""}</span>
            ${e=>e.getMatchData().tvChannel&&e.getMatchData().gameDate?q:""}
        <span>${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,ee=e=>S.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime+"-"+e.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${e=>""+(e.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${e}">
        <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${e}
        </span>
    </div>
`,te=()=>S.qy`
    <div class="middle-game-detail ${e=>e.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,I.z)(e=>e.getMatchData().participantOne?.isWinner,S.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${S.qy.partial(D)}</span>`)}
            ${e=>e.getMatchData().participantOne?.score??""}
        </span>
        ${e=>(0,_.oT)(e.getMatchData().participantOne?.score||"")||(0,_.oT)(e.getMatchData().participantTwo?.score||"")?"":q}
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantTwo?.score??""}
            ${(0,I.z)(e=>e.getMatchData().participantTwo?.isWinner,S.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${S.qy.partial(D)}</span>`)}
        </span>
    </div>
`,ie=e=>S.qy`
    <div class="top-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?G:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
    ${te()}
    ${(0,I.z)(!(0,_.oT)(e),S.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${e}">
            <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${e}
            </span>
        </div>
    `)}
`,ae=()=>S.qy`
    ${te()}
    <div class="bottom-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?G:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
`,ne=()=>S.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${e=>re(e)}
        </div>
        <div class="game-winner-description" title="${e=>e.viewModel.strings.champions||""}">
            ${e=>e.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantOne?.score??""}
        </span>
        ${e=>(0,_.oT)(e.getMatchData().participantOne?.score||"")||(0,_.oT)(e.getMatchData().participantTwo?.score||"")?"":q}
        <span class="game-score-text-style">
            ${e=>e.getMatchData().participantTwo?.score??""}
        </span>
    </div>
`,oe=()=>S.qy`
    <div class="middle-game-detail">
        ${e=>e.viewModel.enableLiveScores?S.qy`
    <span class="game-score-text-style">
        ${e=>e.getMatchData().participantOne?.score??""}
    </span>
    ${e=>(0,_.oT)(e.getMatchData().participantOne?.score||"")||(0,_.oT)(e.getMatchData().participantTwo?.score||"")?"":q}
    <span class="game-score-text-style">
        ${e=>e.getMatchData().participantTwo?.score??""}
    </span>
`:S.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${e=>(e.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.enableLiveScores?"live-scores-detail":""}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gamePeriodAndClock} - ${e.getMatchData().tvChannel}`:e.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${e=>e.getMatchData().gamePeriodAndClock}">
            ${e=>e.getMatchData().gamePeriodAndClock||""}
        </span>
        ${e=>e.getMatchData().gamePeriodAndClock&&e.getMatchData().tvChannel?q:""}
        <span title="${e=>e.getMatchData().tvChannel}">${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,re=e=>{const t=e.getMatchData();if(t&&t.gameStateCatetory==M.Xp.postGame){let e=t.participantOne?.isWinner?t.participantOne?.name?.toUpperCase():null;return e||(e=t.participantTwo?.isWinner?t.participantTwo?.name?.toUpperCase():null),e||""}return""},se=S.qy`
    ${e=>e.isVertical()?S.qy` ${J} `:e.isCopilotTheme()?S.qy` ${R} `:e.viewModel?S.qy` ${K} `:void 0}
`;let le=class extends s{};le=(0,a.Cg)([(0,l.E)({name:"sports-match",template:se,styles:C,shadowOptions:{delegatesFocus:!0}})],le)},99657(e,t,i){i.d(t,{D(){return r},I(){return o}});var a=i(68136);const{create:n}=a.G,o=n("sloppy-click-z-index",1),r=n("click-z-index",1)},38817(e,t,i){i.d(t,{R7(){return x},e(){return g},kc(){return m},nH(){return h}});var a=i(57416),n=i(55153),o=i(95239),r=i(26920),s=i(48751),l=i(64187),c=i(22131),d=i(74849),p=i(50882);const h=d.A` :host([size][card-fill-color="light-blue"]){background:linear-gradient(140.53deg,#f0e1f7 9.32%,#cddfff 58.45%)}:host([size][card-fill-color="light-purple"]){background:linear-gradient(139.03deg,#ffe9e1 5.05%,#f0e1f7 51.71%)}:host([size][card-fill-color="light-sky"]){background:linear-gradient(140.53deg,#f5f7e1 9.32%,#cdf0ff 58.45%)}:host([size][card-fill-color="light-pink"]){background:linear-gradient(139.03deg,#fff1cd 5.05%,#ffe8ed 51.71%)}:host([size][card-fill-color="light-yellow"]){background:linear-gradient(140.53deg,#fffedc 9.32%,#fff4d7 58.45%)}:host([size][card-fill-color="light-bluebird"]){background:linear-gradient(139.03deg,#e1e6f8 5.05%,#ebfefb 51.71%)}:host([size][card-fill-color="light-orange"]){background:linear-gradient(140.56deg,#f0e1f7 5.42%,#ffe9e1 51.68%)}:host([size][card-fill-color="light-aqua"]){background:linear-gradient(140.56deg,#cef9ff 5.42%,#e3f9f3 51.68%)}:host([size][card-fill-color="light-green"]){background:linear-gradient(140.56deg,#fffee9 5.42%,#d0f0e1 51.68%)}:host([size][card-fill-color="dark-plum"]){background:linear-gradient(138.52deg,#512c2c -1.32%,#252c4e 85.77%)}:host([size][card-fill-color="dark-desert"]){background:linear-gradient(138.25deg,#553f2b -1.2%,#372d54 84.27%)}:host([size][card-fill-color="dark-dawn"]){background:linear-gradient(140.02deg,#58314f -2.33%,#29203c 84.75%)}:host([size][card-fill-color="dark-sea"]){background:linear-gradient(138.52deg,#264b50 0.44%,#292448 85.15%)}:host([size][card-fill-color="dark-orange"]){background:linear-gradient(140.69deg,#514c28 -7.13%,#482b24 87.33%)}:host([size][card-fill-color="dark-tropic"]){background:linear-gradient(140.08deg,#0b4b4f 1.27%,#39371e 85.21%)}:host([size][card-fill-color="dark-merlot"]){background:linear-gradient(140.02deg,#5c452f -2.33%,#3a1b26 84.75%)}:host([size][card-fill-color="dark-purple"]){background:linear-gradient(140.02deg,#283266 -2.33%,#351740 84.75%)}:host([size][card-fill-color="dark-green"]){background:linear-gradient(138.44deg,#57511f 0.35%,#17352f 83.81%)}`,g=d.A` ${(0,l.V)("flex")} :host{background:${o.p};outline:calc(${r.XA} * 1px) solid ${n.cu};border-radius:calc((${a.JU} - ${r.XA}) * 1px);box-shadow:0px 2px 4px rgba(0,0,0,0.04);box-sizing:border-box;color:${s.l};contain:content;content-visibility:auto}:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@supports selector(:nth-child(1 of x)){:host{outline:none;box-shadow:0 0 0 calc(${r.XA} * 1px) ${n.cu},0px 2px 4px rgba(0,0,0,0.04)}:host(:hover){box-shadow:0 0 0 calc(${r.XA} * 1px) ${n.cu},0px 4px 8px rgba(0,0,0,0.14)}@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0 0 0 calc(${r.XA} * 1px) ${n.cu},0px 4px 8px rgba(0,0,0,0.26)}}}:host([size="_1x_1y"]){width:calc(${n.QG} * 1px);height:calc(${n.l8} * 1px)}:host([size="_1x_2y"]){width:calc(${n.QG} * 1px);height:calc((${n.l8} * 2px) + (${n.Sn} * 1px))}:host([size="_2x_2y"]){width:calc((${n.QG} * 2px) + (${n.Sn} * 1px));height:calc((${n.l8} * 2px) + (${n.Sn} * 1px))}:host([size="_2x_1y"]){width:calc((${n.QG} * 2px) + (${n.Sn} * 1px));height:calc(${n.l8} * 1px)}::slotted(*){color:inherit}`,m=(0,c.mr)(d.A` :host{background:${p.A.Canvas};color:${p.A.CanvasText}}`),x=d.A` ${g} ${h} :host([card-secondary-color]){background:linear-gradient( var(--gradient-angle),var(--gradient-start-color) 35.59%,var(--gradient-end-color) 100% );background-clip:padding-box}`.withBehaviors(m)},70289(e,t,i){i.d(t,{f(){return l}});var a=i(64187),n=i(74849),o=i(38817),r=i(99657),s=i(36452);const l=n.A.partial`position: relative; z-index: ${r.D};`;n.A` ${o.e} ${o.nH} ${(0,a.V)("grid")} :host{grid-template-rows:auto 1fr minMax(16px,auto);grid-template-columns:100%;${l}}.content{padding:0 var(--sd-card-content-padding-inline,16px);overflow:hidden}::slotted([slot="header"]){grid-row:1}::slotted([slot="footer"]){grid-row:3}::slotted([slot="image"]){position:absolute;bottom:0;right:0;left:0;width:100%;height:100%;object-fit:cover;z-index:-1}::slotted(fluent-button[appearance="neutral"]),::slotted(fluent-anchor[appearance="neutral"]){border:1px solid ${s.I2}}::slotted(fluent-button[appearance="neutral"]:hover),::slotted(fluent-anchor[appearance="neutral"]:hover){border-color:${s.mb}}::slotted(fluent-button[appearance="neutral"]:active),::slotted(fluent-anchor[appearance="neutral"]:active){border-color:${s.MY}}.header-overlay,.footer-overlay{position:absolute;background:rgba(255,255,255,0.46);height:100%;width:100%;opacity:0}.header-overlay{grid-row:1 / span 1}.footer-overlay{grid-row:3 / span 1}.gradient{position:absolute;grid-row:2 / span 1;height:100%;width:100%;opacity:0;background:linear-gradient( 180deg,rgba(255,255,255,0.46) 0%,rgba(255,255,255,0) 22%,rgba(255,255,255,0) 86%,rgba(255,255,255,0.46) 100% )}@media (prefers-color-scheme:dark){.header-overlay,.footer-overlay{background:rgba(0,0,0,0.54)}.gradient{background:linear-gradient( 180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 22%,rgba(0,0,0,0) 86%,rgba(0,0,0,0.54) 100% )}}:host([immersive-card]) .header-overlay,:host([immersive-card]) .footer-overlay,:host([immersive-card]) .gradient{opacity:1}`.withBehaviors(o.kc)}}]);