"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_video-card-wc_dist_components_PlutoTvPlayerElement_js"],{60630:function(e,t,l){l.d(t,{PlutoTvPlayerElement:function(){return i}});var a=l(56911),o=l(59669),r=l(89757),n=l(92011);let s=(0,o.A)`
.plutoTV_root > iframe{
    border: none;
    height: 70vh;
    min-height: 720px;
    width: 100%;
}`,u=(0,r.qy)`
<div class="plutoTV_root" data-t="${e=>e.videoCardProps?.telemetryContext?.parentTelemetry?.getMetadataTag()}">
    <iframe class="plutotvplayer" scrolling="no" src="//msn.pluto.tv/" allowfullscreen="true" allow="autoplay; fullscreen"></iframe>
</div>`,i=class extends n.L{};i=(0,a.Cg)([(0,n.E)({name:"pluto-tv-player",template:u,styles:s})],i)}}]);